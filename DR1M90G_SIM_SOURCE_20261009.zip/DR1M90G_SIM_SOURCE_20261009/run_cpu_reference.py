"""Replay the existing scalar Hard PW + PL DW/Add arithmetic; NO device access.
Requires numpy and onnxruntime (import dependency of original reference modules).
This is a mathematical reference, not a HardNPU cycle model.
"""
from pathlib import Path
import importlib.util,json,os,sys
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import numpy as np
base=Path(__file__).resolve().parent
root=base/'source'
stage=root/'experiments/sol_block34_hard_20261007'
spec=importlib.util.spec_from_file_location('bundle_block34_reference',stage/'reference.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
ref=module.HardBlock34Reference(stage/'assets_vendor')
fixture=root/'experiments/sol_block34_cached_20261008/board_candidate/fixture'
x=np.load(fixture/'input.npy',allow_pickle=False)
expected=np.load(fixture/'expected.npy',allow_pickle=False)
actual=ref(x)
delta=actual.astype(np.int64)-expected.astype(np.int64)
report={'scope':'CPU arithmetic replay, not device performance','input_shape':list(x.shape),
 'output_shape':list(actual.shape),'dtype':str(actual.dtype),'different_values':int(np.count_nonzero(delta)),
 'max_absolute_error':int(np.abs(delta).max()),'pass':bool(np.array_equal(actual,expected))}
out=base/'verification';out.mkdir(exist_ok=True)
(out/'cpu_reference.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['pass'] else 1)
