# 仿真、时钟、资源与证据边界

## 本包便携离线入口

`run_sim.py`直接使用原RTL与原testbench，不生成新的算法核。每次结果在`verification/simulation_results.json`和各case日志；它们是本次实跑依据。

| case | testbench与范围 | 测试时钟 | 不能外推的内容 |
|---|---|---|---|
| dw_split | 真实输入两种DW144模式；数值、范围、backpressure和最后B响应 | TB 100MHz | 当前板端PL为80MHz；模拟AXI等待不是实板DDR等待 |
| resize | 三张不同1080p真实图→224×224，与已保存Q22/Pillow参考逐像素比较 | 80MHz | 无实际传感器/DDR/HardNPU |
| isp_resize | 128位四像素输入→跨时钟串行化→缩放，两张不同真实图 | 输入100MHz、处理80MHz | 激励每行32µs约28.94fps，不证明约50fps相机输入可被完整处理 |
| isp_fault | 小FIFO溢出、首拍错误行末，故障粘滞与禁止有效输出 | 见原TB | 非完整故障恢复/真实板卡测试 |
| small_fdma | 224几何、像素打包、50176像素、448个burst与槽选择 | 见原TB | 使用已保留的uidbuf_sim仿真副本和模拟DMA，不等于实际DDR上板 |

`uidbuf_sim.v`是历史阶段为Icarus声明语法整理的仿真副本；综合工程中的原`uidbuf.v`同时保留，不能混称同一源。

双像素缩放在`source/experiments/sol_pillow_resize_pair_20261009/`，原sim1存在readmemh路径截断、参考未加载问题，其PASS无效。本包不将此候选纳入通过列表，不修改或掩盖历史失败。

## 时钟和约束必须成套阅读

现有已上板DW split候选的目录：`source/experiments/sol_block34_dw_split_20261008/`。

1. `soc_v2.prj`：器件DR1M90GEG400、speed 2和源文件列表。
2. `physical_dw_split.tcl`：实际加载约束与P&R顺序。
3. `camera_dsi_pins.adc`：实际该候选引脚约束。
4. `board_softnpu_80mhz.sdc`：IOPLL400MHz、P2F0除5=80MHz、P2F1除10=40MHz等IP属性；板端分频必须一致。
5. `uisrc/04_pin/timing.sdc`：输入I_sysclk 10ns、derive_pll_clocks及相关相机PLL时钟。
6. `dwsplit_first_stage_cdc.sdc`和`dwsplit_reset_first.sdc`：仅针对相应网表同步器/复位第一级的例外；加载流程见`dwsplit_first_stage.tcl`和`dwsplit_final.tcl`。
7. `final_timing.rpt`、`camera_dsi_dwsplit_final.ts`、`camera_dsi_dwsplit_phy.area`：历史布局布线后的对应证据。

小图候选另见`source/experiments/sol_pillow_resize_20261009/integrated/`的prj、physical_small.tcl、first_stage_small.tcl、small_first_stage.sdc及timing/area/ts文件。不要把DWsplit的SDC例外无条件套到新网表。

历史状态记录：DWsplit约46932 slices /150 ERAM /174 DSP，最终SWNS+0.108ns、HWNS+0.023ns，STA coverage63.52%；单像素小图集成约47971 slices /156 ERAM /186 DSP，最终SWNS+0.103ns、HWNS+0.024ns，coverage64.82%。这些为既有报告，不是本次重跑P&R。小图候选未BIT/BOARD通过。

外部MIPI接收时钟未完整出现在相关clock summary中，不能声称全部IO时序已证明。资源对比必须同阶段（综合对综合、P&R对P&R），不能把独立核资源相加当作完整工程结果。

## 外部依赖与可复现范围

模块仿真无需厂商许可证。完整SoC综合/时序与厂商IP仿真仍需要匹配TD 6.2.1环境、DR1设备数据库及合法的原语/IP模型；本包仅带项目已有的源码/配置/SDC，不复制安装目录或许可证。

原项目和历史Tcl可能保留绝对主机路径，实际重建时应在新的隔离副本中重定向。`check_bundle.py`会审计两个主要工程的File引用是否已包含（对原工作副本绝对路径仅在审计时重定位），不代表厂商库已经齐备。生成.db、bit、elf、so、ko、exe和大型工具安装文件未打包。

HardNPU接口可用于数学对齐、packet/布局核验和准备真实板测；缺少Hard硬核周期模型，不能声称本包已完成整芯片周期精确仿真。新的ASL CNN周期、资源、时序必须分别取得对应RTL/厂商综合/P&R/板测证据。
