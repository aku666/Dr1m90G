"""Device-free source integrity, captured asset and project dependency checks."""
from pathlib import Path
import hashlib,json,os,xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent
ROOT=Path('\\\\?\\'+str(BASE)) if os.name=='nt' else BASE
def main():
    manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    bad=[]
    for item in manifest:
        p=ROOT/item['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:bad.append(item['path'])
    assets=ROOT/'source/experiments/sol_block34_cached_main_20261008/combined_assets'
    spec=json.loads((ROOT/'source/experiments/sol_block34_buffer_20261008/candidate/main/combined_jobs.json').read_text())
    checks=[]
    for i,job in enumerate(spec['jobs']):
        for kind in ['packet','weight']:
            p=assets/f'{kind}_{i}.bin';data=p.read_bytes()
            expected=job.get(kind+'_sha256')
            ok=len(data)==job[kind+'_bytes'] and (expected is None or expected==hashlib.sha256(data).hexdigest())
            checks.append({'slot':i,'kind':kind,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'metadata_sha_present':expected is not None,'pass':ok})
    projects=[]
    for rel in ['source/experiments/sol_block34_dw_split_20261008/soc_v2.prj','source/experiments/sol_pillow_resize_20261009/integrated/camera_small_aa224.prj']:
        p=ROOT/rel;parsed=ET.parse(p);files=[]
        for n in parsed.findall('.//File'):
            val=n.attrib.get('Path','')
            if not val:continue
            q=p.parent/val
            # Original projects may retain host absolute paths. Rebase only for this audit.
            native=val.replace('\\','/')
            original='C:/Users/16429/.codex/worktrees/19de/fdma_imx415_20251008/'
            if native.startswith(original):q=ROOT/'source'/native[len(original):]
            files.append({'reference':val,'included':q.is_file()})
        projects.append({'project':rel,'references':len(files),'missing':[f for f in files if not f['included']]})
    report={'source_files':len(manifest),'source_hash_mismatches':bad,'current_main_abi':spec['abi'],
       'captured_assets':checks,'project_dependency_audit':projects,
       'hardnpu_internal_rtl':'NOT_INCLUDED_NOT_FOUND_IN_SELECTED_PROJECT',
       'vendor_primitive_libraries':'EXTERNAL_NOT_BUNDLED',
       'full_soc_simulation':'NOT_RUN','board':'NOT_RUN',
       'pass':not bad and all(x['pass'] for x in checks)}
    folder=ROOT/'verification';folder.mkdir(exist_ok=True)
    (folder/'bundle_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='captured_assets'},indent=2))
    return 0 if report['pass'] else 1
if __name__=='__main__':raise SystemExit(main())
