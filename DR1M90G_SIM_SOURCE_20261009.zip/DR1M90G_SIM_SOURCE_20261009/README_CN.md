# DR1M90G 可仿真源码与硬件接口交接包

整理日期：2026-10-09。来源为活跃工作副本 `C:/Users/16429/.codex/worktrees/19de/fdma_imx415_20251008`，不是原目录的过期快照，也不依赖GitHub下载。

用户新方向是单帧ASL英文24字母（排除J/Z）。本包提供已有硬件与软件接口作为新算法适配依据；包内旧模型、真实测试向量及历史报告仍属于原动态手语工程，不是已经训练完成的24字母模型。

本次交付验证：5项RTL仿真全部PASS；完整BLOCK34 CPU数学回放与保存输出逐值一致（最大误差0）；16组packet/weight共32个文件通过长度及现有hash核对；两个主要工程101/103项File引用均已包含。实际日志见verification。以上均为离线检查，本次没有板测或重新综合/P&R。

## 先读这三个文件

1. `HARDNPU_INTERFACE.md`：当前驱动ABI、作业入口、张量布局、量化及实际载荷。
2. `SIMULATION_AND_TIMING.md`：可运行的模块仿真、时钟约束、资源/时序证据和外部依赖。
3. `verification/bundle_check.json` 与 `verification/simulation_results.json`：本次交付检查和实际复跑结果。历史日志不能覆盖本次结果，反之工具启动问题也不取消历史有效结果。

## 包含内容

| 路径（均相对本包） | 用途 |
|---|---|
| `source/experiments/sol_block34_buffer_20261008/candidate/main/` | 当前完整空间主入口的Hard固定所有者驱动、ABI 0x42341910、16项作业配置 |
| `source/experiments/sol_block34_buffer_20261008/board_20261009/` | 从实际板端取回的运行源码、日志和数值验证记录；和准备目录分开保存 |
| `source/experiments/sol_block34_cached_main_20261008/combined_assets/` | 上述16项作业复用的真实packet与weight二进制 |
| `source/experiments/sol_block34_cached_20261008/board_candidate/` | BLOCK34六项Hard作业的输入/权重/输出样例、PL参数及旧ABI配套参考 |
| `source/implementation_hardnpu/` | 驱动、DMA合同、分片张量布局、CPU桥接与定点参考源码 |
| `source/tools/npu/` | 实际捕获packet解码、量化、布局与映射工具源码 |
| `source/experiments/sol_block34_dw_split_20261008/` | 现有上板SoC对应RTL、工程文件、DW testbench、向量、SDC与历史P&R报告 |
| `source/experiments/sol_pillow_resize_20261009/` | 单像素缩放、跨时钟输入、小图FDMA的RTL、testbench、三张真实图像向量和参考 |
| `source/experiments/sol_pillow_resize_pair_20261009/` | 未完成数值资格的双像素候选，仅供研究；不在默认复跑列表中 |
| `source/experiments/sol_resident_ring_20261009/` | 常驻/摄像头接口和GP互斥修复候选；实时panic修复尚未BOARD通过 |
| `source/model_pipeline/src/sign_model/` | 原训练/预处理/模型接口代码；无新24类训练结果 |
| `source/docs/` | 工程总览、HW_SW_INTERFACE、构建说明和最新相关日志 |

`source/`为逐字节原样导出，保留原目录结构。`SOURCE_MANIFEST.json`逐文件给出来源、大小和SHA-256。`SOURCE_IDENTITY.json`记录HEAD元数据；当前源码可能含未提交改动，不能仅凭commit复现，应以manifest为准。

## 离线复跑

依赖：Python 3（仅标准库）和Icarus Verilog。打包机使用Icarus 13.0；不附软件安装包、密钥或许可证。Linux或Windows安装工具后，在本包根目录运行：

```text
python check_bundle.py
python run_sim.py --jobs 1
```

Icarus未在PATH时：

```text
python run_sim.py --iverilog /path/to/iverilog --vvp /path/to/vvp --jobs 1
```

可选择 `--case dw_split`、`resize`、`isp_resize`、`isp_fault`、`small_fdma`。新入口将所需RTL及向量复制到交付目录下的临时子目录，以短相对文件名执行，避免历史绝对路径和testbench文件名截断问题；不改原RTL或testbench数学，不访问设备。

可选数学回放：安装了NumPy与ONNX Runtime的Python环境运行 `python run_cpu_reference.py`，用包内实际输入和`assets_vendor`的逐层量化/权重重算完整BLOCK34，并和保存输出比较。ONNX Runtime是原参考模块的导入依赖；此入口仅调用CPU参考，不创建硬件执行器、不测芯片周期。

默认超时900秒可用 `--timeout`调整。结果写入 `verification/`。脚本同时检查退出码、错误信息、必需PASS标记及文件读取失败；出现PASS字样不单独构成通过。再次运行会更新本地verification结果。

Windows建议解压到较短目录（如 `C:/work/dr1sim`），并使用支持长路径的解压工具。包内保留深层历史证据路径。原版生成/板测脚本可能含主机绝对路径，只作来源材料；便携离线入口是根目录的两个Python脚本。

## 这份包不能证明的内容

- 未找到并交付HardNPU内部微架构RTL或周期精确模型。已有接口、packet、CPU参考和板测日志，不等于HardNPU本体可开源RTL仿真。
- 不包含TD设备数据库、厂商仿真原语库、完整内核构建树、完整模型部署包、bit/ELF/内核模块和软件许可证。
- 包内相关PL模块可以独立仿真；完整SoC仍需要匹配的厂商IP/原语及环境，未在本轮完整SoC仿真或重做P&R。
- 现有普通卷积与PL块是特定shape/量化候选，不是任意新网络可直接执行的通用NPU编译器。
- 仿真周期只对应所选时钟和testbench的AXI响应模型；不能替代真实DDR、CPU调度、Hard执行耗时和屏幕光学延迟。
- 历史源与证据存在不表示持续30fps、新24类精度或长期实体显示已经完成。

交付阶段只做文件导出、接口整理与离线验证；没有操作板卡、写Flash、重建原工程或覆盖known-good产物。
