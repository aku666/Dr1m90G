# HardNPU调用、张量与量化接口索引

以下均为实际文件索引；不是新发明的芯片规格。路径相对 `source/`。

## 1. 选择同一版本的接口

当前完整空间固定作业入口：

- 驱动：`experiments/sol_block34_buffer_20261008/candidate/main/driver/space16_fixed/space16_span_fixed_main.c`
- UAPI：同目录 `block_run_uapi.h`，ABI **0x42341910**，设备 `/dev/space16_span_fixed`。
- DMA/尺寸：同目录 `block_dma_contract.h`、`block_frozen_config.h`及相邻 `driver/h10_multishard/`源码；不能只复制wrapper。
- Python调用：`experiments/sol_block34_buffer_20261008/candidate/main/runtime/space16_executor.py`。
- 16项作业：`experiments/sol_block34_buffer_20261008/candidate/main/combined_jobs.json`。
- 不变的真实载荷：`experiments/sol_block34_cached_main_20261008/combined_assets/packet_0.bin`到`packet_15.bin`及对应`weight_*.bin`。
- 结构定义依赖：`implementation_hardnpu/runtime/h10_fixed_model_executor.py`，包含Status/Model/Input/Output/Release及ioctl构造。

BLOCK34独立入口为`candidate/block/driver/block34_hard_fixed/`，当前ABI **0x42343410**。早期`board_candidate/jobs.json`可能保留生成时的旧ABI字段；仅将其当作不变作业/资产说明，不能覆盖当前UAPI版本。完整主入口的combined_jobs已携带0x42341910。

时序TCN/旧H10/新缩放还有各自ABI，不能因为寄存器地址相同就混用。`source/docs/architecture/HW_SW_INTERFACE.md`保留完整版本背景。

## 2. 实际调用顺序与完成语义

固定模型模式采用：读冷态与ABI → 预载packet/weight → 提交本次输入 → RUN → 检查完成、IRQ、错误、保护区及输出 → 复制输出 → 成功释放当前输入/输出；常驻资产复用。代码中ioctl号如0x21状态、0x28模型、0x25输入、0x20运行，仅和其结构及当前ABI一起使用。

当前executor认可的成功状态包含phase=3、writes=8、irq=1、work=5、guard=0、reason=0，细节以相应源代码为准。不能只检查IRQ或单个done位。

CPU传入的用户地址由内核复制，不是可直接交给DMA的物理地址。实际DMA基址重定位、32位地址范围、缓冲生命周期、完整输出和失败固定缓冲逻辑均在驱动中。超时/未知DMA状态不能重复提交或提前释放。

本包的离线脚本完全不执行上述真实设备调用。

## 3. 布局与权重

- 主机侧当前普通PW输入/输出主要是连续UINT8 NCHW；逐项shape和bytes以combined_jobs为准，不能套一个全网统一shape。
- 示例slot 0：输入`[1,32,56,56]`、100352B；输出`[1,144,56,56]`、451584B。逻辑C24输入补齐到C32时补的是输入zero-point（该作业106），不是数值0。
- 投影层按行分片，slot 1示例`[1,144,19,56] → [1,24,19,56]`；不是把分片按文件顺序简单拼接就总能恢复NCHW。
- 分片布局实现：`implementation_hardnpu/common/pointwise_tensor_layout.{c,h}`；packet结构/字段解码：`tools/npu/pointwise_packet_contract.py`。
- 对设备的weight.bin是实际厂家打包载荷；不能把ONNX权重直接reshape后当作设备布局。packet中含bias和量化/几何信息，设备地址还需要驱动重定位。
- 字节序、参数record及边界以解析器/对应RTL为准；当前packet按little-endian 32位word解析。各PL参数结构可能采用不同打包，不要统一假设。

## 4. 量化规则：Hard与PL不能混写

当前BLOCK34 Hard PW整数参考：

`acc = Σ((x - input_zero) * (w - weight_zero)) + bias`

`y = clip(((acc * multiplier) >> shift) + output_zero, 0, 255)`

对应源：`experiments/sol_block34_buffer_20261008/board_20261009/evidence/block34_span1/main/runtime/block34_cpu_reference.py`。它先检查signed32累加范围，再使用宽整数乘法和算术右移；这里不能擅自改为四舍五入。multiplier/shift以及每层zero-point必须来自该候选合同/捕获载荷。

现有PL DW/残差参考则使用nearest/ties-to-even重新量化：`implementation_hardnpu/runtime/dw16_reference.py::requantize`。负数、中点、饱和和通道广播都影响结果。`front_block3.py`、`front_block4.py`和`front_block*_native.c`提供相应连续块/CPU实现；Hard参考类对普通PW覆盖了原PL参考的量化方法。

新单帧模型若采用不同量化数学，必须重新导出并核验，不能借用旧零差报告。旧候选对其CPU整数参考零差也不意味着与原FP32零差。

用于这组参考的逐层scale/zero/multiplier/shift与UINT8权重、int32 bias已包含在`experiments/sol_block34_hard_20261007/assets_vendor/block3/`和`block4/`；配套原`reference.py`保留，根目录`run_cpu_reference.py`可直接数学回放。不要误用同阶段未采用的group32候选。

## 5. PL/DMA相关接口

主要RTL在`experiments/sol_block34_dw_split_20261008/uisrc/01_rtl/`：`front96/`、`front_block34/`、`dw16/`、`capture/`及`system/`。现有时序V4R也随集成源码保留，但新单帧分类不必启用。

DW144独立mode：1为C144/56×56/stride1，2为stride2输出28×28、DDR行pitch补到32字节，0仍为原完整BLOCK34。匹配control ABI0x60002和mode寄存器说明见该stage的preparation.json及驱动；preparation早期PENDING不覆盖后续实际日志。

HP0传输按当前AXI3接口每burst最多16拍、不得跨4KiB边界。输出完成必须等待全部写响应B完成；testbench显式验证最终B响应排空。AXI行为模型仅模拟握手、间隔和数据，不是DR1真实DDR控制器。

实时视频GP控制与PL调用的已知冲突及最小互斥候选在`experiments/sol_resident_ring_20261009/gp_write_gate.py`。其导致历史panic的因果仍未上板确认，不要据此声称实时稳定。
