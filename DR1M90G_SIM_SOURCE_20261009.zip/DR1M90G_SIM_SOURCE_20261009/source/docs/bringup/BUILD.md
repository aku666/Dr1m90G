# Build and Baseline Protection

## T01目标构建与生产入口（2026-09-29）

冷恢复第二轮复用两已编译模块，不重编：H5 9c117c...45051，Soft c934f9...da63从已取回board_evidence.tgz恢复到/run/t01_cold2。旧Soft80MHz JTAG临时下载/DTB CRC0660312d，无Flash写入；run_product_board.sh /run/t01_cold2/product实际退出0。16帧输出验收通过，归档/准确命令见experiments/product_20260929_T01_cold2；Hard卸载0，Soft固定等待冷恢复。

只传19个当前源/依赖共60777B新包到/root/product_20260929_T01_1，无模型/库重传；H5 native模块9c117c1137177b67ffc59b5ec85d414ac03d6791750b60ea16f5b5e31cc45051。核对发现Soft core与驱动的ABI宏也须同步，工作副本及板端本次/run副本均改1000b，目标重编退出0，实际模块c934f906a7a8252d20bcbf119926ecb8394010fa52540740e96117d89c81da63。初次1166fc...模块只作未运行草稿，不用于实验；实际源/模块将随board_evidence.tgz保存。

已有旧Soft80MHz bit/DTB临时下载启动，DTB CRC0660312d与原证据一致，div07070904；用户物理恢复后正常Linux模块空才软件重启进入U-Boot，无Flash/boot环境保存。原CPU库/模型/raw16帧复用，输入SHA bb1d522abafd7ebf026e4d6603793c986547f739ae061891dbd4f0feec6ad0d6与当前PC16保存图预处理相同。实际Hard新模块在START前空闲拒绝，不能软件重启/热换后自动重试。run_product_board.sh是本轮真实已执行参数，不含自动装卸或恢复。

## 采集Soft候选构建完成（2026-09-29）

采集主入口小补丁由stage_capture_software.ps1 -ClipPatch逐文件SHA传到/run/video_clip_patch_20260929_1，模型/模块不重传。实查旧空间/Soft包PYTHONPATH分别为/root/hard_soft_live_product_20260929_1/runtime、/root/hard_soft_serial_product_20260929_1/runtime（不是该包implementation_hardnpu/runtime），TCN仍/root/tcn_grid7_fixed_product_20260929_1/implementation_hardnpu/runtime；私有Pillow及NumPy目录同前节。该纠正后板端--help退出0，不能当实际capture或NPU执行。

tools/video/prepare_soft_capture.py只读既有Soft隔离来源，当前工作树experiments/video_soft_capture_20260929_1完成elaborate/RTL及gate综合/P&R/最终STA/bitgen。capture_soft_80mhz.bit为4052202B/SHA75fcf1885632e5766a194816d538a9ac2f18d684a8f2c73bb5fa6ed3689851eb；capture_reserved.dtb为17128B/SHA167e4c98b90617bb951878194b28f155b84228a6ee99820ec648f53b4ae95d21。80/40/50MHz与该Soft来源一致。capture_reset_entry.sdc只豁免实际PS异步reset到四级同步器第一级，后三级及数据保持计时；最终SWNS+0.103/HWNS+0.022ns，coverage95.45%，非全系统验收。

capture_download.tcl已准备未执行，未Flash写入/未Generate覆盖；必须冷恢复清除旧固定Soft实例后替换PL。启动保留DTB尚未上板；启用采集前检查实际内核no-map/地址和ID10001。板端软件从已存在只读USB包仅提取PIL/pillow.libs/source_frame，私有/run路径运行，无全局安装；tools/video/stage_capture_software.ps1只传当前小软件文件并逐文件读回SHA。重启后/run丢失，复用旧包再提取即可，无需重传大模型。

## 连续空间实际运行与保存帧入口（2026-09-29）

后续可选结果渲染依赖sign_result_display.py、Pillow及显式中文字体路径；PC使用系统msyh.ttc，只读取、不复制字体到板卡。该新增显示脚本未传板端、不生成新的bit或写Flash；已封存实际板测运行包保持。实体显示需用户连接和板端实际显示设备，不能由PNG代替BOARD验收。

本阶段复用已编译H5 81408d50...b97d、Soft串行模块ad7fbb09...29b2c8及TCN2b9a2941...7b28，不重新构建模型/驱动。新独立/root/hard_soft_serial_product_20260929_1来自236286B冷恢复包SHA1e171cabf19d20589f24b5e82c2e4e4af76c40f3919fecce2b19587ba2a180fe，入口补丁c9dde96f...97f另解包，不覆盖冻结旧产品目录。临时Soft80MHz bit/DTB复用，无Flash写入。连续空间和两层时序实际START/数值已通过，分别归档hard-soft-clip-board。

后续保存帧入口需当前run_hard_soft_clip.py、frame_input.py和model_pipeline/src/sign_model/{fdma_frame,preprocess}.py以及Pillow。新--frames-dir/--raw-layout仅PC真实PNG入口运行通过，尚未同步到该已封存板端运行目录；不凭本地改动替代本次实际运行源码。现有板端原raw入口与模型不变，核验仅覆盖本次实际输出。

## 当前空间特征TCN/V4R补丁（2026-09-29）

本阶段不重建TCN模块/native库或模型，复用2b9a2941...7b28与dc2a79fe...7e3d。experiments/hard_soft_temporal_adapter_20260929_1.tar.gz（2989B，SHAc9dde96fdca9cdc8485442c858d9a00f7ea57f1e427f927d558ef21f992d197f）只含新clip时序参数入口与当前特征CPU核验工具，冻结旧连续空间冷恢复包保持。V4R入口须把旧TCN runtime加入PYTHONPATH，显式给出models/assets/native位置，不称补丁自含模型。两层实际Hard前缀在当前Soft环境通过，旧Soft原三缓冲未变，未重复Soft START。

## 两层空间候选目标构建（2026-09-29）

prepare_dual_spatial.py从正确浮点导出切prefix/bridge/tail，复用H7/H10已资格14包；生成spatial_dual_fixed wrapper，共享主驱动模型数组按显式count，默认H10仍8。输入组释放仅新wrapper指定6/0，默认H10及TCN分支行为保持；旧已资格二进制保留，不凭当前共享源替代旧源码身份。

板端独立/root/dual_spatial_product_20260929_1 native Kbuild：初版ABI100/module47ea6430...89219；当前组共享ABI101/module8046e8d6a341bfce66187df38b93e85ea6a9d0a877c8fd63f4a13ae9522e5413，三次整图通过/释放/卸载0。原Module.symvers/时钟告警及Image源码精确身份UNKNOWN保留。首次默认关闭拒绝/卸载已通过，组版没有重复未受影响的关闭门槛测试。

大模型数据复用U盘只读旧包：字节copy/literal差分在PC重建相同，并在板端复核源及输出SHA；仅串口传488765B功能包和11748B组共享补丁，没有移动U盘/覆盖旧包。未来空间准备依赖加入dual运行时；该旧H10包仍不自包含两层模型/资产/模块。旧首版与组版原始归档分别保存资格证据。

## V4R native CPU运行核（2026-09-29）

implementation_hardnpu/runtime/v4r_c128_native.c在板端独立/root/tcn_grid7_fixed_product_20260929_1以gcc -O3 -std=c11 -Wall -Wextra -Werror -fPIC -shared编译libv4r_c128.so，SHA dc2a79fe00819c715a6d5b2908fcb051c4590ca9536f507ef2069bf77e537e3d。v4r_native.py显式ctypes加载，未全局安装；没有设备访问。复用已资格TCN模块，不重建NPU模块/模型/空间包。native_board_evidence.tar.gz保留源、库、实际整数核验及混合原始输出。

未来runtime准备依赖已加入v4r_batched_temporal.py、v4r_native.py、v4r_c128_native.c；冻结USB包未重打包。模型/TCN资产/模块/native库仍需显式提供，不称原空间包已自包含整个系统。

## 当前已资格TCN产品模块（2026-09-29）

implementation_hardnpu/tcn_grid7_fixed复用共享H10 fixed-model代码，默认H10模型数8不变，TCN明确3和每层独立输入；独立ABI0x54430107。实际native Kbuild模块SHA2b9a2941ceb164e1756094c701e40b0685daba788618f240416fdf283c8b7d28，默认关闭/三层真实数值/主入口运行/释放/卸载通过。Module.symvers告警及运行Image精确源码身份UNKNOWN仍保留。归档real-tcn-grid7-fixed-board/qualified_evidence.tar.gz保存实际源、模块和日志，SHA015ae183c744043901e875b9592398c3faf2524eac5d26963f37466a8ca2ced6；未凭改动后的共享源替代旧H10 dfc9二进制身份。

板端独立/root/tcn_grid7_fixed_product_20260929_1，assets/models只读使用已冻结/root/tcn_grid7_product_20260929_1内容，未重复搬空间模型。main_entry_evidence SHA f068d56f3d5779a41e6515326fa5b27710613460a0b6595929c3d9ae76ed1bbb。prepare_h10_product_runtime未来目录加入新TCN执行器依赖，但冻结旧包不重建；TCN模块/模型/载荷仍须单独提供，不能把仅空间包称全链自包含。

## 真实TCN候选目标构建（2026-09-29）

implementation_hardnpu/tcn_pointwise复用h10_multishard源，独立冻结3包FNV/ABI。Makefile使用Kbuild正常告警选择加-Werror；不加-Wall/-Wextra放大内核头未使用参数告警。实际板端native Kbuild产物SHA f413290c7895ce8d870ee2b3cf354ea23dde39e1ac84c8f7ac7e6b7a096ab9d9，保存在first-prestart/board_evidence.tar.gz；Module.symvers/精确内核源码身份UNKNOWN保留。

cold_restore.tar.gz仅在冻结runtime_board_bundle基础上更新实际Makefile/加入真实.ko，部署新/root/tcn_pointwise_product_20260929_1，后续物理恢复复用，不再次编译。默认关闭通过、首层START完成但数值未通过；不是资格时序模块。下一软件工具tcn_cma_capture_20260929.c仅启用既有虚拟CMA supervisor的实际字节导出，后端仍隔离/不Execute，直接定位已发生的通道16边界差异。

## 当前资格串行产品模块（2026-09-28）

prepare_h10_product_runtime.py复用product-fixed-serial-board/qualified_module.tar.gz内h10_fixed_model/h10_fixed_model.ko，SHA dfc9d4eda189e5df27f660e1c1eb49c87f9c82ab4466f3a9b90fb88919c9fb8c；152实际原始片与整数参考精确、成功释放及卸载。旧7e6b模块及冻结USB包保留。新目录依赖加入run_temporal_features.py、同图benchmark及训练INT8 calibration/weights，直接服务已保存特征接时序，不重生成冻结目录。

目标仍复用板端native GCC/历史6.1.111-rt42内核构建树，Module.symvers告警及与运行Image精确身份UNKNOWN保留。完整目标日志/模块/实际源码在qualified_module归档；不凭当前源码替代旧二进制身份。特征时序补丁实际串口传输SHA1e6ad758...8df1回读一致，板端INT8/V4R CPU执行通过，不加载时序硬件。

## 固定模型目标构建与复用（2026-09-28）

implementation_hardnpu/h10_fixed_model包装复用h10_multishard主驱动/合同，H10_FIXED_MODEL切独立ABI及设备名，h10_fixed_model.inc仅固定预加载/共享输入，不新建通用调度器。板端/run/h10_fixed_model_20260928_1 native Kbuild产物SHA7e6b01...1f68f；默认关闭/单图及16帧128START/释放/卸载和独立原始数值资格验收通过。历史内核树Module.symvers缺失告警/运行Image精确源码身份UNKNOWN仍有，不由本次通过取消。

prepare_h10_product_runtime.py未来目录附h10_fixed_model_executor.py及已通过产品.ko；run_fixed_model.sh要求已加载对应模块，显式cpu-h10-fixed-model，无自动装卸/重试。既有run_mixed/诊断.ko保留，冻结USB目录不覆盖。本次宽读取比较候选无速度提升，PC源码已回退，保留首版.ko；源格式变化不冒充新模块资格验收。

## 当前H10读取开销优化版（2026-09-28）

prepare_h10_product_runtime.py未来准备默认复用product-dma-hash-board归档内SHA317d712...76020目标模块；ABI/既有客户端不变，八输出及特征已BOARD字节相同。仅优化FNV读取宽度，所有字节仍参与校验。默认关闭RUN拒绝/装卸和真实八START/释放/卸载均通过。已冻结旧USB运行包不覆盖。本次源新增measure_completion默认关闭可选测时，另建模块及成功板证在completion_timing_evidence.tar.gz；未混称317d二进制为含测时代码的同一产物。

## 当前产品板端运行（2026-09-28）

experiments/h10_product_runtime_board_20260928_1.tar.gz通过USB部署至/run/h10_product_20260928_2/h10_product_runtime；板端GCC9.3严格native编译ARM64 h10_serial_client成功，运行内核6.1.111-rt42。复用模块SHA30eb3fb...d1c4。PYTHONPATH为包内Pillow加历史私有NumPy/ORT，OPENBLAS_NUM_THREADS=1/OMP_NUM_THREADS=2；未全局安装或改rootfs。单图和真实16帧CPU＋H10已实际运行并卸载成功，状态与证据见PROJECT_STATUS最新顶部。

run_spatial_sequence.py新增--normalized-video（与--frames-dir互斥）复用板端已有真实16x3x224x224 little-endian float32张量；检查精确大小/有限值，不触设备取帧。板端源更新SHA5b922f...dd39，当前h10_executor精确BLAS更新SHAd4247bb...7a54；冻结USB包仍为原版，不覆盖其manifest。未来准备脚本自动带当前源码，不重复生成本次包。

## 当前精简单图运行目录（2026-09-28）

prepare_h10_product_runtime.py仅PC准备experiments/h10_product_runtime_20260928_1；自包含图片入口/预处理/运行时/正确浮点模型前尾/现有真实H10资产，直接复用SHA30eb3fb...d1c4已板证h10_multishard.ko。build_client.sh用板端native GCC严格编译新h10_serial_client，不访问设备；run_cpu.sh运行CPU基线；run_mixed.sh显式真实八START，必须待用户恢复上板且模块按既有条件准备后执行，没有自动装卸/复位。

当前默认模型是2026-09-28-float-prefix-h10，旧minimal-h10-spatial诊断量化模型不再产品默认。自包含目录PC两模式已运行并与此前对应128维逐字节一致。新C客户端加CLOCK_MONOTONIC每片RUN ioctl时间，Python记录金样/文件/客户端/RUN开销，RUN含驱动提交轮询；源码CODED，目标编译和BOARD未执行。电脑WSL/交叉工具链不可用，未安装或绕过系统应用控制。

## 下一单图H10混合运行入口（2026-09-28）

当前PC入口tools/npu/run_spatial_image.py默认cpu；--backend h10-fixed-cpu --h10-assets <准备的真实H10资产目录>运行CPU定点预测，不碰设备；--backend cpu-h10还需--h10-client <已目标编译客户端>，会真实执行八次START，仅用户恢复实验后运行。最小模型目录2026-09-28-minimal-h10-spatial含cpu_prefix.onnx、复用H11 cpu_tail.onnx、plan.json；资产2026-09-28-h10-runtime-assets含实际八包/权重及bias/倍率合同。

新h10_serial_client.c目标编译复用既有h10_multishard头文件，候选命令为gcc -O2 -Wall -Wextra -Werror -I<旧H10源码目录> h10_serial_client.c -o h10_serial_client；尚未执行。已有模块仍需按原版本/冷态/合法DMA及武装设置准备，不由Python自动加载/卸载/复位。prefix/尾部及CPU预测CLI实际运行，ARM客户端及cpu-h10未构建/运行。不为这一步重建全部层诊断包。


## 所有权策略PC运行（2026-09-28）

check_tensor_ownership.py以冻结graph contracts SHA加载Python策略；374节点状态流/304激活释放/10残差保留、707拒绝无状态改写及遗漏残差消费者声明拒绝通过。当前tensor-ownership-host-v2报告绑定源码SHA，v1保留。只运行Python策略，未算子数学、未新C受阻程序、未Linux/ARM构建/设备操作；账本状态不是实际allocator/DMA完成。


## 全图合同PC生成（2026-09-28）

prepare_hardnpu_graph_contracts.py源SHA锁定并checker/shape inference后生成静态DAG；bind_hardnpu_profiles_to_graph.py核冻结775profile并绑定78模型；prepare_tensor_release_contracts.py锁同contracts SHA生成304张量语义要求。PC Python三工具执行通过，输出graph-contracts-static-v2；v1仅量化多消费者结果保留，v2补完整激活10残差分支。没有C受阻程序重试/ARM构建/板端动作。这些JSON不是可执行调度器、backend分配或硬件验收。


## C输入取块编译与运行边界（2026-09-28）

check_pointwise_host_extract.py已核profile775/源225文件清单并严格编译新extract及layout主机程序。首次extract运行被Windows应用控制WinError4551拒绝，未实际取块/输出复验；2026-09-28-pointwise-c-extract-static保留编译日志/EXE、计划和失败说明。生成并核阅同源码主机汇编，仅静态证据；未Linux/ARM编译、无板端操作。脚本新增OSError失败记录分支未复验，现有证据不能提升为运行PASS。


## 普通层可移植C布局主机验证（2026-09-28）

check_pointwise_host_layout.py先复核冻结profile775文件和源225文件SHA，再用D:/mingw64/bin/gcc.exe以C11/O2/Wall/Wextra/Werror/pedantic编译common/pointwise_tensor_layout.c及主机检查程序。56整层/360乱序分片一致，拒绝路径通过；成功证据2026-09-28-pointwise-c-layout-static-v2，初次MSVCRT `%zu`格式告警失败日志保留旧目录。主机入口改用unsigned long格式，实际API为size_t。未Linux/ARM编译、未板端加载/START，无新ABI/DMA证明。详见HARDNPU_POINTWISE_C_LAYOUT_STATIC_20260928.md。


## 普通1×1真实载荷主机核验（2026-09-28）

verify_pointwise_capture.py接收真实模型/capture-log/一个或多个input/新的output-dir，只在主机核验并输出真实载荷副本及定点预期，无设备API、无覆盖已有目录。check_pointwise_contract_static.py复用历史H5/H10真实包和归档数据，18组精确、78待验证模型元数据核对、三类损坏拒绝。本轮仅使用现有PC Python依赖，无串口、板端构建/加载/START。未改变已冻结H12整包和78模型未来捕获输入包。详见HARDNPU_POINTWISE_PACKET_STATIC_CONTRACT_20260928.md。


## 28层/78模型未来厂家软件捕获输入（2026-09-28）

prepare_hardnpu_remaining_pointwise_fixtures.py及prepare_hardnpu_pointwise_profiles.py在授权工作树输出CPU模型和数据，无板卡。78子模型未来隔离捕获包86文件、813777B，SHA28e39fc7943b5342e471e7f6182ef105536b2518784242740a5614e40179f79a。三个旧同SHA捕获二进制复用，新参数化Cwrapper目标编译未执行；两份shell经本地Git Bash -n通过。stage_pointwise_software_capture_20260928.ps1 -VerifyOnly及语法通过，不开串口；未来新/run/hardnpu_pointwise_capture_20260928_1中核整包及86成员再记录暂存成功，脚本不构建/内核加载/START。真实厂家支持、Load及packet仍未运行，用户静态限制持续。


## H12T整层准备与用户程序拆分（2026-09-28）

275文件冻结包SHA4f8e4147975a518edde6f04dd7d3d6d7aab07da548913a55976cfe74042942ca，压缩1176600B，本地逐成员/当前源码一致通过；stage_h12_layer_bundle_20260928.ps1 -VerifyOnly及语法通过，未串口暂存。首块程序重构共享h12t_tile_client.h后暂存清单14文件。整层用户目标编译需h12t_tile_layer.c+h12t_tile_layout.c；内核对象仍main/dma，无新增模块ABI。主机仅实际布局C严格编译/双帧核验通过；WSL无Linux环境，未安装，Linux用户程序/Kbuild未执行。用户静态限制持续，不执行START。


## H12T静态候选构建边界（2026-09-28）

用户要求暂只静态，未运行板端构建/加载/START。`implementation_hardnpu/h12_tile/`为独立候选。prepare_h12_tile_driver_config.py以固定SHA和标准FNV生成header；stage_h12_tile_20260928.ps1 -VerifyOnly在打开串口前核13文件、config/path一致，已通过；真实暂存路径/run/h12t_tile_20260928_2，拒绝现有目录、完整标记等待12秒。原/run/..._1只创建空目录，未复制候选。目标ARM/Kbuild未执行；本地MinGW仅编译和执行纯CPU合同/身份核验，不能称模块构建或BOARD结果。恢复实验后先冷态核验再按默认关闭/武装顺序运行。


**历史29×29候选失败（不是当前32×32候选状态）：** H12小块软件捕获后续：6/6暂存通过，但隔离partition输出文件报错、Load进程signal11；无设备ioctl/分配、无START，无真实小块packet。失败归档已取回，根因待定位，不能记厂家支持或板证通过。

## H12目标构建与冷恢复边界（2026-09-28）

`implementation_hardnpu/h12_stem/`仅传到新私有/run/h12_stem_20260928_1，13/13 SHA匹配。用户严格编译通过；模块生成并加载，模块构建退出标记未取回；Module.symvers告警和精确内核身份缺口保留。模块SHA2cb3e51a8bef4e7eb18a7f9ac2cbb19f71ac3ddef42ec7ed516e57fa895d03f7。默认拒绝通过，但首次START超时固定，禁止据产物存在称BOARD成功。小块软件捕获脚本仅准备和语法通过，须新私有目录与对应模型SHA。原始失败归档已取回，物理恢复前保持固定状态。


## 2026-09-28 H10复用板证和H11CPU交接

恢复包结束标记观察超时后，直接核板端整包538502B同SHA，解包43/43校验通过；复用已归档目标产物完成16次H10 START/释放/卸载板证。H11模型/CPU程序仅暂存新私有/run，第二轮逐SHA核6文件，ORT CPU双帧浮点容差通过；未重新构建FPGA或原工程。恢复包脚本自动流程未完整成功，手动受控核验路径证据另记 `board_stage_recovered.txt`，不能称脚本端到端已验证。

## 2026-09-28 H10冷恢复复用目标产物

`prepare_h10_retry_bundle.py`锁定原取证归档与模块/用户程序SHA，并以stage清单加用户源码修订单独清单核所有43文件，生成恢复包后本地解包复验。`stage_h10_retry_bundle_20260928.ps1`要求冷恢复、旧/run目录消失、相关模块/设备节点无残留、6.1.111-rt42内核匹配，传输同SHA包后解包并逐文件校验；不自动加载或START。仅准备及语法检查通过，板端未执行。原源码/Image同一性UNKNOWN仍保留。

## 2026-09-28 H10目标构建（当前最新）

H10隔离软件工具及八片模型仅在工作树/板端私有易失目录生成；重建工具补齐线程链接库，哈希不同于旧工具并独立记录。H10诊断41文件逐SHA传输；用户程序输入长度修订单独暂存并保留清单历史，严格GCC及Kbuild成功。默认关闭及卸载通过，首次武装尝试在空闲检查被拒绝、无START。Module.symvers缺失及板端时钟差异仍限制源码/Image同一性。见 `docs/research/HARDNPU_H10_PRESTART_REFUSAL_20260928.md`。

## 2026-09-27 H9五片诊断目标构建（当前最新）

`implementation_hardnpu/h9_segment/`和冻结载荷仅在隔离工作树与板端易失私有 `/run/h9_segment_20260927_1` 使用，29文件逐SHA传输。板端严格GCC用户程序、现有6.1.111-rt42输出树Kbuild模块完成，默认关闭拒绝、10次START/释放、卸载通过。`Module.symvers`缺失、板端时钟偏差使当前Image与源码精确同一性仍 `UNKNOWN`。原工程、外部快照、known-good目录未用作构建目录。见 `docs/research/HARDNPU_H9_POINTWISE_BOARD_20260927.md`。

## 2026-09-27 H7六片诊断目标构建（当前最新）

`implementation_hardnpu/h7_multishard/`及冻结输入仅在隔离工作树与板端私有`/run/h7_multishard_20260927_1`使用，33文件逐SHA传输核验。板端GCC严格编译用户程序、当前`6.1.111-rt42`输出树Kbuild模块；默认关闭、12次START/释放及卸载均板证。`Module.symvers`缺失和板端时钟差异使源码/Image精确同一性仍`UNKNOWN`；没有在原工程、外部快照或known-good目录构建。见 `docs/research/HARDNPU_H7_SIX_SHARD_BOARD_20260927.md`。

## 2026-09-27 H5四段诊断目标构建（当前最新）

`implementation_hardnpu/h5_segment/`和20份冻结输入仅在隔离工作树与板端私有易失`/run/h5_segment_20260927_1`使用，传输逐SHA匹配。板端GCC严格编译用户程序并在当前`6.1.111-rt42`输出树Kbuild模块；默认关闭、四次START、释放及卸载均板证。构建树缺`Module.symvers`且板端时钟错误，源码/Image精确同一性仍`UNKNOWN`。没有在原工程、外部快照或known-good目录构建。详见 `docs/research/HARDNPU_H5_POINTWISE_BOARD_20260927.md`。

## 2026-09-27 H4六片共用模块目标构建（当前最新）

`implementation_hardnpu/h4_multishard/`及两帧六片冻结载荷仅在隔离工作树和当前板私有易失 `/run/h4_multishard_20260927_1` 使用；33份文件逐SHA传输核对。板端严格GCC编译用户程序SHA `9a751452790fe5c4b187750f6081a232036e0a19aa4824eedf47db5d485255c3`，目标模块SHA `1abb92aab8b240ea1e59efcb340d51363bbfdb88b71f138501f98b969c1307d5`。默认关闭拒绝、12次真实运行/释放、最终卸载均板证通过。构建树缺`Module.symvers`，源码/Image精确同一性为`UNKNOWN`。没有在原工程、外部快照或known-good目录构建。见 `docs/research/HARDNPU_H4_MULTISHARD_TWO_FRAME_BOARD_20260927.md`。

## 2026-09-27 H4同模块双帧诊断目标构建（当前最新）

`implementation_hardnpu/h4_reuse/`及冻结packet、权重、两帧输入/预期仅从隔离工作树传入板端私有 `/run/h4r_reuse_20260927_1`，13份文件逐SHA通过；板端GCC以 `-O2 -Wall -Wextra -Werror` 编译用户程序，现有SDK内核输出树目标构建模块。模块SHA `7c20b8bc399807663d496d06f281e9ea52cb0dfd7d8e976d986f59b21a66dbe4`，用户程序SHA `46c05fd6819dd3d88d326792a98a2bae5e66478dd7971fbb5263ef4b204f5e06`；默认关闭/双帧/卸载均实测。`Module.symvers`仍缺，不能证明当前Image与此源码树精确同一。没有在原工程、外部快照或known-good目录构建。见 `docs/research/HARDNPU_H4_REUSE_TWO_FRAME_BOARD_20260927.md`。

## 2026-09-27 H4变化输入分片目标构建（当前最新）

确定性平移和第二张真实帧的分片配置、输入与冻结packet/权重分别在隔离工作树生成，只传板端私有 `/run/h4r_shift1_20260927_*` 与 `/run/h4r_frame2_20260927_*`。六片各逐SHA核对，在板端既有目标内核输出树编译一次性诊断模块与严格GCC用户程序；默认关闭、武装单次运行、输出归档及释放均记录。`Module.symvers`缺失与时钟偏差仍使目标源码/Image精确同一性为 `UNKNOWN`。原工程、外部快照、known-good目录未用作构建目录。见 `docs/research/HARDNPU_H4_DYNAMIC_INPUT_BOARD_20260927.md`。

## 2026-09-27 H4 六片一次性诊断模块构建（当前最新）

六片分片配置、真实packet和冻结载荷仅从本隔离工作树经串口逐SHA传到当前板 `/run/h4r_once_20260927_1` 至 `_6` 的私有易失目录；模块只在板端现有目标内核输出树编译，用户程序以严格GCC选项编译。第0～5片各自冷启动验证及后一轮同上电连续链均使用独立分片配置，均先检查默认关闭，再武装一次运行，成功后卸载。板端构建的`Module.symvers`缺失、时钟偏差仍使目标源码与当前Image的精确同一性 `UNKNOWN`。原工程、外部快照及known-good目录未用作构建目录。见 `docs/research/HARDNPU_H4_160_SHARD_BOARD_20260927.md`。

## 2026-09-27 H4 第0包诊断目标构建（当前最新）

`_2/_3/_4` 三个隔离候选只在板端私有易失 `/run/h4_tile0_once_20260927_*` 中目标构建。最终 `_4` 模块 SHA-256 `e80d07ba3be0ea828e5d34fd4c2574746c42dc7a372c9559f287415ac2b38179`，用户运行程序 SHA `558999efcb3875606bc617e252cd9cf7e48b0c185f0d68979f578fc1e2dddff8`，构建日志 SHA `d5675406f1079b9d35b5f5956a3a09a8060f4b2873bc50af949e912d5053eef9`。默认关闭装载/拒绝/卸载通过；武装真实运行超时并按设计固定资源，后由物理冷恢复。目标内核源码与当前Image精确同一性仍 `UNKNOWN`，`Module.symvers`缺失与时钟偏差保留。没有在原工程、外部快照或known-good目录构建。见 `docs/research/HARDNPU_H4_TILE0_TIMEOUT_BOARD_20260927.md`。

## 2026-09-27 H4 冻结载荷无启动模块构建（当前最新）

最终 H4 载荷诊断源码和五份冻结数据经 COM4 逐 SHA 传至板端新易失 `/run/h4_payload_stage_20260927_2`，只在该目录使用已有目标内核输出树构建。最终模块 SHA `4328415c07e3130856f6469f076ab8bc42a751102e8376f6af9304ae67da608f`，vermagic `6.1.111-rt42 SMP preempt mod_unload aarch64`；构建日志 SHA `9ddb092d92080378b06f513ef27a6625680ec62f01bda046b0da9425d19aec0b`。正向装卸、反向载荷拒绝和恢复后装卸均在板端实测；`Module.symvers`缺失、modpost未解析符号及板端时钟偏差仍在，精确内核源码同一性 `UNKNOWN`。此构建无真实NPU START。见 `docs/research/HARDNPU_H4_PAYLOAD_STAGE_BOARD_20260927.md`。

## 2026-09-27 H4 无启动诊断模块目标构建（当前最新）

H4 四缓冲诊断模块四项源码/Makefile 通过 COM4 逐 SHA 传至当前板此前不存在的易失 `/run/h4_alloc_only_20260927_1`，仅在该目录使用已有 SDK 6.1 目标内核输出树构建。模块 SHA-256 `1231a869618e140c284872e8e58cb13bce72839e22d975ccba462d65cee18046`，vermagic `6.1.111-rt42 SMP preempt mod_unload aarch64`，实际装卸通过。构建日志 SHA-256 `8a29a8b5205375d9ebacd58a2e87e6530c2fdcbd78646c595b2be0e66dcb9056`；`Module.symvers`缺失、modpost未解析符号和板端时钟偏差仍存在，不能据此断言当前 Image 与源码树精确同一。源码无 MMIO/IRQ/START，板证仅为分配与CPU侧地址检查。见 `docs/research/HARDNPU_H4_ALLOC_ONLY_BOARD_20260927.md`。

## 2026-09-27 H4 软件packet隔离目标构建（当前最新）

H4单层模型/CPU夹具只在当前隔离工作树生成。板端只在易失私有`/run/h4_virtual_partition_20260927_1`暂存逐SHA核对的模型/源码；复用H3相同源码且哈希相同的目标监督器和分区探针，只重编H4启动器，随后新增LoadNetwork探针和三段packet捕获监督器。捕获监督器目标SHA`96788f13889d3e42cf34399d08ddd039cfd730c417a817e43c489d43cee0f547`；隔离Load/Unload通过，真实设备/内核模块/START均未使用。原工程、外部快照和known-good产物不是构建目录。见`docs/research/HARDNPU_H4_LARGE_CONV_VENDOR_PACKET_20260927.md`。


## 2026-09-27 H3 depthwise 软件分区目标构建（历史阶段）

H3 CPU夹具只在隔离工作树生成并封存；板端仅在易失私有 `/run/h3_virtual_partition_20260927_1` 目标编译厂家软件探针，不构建内核模块。模型和3份源码逐SHA传输；监督器/启动器/探针目标产物SHA依次 `88ed84366ae400e02f24e9094e712a9ad28ea62b7785d58c4e16acba75f03972`、`4f41852c4802642a8d8c81f46269263853d94cf20ae1704b102e8f2687413973`、`10515aeb003ad28e6f0f6bf71f6a7177057048cef14b729a65f567fffe1e83c1`。冻结厂家库在隔离设备环境中只运行 parser/Optimize；因Alnpu不支持此depthwise而退出，没有内核模块/START。原工程、只读快照、known-good产物不是构建目录。见 `docs/research/HARDNPU_H3_DEPTHWISE_CPU_AND_VENDOR_BOUNDARY_20260927.md`。


## 2026-09-27 H2 一次性真实运行候选目标构建（历史阶段）

独立 `implementation_hardnpu/h2_one_shot.c` 只传当前板易失私有 `/run/h2_one_shot_20260927_3`，在板端目标内核输出树编译；运行模块 SHA-256 `a333e498e3f9ec65b99645265e5ecf03acab965460a1775d3fb254e1aefddda6`。本次显式单次 START 与输出核对、成功释放和卸载通过，详见 `docs/research/HARDNPU_H2_FIRST_START_BOARD_20260927.md`。构建日志已取回；`Module.symvers` 缺失、时钟偏差及构建树与当前 Image 精确同一性 `UNKNOWN`，不得从装载成功推出可复现量产构建。原工程、只读快照和 known-good 产物未作为构建目录。

## 2026-09-27 H2 固定载荷无 START 模块目标构建（历史阶段）

新私有板端目录 `/run/h2_payload_stage_20260927_2` 收到7个明确文件（5个源码/构建文件及冻结输入/权重），逐 SHA 与隔离工作树一致。目标内核 `6.1.111-rt42` 构建最终 `h2_stage_only.ko` SHA `7ae97416d71d4d1dd0ed8f3139c602c10ad4843ec7c6b34fa786a393f50d2912`；正向装卸通过，受控篡改权重时装载失败且无模块残留。第一次候选曾出现 probe 错误但 `module_platform_driver` 返回装载成功，已修正并废弃。最终构建日志 SHA `ffb841120de822ccddb2a83ee6f51bc8cd5fb5b6d2a1e9e1b737f150009a87dd`，仍含 `Module.symvers` 缺失/符号和时钟偏差告警，SDK/Image 精确同一性 `UNKNOWN`。没有原工程或外部快照构建，也没有 NPU START。见 `docs/research/HARDNPU_H2_PAYLOAD_STAGE_BOARD_20260927.md`。

## 2026-09-27 H2 无 START 分配模块目标构建

只将5个明确源码文件传到当前板新私有 `/run/h2_alloc_only_20260927_1`，逐 SHA 核对后，以板端独立 SDK `linux` 构建树为目标编译 `h2_alloc_only.ko`。模块 SHA `8de28a80f9cd136b6426132b7e90ee3985ede7e67499a3b92e8e92f7e525d0ee`，vermagic `6.1.111-rt42 SMP preempt mod_unload aarch64`，装卸均返回0。构建日志记录缺 `Module.symvers`、未解析符号告警和板端时钟偏差；因此精确源码/Image 同一性仍 `UNKNOWN`。构建目录不是原工程、外部快照或 known-good 产物目录；本次模块仅分配与释放 DMA，没有 MMIO/IRQ/START。原始构建日志见 `docs/records/hardnpu_h2/2026-09-27-alloc-only-board/build.log`，完整说明见 H2 无 START 板测报告。

## 2026-09-27 H2 四缓冲合同主机构建

只在当前隔离工作树新 `tmp/h2_contract_20260927_1/` 用 MinGW GCC 严格编译 `h2_dma_contract.c`、`h2_packet_fixture.c`、`test_h2_dma_contract.c` 并运行主机 mock 回调，8笔写序/8个故障截点/8种非法计划通过。它不加载内核模块或触发板端 START；H2 内核激活代码固定拒绝。原工程、外部快照和 V2 known-good 二进制未作为构建目录。见 `docs/research/HARDNPU_H2_HOST_DMA_CONTRACT_20260927.md`。


## 2026-09-27 H2 模拟设备软件探针构建边界

H2 源模型与探针源码经串口逐项哈希核对，只在当前板新易失私有目录 `/run/h2_virtual_cma_20260927_1` 目标编译监督器、pre-exec 包装器及 Arm NN 探针。使用板端现有已哈希核对的 Arm NN/parser/protobuf 运行库和头文件，**未构建内核模块、未使用真实 NPU 节点、未调用 Execute/START**。C 严格 GCC、C++ 严格 G++ 构建的最终二进制哈希见 `docs/records/hardnpu_h2/2026-09-27-virtual-probe/h2_manifest.txt` 与 `h2_packet_manifest.txt`。首次 C++ 链接缺 protobuf 依赖、首次运行缺动态库搜索路径，修正后才得到通过结果；失败未计为通过。原工程和外部快照未运行构建，结果仅为设备隔离软件证据。详见 `docs/research/HARDNPU_H2_VIRTUAL_PACKET_20260927.md`。


## 2026-09-26 H1 双帧诊断运行脚本

纯shell脚本SHA=`74db6ba413b583e9cec0e84c19109db2ae33755a36cf040aaff18971a4465648`经串口传板端新易失私有`/run/h1_dynamic_runner_transfer_20260926_1`，哈希和语法核对后执行；使用此前已在板端私有目录严格编译并实跑的CPU oracle、最终H1模块和用户验证程序，不重新构建。结果仅写新私有`/run/h1_dynamic_frames_20260926_1`，双帧通过并卸载，模块0。原工程、快照、U盘未构建或运行。见双帧报告。

## 2026-09-26 H1 十次作业脚本边界

已构建/实跑的最终模块SHA=`977ed055518a567a88a5e13ea2af57b6e90589323f609c89433fc2c58d57c4dd`，用户程序SHA=`9407c2cd2501506dd69922d810c473744b30e9420d19f566fadb1b54acb26d3a`；本轮未重新构建二者。只将受限十次脚本SHA=`5e350babe5886b3b6025d3ae00aa87febee29a69d914c56af8d19dcf8a6c07c3`传板端新私有`/run/h1_stress_transfer_20260926_1`，SHA和shell语法核对后执行；十次成功作业结果只在新私有`/run/h1_custom_stress_20260926_1`，最终模块0。原工程、外部快照、U盘均未构建或运行。见十次作业报告。

## 2026-09-26 H1 板端CPU定点预期程序构建

新纯CPU源码 `implementation_hardnpu/h1_fixed_oracle_runtime.c` SHA-256=`d325158a0453249d062c5e1eb2497c96e2ce7e0bc96b33d5d981df8577da1950`，与已冻结 `h1_packet_fixture.c` 和头文件只传板端新易失私有`/run/h1_oracle_runtime_20260926_1`，严格GCC 9.3.0 `-std=c11 -O2 -Wall -Wextra -Werror` 编译rc0，ELF SHA=`7470c78a414bed370a18a2fd644201612053a6d25d3a272f3217aa4881434eb5`。仅CPU计算两份新输入，与既有主机预期均0差；又用其中一份结果在最终驱动上完成一次真实START/释放。无原工程、快照或U盘构建。见自定义输入报告。

## 2026-09-26 H1 自定义输入候选目标构建

自定义预期绑定首版源码SHA-256=`2cb20f0a1528feddaa5786ff68e8b20c2c24bce6b22e721ae11812ba040e6a17`，仅在板端新私有`/run/h1_linux_custom_oracle_20260926_1`目标构建，`.ko` SHA=`18ba0d14c19310722361b16e61b77668cde32a28729501a1b77e3391e36b7e2a`；严格用户态编译程序SHA=`9407c2cd2501506dd69922d810c473744b30e9420d19f566fadb1b54acb26d3a`。同实例XOR55→XORAA完成、释放和卸载通过。最终收紧源码SHA=`2ef81835a3879587579831bc2e1ffa417f922ecc5af4f7c60814ee172375bb69`，板端新私有`/run/h1_linux_oracle_guard_20260926_1`目标模块SHA=`977ed055518a567a88a5e13ea2af57b6e90589323f609c89433fc2c58d57c4dd`，XORAA正向运行、释放、卸载通过。所有输入在主机预先生成并按SHA传至板端；没有在原工程/外部快照/U盘构建。`Module.symvers`缺失、modpost未解析符号、目标时钟偏差及当前Image精确源码身份`UNKNOWN`继续适用。见自定义输入报告。

## 2026-09-26 H1 Linux 两种输入同实例板端构建与执行

最终H1驱动源码SHA-256=`d70bec3d90c1e64c36623052f6a68f6616e74ec2fb87644cf8ca6552126760ea`，只传板端新易失私有`/run/h1_linux_mixed_20260926_1`目标构建，`.ko` SHA-256=`1cc037dd3ceb8a6d79318d64c4d3391fd401b26ea7f8ad7535c25305cbc6c01e`；严格目标编译用户程序SHA-256=`ab933708590fd70b0c243f950d07ccd0467bbcbf47d3c8a8150094734be7fcca`。源/板哈希一致，运行内核与vermagic同为`6.1.111-rt42`；实际装载、两次START、两次成功释放及卸载通过。构建仍缺`Module.symvers`，有modpost未解析符号与时钟偏差，历史输出树与当前Image精确同源仍`UNKNOWN`。原工程、外部快照、U盘均未用于构建；详情见混合作业报告。此前原输入同实例两次作业的模块哈希和限制见重复运行报告。

## 2026-09-26 H1 双层验收程序目标构建

仅在板端新易失 `/run/h1_dual_oracle_verify_20260926_1` 以 GCC 9.3.0 所在环境严格编译用户态 `h1_first_run_verify.c`，退出0，ELF SHA-256=`d073d250c007462ac03b04e62c0db538be1e5db21022ecbae2f7c6718f5af458`。主机 MinGW 缺 Linux `sys/ioctl.h`，未获得主机编译结论；板端没有构建/加载内核模块或执行设备命令。输入与旧证据均按 SHA 核对，只在私有 `/run` 写编译及坏字节对照副本。见 `docs/research/HARDNPU_H1_LINUX_DUAL_ORACLE_VERIFIER_20260926.md`。

## 2026-09-26 H1 Linux 激活候选目标构建

仅板端新易失 `/run/h1_linux_activation_candidate_20260926_1`构建修正源码，源/板10文件逐SHA一致。目标构建rc0，`.ko` SHA-256=`2d4e5bdf24544ff388226c2babc22d574634bbc0e61b263a54fd80e27fb0548a`，vermagic匹配6.1.111-rt42；但Module.symvers缺失、modpost未解析符号及时钟偏差，不能宣称可装载或ABI同一。反汇编已回传核查；没有装载或运行。见 `docs/research/HARDNPU_H1_LINUX_ACTIVATION_ALIGNMENT_20260926.md`。

## 2026-09-26 H1 独立定点预期生成

只在隔离工作树执行 `tools/npu/build_h1_packet_fixed_oracle_20260926.ps1`，冻结输入/权重/bias/packet哈希门禁通过，生成12544B新预期SHA-256=`d508fcd898b10c7b4dac298213ee863747053ae0fb8027b2380b2e5d83196322`，与板端原始输出0差、与原CPU金样6267点差1。未目标编译、未加载内核模块或运行板卡。见 `docs/research/HARDNPU_H1_PACKET_FIXED_ORACLE_20260926.md`。

## 2026-09-26 H1 首次单次 START 实际产物

使用隔离工作树已目标构建的武装BIN，未重新编译或更改源码。板端临时文件及U盘新`H1ARM1.BIN`均6248B、SHA-256=`18e05b355d5b5534cc141d5db0f65d96730dacb01de2a9b0fbc32da44b08d769`；U-Boot `fatload`后三段内存CRC与冻结文件匹配。仅一次`go`/START，输出原始文件及量化审计见 `docs/research/HARDNPU_H1_FIRST_START_BOARD_20260926.md`。结果为定点packet全长吻合、原CPU金样未通过；用户物理断电上电后已复核Linux恢复。

## 2026-09-26 H1 抓取全长模拟与产物复核

在PC用冻结金样模拟全部784行`md.b`输出，按抓取脚本相同逻辑还原后SHA一致；地址断裂、末行截断均触发拒绝。最终H1源码SHA-256=`b1dfd5e0afb0dec80fe00532a8ebbc06898048e071ccf426f861a25f3f6459c3`，本地武装BIN6248B SHA-256=`18e05b355d5b5534cc141d5db0f65d96730dacb01de2a9b0fbc32da44b08d769`，未重新构建、未运行。

## 2026-09-26 H1 手册边界复核

本轮仅复核本地 UG1215 HardNPU、CRP、XMON 寄存器定义并更新接口/状态记录；未重新构建、未放武装 BIN 到 U 盘、未执行 START。`work=5`/完成 IRQ 是作业完成依据，异常后 AXI 排空仍 `UNKNOWN`。见 `docs/research/HARDNPU_H1_AXIDRAIN_EVIDENCE_AUDIT_20260926.md`。

## 2026-09-26 H1 武装产物只读审计

未重新构建或运行武装BIN；本轮再次核对隔离副本6248B SHA-256=`18e05b355d5b5534cc141d5db0f65d96730dacb01de2a9b0fbc32da44b08d769`，板端重启前对当次目标ELF只读反汇编，确认写索引、偏移/值双表、最终START前读IRQ/work及`str`指令。提取最终源码中的完整report结构，在PC隔离输出目录做仅用于偏移核对的严格C编译，得到status4、final_irq156、final_work160、map_stage196、结构256B。只读抓取脚本语法解析0错，尚未用于真实NPU输出。详见 `docs/research/HARDNPU_H1_ARMED_STATIC_AND_OUTPUT_CAPTURE_20260926.md`。

## 2026-09-26 H1 四页映射和整合首算候选

四页映射探针在板端新私有`/run/h1_uboot_npu_map_four_20260926_1`目标构建，1136B BIN SHA-256=`4d88d2586db5ee010e2dbe42989be4765c1ec7f7cecb5debd573c8667d129037`；U盘新`H1MF1.BIN`回读同哈希、U-Boot `go`状态0。整合源码最终 SHA-256=`b1dfd5e0afb0dec80fe00532a8ebbc06898048e071ccf426f861a25f3f6459c3`，板端新私有`/run/h1_uboot_first_run_mapped_20260926_7`六输入逐哈希一致。最终无START模式BIN与已板测`H1MA2.BIN`字节相同，SHA-256=`d85a96c73d24451fd277ee1fbb5e4b5f6d022334db70f3647b4011c26818a2b0`。武装模式6248B BIN SHA-256=`18e05b355d5b5534cc141d5db0f65d96730dacb01de2a9b0fbc32da44b08d769`，目标构建并经串口取回隔离工作树`experiments/h1_uboot_first_run_mapped_20260926/out/`，未放入U盘或运行；反汇编操作数无x18/w18。详见 `docs/research/HARDNPU_H1_FOUR_PAGE_MAPPED_PREFLIGHT_20260926.md`。

## 2026-09-26 H1 U-Boot NPU 控制面无启动构建

`experiments/h1_uboot_npu_reg_ro_20260926/` 与 `experiments/h1_uboot_npu_reset_only_20260926/` 各自在板端新私有`/run`目录用三份逐哈希一致输入目标构建，BIN SHA-256分别为`b6a03bb8641bfdd3cdb0686fdaad9482fcf1872b122d317f4cfc5f33a150ea3b`与`cae3b444d3594ebf9293abbae76c578b56066b319d19b1794452a15e85f9f62b`；反汇编操作数无x18/w18。U盘仅新增`H1RR1.BIN`/`H1RS1.BIN`且回读一致，U-Boot两次`go`均返回0。无START。见 `docs/research/HARDNPU_H1_UBOOT_MMIO_READ_RESET_BOARD_20260926.md`。

## 2026-09-26 H1 U-Boot NPU MMIO 翻译探针

`experiments/h1_uboot_npu_translation_20260926/` 在板端独立 `/run/h1_uboot_npu_translation_20260926_1` 构建；三项输入 SHA 一致，256B BIN SHA-256=`8c349f857c8ebbaa1ac6da86cb3752ab31936c78a64f807fa5f88d7635ccd85d`，反汇编无 `x18/w18`。U 盘新增 `H1NT1.BIN` 并回读同哈希。探针只执行 EL3 地址翻译指令，无目标 MMIO 读写或 START；详见 `docs/research/HARDNPU_H1_UBOOT_NPU_MMIO_TRANSLATION_20260926.md`。首算激活专用程序的构建不构成运行许可，武装 BIN 未进入 U 盘。

同轮 `experiments/h1_uboot_npu_table_ro_20260926/` 120B 只读寄存器探针 BIN SHA-256=`d605991d1176ad558e70c5f55535c193ef2704cca3185f8ce8cbbe8632e683fd`；`experiments/h1_uboot_npu_map_roundtrip_20260926/` 872B临时页表往返程序 BIN SHA-256=`2056e717e45f2e9008b8d95fd880705bc6f8ba5b37b624056971e45ce503262c`。均仅在各自板端新`/run`私有目录构建、三输入逐哈希一致，U盘分别新增`H1TR1.BIN`/`H1MR1.BIN`并回读同哈希；`go`均返回0。往返程序仅改变临时EL3页表并恢复，不读写NPU MMIO，不执行START。详见同一研究文档。

## 2026-09-26 H1 U-Boot 缓存无启动程序目标构建

新隔离 `experiments/h1_uboot_cache_nostart_20260926/` 主源码及冻结合同等六项输入只传板端易失 `/run/h1_uboot_cache_nostart_20260926_1`，逐哈希一致；严格freestanding目标构建返回0，ELF反汇编无x18/w18，3024字节BIN SHA-256=`330dbcd7c0e928bd5d44f733c2478e249b3ebca7ee74204c50e8718068b5a4a4`。仅写U盘新文件`H1CNS1.BIN`、回读同SHA；U-Boot加载/运行无START程序并正常回Linux。未在原工程或外部快照构建，未执行HardNPU START。见 `docs/research/HARDNPU_H1_UBOOT_CACHE_NOSTART_BOARD_20260926.md`。

## 2026-09-26 DDRS1 源页对照目标构建

隔离 `experiments/h1_axi_dma_ddrs1_group_bit5_rw0_read_20260926/` 两项输入只传板端易失私有 `/run/h1_pl330_ddrs1_group_bit5_rw0_read_20260926_1`，逐哈希一致；沿用私有历史内核输出树目标构建返回0、vermagic匹配，模块SHA-256=`9db225fe8e31faea1ef4b4f5130d283259e37f06dbb4a18ab03ac3ffbc4fdb4f`。默认无提交装卸载通过，显式一次PL330故障并经DDR S1回滚、软件重启恢复。历史输出树与当前Image精确同源仍 `UNKNOWN`；未在原工程/外部快照/U盘构建，未执行HardNPU START。详见 `docs/research/HARDNPU_H1_DDRS1_RW0_SOURCE_READ_AND_POLICY_REJECTION_20260926.md`。

## 2026-09-26 DDRS1 RW=0 组选择性板端目标构建

`experiments/h1_axi_dma_ddrs1_group_bit3_rw0_20260926/` 两项输入只送当前板易失私有 `/run/h1_pl330_ddrs1_group_bit3_rw0_20260926_1`，逐哈希一致；板端既有私有历史内核输出树目标构建返回0，模块 SHA-256=`6d1794fa43308a617e6817e720170bca1f537e56c7cfd4dcf3adabb0f6ee58ee`，vermagic匹配，默认关闭装载/卸载和显式单次 PL330 对照通过，卸载后模块0。前一 `GROUPID=0` 和 `0x20` 变体亦在同类私有目录目标构建；见研究记录。历史输出树与当前Image精确同源仍 `UNKNOWN`，不作为发布模块。未在原工程、外部快照或U盘构建，未执行HardNPU START。

## 2026-09-26 DDRS1 区域命中与属性四组合构建

四个新隔离变体分别位于 `experiments/h1_axi_dma_ddrs1_empty_20260926/`、`experiments/h1_axi_dma_ddrs1_unmatched_guard_20260926/`、`experiments/h1_axi_dma_ddrs1_secure_priv1_20260926/`、`experiments/h1_axi_dma_ddrs1_priv1_20260926/`；每个均传到板端新的 `/run` 私有目录并核对两输入哈希，沿用板端既有私有输出树目标构建，vermagic匹配、默认无提交加载/卸载通过。两个对照复制成功；后两种命中目的页属性配置故障并按计划回滚/重启。构建时钟偏差、`Module.symvers`缺失及与当前Image精确同源仍 `UNKNOWN`。未在原工程、外部快照或U盘构建，也未执行HardNPU START。见 `docs/research/HARDNPU_H1_DDRS1_REGION_HIT_MATRIX_BOARD_20260926.md`。

## 2026-09-26 XMON GroupID 限定探针目标构建

新隔离 `experiments/h1_axi_dma_xmon_gid_20260926/` 两输入经串口传至板端易失私有 `/run/h1_pl330_xmon_gid_20260926_1`，双哈希相同；使用板端既有私有内核输出树目标构建模块 SHA-256=`db7266702b069c040c0d037bfba6723bda048672d720c5fba00e363b3b140b49`、vermagic匹配。默认无提交装载/卸载及显式 XMON/PL330 限定实验完成；历史输出树时钟偏差、与当前 Image 精确 ABI 同一性仍 `UNKNOWN`。未在原工程、外部快照或 U盘构建，未执行 HardNPU START。详见 `docs/research/HARDNPU_H1_XMON_PL330_GROUP5_BOARD_20260926.md`。

## 2026-09-26 DDRS1 SECURE 单变量目标构建

新隔离 `experiments/h1_axi_dma_ddrs1_secure1_20260926/` 只将区7 RASR从`0x001`改为`0x041`及名称/日志，传板端新易失 `/run/h1_pl330_ddrs1_secure1_20260926_1`；两输入逐哈希相同。既有板端私有历史输出树编译模块 SHA-256=`1c06979aeed3d8de6fbede76cb0973f1652bb9e84cef9aa2e2d06ab9a538ca74`、vermagic匹配，默认关闭装载/卸载返回0。显式一次 PL330 故障并恢复，非 HardNPU START。历史树精确 Image ABI 未证，未在原工程/外部快照/U盘构建。见 `docs/research/HARDNPU_H1_DDRS1_SECURE1_XMON_BOARD_20260926.md`。

## 2026-09-26 DDRS1 全组位/RW开放对照目标构建

新源码仅放工作树隔离 `experiments/h1_axi_dma_ddrs1_group_all_allow_20260926/`，两项源码/Makefile经串口传至板端易失新私有 `/run/h1_pl330_ddrs1_group_all_allow_20260926_1` 且逐哈希一致；沿用板端历史私有 `/root/dr1_npu_module_build_20260914_r2` 输出树目标构建，模块 SHA-256=`be5df477632ff64a72ebbbfc13587328dd0725ef11a4daab71d4f3bec5b86c53`，vermagic匹配。默认无提交加载/卸载通过；显式一次 PL330 实验故障并按固定缓冲、DDRS1恢复、软件重启回收。构建有 `auto.conf` 时间偏差，历史输出树与当前 Image 精确 ABI 仍未证明；构建成功不能当作 NPU 可运行。未在原工程、外部快照或 U盘构建，未执行 HardNPU START。详见 `docs/research/HARDNPU_H1_DDRS1_ALL_GROUP_RW_OPEN_BOARD_20260926.md`。

## 2026-09-26 H1 迟到 IRQ 状态机目标构建

仅在工作树新 `experiments/h1_late_irq_20260926_1` 输出主机测试，在板端新 `/run/h1_late_irq_20260926_1` 放置哈希一致的11项输入并构建。主机和板端状态测试均退出0；目标Kbuild模块 SHA-256=`4c4dd33e5c8347bc0a329ecfcc27e39fcf007ad7b0d892ed67fd458f8191c919`、vermagic=`6.1.111-rt42 SMP preempt mod_unload aarch64`，默认装载/卸载成功。候选内核输出树仍有时钟偏差及精确 Image 同源缺口；构建不代表真实 IRQ/START 或系统运行通过。详见 `docs/research/HARDNPU_H1_LATE_IRQ_DIAGNOSTIC_20260926.md`。

## 2026-09-26 DDRS1 GROUPID=0 对照目标构建

源码只在工作树新 `experiments/h1_axi_dma_ddrs1_group0_20260926/` 编写，通过串口传到板端新 `/run/h1_pl330_ddrs1_group0_20260926_1` 并双文件哈希核对，未在原工程、U盘或外部快照构建。该板端私有目录使用既有 `/root/dr1_npu_module_build_20260914_r2/source` 与 `output/kernel` 目标编译；`ARCH=arm64`、目标内核 `6.1.111-rt42`、vermagic匹配，模块 SHA-256=`c391e8af2e07cc2da06ec155f08055b25fd4ebbcc554b34cf52462c10bca3057`。输出树时钟偏差告警及与当前 Image 精确源码身份缺口仍在。默认关闭和一次显式对照见 `docs/research/HARDNPU_H1_DDRS1_GROUP0_COUNTEREXAMPLE_20260926.md`；构建成功不等于 HardNPU 可运行。

## 2026-09-26 U-Boot 临时程序编译约束

`experiments/h1_uboot_preflight_20260926/Makefile` 的 freestanding C 规则加入 `-ffixed-x18`；当前 BOOT.bin 的 U-Boot 通过 x18 读取全局数据，旧程序改写 w18 与无提交同步异常相符。每个未来 U-Boot 临时对象还需静态反汇编确认不使用 x18/w18。DDRS1 group0x8 写入变体在板端停机、由用户断电恢复；该 Makefile 已移除写入目标，源码遇到 `H1_GROUP8_ALLOW_WRITE` 编译失败。此封禁不影响已有无写入预检的只读证据。详见 `docs/research/HARDNPU_H1_UBOOT_X18_AND_GROUP8_HANG_20260926.md`。

## 2026-09-26 U-Boot PL330 缓存见证目标构建

最终 `experiments/h1_uboot_preflight_20260926/h1_dma_witness.c` SHA-256=`ffb9d7e37e6e1ba45da930f412b0fe809b94538cc24ad6e3d258019b6a54db67`；仅在板端易失新私有 `/run/h1_uboot_dma_witness_20260926_4` 严格目标构建，三份输入哈希一致。`-DH1_WITNESS_ALLOW_SUBMIT=1` 提交版 BIN 1844字节 SHA-256=`69ad1b19932825b6e73dbcf7f076ec017214fb998e357a0ce4d04ecd72689944`，U盘新文件 `H1DMS3.BIN` 回读一致；U-Boot 单次64B PL330见证通过并恢复 Linux。非提交版与提交版分离，前者返回报告状态7/函数0。早期非提交候选曾因 `go rc7` 后 U-Boot 同步异常自动重启；不能将该路径写为通过或当成稳定恢复机制。原工程/外部快照/U盘未构建，未执行 HardNPU START。详见 `docs/research/HARDNPU_H1_UBOOT_PL330_CACHE_WITNESS_20260926.md`。

## 2026-09-26 H1 U-Boot 无启动验收产物

`experiments/h1_uboot_preflight_20260926/h1_nostart.c` 最终 SHA-256=`5debf415598759278d7d9262d7304ef2a044cd7bdbbb2f19d5f6eed2ad4aae53`；与 linker/Makefile 及冻结合同共六项输入只传板端易失新私有 `/run/h1_uboot_nostart_20260926_2`，哈希6/6一致。目标严格 GCC、ld、objcopy 生成2440字节 BIN SHA-256=`445e1592bcc98948bd51e98bc026129a79e3f927856917496fd41a532c796720`，新U盘文件 `H1NST2.BIN` 回读相同。U-Boot 加载与 CPU-only 无 START 测试返回0，正常恢复 Linux。未在原工程、外部快照或U盘构建；不能将其当成设备计算或发布镜像。详见 `docs/research/HARDNPU_H1_UBOOT_NOSTART_STAGE_20260926.md`。

## 2026-09-26 U-Boot 预检载荷隔离构建

`experiments/h1_uboot_preflight_20260926/h1_preflight.S` 最终 SHA-256=`b346baed548d6bd6ed81b996c44e47872c6239688b7f2f009678a0303f207bc9`；仅传入板端易失 `/run/h1_uboot_preflight_20260926_2` 私有目录，哈希一致后以板端 GCC/ld/objcopy 构建，BIN 168字节、SHA-256=`622ea292bd23957c9738624015af20e8ab9caaa3d7cb4976768abdcaef79ea65`。复制到 U 盘新文件 `H1PRE2.BIN`、回读同哈希；U-Boot FAT 加载并执行只读预检后正常返回 Linux。未在原工程/外部快照/U盘构建，未覆盖旧文件或执行 NPU START。U-Boot 可运行性不等于 HardNPU 算子构建/板测。见 `docs/research/HARDNPU_H1_UBOOT_EL3_PREFLIGHT_20260926.md`。

## 2026-09-26 H1 组路由固定拒绝版目标构建

隔离源 `implementation_hardnpu/h1_alloc_probe.c` SHA-256=`4033b5a49a8175802eba82387c9db92974ef4f105b922f1cc17089b7f746c3f4`，14项输入仅传板端新私有 `/run/h1_ddrs1_route_gate_20260926_1`，逐哈希一致。历史 `_r2` 输出树 Kbuild退出0，模块 SHA-256=`39b2fd2b3c92ad8a0fae836d33547ae2885d994944eccea9074845e74114f055`；默认装载、三项无启动用户程序与卸载通过，模块数0。缺 Module.symvers、modpost未解析符号和时钟告警仍在；当前内核精确 ABI 未证。未在原工程/外部快照/U盘构建，未执行 NPU START。详见 `docs/research/HARDNPU_H1_DDRS1_GROUP_ROUTE_FAIL_CLOSED_20260926.md`。

## 2026-09-26 DDRS1 group0x1 对照模块构建

工作树隔离源码 `experiments/h1_axi_dma_ddrs1_group1_20260926/h1_pl330_ddrs1_group1.c` SHA-256=`05928f32f08e51ed1374dfca3f521c0bee8151483b870f6e17d02591ef3dcafd`；仅传板端私有 `/run/h1_pl330_ddrs1_group1_20260926_1`，目标模块 SHA-256=`8841e899a2025f2e772ff62d952f88ac8740f48beafb5040e13d635b32af043f`。首次选错历史输出目录缺 `auto.conf`，返回2；用已准备的 `_r2` 输出构建、默认关闭装载/卸载、显式对照及故障重启回收通过。历史输出仍非当前运行内核精确 ABI 权威，原工程/快照未参与构建。详见 `docs/research/HARDNPU_H1_DDRS1_GROUP1_COUNTEREXAMPLE_20260926.md`。

## 2026-09-26 DDRS1 group0x8 对照模块构建

隔离源 `experiments/h1_axi_dma_ddrs1_group8_20260926/h1_pl330_ddrs1_group8.c` SHA-256=`54f76fbb576eeb6c50c14186d30ff75a9cc5a562d1a4c4bc746b82df54b1fd72`，仅送至板端 `/run/h1_pl330_ddrs1_group8_20260926_1` 私有目录构建，模块 SHA-256=`49038f55dfc3920b572e1ec4e2b95d3f06bff0fa2cf6e1f1a45c7f5e62b396f7`。默认关闭装载/卸载通过；显式对照产生 PL330 故障，恢复 DDRS1 后正常软件重启回收。历史私有输出树仍非当前精确内核 ABI 的权威构建，不作为发布产物。原工程和外部快照未参与构建；见 `docs/research/HARDNPU_H1_DDRS1_GROUP8_COUNTEREXAMPLE_20260926.md`。

## 2026-09-26 DDRS1 DMA_AXI 允许/拒绝试验构建

只在板端 `/run/h1_pl330_ddrs1_allow_20260926_1` 与 `/run/h1_pl330_ddrs1_deny_20260926_1` 私有目录用旧历史源码/输出树构建，源哈希分别为`3d30fec12203c3a2e7e1ea8fd0c09602efd280dde18c07d3b8963fa15a3c64c7`、`d0c25ed289671ee91d79b35e29bfd0096ee46a847870fc439e5e8797dacac546`，模块 SHA-256分别为`168d91f1fd539f111d209bfd5ceea077ff8a2d982c0e24c42e204ce4fbae2d61`、`3eafe0fb1573cd9079b5cbc6c52b6a865a2a9b901bd0e73bcde4bcc2fa374e3d`。两版默认关闭装载/卸载通过，显式允许复制成功、显式拒绝产生受控通道故障并经正常软件重启回收。缺 `Module.symvers`、modpost未解析符号与时钟告警仍在；不当作发布构建或精确内核 ABI。原工程/外部快照未参与构建。见 `docs/research/HARDNPU_H1_DDRS1_DMA_AXI_ALLOW_DENY_BOARD_20260926.md`。

## 2026-09-26 PL330 64B 复制候选目标构建与板测

当前工作树 `experiments/h1_axi_dma_copy_20260926/h1_pl330_copy.c` 对应板端私有 `/run/h1_pl330_copy_20260926_3` 源 SHA-256=`ca381c76c298c099e8a1a04a2d3ed551965c57dba960569d0b9684f2d919d44b`，模块 SHA-256=`ac7cd8467c690f70ba1dc13a2571df225aadbd32acde06b077d63c35d1e0eb37`；默认禁止、显式一次普通 DDR 64B复制、独立数据复核及卸载均通过。纯微码新版在 `/run/h1_dma_microcode_20260926_2` 严格目标 GCC 测试 `bytes=26/go_ns=1/negatives=9` 通过，二进制 SHA-256=`a1ae59999b83b6e4845e22fa08b13753426ac4f5dc2c86feb67c077a03a1fe0d`。首次旧模块假故障保留经正常软件重启回收；最终模块数0。旧私有内核输出构建仍有缺 `Module.symvers`、modpost与时钟告警，不能当作精确发布构建；原工程/外部快照未参与构建。详见 `docs/research/HARDNPU_H1_PL330_64B_DDR_COPY_BOARD_20260926.md`。

## 2026-09-26 PL330 MMIO 资源申请探针目标构建

最小探针仅在板端新 `/run/h1_dma_claim_20260926_1` 从历史私有源码/输出树外部构建，源码与工作树2/2哈希一致，模块 SHA-256=`82374558e15db5679c79a1c640b8e18b16cac424844a42bd423e9a950d6c68f6`、vermagic匹配。首次无 `O=` 构建因缺配置返回2；重试指定旧输出后返回0，但 `Module.symvers` 缺失、modpost 未解析符号和 clock-skew 告警仍在。一次受限装载/卸载成功，模块数0；不证明当前内核精确 ABI，也未运行 DMA。见 `docs/research/HARDNPU_H1_PL330_MMIO_CLAIM_BOARD_20260926.md`。

## 2026-09-26 PL330 纯微码编码器目标构建

`experiments/h1_axi_dma_microcode_20260926/` 三份源只经 `tools/npu/stage_h1_dma_microcode_20260926.ps1` 送入新板端私有 `/run/h1_dma_microcode_20260926_1`，哈希3/3一致；主机 MinGW GCC 和板端 GCC 均以严格 C11、`-Wall -Wextra -Werror -O2` 编译并通过精确字节/9个拒绝条件测试。板端测试二进制 SHA-256=`236fa72b72583a322af120c861c06d2634536e12e71a176ffde4c90b93c4b280`、模块数0。该代码不含 MMIO，不能作为 DMA 控制或受保护传输通过证据；详见 `docs/research/HARDNPU_H1_PL330_DMAGO_SECURITY_MISMATCH_20260926.md`。

## 2026-09-26 非安全 AXI DMA 只读探针目标构建

工作树 `experiments/h1_axi_dma_readonly_20260926/h1_axi_dma_readonly.c` 源 SHA-256=`6e8f645389dedd6b689efd85e9de3c4798ec9ef0e17b3db6455842b006dd2d83`，仅送到板端私有 `/run/h1_axi_dma_readonly_20260926_2`，板端 GCC 严格 C11、`-Wall -Wextra -Werror -O2` 构建成功，二进制 SHA-256=`ca0374e01455b043106067048dc098a5bc52c1537a83ba3f0c73721bfb31dba5`。只读 MMIO 实验无内核模块、无 DMA/DDRS1 写或 NPU START；不能用此构建作为未来 DMA 控制程序验收。详见 `docs/research/HARDNPU_H1_AXI_DMA_NONSECURE_READONLY_20260926.md`。

## 2026-09-26 SDK linux 子模块源码边界

安路 SDK 声明 `linux` 子模块；本地 SDK_2026.01 快照未检出该子模块。已有 2025.07 `linux-SDK_2025.07-linux6.1.tar.gz` 的 Makefile 为6.1.111、DR1M90 RT defconfig 含 PL330=y，但当前 Image 的 AMBA 对象资源偏移与用历史头文件构建的模块不同。后续目标模块构建须先锁定当前 Image 对应源码/实际 `.config`/输出并验证使用到的 ABI；不能仅用 release、defconfig、vermagic或可装载性认定匹配。见 `docs/research/HARDNPU_H1_SDK_LINUX_SUBMODULE_AND_RISCV_SCOPE_20260926.md`。

## 2026-09-26 PL330 模块 ABI 反证

仅板端新私有 `/run/h1_pl330_build_20260926_1` 对历史树`pl330.c`做外部模块构建，模块 SHA-256=`38f6fe713383787fecf211dd307695229dec91484c615cca38a689aa684d8f33`。加载返回0但设备 probe 因资源字段错位失败；新 `/run/h1_amba_resource_probe_20260926_1` 只读诊断模块 SHA-256=`34bacb3643b4c333ee72db1cef6d054d3341a1661604d4dfc3a2bf`实证 AMBA 布局与运行内核不兼容。两模块已卸载、模块数0。该历史构建树不得视为当前内核完整 ABI 的权威输出，不能因 vermagic 匹配放行 PL330 DMA 或 H1 首算。详见 `docs/research/HARDNPU_H1_PL330_AMBA_ABI_MISMATCH_BOARD_20260926.md`。

## 2026-09-26 当前内核与历史目标构建树的身份边界

板端历史输出树`CONFIG_PL330_DMA=y`且生成编译信息为 GCC9/root；运行内核`/proc/version`为 Linaro GCC7.5/uisrc，当前 PL330 AMBA 设备未绑定驱动，且运行配置不可读。外部模块虽有相同`6.1.111-rt42` release/vermagic并能装载，仍只保留目标构建和受限装载证据，不宣称与运行内核精确同源或生产可复现。生成编译信息可能已因后续 Kbuild 改写，不能将差异直接判为源码不同。见 `docs/research/HARDNPU_H1_PL330_LIVE_KERNEL_PROVENANCE_20260926.md`。

## 2026-09-26 H1 DDRS1 使能读回试验产物

复用上一轮仅在板端私有 `/run/h1_ddrs1_enable_probe_20260926_1` 构建且已核哈希的 H1 模块（SHA-256=`4996fe04fa42c218ba6c91b7bf639d0f65fdf743aa591eb8364e817b257c2217`）。本轮未重新构建，显式装载参数仅开启 DDRS1 使能探针；默认 HardNPU RUN 两参数仍关闭。一次短时使能/关闭和恢复通过，随后卸载模块数0；未执行 NPU START。既有 `Module.symvers`、clock-skew及内核源码精确身份限制仍适用。见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_READBACK_BOARD_20260926.md`。

## 2026-09-26 H1 START 前旧事件门槛目标构建

修订源仅在板端新 `/run/h1_prestart_status_20260926_2` 构建，目标严格 C11 用户程序和 Kbuild 模块通过；模块 SHA-256=`9b9f2b5c75bb45f2e3ecd02da2765534aaa789bc87b2a85022ac755c4e9b2c6d`、vermagic匹配。默认关闭下冻结载荷、诊断轨迹与卸载通过，最终模块数0；没有触发真实 START 前读回或 START。缺 `Module.symvers` 与 clock-skew 告警，精确源码身份不由此证明。见 `docs/research/HARDNPU_H1_PRESTART_STALE_IRQ_GUARD_20260926.md`。

## 2026-09-26 H1 DDRS1 短时使能探针默认关闭目标构建

仅在板端新 `/run/h1_ddrs1_enable_probe_20260926_1` 构建，目标严格 GCC C11 用户程序通过，Kbuild 模块 SHA-256=`4996fe04fa42c218ba6c91b7bf639d0f65fdf743aa591eb8364e817b257c2217`、vermagic匹配运行内核。默认参数装载下探针 `EPERM`、只读基线及卸载通过；没有武装 DDRS1 使能或 NPU START。仍有 `Module.symvers` 与 clock-skew 告警，精确内核源码身份未证；详见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_PROBE_PREP_20260926.md`。

## 2026-09-26 H1 DDRS1 八区关闭状态事务目标构建

仅在板端新 `/run/h1_ddrs1_full_transaction_20260926_1` 构建同源 H1 候选，严格用户程序和纯C合同测试通过。模块 SHA-256=`84f4bb31b38bbda339c8b68d7da6f918e565671ace19f66239faf6eb6165ad10`、vermagic匹配；默认拒绝和一次显式无 START 八区事务/恢复通过，最终模块数0。`Module.symvers` 未解析符号与 clock-skew 告警仍在；不能据此宣称发布构建或精确内核源码身份。见 `docs/research/HARDNPU_H1_DDRS1_FULL_DISABLED_TRANSACTION_20260926.md`。

## 2026-09-26 DDRS1 关闭状态写入探针目标构建

仅在板端新 `/run/h1_ddrs1_disabled_write_probe_20260926_1` 构建独立测试模块，Kbuild退出0，vermagic匹配，SHA-256=`e077de354500b052e9452c06fc1086e295dfca88dd46bab3467f16c50bdbb3f7`。默认不武装装载/卸载通过；一次显式武装的区7 SAR 写入读回和恢复成功，H1 八区只读复核不变；最终模块数0。构建仍有 `Module.symvers` 和 clock-skew 告警。未在原工程/快照/U盘构建，未执行 NPU START。见 `docs/research/HARDNPU_H1_DDRS1_DISABLED_WRITE_READBACK_20260926.md`。

## 2026-09-26 H1 DDRS1 冲突实验目标构建

板端新 `/run/h1_ddrs1_claim_20260926_1` 与 `/run/h1_ddrs1_claim_obstacle_20260926_1` 分别构建 H1 候选及只登记资源的测试模块，两个产物均实际装载成功；H1 `.ko` SHA-256=`c0ee22e8d86177b3fec49369f2a3db0fc84734e6350d297017aa6d94b25eb688`。构建完整退出行/告警未归档，不能作为发布或精确内核源码同一性证据。测试后均卸载，模块数0，无 NPU START。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CONFLICT_BOARD_20260926.md`。

## 2026-09-25 H1 DDRS1 资源申请版目标构建

新板端私有 `/run/h1_ddrs1_claim_20260925_1` 中 Kbuild 产出模块 SHA-256=`50c1663bfce59cc3694ff5bb6da6398142149d1462db08c700b724c3a2cfeb1c`，vermagic 匹配，默认关闭参数下只读诊断及卸载通过；`Module.symvers` 缺失和时钟偏差告警仍在。后续临时占位模块的目标构建因 COM4 无输出未确认，不得写为构建成功。未在原工程/快照/U盘构建或执行 START。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CLAIM_20260925.md`。

## 2026-09-25 H1 DDRS1 生成器目标构建

本次15项输入仅传至板端新 `/run/h1_ddrs1_candidate_20260925_1`，逐哈希15/15同源。目标严格 GCC C11 正例1/反例12通过；历史私有6.1.111-rt42输出树 Kbuild 产出 vermagic 匹配的模块，SHA-256=`51619e89d763655d4448e321c5e6e707b6aafcce97d8f0ba4c606dd8267c0b46`。默认关闭参数下两次无启动装载/诊断/卸载通过，模块数0。Kbuild 输出本次未留存，既有 `Module.symvers` 和精确内核源码身份限制仍在。见 `docs/research/HARDNPU_H1_DDRS1_BUILDER_TARGET_20260925.md`。

## 2026-09-25 H1 DDRS1 候选生成主机构建

仅在隔离工作树以 MinGW GCC C11 `-Wall -Wextra -Werror -O2` 编译 `h1_ddrs1_contract.c` 与 `test_h1_ddrs1_contract.c`，执行输出 `H1_DDRS1_CONTRACT_PASS candidate=1 positive=1 negative=12`。改动后的板端内核模块尚未目标构建或板测；此前目标构建哈希只对应旧源码。无原工程、外部快照、U盘写入或 NPU START。

## 2026-09-25 H1 驱动 DDRS1 只读入口目标构建

15项输入仅在新板端 `/run/h1_ddrs1_live_diag_20260925_1` 私有目录目标构建且哈希与工作树一致。严格用户程序和目标模块构建成功；模块 SHA-256=`ca7b6fa0b42a1f6d3765f6a209a41d5d4c005978362059b6e30037516b73976a`，只读诊断程序 SHA-256=`d0067e68741e8577fa5c650efaa6e8b316d2b6896cc2fc06e703a957a0e2ceab`。默认双运行参数 N 下诊断、卸载通过，仍有缺 `Module.symvers` 和时钟偏差告警。未在原工程/快照/U盘构建，也未执行 START。见 `docs/research/HARDNPU_H1_DDRS1_DRIVER_LIVE_READ_20260925.md`。

## 2026-09-25 H1 DDRS1 补集匹配目标构建

新的 `h1_ddrs1_contract.c` 与 H1 模块仅在板端私有 `/run/h1_ddrs1_policy_20260925_1` 目标构建；14项输入逐哈希与工作树一致。主机和板端 C11 严格测试均为正例1/反例10通过。模块 SHA-256=`ecfca49cabe93a550fe2003034e72cbed831718fae6bda093a4f16bbc9ba2cbf`；默认双运行参数 N 的无启动装载/冻结载荷/卸载通过。仍有 `Module.symvers` 缺失及板端时钟偏差告警。未在原工程、快照或 U盘构建，未执行 RUN_ONCE/START。见 `docs/research/HARDNPU_H1_DDRS1_POLICY_MATCH_20260925.md`。

## 2026-09-25 DDRS1 固定只读探针目标构建

在板端 `/run/h1_ddrs1_readonly_20260925_1` 首次严格编译因 `write()` 返回值告警失败；修正后在新 `/run/h1_ddrs1_readonly_20260925_2` 严格 C11/GCC 构建返回0，源码 SHA-256=`0fed4589263e7c16bc32a1078f75315978da8b7cefb3ad4c1dfcf48ecf252629`，板端二进制 SHA-256=`92e912f4fc4d2b593326bd97249a6e6a99640484ce0abf4b5a00389cb8d36712`。程序只有五个固定只读地址选项；本次实读结果和受控故障见 `docs/research/HARDNPU_H1_BOARD_DDRS1_CTRL_READ_20260925.md`。无模块或 NPU 启动。

## 2026-09-25 H1 DMA 地址快照的无启动板端构建

仅在板端新 `/run/h1_ddr_snapshot_20260925_1` 使用既有私有 `6.1.111-rt42` 内核输出树构建 H1 模块，并以目标 GCC 严格 C11 构建新增地址打印的 `test_h1_stage`；两者返回0，SHA 分别为 `5926323984339b49719dfc8eec565259e2feae9bfa03ef935bef4b5d238cc753` 和 `23988fb98290a2bd9bc132797f3990a8221f7fea677d0ac2e9a019ffd8499824`。源和冻结数据11/11传输哈希一致。模块默认三运行参数均 `N`，一次无启动测试及卸载通过。`Module.symvers` 缺失的 modpost 告警仍在；没有启动 HardNPU。详见 `docs/research/HARDNPU_H1_BOARD_DDR_ADDRESS_SNAPSHOT_20260925.md`。

## 2026-09-24 H1 无桩分区隔离构建

新板端私有目录 `/run/h1_nostub_partition_20260924_1` 只复制已有目标探针、冻结模型及三份厂家库；目标两份精确预执行包装器从工作树源码编译，返回0，源端和板端 SHA-256 一致。没有在原工程、外部快照或 U盘构建。负门禁19项通过；真实 parser/Optimize 探针在被拒绝的 `ioctl 0x4801` 停止，不能记录为分区构建或运行通过。证据与边界见 `docs/research/HARDNPU_H1_NOSTUB_OPTIMIZE_DRIVER_BOUNDARY_20260924.md`。

用户随后主动重启板卡，`/run/h1_nostub_partition_20260924_1` 已清空。重启前回收的六份证据在工作树保存且当时与板端 SHA-256 相同；当前板端该临时二进制和输出已不存在，若继续目标试验须在新的隔离目录重新传输并核验，不能把历史目录当作当前可执行产物。

## 2026-09-24 H1 故障原因 ABI 2 板端构建

本轮仅将 `implementation_hardnpu/` 候选源码复制到新 `/run/h1_fault_telemetry_20260924_1`。三份关键源码 SHA-256 与工作树一致；板端 GCC 9.3.0 严格用户程序编译、目标 Kbuild 均退出0。模块与验收程序 SHA-256 分别为 `05bb0d4c02da8a1c4e6c95d2e15254d97118ca9b635e443b9f4ae0a059d04a88`、`8faad41757d56a66b3553ba4265b3059c6ec26d3304c8efa6f9239541ea69d45`。默认禁用模块装载、启动拒绝、冻结夹具预检、卸载通过；旧版验收程序因 ABI 版本不符退出1。`Module.symvers` 缺失与内核精确源码身份 `UNKNOWN` 继续适用；未执行真实启动。

## 2026-09-24 H1 IRQ 后使能候选构建

仅在板端新 `/run/h1_irq_arm_after_start_20260924_1` 私有目标树构建，返回0，模块 SHA-256 `36fedbf950b804c9a149365de68cd36382b95a9a274568af4f47bec24bba5313`。默认参数模块装载、匹配新 H1 UAPI 的冻结数据无启动预检、卸载通过；IRQ/START 实际顺序未运行。缺 `Module.symvers` 告警仍在，见 `docs/research/HARDNPU_H1_SOFT_RESET_IRQ_ARM_ORDER_20260924.md`。

## 2026-09-24 H1 权重哨兵候选目标构建

仅在工作树隔离 `experiments/h1_weight_guard_20260924/` 编译主机 DMA 合同/状态机测试，均通过；板端新 `/run/h1_weight_guard_20260924_1` 目标 Kbuild 复核返回0，模块 SHA-256 `c247a6f7b90cbf0af0221550a76c08d477e891ad0c7283f74f346322ac06e831`，匹配新头的用户程序二进制 SHA `31988379aa060e70eaebd443a251ab4d019bed23d960f1233e445ff06d04ed41`。新模块预检和默认拒绝通过，无 NPU START；缺 `Module.symvers` 告警仍在。见 `docs/research/HARDNPU_H1_WEIGHT_GUARD_AXI_LIMIT_20260924.md`。

## 2026-09-24 H1 可选复位实验候选目标构建

最终候选仅在板端新 `/run/h1_resetless_candidate_20260924_1` 用私有 `6.1.111-rt42` 输出树构建，模块 SHA-256 `9eeda930f958913116708877de39a767f8b7c366d47352e5dee299e38cf01d11`。单独启用 `trust_boot_reset_release=1` 时参数为 `N/N/Y`，无启动预检及重新装载后的默认 `EPERM` 拒绝、卸载均通过；真实复位/时钟/NPU 分支未运行。`Module.symvers` 缺失告警保留，见 `docs/research/HARDNPU_H1_OPTIONAL_RESET_ROUTE_20260924.md`。

## 2026-09-24 H1 原始输出留存程序修订构建

后续修订仅在板端新 `/run/h1_first_run_verify_20260924_2` 严格 C11 编译，源码哈希与工作树一致，二进制 SHA-256 `45d58972617e594a5e828ea7663cb99c6c4c457af981337c4c219b6b604c05fa`。离线比较、默认关闭模块预检、RUN_ONCE 的默认拒绝与空文件清理、卸载通过；未触发 NPU 或生成真实输出。详见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。

## 2026-09-24 H1 CRP 占用门禁目标构建

仅在板端新 `/run/h1_crp_claim_gate_20260924_1` 使用私有 `6.1.111-rt42` 输出树构建 H1 模块，返回0，模块 SHA-256 `b302c7da7861e25a089669df7c53bf2b07160929a753e7b36e820b697cbd14c9`。默认关闭参数的一次装载、冻结数据 `--preflight` COLD/零写、卸载通过；没有执行 RUN_ONCE 或资源申请分支。缺 `Module.symvers` 的未解析符号告警依旧。证据见 `docs/research/HARDNPU_H1_BOOT_DTB_CRP_OWNER_GATE_20260924.md`。

## 2026-09-24 H1 输出验收程序目标构建

新程序 `implementation_hardnpu/h1_first_run_verify.c` 仅在板端新 `/run/h1_first_run_verify_20260924_1` 原生 GCC 严格 C11 构建，源码板端与工作树 SHA-256 一致，构建返回0。复用已构建的默认禁用 H1 模块，仅运行 `--preflight`，一次装载/卸载和持有/释放通过，无 NPU START。源码/二进制 SHA 与边界见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`；`--execute` 未运行。

## 2026-09-24 H1 完成完整性门禁目标构建

主机 `experiments/h1_integrity_state_20260924/` 与板端新 `/run/h1_run_candidate_20260924_6` 严格 C11 状态机测试通过；板端同目录私有 6.1.111-rt42 Kbuild 返回0，模块 SHA-256 `12e2dd58c2c82587998fa132589f73228f297ea71f35652e80c523cc3e8087ea`。默认关闭模块装载、RUN 拒绝、旧载荷/轨迹回归、卸载通过；没有运行 IRQ 或 NPU。缺 `Module.symvers` 警告及源码哈希见 `docs/research/HARDNPU_H1_DONE_INTEGRITY_GUARD_20260924.md`。

## 2026-09-24 H1 默认禁用首算候选目标构建

仅在板端新 `/run/h1_run_candidate_20260924_5` 构建最终 H1 模块和严格 C11 门禁测试；Kbuild/用户态返回0，模块 SHA-256 `396ae2ca52463a918261fb601363e7f06a7784e2e96f40ad5ac23de582205e1a`、vermagic 匹配。默认参数装载、`RUN_ONCE` 拒绝/COLD/零命令、既有载荷/轨迹测试和卸载通过；未启用硬件路径。缺 `Module.symvers` 警告及证据边界见 `docs/research/HARDNPU_H1_GATED_FIRST_RUN_CANDIDATE_20260924.md`。

## 2026-09-24 H1 CRP 只读目标构建

固定地址 TOP/CRP 只读探针仅在板端新 `/run/h1_crp_ro_20260924_1` 原生严格 C11 构建和限时运行，源码 SHA-256 `0a6f4c788b9e7e76f19dac97419c83cb77210b19d1605a4cddbde509d1b6178f` 与工作树一致；退出0，`CRP+0x74=0x73f0`。使用 `O_RDONLY/PROT_READ`，未加载模块或写硬件；来源及解释限制见 `docs/research/HARDNPU_H1_LIVE_RESET_BINDING_20260924.md`。

## 2026-09-24 H1 资源门禁无启动目标构建

仅在板端新 `/run/h1_resource_gate_20260924_1` 使用私有 6.1.111-rt42 输出树构建 `h1_alloc_probe_module`，最终返回0；模块 SHA-256 `16dca6d51189d0745b830a3ab2fe8785a422b3fc3a9ad4626a9a2083cfefb13f`。一次装载、既有固定载荷/8 笔轨迹回归、卸载均通过，无寄存器写或 NPU 作业。缺 `Module.symvers` 的 modpost 警告仍在；见 `docs/research/HARDNPU_H1_LIVE_RESOURCE_GATE_20260924.md`。

## 2026-09-24 H1 激活顺序纯软件构建

主机仅在工作树 `experiments/h1_activation_state_20260924/`，板端仅在新 `/run/h1_activation_state_20260924_1`，以严格 C11 构建/运行 H1 状态机测试，均输出 `H1_RUN_STATE_PASS`。未构建或加载内核模块，也未启动 NPU；源码哈希及验证范围见 `docs/research/HARDNPU_H1_ACTIVATION_PIN_ORDER_20260924.md`。

## 2026-09-24 H1 TOP 只读探针目标构建

固定 TOP 页只读探针 `implementation_hardnpu/h1_top_readonly.c` 仅在板端新 `/run/h1_top_ro_20260924_1` 原生严格 C11 构建并单次限时运行，返回 `0xF8800030=0`、`0xF88001B8=0`。只映射 `O_RDONLY/PROT_READ`，没有寄存器写、NPU 作业或目标内核模块。源码/目标哈希和手册解释见 `docs/research/HARDNPU_H1_LIVE_TOP_CLOCK_READ_20260924.md`。

## 2026-09-24 H1 持续引用目标构建

在板端新 `/run/h1_owner_hold_20260924_1` 中，历史私有 6.1.111-rt42 输出树 Kbuild 与原生严格 C11 两个用户程序构建完成。两轮模块装载分别验证 HOLD/RELEASE 同进程与跨进程生命周期；后者在测试进程退出后拒绝普通卸载，独立释放后卸载成功。目标构建仍缺 `Module.symvers` 并有 clock-skew 警告，未运行 NPU。源码/产物/日志哈希和限制见 `docs/research/HARDNPU_H1_PERSISTENT_OWNER_HOLD_20260924.md`。

## 2026-09-24 H1 解绑保护目标构建

在板端新 `/run/h1_bind_guard_20260924_1` 用历史私有 6.1.111-rt42 输出树构建无启动模块，源码传输 SHA 一致；一次装载检查 sysfs bind/unbind 缺失，固定数据/轨迹测试通过，一次空闲卸载通过。另一次装载证明设备 FD 持有时 `rmmod` 拒绝、关闭后卸载成功。`h1_run_state` 引用前置条件在工作树 MinGW 和板端新 `/run/h1_owner_guard_20260924_1` 严格 C11 构建/运行通过。目标 Kbuild 仍缺 `Module.symvers` 且有 clock-skew 警告，未执行 NPU。原始日志与限制见 `docs/research/HARDNPU_H1_MODULE_LIFETIME_GUARD_20260924.md`。

## 2026-09-24 H1 无启动目标地址轨迹构建

仅在板端新 `/run/h1_stage_trace_20260924_1` 中使用历史私有 6.1.111-rt42 输出树 Kbuild 和原生 GCC 构建；模块/测试 SHA 与原始日志见 `docs/research/HARDNPU_H1_BOARD_DMA_PLAN_TRACE_20260924.md`。一次装载、固定输入/权重装入、真实分配地址的 8 笔诊断轨迹、卸载通过，无 NPU MMIO 或 IRQ。`Module.symvers` 缺失和 clock-skew 警告仍在，此结果仅为目标诊断构建及无启动测试，不是首算或发布构建。

## 2026-09-24 H1 提交状态包装主机构建

只在工作树隔离 `experiments/hardnpu_h1_submit_state_20260924_1/` 生成主机测试程序：`h1_dma_contract.c`、`h1_packet_fixture.c`、`h1_run_state.c`、`test_h1_run_state.c` 以 MinGW GCC 严格 C11 编译并通过。测试回调无 MMIO，未进行目标模块构建、加载或硬件运行。旧隔离测试产物未覆盖。详见 `docs/research/HARDNPU_H1_SUBMIT_STATE_AND_IRQ_MASK_20260924.md`。

## 2026-09-24 H1 一次性状态机纯软件构建

`h1_run_state` 与测试仅在工作树隔离 `experiments/hardnpu_h1_run_state_20260924_1/` 和板端新 `/run/h1_run_state_20260924_1` 做 C11 严格编译/运行，两处均通过；没有 Kbuild、模块装载或设备读写。运行中 TF BOOT 分区只读挂载用于哈希，已卸载，未改启动文件。详见 `docs/research/HARDNPU_H1_ONESHOT_IRQ_AND_BOOT_AUDIT_20260924.md`。

## 2026-09-24 H1 数据装载候选构建

新 `/run/h1_stage_20260924_1` 在板端历史私有 `6.1.111-rt42` 内核输出树中构建 H1 限定装载模块，返回 0、vermagic 匹配；原生用户测试程序严格编译返回 0，一次加载/装载测试/卸载成功。内核 `Module.symvers` 仍缺且有 clock-skew 警告，结论仅为诊断候选的目标构建和无启动数据装载验证。源码、二进制 SHA 和限制见 `docs/research/HARDNPU_H1_TARGET_PAYLOAD_STAGING_20260924.md`。原工程和外部快照未构建。

## 2026-09-24 H1 分配候选构建

板端标准 `/lib/modules/6.1.111-rt42/build` 不存在，但历史私有 `/root/dr1_npu_module_build_20260914_r2/{source,output/kernel}` 仍在，输出树 `kernel.release` 与运行内核同为 `6.1.111-rt42`。只在新 `/run/h1_alloc_probe_20260924` 构建 H1 四缓冲分配候选，返回 0，模块 vermagic 匹配；随后一次加载分配/校验和一次卸载成功，未启动 NPU。内核 `Module.symvers` 缺失导致 modpost 未解析符号警告，板端时间偏差导致 clock-skew 警告，不能推断精确源码同一性或发布可用性。详细日志和源码哈希见 `docs/research/HARDNPU_H1_ALLOCATION_MODULE_TARGET_BUILD_20260924.md`。原工程和外部快照均未构建。

状态日期：2026-09-20。本文记录历史入口和风险，**不是可直接执行的一键构建指南**。当前基线目录和外部快照都禁止构建、生成、仿真和板测准备。

## 2026-09-20 SoftNPU 隔离构建记录

本地只读证据中已找到 `F:/My_proj/_isolated_builds/softnpu_takeover_20260914_1/linux-SDK_2025.07-linux6.1.tar.gz`（221819301 字节，SHA-256 `521d0bd9d3fda583e4dd91d5a4694158844392bcd6e0d7ccfa01d7f4563e128f`），另两份备份副本逐字节同哈希。归档 Makefile 为 Linux 6.1.111，`localversion-rt` 为 `-rt42`，与历史实读板端 `6.1.111-rt42` 一致；`anlogic_dr1m90_rt_defconfig` 启用 PREEMPT_RT、模块、模块卸载、CMA 和 DMA_CMA。对 v0.5.2 所需 API 的选择性源码审计已通过，因此状态仅提升为 `SOURCE_API_COMPATIBILITY_ACCEPTED_LIMITED`。

该归档不包含生成 `.config`、`include/generated` 或 `Module.symvers`，Windows 本机也没有可用 Linux/AArch64 目标构建链，故它不是可直接用于外部模块的完整 prepared output tree，不能写成目标编译通过。审计证据位于 `F:/My_proj/_isolated_builds/softnpu_kernel_sdk_audit_20260920_1/`，15/15 清单通过，`FINAL_SHA256SUMS.txt` SHA-256 为 `4b49b73ffff305cdcd19534a224a061b33463844ecb856416b0262386d20b638`。仍不得把历史构建命令整理成 Windows 一键执行入口；下一目标构建须在冷恢复后的板端新私有目录中使用匹配输出树完成。

v0.5.4 ABI `0x00010006` 仅支持原生64位 ioctl。主机状态机162/162、追踪21/21、静态门禁35/35及UAPI编译断言通过后，用户确认物理冷恢复，板端新私有目录 `/root/softnpu_ddr_v054_target_20260920_1/` 使用只读U盘中的 Linux 6.1.111 + `-rt42` SDK 完成原生 AArch64 构建。构建依赖仅解包到私有 `toolroot`，没有安装到板端系统；bison 需要显式 `BISON_PKGDATADIR`，其 Debian 二进制还需显式 `M4` 指向私有 m4。

首次使用 `anlogic_dr1m90_rt_defconfig` 得到 `preempt_rt` vermagic，运行内核以 `Invalid module format` 明确拒绝；没有强制装载。随后确认当前内核要求普通 `preempt`。因板端时钟落后，单纯切换 defconfig 仍复用了旧生成物；仅在该私有 SDK 副本内执行 `mrproper`、统一私有文件时间戳并从 `anlogic_dr1m90_defconfig` 干净生成，才得到匹配的 `6.1.111-rt42 SMP preempt mod_unload aarch64`。最终模块/探针 SHA-256 分别为 `9ade02c508855b949dcba6708cc43d4f9867438638db3f5f8604612ee5c0f0a4`、`2e09c7f8f13fb3192153ea8e1349de158f67e7f2fec2fe7ea2448816e374076c`。

构建本身只能记 `TARGET_BUILD_PASS_LIMITED`：SDK没有 `Module.symvers`，modpost报告未解析符号，驱动还有1104字节栈帧警告。匹配模块先在80MHz临时环境以默认关闭run gate完成INFO与PREPARE-only；随后在另一次明确授权的冷启动中，以只读最小根、run gate显式开启执行唯一一次fixed Pool normal DDR作业并取得 `BOARD_PASS_LIMITED`。这不消除构建警告，也不把模块变成发布驱动。完整日志和回收缓冲位于 `F:/My_proj/_isolated_builds/softnpu_ddr_targetbuild_v054_20260920_1/`；任何后续硬件作业仍需新的隔离版本、前置门禁和冷恢复计划，不能把这里整理成一键运行命令。

另在 `F:/My_proj/_isolated_builds/softnpu_v053_submission_audit_20260920_1/` 用 MinGW 主机程序发射纯软件 write 序列，与冻结 normal/DMA 捕获逐笔比对 17/17；该主机 EXE 完成后已删除，审计包 20/20。它只验证 C 路径生成的 offset/value，不构成内核模块构建或硬件执行。

后续 v0.4 源码位于 `F:/My_proj/_isolated_builds/softnpu_ddr_outputgranule_20260920_1/`，PC 状态机/静态门禁复跑为 `143/143`、`24/24`。只读导入既有布局布线 DB 已确认 HP1 8 字节 beat，但没有运行新的硬件构建。v0.4 当前仍 `NOT_TARGET_BUILT/NOT_HARDWARE_RUN`；目标构建只允许在已确认物理冷恢复后的板端新私有目录，或具有匹配完整内核输出树的离线隔离环境执行。现有 PC 隔离目录未找到可替代板端输出树的 `Module.symvers/kernel.release` 组合。

既有 board DB 查询只是静态读取，不是综合、P&R 或 bitgen。它不能替代目标内核构建，也不能把动态 `WSTRB` 推定为全开。具体构建/运行决策见隔离目录 `v04_target_build_decision.md`；历史一键命令仍不得直接复制执行。

本轮只在 `F:/My_proj/_isolated_builds/softnpu_ddr_oneshot_20260920_1/` 和板端私有目录 `/root/softnpu_ddr_oneshot_20260920_7/` 构建；没有在本工程目录运行构建入口。目标为板载 `6.1.111-rt42`，最终模块/探针构建返回 0，vermagic 为 `6.1.111-rt42 SMP preempt mod_unload aarch64`。模块 SHA-256 为 `8d6575f5a2a2517e296658bdd7a1d418a0cbeee579cc6d18ab9a6fa7462c2b8b`，探针 SHA-256 为 `e47b8d050f7d0264d9f243d927e602cf915fb2b50029271e058ebcf15b4fac8c`；实际产物位于板端私有目录的 `driver/` 子目录。

该目标内核输出树没有 `Module.symvers` 且 `CONFIG_MODVERSIONS` 未设置，modpost 有 unresolved-symbol 警告；板端与电脑文件时间不同还产生 clock-skew 警告。因此状态仅为 `DONE_WITH_KNOWN_SYMBOL_TABLE_GAP`，不能作为通用或发布构建。模块已在无 SoftNPU 节点环境完成装载/卸载控制，在候选环境完成 PREPARE，并在只读最小 Linux 下执行唯一一次 normal-mode 作业；后者因 output guard 失败进入隔离，不代表构建或驱动已产品化。

80MHz bit 下载沿用已验证的 U-Boot 复位/分频、FD25.1 OpenOCD D2XX/RBB 和 TD 6.2.1 流程，仅易失下载、不写 Flash。这里不列成可直接复制的一键命令：必须先核对候选 bit/DTB 哈希、板卡状态、工具绝对路径和已有成功记录。常规 Linux 在线 `remount,ro` 本轮返回 busy，正确处理是 start 前中止；后续首算改用 U-Boot bootargs 指定 `ro init=/bin/bash`，不是绕过只读门禁。

## 只读查看方法

下列操作不启动项目工具、不导入项目模块，也不应产生工程输出：

- 用文本查看器或 `Get-Content` 阅读源码、配置、报告和日志。
- 用 `rg` 搜索文件名、接口常量、路径和报告关键字。
- 用 `Test-Path` / `Get-ChildItem` 确认路径和目录内容。
- 用 `Get-FileHash -Algorithm SHA256` 核对既有产物；不得把输出写回基线 manifest。
- 读取 JSON 时仅解析现有文件；不得运行生成这些 JSON 的模型脚本。

只读检查仍需避免会创建缓存的项目模块导入、IDE 打开/升级工程、供应商数据库迁移和任何“Generate/Refresh/Build”操作。

## 当前受保护基线

- 工程目录：`F:/My_proj/fdma_imx415_20251008`，不得直接构建。
- 外部快照：`F:/My_proj/_snapshots/fdma_imx415_20251008_v2_known_good_20260908`，只读用途；2026-09-09 核验时路径及父目录不存在，状态为 `UNKNOWN`，不得自行创建替代品并称为既有快照。
- bit：`implementation_v2/soc_v2/soc_v2.bit`。
- ELF/BIN：`soc_sdk/duration_v2/build/duration_v2.elf` 和 `duration_v2.bin`。
- 固件及约束：`soc_sdk/duration_v2/main.c`、`board_lowfreq.sdc`、`reset_cdc_board.sdc`。
- 原始证据：`implementation_v2/board_test_20260907/` 下回读、下载、功能、重复、复位和 UART 日志。
- 用户新增的视频参考工程：`demo/11_csi_dsi_imx415_7cun/`。该目录位于原工程内，只允许只读核验；在建立其产物manifest和隔离副本前不得直接打开升级、Generate、构建、bitgen、SDK构建或覆盖根 `BOOT.bin`。

## 历史构建入口及覆盖面

下表仅用于识别历史流程。入口名称不表示当前可安全运行。

| 层级 | 历史入口 | 历史输入/输出 | 已确认覆盖或写入风险 |
|---|---|---|---|
| SDK 准备 | `implementation_v2/prepare_sdk.py` | 从普通 TCON 应用复制元数据/lds，以 `sdk_main.c` 准备 `soc_sdk/duration_v2/` | 无条件改写 `.project`、`.cproject`、`.ApplicationProject`、`Makefile`、lds 和当前 `main.c`；旧模板缺 100/50MHz、板测状态及 version 双检查 |
| SDK 构建 | `implementation_v2/build_sdk.py` | 在 `soc_sdk/duration_v2` 调用 FD make，使用共享 `soc_sdk/soc_base` | 覆盖/更新应用 build 下 ELF、BIN、map 等输出，写 `implementation_v2/test_results/sdk_build.log`，并可能更新共享 BSP 构建产物 |
| SoC 变体准备 | `implementation_v2/prepare_soc_variant.py` | 从 `soc_prj` 复制到 `implementation_v2/soc_v2` 并替换 temporal_conv 生成槽 | 目标存在时会停止；目标不存在时创建并写大量工程文件。不能为了重跑删除现有目录；其生成 README 仍含早期“未 P&R/bit”状态 |
| SoC 综合 | `synthesis.tcl` | `system_top`、工程 RTL、ADC、默认 IP SDC | 写数据库、面积报告和综合输出；默认 IP SDC 为 400MHz 的 /2、/3，即约 200/133.32MHz |
| 布局布线 | `physical_board.tcl` | 综合数据库和工程约束 | 写 P&R 数据库及报告；历史默认频率报告含负裕量 |
| 低频重约束 | `check_lowfreq.tcl` | 从 P&R 数据库清除 SDC 后加载 `board_lowfreq.sdc` 及顶层 timing SDC | 写低频数据库/报告；不能只改分析约束而不匹配固件实际分频 |
| 最终约束 | `final_board.tcl` | 低频数据库加 `reset_cdc_board.sdc` | 写最终数据库/报告；复位例外仅限指定同步器首级，不是完整 CDC 签核 |
| 编程文件 | `bitgen_board.tcl` | `soc_v2_board.db` | `bitgen -bit soc_v2.bit` 直接覆盖 known-good bit |
| Design Integrator | GUI Generate | 原设计/IP 元数据 | 可能将 V2 适配生成槽恢复为普通 TCON；当前禁止 |
| 数学/仿真 | `simulation/`、`innovation_research/`、`implementation_v2/verify.py` 中的历史入口 | 生成测试、日志和结果 JSON | 会写或覆盖结果、日志、临时 RTL/仿真输出；当前禁止 |

历史板测还使用 `platform_probe.tcl`、`download_v2.tcl`、`run_v2.gdb`、`verify_readback.py`、结果/压力 GDB 脚本和串口采集。这些属于下载、回读、板测或日志覆盖流程，本阶段不得执行。

## 当前禁止在基线目录运行

- `prepare_sdk.py`、`build_sdk.py`、`prepare_soc_variant.py`。
- Design Integrator Generate、任何同步/再生成动作。
- synthesis、P&R、时序数据库更新、bitgen。
- Python 数学模型、结果 JSON 生成、RTL/AXI 仿真。
- SDK make、BSP 重建、ELF/BIN/链接映射生成。
- JTAG/OpenOCD/GDB 下载与回读、板测、串口采集、Flash 操作。
- 任何会写 `.metadata`、工程数据库、缓存、日志或结果目录的 IDE/工具动作。

## 未来隔离构建前置条件

只有在后续任务明确授权后，才可设计隔离流程；开始任何构建前必须同时满足：

1. 定位或恢复外部只读快照，并对关键输入、bit、ELF、BIN、固件、SDC、报告和日志生成只读 manifest；所有已知哈希匹配。
2. 创建与原工程、外部快照不同的完整隔离工作副本；不得用 junction/symlink 或共享 build/BSP 目录回指基线。
3. 静态检查全部 Python、Tcl、Makefile、GDB 和工程元数据中的绝对路径，证明输入、输出、日志和临时目录都落在隔离副本。
4. 固定工具版本、器件库、环境变量、许可证位置、PATH 顺序和工程顶层；不在文档或版本库复制许可证内容。
5. 明确目标版本和 ABI；V2 DUC2、普通 TCON、V4、V4R 分开构建，禁止仅按 `0x90000000` 选固件。
6. 同时绑定软件分频与 SDC：V2 known-good 为 100/50MHz；默认约 200/133.32MHz 是另一配置。
7. 保留输入及输出的前后哈希；构建后证明原工程和外部快照未变。
8. 先定义验收层级。构建成功不等于仿真、P&R、bit、固件装载或 BOARD_PASS；新产物不得继承旧产物状态。
9. 准备失败或差异无法解释时停止，保留隔离日志，不回写基线“修复”。

## 工具版本和绝对路径风险

历史记录显示 TD 运行版本 6.2.168116、安装目录 `D:/TD6.2.1`；FD 25.1、安装目录 `D:/FD25.1`；仿真日志提及 Icarus 12.0 开发版。当前许可证有效性、器件库版本、Python 精确版本和工具可重跑状态均为 `UNKNOWN`。

`build_sdk.py` 把 FD 工具路径写死为 `D:/FD25.1/...`；保存的 GDB/构建日志和 BSP 调试信息还包含 `F:/My_proj/fdma_imx415_20251008` 绝对路径。直接复制单个 ELF、修改 PATH 或把隔离目录映射回原路径都不能证明可复现，也可能让输出写回基线。

## Git 建基线后的附加条件

- 2026-09-09 已初始化本地 Git/main，但这不改变“原工程不得直接构建”的限制。
- 未来隔离副本构建前必须能运行 `tools/git/repo_guard.ps1 -Mode Baseline`，确认17项 V2 基线哈希；构建后还必须证明原基线未变化。
- Git LFS 仅保存指定 known-good bit/ELF/BIN，不意味着历史构建命令可安全重跑。
- Build isolation 状态为 `TODO`，clean reproducible build 为 `UNKNOWN`；首次 Git 提交和 tag 也不能提升这两个状态。
- 首次源码/验证提交纳入若干历史 Python/Tcl/SDC/PRJ 和 Makefile 仅为版本化输入，不表示这些入口已变得可安全执行；本轮没有运行其中任何一个。

## 2026-09-09 V4R-1 隔离构建记录

用户授权实现 V4R 后，在 `F:/My_proj/_isolated_builds/` 建立了独立目录并完成一轮 V4R-1 构建。原工程只保存权威源码、manifest 和文档，没有在原工程运行 SoC/SDK 准备、综合、P&R、bitgen 或 SDK 构建。收尾重跑仿真时曾因新建隔离目录参数错误，在原工程误运行一次回归并新建 `implementation_v4r/sim/`；确认该目录此前不存在且只含本轮 9 个临时文件后已删除，随后在 `_7` 隔离目录用绝对脚本路径重跑通过。最终检查确认原工程不存在该 `sim/` 目录。

V4R 的历史入口为 `implementation_v4r/prepare_soc_variant.py`、`prepare_sdk.py`、`build_sdk.py` 和生成到隔离副本内的 Tcl。它们不是可在原工程直接执行的一键命令：前两个会创建 SoC/SDK 变体，SDK 构建会写 build 输出，TD 流会写数据库/报告/bit。`prepare_soc_variant.py` 会在目标已存在时停止，也不会调用 Design Integrator Generate；但仍必须只在新隔离副本运行。

`implementation_v4r/verify.py` 不再内置个人目录；隔离运行时必须显式设置 `IVERILOG_BIN`，或由隔离环境 PATH 提供 `iverilog`/`vvp`。`build_sdk.py` 仍固定到当前已验证的 `D:/FD25.1`，换机或换版本前必须先改为受控工具配置并重验，不能假定该绝对路径存在。

本轮证据：

- Icarus core/AXI 最终仿真：`F:/My_proj/_isolated_builds/fdma_imx415_v4r_20260909_7/sim/results/report.json`。
- 单核 TD 综合：`F:/My_proj/_isolated_builds/fdma_imx415_v4r_20260909_6/implementation_v4r/td/`。
- 完整 SoC 构建：`F:/My_proj/_isolated_builds/fdma_imx415_v4r_soc_20260909_1/`。
- 最终 100/50MHz 时序、bit/ELF 路径和哈希：`implementation_v4r/V4R_BUILD_MANIFEST_20260909.json`。

默认高频约束的完整 SoC P&R 虽完成布线，但 setup WNS 为负；低频重约束先得到 setup 正裕量、一个外部复位 CDC 保持违例。继承的 V2 SDC 端点名称未匹配当前物理数据库，V4R 流改为只对真实 `reg[1].ie` 异步入口做唯一匹配例外，最终 setup WNS `+4.223ns`、hold WNS `+0.020ns`、TNS 均为 0 后才执行 bitgen。该例外不代表完整 CDC/PVT 签核；历史 NPU 的异步复位到 ERAM critical-warning 仍需单独处理。

本轮证明了“一次隔离构建不回写 V2 基线”，尚未证明第二个全新副本可产生字节完全相同的结果。clean reproducible build 仍为 `UNKNOWN`。

## 2026-09-11 IMX415/DSI demo只读审查

`demo/11_csi_dsi_imx415_7cun/` 保存了一份候选完整视频参考工程。保存的 P&R PRJ 明确使用 `soc_prj/uisrc/01_rtl/system.v` 中的 `system_top`；旁边的 `system_top.v` 是不同的 HDMI 顶层，不得因同名而替换。有效源包含IMX415四通道CSI输入、ISP、DDR三帧缓存读写、1024×600 DSI视频包、显示配置ROM和四通道MIPI D-PHY TX。保存的 TD 6.2.168116 最终报告 setup/hold WNS 为 `+7.748ns/+0.039ns`，bit 已生成。

用户确认该 demo 已在7寸屏显示正常，但当前缺少可把板上结果绑定到唯一组合的manifest：根 `BOOT.bin` 日期为2025-06-24，保存的 `fdma_en.elf` 为2025-06-19，当前P&R bit为2025-09-29；`uisrc/05_boot/BOOT.bin` 是另一个更旧且不同哈希的文件，`output.bif` 还写死失效的 `F:/anlogic_demo/...` 路径。因此未来迁移前应在只读状态记录用户实际使用的根BOOT、屏幕型号和连接，再复制整个demo到新的隔离副本；不得在demo原目录尝试重建来“确认”产物来源。

## 2026-09-18 Soft NPU V3软件entry探针构建边界

2026-09-18 V3隔离entry探针的目标Linux构建只发生于板端新私有目录`/root/g4b_v3_gate_20260918_1`；原工程和只读U盘不构建。板载旧头文件未定义`SYS_close_range`，直接编译按设计失败。经运行内核符号、Linux v6.1 AArch64系统调用表核对436后，**仅该板**在编译时补充`-DSYS_close_range=436`，产物SHA-256=`f5c573b851fa3de5f28c0d319518d9a95d73a9bc7bf0561b35310806a90ad4c6`，不能写成跨版本一键命令。隔离门禁及一次软件entry捕获已通过，但真实packet和设备执行仍未通过；详见`docs/research/SOFTNPU_G4B_V3_VENDOR_ENTRY_CAPTURE_20260918.md`。

## 2026-09-18 Soft NPU V1软件包探针构建边界

V1仅在板端新私有目录`/root/g4b_packet_capture_20260918_1`目标构建，仍针对当前Linux旧头文件作板端限定`-DSYS_close_range=436`兼容；ELF SHA-256=`f290f40a68845fa1702f205255059805289184967a546387cb80a0801786ecd2`。U盘只读核验后卸载，原工程、外部快照及U盘目录均未构建。非root负门禁、无库隔离门禁及一次限时**软件**打包捕获通过；不含NPU驱动加载、设备命令提交、DMA或算子计算。该选项不是通用构建配方。详见`docs/research/SOFTNPU_G4B_VENDOR_SYNTHETIC_PACKET_CAPTURE_20260918.md`。

## 2026-09-18 Soft NPU固定Pool填充V3构建边界

冻结V3源码只在真实板端此前不存在的`/root/g4b_pool_fill_capture_v3_20260918_1`私有目录目标编译；原工程、外部快照和U盘均未构建。只读U盘和板端副本清单各3/3通过，目标`g++ -std=c++17 -O2 -Wall -Wextra -Werror`并仅对已核对的当前AArch64 Linux补`-DSYS_close_range=436`，退出0；ELF SHA-256=`5ca211d943d4c84bc7009796af8f0319582bd28d9df99487cea752830e7a579e`。非root负门禁、root无库门禁后，单次限时厂家**软件**填充/打包获得固定描述符20字，详见`docs/research/SOFTNPU_G4B_POOL_FILL_V3_BOARD_20260918.md`。这不是通用构建命令或设备运行许可；含`NN_start`的输出不得提交NPU。

## 2026-09-15 Soft NPU诊断v2构建边界

`tools/npu/soft_npu_diag_v2/`是权威源码位置，不是构建目录。6个源/说明文件已复制到`F:/My_proj/_isolated_builds/softnpu_diag_v2_20260915_1/`且哈希一致，另附`SHA256SUMS.txt`；7文件载荷也已复制到U盘新目录`DR1_SOFTNPU_DIAG_V2_20260915`并回读一致。2026-09-15只从只读U盘复制到板端新私有目录`/root/softnpu_diag_v2_20260915_1`后构建，没有在权威源码、PC隔离输入或U盘目录中生成构建产物。

后续构建必须复制到新的隔离或板端私有目录，并在构建前冻结：目标内核源码/commit或tar哈希、目标`.config`、`Module.symvers`可用性、编译器版本、`ARCH`/`CROSS_COMPILE`、运行内核`uname -r`。本次板端使用`/root/dr1_npu_module_build_20260914_r2/source`及其`output/kernel`，运行内核和输出树kernel.release均为`6.1.111-rt42`，板端GCC为9.3.0；`Module.symvers`缺失，目标内核未启用`CONFIG_MODVERSIONS`。模块vermagic匹配且实际加载，但候选源码树与运行内核的精确来源同一性仍`UNKNOWN`。候选源码包名为`linux-SDK_2025.07-linux6.1.tar.gz`，公开Arm NN运行库来自`SDK_2026.01`；该版本差异不能由`vermagic`相同消除。

诊断v2只允许生成只读bring-up模块。若源码检查发现`writel`、`remap_pfn_range`、IRQ使能、任意offset读写或DMA-start，构建应停止。本次模块和探针SHA-256分别为`62f00499b47e0620d3bd84d29411d3e6204bd3dd2058d80f40211c1793801462`、`82fa004bc3454ce81e642ded3cf64ff32125a0f83459cd8863f2d7c83a494839`；默认无IRQ和登记但禁用IRQ两级板测通过，仍只提升为受限控制面`BOARD_PASS_LIMITED`。它不代表公开Arm NN ABI、CMA/DMA、实际IRQ、算子或模型通过。公开运行库需要`/dev/hard_npu`、`/dev/soft_npu`和`/dev/cma_mem`，并对Hard/Soft窗口建立RW映射；不得把诊断v2设备改名后当成安全运行入口。

## 2026-09-15 Soft NPU G3连续内存诊断构建边界

权威源码位于`tools/npu/soft_npu_cma_diag_v1/`，只保存源码、说明、静态guard和SHA-256清单，不在原工程构建。最终6项载荷已经复制到全新隔离输入`F:/My_proj/_isolated_builds/softnpu_cma_diag_v1_20260915_2/`，静态guard通过且清单6/6匹配；先前`..._1`为复核前草案，不得用于板测。最终7文件包已新增到U盘`DR1_SOFTNPU_CMA_DIAG_V1_20260915/`，源端与U盘7/7一致、U盘清单6/6通过，没有覆盖既有U盘目录。

G3必须延续G2的板端私有构建规则：从只读U盘核验后复制到一个此前不存在的`/root/softnpu_cma_diag_v1_20260915_*`目录，记录运行内核、输出树kernel.release、GCC、`Module.symvers`状态、vermagic和最终模块/探针哈希。只加载本诊断，公开CMA/Hard/Soft NPU驱动和Arm NN必须保持未加载。

构建前静态门禁必须确认不存在`readl/writel/ioremap`、IRQ API、DMA-start、`remap_pfn_range`和`dma_sync_single_*`，并确认固定64KiB、32位DMA mask及`dma_mmap_coherent`仍在。板测只允许运行一次CPU-only探针和卸载恢复检查；它不允许任何NPU设备事务。只有分配地址在32位范围、两向逐字节一致、卸载后解绑且dmesg无DMA API错误/Oops/hang时，才可写`CMA_CPU_COHERENT_PASS_LIMITED`。

实际板端构建使用`/root/dr1_npu_module_build_20260914_r2/source`和`output/kernel`，二者kernel.release与运行内核均为`6.1.111-rt42`，GCC 9.3.0。`Module.symvers`仍缺失、`CONFIG_MODVERSIONS`未启用，故modpost出现未解析符号告警；模块vermagic匹配并实际加载。模块与用户探针SHA-256分别为`5478b2880227407bee1d3ba8c0fa6cc714e59da4a0d65d05b5ef3fe4e765b631`和`a2ee0ee5d5e40f7051e297d4bc31d977711c5a9ff7ca30659c8ff657f54b0fb4`。

唯一一次CPU-only探针和卸载恢复验收通过，状态为`CMA_CPU_COHERENT_PASS_LIMITED`。板端时间错误导致源码mtime和内核输出树出现clock-skew告警，不能以板端mtime证明产物日期；候选源码与运行内核的精确来源同一性仍`UNKNOWN`。本结果不授权直接运行公开CMA/Soft/Hard NPU驱动或Arm NN。

## 2026-09-15 Soft NPU G4a空闲IRQ构建边界

权威源码位于`tools/npu/soft_npu_irq_diag_v1/`，不能在原工程内构建。当前源码与静态guard已完成，清单6/6匹配；7项载荷已复制到新输入`F:/My_proj/_isolated_builds/softnpu_irq_diag_v1_20260915_1/`且源端/副本7/7一致、隔离清单6/6通过。尚未复制到U盘或板端，尚无模块/探针哈希和`vermagic`。

未来只允许复制到新的隔离输入和新的板端私有目录，继续使用与运行内核`6.1.111-rt42`一致的已核验输出树。构建前guard必须确认无MMIO写、DMA、用户控制输入、device start/ack，并确认恰好一个IRQ登记和一个运行期使能调用。板测只能在复位对齐80/40MHz临时冷启动中执行一次250ms空闲窗口；禁止同时加载公开NPU/CMA驱动、禁止Arm NN、禁止写任何NPU寄存器。任何事件、非零状态或内核异常都必须保持隔离并停止，不能自动重试。

2026-09-16已把同一7文件输入复制到U盘全新目录`DR1_SOFTNPU_IRQ_DIAG_V1_20260916/`，回读7/7哈希一致、内部清单6/6通过，随后Windows安全弹出且卷不可访问。U盘只作为只读传输输入；尚未在板端复制、构建或测试，构建产物哈希与`vermagic`仍`UNKNOWN`。原工程和PC隔离输入均未运行构建。

## 2026-09-16 G4a板端私有构建与卸载

同日稍后已在真实板卡以只读U盘核验G4a清单6/6，复制到此前不存在的`/root/softnpu_irq_diag_v1_20260916_1/`并复验6/6，随后卸载U盘。只在该板端私有目录调用既有`/root/dr1_npu_module_build_20260914_r2/source`与`output/kernel`构建模块及用户探针；运行内核/输出树均为`6.1.111-rt42`，板端GCC 9.3.0。`Module.symvers`仍缺失、`CONFIG_MODVERSIONS`未启用，modpost给出未解析符号告警；板端时钟错误另造成clock-skew告警，因此构建完成本身不能证明源码树的精确身份或可复现性。

模块SHA-256=`045eafb82af207e8fcf267928df6f7e6b3297023dadd13a5340a0e7d6087d98c`，探针SHA-256=`b94fdd75596f9933634e7534ee342ef7e42b74a17f21a33ac8f4b5a0674a41a2`；vermagic=`6.1.111-rt42 SMP preempt mod_unload aarch64`，实际加载、单次250ms空闲观察和卸载均成功。PC端JTAG工具只在新隔离日志目录`F:/My_proj/_isolated_builds/softnpu_g4a_board_20260916_1/`运行，使用哈希已核的旧候选bit易失下载，没有在原工程或旧候选目录生成构建输出。结果仅`IRQ_IDLE_WINDOW_PASS_LIMITED`；没有设备start/ack、DMA、算子或模型验证。工具首次因Windows反斜杠Tcl参数路径未读到下载脚本，实际下载由随后正斜杠路径的调用完成，不能将首次进程退出码0视为成功。

## 2026-09-17 G4前置三缓冲诊断构建门槛

`tools/npu/soft_npu_three_buffer_diag_v1/`为权威源码和冻结传输清单，不可在原工程内运行Kbuild。2026-09-17板端只读U盘清单4/4通过后，复制到新私有目录`/root/soft_npu_three_buffer_diag_v1_20260917_1/`并复验4/4；仅在该目录以当次运行内核`6.1.111-rt42`匹配的输出树和GCC 9.3.0目标编译。构建退出码0，模块SHA-256=`1e1a0c8e8ac52758ec1b34ea9bbeb03a7ca10c697fee1c81f001d8b78d328d2b`，`vermagic=6.1.111-rt42 SMP preempt mod_unload aarch64`；一次加载和卸载成功。`Module.symvers`缺失、modpost未解析符号告警及板端时钟偏差仍是构建证据缺口，不能据此声称精确内核源码同一性或可复现性。

本模块仅使用Soft平台设备的DMA API分配三块coherent缓冲；不含NPU寄存器映射、IRQ、运行库或用户控制入口。三缓冲板测结果仅为`THREE_BUFFER_CPU_ALLOCATION_PASS_LIMITED`，不等于设备DMA或Pool通过。详细结果与停机条件见`docs/research/SOFTNPU_G4_PRESTART_THREE_BUFFER_PLAN_20260917.md`。

## 2026-09-29 Hard＋Soft现场入口准备

后续实际运行：冷恢复后复用此模块，现场单图1506.721ms/128维已BOARD通过。连续候选implementation_softnpu/h6_serial以同板端kernel树、ARCH=arm64/CROSS_COMPILE为空/CC=gcc native构建通过，ABI1000a，模块SHAad7fbb0949f867e5ff71782b5f5dc0d1b282d594b9bb7e3535ccb6a0e829b2c8。Module.symvers/modpost/时钟及Image精确源码限制保留。experiments/h6_serial_cold_restore_20260929_1.tar.gz SHA1e171cabf19d20589f24b5e82c2e4e4af76c40f3919fecce2b19587ba2a180fe，236286B，含实际模块/新入口/类名，不重编旧Hard或重传CPU段。新连续模块未加载，须物理清除旧单次Soft固定后运行；已有START授权持续有效。

新实现implementation_softnpu/h6_live和implementation_hardnpu/runtime/{hard_soft_spatial,h5_serial_executor,h6_live_executor,run_hard_soft_image}.py；准备工具prepare_hard_soft_float.py保留训练浮点CPU前/尾段，H5/H6固定量化。板端私有/run/hard_soft_live_1，以旧6.1.111-rt42 kernel native构建两模块；临时init必须export标准PATH才能让GCC定位cc1，ro根下传输heredoc用/tmp内存挂载，不需root remount。Image精确源码/Module.symvers发布构建边界仍UNKNOWN。

experiments/hard_soft_live_cold_restore_20260929_1.tar.gz包含本次实际模块与源/资产/模型delta，receipt见hard-soft-live-board/receipt.json。冷恢复后复用实际模块；模型以板端已有legacy正确float spatial_cpu.onnx字节恢复并按SHA检查，只输出本次新目录。当前仅CPU入口614.672ms/128维已板跑，不自动加载新模块或在旧固定状态START。两设备现场实验待物理恢复；已有START授权持续有效。
