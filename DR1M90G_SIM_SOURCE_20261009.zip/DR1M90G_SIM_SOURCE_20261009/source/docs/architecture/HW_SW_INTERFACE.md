# Hardware/Software Interface

## 2026-10-09 AA224隔离采集候选（SIM/整合SYNTH，未BOARD）

仅sol_pillow_resize_20261009/integrated：FST1 0x90000104=0x10006，0x90000164=0x00e000e0（224×224）、0x168=200704B、0x16c=0x41413232（AA22）。0x144原flags保留，新增bit10跨时钟像素FIFO溢出、bit11输入行长度/中途SOF错误；任一错误粘滞停止有效像素、合并cap_fault并禁止发布完整帧，必须按真实故障恢复，不承诺热复位。

0x140仍默认0；一次enable接下一张完整1920×1080，结束后保持禁接下一帧直到enable低电平重装。原SFIFO104位写/26位读，2048四像素项；源端无背压，容量不是全帧缓存，也不保证实际50fps源不溢出。两时钟100/80MHz、32us/行仿真通过对应28.94fps，不是30fps BOARD。224 BGRX、小图stride896B、总200704B；FDMA448次56个64位数据拍，原三槽0xa000000起始/8MiB步长、保留DTB与末B完成guard不变。

small_runtime1仅接受新ABI/几何/算法和freeze-copy，沿原GP互斥与状态/代数校验，复制完整小图后原FLOAT32除255、均值/标准差及CHW，返回独立数组。旧全高清入口不支持此ABI，不能混用。现有PS、PLL、管脚、NPU模型和驱动保持；综合通过不代表布线/时序/板测通过，默认入口未切换。

## 2026-10-09 实时采集与共享GP互斥（CODED，板测PENDING）

现用BLOCK34 DW split bit的net_pl_control.v:96在任一PL任务pending或fault时拒绝全部写入，包括采集控制0x90000140。新生产者不能在PL任务执行期间直接暂停/恢复FDMA；只读状态没有此限制。

sol_resident_ring_20261009实时入口对FRONT96、DW144、DW16完整调用及完成检查，与全部采集控制写共享文件互斥；CPU/只读/Hard独立寄存器仍可重叠。实际PL失败后拒绝进一步GP写，不释放未知DMA或承诺热恢复；bit/驱动/数学不变。尚未板测，本次SError因果仍待实际定位，不以静态冲突证明硬件修复通过。

## 2026-10-08 可选整图固定Hard所有者（目标编译，未BOARD）

sol_block34_main_20261008：/dev/space16_fixed ABI0x42341600，LOAD_MODEL为16个904B packet/46080B weight定长padding槽；原H4/H5十槽身份不变，新前段六槽来自真实捕获。输入/输出最大451584B/coherent454656B、packet4096B、weight49152B，所有buffer仍既有4096/32bit/不重叠及pin规则。无新控制器或IRQ所有者；不与独立block34_hard_fixed/h4_h5_fixed同时加载。

为保留原固定16 CPU批处理，两组分别循环：BLOCK34 0..5→0，每作业换输入；H4/H5 6..15→6，仅6/12换输入，组内复用原输入。新K/0x29 IOW8结构{u32 abi,u32 first_model}只允许first_model0/6，须CAP_SYS_RAWIO、model_ready、phase COLD、没有module_ref/has_run/job_ready/input_ref、writes/irq/work均0及当前cursor0/6；仅改软件cursor，不读写MMIO、复位或释放缓冲。原RUN/完成/CRC/RELEASE保持。

Space16Executor加载一次供Block34HardExecutor借用，后者不另开Hard fd；Front96/两DW144/DW16继续由同一个共享PL driver拥有。复制的独立run_hard_soft_clip新增显式--combined-hard-root和hardpl34，仅固定16/硬件/原H4-H5/精确CPU TCN组合可用；原工程/默认runtime不修改。保存16输入运行sh在成功后卸载，失败保留设备；恢复sh仅在实际冷恢复后的临时环境恢复文件，不加载/START。计划完整16窗256 Hard与32 DW144，实际计算和正确性/速度PENDING。

## 2026-10-08 独立PL DW两模式候选接口（SIM/P&R/BIT/目标编译，未BOARD）

仅sol_block34_dw_split_20261008：BLOCK34控制版本0x90000084=0x60002，旧0x60001不可混用；匹配独立net_pl.c在probe强制检查版本。新增0x900000b0模式0原全块/1仅DW3/2仅DW4，复用原0x80控制区/owner3，每次串行作业明确写模式，reset默认0，忙或故障时保留原拒写门槛。其余算子与FST1版本保持。

同/dev/block34：G/1 Job56 ABI0x70001、H/1 ABI0x80001，输入UINT8[1,144,56,56]451584B，固定参数4608B；输出分别451584B和UINT8[1,144,28,32]129024B（最后4列0，客户端取前28列独立副本）。不新增DMA分配，复用BLOCK34 scratch3输入/scratch4输出，参数使用原buffer1起始+64；输入/参数CRC、所有缓冲guards、完整末B后done和失败pin保留。driver每次将unused寄存器写合法存活对齐地址；未使用偏移不代表该模式有访问。

新DW144Executor可直接供Block34HardExecutor的pl_dw参数调用，分工四Hard PW/六START+两PL DW+一CPU Add；product无PW CPU oracle。run_board_dw.py复用cpu_gap_check.tgz真实中间张量，先串行两模式运行，随后比较既有golden。尚无实际PL/NPU输出或整链速度证据，不能采用为默认。

## 2026-10-08 T30-2独立BLOCK34 Hard PW实验ABI（未BOARD计算）

实验/dev/block34_hard_fixed/ABI0x42340100复用H10固定加载/SET_INPUT/RUN/OUTPUT/RELEASE生命周期，不与已通过H4/H5 ABI0x48450100混用。顺序：block3 expand、project紧凑19行、project紧凑19行、project紧凑18行、block4 expand、project；6次固定作业，每作业清输入。四个PW的真实m/s依次25133/18、24048/24、18483/18、17055/23，标量权重候选会改变当前量化结果，NOT_ADOPTED。

紧凑分片每通道是本片连续行，无原图跨通道stride或猜测地址偏移；CPU切片/拼接空间行，DW/Add仍现有固定CPU规则。最大packet840/weight4608/input与output451584B，coherent分配分别4096/8192/454656/454656，所有提交基址4KiB对齐且32bit合法/存活/互不重叠。packet、weight来自实际厂家捕获，按固定FNV身份加载；包内bias、geometry及m/s已与模型检查。非正方形input通道descriptor高10位H/低10位W，compute grid高W/低H，修正checker；旧正方形不变。

运行统计仅writes==8计实际START，RUN ioctl次数单列；product不执行PW CPU金样、不逐作业保存大张量，validate/失败保留证据。完成/CRC/成功释放及实际故障后固定DMA的规则保持。首次板测是START前空闲拒绝，不能声称6作业或输出通过；原错误计数证据保留并在最新status解释。

## 2026-10-07 T30无屏运行补充（既有ABI不变）

当前qualified捕获ABI仍0x10003。disable_dsi.py先核验GPIO reset已释放、FST1 ID及支持ABI、capture=0，再将0x90000160显示enable置0并读回；只阻止uidbuf在S_IDLE开启未来读帧，不复位在途AXI，不释放0xb800000独立显示保留区，不关闭共享相机时钟。BOARD实际采集继续可用，off运行不生成PNG/RGBX。

--capture-no-snapshots直接传入save_snapshots=False；mapped路径不再为首末PNG而额外copy，原copy路径仍需全ROI用于原预处理。真实单帧mapped数值精确但2407.850ms慢于原总203.578ms，copy为默认。帧JSON增加host monotonic观察时间、发布sequence差和CSI Gray计数差；均不承诺曝光时间、传感器30fps或全帧持续处理。冻结/代数/完成及保留区规则保持。

CPU会话复用仅固定同模型路径/options/library的单进程CPUExecutionProvider；不缓存device executor/DMA/视频帧，不改变成功close/unload或失败保留规则。PC原CPU三窗+真实C128 fixed TCN零差，当前neon9混合会话复用BOARD收益PENDING；不能视为T30-4常驻硬件模式。

## 2026-10-07 DSI持续循环错位候选（SIM/SYNTH，未BOARD）

sol_dsi_frame_align_20261007复制已通过alignreset源，新增显示流游标对齐；模型、NPU ABI、80MHz HP0和独立显示DDR区域保持。候选FST1版本0x90000104=0x10005；原capture寄存器及0x90000160显示使能保持。新增只读0x90000164：低16位缺数损坏帧计数Gray码，高16位归零恢复计数Gray码，两者可回绕。扫描域先注册Gray码，UI域两级同步，仅用于本次故障定位。

缺数时DSI扫描/同步继续，损坏帧余部送黑。游标按FIFO实际非空消费递增，下次VS若非零，继续读完该帧剩余数据，归零后等待垂直后廊或下一VS；没有复位AXI/FIFO、释放或重用显示缓冲。读预取阈值增加到3个半行burst并受容量减一个完整burst/8拍余量约束，uidbuf原默认仍1。旧板具体FIFO缺数因果仍INFERRED。新实体修复尚未BOARD，缓冲读回精确不代替实体屏验收；此前三窗只作短期通过证据。

主入口可选mapped resize已CODED/OFFLINE精确、未BOARD，默认copy。只在完成当前写帧/全部B响应并停止采集后读映射槽；返回张量独立拥有数据，代数检查后才恢复采集。当前板最后确认仍ABI1.3；其后COM4无命令返回，实际状态UNKNOWN，已请求用户物理恢复。

## 2026-10-07 15:09 CPU原float32九层DW默认接口

run_live_window.sh第三参数默认neon9，显式ort回退；neon9使用/run/sol_float_dw9_graph1/models和同目录libdepthwise_ort.so，通过原--cpu-depthwise-library入口注册。sign_cpu::DepthwiseFloatFixed仅接受batch1/16及C192/H28、C384/H14、C576/H14、C960/H7，stride1/pad1/3×3、九tap FMA→bias→Clip0..6；计算无MMIO。图声明九处固定输出shape以让后继ORT看到原形状，原权重/其它节点不变。CpuDepthwiseLayersExecuted本窗144表示9层×16帧CPU计算，不是设备START。原核验模式和DMA/完成判据保持；快路径真实C128接口不变，当前时序CPU。

实际数值：四层未声明shape时整链失败，补shape后同库CPU尾部及整链零差；九层CPU尾部及两组实际16帧最终features/logits均字节精确。两对相同条件整推理7489.169→6812.292ms（中位9.038%减少）。没有新增硬件ABI/bit/FPGA资源/量化。USB float_dw9_cpu_stage/runtime.tgz为30995B小包，包含编译库/元数据/原入口代码，restore_cpu_dw9.sh从已安装原参数恢复；restore_screen_overlay.sh在旧camera setup后恢复屏幕软件及九层入口。同启动安装恢复已运行，fresh冷启动恢复完整链仍PENDING。此前默认ort和浮点误差描述为历史候选，不能与本次固定shape九层证据混写。

## 2026-10-07 可选CPU原float32 DW图内算子（整混合链BOARD通过）

14:36验收：原入口显式neon在两组真实16帧的最终128维features及固定点时序logits零差；同一组两对交换顺序整推理7457.108→7246.816ms（中位，2.820%）。新增语义CPU DW计32，无硬件调用数或ABI变化。新真实相机窗口与DSI发布成功，用户确认屏幕正常；原ORT同输入回放最终零差。原整浮点尾部1.132488e-5误差没有消失的证明，不能把最终量化边界验收写成全部浮点张量逐位保证。默认ort保持，显式候选neon可用；匹配bit/DTB实际恢复后模块空，capture0/display1。以下待验描述为14:17历史状态。

run_hard_soft_clip.py的--cpu-depthwise-library显式注册ORT C API16库；仅配套候选图中的sign_cpu::DepthwiseFloat14执行，输入float32 batch1/16,C576,H14,W14及原576×1×3×3权重/576偏置，保持nine-tap FMA→bias→Clip0..6，无MMIO或设备START。其余ONNX节点/initializer字节不变。CpuDepthwiseLayersExecuted计实际batch语义层数，report的actual_cpu_float_depthwise_layers报告增量；一次batch16尾部实测32。run_live_window.sh第三参数ort（默认）/neon选择既有或候选batch模型，第四参数可选同16保存张量；无第四参数仍原freeze采集。neon采用OMP_WAIT_POLICY=PASSIVE、内部2 CPU工作线程，调度仍一个进程串行。单层实测字节精确，整CPU尾部已有1.132488e-5浮点差，整混合特征和收益未验，不切默认。没有新NPU ABI、DMA布局或完成/释放规则变更。

串口临时init=/bin/bash故障修复：h1_serial_command的ChildShell显式选项用shell单引号编码复合命令，父set +e，子sh可自行set -eu，打印BOARD_CHILD_RC。不得再给PID1父shell裸set -e；原CLI默认行为保持，后续本任务复合操作使用ChildShell。用户已冷恢复到正常Linux；此前alignreset三窗是历史成功证据，不等于本次冷启动后的PL身份。

## 2026-10-07 原实时入口freeze-copy与对齐DSI结果BOARD

alignreset当前BOARD边界：临时JTAG及匹配DTB启动、GPIO释放、固定结果和三个原入口真实16帧窗口已运行。用户固定图确认“不分块”，最终更新确认“正常”；show --update成功保持同一0b800000独立no-map帧，不改地址、不复位或释放读DMA。每次采集结束才发布，16复制0拒绝，网络设备按guard PASS卸载，下窗新实例。screen_result.json实测16470/15230/15280ms，仍是内存发布终点而非光学时间。第一窗同输入CPU特征字节精确/logits零差。当前capture0/display1/modules空，显示保留区维持所有权至启动；无待物理恢复。历史scanfix四象限失败保留，不能与本次已通过alignreset混用。后续段落中的NOT_YET描述为此次BOARD之前的历史状态。

最新显示边界：scanfix BIT实际读回帧精确并开启display1，用户报告四象限互换。新dsi_scan_start在ui域锁存实际HP1读数据到达，双级同步至scan域，在原S_24b_vsync上升沿开放FIFO消费scan_de，未到边界前送黑像素、不重置AXI；模型/采集布局不变。SIM三启用相位九帧通过、旧接法首帧不足完整像素复现；alignreset SYNTH/P&R/STA/BIT完成，setup+.102/hold+.024ns、TNS0、coverage63.50%，实体对齐NOT_YET。针对实际reset counter recovery，复用fdma_frame_reset_sync将PS reset在camera S_clk本地两级释放，仅改变demo reset_gen的I_rst，PLL.reset原接法不变；counter recovery保持计时、违例已消失。新的camera_reset_sync首级异步输入按本route报告约束，后级和全部数据仍计时。show_dsi_result新增显式--update仅原位替换独立no-map缓冲，不改变地址、不释放/复位读DMA；可能短暂撕裂、尚未BOARD更新。run_live_window.sh第二参数dsi接发布，screen_result.json的window_through_screen_publish_ms包括模块装载/采集/推理/渲染/拷贝，/proc/uptime精度10ms，终点为内存读回与使能、不是实体屏光学时间。默认off保持旧入口。

当前修正：主入口默认保存384×216预览，可用--capture-full-snapshots恢复全图；缩略仅发生在16张原224归一化张量形成之后。sign_result_display优先展示capture_through_classification_ms，包含采集/预检/模型初始化/推理。首版DSI uidbuf R_SYNC默认1而I_R_sync=0，显示未启用；新builder及scanfix源码显式R_SYNC=0复用原演示自由运行语义。scanfix P&R进行中，首版BIT/STA不证明修正版屏显。当前板已匹配DSI DTB临时Linux运行，独立显示槽与enable0保持，真实输入网络通过。

run_hard_soft_clip --capture-fdma新增--capture-copy-policy freeze/continuous，默认freeze；旧capture函数独立调用仍默认continuous，显式--freeze-copy采用新路径。当前uidbuf只在S_IDLE检查enable，关闭不截断已接收帧；确认write_active=0、raw_busy=0、AW=B连续两次后复制，再保留before/after代数、epoch和fault检查，下一帧在复制后恢复使能。500ms无法完成时不自动复位/重复提交，关闭未来帧使能、保留reservation。新会话排除使能前已有completed sequence，避免重复采集旧帧。该完成判据针对本候选，不称通用DMA drain。

Pillow raw解码颜色/ROI/stride、原bilinear/均值方差保持逐字节；PNG无损level1在关闭采集后保存。报告分别记录sampling_ms、copy/decode/preprocess/snapshot/freeze_wait耗时、copy_attempts/rejected及capture_policy。三个原实时入口LIVE_IMX415_FIXED_WINDOW通过，3.33～3.44秒采样不称8FPS；capture_through_classification_ms包括预检/保存、模型初始化及推理。

DSI候选实际bank为FST1 ABI10003加90000160 display_enable；fresh builder1.4仍非本bit。camera_dsi_result_resume.bit与camera_dsi_reserved_80mhz.dtb匹配：capture三槽24MiB原布局不变，独立显示0b800000..0bbfffff no-map，1024×600×4=2457600B。HP1读写最多16拍，显示reset0；resume当时显示未运行，后续scanfix内容已见但四块错位，alignreset待BOARD。不可用camera-only bit启动显示。实际34管脚/STA报告见sol_camera_dsi_result_20261006/resume_*；首同步级例外按物理接收net判定，即使slice名字沿用secondary_addr_o/RVALID也不豁免后级或数据路径。

## 2026-10-06 真实采集接口BOARD，独立DSI结果接口候选

90000100 FST1 ABI10003已实际读回；该bank共用dw16_resetn，必须沿现release_dw16_reset.py先释放GPIO bank2 bit0，不能先GP ID读再释放。实际GPIO0→1、ID46535431/version10003、capture enable0；CSI/ISP当前连续增长。真实一帧及16帧before/after代数检查通过，capture结束enable0、AW/B相等。128D整链对同CPU特征/logits零差，Hard/共享PL按既有guard成功卸载。

新增DSI独立候选只接现HP1 FDMA read侧、uidbuf固定1024×600/stride1024/slot0与原扫描TX。reserved-memory/dsi_result@b800000为4MiB no-map；画面2457600B小端B,G,R,0。90000160独立读使能reset0，先capture结束、写入并读回完整画面，最后使能；当前show_dsi_result只发布一张固定图，启用后不允许覆盖仍被扫描的缓冲，保留至下次启动。当前编译candidate为capture ABI1.3兼容扩展，fresh builder输出1.4，capture兼容四版；不混用未编译版本。当前SYNTH/P&R中，实体屏NOT_RUN；采集专用bit不能运行此显示入口。

## 原DSI对照通过与受控采集候选（2026-10-06）

原FDMA三个0a000000/0a800000/0b000000槽常开写读，原bit只在无Linux的原SDK裸机组合运行。原ELF在实际cache-clean交接后重新加载，main命中/明确resume，用户确认清晰实时画面；不是Linux可直接使用的采集驱动。原SDK cache clean/invalidate、SCTLR M/C/I关闭及ELF readback证据见sol_original_dsi_debug_20261006/board/cache_clean_retry。

新sol_dsi_camera_pw32_20261006保留当前PS/HP0网络及80MHz，共享GP新增90000100 FST1 ABI10003：原status偏移00..34；40为capture enable（reset0，写0/1）；44..5c为现有flags/CSI/ISP/AW/B/RX/valid probes。HP1复用已移除Soft DMA连线，FDMA最多16拍；原最终B写响应完成判据、帧代数和缓冲生命周期保持。显示reader禁用。匹配camera_reserved_80mhz.dtb预留0a000000..0b7ffffff no-map并禁用Soft平台节点，其它PS/网络节点保持。新增bank仿真/综合已通过，P&R中、BIT/BOARD PENDING，不把该候选称已采到帧。

原camera PLL真实参考输入100MHz、output0=50MHz、cam24和约70MHz完整保留，不沿用先前“50MHz参考输入”的推测；原CSI管脚保留。原PLL/启动时序只是历史待验证假设。运行入口--capture-status-offset 0x100，独立采集--status-offset 0x100；capture关闭AW/B零值正常，config_done非全部IIC写成功，历史IIC告警按当前CSI/ISP增长判定。下一Linux必须先装受控bit和保留DTB，再采一帧。

## 共享PW32候选（2026-10-06，完整16帧BOARD通过）

pointwise34_row_core新增MAC_LANES默认16、独立候选32，只改内部通道组/缓存/并行MAC及尾组有效通道。原S30 ties-even、40bit累加、残差和模型张量保持；144扩张末组16及24投影边界正确。BLOCK34 ABI60001、GP/DDR布局/467560B net_pl.ko、最终B完成保持，原MAC16六层AXI周期保持。候选bit SHA482fe992763b0935f2d655514137a6c491b98391c69350cf4416cd4cd37ec7ce，80MHz、无Soft、OC16 V4R保持，不加载Soft驱动；仅既有block3＋4几何，不宣称C576。

首图25088B精确/device66.199ms，原16帧三个成功窗口features字节精确/direct logits0差。现Hard构造要求fresh model instance：前一窗口成功后guard PASS卸载Hard，下窗新加载实例；仅重复进程会在初始化拒绝。本次拒绝无START，按已有成功卸载流程后通过，不修改门槛或真实超时固定DMA/物理恢复规则。全部模块正常卸载，证据experiments/sol_shared_pw32_soc_20261006/board_verification.json。该较快profile用CPU direct时序，既有C128硬件显式后端保持。

## 固定16 CPU前段批量选项（2026-10-06，原16保存帧BOARD通过）

run_hard_soft_clip.py新增--spatial-batch16-models；run_block3_clip.sh第9参数可选模型目录。仅匹配hardware/fused FRONT96/pl34且无新block12量化时启用。CPU三个前段固定batch16，原节点/权重/精度保持；CPU批量→16次串行FRONT96→CPU批量→16次串行BLOCK34→CPU批量，随后按原次序执行Hard/DW16/CPU Add及尾部。复用原设备ID/ABI/驱动；缓存PL输出必须copy，避免复用缓冲覆盖。主入口total_ms是真实wall clock，CPU批量阶段分摊至帧的值不是逐帧延迟。原不传参数路径保持。两新窗口features字节精确、direct logits0差，含初始化小幅收益1.182%，证据experiments/sol_cpu_batch16_fix_20261006/verification.json。

NEON转换仅AArch64且显式FDMA_ENABLE_NEON_CODEC启用，默认保持原U8及NumPy signed16路径；旧库缺新symbol时兼容。实际边界精确但整链无收益，不启用默认。

## 2026-10-06 当前BOARD：OC16/BLOCK34及CPU Add无Soft profile

本节覆盖下列候选的旧未BOARD状态。OC16/BLOCK34 bit SHAa7dc341b41d5d5e9356dff516ab84fbb287221a7f295c6ded531080e72b8a287，匹配net_pl.ko 467560B，BLOCK34 ABI60001、C128 ABI20001、FRONT96 ABI50001、DW16 ABI10001保持。真实首图BLOCK34完整25088B零差；OC16预算0/32完整49152B金样及分类证书精确，三个原完整16帧窗口零差。

无Soft CPU Add profile bit SHA5df15706ef4acc86912f51263a0b79f751101e4696095f215845bb8e18599524使用同共享PL驱动/地址/布局和80MHz时钟；只移除Soft运算，旧Soft AXI-Lite端点读写返回DECERR（读CPAD 43504144），HP1 AW/W/AR valid与IRQ为0。不加载Soft驱动，不把DECERR返回当运算成功；AW/W任意先后及B/R背压已SIM，主链不访问此端点。独立bit原16帧BOARD精确，实际CPU H6 Add16次、Soft0。H6沿原M/S、zero、舍入、饱和，不改为S30 ties-even。Soft回退bit保持。

--temporal-backend fixed-cpu使用同一scalar固定TCN的现有精确回退计算，全三层CPU direct，不调用TCN/C128设备，预算0/近似层空；预算32 V4R及Hard前缀后端保留。固定形状1×16×128、有效mask、真实层数和耗时仍报告，不把精确logits与预算32 logits不同写为错误或零差。原run_block3_clip.sh第8参数fixed-cpu（第7参数cpu指定Add），完整16帧两次BOARD通过：features逐字节相同，logits对原direct参考精确/在V4R证书内；实际Hard空间160、CPU Add16、TCN/C128 START0。固定CPU入口前置初始化与硬件入口串行切换初始化的位置不同，比较全路径须计input_preparation＋initialization＋total，不能把temporal_initialization再加一次。DMA完成/守卫/生命周期/实际故障物理恢复规则保持。

## C128 OC16区间复用候选（2026-10-06，SIM/SYNTH，未BOARD）

V4R_OUTPUT_GROUP=16只改变内部输出通道工作集；T16/C128/O128/K3/dilation4、input2048B、parameter49664B、output49152B、预算64bit和输出三元INT64 center/lower/upper布局保持。GP/驱动ABI20001不变，C128结果含义与原候选兼容；同一任务完成后外部仍取得全部2048结果。

内部发出次序为输出通道组→时间→组内通道，DMA仍严格检查该预期索引，并写到原时间→全通道的全局偏移；保持64字节基址、4KiB拆分、最终B后完成。残差cache读统计由2048变16384是实际重读，不是ABI错误；原执行器按真实计数报告，不假定值固定。默认参数128保留旧顺序及回归结果。OC16为当前固定支持profile，不代表任意分组支持。

原预算0/32真实输出/证书和完整DMA仿真精确；完整SoC综合157 ERAM，最终时序/bit/板测PENDING。CPU精确回退和分类区间处理未改，不用存储压缩宣称实际提速。原入口--soft-backend cpu复用H6真实整数运算，不打开Soft设备；当前bit仍含Soft，软件切换不等于删除IP或释放其74 ERAM。必要驱动/地址/缓冲生命周期检查保持。

## BLOCK34连续六层候选（2026-10-01，完整AXI/SYNTH通过，未BOARD）

匹配BLOCK34=1 bit只替换原owner3空间块，其余FRONT96/DW16/C128及PS/Soft关系保留。GP0x90000080 ID424c4b34，0x84 ABI60001，0x88状态，0x8c输入，0x90六层参数基址，0x94输出，0x98 START/读shape2090381c，0x9c周期。0xa0/0xa4仍分别为第3块DW/投影参数，0xa8/0xac为两独立451584B scratch；第4块参数从基址偏移31488/54528/59136，全部64字节对齐。

NET_BLOCK34_RUN=_IOWR('C',1,net_pl_job)，56B结构，设备/dev/block34，拒绝与旧BLOCK3 ABI40001混用。输入UINT8[1,24,56,56]75264B、参数64256B、用户物理输出28672B，解包32×28行、每行32字节的前28字节得到UINT8[1,32,28,28]25088B。尾4字节固定0。

输出coherent DMA实际分配有效区75264B，先保存第3块C24；第4块扩张完整读取后才可覆盖其前28672B。守卫检查从75264B有效区末开始，不能误把仍留有中间张量的区域当尾守卫。参数DMA扩为64256B，其余缓冲保持；输入/参数CRC、完整缓冲守卫、最终AXI B后完成、单mutex及真实失败后固定缓冲/物理恢复保留。真实全六阶段AXI/SYNTH通过，匹配驱动目标编译，尚无BIT/BOARD。

## FRONT96固定融合候选（2026-10-01，完整16帧BOARD通过）

在匹配FRONT96=1隔离bit中，NET_PL owner2替换旧DW96；其余DW16、BLOCK3、C128及HP0/Soft HP1时钟关系保留。0x90000060读ID46573936、0x64读ABI50001、0x68状态0空闲/1忙/2完成/4故障；0x6c/0x70/0x74分别为输入/参数/输出32位coherent DMA地址，0x78写1 START、读00107070形状，0x7c周期。地址64字节对齐，最终B响应接受后才能完成。

输入signed16[1,16,112,112]401408B；参数PW96×160＋DW96×32=18432B；输出UINT8[1,96,56,56]301056B。NET_FRONT96_RUN=_IOWR('F',1,net_pl_job)，结构56B/ABI50001，设备/dev/front96；旧DW96 ID44573936/ABI30001仍对应/dev/dw96，不允许跨版本调用。驱动分配相应大小的独立DMA，保留CRC、64B守卫、单mutex串行和实际超时固定缓冲/物理恢复规则。

固定六组16输出通道，三行分布式缓存，无完整PW中间DDR张量。product不重复CPU金样；validate真实独立PW→DW参考比较，CPU核验时间与实际ioctl时间分列。真实首图BOARD零差/device44.079ms；原16帧product融合16次、features/logits对同候选CPU零差，总8441.524494ms。P&R/最终STA/BIT通过，bit SHA224f66e4172ed26d7d7e58d9562fe4bd68900a3850e7990c50c7767b6d65feae；GP probe前先执行已通过GPIO bit0释放，不能跳过。证据experiments/sol_front96_fused_20261001/board/verification.json。此候选仍为固定形状混合网络，不代表全空间硬件或相机链通过。

## DW16固定深度卷积候选（2026-09-30，BIT/待实际运行）

网络专用候选以GP 0x90000000替换旧TCON；必须读ID 0x44573136和ABI 0x00010001，不可混用旧TCON/FST1。GP与HP0沿原p2f_clk0 80MHz，Soft继续HP1。加载DW驱动前必须释放继承的HP0 UI复位：GPIO0xf8411000 bank2 data+0x200 bit0置1、保留其它位并读回；本次漏做使GP读取挂起，冷恢复后释放0→1即probe和18次DW作业通过。已有release_dw16_reset.py，仅按匹配bit启动使用。

| 偏移 | 含义 |
| --- | --- |
| 0x00/0x04 | 只读ID/ABI |
| 0x08 | pending bit0、done bit1、fault bit2；成功为2 |
| 0x0c/0x10/0x14 | 输入/参数/输出DMA地址，须64字节对齐；在pending时不可修改 |
| 0x18 | 写1启动；读固定形状0x03c00707 |
| 0x1c | 完成作业的设备周期计数 |

固定NCHW UINT8 1×960×7×7，输入/输出各47040B；960个32B参数记录，每个为9权重字节、3保留、INT32 bias、UINT32 multiplier、12保留。当前参数input_zero=0、weight_zero=128、output_zero=0、shift30，signed ties-even并裁剪0～255。AXI在4KiB边界拆分，最终B响应后才done。

/dev/dw16的RUN ABI结构56B，命令_IOWR('W',1,struct dw16_job)，用户仅提供虚拟指针；驱动分配3个存活coherent DMA缓冲，前64字节/尾PAGE_ALIGN守卫。成功可串行复用并卸载；timeout/fault/完整性异常保留模块和缓冲，必须物理恢复。allow_run默认false。DTB在已资格Soft80MHz临时树仅新增/soc/dw16@90000000；不声明dma-coherent、不改PS/Soft属性。见implementation_pl/depthwise/driver及network_n2_dw16_soc_4k_20260930构建证据；尚未BOARD START。

## FST1采集零帧定位ABI10002（2026-09-30，本地BIT）

ABI10002保留ABI10001原0x00～0x34状态、0x40使能及DMA行为，仅加合法对齐32位只读0x44 flags（低8位ui_resetn/PLL/配置延迟完成/相机配置完成/AE配置完成/ISP ready/FDMA raw busy/write fault）、0x48 CSI帧起始灰码低16位、0x4c ISP帧起始灰码低16位、0x50 AXI AW握手数、0x54 B握手数。0x38/0x3c仍非法；曾误读导致SIGBUS。tools/video/read_capture_probe.py仅读合法偏移且要求使能0，记录1秒变化。此版有BIT及STA，无BOARD；实际CSI/ISP帧数UNKNOWN。

## T01产品/验证模式ABI（2026-09-29）

后续BOARD：匹配48350001/1000b模块的product16帧已完成64 Hard/16 Soft，oracle0；特征和logits与既有validate精确。Hard正常卸载，Soft结束固定仍要求冷恢复。见experiments/product_20260929_T01_cold2/verification.json，不能混用旧ABI或把本次正确输出视为任意故障热恢复。

H5当前源码ABI48350001：Job.reserved=0为validate，expected_crc为独立金样；reserved=1为product，expected_crc字段须零且无金样语义，OUTPUT后用户按真实字节计算CRC，RELEASE与设备实际输出CRC比较。实际内容/守卫、地址/范围、输出已导出、IRQ/work和安全释放门槛保留。旧ABI48350000模块只作历史资格，不能以零CRC绕过旧释放。

Soft串行当前源码ABI1000b：PREPARE.request_flags=1固定product会话，0为validate，返回flags回显；product不计算live_golden，完成与跨作业复用仍检查原输入/packet、全部守卫/严格IRQ/无late及空闲态。GET_RESULT.output_matches在product为0（未比较），timing_reserved=1明确模式；客户端不把0写成金样通过。product只取输出缓冲、不逐层落盘；失败保留诊断取回与固定状态。旧1000a二进制保留，禁止混用。两新模块目标编译通过，首次Hard空闲拒绝、尚无Soft product START证据。

## 采集＋Soft候选（2026-09-29，BIT非BOARD）

run_hard_soft_clip --capture-fdma与--frames/--frames-dir互斥，必须明确--capture-pixel-bytes BGRX/RGBX及--capture-roi X Y W H。先完成capture、关闭未来帧使能并载入私有16×3×224×224，再打开NPU执行器；不将循环复用槽交给推理。成功报告scope LIVE_IMX415_FIXED_WINDOW，capture元数据和capture_through_classification_ms单列；不会把固定窗口写成多窗口连续产品。实际相机分支仅CODED/板端CLI加载通过。

FST1位于0x90000000，ID46535431/ABI10001；0x40 byte0写0/1控制未来帧，reset默认0，不能当DMA排空。复用原Soft/HP1，视频HP0三槽0x0a000000起每槽8MiB，1920×1080×4/stride7680；新启动DTB必须保留24MiB/no-map。状态完成须全部AXI写响应接受，fault固定；版本/epoch/槽generation在复制ROI前后核验。capture_model_clip默认16完整不同帧、主机目标8FPS采样，复制后训练预处理并输出NPY供原链，尚无实际采集BOARD证据。读回仍ENABLE_READBACK=0，不能写成屏显可用。

板端Pillow10.4/NumPy现已实际加载，保存PNG预处理与PC字节相同；结果渲染需Droid中文＋显式DejaVu数字字体，sign_result_display --latin-font及clip --display-latin-font已实现。独立板端PNG路径通过，clip新增字体参数尚未在板端整链重跑。PNG不是实体屏幕。

## 连续Hard＋Soft空间入口资格（2026-09-29）

可选--display-font使用明确中文字体，在已写出clip_result.json后生成result.png；图片输入时预览真实末帧。sign_result_display也可读取已有实际报告独立生成指定尺寸PNG，默认1024×600。仅Pillow文件渲染，无/dev/fb/MMIO写入，屏幕实际接入与分辨率仍待现场确认；结果画面明确保存片段和拒识未校准。显示渲染不计入已有total_ms，不能混作屏幕端到端时间。

run_hard_soft_clip硬件模式同进程16帧BOARD通过：H5 ABI48350000每帧四作业完成/RELEASE；Soft ABI1000a/dev/softnpu_h6_serial一次PREPARE，同三20KiB DMA连续16 SET_INPUTS/RUN，generation1～16，严格SUCCESS/IRQ4/无late/原缓冲与守卫核验后才接下一帧。64 Hard释放、16 Soft完成；会话结束Soft仍固定、请求物理恢复，不称热释放或多窗口连续运行已验证。实际NPU每帧H5 Conv及H6 Add，其余CPU。

入口新增互斥--frames（严格16×3×224×224 normalized raw/NPY）或--frames-dir（严格16个按名字排序图像文件）。可配--raw-layout读取明确width/height/stride_bytes/pixel_bytes/roi_xywh/slot_bytes的.raw文件，复用frame_input/训练RGB预处理；该路径需model_pipeline/src与Pillow，并只用于已保存完整帧，不主动访问FDMA寄存器或推定采集完成。input_preparation_ms单独记录、不混入既有total_ms。PC真实PNG输入和冻结板测张量精确；未上板运行该新增图片解码选项。

真实V4R选项已接此次实际16×128，同实际特征另接两层Hard TCN也通过；V4R仍CPU、证书范围精确定点。实时采集/显示/拒识仍未验证。

## 当前Hard/Soft图片入口的TCN/V4R选项（2026-09-29）

run_hard_soft_clip增加--temporal-backend onnx（默认）/pointwise-cpu/v4r-batched-cpu。onnx的--temporal-model为原temporal_head.onnx；其余为既有grid7模型目录；V4R另需--tcn-assets及可选--v4r-native-library、--v4r-budget-code（显式V4R默认32）。复用固定16×128/C128实现，V4R仍CPU，证书仍精确定点而非原浮点/RTL。新空间保存特征的CPU及两层Hard前缀已BOARD通过；完整连续Hard＋Soft图片入口未START，不能将保存特征分类当连续空间验收。

H5成功释放/卸载后，旧TCN模块在当前Soft临时PL/DTB环境加载、2作业释放并卸载0；旧Soft仍固定，原三缓冲经运行字节未变。本阶段没有修改驱动/解锁Soft或声称排空/热释放。

## 两层空间固定候选（2026-09-29）

spatial_factory与单图/16帧CLI增加显式dual-fixed-cpu、cpu-dual-fixed，需要新两层模型目录及--h10-assets指向14份冻结包目录；旧backend/default保持。CPU前段[1,160,7,7]→H7输入scale0.3371888995/zp154→NPU[1,960,7,7]→真实浮点depthwise/投影→H10原量化[1,320,7,7]→NPU[1,1280,7,7]→128维。解量化输出scale0.0235294122/zp0。其余CPU层明确报告。

设备/dev/spatial_dual_fixed当前ABI0x48470101，14模型一次加载；包904/权重自有51200、输入自有15680、输出7840B。H7前7840输入/25600权重是原内容，剩余已拥有的逻辑区零填充，packet原形状不改。DMA包4096/输入16384/权重53248/输出8192，输入层内六片或八片共享、只在模型编号6/0时释放。组内完成后reserved[3]保留input-live位，编号循环14；所有既有DMA/内容全文/守卫/IRQ/work/失败固定保留。旧ABI0x48470100每片释放版本只作历史，新客户端明确要求101；相同模型资产可复用，两种驱动ABI不得混用。

单图实际通过，三次同实例单图通过；两层16帧backend仅CODED，未实测。程序关闭句柄，不自动装卸、复位或重试。量化特征与原浮点有差异，不声称全图NPU或稳定加速。

## 真实非零预算V4R入口（2026-09-29）

run_temporal_features.py显式backend v4r-batched-cpu或v4r-batched-hardnpu-prefix，需要7×7模型目录、--tcn-assets及--v4r-budget-code；可选--v4r-native-library加载纯CPU共享库。BatchedV4RTemporalSequence处理固定16×128，默认仅末层V4R，前两层精确定点CPU或实际NPU。所有V4R结算均CPU，actual_v4r_hardware=false；非零预算类别区间不确认时执行精确定点CPU回退，不用于设备失败恢复。证书范围仅已资格标量定点模型，不是原浮点模型/RTL证明或拒识校准。

硬件前缀复用ABI0x54430107三模型与完成/DMA保护，无新寄存器映射。当前CLI一次分类执行模型0/1，两次RELEASE后停在下一模型2空闲；已实际成功卸载，不重复提交新序列或称连续调度通过。执行器关闭文件句柄，不自动卸载/复位/重试。纯C核没有MMIO/DMA或线程。

## 真实三层TCN产品资格接口（2026-09-29）

PointwiseTemporalSequence仅支持固定4×4/7×7两种实验网格；7×7每通道前16位置存真实因果展开token，余下33位置零点128，输出只提取前16。三层C384→O128真实NPU，CPU残差/激活/池化/分类；所有实际输入/输出在板后独立整数资格验收通过，非仅CRC证明。

tcn_grid7_fixed ABI0x54430107/dev/tcn_grid7_fixed，三包各776B/权重49152B预加载一次，SET_INPUT18816B每层一次、OUTPUT6272B、RELEASE实际CRC。DMA包4096/输入20480/权重53248/输出8192B；独立地址32位合法/存活。H10_FIXED_MODEL_COUNT默认8保留原H10行为，TCN指定3；H10_FIXED_INPUT_PER_JOB仅TCN，释放每层输入后保留下一模型编号，第三层后回0。冻结内容加载及完成校验、输入全文/全部守卫前检、IRQ/work及失败固定仍有效。

run_temporal_features --backend pointwise-hardnpu-fixed要求--temporal-model为7×7模型目录和--tcn-assets为冻结3包目录，使用已加载正确模块；不自动装卸、复位或失败回退。空间已保存float32[1,16,128]/bool mask直接接入，运行28～29ms（诊断保存/CPU残差包含），不是全图NPU、时序加速收益或V4R硬件。

## 真实TCN点卷积候选接口（2026-09-29）

PointwiseTemporalSequence接float32[1,16,128]/bool mask，三层因果tap展开UINT8[1,384,4,4]，每层输出UINT8[1,128,4,4]，标量输入/权重/输出scale；CPU执行残差/ReLU/池化及训练3类分类。pointwise-cpu已接图片序列主链。V4R未运行；不能以该接口代替专利硬件验证。

tcn_pointwise独立ABI0x54430000、/dev/tcn_pointwise，复用诊断提交/状态/成功释放/失败固定。有效包776、输入6144、权重49152、输出2048B；对应DMA分配4096/8192/53248/4096B。与H10不能同时绑定同一NPU。真实首层START完成，但数值不匹配（仅前16通道精确）；没有三层硬件分类。候选用户执行器以实际输出连CPU残差/下一层，不以金样替代输出，失败立即停止，不自动装卸或重试。

## 固定模型H10产品接口（2026-09-28）

最新串行模块dfc9d4使用4KiB包分配（904B有效/3192B守卫），旧诊断宏仍16KiB；共享头与产品contract wrapper均定义H10_FIXED_MODEL，实际分配和验证一致。模型加载时完整核对，冻结模型不在每次START前重复memcmp，但每次完成后仍完整比对；实际输入和全部守卫START前仍检查。寄存器/IRQ跨作业复用，释放后IRQ禁用并同步，下次START前重新初始化completion；成功卸载才解除IRQ/映射及释放DMA，失败不自动恢复。

run_temporal_features.py读取已有float32[1,16,128]/bool[1,16]，只执行onnx/int8-cpu/v4r-zero-cpu/v4r-int8-cpu，不重算图像或触设备。真实NPU特征接板端INT8及完整C128 V4R reference通过，35.563ms/59.183s；时序仍CPU，输入来自NPU不代表TCN也由硬件执行。

cpu-h10-fixed-model使用独立ABI0x48400100和/dev/h10_fixed_model；不能将诊断ABI0x48400000模块混入。LOAD_MODEL固定八个904B包/51200B权重，冻结FNV核验/合法coherent地址/持久RAM内容快照；SET_INPUT固定15680B实际UINT8输入及存活CPU快照，输入结构旧hash/expected字段须0，不以预期金样作为设备启动条件。八次RUN按固定片号0..7；实际输出CRC通过用户字节校验后RELEASE，以实际CRC和IRQ/work/guard判据释放；每帧输入只复制一次。失败仍固定DMA，不自动重试。模型只加载一次，后续帧复用存活DMA资源，冷态status reserved[3]为model_ready bit0/input_active bit1/片号bit8+。

数值验收独立读取归档原始输入/输出，在PC执行INT64参考；CRC/内容守卫不能代替数值正确。单图及真实16帧均已独立通过，真实特征和TCN结果与诊断版相同。H10Spatial接口仍[1,320,7,7]UINT8→[1,1280,7,7]UINT8→CPU尾部128float32，实际NPU仅H10。加载时间是初始化，单图472.268ms、16帧8.248s仍非实时系统/端到端加速完成。

## 当前板测通过的产品接口（2026-09-28）

共享CPU前段→H10Executor→CPU尾部已真实BOARD产出128维；每帧8片现有h10_multishard ABI，原始输出先验算再交尾部，仅H10一层NPU。h10_serial_client native ARM64编译通过，单图及真实16帧128START成功完成/释放并卸载。精确BLAS验算保留独立INT64参考及失败固定措施；单图916.274ms，当前比纯CPU慢。具体数值误差和范围见PROJECT_STATUS最新顶部。

run_spatial_sequence支持--normalized-video为固定little-endian float32[16,3,224,224]，与图像目录互斥；已有真实0020预处理张量复用，输出真实混合float32[1,16,128]交训练TCN及bool mask。实际板端CPU TCN分类咳嗽、同特征PC logits一致，非C4演示。原始输入载入/初始化不计入18.659s推理时间；尚无摄像头/实体屏幕/V4R硬件通过。下文“未编译/运行”属于历史阶段，被本次通过证据替代。

## 真实TCN INT8/C4软件映射接口（2026-09-28）

pointwise_temporal_tensors(q,w,dilation)将有符号INT8[16,128]按因果tap坐标展开成[1,384,4,4]，权重[128,128,3]按(channel,tap)同序展平[128,384,1,1]。prepare_real_tcn_pointwise保存signed张量及+128的UINT8输入/权重、INT64 bias和逐输出scale；真实16×128三层完整算术精确。尚无厂家包、4×4板证或逐通道requant硬件适配，不作为NPU可提交载荷。

Int8TemporalSequence从训练集校准目录calibration.json/weights.npz加载固定三层输入scale、逐输出权重scale/INT8权重和INT64偏置，真实输入float32[1,16,128]及bool mask。卷积INT8，跨组累加INT64后偏置只加一次，再解量化进入CPU浮点激活/残差/池化/分类。v4r-int8-cpu模式对因果填充后的序列按dilation相位降采样，转换为既有V4R-1整数reference支持的C4/K3/VALID/T<=32，32通道组求和组成128输出；一个完整片段28672参考任务。实际软件已匹配，未访问V4R寄存器、无新RTL/BOARD，批量多通道/非零预算收益未完成。

## 真实TCN的V4R CPU接口（2026-09-28）

V4RTemporalSequence接受同一float32[1,16,128]与bool[1,16]有效mask，加载SHA d452b0f...de0dc训练导出；内部FLOAT64固定块4、128输入/输出通道、K3/dilation1/2/4，按因果pad坐标分配块贡献，偏置加一次，完整残差/激活/mask池化/分类。零预算全部残差结算，区间仅浮点数值检查，不是INT64硬件误差证书；CPU_V4R_ZERO_BUDGET_FLOAT返回3类logits和工作量。序列入口--temporal-backend v4r-zero-cpu可选，默认onnx。此软件接口不是V4R-1 C4 INT8 ABI，不访问0x90000000或任何设备，未RTL/硬件/性能收益。

## 当前浮点空间/真实16帧TCN接口（2026-09-28）

默认模型切换到正确训练浮点空间图：CPU前段float32[1,320,7,7]按现有H10 scale0.1773609519/zp130量化为UINT8，八片输出拼为UINT8[1,1280,7,7]，按scale0.0235294122/zp0解量化交原浮点尾部，输出float32[1,128]。只H10候选硬件，其余34普通Conv/17depthwise/10Add及投影CPU。旧诊断量化/H11接口保留为历史，不能作为当前产品默认。

spatial_factory被图片与run_spatial_sequence.py复用；序列入口从按文件名排序的至少16张真实图像均匀抽16帧，交TemporalSequence的float32[1,16,128]及bool[1,16]有效mask，输出3类logits/置信度。当前CPU_TCN，拒识NOT_CALIBRATED，V4R未运行。固定单进程串行；cpu默认、h10-fixed-cpu为数学预测、cpu-h10显式实际硬件候选（每帧8START，未执行）。设备错误停止，不自动重试或卸载。

## 当前单图片最小混合接口（2026-09-28）

runtime/h10_spatial.py：CPU prefix接标准float32[1,3,224,224]，输出UINT8[1,320,7,7]给现有H10模块；八片各UINT8[1,160,7,7]拼接为[1,1280,7,7]，交既有H11 tail，得到float32[1,128]。只有H10候选硬件，其它34普通Conv、17depthwise、10Add及尾部CPU。H10Executor返回必须来自客户端原始output，oracle只验收；错误传播，无自动回退/复位。h10_serial_client.c复用原ABI/载荷/成功释放/失败固定路径，动态目录携带packet/weight/input/expected/output。未目标编译或运行；当前CPU固定预测与原CPU最终特征存在max_abs约0.05差，未识别质量验收。此实现不调用通用所有权账本。


## 所有权账本接口（2026-09-28）

runtime/tensor_ownership.py单线程frame-local策略：begin预约输入/输出，依赖必须完成；complete_cpu仅CPU ticket，release须所有消费者完成、读预约空、外部所有权解除；fail停止全帧并固定所有在途tensor。DEVICE无完成接口，不能CPU完成/凭IRQ释放；图输入/常量不在激活账本，未接真实buffer或DMA。初始化核实际依赖和完整消费者声明，独立frame/nonce拒绝旧票据。374源图节点仅状态流通过，不是算子数学/驱动完成/排空。见HARDNPU_TENSOR_OWNERSHIP_HOST_20260928.md。


## 全图静态张量交接和所有权（2026-09-28）

当前graph-contracts-static-v2以源SHA锁定374节点，66动态Q/DQ合同scale/zero dtype及原始字节精确；10残差分支发生在float32 DQ输出。78分片模型输入输出tensor、shape、scale/zp精确绑定原图，仍CPU输入/未厂家packet/未指派ABI。304激活语义要求必须消费者全部完成且设备访问结束才考虑回收，提交不等于完成，最终spatial_feature[1,128]float32须外部释放。原图last_consumer只是静态提示，不是融合后DMA排空或实际内存管理。详见HARDNPU_GRAPH_HANDOFF_CONTRACTS_STATIC_20260928.md。


## 普通层输入取块API（2026-09-28）

pw_tensor_extract从完整NCHW UINT8张量取指定空间/通道region，调用方提供独立buffer；大小/范围/溢出先核，错误不改变目标。新增API仅CPU字节布局，不定义量化转换/DMA/设备ABI；原insert/complete函数未改。严格主机编译及编译后静态核对已做，但运行被WinError4551拒绝，尚无360输入取块结果；上一轮拼接运行不能证明新增extract。Linux/ARM编译及真实上游张量仍待核验。


## 普通层CPU张量布局API（2026-09-28）

common/pointwise_tensor_layout.c/h只定义NCHW UINT8字节布局：shape(C,H,W)、region(c0,y0,x0,C,H,W)，精确长度/边界/乘法溢出及逐元素覆盖检查；pw_tensor_insert先核全区域重叠，错误不改输出/覆盖，pw_tensor_complete要求全元素覆盖1。调用方保证三个buffer互不重叠、覆盖初始0；API无设备/分配/DMA，不改已有模块ABI。量化scale/zp匹配、上游输入裁剪及作业提交仍由未完成的上层合同负责。28层两帧实际C主机布局通过仅CPU证据，非新BOARD。见HARDNPU_POINTWISE_C_LAYOUT_STATIC_20260928.md。


## 真实普通1×1载荷静态合同（2026-09-28）

新pointwise_packet_contract.py核原始包、scalar DQ/Conv/Q模型、分包通道/偏置、几何、零点、写回长度、tile计数及倍率移位；fixed_output以INT64参考、实际输入累加须落在INT32内。H5/H10历史数据18组精确，不改变现有驱动ABI。H5分包各包权重相对偏移0且写回几何保留完整模型OC，多包调用方DMA重定位仍UNKNOWN；不能据静态拼接通过定义生产提交。Tile_order1/3分别使用直出/非直出4×1公式，其它顺序拒绝。78候选未捕获真实包。详见研究报告HARDNPU_POINTWISE_PACKET_STATIC_CONTRACT_20260928.md。


## 其余28普通层静态分区接口数据（2026-09-28）

源图52Conv中的35普通层，排除六个已有报告和H12后剩28个1×1；提取量化输入/权重/bias/scale/zp及两帧CPU输出。78子模型的360空间/通道作业均CPU裁拼精确、覆盖恰一次。源输入来自完整图CPU，不是上游硬件交接；预期仅CPU最近舍入，厂家实际packet倍率/移位未取得。拟用128KiB/64KiB/32KiB输入/权重/输出预算不是已验证DMA合同，不能使用H12T ABI0x48421000提交其它形状。通用生产ABI/驱动仍未实现。


## H12T整层用户调度源码边界（2026-09-28）

新增h12t_tile_layer.c，复用h12t_tile_client.h和同一ABI0x48421000，单帧64作业；共享h12t_tile_layout.c从每块32×16×16裁剪[1:15,1:15]，按8×8 ID放回32×112×112。全部64位seen、全字节匹配才保存整层输出，任一设备失败停止、无自动卸载。首块和整层程序共用原成功/固定故障合同。实际C拼接主机双帧通过，仅CODED/CPU静态边界，完整Linux用户编译与BOARD未运行。详见H12整层静态报告。


## H12T对齐空间块候选接口（2026-09-28）

h12t_tile新ABI0x48421000，不与原h12_stem ABI0x48420000混用。逻辑packet392/input3072/weight864/output8192B，分配16384/8192/4096/12288B；单冻结载荷与权重，默认START关闭、IRQ1/work5及失败固定合同保持。32×16×16输出须取空间[1:15,1:15]，64块才拼成32×112×112；历史初版用户程序只准备两帧首块，后续整层调度源码已CODED（见上节），未目标构建/BOARD。小块厂家软件/包/主机算术已核。


## H12首层诊断接口边界（2026-09-28）

独立h12_stem ABI0x48420000，单包392B/input150528/weight864/output401408B；分配16384/151552/4096/405504B。沿用冻结身份、guard、IRQ1/work5完成和故障固定DMA合同。第0帧START超时，现场work3/IRQ0，未成功释放；不是可用首层驱动。64小空间块halo方案仅CPU等价通过、无新硬件证据。详见H12超时报告。


## 2026-09-28 H10与H11已验证的文件交接

H10双帧八片真实输出 `[1,1280,7,7]` UINT8/62720B逐字节匹配定点预期，成功释放和卸载后，板端CPU H11消费真实拼接文件并产生 `[1,128]` float32/512B。浮点跨平台验收采用atol1e-6/rtol1e-5，原始向量误差2.98e-7/3.58e-7；不称逐字节相同。该文件接口未建立生产张量队列、DMA共享、零拷贝或实时预算；H11未使用Hard/SoftNPU。

## 2026-09-28 H11尾部候选张量边界

H10八片通道拼接为 `[1,1280,7,7]` UINT8/62720B；H11 CPU候选子图接收同格式，经过原QDQ池化/Flatten/MatMul/BatchNormalization/Relu，输出 `[1,128]` float32/512B。仅电脑CPU完整图逐字节一致性通过，当前两帧H10来源为定点预测，未验证板端消费/DMA同步/生产队列。见H11尾部准备报告。

## 2026-09-28 H10诊断ABI与拒绝态（当前最新）

H10独立ABI `0x48400000` 用片号0～7绑定904B packet和51200B权重，输入15680B、每片输出7840B；四块coherent分配16384/16384/53248/8192B。首轮运行尝试在提交前空闲检查拒绝，writes0、reason14、复位前work2/末次work3；固定DMA待物理冷恢复，不提供失败释放。默认关闭拒绝和卸载守卫已板证，但无H10 START或输出。见H10拒绝报告。

## 2026-09-27 H8/H9文件交接和诊断ABI（当前最新）

H7硬件输出 `[1,960,7,7]`、47040B 以私有文件交H8板端CPU depthwise，H8输出同形状作为H9输入。H9 `h9_segment` ABI `0x48390000` 接收片号0～4，各片520B真实厂家packet、61440B权重、47040B输入并产生3136B输出；五片按通道序拼接成 `[1,320,7,7]`、15680B。packet/input/weight/output coherent分配分别16384/49152/65536/8192B。START默认禁止，成功路径必须通过完成态、CRC/守卫、用户态逐字节金样后释放回冷态；两帧10次已通过。失败仍固定DMA等物理冷恢复，没有生产队列、零拷贝、实时预算或事务排空保证。见 `docs/research/HARDNPU_H9_POINTWISE_BOARD_20260927.md`。

## 2026-09-27 H7六片诊断ABI（当前最新）

`h7_multishard` ABI`0x48370000`以片号0～5绑定冻结904B厂家packet、25600B权重及7840B动态输入FNV64；各片7840B输出由用户态按通道序拼接为47040B。四块coherent DMA缓冲沿用H4已实测的16384/8192/28672/8192B合同，START默认禁止、武装后每次8笔提交，完成态和CRC/守卫/逐字节预期均通过才RELEASE。两帧12次同实例板证通过。故障仍固定模块与DMA待冷恢复，生产张量队列/异常事务排空/实时预算尚未建立。见 `docs/research/HARDNPU_H7_SIX_SHARD_BOARD_20260927.md`。

## 2026-09-27 H5到残差的文件交接（当前最新）

H5四段板输出按通道顺序拼接为`[1,160,7,7]` UINT8/7840B，再作为第16块残差Add的右输入。左输入为第15块跳连`[1,160,7,7]` UINT8/7840B，当前由完整图CPU捕获；两路各经原QDQ缩放后Add并重新量化。两帧在板卡CPU上的结果与电脑端逐字节一致。这个接口目前依赖私有文件，未建立DMA共享、同步或视频帧时限合同。见 `docs/research/HARDNPU_H6_RESIDUAL_HANDOFF_20260927.md`。

## 2026-09-27 H5四段诊断ABI（当前最新）

`h5_segment` ABI `0x48350000` 的`SET_JOB`只接受段号0～3、各段真实packet/权重冻结FNV64和47040B输入FNV64，输出逻辑长度为2352/2352/2352/784B。每段从同一组coherent DMA缓冲起点提交，packet字数114/114/114/82，八笔写的最后一笔为START；默认关闭。OUTPUT导出原始字节，成功路径须与板前预期逐字节相同，RELEASE复核CRC/守卫及16次空闲读后清空四缓冲回冷态。当前板4/4段顺序通过、最终卸载守卫PASS。失败路径固定模块和缓冲，物理冷恢复前不得释放；真正事务排空仍`UNKNOWN`。见 `docs/research/HARDNPU_H5_POINTWISE_BOARD_20260927.md`。

## 2026-09-27 H4六片同模块诊断ABI（当前最新）

`h4_multishard` ABI `0x48340300` 的 `SET_JOB` 只接受片号0～5与已封存对应packet/权重FNV64，并核7840B输入FNV64；在冷态将三份载荷装入同一组coherent DMA缓冲。RUN默认禁止、显式武装后提交；OUTPUT后由用户态逐字节核板前预期，RELEASE重查完成态/CRC/守卫/空闲，清空四缓冲并回冷态。单实例两帧×六片12次板证通过，输出拼接47040B与旧完整H4层定点预期一致。该ABI仍为诊断协议，未覆盖完整图生产张量流、失败事务排空或视频实时预算。见 `docs/research/HARDNPU_H4_MULTISHARD_TWO_FRAME_BOARD_20260927.md`。

## 2026-09-27 H4第0片可复用诊断ABI（当前最新）

独立 `h4r_reuse` 诊断模块使用 ABI `0x48340260`，新增 `SET_INPUT` 接收7840B用户输入、FNV64和本帧预期CRC32；仅冷态可设置。每次RUN完成后以IRQ1/work5、CRC、输出守卫和板前逐字节金样为释放门槛；RELEASE再确认空闲，重置输入/输出缓冲及状态，以同一模块实例接受下一帧。当前板第一帧和第二张真实帧的第0片连续通过，模块卸载守卫PASS。packet/权重仍冻结第0片，不能接收其它五片或充当通用视频ABI；失败保持DMA固定，真正超时排空未知。见 `docs/research/HARDNPU_H4_REUSE_TWO_FRAME_BOARD_20260927.md`。

## 2026-09-27 H4第二张真实帧的输入输出身份（当前最新）

旧量化完整图在第二张测试帧上捕获本层UINT8输入 `[1,160,7,7]` 7840B，SHA `4fcc1cdb5c4899e42d8719d7912e7ed6ade204ba2e0672558569147894b3cc7c`。六片160通道板端输出各7840B，通过相同真实packet/权重计算后按输出通道序拼接成 `[1,960,7,7]` 47040B，SHA `02e7406bdb7e07b90df8c9b5c1c11acd9b145b94737f27b215d6098e9f7dd1ed`；与预封存的packet整数定点预期逐字节一致，相对ONNX CPU输出8875字节各低1。硬件接口仍为六个专用一次性模块，并未提供动态输入ioctl或可直接接SoftNPU的视频张量ABI。见 `docs/research/HARDNPU_H4_DYNAMIC_INPUT_BOARD_20260927.md`。

## 2026-09-27 H4 六片诊断执行接口（当前最新）

当前板六个160通道独立厂家packet各904B，经一次性模块的四块coherent DMA缓冲执行；模块默认禁START、显式武装后只允许一次8笔提交。每片完成态IRQ1/work5、输出7840B先在板端保存，再经串口归档、与预封存定点结果逐字节比较，随后显式成功释放与卸载。六片同上电顺序0～5已有三轮共18次通过，拼接47040B与完整层定点预期相同；另一次0→1在第1片停work3，故接口**无长期可靠重复执行和真正超时异常回收保证**。曾因同名输出文件 `O_EXCL` 使已完成作业的用户程序返回非0；仅导出工具从完成态另存、核验与释放后修正脚本先移走旧文件。作业间需重装分片专用模块且由电脑软件拼接，不是可供视频流调用的通用ABI。见 `docs/research/HARDNPU_H4_160_SHARD_BOARD_20260927.md`。

## 2026-09-27 H4 第0包运行接口与故障边界（当前最新）

独立一次性诊断模块对冻结第0包用四块coherent DMA缓冲提交8笔packet-DMA写；START默认关闭，武装后每个模块实例仅一次。三次板证均超时并固定模块/DMA缓冲，10秒现场 `Working_status=3`、IRQ状态0/IRQ31计数0，输出部分字节与独立定点金样一致。第三次故障固定态只读导出两份缓冲快照，不提供释放；物理断电后验证模块与易失目录清除。此接口**没有完成态、全层输出或异常事务排空保证**，不能当作通用HardNPU提交ABI。见 `docs/research/HARDNPU_H4_TILE0_TIMEOUT_BOARD_20260927.md`。

## 2026-09-27 H4 冻结载荷四缓冲接口（无启动）

当前板独立 H4 模块将三份各1544B packet 顺序放入16KiB coherent包池，将7840B输入和153600B权重分别装入8192/155648B coherent缓冲，输出49152B缓冲保持A5；文件长度与冻结FNV64在内核核验，传输前后 SHA-256 在电脑/板端核对。卸载逐段和尾部守卫 `PASS`；受控错误权重得到 `-EBADMSG`、`insmod` 失败且模块不残留。该接口仍无NPU MMIO/IRQ/START，不证明设备DMA或控制字段。见 `docs/research/HARDNPU_H4_PAYLOAD_STAGE_BOARD_20260927.md`。

## 2026-09-27 H4 四缓冲真实地址（无启动）

当前板独立诊断模块使用 `anlogic,hard_npu` 平台设备的 coherent DMA API，实际分配 packet/input/weight/output 基址 `0x17c6c000/0x17c70000/0x17cc0000/0x17ca0000`，长度16384/8192/155648/49152B。三段相对偏移按静态计划分别为 packet 0/1544/3088B、input全0、weight 0/51200/102400B、output 0/15680/31360B；全部子范围通过32位与不重叠核验。卸载守卫PASS并释放。该模块没有装填载荷、MMIO或 START；这些地址仅证明本次分配与CPU侧算术，不证明硬件接受非页对齐段起点。见 `docs/research/HARDNPU_H4_ALLOC_ONLY_BOARD_20260927.md`。

## 2026-09-27 H4 三段提交静态地址合同（当前最新）

同 SHA 厂家 `libarmnn.so.32.1` 静态代码：`r_HardNPUDriver` 装载阶段填 `pkg_info+0` packet 物理地址、`+16` 字数和 `+32` 权重地址；`Execute` 填 `+28` 输入和 `+36` 输出，逐段调用 DMA 提交并等待 IRQ。本 H4 夹具三段 packet 起点相对包池为0/1544/3088 B，权重相对基址0/51200/102400 B，输出相对基址0/15680/31360 B，输入均基址。该表由软件 packet 与反汇编推导，尚无厂家真实 `Execute` 或设备运行时值；真实缓冲基址、模式分支、控制字段、硬件对非页对齐分段地址的接受性均 `UNKNOWN`。具体静态审计见 `docs/research/HARDNPU_H4_VENDOR_SUBMIT_STATIC_AUDIT_20260927.md`。

## 2026-09-27 H4 三段Hard packet软件接口（当前最新）

厂家软件将第16块普通1×1 Conv `[1,160,7,7]`→`[1,960,7,7]` 分给`ALHardNPU/Alnpu`，虚拟CMA同步一块153600B权重、一块3840B bias和三段各1544B packet。每段13项中`0x0044`处包含320个不同bias字，三段合计960个，与源模型完全一致；末尾各含`0x1004=1`的启动项，**不能直接回放**。packet本身不证明三段实际设备提交的顺序、权重/输出地址偏移或完成态；模拟`0x56000000`地址不是物理DMA合同。H4 PC输出与H3输入逐字节相同仅是CPU层间张量身份。见`docs/research/HARDNPU_H4_LARGE_CONV_VENDOR_PACKET_20260927.md`。


## 2026-09-27 H3 depthwise 后端边界（历史阶段）

历史UINT8图第16块 `[1,960,7,7]`、3×3/group960 depthwise QDQ层的PC单层输出与完整图/独立NumPy一致；板端隔离厂家 parser 的权重/bias逐SHA匹配，但冻结 `Alnpu` Optimize 对 QAsymmU8 depthwise 明确拒绝，未生成可提交 packet。因此此层当前**没有 HardNPU 设备接口或 START 合同**；不能复用H2普通Conv的8笔写与缓冲身份。仅请求Alnpu的结果不决定CPU/Soft后端归属。见 `docs/research/HARDNPU_H3_DEPTHWISE_CPU_AND_VENDOR_BOUNDARY_20260927.md`。


## 2026-09-27 H2 单次真实执行接口边界（历史阶段）

独立 H2 一次性模块在 `anlogic,hard_npu` 平台设备上用四块 coherent DMA 缓冲提交冻结392B packet 和112896/4608B输入/权重；最后的 START 仅在显式 `allow_h2_start=1` 且空闲、内容与地址门槛通过后发生。当前板一次真实运行8笔写、IRQ1/work5、25088B输出CRC32 `0xa2c9574d`；输出与独立定点预测逐字节一致，保存后成功释放、卸载守卫 PASS。一次预 START work3 拒绝后保留缓冲、物理重启；冷态直接读 NPU 寄存器触发自动复位，不再使用该探针。此接口只为冻结 H2 诊断夹具，不是通用厂家 ABI 或任意模型提交入口。异常排空、共享DDR MPU保护、完整图层间张量和其它算子仍未验证。见 `docs/research/HARDNPU_H2_FIRST_START_BOARD_20260927.md`。

## 2026-09-27 H2 固定载荷无 START 访问边界（历史阶段）

当前板从封存文件逐 SHA 核对112896B输入与4608B权重后，诊断模块在 `probe` 中用 `kernel_read` 装入对应 coherent DMA 缓冲，核固定长度/FNV64；packet为冻结392B，输出保持 A5。卸载再核载荷和各尾部守卫；权重第1字节受控改变被 `-EBADMSG` 拒绝，修正后 `insmod` 非0且模块不残留。此仅为 **CPU 装填与内核 DMA API 分配**，没有设备 master 读写、DDR/MPU有效性、START或输出证据。冻结输入和权重身份及原始板证见 `docs/research/HARDNPU_H2_PAYLOAD_STAGE_BOARD_20260927.md`。

## 2026-09-27 H2 真实 coherent 分配边界（无 START）

当前板内核 `6.1.111-rt42` 上，独立 H2 分配诊断模块对 `anlogic,hard_npu` 平台设备设置32位 coherent DMA mask，分配 packet `0x17c6c000/16384`、input `0x17ca0000/114688`、weight `0x17c70000/8192`、output `0x17c78000/28672`；四块满足4KiB对齐、不重叠及32位合同。此阶段只把冻结392B packet 复制到 packet 缓冲，其余内容为 A5 守卫；卸载检查 `PASS` 并释放。后续固定载荷 CPU 装填见上节；设备缓存语义、MPU与DDR访问、输出仍 `UNKNOWN`。见 `docs/research/HARDNPU_H2_ALLOC_ONLY_BOARD_20260927.md`。

## 2026-09-27 H2 厂家软件 packet（虚拟地址，未映射真实设备）

冻结 Arm NN 库下，H2 单层被分配为 `ALHardNPU`/`Alnpu`，模拟设备 `LoadNetwork` 生成392B、13条寄存器条目的packet，SHA `e79c1f8adb3712dcd26fbadee21d6586fc7bbef552e000d13c5421f1a1544b40`。packet `Uint_scale=0x006b6a18` 对应乘数27498/右移24，bias32字与源图INT32常量相同；输入/输出112896/25088B。packet内 `0x56000000` 一带地址为 ptrace 合成 CMA 地址，不是可提交设备的物理地址。后续真实分配见上节；缓存同步、DDR保护、IRQ/完成态和真实输出仍 `UNKNOWN`；H1固定物理地址/CRC与缓冲尺寸不适用。证据详见 `docs/research/HARDNPU_H2_VIRTUAL_PACKET_20260927.md`。


## 2026-09-27 H2 诊断张量接口（PC 金样，尚非硬件 ABI）

H2 从历史 UINT8 空间图提取 `/backbone/backbone.4/conv/conv.2/Conv`：输入 `[1,144,28,28]` UINT8 112896B、权重 `[32,144,1,1]` UINT8 4608B、bias `[32]` INT32 128B、输出 `[1,32,28,28]` UINT8 25088B；group1、1×1、stride1、pad0。输入 scale/zp `0.0235294122248888/0`，输出 scale/zp `0.3137936592102051/133`。此节记录当时 PC 夹具阶段；后续厂家 packet 和真实分配见前两节，HardNPU 输出及舍入语义仍 `UNKNOWN`。不可将 H1 的 12544B 固定输出驱动接口套用到 H2。权威文件见 `docs/research/HARDNPU_H2_CPU_FIXTURE_20260927.md`。


## 2026-09-27 空间模型输入预处理身份

当前模型训练/回放的权威输入合同为`sign-rgb-preprocess-1`：Pillow RGB双线性直接缩放224×224、UINT8转FP32除255、ImageNet mean/std、NCHW。历史完整图PTQ使用OpenCV `INTER_LINEAR`，H1单层硬件夹具使用OpenCV letterbox/RGB/除255；三者不能共享输入/中间张量逐字金样。48帧同图OpenCV直缩与Pillow输入使FP32特征平均cosine仅0.817348；Pillow重校准PTQ仍不合格。设备接口接入前须把预处理合同及其哈希绑定到模型/packet/输入/输出报告，不得把H1诊断结果当产品视频流语义。详见 `docs/research/HARDNPU_SPATIAL_PREPROCESS_QUANT_CONTROL_20260927.md`。

## 2026-09-26 H1 双帧诊断串联实证

相同已核冻结packet/权重下，板端CPU oracle每帧生成新12544B预期，再由用户态在NPU START前绑定CRC、提交、读取真实输出并逐字节比较、调用成功释放；当前板两种输入顺序运行2/2通过。这条接口用CPU全量复算作诊断，不能直接当作目标视频生产接口或吞吐证明。源/板证据见 `docs/research/HARDNPU_H1_DYNAMIC_TWO_FRAME_BOARD_20260926.md`。

## 2026-09-26 H1 成功路径重复运行上限

当前冻结packet/权重及预先绑定输出CRC下，同一模块可在成功作业后经`REARM_SUCCESS`回COLD并重装填；两种输入交替十次的输出逐字节0差、每次释放和最终卸载通过。板端十次总作业段369ms，不含CPU oracle或流媒体处理。该限定证据不提供错误后AXI排空或DDR硬件隔离；见 `docs/research/HARDNPU_H1_TEN_JOB_REPEAT_BOARD_20260926.md`。

## 2026-09-26 H1 板端CPU预期与硬件绑定

纯CPU程序以同一冻结packet的bias与`Uint_scale=0x00611118`、冻结权重及本次输入生成12544B定点预期，用户态验证程序在真实START前把该预期CRC与输入CRC绑定给内核。当前板XOR55一份输入完成了CPU预期→绑定→硬件输出逐字节相同→成功释放链；XORAA也完成CPU预期与主机预期核对。CPU生成约15ms仅是两次算术段样本，不包含载荷输入、NPU运行、输出、相机或显示时延。接口仍限定本packet/权重与默认关闭诊断模式，详见 `docs/research/HARDNPU_H1_GENERIC_INPUT_ORACLE_BOARD_20260926.md`。

## 2026-09-26 H1 自定义输入的运行前预期绑定

UAPI 2增 `H1_STAGE_IOCTL_BIND_ORACLE`(0x1c)，调用方须先完成固定大小输入/权重staging、合法计划及模块所有权，并在COLD且显式诊断参数开启时提供当前输入CRC、冻结权重CRC和**运行前独立算得**的输出CRC。最终源码 `RUN_ONCE` 只接受冻结权重；未知输入若未绑定则在任何硬件激活前拒绝。`REARM_SUCCESS` 对已知两输入保留既有硬编码CRC规则，其他输入只接受运行前绑定的CRC、实际输出CRC和完成态/完整性/IRQ稳定门槛；成功清绑定并回COLD，异常仍固定DMA。两种新增输入及同实例重用的正向板证见 `docs/research/HARDNPU_H1_GENERIC_INPUT_ORACLE_BOARD_20260926.md`。调用方提供的预期CRC不是内核独立的模型正确性证明；DDR隔离/异常排空仍未知。

## 2026-09-26 H1 模型与板端结果的身份边界

冻结ONNX经模拟CMA下的厂家`LoadNetwork`生成130字/520B packet，与原独立厂家捕获逐字相同；该packet对应优化图唯一 `ALHardNPU` Conv，输入`[1,192,14,14]`、输出`[1,64,14,14]`。独立Linux驱动对原输入得到12544B输出，与该packet的定点预期逐字相同。两条执行链用冻结输入/权重/bias/packet和原始输出证据桥接，**未在真实厂家 `Execute` 中直接贯通**。接口参考 `docs/research/HARDNPU_H1_MODEL_TO_BOARD_BRIDGE_20260926.md`；仍不得把虚拟CMA地址用于真实DMA。

## 2026-09-26 H1 Linux 当前受控运行接口

当前UAPI 2的 `RUN_ONCE` 在四项装载参数 `allow_first_run=1 hardware_contract_confirmed=1 trust_boot_reset_release=1 allow_h1_with_ddrs1_disabled=1` 全部显式开启、其余门槛通过时，可在当前板DDRS1关闭基线(`CTRL=0x800`、区0`RASR=0x301`、其余区禁用)做诊断运行；默认不开启。`H1_STAGE_IOCTL_REARM_SUCCESS` 仅对已完成IRQ1/work5、8笔写、输入/权重/输出完整且CRC属于原/变体两组允许表的作业启用，之后要求当前IRQ0、工作状态稳定为idle0或done5、禁用并同步IRQ，再释放映射/资源和清空staging，回COLD。两组板测均成功；任何故障、超时、迟到IRQ或未列入的输出仍固定缓冲。该接口不声称DDRS1隔离或异常AXI排空；其它输入/权重/算子不能直接套用。见 `docs/research/HARDNPU_H1_LINUX_REPEAT_TWO_BOARD_20260926.md` 与 `docs/research/HARDNPU_H1_LINUX_VARIANT_AND_MIXED_BOARD_20260926.md`。

## 2026-09-26 H1 输出验收接口

纯用户态 `h1_first_run_verify` 新增 `--compare-fixed` 和 `--execute-fixed`。固定 packet 预期与 CPU/ONNX 金样分别报告；固定模式仅以前者的逐字节结果决定退出码。原 `--compare`/`--execute` 的严格 CPU 判据保留，内核 UAPI 和驱动未因本验收模式改变。`--execute-fixed` 仍受当前 DDRS1 固定拒绝门槛约束，尚无 Linux 设备运行证据。见 `docs/research/HARDNPU_H1_LINUX_DUAL_ORACLE_VERIFIER_20260926.md`。

## 2026-09-26 H1 Linux 激活候选门槛

当前Linux候选在可能的NPU写之前读TOP_ENABLE并保留原位按位或3；软复位后要求IRQ0、连续16次工作状态0、最终IRQ0，且第八笔START前再次检查IRQ/work双零。此对齐已进入目标机器码，但Linux `RUN_ONCE`仍由DDRS1 live policy固定拒绝；不能把构建成功等同设备接口通过。详见 `docs/research/HARDNPU_H1_LINUX_ACTIVATION_ALIGNMENT_20260926.md`。

## 2026-09-26 H1 双层输出判据

定点设备层独立预期由冻结输入/权重/bias、packet `Uint_scale=0x00611118`及夹具零点生成，不使用板端输出构造；本次预期与板端12544B完全一致。原CPU/ONNX金样为另一层语义验收，当前6267点差1。Linux驱动不得仅以IRQ或现有CPU金样单一CRC将两类证据混为一谈；需要分别报告packet匹配和模型误差。见 `docs/research/HARDNPU_H1_PACKET_FIXED_ORACLE_20260926.md`。

## 2026-09-26 H1 当前观测的定点量化接口

单次获准的U-Boot HardNPU作业完成IRQ1/work5。冻结packet的`Uint_scale@0x63f05040=0x00611118`，UG1215字段为16位`scale_data=0x6111`和8位`rshift=24`。本次12544字节输出逐点符合`clamp((acc*24849 >> 24)+119)`，其中`acc`由冻结1×1卷积输入/权重/bias独立计算。CPU/ONNX金样采用最近整数舍入，本次硬件相对金样有6267个字节低1。此为当前packet/夹具的观测合同，不可自动推广到其它量化参数或模型。见 `docs/research/HARDNPU_H1_FIRST_START_BOARD_20260926.md`。

## 2026-09-26 HardNPU 完成与异常回收边界

UG1215 对 `0x63f01014` 的 `work=5` 和 `0x63f01018` 的 IRQ bit0 给出作业完成语义；`work=4` 是等待写回。该手册仅把 `0x63f00000` 软复位描述为复位 NPU 寄存器状态，CRP NPU 复位和 XMON 计数也没有给出异常时在途 AXI 排空的可核条件。因此 H1 完成后按固定报告和输出逐字节验证，异常时保留 DDR 缓冲、不启动 Linux、物理断电恢复；不能把该接口直接推广为可重复的 Linux DMA 驱动。详见 `docs/research/HARDNPU_H1_AXIDRAIN_EVIDENCE_AUDIT_20260926.md`。

## 2026-09-26 H1 首算完成后的原始输出接口

当前武装报告结构由最终源码实际定义核得 `status@0x4`、`final_irq@0x9c`、`final_work@0xa0`。只在U-Boot收到一次作业的完成态`IRQ=1/work=5`且报告状态0或34时，才允许从固定输出DDR`0x22030000`只读12544字节并与冻结CPU金样逐字节比较；错误、超时或未配对完成应拒绝读取并物理恢复。该抓取工具已在首次真实作业状态34、IRQ1/work5下运行，取得完整原始输出；结果见 `docs/research/HARDNPU_H1_FIRST_START_BOARD_20260926.md`。

## 2026-09-26 H1 四页CPU控制映射与首算边界

冻结八笔 CPU 写寄存器偏移为`0x50/0x2000/0x2004/0x6000/0x3c/0x100c/0x1010/0x1000`，涉及NPU寄存器页0/1/2/6。当前U-Boot EL3精确四页临时映射往返板测通过；冻结四缓冲整合无START预检也通过。厂家packet内部含其它NPU寄存器地址，那是设备内部packet-DMA路径，不能把CPU四页映射误写成设备访问保证。TOP_ENABLE保留原位只置所需bits0/1，退出恢复原值。真实START、IRQ配对、设备DDR AXI及异常排空尚无板证。见 `docs/research/HARDNPU_H1_FOUR_PAGE_MAPPED_PREFLIGHT_20260926.md`。

## 2026-09-26 H1 U-Boot NPU 无启动控制面

当前板在EL3临时映射`0x63f00000/0x63f01000`两页、TOP_ENABLE置3且TOP_SRAM门控后，可读NPU `Working_status@0x1014=0`、`Interrupt_status@0x1018=0`；一次写软复位`0x63f00000=1`后bit0自清，复位后两状态仍0。测试恢复TOP和L2表项，未写START。该CPU控制通路不能外推为NPU主AXI/DDR/IRQ或算子安全。见 `docs/research/HARDNPU_H1_UBOOT_MMIO_READ_RESET_BOARD_20260926.md`。

## 2026-09-26 U-Boot EL3 NPU MMIO 映射边界

当前 BOOT.bin 的 U-Boot 在 EL3/MMU 开启时，`AT S1E3R/W(0x63f00000)` 均返回 `PAR_EL1=0x80d`（翻译故障状态6），而 TOP `0xf88001b8` 与 DDRS1 `0xf840f004` 翻译成功。NPU所在L2表项`0x3ffe28f8`为0；受限程序只映射`0x63f00000/0x63f01000`两页后读写翻译均成功，撤销后表项0、翻译重新失败。这证明临时CPU映射可往返，不证明寄存器响应、NPU主AXI或DDR保护。见 `docs/research/HARDNPU_H1_UBOOT_NPU_MMIO_TRANSLATION_20260926.md`。

## 2026-09-26 U-Boot EL3 H1 缓存/翻译接口

固定临时DDR布局：报告`0x21000000`、输入`0x22000000/40KiB`、权重`0x22010000/16KiB`、packet`0x22020000/16KiB`、输出`0x22030000/16KiB`。当前 U-Boot EL3对23页 `AT S1E3R/W` 均返回同页物理地址；CTR_EL0对应64B行，SCTLR_EL3 M/C/I开启。清输入/权重/packet至PoC并清失效输出、最终清报告的无启动程序板测通过。该接口是固定布局的CPU与缓存前置条件，不证明HardNPU总线看到相同地址、写回输出或完成中断。详见 `docs/research/HARDNPU_H1_UBOOT_CACHE_NOSTART_BOARD_20260926.md`。

## 2026-09-26 DDRS1 补集候选不得作为共享运行策略

当前 `h1_ddrs1_contract.c` 的缓冲外禁止区形状 `RASR=0x301/GROUPID=0x8` 已在 PL330 自有目的页试验中产生写故障，因而不能假定只针对NPU；RW0下的组选择性不适用于证明RW3安全。本轮 RW0/group0x20 的自有源页匹配也使 PL330复制故障，但未取得故障当时FTR7/PC，不能精确指定哪个数据读/写事务失败。驱动 RUN_ONCE继续固定拒绝；见 `docs/research/HARDNPU_H1_DDRS1_RW0_SOURCE_READ_AND_POLICY_REJECTION_20260926.md`。

## 2026-09-26 DDRS1 RW=0 组字段选择性

在当前板非安全PL330通道7、自有目的4KiB页、Region7 `RASR=0x001`、Region0临时禁用条件下，`GROUPID=0/0x8` 的64字节复制通过，`0x20/0xffffffff` 目的写故障。与前期四组都故障的 `RASR=0x301` 不同。成功路径XMON AWGID=5、SDK DMA_AXI候选位5与观察相容，但不能直接证明DDR S1比较极性或NPU主AXI路由。接口门槛继续保持 H1 RUN_ONCE 固定拒绝；见 `docs/research/HARDNPU_H1_DDRS1_GROUP_SELECTIVITY_RW0_BOARD_20260926.md`。

## 2026-09-26 DDRS1 Region 命中边界

在当前板、非安全PL330通道7的64字节自有缓冲写中，DDRS1全局使能而八区禁用、或区7只覆盖未被写入的独立guard页时均复制PASS。区7命中目的页、`GROUPID=0xffffffff/RW=0` 时，SECURE/PRIVILEGE四种组合均报同型写故障。这把失败收窄到启用区域的地址命中之后，但不能从单一故障码区分组比较、安全/特权sideband、RW实现或其它内部路径。XMON在成功复制时计得写GroupID=5，失败事务未同期计数；不能据此宣称HardNPU主设备组号。见 `docs/research/HARDNPU_H1_DDRS1_REGION_HIT_MATRIX_BOARD_20260926.md`。

## 2026-09-26 PL330 写通路 GroupID 计数

UG1215 的 XMON `SUBPARA_GRPID` AW min/max 与 `CNT_AWGID` 已在当前板的非安全 PL330 通道7、64字节自有缓冲复制中受控使用：DDRS1 MPU 关闭、两个监测点 DDR_S1/DMACX 对组号范围0..255和5..5均各计64、空闲窗口计0，复制无故障。此结果支持这条写通路的 AW GroupID=5；XMON 错误 `DEBUG_ID` 仍是 AXI ID，不以其替代 GroupID。它不证明 DDRS1 MPU Region 的其他安全/特权条件，也不证明 HardNPU 主设备组号或 DDR 路由。详见 `docs/research/HARDNPU_H1_XMON_PL330_GROUP5_BOARD_20260926.md`。

## 2026-09-26 DDR_S1 XMON 监视与 SECURE 对照

区7 `GROUPID=0xffffffff/RW=0` 条件下，SECURE bit6=0 (`RASR=0x001`) 和=1 (`0x041`) 的受控非安全 PL330 目的写都报 `FTR7=0x20000`、目的页未改变；单独改变 SECURE 不足以放行。后一次故障尚未重启时，XMON DDR_S1 `DEBUG_FLAGINFO=0x200100/DEBUG_ADDR_L=0x2757a000/DEBUG_ID=0x1d0`，DMACX `0x200100/0x2757a001/0x7`。UG1215 将 bit21 定义为写错误、DEBUG_ID 定义为 AXI 错误 ID，不定义为 MPU GROUPID；这些读值支持当前写路径到达 DDR_S1 监视点，不能独立定位 MPU 内部拒绝原因。TOP_NS `INTR_MPU_STATE=0`且该区中断未启用，也不能排除 MPU 违规。见 `docs/research/HARDNPU_H1_DDRS1_SECURE1_XMON_BOARD_20260926.md`。

## 2026-09-26 DDRS1 GROUPID 与 PL330 AXI 属性边界

UG1214 v1.3 支持 GROUPID 按主设备编号索引授权位图，但此前四次目的页规则均以 `RASR=0x301`（RW=3）拒绝读写，不能判定组选择。新对照设区7 `GROUPID=0xffffffff/RASR=0x001`（RW=0、SECURE/PRIVILEGE=0），仍使 PL330 的非安全目的写得到 `FTR7=0x20000`、目的页完整哨兵；故障后回滚、软件重启核验基线。微码 CCR=`0x00804201` 按 Arm DMA-330 手册配置目的 AWPROT[1:0]=`10`（非安全、非特权），尚无片上 sideband 波形。DDR S1 区域安全/特权位的精确极性、重叠优先级和实际主设备组号仍`UNKNOWN`，不能启用 HardNPU RUN_ONCE。UG1214 明确 `MPU_NPU=0xF841C000`保护其他主设备访问 NPU，不证明 NPU→DDR 通路独立隔离。见 `docs/research/HARDNPU_H1_DDRS1_GROUPID_MANUAL_RECONCILIATION_20260926.md` 与 `docs/research/HARDNPU_H1_DDRS1_ALL_GROUP_RW_OPEN_BOARD_20260926.md`。

## 2026-09-26 H1 超时后 IRQ 诊断语义

`h1_run_observe_irq()` 在 `TIMEOUT_PINNED` 接到首次非零 IRQ 时将原始 IRQ/工作状态保留到 `last_irq_status/last_work_status`，返回 `H1_IRQ_REJECTED`，不改变 phase、不完成作业、不释放 DMA 缓冲；后续迟到 IRQ 不覆盖第一次值。驱动 IRQ handler 清除硬件状态后调用该逻辑，`RUN_STATUS` 可读保留值。仅软件/默认装载验证，真实 IRQ 时序与 AXI 排空仍 `UNKNOWN`；见 `docs/research/HARDNPU_H1_LATE_IRQ_DIAGNOSTIC_20260926.md`。

## 2026-09-26 DDRS1 零组字段反例

同一 PL330 目的页拒绝条件下，区域 `GROUPID=0/0x1/0x8/0x20` 均产生 AXI 数据写错误；`RASR=0x301` 按 SDK 为 `NOREADWRITE`。0不是当前板上可直接当作“排除所有主设备”的安全值。此事实不证明 GROUPID 被忽略，也不证明 NPU与DMA_AXI同组；区域比较/路由仍`UNKNOWN`，H1 RUN_ONCE 固定拒绝保留。详见 `docs/research/HARDNPU_H1_DDRS1_GROUP0_COUNTEREXAMPLE_20260926.md`。

## 2026-09-26 U-Boot 临时 C 代码寄存器约束与 DDRS1 停机

当前 BOOT.bin 的 U-Boot 路径使用 AArch64 `x18` 访问全局数据；从 U-Boot `go` 调用的 freestanding C 必须用 `-ffixed-x18`，并对最终对象反汇编确认无 x18/w18。旧无提交程序占用 w18 并触发同型同步异常；修正后无写入预检正常返回。EL3 DDRS1 group0x8 显式写入对照在 `go` 后静默，阶段不明，复位后基线正常；该变体已封禁。静态 NPU/DMA_AXI 组号3/5仍不能解释 DDRS1 组比较，不能放行 H1 START。见 `docs/research/HARDNPU_H1_UBOOT_X18_AND_GROUP8_HANG_20260926.md`。

## 2026-09-26 U-Boot EL3 设备缓存接口实证

受限 PL330 见证使用代码`0x20000000`、报告`0x21000000`、源/目的/微码三个独立临时页`0x23000000/0x23001000/0x23002000`。EL3 `SCTLR=0x00c5383d`，CTR_EL0低值对应64B数据缓存行；`AT S1E3R`的PAR屏蔽属性后匹配三页物理地址。填页后源和微码使用 `dc cvac`，目的使用 `dc civac`；PL330非安全通道7停止/无故障后目的用 `dc ivac` 再逐字节比对。一次64B复制及尾部哨兵通过，DDRS1一直`0x800`。此方法是当前 U-Boot 配置与 PL330 的实证，不自动证明 NPU cache/AXI 合同。失败状态放结果页并正常返回，不能让非零 `go` 返回参与恢复；见 `docs/research/HARDNPU_H1_UBOOT_PL330_CACHE_WITNESS_20260926.md`。

## 2026-09-26 H1 U-Boot 无启动缓冲布局

受限 CPU 试验使用代码`0x20000000`、结果`0x21000000`、输入`0x22000000`（40KiB）、权重`0x22010000`（16KiB）、packet`0x22020000`（16KiB）、输出`0x22030000`（16KiB）。U-Boot FAT 实装输入37,632B、权重12,288B；程序核对冻结 CRC、130字 packet、三尾部及输出16KiB哨兵，调用 `h1_emit_packet_dma()` 但其回调仅把八个 offset/value 写入结果页。实测轨迹末项`0x1000=1`**没有**写到 NPU。当前 MMU/数据缓存开启，CPU一致性不证明设备 DMA 一致性。详见 `docs/research/HARDNPU_H1_UBOOT_NOSTART_STAGE_20260926.md`。

## 2026-09-26 U-Boot EL3 运行接口实测

当前 U-Boot 2021.01 可从 USB FAT 把168字节 AArch64 程序加载到临时 DDR `0x20000000`，`go` 执行并返回0。程序在 `0x21000000` 写结果：CurrentEL=`0xc`（EL3）、TOP_S NPU/DMA_AXI 组号3/5、DDRS1 CTRL=`0x800`、SCTLR_EL3=`0x00c5383d`，后者 M/C/I 均置位。未来 U-Boot DMA 实验须显式处理缓存、地址映射及异常后保留；这份预检没有 NPU START、MMIO 写、DDR 保护生效或 Linux 实时组号证据。详见 `docs/research/HARDNPU_H1_UBOOT_EL3_PREFLIGHT_20260926.md`。

## 2026-09-26 H1 软件门槛与 DDRS1 硬件证据

RUN_ONCE 的 DDRS1 寄存器形状比对之后现固定返回 `-EOPNOTSUPP`；只读 DDRS1_POLICY 仍可报告原始快照和软件匹配位。即使将来快照与候选完全相同，也不能从该位推出组过滤/主 AXI 安全。解除此门槛须以硅片组匹配和共享影响实证替换，见 `docs/research/HARDNPU_H1_DDRS1_GROUP_ROUTE_FAIL_CLOSED_20260926.md`。

## 2026-09-26 DDRS1 GROUPID 证据边界

板端区7目的页规则在 `GROUPID=0x20/0x8/0x1` 三个设置下均使 PL330 通道7得到 AXI 数据写错误且目的页未写；0x20规则放闲置页时复制通过。U-Boot 只读 NPU/DMA_AXI 组号为3/5，与手册默认一致，但 Linux 实时组路由和 DDRS1 比较方式未证。软件不得据 SDK 的 `MPU_GROUP_ID_NPU=0x8` 假定该策略只约束 NPU；见 `docs/research/HARDNPU_H1_DDRS1_GROUP8_COUNTEREXAMPLE_20260926.md`、`docs/research/HARDNPU_H1_DDRS1_GROUP1_COUNTEREXAMPLE_20260926.md`。

## 2026-09-26 DDRS1 DMA_AXI 实际保护路径

本次板端把 DDRS1 区7 `GROUPID=0x20/RASR=0x301/SAR=EAR=页号`，短时 CTRL=`0x801`。目标为自有闲置页时 PL330 64B复制通过；目标为本次 coherent 目的页时 PL330 通道7以 `FSRC=0x80/CS低状态0xf/FTR7=0x20000` 停止，目的整页未写。ARM PL330 FTC bit17为数据写入的AXI错误响应。两次 CTRL/八区恢复；故障模块固定缓冲后软件重启。后续只把 GROUPID 改成 NPU 候选0x8，PL330 目的页仍被拒绝，证明当前组选择解释有缺口；只能把目的页写入拒绝记为受限板测，不能推断组隔离或 NPU 路由。见 `docs/research/HARDNPU_H1_DDRS1_DMA_AXI_ALLOW_DENY_BOARD_20260926.md`、`docs/research/HARDNPU_H1_DDRS1_GROUP8_COUNTEREXAMPLE_20260926.md`。

## 2026-09-26 PL330 普通 DDR 实传接口

当前板非安全 PL330 manager DSR=`0x200`，一次通道7 `DMAGO ns=1` 的26字节程序完成64字节普通 DDR coherent→coherent 复制。程序以 DMAWMB 保证此前写完成，再 DMAEND；无 DMASEV，因 INTEN=0 的事件不能由 INTCLR 清除。CS7 最终 `0x00200000`：bit21 是 CNS，低状态位0才是停止；不能拿整个 CSR==0 判完成。两次实际提交的独立物理读证明数据复制，修正后模块自动验收通过并释放资源。DDRS1 CTRL 在 `0xF840F004` 事后仍`0x800`，此实传不证明 DDRS1 或 NPU AXI 路由。详见 `docs/research/HARDNPU_H1_PL330_64B_DDR_COPY_BOARD_20260926.md`。

## 2026-09-26 PL330 Linux 资源树接口

未绑定的 AMBA 设备 `f8419000.dma-controller` 在 `/proc/iomem` 中已有父范围；最小模块 `request_mem_region(0xf8419000,0x1000)` 在父级下申请子范围成功，卸载时 `release_mem_region` 后消失。这个通用资源接口不依赖历史 `struct amba_device` 布局，且本次未映射/访问 PL330；它不能保证固件/其它处理器不使用该硬件。真实 DMA 的申请需跨越完整传输与故障缓冲保留期。见 `docs/research/HARDNPU_H1_PL330_MMIO_CLAIM_BOARD_20260926.md`。

## 2026-09-26 PL330 DMAGO 安全态接口

ARM PL330 TRM 把 DSR bit9 定义为 manager DNS；板端 `DSR=0x200` 因而为非安全 manager。TRM 规定该 manager 的 `DMAGO ns=0` 不启动通道且设置 fault，`ns=1` 才能启动非安全通道。本地 SDK `DMA_Exec_DMAGO` 固定传0，故不能原样用于当前非安全实例。离线候选编码 `0xA2` 和 CCR 源/目的 NS 位已精确字节测试，后续26B无事件微码的普通DDR实传见上方新记录。SDK 全局 DeInit 会 kill 全通道，不能作为共享 Linux 控制器的实验清理。见 `docs/research/HARDNPU_H1_PL330_DMAGO_SECURITY_MISMATCH_20260926.md`。

## 2026-09-26 非安全 AXI DMA 只读接口边界

Linux 枚举的非安全 PL330 地址是 `0xF8419000`；SDK 裸机 DMA 默认安全实例 `0xF8418000`，二者不能混用。当前只读 DSR=`0x200`、DBGSTATUS=0、八通道 CSR=0、故障/事件寄存器=0、CR0=`0x001e3075`、CRDN=`0x00ff7f74`；SDK 字段解释为8通道、4外设、16事件、128位总线。`MPU_GROUP_ID_DMA_AXI=0x20` 是 DMA_AXI 候选组掩码，与 NPU 候选0x8不同；只读配置不证明任何 DDRS1 路由或访问隔离。裸机 HAL 有无界等待，Linux 侧后续实现必须独立约束通道所有权、轮询时限和故障后 DMA 内存生命周期。见 `docs/research/HARDNPU_H1_AXI_DMA_NONSECURE_READONLY_20260926.md`。

## 2026-09-26 运行内核 AMBA 结构偏移实证

当前同哈希 Image 的 `amba_device_alloc` 在偏移472/480写 AMBA 资源起止，偏移496写 flags；`amba_request_regions`从472读取。历史构建头文件的 `offsetof(struct amba_device,res)=480`，所以旧模块把实际 end 当 start。此为资源接口不兼容的局部直接证据，不能硬编码结构偏移或外推全部内核 ABI；见 `docs/research/HARDNPU_H1_PL330_LIVE_IMAGE_RESOURCE_OFFSETS_20260926.md`。

## 2026-09-26 PL330 AMBA 结构边界

板端历史内核树编译的 PL330 模块可加载，但读`struct amba_device.res`触发`invalid resource`；只读诊断按相同头文件读出资源 flags=0、periphid=0，与运行 sysfs 的`flags=0x200`、`AMBA_ID=00341330`矛盾。因此目标输出树对 AMBA 设备结构不兼容，不能以加载成功推断可安全控制 AXI DMA，也不能用直接偏移替代驱动资源接口。见 `docs/research/HARDNPU_H1_PL330_AMBA_ABI_MISMATCH_BOARD_20260926.md`。

## 2026-09-26 DDRS1 控制位短时使能实读

H1 ioctl 0x1a 在显式装载参数下，于关闭状态准备自有 DMA 一页的 region7 候选，短时写/读 CTRL=`0x801`，立即写回并读`0x800`，恢复八区。当前板一次执行与事后独立只读诊断均通过，NPU RUN_ONCE/START仍未调用。控制位读回不能证明 region 比较、未命中动作、group0x8路由或故障排空；见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_READBACK_BOARD_20260926.md`。

## 2026-09-26 H1 START 前状态接口

一次性提交的第8笔`0x1000=1`前，候选读取 HardNPU `0x1018` IRQ 状态和`0x1014`工作状态，分别要求0/0；非零置故障原因10、拒绝该笔 START 并固定 DMA。UG1215 将工作状态0定义为空闲，但新检查尚无真实硬件执行证据。`h1_stage_run_once`布局不变；厂家 bit2 与手册冲突及读后竞态继续存在。见 `docs/research/HARDNPU_H1_PRESTART_STALE_IRQ_GUARD_20260926.md`。

## 2026-09-26 H1 DDRS1 短时使能探针接口（未武装）

ABI 2 新增 ioctl 0x1a，需默认关闭的 `allow_ddrs1_enable_probe` 显式开启、`CAP_SYS_RAWIO`、COLD、当前严格八区基线和 Linux 资源独占。候选入口在 CTRL关闭时清 region0、用 region7 对本驱动一个DMA页设组0x8/RASR0x301，预定短时写 CTRL使能和关闭，再恢复原八区；失败时保持故障钉住。板端仅验证默认 `EPERM`、只读基线和卸载；**未调用使能入口**。寄存器可读写与未命中规则、NPU主 AXI保护生效不是同一证据；见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_PROBE_PREP_20260926.md`。

## 2026-09-26 H1 DDRS1 关闭状态八区事务

新增 UAPI 2 命令 `0x19`，需显式装载参数及 `CAP_SYS_RAWIO`/COLD/当前八区严格基线；从本次四 DMA 地址生成候选，独占 DDRS1 配置口，只写8区 RASR/SAR/EAR/GROUPID 并逐字段读回，再恢复原快照。板端一次候选/恢复均匹配、80次写、CTRL始终`0x800`，模块最终卸载。它不写 CTRL 或 NPU START，不证明全局使能后的保护作用；见 `docs/research/HARDNPU_H1_DDRS1_FULL_DISABLED_TRANSACTION_20260926.md`。

## 2026-09-26 DDRS1 关闭状态 APB 字段写入边界

板端独立模块仅在 `CTRL=0x800`、区0预置及区1–7全0的基线下，向未启用区7 SAR `0xF840F084` 写1/读1/恢复0/读0；最后 H1 驱动八区只读快照仍为原值。此为 APB 单字段可写和本次恢复证据，不涉及 CTRL、RASR/GROUPID、MPU 生效或 HardNPU START。见 `docs/research/HARDNPU_H1_DDRS1_DISABLED_WRITE_READBACK_20260926.md`。

## 2026-09-26 DDRS1 Linux 资源冲突实测

当前板测试模块只登记 `0xF840F000/0x100`，H1 `DDRS1_POLICY` 诊断返回 `-EBUSY`；解除登记后同一诊断成功，验证诊断入口的 Linux resource tree 互斥。RUN_ONCE 对应申请分支未运行，固件/其它处理器/raw MMIO 不在此机制内。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CONFLICT_BOARD_20260926.md`。

## 2026-09-25 H1 DDRS1 Linux 资源仲裁

RUN_ONCE 候选在策略读取前以 `request_mem_region(0xF840F000,0x100)` 申请 DDRS1 配置口，失败返回 `-EBUSY`；启动前错误释放，固定作业期间保留。只读 DDRS1_POLICY 诊断短暂申请同一区域后释放。板端正例通过，冲突反例未完成；该仲裁只覆盖遵守 Linux resource tree 的软件，不能证明固件、其它处理器或 raw MMIO 用户的所有权。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CLAIM_20260925.md`。

## 2026-09-25 H1 DDRS1 候选生成与组编号

`h1_ddrs1_build_candidate()` 仅由当前 `h1_dma_plan` 生成 CTRL=0x801 和八区候选值，`h1_ddrs1_validate_snapshot()` 逐字段比对同一生成值；均不执行 MMIO。UG1215 TOP_S 七个组编号与 SDK MPU GROUPID 七个掩码系统性对应 `1<<编号`，U-Boot 实读 NPU=3 支持候选 `0x8`。该关系尚无当前 Linux 事务路由/MPU 生效实证，不允许据此启用 DDRS1 或 START。见 `docs/research/HARDNPU_H1_GROUP_ROUTE_MAPPING_20260925.md`。

## 2026-09-25 U-Boot 实时 NPU group 与 DDRS1 状态

当前板 U-Boot 只读 `TOP_S GROUPID_NPU@0xF8806110=3`，同次 DDRS1 CTRL=`0x800`、区0=`0x301/0/0xffffffff/0`。SDK 给区域 GROUPID 的 NPU 值0x8，数字上等于 bit3，寄存器手册未直接说明编号到区域掩码的硬件比较规则；U-Boot 值也不等于 Linux 运行时可再次读回。FSBL 源码桥与完整结果见 `docs/research/HARDNPU_H1_FSBL_DDRS_SOURCE_BRIDGE_20260925.md`、`docs/research/HARDNPU_H1_UBOOT_DDRS_GROUP_READ_20260925.md`。不得凭数字对应启用 DDRS1 或放行 START。

## 2026-09-25 H1 只读 DDRS1_POLICY ioctl

UAPI 2 新增命令 `0x18`，需 `CAP_SYS_RAWIO`、COLD；只读返回四块当前 DMA 地址/容量、CTRL 前后、八区 RASR/SAR/EAR/GROUPID 和软件补集匹配位，不进入 RUN_ONCE。当前板实测 `CTRL=0x800`、match=0、COLD/零写。新命令没有配置 MPU 的能力，match 即便为1也不证明硅片路由或故障排空。见 `docs/research/HARDNPU_H1_DDRS1_DRIVER_LIVE_READ_20260925.md`。

## 2026-09-25 H1 DDRS1 策略形状验证边界

`RUN_ONCE` 以当前四块 coherent DMA 地址/完整分配长度构造 DDR 补集，仅只读比较 DDRS1 CTRL、8区 RASR/SAR/EAR/GROUPID；要求 `CTRL=0x801`，有效区依次为 SDK 编码的 4 KiB 起止页、`RASR=0x301`、`GROUPID=0x8`，多余区清零。该校验在任何 NPU/TOP 写入之前，当前板 `CTRL=0x800` 因而不满足。软件编码、实时读回和两次 CTRL 一致仍不足以证明硬件生效或资源独占；见 `docs/research/HARDNPU_H1_DDRS1_POLICY_MATCH_20260925.md`。

## 2026-09-25 DDRS0/1 第一区非复位快照

当前板固定只读实测 DDRS0/1 的 CTRL 与第一区四字段分别同为 `0x800`、`0x301/0/0xffffffff/0`；UG1215 所列 RASR/EAR 复位均为0。全局 ENABLE=0，预置来源 `UNKNOWN`，不能把第一区的全地址数值视为有效保护或可安全配置的证据。当前 TF 同哈希 BOOT 只证全局使能清除路径；见 `docs/research/HARDNPU_H1_DDRS0_DDRS1_PRESET_ORIGIN_20260925.md`。

## 2026-09-25 当前 DDRS1 控制寄存器只读状态

当前板固定 `O_RDONLY/PROT_READ` 探针实读 `MPU_DDRS1 CTRL@0xF840F004=0x00000800`：按 UG1215 bit15:8 为8区，bit0使能为0。CRP `SRST_CTRL1@0xF8801074=0x73f0` 的 DDR 总线和 NPU 复位释放位均为1；LOCK `CFG_LOCK1@0xF8807004=0`。TOP_S `GROUPID_NPU@0xF8806110` 触发受控只读故障，实时组编号未证。此读回不构成 DDRS1 配置/保护或 HardNPU 主 AXI 路由证明；接口边界见 `docs/research/HARDNPU_H1_BOARD_DDRS1_CTRL_READ_20260925.md`。

## 2026-09-24 H1 Optimize 的驱动依赖

冻结目标 `h1_armnn_probe` 未创建 runtime，采用仅列 Alnpu 的设备规格；即便如此，真实厂家 Optimize 阶段仍以 `O_RDWR` 打开 `/dev/hard_npu`，紧接着请求 `HARDNPU_IOCTL_GET_REGISTER_INFO=0x4801`。此为板端受监督的私有普通文件占位观察，不含真实设备信息。独立驱动 `/dev/h1_stage` 的候选 UAPI 与厂家 `0x4801` ABI 不同，不能用现有预检通过推断无桩 Optimize 可用。详见 `docs/research/HARDNPU_H1_NOSTUB_OPTIMIZE_DRIVER_BOUNDARY_20260924.md`。

同版库的 `RegisterTensorHandleFactories` 在 Hard 初始化后无条件紧接 Soft 初始化；两者分别读取 `0x4801/0x5301` 的地址/长度并申请 `PROT_READ|PROT_WRITE, MAP_SHARED`。本次运行只动态到达 Hard `0x4801`，Soft 为静态待验证路径。候选独立驱动不能开放该厂家宽泛共享寄存器映射作为便捷兼容层。

## 2026-09-24 H1 运行结果 ABI 2

`h1_stage_run_once` 增加 `failure_reason`，取值 `H1_FAILURE_*`：0无故障，1复位路径，2 CRP 复位仍保持，3 TOP 时钟读回，4 NPU 软复位超时，5旧 IRQ 清除失败，6寄存器提交，7异常 IRQ，8等待超时，9数据完整性。仅保留首个终止原因；`integrity_fail_mask` 继续给出详细破坏位。结构改变使 `H1_STAGE_ABI_VERSION=2`，模块和用户程序必须同版；旧程序在新版模块上预检拒绝。故障值只是候选软件诊断，硬件路径未验证。

## 2026-09-24 H1 提交与 IRQ 的候选先后

本地 UG1215 的 NPU `0x0000` bit0 是写高脉冲、自清；一次运行候选在时钟/SRAM激活后有限轮询其清零。IRQ 用 `IRQF_NO_AUTOEN` 登记，清旧状态后保持禁用；8笔 packet-DMA 写中最后的 `0x1000=1` 先提交，再使能已登记 IRQ。该顺序只经构建/无启动回归，真实快速完成事件是否保持为电平直至清除仍未实测。见 `docs/research/HARDNPU_H1_SOFT_RESET_IRQ_ARM_ORDER_20260924.md`。

## 2026-09-24 H1 权重 DMA 容量与尾部状态

冻结权重逻辑长度保持12,288字节，候选 coherent 分配增至16,384字节；后4,096字节为 `0xA5`，PLAN_TRACE/HOLD/RUN 前以及 DONE 后检查。`H1_INTEGRITY_WEIGHT_TAIL=0x20` 表示尾部写坏，RUN 结果追加 `weight_tail_clean`；新结构应只与同版 UAPI 头文件配用。packet `0x003C=0x0808` 是 AXI burst/outstanding 字段，不是访问地址上界。见 `docs/research/HARDNPU_H1_WEIGHT_GUARD_AXI_LIMIT_20260924.md`。

## 2026-09-24 H1 当前可选 reset 与实验模式

当前运行 NPU 节点的 `devm_reset_control_get_optional_shared` 实测返回 NULL。冻结公开驱动允许此条件下继续 TOP 时钟/SRAM 初始化，板端私有 reset 核心源码显示 `reset_control_reset(NULL)` 返回0；这不证明当前芯片复位释放。H1 候选新增 `trust_boot_reset_release` 默认0，显式为1且句柄缺失才不访问 FPGA manager 持有的 CRP 窗口；另两个启动参数和一次性门禁仍独立生效。该执行分支尚未运行，见 `docs/research/HARDNPU_H1_OPTIONAL_RESET_ROUTE_20260924.md`。

## 2026-09-24 H1 一次运行输出文件接口

`h1_first_run_verify --execute` 现在强制指定一个不存在的输出文件路径；程序在 RUN_ONCE 前以独占创建保留路径，只有 DONE 且 READ_OUTPUT 成功时写入12,544原始字节并同步，然后与 CPU 金样比较。失败清除本次不完整文件，已有文件绝不覆盖。目标仅验证默认禁止时拒绝和清理；真实保存分支未运行，见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。

## 2026-09-24 当前 CRP 窗口的互斥约束

实时 NPU 节点与当前 TF `system.dtb` 的 NPU 节点全属性一致，第三段 `0xF8801000/0x100` 覆盖在 FPGA manager 已持有的 `0xF8801000/0x1000` 内；`/proc/iomem` 也显示该持有。H1 一次运行候选必须在 CRP 映射前申请独占区，失败以 `-EBUSY` 拒绝，不绕过内核资源持有者。该运行分支只编译、未调用；完整复位/资源协同接口仍 `UNKNOWN`。见 `docs/research/HARDNPU_H1_BOOT_DTB_CRP_OWNER_GATE_20260924.md`。

## 2026-09-24 H1 固定金样的用户态验收约定

`h1_first_run_verify` 复用同版 `h1_stage_uapi.h`，默认预检只调用装载、PLAN_TRACE、HOLD/RELEASE、RUN_STATUS；该路径要求 COLD/零提交。未来明确选 `--execute` 才调用 RUN_ONCE 和 READ_OUTPUT，并要求 IRQ=1/work=5、8笔提交、零完整性掩码及全部尾部/源检查，然后对固定12,544字节 UINT8 金样作逐字节比较。本轮只执行预检，真实输出布局和量化等同性未验证。详见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。

## 2026-09-24 H1 完成状态与数据故障

候选在精确完成 IRQ 后、仍持有模块与 DMA 缓冲时核对 packet 前部/尾部、输入/权重 CRC、输入尾部和输出尾部；任一异常使 DONE_PINNED→FAULT_PINNED。`RUN_STATUS` 返回五类故障 bitmask，`READ_OUTPUT` 在完整性故障时拒绝。新 RUN 结果结构大小已调整，必须使用同版头文件；该阶段旧装载/诊断 ioctl 曾保持 ABI version1。目标只验证默认关闭路径及纯状态机转移，见 `docs/research/HARDNPU_H1_DONE_INTEGRITY_GUARD_20260924.md`。

## 2026-09-24 H1 一次运行候选 UAPI

原生 root 限定 `/dev/h1_stage` 增加 `RUN_ONCE`、`RUN_STATUS`、`READ_OUTPUT`；该阶段旧 ABI version1 的装载/诊断 ioctl 曾保持。`RUN_ONCE` 需要 `CAP_SYS_RAWIO` 和装载时两项默认0、0400的显式参数，还要求已持有模块引用及固定数据/计划通过。返回状态包含 phase、8笔尝试数、IRQ/work状态及输出/源/packet哨兵与CRC诊断；`READ_OUTPUT` 仅 DONE 且尾部哨兵完整时读取固定12544字节。DONE/FAULT/TIMEOUT 均固定缓冲与模块引用。目标仅验证默认拒绝及旧功能回归，未调用实际硬件路径，见 `docs/research/HARDNPU_H1_GATED_FIRST_RUN_CANDIDATE_20260924.md`。

## 2026-09-24 H1 复位资源版本差异

当前运行 DTB 的 NPU 节点没有 `resets`，第三段 `0xF8801000/0x100` 与 FPGA manager 已声明的 `0xF8801000/0x1000` 重叠；私有/公开 DTS 则使用 CRP reset phandle 且 NPU 仅两段资源。私有时钟复位源码把 NPU 映射到 CRP `+0x74` bit12、低电平断言；板上只读 `0xF8801074=0x73f0`。该源码未证明与运行 DTB 同版，当前不允许把 optional reset 当作有效控制或直接读改写重叠窗口。见 `docs/research/HARDNPU_H1_LIVE_RESET_BINDING_20260924.md`。

## 2026-09-24 H1 当前设备树资源

当前板端 `anlogic,hard_npu` 的三个大端 `reg` 项为 `0x63F00000/0x100000`、`0xF8800000/0x200`、`0xF8801000/0x100`；TOP 使能偏移 `0x1B8` 落在第二项内。`interrupts=<0 112 4>` 在运行内核解析为 IRQ 31。无启动候选仅严格核对前两段并解析中断号，未请求 IRQ、映射/写 MMIO。节点缺 `iommus/dma-ranges/dma-coherent`，父 `soc/dma-ranges` 为空；不据此宣称 AXI 可达性或 Cache 合同。见 `docs/research/HARDNPU_H1_LIVE_RESOURCE_GATE_20260924.md`。

## 2026-09-24 H1 一次性激活顺序

软件接口 `h1_run_submit_once` 现要求有效的激活回调；完整 DMA 计划通过后，先将状态置 STARTED 并固定四缓冲，再执行可能有副作用的时钟/复位激活，最后发送 8 笔 packet-DMA 命令。激活失败进入 FAULT_PINNED，零命令且不允许重试或释放。本接口尚未接真实 TOP/MMIO/IRQ，见 `docs/research/HARDNPU_H1_ACTIVATION_PIN_ORDER_20260924.md`。

## 2026-09-24 H1 顶层时钟控制实读

`CFG_CTRL_NPU@0xF88001B8` 的本地 UG1215 bit0/bit1 分别使能 NPU 功能与内部 RAM 时钟。当前板端只读实值0，故两项均未使能；公开驱动 probe 写3但本轮未执行。`0xF8800030` 实值0，不等于该偏移的 SRAM 电源语义已明确。TOP 实读不提供 HardNPU IP 修订或 IRQ bit2 身份。见 `docs/research/HARDNPU_H1_LIVE_TOP_CLOCK_READ_20260924.md`。

## 2026-09-24 H1 持续所有权接口

原生 64 位 root 限定 `/dev/h1_stage` 新增 `HOLD_OWNER/RELEASE_OWNER`：持有前复核 coherent 输入/权重 CRC、输出哨兵及 DMA 计划，再增加模块引用；释放仅限一次性状态机 COLD。用户进程退出后引用仍有效，板端实证普通卸载失败；另一个进程在无启动状态释放后卸载成功。它不是设备 START 或“DMA 已排空”声明。模块移除时若仍有引用或状态禁止释放，本驱动不调用 `dma_free_coherent`。见 `docs/research/HARDNPU_H1_PERSISTENT_OWNER_HOLD_20260924.md`。

## 2026-09-24 H1 模块引用与解绑合同

目标内核 `platform_remove()` 忽略旧式 `remove()` 的错误返回，因此不能用返回 `-EBUSY` 保护已提交作业。现有 H1 模块关闭 sysfs bind/unbind，板端验证这两个入口不存在；用户 FD 打开期间普通 `rmmod` 被引用计数拒绝。`h1_run_prepare()` 现要求调用方先持有模块引用，未来内核 START 实现仍须实际 `try_module_get()` 并在无法证明 AXI 排空时持续持有。当前没有 START、IRQ 或硬件作业，见 `docs/research/HARDNPU_H1_MODULE_LIFETIME_GUARD_20260924.md`。

## 2026-09-24 H1 实际 DMA 地址的诊断轨迹接口

限定原生 64 位 `/dev/h1_stage` 新增 `H1_STAGE_IOCTL_PLAN_TRACE`：两份固定载荷均装入且 CRC/输出哨兵通过时，内核用真实 coherent DMA 地址生成 8 笔 packet-DMA offset/value 并返回；未装载返回 `ENODATA`。它不执行任何寄存器写，也不暴露任意偏移访问。板端一次完整测试通过，见 `docs/research/HARDNPU_H1_BOARD_DMA_PLAN_TRACE_20260924.md`。返回结构末项 `0x1000=1` 是诊断数据，不可当作获准提交；当前 IP 修订与 DMA/IRQ 硬件行为未验。

## 2026-09-24 H1 一次性中断分类与缓冲隔离

冻结厂家 ioctl 结构体顺序与 ELF 分支复核后，候选仅接受 `intr_flag==1 && work_status==5`。`0x1018` bit1/bit2 错误位冲突不影响把其它非零值全部拒绝，但不解决错误清除和迟到 IRQ。纯软件 `h1_run_state` 在开始潜在设备写前转入不可释放状态，完成/故障/超时均不能重试或归还 DMA；尚未接硬件。当前 TF BOOT/脚本/DTB 哈希与 2026-09-14 备份一致，不能据此证明当前 bit/IP 来源。详见 `docs/research/HARDNPU_H1_ONESHOT_IRQ_AND_BOOT_AUDIT_20260924.md`。

## 2026-09-24 H1 IRQ 位语义冲突

UG1215 DR1M90 的 `0x1018` 文档为 bit0 完成、bit1 地址错误，`0x101C/0x1020` 同位清除/使能；但冻结厂家 `wait_for_hard_npu_irq` 在 `0x401d98` 检查 bit2，再要求中断字等于1和工作状态 `0x1014=5`。公开驱动只转发实读中断字。当前 bit/IP 身份未知，不能把文档或库单方面写成已验收硬件 ABI；见 `docs/research/HARDNPU_H1_IRQ_BIT_CONFLICT_20260924.md`。

## 2026-09-24 H1 固定数据装载 UAPI

当前仅供首算前诊断的原生 64 位 `/dev/h1_stage` 接受冻结 H1 输入 37,632 字节和权重 12,288 字节各一次，状态提供两块 coherent 目标缓冲的 CRC 与输出 16 KiB `0xA5` 哨兵是否完整。没有物理地址、任意寄存器、设备启动或 IRQ 接口。板端一次装载/卸载及错误 CRC/重复装载拒绝已验证，见 `docs/research/HARDNPU_H1_TARGET_PAYLOAD_STAGING_20260924.md`。这些数据尚未被 HardNPU 主 AXI 读取，不能据此放行提交。

## 2026-09-25 H1 RUN_ONCE 前的 DDRS1 CTRL 必要条件

独立 H1 候选在 RUN_ONCE 完成冻结载荷及四缓冲 DMA plan 检查后，以只读映射核对 DDRS1 CTRL 的 ENABLE=1、region 数=8；不满足则在 CRP 资源申请/IRQ 登记/NPU/TOP 写入前拒绝。当前板只读值 `0x800`，因而不具备该必要条件。此门槛不配置或验证八区 RASR/SAR/EAR/GROUPID，也不证明 NPU 主 AXI 路由、共享影响、异常排空、当前 IP/IRQ 或复位合同。见 `docs/research/HARDNPU_H1_DDRS1_LIVE_GATE_20260925.md`。

## 2026-09-24 H1 四缓冲分配候选边界

`h1_alloc_probe` 仅把固定 H1 的 packet/input/weight/output 四块 coherent 缓冲接到 `anlogic,hard_npu` 平台设备，并限定首段资源为 `0x63f00000/0x100000`、DMA mask 为 32 位；使用此前纯 C 合同校验地址和长度。板端一次加载分配/校验成功、一次卸载恢复未绑定，但无设备 AXI 可达性证据。它不映射 MMIO、不申请 IRQ、不提供提交接口，不得把该结果解释为首算。见 `docs/research/HARDNPU_H1_ALLOCATION_MODULE_TARGET_BUILD_20260924.md`。

## 2026-09-24 H1 张量/packet 静态几何

冻结真实软件包的 `0x0004/0x000C/0x600C/0x6014` 与输入 37,632、权重 12,288、输出 12,544 字节相符；64 个 type-1 `0x0044` bias 字与原始小端 int32 完全相同，该条目持续写同一 RAM 端口。输出零点数据 `0x004C=119`，但使能 `0x0048=0`；不能从数值相同推断硬件输出必与 CPU 金样一致。静态几何不证明设备 AXI 最大读写范围或 NCHW/OIHW 物理顺序。见 `docs/research/HARDNPU_H1_PAYLOAD_PACKET_GEOMETRY_20260924.md`。

## 2026-09-24 固定 H1 packet-DMA 软件提交合同

`implementation_hardnpu/h1_dma_contract.*` 仅定义当前冻结 H1 夹具的 32 位 DMA 地址、4 KiB 对齐、精确分配长度、四区域不重叠、130 字冻结 packet 及 8 次厂家 packet-DMA 写序列；最后 `0x1000=1` 具有启动含义。函数经调用方回调写出，当前仅用内存记录回调完成主机/板端纯软件测试；尚无 MMIO 实现或硬件许可。回调中途失败后，驱动未来必须隔离已暴露给设备的缓冲直到证明 AXI 排空；公开软复位描述不构成该证明。完整证据和限制见 `docs/research/HARDNPU_H1_DMA_SUBMISSION_CORE_20260924.md`，首算仍 `NO-GO`。

## 2026-09-24 H1 Execute点实际模式与诊断字段

同哈希厂家库在AArch64目标的空设备隔离根中，对冻结单层夹具执行真实`Execute(vector,vector)`，于提交函数入口截断；本次选择`run_npu_hard_dma_mode`，不是normal。`pkg_info+0x10=130`；`+0x00`为命令包主机哨兵`0x55555000`，`+0x1c/+0x20/+0x24`依次为输入`0x11111000`、权重`0x22222000`、输出`0x33333000`哨兵。`+0x18=0`仅为本次观察。所有地址均为诊断值，不能作为真实DMA地址；没有调用提交函数。见`docs/research/HARDNPU_H1_PRE_SUBMIT_RUNTIME_CAPTURE_20260924.md`。当前实际分支指向packet-DMA合同审查，但无桩后端归属和独立驱动仍缺，首算`NO-GO`。

## 2026-09-24 H1打包后实际首个边界

冻结单层夹具在目标AArch64设备遮蔽环境中打包返回后，首先到达`Pool::Acquire`，不是`Pool::GetPhyAddr`。当时保留tripwire安全退出，未分配或读取物理地址；详见`docs/research/HARDNPU_H1_POSTPACK_POOL_TARGET_20260924.md`。后续有界主机CMA替身一次目标运行记录16 KiB分配并在`Pool::GetPhyAddr`入口退出，未读取或返回物理地址，见`docs/research/HARDNPU_H1_POSTPACK_HOST_CMA_TARGET_20260924.md`。两次都未取得真实`pkg_info`，替身哨兵和软件packet均不能用于板端HardNPU写入。

## 2026-09-24 H1打包后边界候选

`h1_postpack_pool_boundary_gate.cpp`只允许厂家软件packer完成并返回，随后在首个`Pool::GetPhyAddr`入口退出；不会返回物理地址。这是用于验证调用次序的候选软件探针，未目标构建/运行。即使将来观测到该边界，也仍没有有效DMA地址、真实`pkg_info`或可提交的HardNPU任务；硬件保持`NO-GO`。

## 2026-09-24 HardNPU Execute软件截断候选（后续目标实证见首节）

同哈希厂家ELF的两处`Execute`模式分派分别在`0x3cb290/0x3cb3f0`和`0x3cb500/0x3cb550`调用packet-DMA/normal提交，提交符号带动态JUMP_SLOT。这个位置适合设计“在提交函数入口记录模式和`pkg_info`后立即退出”的软件探针，**仅静态定位**；它不能单独封住打包后到提交前的Pool/CMA访问。真实截断方案须先使所有前置物理地址、缓存同步、容量不足和异常/析构路径处于设备遮蔽且可观察状态。见`docs/research/HARDNPU_H1_EXECUTE_SUBMIT_BOUNDARY_20260924.md`；硬件继续`NO-GO`。

## 2026-09-24 HardNPU首算输入门禁（当时离线状态）

冻结13项/130字packet仅是设备遮蔽下的厂家**软件打包**。`audit_first_run_gate.py`交叉核对packet哈希、版式、字数与同哈希库的静态提交分支后仍返回`NO-GO`。没有实测`Execute`点模式或`pkg_info`，不得把packer的mode 0误作normal提交，也不得把库加载后`run_npu_in_dma_mode=1`误作执行点值。包内`0x1004=1`及packet-DMA分支末项`0x1000=1`均有启动风险；离线审计结果不能直接作为写寄存器白名单或物理地址来源。详见`docs/records/hardnpu_h1/2026-09-24-first-run-gate.json`。

## 2026-09-24 视频帧状态复位同步器限制

新增`fdma_frame_reset_sync`只为`p2f_clk0`状态域提供PS复位/PLL失锁异步断言及两拍释放，`fdma_frame_status_path`使AXI握手和帧会话复位分离。它不覆盖`uidbuf`中使用同一`I_ui_rstn`的摄像头写时钟、显示读时钟与FIFO，也不证明FDMA在途写响应已排空。Linux消费者只有在会话代数、DDR提交、缓存及防覆盖全部闭合后才可采帧；见`docs/research/VIDEO_RESET_SYNCHRONIZER_CANDIDATE_20260924.md`。

## 2026-09-24 视频状态时钟/复位候选

保存`uidbuf`帧状态与FDMA AXI使用`p2f_clk0`；未来GP0及状态AXI从端若同接`p2f_clk0`，这段路径不需多位跨时钟快照桥，但必须在生成HDL中核验。AXI桥的`ARESETN`负责总线握手，新增`FRAME_RESETN`负责视频会话状态；建议分别由PS总线复位和同步到同一时钟的帧复位驱动，具体同步/复位释放尚未实现与仿真。若生成设计选择其它GP0时钟，多位状态跨域仍需握手快照，不得直接连线。见`docs/research/VIDEO_STATUS_CLOCK_AND_RESET_AUDIT_20260924.md`。

## 2026-09-24 视频帧状态候选总线接口边界

候选`FST1`寄存器偏移与C读取器、RTL读复用器已有静态对应，但参考视频SoC两层PS配置都未启用GP0/GP1，地址源及活动总线连接均为0，保存生成HDL无GP0。尚无已分配基址、Linux资源或板端ID实读。主工程`0x90000000`属于其它版本接口，不能直接用作视频状态基址。视频/UI帧事件处于`p2f_clk0`；若生成GP0/从端也同接该时钟，可同域读取，异域则需原子跨域快照。独立AXI桥综合不证明实际GP0时钟连线。审计见`docs/research/VIDEO_GP_STATUS_SOC_INTEGRATION_AUDIT_20260924.md`及`docs/research/VIDEO_STATUS_CLOCK_AND_RESET_AUDIT_20260924.md`。

## 2026-09-23 H1厂商软件packet的当前证据边界

同日后续在目标AArch64设备遮蔽私有根中，仅加载同哈希厂家库并实读导出`run_npu_in_dma_mode=1`；源码/监督器和原始日志见`docs/research/HARDNPU_H1_RUNTIME_MODE_LOAD_20260923.md`。**当时**没有到达`Execute`；上文2026-09-24的直接构造夹具截断实证显示实际选择packet-DMA，但不改变DMA/Cache/IRQ/停止合同缺口及硬件`NO-GO`。

同哈希厂家库在设备遮蔽的板端AArch64私有根中，由冻结模型派生fixture和原生v2载荷直接构造`AlnpuALHardNPUWorkload`，经`r_HardNPUDriver`进入厂商packer，捕获mode-0 **13个entry、130个32位字/520字节**。原静态预测12项/127字遗漏type-0 `0x5040`一字（值`0x00611118`）；其余12项的顺序、类型、偏移和字数相同。两字header/entry payload逐项复算一致，type-1的64个bias字与冻结输入一致。这是软件包格式的限定实证，详见`docs/research/HARDNPU_H1_REAL_PACKET_CAPTURE_20260923.md`及原始JSON。

捕获的最后一项`0x1004=1`有启动副作用风险，**不得向设备提交或直接回放**。当前包还没有submit阶段独立的`0x0050/0x2000/0x2004/0x6000`前置entry；但按厂商normal-mode反汇编展开，`0x0044`的64字bias块会经过`0x0050`，且五个偏移被包内重复写调用。`0x0050`的前置值是`pkg_info+0x18`控制选择值，不能称为物理基址；后三个才是输入/权重/输出基址。104个payload写调用加4个前置写调用仅是**在真实Execute选择normal-mode时的静态推定**，本次没有调用Execute，真实模式、寄存器别名及副作用未审明；见捕获报告的重放地址审计。真实`pkg_info`、权重重排和DMA范围、Cache/IRQ/停止恢复、独立驱动与当前bit身份仍未验证。该过程不经过无桩parser/Optimize的Alnpu分区，不能推断完整模型backend ownership；ptrace精确规则只对本软件捕获路径作有限验证，尚非通用seccomp等效隔离。HardNPU硬件首算继续`NO-GO`。

同库`run_npu_in_dma_mode`的ELF`.data`初值为1，`Execute`通过其GOT重定位选择零值normal或非零packet-DMA；运行时值没有实测，**软件packer mode 0不等于Execute normal-mode**。若选择packet-DMA，静态提交函数的8次写调用为`0x0050/0x2000/0x2004/0x6000/0x003c/0x100c/0x1010/0x1000`，最后`0x1000=1`启动，包物理地址和设备读取范围未捕获。详见捕获报告和`dma_mode_static_audit.json`；不得从库初值推断当前板卡已执行过该路径。

2026-09-23实时板端设备树复核：`anlogic,hard_npu`的`reg`三段为`0x63F00000/0x100000`、`0xF8800000/0x200`、`0xF8801000/0x100`，`interrupts=<0 112 4>`（GIC hwirq144）；当前live树未见SoftNPU节点。只读解析80MHz候选临时DTB（SHA-256 `bd9125ad1fc31d8fb23aa5a8b9851376647601d836aae5d0d9ad2cb402ceb9f2`）得到相同Hard资源，另有`anlogic,soft_npu`的`0x80000000/0x4000`、`interrupts=<0 85 4>`（hwirq117）。候选并未在本轮加载，不能拿其Soft资源解释当前live系统，也不能从DT节点推断当前bit身份或设备可安全运行。目标AArch64独立句柄自检确认派生`GetPhyAddr() const`在`vtable[15]`/`+0x78`返回四个哨兵；厂家真实调用和DMA地址仍未验证。

状态日期：2026-09-23。接口必须按**版本身份**选择，禁止仅按基址归类。`0x90000000` 同时被普通 TCON、V2 DUC2 和 V4R-1 使用，但三者不是兼容 ABI。

## HardNPU H1目标端运行时边界（2026-09-22）

### 2026-09-24 H1 中断使能版本边界

冻结实捕厂家 packet 的 type-0 `0x1020` payload 是 `7`，包括 bit2；本地 UG1215 只定义该寄存器 bit0/bit1，bit31:2 标为保留；同哈希厂家等待函数检查 `0x1018` bit2。当前 IP 修订尚未绑定，因此不能把 `0x1020=7` 直接列为当前板卡可执行写值。一次性提交软件包装已要求首写前固定 DMA 缓冲，并在写故障后禁止释放/重试；它尚未接到内核 MMIO 或 IRQ。详见 `docs/research/HARDNPU_H1_SUBMIT_STATE_AND_IRQ_MASK_20260924.md`。

### 2026-09-23 Alnpu注册条件补充（静态限定）

目标端后续只读审计将Hard runtime初始化的首段调用顺序确认为：`openat("/dev/hard_npu",O_RDWR)`；只读普通文件占位返回`EROFS`。仅`/run`可写普通文件占位时打开得到FD 3，随后发出`ioctl 0x4801`并被隔离监督器拒绝。公开驱动头定义`0x4801=HARDNPU_IOCTL_GET_REGISTER_INFO`，返回`uint64_t addr,size`。这**没有**验证真实设备的资源值、用户共享映射或软件MMIO安全；普通文件占位不构成该ABI，禁止用占位继续硬件写路径。

同日目标端直接补证：在设备遮蔽的私有根中查询冻结库`BackendRegistry`，无`/dev/hard_npu`时`Alnpu=no,size=3`，加入**仅命名空间内普通文件**后`Alnpu=yes,size=4`。这是该库条件注册的目标运行证据；创建runtime仍因无法打开HardNPU驱动而失败。不得从factory存在推导设备可用、寄存器/DMA ABI或硬件运行许可。受控启动器关闭FD≥3并在目标核对3～4095；系统调用隔离仍非完整等效seccomp。

2026-09-23初期隔离证据：板端ptrace监督器与私有根通过原H1 19项负探针、fork/pthread各四项禁止调用和二次exec阻断。其后在新增精确默认拒绝规则、空设备和中止钩子下完成了上方的限定软件构造/捕获；监督器仍不是通用seccomp等效门禁，硬件继续NO-GO。

冻结`libarmnn.so.32.1`的`AlBackendStaticRegistryInitializer`（`0x3b3e10`）在调用`BackendRegistry::Register`（`0x3b3f64`）前，对`/dev/hard_npu`调用`__lxstat`。`ENOENT`/`ENOTDIR`的控制流跳过注册并返回。因此完全遮蔽设备路径后出现`Alnpu has no IBackend factory registered`，有与库字节一致的解释；私有regular-file占位使桩化Optimize继续，不证明真实设备backend。真实设备节点、无桩Optimize分区和功能性runtime仍未验证；上方直接构造的厂商软件packet不能替代这些证据。禁止为触发注册而恢复真实设备节点或加载原始驱动；占位条件下的结果必须标`CONDITIONAL_STUBBED_SOFTWARE`。目标seccomp返回`EINVAL`，完整等效隔离仍未闭合。证据和证伪步骤见`docs/research/HARDNPU_H1_BACKEND_FACTORY_AUDIT_20260923.md`。

### 桩化软件边界（不是硬件 ABI）

外部隔离实验
`F:/My_proj/_isolated_builds/hardnpu_h1_stub_packet_capture_20260922_1/`
包含 typed no-op CMA 和 Hard driver 替身。它只用于在私有命名空间中让真实
`AlnpuALHardNPUWorkload` 构造和厂家 packer 路径可被观察；Pool 获取、物理
地址、run、wait 和 IRQ 符号仍为 fail-closed tripwire。即使得到对象或 packet，
也只能标记为 `STUBBED_SOFTWARE_PACKET_CAPTURE`；哨兵地址不是物理地址，绝不
得提交到硬件。

在板端私有命名空间中，使用同类 typed stub 和 regular-file 设备占位完成了
一次 parser/Optimize 软件运行：目标节点显示为 `ALHardNPU`，后端标识为
`Alnpu`，输入/输出形状和量化类型与冻结夹具一致。该结果只证明 Arm NN
分区逻辑在桩条件下可继续；真实厂家backend factory与无桩Optimize分区仍未捕获。上方另有**不经Optimize**的真实厂家workload及软件packet捕获，物理地址路径仍未验证。

该实验没有建立 HardNPU 的寄存器、DMA、IRQ、缓存或缓冲生命周期契约。目标
seccomp 当前返回 `EINVAL`，因此完整 H1-02 隔离门禁仍未闭合；桩化结果不能
推动 H1-04/H1-05，也不能与 SoftNPU Pool ABI 合并。

- 冻结目标层为真实模型派生的`/backbone/backbone.7/conv/conv.2/Conv`，形状为输入UINT8 `[1,192,14,14]`、权重UINT8 `[64,192,1,1]`、bias INT32 `[64]`、输出UINT8 `[1,64,14,14]`。
- 板端AArch64 parser已成功写出绑定、原始层记录和常量；这只证明parser输入语义，不证明后端分区。
- 对`Optimize`请求`Alnpu`时，运行库返回`Alnpu has no IBackend factory registered`。因此当前板端环境仍没有可接受的无桩Alnpu backend ownership证据；后续直接构造和packer捕获绕过该分区步骤，不能替代它。
- 当前板端运行库目录可见`libarmnn.so.32.1`、`libarmnnOnnxParser.so.24.6`和`libprotobuf.so.23.0.0`，未发现独立Alnpu backend共享库；库本体包含Alnpu相关符号，不等价于factory已经注册。
- 设备遮蔽降级变体保留私有mount/network namespace、空`/dev`/`/sys`/`/proc`、uid/gid 65534、capability清零、no-new-privs和继承FD关闭；当前内核对seccomp filter返回`EINVAL`，所以该变体仅为`PARTIAL_DEVICE_BLIND`，不能放行真实workload或硬件执行。
- HardNPU mode-0软件packet已限定捕获；动态重定位、DMA地址/长度、权重布局、IRQ、停止和缓冲生命周期仍为`UNKNOWN/NOT_RUN`。SoftNPU Pool的packet、寄存器和完成判据不得复用到HardNPU。

## 版本识别总表

| 版本 | 控制窗口 | 身份 | 当前状态 | 可否用于操作 |
|---|---|---|---|---|
| V2 DUC2 | `0x90000000..0x90000FFF` | ID `0x44554332`，version `0x00020000` | 当前有限板测 ABI | 仅与指定 V2 bit/ELF、100/50MHz 条件配套 |
| 普通 TCON | `0x90000000..0x90000FFF` | ID `0x54434F4E`，version `0x00010001` | 原系统 ABI；新板测 `UNKNOWN` | 只能使用普通 TCON 固件和寄存器表 |
| NPU 历史接口 | 当前候选映射 `0x80000000..0x80003FFF`，IRQ 117 | 可验证版本身份 `UNKNOWN` | 项目产品驱动仍缺失；隔离 v0.5.4 fixed-Pool normal DDR 单作业限定通过 | 仅能按该固定实验 ABI、bit/DTB/模块哈希解释；历史寄存器记录不得作为通用写操作指令 |
| V4 | `UNKNOWN` | ID/version `UNKNOWN` | 数学设计，不是硬件完成态 | 否 |
| V4R-1 | `0x90000000..0x90000FFF` | ID `0x56345231`，version `0x00010000` | manifest 指定 bit/ELF 的 8 个合成用例限定板测通过 | 仅与该 V4R-1 bit/ELF、100/50MHz 配套 |

任何软件在首次写入前都应读取并匹配该版本的 ID/version。身份不符时停止，不得用“同基址”推断兼容。

## SoftNPU 系统 DDR fixed-Pool 实验接口（2026-09-20）

该接口位于工程外隔离目录，不是项目当前产品驱动，也没有可读 ID/version 寄存器证据。只允许与候选 80MHz bit、临时 DTB、固定 packet 和模块 SHA 绑定解释。

- 平台资源：MMIO `0x80000000..0x80003FFF`，GIC hwirq 117 / Linux IRQ 30，设备树时钟 80MHz。
- 软件 ABI：`/dev/softnpu_pool_oneshot`，只含固定 `GET_INFO/PREPARE/RUN/GET_RESULT/GET_DUMP`；无 mmap、任意 offset、任意物理地址或用户 packet。
- 数据流：PS 驱动以 SoftNPU platform device 的 DMA API 分配 packet/input/output 三块 4KiB coherent 系统 DDR；CPU 写入固定 packet 和输入；normal-mode 由 CPU 配置寄存器，SoftNPU 主口仍通过 DMA 访问系统 DDR；完成仅接受严格 NN 状态 `0x4`。
- 逻辑张量：UINT8 输入16字节，固定2×2 Pool黄金输出4字节。v0.3首次作业得到 `05 07 0d 0f` 且把偏移4～7写为零，因旧guard从偏移4开始而隔离；v0.5.4显式区分4字节逻辑输出与8字节实验可写容量后，单次真机输出 `05 07 0d 0f 00 00 00 00` 并通过padding/guard校验。该8字节容量只适用于此fixture。
- 已实现 80MHz board DB 的只读逐位查询确认 HP1 `AWSIZE[1:0]=2'b11`，即写拍为 8 字节；八路 `WSTRB` 都是动态逻辑，不是恒定全开或恒定关闭。它支持固定作业的 8 字节写回假设，但不能证明尾拍 lane mask 或其它 shape/算子的写回容量。
- 冻结运行库 `fill_soft_pool_driver_data()` 的 AArch64 数据流确认 `0x1834=0x00101004` 为输入 `C=1/H=4/W=4`，`0x1838=16` 为输入元素数；输出 TensorInfo 只参与量化 offset/scale，未读取输出 shape/元素数。故该固定块没有独立 output-byte-count，逻辑输出需由 Pool 几何推导；这仍不能替代运行时 WSTRB/AWLEN/WLAST 证据。
- 边界：v0.5.4单次作业内可确认packet/input整块未变，output只有约定8字节发生预期变化，偏移8～4095保护区不变；仍不能证明三个分配区之外没有AXI访问，也不能证明完成IRQ等同所有写事务全局排空。
- 当前实验 UAPI 派生到v0.5.4/ABI `0x00010006`，设备名仍为独立的 `/dev/softnpu_pool_oneshot`。结果结构为20次固定提交写和严格NN IRQ清除写保存顺序、阶段、值及单调时钟进入/返回时间；成功契约要求21条，追踪容量24。INFO声明 `NATIVE_64BIT_ONLY`，驱动不提供 `.compat_ioctl`。该ABI已取得 `TARGET_BUILD_PASS_LIMITED`、`DDR_PREPARE_PASS_LIMITED` 与 `BOARD_PASS_LIMITED(fixed Pool normal DDR)`；它仍不是厂家通用ABI。
- 继承的提交前门禁：enable IRQ 后、第一笔提交写前观察到严格 NN 事件时记 `EARLY_IRQ` 并隔离，错误事件保留 `IRQ_ERROR`，均不得继续提交。继承的超时门禁规定 wait 已返回0后的完成不得进入验证：仍 RUNNING 记 `TIMEOUT`，已观察到严格完成记 `TIMEOUT_LATE_IRQ`；该分类只是软件截止顺序，不是硬件作业标签。
- 只要可能start，即使结果数值正确也保留三块coherent缓冲并自锁模块至物理冷恢复；仅never-started PREPARE可清理。v0.3结果保持 `PARTIAL/QUARANTINED`；v0.5.4在80MHz、只读最小根、明确风险授权下完成唯一一次normal-mode作业并通过固定fixture验收，证据回收后未卸载/重试，用户确认物理断电。输出尾拍strobe的通用规则、其它shape/算子容量、IRQ后排空和异常停机仍 `UNKNOWN`；packet-DMA与重复提交继续NO-GO。
- 独立软件序列审计确认当前继承的 normal 后16笔与厂家拦截完全一致，前四笔依次为 `0x080c=0`、`0x100c=0`、`0x0804=1`、`0x1004=1`。公开驱动只直接证明后两笔 start；前两笔高地址清零来自候选33位 IP-XACT 并曾用于一次有限硬件执行，故只接受为当前候选实验序列，不定义通用 SoftNPU ABI。

### v0.6.0第二尺寸受限参数化ABI（2026-09-21）

v0.6.0是与v0.5.4分开的诊断ABI：设备 `/dev/softnpu_pool_v060`、ABI `0x00010007`，并以INFO flag bit10标识第二尺寸夹具。它固定为UINT8 NCHW `[1,1,4,6]`、MaxPool 2x2、stride 2x2、zero-pad、scale0.25/zero-point0、输出 `[1,1,2,3]`；逻辑输出6字节，实验可写容量8字节，guard从偏移8开始。输入为`00..17`，独立黄金输出为`07 09 0b 13 15 17`。

当前独立恢复结果只支持Max、NCHW UINT8、zero padding、方形kernel和X/Y相同stride。冻结厂家fill路径没有读取padding、pool height、stride X或输出shape，因此其它组合不能由本ABI参数化，也不能由单次成功外推。第二尺寸配置中 `0x1834=0x00101006`、`0x1838=0x18`；完整20-word packet、寄存器顺序和动态DMA地址仍由固定驱动内部生成，用户不能提供packet、offset或物理地址。

匹配80MHz候选、临时DTB、只读最小根和目标内核下完成一次normal-mode真实作业：严格NN状态`0x4`、IRQ一次、21条trace完整，输出`07 09 0b 13 15 17 00 00`；三块4096字节dump与预期逐字节一致，output偏移8～4095的`0xa5` guard不变。接受状态仅为 `BOARD_PASS_LIMITED(second-shape Pool normal DDR, single run)`。packet-DMA、重复提交、其它shape/参数、尾拍规则、分配区外AXI范围、IRQ后全局排空、异常停止、HardNPU和模型链均保持 `UNKNOWN/NO-GO`。启动后模块未卸载、缓冲未释放；软件进入`Power down`后，用户于2026-09-22确认物理断电，冷恢复完成，期间未再次上电或提交。

## IMX415→MIPI-DSI demo参考接口

当前保存Design Integrator生成`system/hdl/system.v`只有FDMA到PS HP0内存端口、P2F时钟/复位、未在有效顶层使用的PS GPIO输出，以及接常量0的1位PS GPIO输入；没有PS可读的多字段帧状态/IRQ通道。后续隔离集成必须新增该通道；仅在`uidbuf`导出完成脉冲/槽号不能构成Linux取帧ABI。PC侧已有显式行步长、字节序、ROI的离线文件探针及合成张量/空间ONNX对照，见`docs/research/OFFLINE_FDMA_FRAME_TO_MODEL_PROBE_20260924.md`；它不代表实际DDR像素语义已验证。

2026-09-24补查PS包装模块：另有1位`pl_gpio_in`，但参考生成`system.v`把它固定接0，故原设计仍无可用PS帧状态。隔离候选把FDMA写响应保护器的粘性故障位接入该输入，8项静态检查通过；该位不能承载完整帧序号、槽号或原子状态快照，也没有实际bit/Linux回读证据。见`docs/research/VIDEO_PS_GPIO_FAULT_PATH_AUDIT_20260924.md`。

2026-09-24多字段状态控制面审计：视频参考PS配置的`Master_AXI_GP0/GP1`均关闭，HP0仅是FDMA写DDR路径；候选`FST1`状态寄存器布局和主机读取器只形成未来接口合同，当前板卡无此ID或偏移。读取器对ID/ABI、偶数版本、前后版本一致及总线错误做拒绝，主机10项检查通过。隔离视频系统需新增PS GP主口/AXI从设备并建立地址、时钟、复位、Linux映射与硬件读回证据；见`docs/research/VIDEO_FRAME_STATUS_READER_CONTRACT_20260924.md`。

后续2026-09-24增量：软件与RTL候选均增加`0x1c`故障位，主机读取器/防覆盖检查更新为12/12、13/13通过。`fdma_frame_status_regs.v`仅同UI时钟域事件寄存器及读复用器，14项偏移静态对照通过，尚未接视频顶层、PS AXI或板卡。复位代数要求复位低电平被运行的UI时钟采到；停钟复位、FPGA重配和计数回绕仍需系统级会话身份与验证。见`docs/research/VIDEO_FRAME_STATUS_PRODUCER_RTL_CANDIDATE_20260924.md`。

2026-09-24候选总线层：`fdma_frame_status_axi_lite.v`把上述14项状态封装为32位只读AXI-Lite；合法对齐读取返回数据，非法读及全部写返回`SLVERR`。独立TD综合通过并导出DB，但日志含未驱动网归零、独立顶层全部73端口无管脚约束警告；无仿真、P&R或板测。视频参考PS GP仍关闭，实际地址、协议转换器、时钟/复位及Linux设备树/驱动均未落地，见`docs/research/VIDEO_STATUS_AXI_LITE_STANDALONE_SYNTH_20260924.md`。

2026-09-24补充的Linux接入门禁：保存顶层`system.v`的FDMA在`0x0A000000`起用三块各8 MiB槽位，合计覆盖`0x0A000000..0x0B7FFFFF`。当前板端Linux `/proc/iomem`把该范围纳入System RAM，列出的reserved区不覆盖它；当前没有`/dev/video*`/`/dev/media*`。顶层未把写完成IRQ和写缓存编号接到PS。因此在当前Linux内存布局下**不能启用该参考FDMA地址或从DDR直接取帧**。必须先绑定实际bit/DTB，建立帧缓冲保留/分配与Cache所有权、完成帧通知和防覆盖协议；详见`docs/research/IMX415_DDR_LINUX_MEMORY_AND_CAPTURE_AUDIT_20260924.md`。此结论是保存RTL与当前Linux地图的条件冲突审计，非参考bit当前运行实测。

2026-09-24消费者帧保护接口草案：`fdma_frame_status`包含偶数稳定版本、复位代数、完成帧序号/槽号、每槽写入开始/完成代数及写中掩码。读取状态必须前后读版本并确保相等且为偶数；复制前后比较同槽代数及复位代数。主机11项检查通过，见`docs/research/VIDEO_FRAME_GUARD_HOST_20260924.md`。该结构目前没有对应PL寄存器、地址、IRQ或驱动ABI，不能作为当前板卡可用接口。生产者必须保证写开始标记先于该槽DDR写、写完成标记晚于该帧所有写提交且CPU Cache同步后再消费；事件序号溢出与跨时钟域仍待设计验证。

2026-09-24当前live FDT哈希`8454c5d088f038833ea1b49d79f053f8feeafff6758731f71251d05bda1bd56d`，根和`reserved-memory`均为`#address-cells=2/#size-cells=2`；已有动态128 MiB CMA但无固定FDMA帧槽。离线候选增加`fdma_frames@a000000`，`reg=<0 0x0A000000 0 0x01800000>`及`no-map`，候选哈希`1dab07ac923b131808663aee3480b48d9895d921d1cf3f02d4c29ab41f48d8d7`。该节点尚未启动，不能改变当前Linux的`NO-GO`判断；参考demo实际bit、PL写完成、PS状态通道、Cache映射及CMA重排仍需联动验收。见`docs/research/VIDEO_FDMA_DTB_RESERVATION_CANDIDATE_20260924.md`。

2026-09-24 `uiFDMA.v`写端完成语义复核：`O_fdma_wbusy`在最后W拍`WVALID&&WREADY`后撤销，而`M_AXI_BVALID/BRESP`不进入该判定。因此`uidbuf`原完成IRQ不是完整AXI写响应确认。隔离候选用同`p2f_clk0`的AW/B计数及BRESP错误锁定延迟送往`uidbuf`的busy；只通过静态连线检查，尚无RTL仿真、PS可读状态或系统集成证据，见`docs/research/VIDEO_FDMA_AXI_B_COMPLETION_AUDIT_20260924.md`。

证据根：`demo/11_csi_dsi_imx415_7cun/`。这是独立参考工程，不是 V2 DUC2、普通 TCON、NPU 或 V4R ABI 的组成部分，也尚未并入当前主工程。

- 保存的 P&R 工程把 `soc_prj/uisrc/01_rtl/system.v` 列为有效源码并以其中的 `system_top` 为顶层；同目录另一个 HDMI 版 `system_top.v` 未参与该次保存的 P&R，不能混用。
- 摄像头侧为 IMX415 I2C 配置、4-lane MIPI D-PHY RX、4-lane CSI解包、RAW10、image correction 和 ISP。
- 视频写通道把1920×1080候选帧写入 DDR 基址 `0x0A000000`，使用3帧缓存；读通道按1024×600、stride 1920读出，表明当前显示是从1920×1080帧中读取1024×600区域而非已确认缩放。
- 显示侧为1024×600时序、RGB24→32转换、DSI video-mode packet、显示初始化ROM和4-lane MIPI D-PHY TX；TX管脚约束存在。
- 保存的最终时序报告为 setup WNS `+7.748ns`、hold WNS `+0.039ns`，TNS均为0；保存 bit SHA-256 为 `e046914d8bd07a8d8afe03a5bcb400cbb2be8d837b9ff5a8646b58c133bfdba4`。
- 用户确认该 demo 已在所接7寸 MIPI屏正常显示。当前目录照片可确认板卡、摄像头和屏幕连接，但照片中的屏幕内容不可见；未保存把该观察绑定到唯一产物的下载/UART日志。
- 根 `BOOT.bin` SHA-256 为 `1848455ed6148258207b65af4e1498fa6ee19b9c2f15f0e11ccfb70f40cc11a8`；保存的 `fdma_en.elf` SHA-256 为 `5d980314db268db4d83e53142c90aa9620dd7f88e39845b0080a8b364269415e`。二者及2025-09-29 bit的时间线不同，且旧 `output.bif` 含失效的 `F:/anlogic_demo/...` 绝对路径，因此在建立manifest前不能推断根BOOT由当前保存bit/ELF生成。

迁移到产品系统前必须冻结面板准确型号、DSI lane/时序、初始化ROM、管脚、有效顶层、BOOT/bit/ELF哈希、摄像头分辨率/帧率及裁剪语义。该 demo 可作为 `VID-001/DISP-001` 的优先参考，但不能证明 NPU、TCN/V4R、OSD或端到端手语识别通过。

## V2 DUC2

证据：`implementation_v2/rtl/duration_accel_axi.v`、`soc_sdk/duration_v2/main.c`、`soc_sdk/soc_base/platform/inc/soc_plat.h`、`implementation_v2/board_test_20260907/stress_probe.log`。

### 地址和寄存器

平台为 DUC2 分配 4KiB 窗口，但包装器仅接收 7 位 AXI 地址并解码到 `0x00..0x6C`。未定义地址和窗口内高位别名不得使用。

| 偏移 | 名称/语义 |
|---|---|
| `0x00` | CTRL：bit0 start；bit1 clear done；运行中写入返回错误 |
| `0x04` | STATUS：bit0 running；bit1 done_latched；bit2 config_error；bit3 segment_overflow |
| `0x08` | T：低 8 位 |
| `0x0C` | K：低 8 位 |
| `0x10` | MODE：低 2 位；0=dense，1=lossless segment，2=budget |
| `0x14` | MAX_LENGTH：低 8 位 |
| `0x18` | THRESHOLDS：4 个通道各 8 位 |
| `0x1C/0x20` | 64 位 budget 的低/高 32 位 |
| `0x24` | RAW_PTR：16 位 |
| `0x28` | RAW_DATA：写低 8 位并自动递增 RAW_PTR |
| `0x2C` | WEIGHT_PTR：16 位 |
| `0x30` | WEIGHT_DATA：写低 8 位并自动递增 WEIGHT_PTR |
| `0x34` | ID：`0x44554332`（DUC2） |
| `0x38` | VERSION：`0x00020000` |
| `0x3C` | CAPABILITIES：`0x10040820` |
| `0x40` | OUTPUT_INDEX：低 5 位 |
| `0x44/0x48` | 有符号 INT64 结果的低/高 32 位 |
| `0x4C/0x50` | 无符号 64 位误差证书的低/高 32 位 |
| `0x54` | bit0：该输出窗口是否回退 |
| `0x58` | active cycles |
| `0x5C` | replay/fallback count |
| `0x60` | overlap products |
| `0x64` | dense products |
| `0x68` | segment count：低 8 位 |
| `0x6C` | output count：低 8 位 |

### 数据、事务和同步约束

- 当前板测参数固定为 T=32、C=4、K=8；样本按 `t*4+c`、权重按 `k*4+c` 紧密装载，元素为有符号 INT8。
- 每次作业输出 25 个有符号 INT64 窗口结果及无符号 64 位证书。64 位值由两个 32 位事务按低字再高字组合。
- 完成后的结果形成冻结 epoch；只能在 done 后、下一次 start 前由单主机读完。总线不提供原子 64 位读。
- 寄存器 32 位、4 字节对齐，WSTRB 按字节生效。非法、未对齐、只读写、运行中写、越界写或非法结果读返回 AXI SLVERR。
- AW/W 可以分离到达；B/R 响应保持到 ready。输入 RAM 不追踪完整装载状态，软件必须写齐全部将使用的数据。
- 本核没有 IRQ 输出，当前固件轮询 done；没有 DDR 地址、DMA 描述符或缓存所有权协议。
- 当前 MMIO 需映射为 Device memory；`volatile` 与 `dsb sy` 的使用不能替代完整页表/Cache 属性审查，该审查为 `UNKNOWN`。
- known-good 实际频率为 P2F_CLK0=100MHz、P2F_CLK1=50MHz。默认约 200/133.32MHz 不属于该板测 ABI 的已验证运行条件。

## 普通 TCON

证据：`soc_prj/uisrc/03_ip/ip_repo/temporal_conv/temporal_conv_files/RTL/temporal_conv.v`、`soc_sdk/temporal_conv/main.c`、当前 `soc_plat.h`。

### 身份和寄存器

| 偏移 | 名称/语义 |
|---|---|
| `0x00` | CTRL/状态：start、done、busy 语义；与 DUC2 的 CTRL+独立 STATUS 不同 |
| `0x0C` | NUM_FRAMES，默认 16 |
| `0x10` | FEAT_DIM，默认 256 |
| `0x14` | KERNEL_SIZE，默认 5 |
| `0x18` | NUM_FILTERS，默认 4，受 PE 数限制 |
| `0x1C` | POOL_SHIFT |
| `0x20` | WEIGHT_WR：写入一个字节 |
| `0x24` | WEIGHT_PTR |
| `0x28` | IRQ_STATUS |
| `0x2C` | IRQ_CLEAR |
| `0x30` | IRQ_ENABLE |
| `0x34` | IP_ID：`0x54434F4E`（TCON） |
| `0x38` | VERSION：`0x00010001` |
| `0x3C` | CAPABILITY：`0x00000001` |
| `0x40` | FEAT_WR：写入一个字节 |
| `0x44` | FEAT_PTR |
| `0x48` | OUTPUT_RD：有符号 INT32 聚合结果 |
| `0x4C` | OUTPUT_RD_PTR |

普通 TCON 的特征地址使用固定帧跨度 256；每个滤波器的权重地址使用 2048 字节跨度，结果按滤波器聚合为 INT32。它不是 DUC2 的 4 通道紧密窗口、INT64 逐窗口结果或证书协议。普通 TCON 的 IRQ、最新板测、DMA/Cache 和实际运行频率均为 `UNKNOWN`；V2 mode0 不能替代普通 TCON 板测。

## NPU 历史接口

当前可确认的工程事实：

- `system.v` 中存在 `Video_NPU_0` 的 AXI-Lite 控制口、AXI master 数据口及中断连接。
- 当前 BSP 映射为 `0x80000000..0x80003FFF`，中断号 117。
- 历史文档曾按另一窗口记录 TOP、AXI_READ、AXI_WRITE、SOFT_NN、SOFT_YOLO 等组，并出现 `0x91000000` 系列地址；这些地址与当前 BSP 映射冲突，且不能证明高位别名是正式契约。
- 历史日志后段称 AXI_READ 某些寄存器可读写，而 SOFT_NN 写入触发 SLVERR；所谓 Linux probe 执行 unlock 仍是推断。
- 当前目录没有 `soc_sdk/fdma_npu/`、`npu_reg.h`、`npu_drv.c` 或 `npu_drv.h`。历史驱动 API、寄存器数量、初始化顺序和模型加载流程不构成当前可用软件。

因此 NPU 的正式 ID/version、完整寄存器偏移、读写属性、复位顺序、缓存/DMA、模型包格式、错误码和裸机/Linux 初始化契约全部为 `UNKNOWN`。在找回原始资产并与官方资料及当前互连复核前，不得据历史表执行写操作。

### HardNPU静态packet ABI（H1诊断限定，非硬件写许可）

2026-09-21对冻结 `libarmnn.so.32.1`（SHA-256 `5def7ba75e4b59644be6f58deaf8b2bb3791c62ed38b52b6aea08b11a8f728ce`）进行只读ELF/反汇编分析，形成 `F:/My_proj/_isolated_builds/hardnpu_h1_packet_abi_20260921_1/`。该证据不加载共享库、不访问设备，状态仅为 `PASS_STATIC_LIMITED`。

packer entry为24字节：type/offset/word_count位于`+0/+4/+8`，payload指针位于`+16`；list为16字节，count在`+0`、entry指针数组在`+8`。每项packet顺序为长度/类型字、地址头和payload：type 0为`0xff000000+words`，恢复到的非零type为`0xff400000+words`。H1实际静态driver路径在`0x3cc0cc`传mode 0，于`0x3cc0d8`调用packer，地址头为`reg_offset|0x63f00000`；`0x63f00000`是编码字段，不能视为PS物理基址。

基础register-list在特殊处理前含7个type-0组：`0x0000..0x005c`、`0x1000..0x1020`、`0x2000..0x200c`、`0x3000..0x3008`、`0x4000..0x4004`、`0x5000..0x5040`、`0x6000..0x6054`。后续builder对`0x0040/0x0044/0x0050`、`0x1000..0x1014`、`0x200c/0x3008/0x4004`及`0x6028..0x6054`中的若干项特殊拆分或替换，所以这7组既不是最终H1 packet，也不是可提交的寄存器白名单。

normal helper在四项prewrite后逐项解码并调用`hard_npu_write`；packet-DMA helper另使用`0x100c`写packet地址、`0x1010`写字数、`0x1000=1`启动。IRQ等待路径只接受flag 1/work 5，bit2为错误。公开Hard驱动的probe会改top/SRAM/reset，任意offset ioctl和mmap长度无界，handler会在无作业generation归属前读`0x1018/0x1014`并写`0x101c`，超时无stop/drain证明。因此它不得原样加载或作为H1首算驱动；真实packet、重定位、DMA范围和硬件寄存器安全仍为 `UNKNOWN`。

#### H1冻结payload的entry形状预测（静态限定）

`F:/My_proj/_isolated_builds/hardnpu_h1_entry_contract_20260921_1/`把冻结H1 payload、公共枚举和厂家ELF交叉验证。`QAsymmU8`枚举值为2；entry builder中仅type 6 (`QSymmS8`) 才生成`0x0040`量化尾项并保留`0x5000..0x5040`组，因此这两部分不属于当前H1预测。`m_HasAct=false`也排除`0x6028`激活LUT；bias使type-1 `0x0044`携带64 words。

对固定`[1,192,14,14]`、权重`[64,192,1,1]`、输出`[1,64,14,14]`、NCHW/stride1/pad0进行静态Split算术，输出通道范围为单组`[0,63]`，tile数为1。条件entry顺序为：`0x0004/15`、type-1 `0x0044/64`、`0x0048/2`、`0x0054/3`、`0x1008/1`、`0x1020/1`、`0x2008/1`、`0x3000/2`、`0x4000/1`、`0x6004/9`、`0x602c/3`，最后type-0 `0x1004/1`且payload为1；合计12项、127 words、508字节。该列表只用于原生设备遮蔽捕获的对照oracle，不包含除最终start外的真实值、物理地址或重定位，不是硬件寄存器写白名单。实际捕获有任何差异都必须保持`UNKNOWN/NO-GO`并重新分析。

#### H1 normal-mode动态基址与隐藏句柄ABI（静态限定）

`F:/My_proj/_isolated_builds/hardnpu_h1_relocation_contract_20260921_1/`对同一冻结厂家库继续只读分析，接受范围仅为`PASS_STATIC_RELOCATION_CONTRACT_LIMITED`。normal-mode在回放entry前读取40字节`pkg_info`：`+0x18`写寄存器`0x0050`，`+0x1c`输入基址写`0x2000`，`+0x20`权重基址写`0x2004`，`+0x24`输出基址写`0x6000`；`+0/+8/+0x10`分别为packet物理地址、host指针和word count，其中packet物理地址用于另一条packet-DMA路径。两种提交模式不得混用。

Hard driver从第二输入句柄通过vptr `+0x78`间接调用取得权重物理基址；厂家`AlnpuTensorHandle`虚表的ELF重定位把该槽识别为`GetPhyAddr() const`。公共`ITensorHandle`头文件没有该方法，因此旧plain `PassthroughTensorHandle`探针不具备已证明兼容性，状态为`REJECTED_OLD_PAYLOAD_AS_NATIVE_READY`。修正版v2派生句柄追加该virtual并先检查`vtable[15]`；2026-09-23板端AArch64独立抽取自检的四个哨兵均通过，状态仅`TARGET_VTABLE_SLOT_PASS_LIMITED`。完整v2载荷及厂家实际经该槽调用仍`NOT_RUN`。

按恢复的pool规则，大于2999字节的池向4KiB舍入；固定H1 input/weight/output的最小池容量分别为40960/12288/16384字节。`GetPhyAddr()`路径可能按逻辑tensor字节执行`AccessForDev`后返回池物理地址，但池容量、cache同步长度都不能证明设备实际AXI burst边界。最终pkg_info、真实DMA读写范围、weight原生布局、padding/scratch、IRQ完成和停止排空仍`UNKNOWN`，不得把12项预测packet当作完整提交契约。

### Soft NPU 80MHz诊断候选（非正式产品ABI）

2026-09-14在隔离候选上形成并板测了最小诊断契约：基址`0x80000000`、窗口16KiB、GIC SPI85，NPU配置/系统时钟和PS GP/HP均位于P2F_CLK0=80MHz，P2F_CLK1=40MHz。该契约只属于`softnpu_hw_v2_20260914_3`实验，不替代历史NPU接口，也不表示模型可运行。

参考版本不能按“安路 Soft NPU”笼统合并：冻结的 D20.3 `2025.1` HPF 自带 DTS 为`0x1F0000000/64KiB`、SPI97且标记器件`DR1M90GEG484`；同批通用Linux DTS为同址1MiB；本候选是`DR1M90GEG400`、16KiB、SPI85。三者需分别按精确bit/HPF/DT/驱动身份核验。旧HPF不授权改写本候选窗口或下载其bit，详见`docs/research/SOFTNPU_D20_3_HPF_VERSION_COMPARISON_20260917.md`。

公开Linux驱动确认以下寄存器语义：

| 偏移 | 公开驱动语义 | 当前证据 |
|---|---|---|
| `0x0008` | 顶层设备中断状态，只读；bit2..5为NN/YOLO/CSC/Resize | 驱动未绑定、80MHz候选两次独立冷启动均只读返回`0x00000000`，系统未挂死或重启 |
| `0x0020` | 冻结用户库 `soft_npu_op_supported` 读取32位并按算子编号取位，Pool查询编号0 | 当前候选与D20.3示例IP-XACT的TOP表未列此偏移的名称/位义；候选硬件读值、能力位有效性`UNKNOWN`，未上板读取 |
| `0x0804` | `DMA_START0`，原驱动probe无条件写1 | 尚未写；地址/缓冲区前置条件`UNKNOWN` |
| `0x1004` | `DMA_START1`，原驱动probe无条件写1 | 尚未写；地址/缓冲区前置条件`UNKNOWN` |
| `0x18BC` | Soft NN clear interrupt，write-high-pulse | 尚未验证 |
| `0x2040` | Soft YOLO clear interrupt，write-high-pulse | 尚未验证 |
| `0x286C` | Soft CSC clear interrupt，write-high-pulse | 尚未验证 |
| `0x3044` | Soft Resize clear interrupt，write-high-pulse | 尚未验证；也证明窗口必须覆盖16KiB |

板上成功流程为：U-Boot保持P2F reset、设置`FCLK_CNT_DIV=0x07070904`、易失下载bit、释放reset、加载80MHz临时DTB；Linux再确认driver未绑定后进行一次RO访问。该流程已在多次独立冷启动中重复成功。因为相对失败候选同时改变了复位连接和频率，根因只能写为组合修正有效，不能单独归因。原驱动probe会先写两个DMA start寄存器，因此不得直接加载；独立只读ABI的v2已经重新验收，结果仍只覆盖控制面。

### 诊断驱动契约与公开运行库边界

已板测的v1隔离诊断驱动默认参数为`allow_dma_start=N`、`enable_irq=N`、`allow_user_mmio=N`，只允许资源匹配、ioremap、字符设备创建和`GET_REGISTER_INFO`。禁用状态下，等待中断返回`EOPNOTSUPP`，寄存器读写IOCTL和mmap返回权限错误。`enable_irq=Y`只使用`IRQF_NO_AUTOEN`登记GIC hwirq117；既有板测没有调用内核`enable_irq()`，因此不得写成实际中断已通过。v1虽然默认门禁有效，但源码仍保留可开放的任意读写/mmap、probe DMA-start和写clear寄存器的handler，后续不得直接打开这些开关。

公开`libarmnn.so.32.1`的`soft_npu_driver_init`会打开`/dev/soft_npu`、通过`0x5301`取得寄存器资源并以可读写方式mmap；`soft_npu_read/write`随后直接访问映射窗口。Soft NN普通模式写`0x1820/0x1824/0x1828/0x182c/0x1830`等配置；DMA模式还写`0x1808/0x180c/0x1810`并以`0x1804=1`启动。内核原驱动在这些用户态配置之前就写`0x0804=1`和`0x1004=1`。公开资产没有说明这两个全局DMA-start的安全前置条件，所以诊断驱动不得仅因字符设备和IRQ登记成功就开放它们。

同一库的`AlnpuLayerSupport::IsPooling2dSupported`会先调用`soft_npu_op_supported(0)`，经`soft_npu_read(0x20)`直接读映射寄存器并取bit0。因此“仅做Alnpu支持查询/Optimize”也不属于无设备的parser-only隔离操作；现有IP-XACT缺少此偏移的位义不能用于推断其运行时返回值，更不能据`NN_POOLING`编译宏冒充设备能力读值。

进一步反汇编确认公开Pool缺省`run_npu_in_dma_mode=1`；单包会先写`0x1820/0x1824`，再写`0x1810=0x1010`、packet物理地址到`0x1808`、packet字数到`0x180c`，最后`0x1804=1`。随后运行库通过驱动等待1000ms、期望状态mask `0x0c`。公开handler会按完成位写clear寄存器；超时后的停止/复位恢复未确认。因此这些信息只接受为`PARTIAL`写序证据，不构成直接启动授权。

G4a `tools/npu/soft_npu_irq_diag_v1/`使用独立magic `Q`，只在预状态0时单次使能Linux IRQ 250ms；不写device start/ack、不做DMA、不开放mmap。2026-09-16在复位对齐80/40MHz临时bit/DTB环境中完成一次限定板测：ABI=`0x00010000`、资源=`0x80000000/0x4000`、Linux IRQ30对应GIC hwirq117、flags=`0x0f`、250ms窗口；前后状态均0、事件数0、`/proc/interrupts`双核计数仍0，随后正常卸载并恢复driver-unbound。结论仅为`IRQ_IDLE_WINDOW_PASS_LIMITED`，证明空闲窗口使能未观察到异常事件；不证明NPU能产生完成中断，更不证明device ack、DMA、Soft/Hard算子或模型。

2026-09-15新增的v2权威源码位于`tools/npu/soft_npu_diag_v2/`，其接口与安全边界为：

| 项目 | v2契约 |
|---|---|
| 设备和身份 | `/dev/soft_npu_diag_v2`；独立ioctl magic `D`；ABI `0x00020000` |
| 资源查询 | 返回物理起点、窗口长度、ABI和能力标志；不提供运行库兼容承诺 |
| MMIO读取 | 仅驱动内固定读取`0x0008`顶层中断状态；用户不能传入offset |
| MMIO写入 | 不存在寄存器写命令或内核MMIO写路径 |
| 用户映射 | `mmap`无条件返回`EPERM`；不存在`remap_pfn_range` |
| DMA | 无DMA-start、描述符或缓冲区接口 |
| IRQ | 默认不登记；`register_irq=1`也只以`IRQF_NO_AUTOEN`登记，驱动无arm/enable/wait接口。handler仅观察`0x0008`并隔离Linux IRQ，不清设备寄存器 |
| 状态 | `UNREGISTERED`、`REGISTERED_DISABLED`、`FIRED_QUARANTINED`、`ERROR_QUARANTINED`，不得把registered写成enabled或fired |

v2于2026-09-15在板端私有目录完成构建和两级受限板测。默认无IRQ时，固定读取`0x0008`返回0，ABI/资源为`0x00020000`和`0x80000000/0x4000`；可选登记模式使用`IRQF_NO_AUTOEN`，Linux虚拟IRQ30映射GIC hwirq117，10秒内双核计数保持0。两种模式均能卸载并恢复driver-unbound。该结果仅为`BOARD_PASS_LIMITED(v2-control-plane)`，不表示中断实际使能/触发或数据面通过。公开Arm NN在注册Alnpu后端时会同时初始化Hard NPU和Soft NPU，内存管理器还初始化CMA；Hard/Soft均要求RW共享mmap。因此v2故意不能运行公开模型，禁止通过软链接、改设备名或放宽mmap来伪装兼容。完整静态矩阵见`docs/research/NPU_STACK_COMPATIBILITY_MATRIX_20260915.md`。

### G3连续内存诊断契约（受限板测通过）

`tools/npu/soft_npu_cma_diag_v1/`定义独立设备`/dev/soft_npu_cma_diag_v1`、ioctl magic `M`、ABI `0x00010000`。它绑定当前`anlogic,soft_npu`平台设备，但不映射寄存器、不登记IRQ、不启动设备DMA，也不兼容公开`/dev/cma_mem` ABI。

| 项目 | G3诊断契约 |
|---|---|
| 分配 | probe固定调用一次`dma_alloc_coherent`，大小64KiB；设备streaming/coherent mask均限制为32位 |
| 暴露信息 | 只返回ABI、能力、大小、DMA总线地址和页大小；不返回内核逻辑地址 |
| mmap | 只允许offset 0、完整64KiB、`MAP_SHARED`且不可执行；使用`dma_mmap_coherent`，无任意物理地址输入 |
| CPU检查 | 内核填充/用户逐字节检查，再由用户填充/内核逐字节检查；输出必须明确`device_dma=NOT_RUN` |
| 生命周期 | 单打开；VMA持有模块引用；禁止sysfs手工unbind；卸载后必须恢复driver-unbound |
| 禁止能力 | 无NPU MMIO、IRQ、DMA-start、描述符、streaming sync、原始`remap_pfn_range`或Arm NN兼容承诺 |

板端确认系统保留128MiB CMA，起点`0x17c00000`；运行时`CmaTotal=131072kB`、测试前`CmaFree=130640kB`。Soft NPU节点没有`dma-coherent`属性，`/soc/dma-ranges`长度为0。

2026-09-15唯一一次探针分配DMA地址`0x17c70000`、大小65536、页大小4096，完整位于32位和已知CMA范围；内核→用户、用户→内核逐字节检查均通过。加载后`CmaFree=130576kB`，卸载约2秒后恢复130640kB，节点/模块/绑定消失，10秒观察无异常。接受状态为`CMA_CPU_COHERENT_PASS_LIMITED`。探针输出明确`device_dma=NOT_RUN`，因此不能推导NPU master可达、缓存所有权切换、设备DMA或算子通过。

## V4

当前仅有 `innovation_research/dynamic_certificate_model.py`、结果 JSON 和技术稿。结果文件明确排除 RTL、FPGA 测量、周期/能耗、真实网络数据及硬件原子性验证。

基址、窗口、ID/version、寄存器、IRQ、数据位宽、DDR/DMA 格式、端序、对齐、Cache、握手、反压、错误码、复位和频率均为 `UNKNOWN`。不得借用 DUC2 或普通 TCON ABI。

## V4R

证据：`implementation_v4r/rtl/v4r_tile_core.v`、`implementation_v4r/rtl/v4r_tile_axi.v`、`implementation_v4r/sw/v4r_regs.h`、`implementation_v4r/sw/main.c`、`implementation_v4r/V4R_BUILD_MANIFEST_20260909.json`。V4R-1 是独立 ABI，不兼容 DUC2 或普通 TCON。

### V4R-1 地址和寄存器

| 偏移 | 名称/语义 |
|---|---|
| `0x00` | CTRL：bit0 start；bit1 清 done；运行中写入返回 SLVERR |
| `0x04` | STATUS：bit0 running；bit1 done_latched；bit2 config_error；bit3 internal_error |
| `0x08` | T：低 8 位，合法范围 1..32 |
| `0x0C` | K：低 8 位，合法范围 1..8 且不大于 T |
| `0x10` | BLOCK_SIZE：低 8 位，只允许 2/4/8/16 |
| `0x14/0x18` | UINT64 误差预算的低/高 32 位 |
| `0x1C` | RAW_PTR：16 位 |
| `0x20` | RAW_DATA：写低 8 位并自动递增 RAW_PTR，容量 128 字节 |
| `0x24` | WEIGHT_PTR：16 位 |
| `0x28` | WEIGHT_DATA：写低 8 位并自动递增 WEIGHT_PTR，容量 32 字节 |
| `0x2C` | ID：`0x56345231`（V4R1） |
| `0x30` | VERSION：`0x00010000` |
| `0x34` | CAPABILITIES：`0x01040820`（ABI1、C4、K8、T32） |
| `0x38` | OUTPUT_INDEX：低 5 位 |
| `0x3C/0x40` | 有符号 INT64 结果的低/高 32 位 |
| `0x44/0x48` | 无符号 64 位误差证书的低/高 32 位 |
| `0x4C` | 该输出已精确结算的 tile 数：低 8 位 |
| `0x50` | OUTPUT_COUNT：低 8 位 |
| `0x54` | active cycles |
| `0x58` | tile commits |
| `0x5C` | interval products |
| `0x60` | residual products |
| `0x64` | 非零证书下冻结的 approximate output 数 |
| `0x68` | 本地作业 epoch：每次接受 start 加一 |

### V4R-1 数据、事务和验证边界

- 当前固定 C=4，样本按 `t*4+c`、权重按 `k*4+c` 紧密装载，均为有符号 INT8。输出数为 `T-K+1`，每项包含 INT64 结果、UINT64 证书和已结算 tile 数。
- 核先建立每块/通道的代表值和残差上下界，再按 tile 顺序用精确残差替换区间贡献；当证书不大于预算时冻结该输出。预算为 0 时所有输出必须精确。
- 软件必须先读 ID/version，配置并完整写入所需输入，再 start；done 后且下一次 start 前读取结果。64 位字段由低字/高字两个事务组合，总线不提供原子 64 位读。
- AXI 地址为 4 字节对齐；AW/W 可分离，B/R 响应保持至 ready，WSTRB 按字节生效。未定义/未对齐/只读写/运行中写/越界写/非法结果读返回 SLVERR。
- 当前没有 IRQ；固件轮询 done。`epoch` 只标识本地 MMIO 作业，不是 DDR 描述符、DMA 所有权或跨复位防迟到协议。
- 当前数据平面只有寄存器装载。DDR/DMA、Cache、乱序/重复/迟到事务、视频/FDMA/NPU 串接、多输出通道、真实模型和错误恢复均为 `UNKNOWN`。
- 板测配置为 P2F_CLK0=100MHz、P2F_CLK1=50MHz，V4R AXI 位于 P2F_CLK1。完整 SoC 最终时序 setup WNS `+4.223ns`、hold WNS `+0.020ns`；默认约 200/133.32MHz 不收敛，不属于 V4R-1 板测条件。
- 当前层级为 `SIM=PASS`、`SYNTH=PASS`、`P&R=PASS`、`BIT=GENERATED`、`FIRMWARE=BUILT`、`BOARD=PASS_LIMITED`。2026-09-10 实读 ID/version/capabilities `0x56345231/0x00010000/0x01040820`、分频 `0x07070703`；8 个指定合成用例首轮和复位重跑通过。该结果不能替代 DDR DMA、视频/NPU、真实模型、长稳或满带宽验证。

## Git 源码基线说明

2026-09-17 Soft NPU G4前置板测新增的**内存证据**：临时80/40MHz候选下，绑定`anlogic,soft_npu`平台设备的诊断模块同时申请packet/input/output各4096字节coherent缓冲，DMA地址为`0x0496c000`、`0x0baf3000`、`0x0e635000`；32位范围、64字节对齐和两两不重叠成立，卸载释放成功。此结果只限定为`THREE_BUFFER_CPU_ALLOCATION_PASS_LIMITED`。没有由NPU主AXI读写这些地址，因而地址翻译、缓存所有权、packet格式、完成IRQ、停止/恢复和Pool算子仍`UNKNOWN`；不得与V2 DUC2、普通TCON或V4R ABI混用。

2026-09-17寄存器元数据复核：当前候选 Soft NPU 主机基址为`0x80000000`，其内部逻辑命令块以`0x91000000`开头，不得把两者当成同一 PS 物理基址。相对主机偏移`0x0804/0x1004`为AXI读/写启动，`0x1804`为读包启动，`0x1814`为NN启动，`0x18b8`为只读中断状态。生成 HDL 指向16KiB窗口，而矩阵配置 XML 指向4KiB；除下面单字结果外，整体高偏移板级可达性仍`UNKNOWN`。名称不构成寄存器写入、DMA或恢复许可；详见`docs/research/SOFTNPU_G4B_REGISTER_MAP_RECONCILIATION_20260917.md`。

2026-09-18在无真实设备节点、私有空`/dev`/`/sys`/`/proc`且降权的隔离软件路径中，冻结厂家库对全新reset镜像仅置Pool使能bit、mode1返回3个type0 entry：`0x181c`一字0、`0x1834`连续12字（仅第9字/`0x1854`为1）、`0x1814`一字1。之后单次厂家软件打包函数实际输出20字/80字节，三组首头为`0xff000001/0xff00000c/0xff000001`；此前静态推断的`0x40000000+字数`把类型0条件写反。上述是**合成软件镜像及软件raw字**，不是ONNX模型包、主机MMIO写序或设备ABI验收。`0x1814`含启动副作用风险，严禁据此直接写设备。证据见`docs/research/SOFTNPU_G4B_VENDOR_SYNTHETIC_PACKET_CAPTURE_20260918.md`。

同日对固定UINT8/NCHW `[1,1,4,4]`、2×2/stride2、scale0.25/zero0的**伪workload+真实TensorInfo**执行完全设备遮蔽的厂家软件填充/打包。实际软件镜像`0x1834=0x00101004`，纠正旧候选H/W/C顺序错误；14数据字校验后厂家返回3个type0 entry、20字/80字节，原始JSON SHA-256=`d75c7e4650782a893ce58ce3c255d9d790d5fa6fc4f57b118adb521e68305b9d`。这只确立该固定描述符的**软件输出**，不是ONNX parser/Alnpu分配、NPU窗口写语义、设备主AXI、算子或恢复契约。末尾`0x1814`仍是`NN_start`副作用候选，绝不可直接提交。见`docs/research/SOFTNPU_G4B_POOL_FILL_V3_BOARD_20260918.md`。

同日U-Boot限定板测中，在80/40MHz复位对齐候选bit下，`0x800018b8`单字只读返回0且控制台仍响应；这是`HIGH_OFFSET_RO_RESPONSE_PASS_LIMITED`，仅更新该**特定字**的响应证据。其他高偏移访问、DMA/IRQ完成和Pool仍`UNKNOWN`。

2026-09-09 首次源码/验证基线导入 V2 DUC2、普通 TCON、历史系统互连和 BSP 映射。随后 V4R-1 在独立开发分支形成自己的 RTL/ABI/固件；这不改变 V2 或普通 TCON。V4、NPU 驱动以及 V4R 的完整 DMA/Cache 契约仍保持上述 `UNKNOWN`。

## 2026-09-29 固定现场Hard＋Soft单图候选

后续BOARD更新：ABI10009现场单图通过，H5四START/释放＋H6一START严格成功；同实际Soft张量板端128维尾部PC allclose。连续候选implementation_softnpu/h6_serial、ABI0x0001000a、/dev/softnpu_h6_serial，布局不变。PREPARE只在首帧；后续SET_INPUTS仅在严格SUCCESS、IRQ关闭同步、TOP_STATUS0与原缓冲重验通过后进入PREPARED。全部DMA贯穿会话且结束固定；失败禁止再提交。连续版native编译完成、未加载/START，不将首版单图作为连续验收。

Hard H5复用h5_segment四片ABI0x48350000，SET_JOB真实输入47040B、各片456/328B包及46080/15360B权重、2352/784B输出；完成/CRC/守卫/释放沿用资格驱动。Soft h6_live ABI0x00010009、/dev/softnpu_h6_live；PREPARE三20KiB缓冲后SET_INPUTS接受16032B（skip7840＋c7填充352＋Hard7840），分别读DMA input和input+8192，写output7840B。固定M17968/27065 S15合并舍入并输出zero154，独立金样按实时输入计算；RUN需要实时输入已设置。单次START，严格IRQ0x4/23trace/全部守卫，成功和失败均保持缓冲并需物理恢复；连续帧与热释放未验证。现阶段BOARD CPU与native构建通过，新的现场Hard/Soft整图未START；原保存Hard→现场Soft证据另列当前状态，不混同。

## 2026-09-30 固定NET_PL共享DW/C128 V4R接口（SIM/SYNTH，待BOARD）

GP0x90000000/4KiB保持DW低0x20寄存器与ABI10001。新增0x20 ID56345232、0x24 ABI20001、0x28 status（pending bit0/done bit1/fault bit2）、0x2c/30/34 input/parameter/output、0x38 START=1与只读shape10808003、0x3c/40 INT64 accumulator budget、0x44 device cycles、0x48 core cycles、0x4c base/0x50 interval/0x54 residual/0x58 skipped/0x5c sample reads。全空间GP/HP0仍共p2f_clk0 80MHz，Soft HP1不变；仅空闲START切换owner，最后B响应后发布done。

net_pl.c为单个platform节点codex,net-pl-c128，提供/dev/dw16与/dev/v4r_c128；同mutex及三存活coherent DMA缓冲，64B prefix及尾守卫，地址32位/64B对齐。DW旧56B ioctl保持，V _IOWR('V',1,88B)布局前56B同DW、offset56 budget u64，64/68/72/76/80/84六u32统计。V输入2048 signed INT8；参数49152 O,C,K signed INT8＋128 little-endian INT32 bias；输出2048行每行center/lower/upper三little-endian INT64，49152B。T16/C128/O128/K3/dilation4固定，M22891/S23，code预算floor(code*2^23/22891)。每job前检查两算子空闲状态，成功末B/守卫/输入参数CRC后可复用；超时/故障固定module与DMA且需物理恢复。仍须在匹配临时bit/DTB下先释放PS GPIO bit0再probe，避免已有GP读挂死。当前仅SIM/SYNTH/目标编译，无新的BOARD结论。

N3 BOARD更新：上述接口在SHA1571ac...1b152临时bit/CRC4f533a68下通过真实零/预算32、原16帧混合及保存特征Hard前缀→PL末层；HP0的ARLEN实际4位，readburst必须≤16，先前64拍因截断造成152cycle RLAST失败，日志及物理恢复已记录。成功可交替DW/V4R，最终B/守卫/CRC合格后NET模块安全卸载；Soft仍沿旧固定策略。此ABI支持硬件V4R功能，不宣称整体提速或视频显示。

N4固定Hard组合ABI48450100（CODED/目标编译，未START）：/dev/h4_h5_fixed复用固定模型K系列ioctl，十槽为6H4＋4H5；LOAD包stride904B/weight46080B，复制和校验各槽实际长度，padding不计packet word count。H4输入7840/输出7840/weight25600，H5输入47040、前三片输出2352/weight46080/packet456、末片784/15360/328。slot6与0释放输入，其余同组复用；循环一帧结束回slot0。新的LOAD头保护已修，首次RUN仍被idle0稳定检查拒绝，故障保留DMA/module需冷恢复。prefetch V4R新bit不改变DW/V4R ABI或参数，仍未BOARD。

2026-09-30 后续BOARD更新：用户冷恢复后固定Hard组合已在原16帧入口通过160空间＋2时序Hard作业，按原完成/导出CRC/释放卸载。C128预取版及DW九乘加流水版均已BOARD，输入/参数/输出/寄存器/ABI不变；各真实输出与金样精确，DW约3.65～3.74ms，V4R预算32约17.58～17.63ms。旧首次work3失败保留、原因UNKNOWN，未放宽idle条件。前部96通道112×112→56×56DW仅已提参数与CPU桥接，尚无新硬件寄存器或DMA ABI，不能向旧DW16接口提交该大张量。


## 2026-09-30 DW96前层固定入口（BOARD）

NET_GP新增0x60 ID44573936、0x64 ABI30001、0x68 pending/done/fault=1/2/4、0x6c/70/74 input/parameter/output、0x78 START写1/shape读00607070、0x7c设备周期。DW16/V4R原地址与ABI保持。/dev/dw96以D1/56B Job提交1204224B input、3072B parameter、301056B output。固定96×112×112→96×56×56、stride2/pad1、iz/oz0、wz128、per-channel M/S30/RNE。新driver只可配新bit，probe校验三ID/ABI，GP单锁owner2bit、HP0最大16拍/4KiB拆分，done等待最终B。实测金样与原16帧同候选CPU完全一致，详见experiments/network_dw96_20260930/board_verification.json。后续匹配大小owned buffer修正尚待BOARD，不改变此ABI。

2026-09-30匹配大小owned buffer修正版已BOARD：三算子各固定3缓冲，共用一个mutex，不改变IOCTL或寄存器ABI；原整16帧特征/logits精确，证据buffer_board_verification.json。
