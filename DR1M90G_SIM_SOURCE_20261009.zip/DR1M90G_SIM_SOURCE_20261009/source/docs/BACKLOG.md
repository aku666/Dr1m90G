# Project Backlog

## 2026-10-09 单帧ASL转向讨论与仿真源码交接包

用户最新方向为单帧ASL英文24字母（排除J/Z），前一轮仅方案分析；本轮仅要求整理硬件接口/RTL/testbench/约束源码包。新24类模型、持续帧率和实体显示均未新增验收；原空间/时序/视频已有成果保持原证据边界，不自动继续旧动态词优化任务。

DELIVERY：[DR1M90G_SIM_SOURCE_20261009](C:/Users/16429/.codex/visualizations/2026/10/09/01a11f12-9dd9-7002-a5d5-ce9b311f58fc/DR1M90G_SIM_SOURCE_20261009/README_CN.md)。来自活跃副本逐文件哈希导出，包含当前0x42341910/独立0x42343410驱动、16项实际packet/weight、张量/量化参考、DWsplit集成RTL/SDC、单像素缩放及真实向量、双像素失败候选与相关日志。便携离线入口run_sim.py和check_bundle.py；本次最终仿真/依赖/哈希验收以包内verification为准。HardNPU内部RTL/周期精确模型未找到，不能把接口数学或PL模块仿真升级为硬核周期/完整SoC性能证明；厂商库与许可证不打包。

未上板、未写Flash、未构建原工程或覆盖基线，只有交付副本离线检查与本条文档记录。Git命令在受限环境拒绝访问，工作树HEAD元数据读得2685d5f4e21bb91b31a52dbde8527c59acd0964c；未创建branch/commit/tag。整体基线、原工程与外部快照完整性未全量复核，UNKNOWN。下一步为接收方据本包对齐新单帧模型，芯片周期/资源/时序待相应环境和实际证据，不因打包自动启动。

## 2026-10-09 工程汇总交付与双像素候选边界

- DONE/DOC：用户要求的全部工程成果及相关信息汇总至docs/ENGINEERING_COMPLETION_SUMMARY_20261009.md，包含20个实际存在的本地证据链接；不作为新增产品运行证据，目标保持active。
- CODED/SYNTH：双像素原数学缩放集成gate 46113 slices/156 ERAM/192 DSP；P&R/BIT/BOARD未完成。sim1长路径被截断，输入/参考读取失败，数值SIM无效，下一直接修复bench并重跑真实图。不能按其PASS标记宣称50/64fps正确。
- 当前整链有效速度仍约2.6fps；最新实时panic恢复待关联确认，质量/拒识和持续30fps未验收。已有未改动的单像素SIM/P&R及保存帧整链证据复用，不重做Soft/T01。

## 2026-10-09 T30-3固定原滤波数据通路

- DONE/SIM+整合SYNTH：四像素ISP→原sfifo弹性CDC→原滤波224输出已接现有uidbuf。两张真实原图100352像素零差；溢出/错误行明确拒绝；小图50176像素/200704B、448×56拍及槽地址通过。原NPU驱动/数学/PS/相机PLL不改，三槽保留区和完整B响应保留。
- DONE/CODED+PC：small_runtime1接原常驻识别入口，强制FST1 0x10006及224几何/AA22算法标识；CPU只复制小图并原归一化，三张完整原图对照451584浮点元素零差。无新板端速度/识别输出，不覆盖默认。
- DONE/P&R受约束时钟STA：47971 slices（91.41%）/156 ERAM/186 DSP；按本route输出网复用31个同步器第一级例外，最终SWNS+0.103/HWNS+0.024ns/TNS0。64.82%覆盖、外部MIPI RX不在clock summary，非完整IO时序证明；BIT/BOARD PENDING。
- 下一直接修复缩放输入服务预算：原camera_preflight2每0.1s5~6CSI/ISP帧，约50fps全量像素超80MHz串行处理；28.94fps仿真和单请求不证明帧内容量足够。先提升处理吞吐/确认行突发，不能用隐藏丢帧、扩大完整高清缓冲或失败板测代替。
- 下一实际板测仍先解决既有GP实时重叠故障。用户本轮重启回复引用旧Hard问题，已请求关联最新panic的恢复确认，确认前不重试；本轮继续有效RTL/仿真/综合实现，目标active。

- 独立pillow_aa_224核SIM/SYNTH DONE：三张不同真实1080p→224图，150528输出像素与PC Pillow零差；1834 slices/17 ERAM/12 DSP。不改默认、不宣称整工程时序或板端速度，P&R/BIT/BOARD PENDING。
- 128位四像素ISP的弹性CDC与受控小图FDMA已CODED/SIM/整合SYNTH；下一取得该候选实际P&R时序与板端图像/原模型输入比较。源端无下游背压，仍必须实测实际速率与是否溢出，不以仿真源代替sensor。证据integration_qualification.json；此前独立核sim1.log/build_core1.log复用。
- 故障板卡物理恢复仍PENDING，板测先验证GP互斥/实时重叠。全网30fps及独立质量未达，目标active。

- 总目标active。2026-10-09常驻32张真实保存帧/C128环已BOARD通过，两个窗口共4096特征及分类与独立CPU零差；一次加载，12181.133ms，单帧p95 380.135ms。实时重叠修复导入后触发异步SError/内核panic，实时16帧未验收，已请求物理恢复；确认前不重试设备。缓冲版6047.195ms/16与其他数学候选/原数学回退保留，持续10/15/30fps、独立质量未达到，显示DEFERRED。

### 2026-10-09 后续：共享GP冲突已确认，最小互斥CODED

现用sol_block34_dw_split_20261008/net_pl_control.v:96在任一PL任务pending/fault时拒绝所有写，包含0x140采集控制。新生产者在PL作业期间暂停/恢复采集确有接口冲突；是否为本次SError原因仍INFERRED，未板测确认。

下一候选更新为live_input4/resident_resume4。gp_write_gate.py仅在实时入口使完整FRONT96、两DW144、DW16调用与四处采集控制写互斥；CPU/只读/Hard独立寄存器继续重叠。实际PL异常后拒绝进一步GP写，保留原DMA/完成/失败pin；锁等待计时进入结果，不包装为吞吐提升。未改bit/驱动/数学。生成Python编译通过、BOARD PENDING，归档哈希见本stage qualification.json。

恢复后先运行probe_gp_gate.py /run/gp_probe1.lock（仅Linux跨进程文件互斥/失败拒写、零设备访问），再TRACE/CAPTURE_FIRST采集对照→真实重叠→新输入独立CPU比较。WSL查询返回REGDB_E_CLASSNOTREG，无可用本机Linux环境，不安装系统，probe未运行。用户新物理恢复确认仍PENDING，未知设备不重试，总目标active。

## 2026-10-09 常驻C128环接续

experiments/sol_resident_ring_20261009：最小stream_consumer回调复用通过的逐帧入口、bit/驱动/冻结模型，未改量化。一次初始化706.840207ms，32张不同真实保存图像各算一次，512 Hard START、FRONT96 32、DW144 64、DW16 32，Soft/V4R硬件0；其余空间/残差/真实C128 TCN由CPU。64x128环32768B；两个完整16帧窗口原观察跨度3.011690460/2.825742328秒，分类不重复空间计算。两段4096特征与分类对独立板CPU零差，第二段实际新算参考。处理12181.133341ms，单图中位377.262259/p95 380.135433ms，非实时持续fps/自动动作结束，质量NOT_CALIBRATED。

只读相机预检camera_preflight2.log已确认CSI/ISP增长、I²C历史error false。实时live_input1相对导入preprocess失败，未START；live_input2已修复。核验ABI0x42341910/phase0/writes0/irq0/work0/MODEL_READY1后旧模块guard PASS卸载；修正版新实验CPU0 PID1066 python3异步SError code bf000002、PC4b7f6c，Linux panic。host串口日志live_run_serial4.log保留；具体START数/首帧完成及根因UNKNOWN，不认定并发或DDR。32原始结果尚未备份，panic后暂不能取回；host运行/独立零差核验日志可用，证据边界明确。

实时重叠DOING/物理恢复PENDING，已请求用户，确认前不重试未知DMA。下一候选live_input3/resident_resume3 CODED/生成Python编译通过、BOARD PENDING：仅对实际失败访问加少量可选UART阶段标记，RESIDENT_CAPTURE_FIRST=1先运行模型仅加载的采集对照，通过后再重叠并以新输入独立CPU验收。restore_resident.sh只恢复文件，不加载模块或START；复用USB span编译包、现有模型和工具，不新增驱动/bit。CPU单图约380ms仍超33ms；T30-5数据条件不变，不以排队或弱样本称30fps/质量达标。

HEAD实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空，无提交；整体基线/原工程/外部snapshot完整性UNKNOWN。总目标保持active，显示延后。详情见docs/records/worklog/2026-10/2026-10-09-sol-resident-ring.md。

## 2026-10-09 本轮实际验收与下一任务

- DONE/BOARD：sol_block34_buffer_20261008冻结模型不变，真实输入155648B、输出454656/28672B；ABI0x42343410/0x42341910目标编译、全活动span同步与guards保留。完整块三次逐字节零差62.849/57.084/56.907ms；同真实16帧256 Hard/32 PL DW144/FRONT96和DW16各16/Soft和V4R硬件0，2048特征与独立CPU参考及分类零差。6047.195ms较同数学旧6393.125ms少345.930ms；初始化/输入准备单列，非持续fps。
- DONE/BOARD：原首段CPU batch1/2/4/16同真实16图对照，节点/权重不变且输出零差，每图中位31.942/30.208/30.014/29.683ms，未确认小批量提速。
- PARTIAL/T30-4：prepare_framewise.py接已通过整链，一次加载参数/会话，完整空间每真实图各算一次，0/6组在已释放边界交替，无新增状态机/线程/驱动。6158.307ms、2048特征/logits零差、每图中位381.819ms/p95 386.221ms；逐帧可运行不等于特征环/常驻多窗口/真实持续fps完成。它慢于批量6047.195ms，不接为吞吐默认。
- CODED：restore_span_from_usb.sh复用已保存编译产物的冷恢复文件入口，不加载/START；完整冷启动重放PENDING。主/逐帧原始证据与实际runtime均已取回，USB BLOCK34_SPAN_20261009_1 sync/RO。
- 下一直接任务：把已有逐帧计算接有限常驻/真实C128特征环，保留完整模型与训练时间跨度、每帧只算一次；CPU中段约151.8ms/图和完整前块约57ms/图已明显超预算，不继续无限堆低收益层。按T30-5触发条件选学生/量化路线；CSL-500训练/独立验收数据未提供且不代下载，质量NOT_CALIBRATED，旧12段仅回归。
- 成功卸载/模块空，boot39c9c0f4-6301-4a36-81eb-1aab7a309a67，无待重启；目标active，不暂停。HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached空，无提交；整体基线完整性UNKNOWN。详见docs/records/worklog/2026-10/2026-10-09-sol-block34-span.md。

## 2026-10-08 20时后：BLOCK34成本分解与复制修正版已实际接整链；无确认整链收益

sol_block34_cost_20261008/run_cost.py复用已通过块fixture/bit/驱动，六Hard/两PL DW输出零差且正常释放；单块69.047ms。Hard SET输入1.926、RUN12.693、export1.211、release2.228、cold状态0.322ms，PL DW host18.421/9.337ms、CPU Add3.328ms，其余约19ms用户态处理。CPU现有CRC451584B约1.867ms/次；不把剩余全部归因CRC或AXI，设备核心和调用耗时已分清。

修改prepare_io生成同ABI同步输入直接传连续numpy指针、输出copy_to_user直达独立numpy数组、原CRC/释放保留；用户数组不是DMA别名，SET_INPUT仍由内核同步复制并持有自己的DMA/ref。单块63.596ms/逐字节零差，仅两次fresh单样本，不作持续提速结论。prepare_main_io把相同改动直接接原head23全16入口：全部2048特征/C128、前段tail_inputs零差，368 Hard/new112、原PL各16。整链5804.641 vs5803.249ms，未确认收益，NOT_ADOPTED，保留此前5803.249ms可运行候选及原数学6354.254ms回退；不包装成核心NPU提升。

两次块和整链已guard PASS卸载，boot00e3dee3-402f-4f7b-86ff-1b299862a7f9/modules空，不需要重启。USB BLOCK34_IO_20261008_1已sync/RO，host board_evidence1.tgz240837B/SHAa684409125ba10b7f0fa35a5db7671c339facb9b819998d55ed5b2d5c4eeabc5，实际IO runtime与host一致。无新bit/驱动/模型/量化/Flash/原工程构建；新头量化独立质量仍未通过，持续10/15/30fps未达到。下一仅针对BLOCK34超过33ms的实际DMA搬运及固定缓冲全span成本做最小修正，复用当前成本结果，不再堆尾部低收益层。

AGENTS/status/backlog/日志及施工单相关T30-2/5已读。整体基线与外部snapshot完整性UNKNOWN。HEAD仍detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff实查空；git status因Git LFS/msys启动0xc0000022失败，不能称工作树干净，无提交。目标active，显示DEFERRED。

## 2026-10-08 20时后：Conv18接原16帧入口，BOARD零差，5803.249ms

sol_head_pw_20261008/main_candidate/run_main.sh已实际完成同真实16帧。尾部320→1280 PW由Hard新增112 START执行，原Hard256及PL FRONT96/BLOCK34/DW16各16保留；DW17/剩余空间、池化/128D投影、真实C128仍CPU，Soft/V4R硬件0。新层实际七packet覆盖全部1280通道，权重与厂家CMA逐字节一致；倍率26518/19，Load/Unload PASS、Load-only Execute未调用。新ABI0x42341720/head23_fixed、23槽，分组0/6/16仅冷边界软件切换；原16包/数学保持，weight padding66560/allocated69632，真实DMA/CRC/guard/失败pin保留。

完整2048特征/C128与板端实际整数尾部CPU参考零差，前段真实tail_inputs与上一版逐字节相同。整链5803.249 vs5872.753ms，只减少69.504ms/1.183%；尾部652.111→536.905ms，新Hard client141.877ms。普通逻辑层每图Hard7/PL5/CPU23，分片START另计。旧12段仍9/12、分类12/12一致，但特征相对原数学有新增量化差异，独立质量/拒识NOT_CALIBRATED、新量化NOT_ADOPTED、不覆盖默认。约2.757图/秒仅单保存窗换算，非持续吞吐，仍未达到10/15/30fps。

Hard及PL guard释放/正常卸载，当前modules空，无待重启。USB HEAD23_HARD_20261008_1已保存并sync/RO；host证据429612B/SHA0efe78b1b5a0f837bab5a1f07a70746e5372085a8211b6e1a65b4df9689cee55，ko SHA6601749778a29ca6299c63e0a510838260bd642acf2adeecdb5eb5b4f50d2be8，实际runtime与host一致。历史Module.symvers/clock-skew警告保留，无新bit/PL资源/Flash/原工程构建。原数学6354.254ms回退入口保留，整体基线/外部快照UNKNOWN，HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached空，目标active。

下一回到未消除的BLOCK34约66ms/图：已通过Hard+PL DW路径核心约22ms而完整块约63ms，直接测其输入/输出/释放开销后修复主链搬运，不继续只堆低收益尾部层。sol_block34_cost_20261008/run_cost.py已接已有固定块入口，仅追加本次必要阶段计时，复用fixture/原驱动/bit；实际运行PENDING。显示DEFERRED。

## 2026-10-08 20时 T30-2最终CPU尾部接入DONE；Conv18迁移DOING

- DONE：固定16尾部及复用NEON17，无层/权重变化；原数学6354.254ms、连续12/13块5872.753ms，同真实16帧features/logits各零差。两模块已正常卸载，无待重启。
- 实际入口/证据：sol_tail_batch16_20261008/candidate/run_original_math.sh、run_main.sh；qualification.json和board1，USB新目录已sync/RO。原数学旧入口保留，新量化NOT_ADOPTED；独立质量/拒识与持续fps未通过。
- 下一唯一实现：真实尾部最大PW Conv18 288.329ms/16；sol_head_pw_20261008实际模型与前后CPU图CODED，Load/BOARD/质量PENDING，直接复用现有厂家capture并接原固定owner。不从Soft/时序资格、全量profile或视频重新开始。
- PL BLOCK34约66ms/图仍必须消除；当前小幅收益不等于30fps，按T30-2/5条件决定学生/QAT，不能无限低收益迁移。

## 2026-10-08 19时：第12→13块连续Hard/CPU整链BOARD零差；CPU向量版5979.310ms

新增可运行入口 `experiments/sol_block13_hard_20261008/main_candidate/run_main_neon.sh` 已运行同真实16帧（输入SHA4701269159219088f9f0cf17a1a16872b3b81c6403bbc7c383d550fb9edc8113）。Hard执行第12/13块四PW与原H4/H5，256 START/两新块各48；PL FRONT96/BLOCK34/DW16各16；两DW576、残差、其余空间和真实C128 TCN为CPU，Soft/V4R硬件0。全部2048特征及logits与相同目标固定16/NEON9、独立整数CPU参考零差。正常guard PASS释放/卸载，当前modules空，同boot00e3dee3-402f-4f7b-86ff-1b299862a7f9，无待重启。

连续两块scalar版6184.527ms，比第12块6212.008ms只少27.481ms；并非增加Hard层就显著提速。随后CPU NEON只向量化DW八个独立像素累加，保留原S30 ties-even舍入/权重/边界/残差数学；两块各全0/全255/随机张量与scalar及整数参考逐字节零差，DW由12.631/12.601降到6.133/6.138ms。接入整链5979.310ms，较本轮scalar减少3.318%，较原数学缓存6462.317ms减少7.474%；为单保存窗，非持续fps，包含CPU优化而非全归NPU核心。CPU reference耗时含未优化整数矩阵和初始化，不作生产性能基线。

独立ABI0x42341620、/dev/space16_b1213_fixed、16常驻槽：0..5循环0，原H4/H5为6..15循环6；冷态无input选0/6，输入边界0/2/3/5/6/12。12→13直接UINT8，无中间float转换；原十项H4/H5 packet/weight不变，既有真实DMA/CRC/guard/完成/超时pin保留。CPU before12 1237.847ms、after13 529.479ms、128D尾部765.083ms，PL BLOCK34约66ms/图仍阻塞30fps；下一沿已有节点profile选择before12最大实际PW，不再重做全层资格。当前新量化与原数学有max0.655770特征差；旧12段9/12、12/12同分类，独立质量及拒识NOT_CALIBRATED，新量化NOT_ADOPTED，默认原数学入口不变。

修改位于本stage：prepare_main/package_main、batch_bridge、cpu_gaps_neon/probe_gaps、固定owner/入口/CPU参考/后验验证；无需新bit/布线。USB BLOCK13_HARD_20261008_1保存原始两轮结果、CPU参考、实际ko/runtime并sync/RO，host已取回board_evidence1.tgz（42536B/SHA37a3bb68cb1acf695175d464c502dcb2ad9b6e7499971e9abf54051eb228e074）及compiled1.tgz（239972B/SHAa8b118992e49dd1147be19ec0a2ce4e6e373e8b0b6b144971ac82b5aea09ac3e）。实际ko SHAbfd7a01038b0b756e374341690cb76c70594fb969cc1add42561de8c2bd5fb4c；NEON so SHA2c1a7b94d2f668716123300d457c1f1548ef1132e218f79e45a8f2d76783ae7b；完整恢复顺序/产物/分工见本stage qualification.json。全量基线/外部快照完整性UNKNOWN，本轮未写原工程/Flash、未构建新bit、未提交；实际HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空。目标active，显示DEFERRED，持续10/15/30fps尚未达到。

## 2026-10-08 18时 T30-2第12块接入BOARD DONE；第13块DOING

- 厂家Load NULL TensorInfo实际崩溃DONE：只补ONNX value_info，原14×14两模型Load/Unload PASS，真实三包/权重已捕获。停止无收益16×16几何尝试。
- 新块完整实张量BOARD零差：两Hard PW/三START＋CPU DW/Add；Python DW版105.320ms，复用C gap版29.141ms，均完成释放。非全块NPU。
- 原16帧主链接入BOARD DONE：ABI0x42341310、一个13槽Hard所有者，共208START/新块48，PL FRONT96/BLOCK34/DW16各16、CPU其余空间/真实C128，Soft/V4R硬件0；6212.008ms，同批处理CPU 2048特征/logits零差。相比原数学缓存6462.317ms单窗少3.873%，同时含缓冲开销变化，非持续fps。
- 初次tuple解包实际软件错误DONE：两Hard已完成释放，COLD/flags513确认后guard卸载；修正后整链通过。默认未覆盖；12段旧弱样本仍9/12、标签12/12一致，独立质量/拒识NOT_CALIBRATED。
- 下一具体运行：复用相同几何与主入口，迁移第13块并串接其真实张量；当前before12 1237.637/after12 866.048ms，CPU DW约12.6ms/图仍可优化。第13块真实Load/Unload PASS/Execute未调用：PW包2248/584与648B、倍率23347/20和17608/23、权重与模型一致；12→13直接整数串接CPU完整128D/C128回归仍9/12、分类12/12一致，独立质量未通过。下一复用固定所有者接连续两块并运行同真实16帧；尚未第13块BOARD。
- USB BLOCK12_HARD_20261008_1已sync/RO保存输出、纯CPU参考和实际ko/runtime；详细数值与恢复包顺序见status18时及本stage qualification。无新FPGA资源/bit、无Flash/原工程构建。

## 2026-10-08 17时 T30-2原整图接入BOARD DONE；CPU第12块迁移DOING

- 原模型缓存DMA16保存帧BOARD DONE：原Hard160、PL FRONT96/BLOCK34/DW16各16、CPU Add/其余空间/真实C128时序；无新量化，features/logits与相同输入原BOARD零差，6462.317 vs6782.880ms。仅单次窗比较，不能称持续fps。成功安全卸载，无待冷恢复。
- 新四Hard层量化整链BOARD DONE：256 START、PL DW14432、FRONT96/DW16各16，6393.125ms。对相同板端批处理/NEON9 CPU参考零差；PC不同执行路径的最初差异原件保留。较原数学缓存路径仅少69.192ms，质量未验收，不切默认。
- 实测after_block4仍约2433.7ms/16、CPU特征尾部约0.77秒，复用旧profiling选择第12块普通PW；两模型CODED/model_contract PASS，下一Load-only实际厂家capture→CPU候选128D/真实C128回归→收益成立才接原入口。DW/残差先复用CPU，无新PL引擎。packet/BOARD/独立质量PENDING。
- 两运行包、依赖overlay、实际ko与原输出/验证结果已USB新目录保存并取回紧凑证据；见status17时段及cached_main/qualification.json。原bit/数学/回退保留，不重做T01/Soft/视频显示。

## 2026-10-08 16时后 T30-2完整C32块BOARD DONE；缓存DMA与原16帧接入DOING

- 原厂家C32六PW＋两PL DW＋CPU Add整体零差/全部释放，285.336ms；厂家CRP低有效bit12启动复位后通过，唯一根因仍UNKNOWN，停止盲目改内部tile。
- 手改4×2仍work2/START1超时且没有输出写回，NOT_ADOPTED；完整日志USB/host保存，用户冷恢复已确认。
- 缓存DMA候选目标编译/BOARD通过，validate77.932ms；product同实例3次69.472/63.020/63.030ms、全零差，保留实际守卫/CRC/完成和失败pin。USB BLOCK34_CACHED_20261008_1；不是持续fps或量化质量验收。
- 原16帧接入候选CODED：sol_block34_cached_main_20261008 ABI0x42341610、256Hard/32DW144、真实C128 CPU TCN，目标编译与同候选CPU128D/logits比较DOING；默认保持最快已通过原路径。整链实测收益PENDING。

## 2026-10-08 早期历史 T30-2独立PL DW BOARD DONE；Hard大图实际超时修复DOING

- 两PL DW数值零差：DW3 device15.440370/client34.494990ms，DW4 device6.023610/client27.666720ms。复用共享引擎，无新增计算资源；完整块收益仍PENDING。
- 原C24、精确C32补齐、14行分片均首次Hard超时，后续层未执行。H4原作业控制PASS/零差/释放；14行已改变3575B全部正确，但109112B不匹配，不能称完成。三种变体未修复，不继续盲换外部形状。
- 本轮12槽ABI0x42341400/目标编译/真实厂家packet与CMA权重/CPU拼接已执行；完整失败证据与模块已USB独立保存。用户确认物理恢复后，新boot0413b429-e904-4fbd-832e-8855da315a4e/modules空已读；不重试旧失败实例。
- 下一直接交付：完整六PW+两PL DW+CPU Add的4×2内部tile派生候选，一次块输出/耗时，再接原保存16帧入口。只改明确的tile字段、不改变模型/量化/默认；BOARD与质量/整链速度分别验收。完整块根因UNKNOWN。

## 2026-10-08 11:45 T30-2同真实16帧CPU候选128D/真实C128参考DONE，BOARD WAITING_COLD_RECOVERY

- 用原真实16输入而非弱数据新采样，候选CPU128D和exact C128已实际跑通；device0，PC空间2001.674ms，不是BOARD性能。原默认相比1159特征不同/max2.418784，logits max0.682688，标签仍过敏/得分65.713%→49.217%，质量NOT_ADOPTED，不切默认。
- 后验verify_main/input恢复入口直接服务下一次原整图BOARD，7KBCPU参考包USB保存RO。原输入1.54MB已完整取回/哈希一致；40s初次观察超时按真实大小延240s修复，UART响应正常，不当作NPU故障。
- 同一物理恢复条件连续三阶段未变化；实际boot_id仍旧、失败模块ref1固定，不能重试设备。bit/PL/合并Hard/原整图入口/CPU金样均已具备，下一只需实际冷恢复后运行，不制造更多准备项。目标未完成/不自行paused；阻塞状态以goal工具为准。

## 2026-10-08 11:25 T30-2可选整图16固定Hard作业接入CODED/目标编译DONE

- 新BLOCK34六PW+原H4/H5十作业由同一个/dev/space16_fixed ABI0x42341600拥有；原十个packet/weight身份一致，不同时加载两个Hard驱动。保留原固定16 CPU batching：前段组0..5循环16帧→软件冷边界选择组6→H4/H5循环16帧。默认入口不改。
- 原整图入口独立候选、层分工/计时/START统计、实际saved16运行和冷恢复文件脚本CODED。合并驱动板端CPU编译DONE，包与编译证据/小overlay已USB新目录保存RO；CLI导入、Python编译及shell语法通过，不等于BOARD计算。
- 计划256 Hard START/32 PL DW144；实际本轮0 START，完整128D/真实C128候选BOARD数值和收益PENDING，量化NOT_ADOPTED。当前实际失败后的物理冷恢复仍待确认；目标active。下一两DW/完整块实测后直接用本入口做同16帧整链，不重新包装大型CPU模型或重做T01。

## 2026-10-08 10:58 T30-2 Hard PW＋现有PL DW连续块DOING

- CPU两DW/一Add真实张量BOARD零差DONE；53.222/12.065/3.413ms揭示CPU gaps已比旧PL完整块更慢，转复用既有DW核，不继续优化该CPU整数桥接。
- PL两DW模式CODED/SIM/SYNTH/P&R/BIT DONE（11:06），原全BLOCK34模式SIM回归零差；actual physical46932 slice（89.43%）/150 ERAM/174 DSP，无新增计算核。最终STA SWNS0.108ns/HWNS0.023ns，TNS0；coverage63.52%及继承ERAM异步reset警告保留。bit4052202B/SHA1e4005f6eaccb50c9bc4af5738732cdc002c0acd2a9943a983f6339f9c661ac8，未下载，BOARD收益PENDING。
- 匹配control0x60002、G/H job0x70001/0x80001驱动目标CPU编译DONE/未加载；固定完整块运行入口可选PL DW，补丁及编译产物USB保存RO。先复用已有真实tensor测两DW，再测六Hard作业完整块，不新建框架。
- 首次Hard空闲拒绝后的模块/DMA仍固定，等待实际冷恢复；没有新START，目标active。默认16帧6767.772ms不变，质量候选NOT_ADOPTED，显示DEFERRED。

## 2026-10-08 10:22 T30-2连续Hard PW候选DOING；等待实际冷恢复，goal active

- 原整图/真实C128/无屏相机T30-1成果保持，默认6767.772ms/16；无本轮新增速度收益，显示DEFERRED。
- 四层厂家加载捕获DONE（无真实Execute），紧凑19/19/18行候选及CPU全PW拼接零差DONE。真实固定m/s完整128D+C128回归9/12、10/12同旧分类，未采用；group32降为8/12 REJECTED。旧prepare块四舍五入误差仅早期历史，已改floor参考。
- 固定6作业ABI0x42340100驱动及两CPU DW/一CPU Add桥接CODED/目标编译/加载分配DONE，BOARD计算未完成：普通Linux预复位work2→work3，空闲保护reason14，作业写0/START0。模块及DMA固定；日志取回、USB新目录候选/编译产物/失败证据sync/RO，已请求物理冷恢复。未在未知状态重复提交；目标保持active。
- 等待期间：修正运行尝试/实际START统计、复用编译产物的冷恢复入口、实际CPU gaps张量核验直接服务下一次运行。当前Windows gcc DLL重定位失败，未宣称PC C验证通过；已采用现有板端成功编译的CPU库做无NPU访问核验。
- 下一实际确认后：已通过临时启动配置→恢复编译候选→连续块真实数值/耗时→仅有质量及整链收益后接默认。T30-3/4/5保持PENDING/PARTIAL，不以本轮包捕获或CPU参考称30fps。

## 2026-10-07 22:34 30fps无屏主线：T30-1 BOARD DONE，T30-2 DOING

- T30-1 DONE：off不渲染/打包/保存PNG，真实16帧入原neon9混合入口；第一窗同输入CPU128维/logits零差，第二窗统计修复后全流程rc0，推理6767.772ms/采集到分类11134.850ms/含装卸13010ms。无Soft/V4R实际启动，Hard160和三个空间PL块各16；质量NOT_CALIBRATED、非持续30fps。
- mapped实际同帧张量0差但2407.850ms，原copy+decode+resize约203.578ms，速度REJECTED，copy保持；不重复调这个低收益映射路径。摄像头已断电接回并真实恢复，当前采集/显示关闭、模块空、无待重启；此前UNKNOWN为历史。
- T30-2 DOING：解决BLOCK34设备66.159ms/图以及CPU剩余普通Conv。四个真实PW Hard标量候选/CPU整数参考已生成，单真实块边界RMSE比现有量化更大，尚未采用；下一整链任务回归、vendor包捕获和连续块实测，shape/packet/Hard BOARD PENDING。不能用model checker代替硬件通过。
- T30-3 PENDING：真正抗混叠小图写DDR，复用共享DW/资源；算法/ISP变化单列质量，mapped慢已给明确转向条件，不把缩小动作跨度当提速。
- T30-4 CODED/OFFLINE PARTIAL：三保存窗CPU会话复用已跑通原CPU桥接+真实C128分类/零差，BOARD收益PENDING。尚无常驻DMA、按帧C128环、采算重叠或稳定10/15/30fps；当前2.36仅单窗推理等效。
- T30-5 PENDING：独立中国手语/负样本质量、拒识、真实V4R同条件收益及最终长运行。既有12段9/12/OC16资格复用，不下载CSL；现未达到学生路线触发所需最大块迁移及一次流水实测。
- 显示DEFERRED：用户排线损坏，frame_align P&R已终态，未继续STA/BIT/BOARD；不恢复实体显示任务。完整新证据及最终小包已USB保存RO，见status/本次headless worklog。

## 2026-10-07 15:44 DSI长期循环错位实际FAIL，定点修复DOING

15:52最新板端状态：主要15999B运行补丁此前已保存并确认USB RO；后续小验证helper传输未确认成功，COM4只读存活命令也无返回。没有新NPU START，原因UNKNOWN；已经请求实际物理断电上电，确认前不再提交设备操作。helper最终USB挂载状态UNKNOWN。goal仍active，本地P&R/时序收尾继续；以下无待重启描述是更早采样状态。


- 识别链实际数值/9.038%CPU DW收益保持；PW CPU原型12.094ms慢于ORT11.028ms且15673值不同，BOARD CPU拒绝接默认，NPU START0。
- 用户最新实体屏持续上下循环移位FAIL；此前三个短期窗口不再视为长期稳定。当前显示缓冲字节精确/capture0/display1/modules空，具体FIFO缺数因果INFERRED。
- 新frame_align在原扫描源SIM复现并修复缺数后的持续位置偏移，旧429错位/新0，11完整帧/2恢复；SYNTH43142/150/174，P&R会话74111正常运行。候选ABI1.5增加本次缺数/对齐Gray计数，PS/模型/驱动/独立DDR区域不变；BIT/BOARD/实体修复PENDING。
- 下一：完成实际布线及STA→合格候选临时下载前请求真实冷恢复→复用同一结果图，在显示负载下观察实体和事件；不重做T01/Soft资格。
- 采集mapped resize可选入口CODED/OFFLINE数值精确，BOARD及收益PENDING，copy仍默认；显示修复优先。新小补丁USB已保存RO，完整产品速度/质量/长期运行未完成。

## 2026-10-07 15:09 原float32九层CPU DW默认主入口BOARD DONE

- 同16实际输入、同启动/bit/显示1两对交换顺序：推理中位7489.169→6812.292ms（减少9.038%），含输入/初始化8155.270→7439.620ms；最终128D特征字节精确/logits0差，CPU空间4750.432→4091.834ms。新增九层CPU向量DW/窗计144，原Hard/PL调用保持。默认neon9已采用，ort显式回退；先前默认ort描述为历史状态。
- 四层最初数值拒绝DONE：特征122差/max0.0155783；补外部算子固定输出shape后CPU尾部与最终整链均零差，未改计算库/权重或量化。九层固定形状扩大已直接接主链，未新增常驻PL、NPU资格或调度框架。
- 默认真实相机→识别→DSI更新DONE：采集3639.133ms、推理6802.985ms、采集至分类11642.512ms、屏幕缓冲发布14360ms。新真实16同原版回放features/logits0差，16复制0拒绝、两个模块安全卸载。屏幕沿同已确认正常的实现，本轮内存更新PASS；不称新光学测时、不同画面不作为视频速度比较。质量/拒识NOT_CALIBRATED。
- 小运行包30995B保存及当前安装恢复DONE，下一fresh启动先旧camera setup，再USB float_dw9_cpu_stage/restore_screen_overlay.sh；跨冷启动整链复跑PENDING，不能把同启动恢复写成已冷启动验收。完整证据board_evidence_1.tgz SHA72d38905...已sync/RO；host sol_float_dw9_cpu_20261007/{board_mixed_verification,board_live_verification,board_tail_verification,board_runtime}.json/tgz（按实际后缀）。当前capture0/display1/modules空、无待恢复，goal active。
- 下一PENDING：用原float32参数比较第12块点卷积投影CPU实现和原ORT，只有真实收益及数值验收后接原入口。高速响应、质量/拒识及更长连续运行仍未完成。

## 2026-10-07 14:36 CPU原float DW混合主链BOARD DONE，后续热点PENDING

- 两个交换顺序同真实16帧主入口对照DONE：ORT中位7457.108ms→neon7246.816ms，减少2.820%；features[1,16,128]字节精确、分类logits零差，CPU float DW计32/窗，原硬件计数/驱动/模型权重保持。首次ORT初始化较冷，不将含初始化中位差全归因算子。候选显式neon可用，默认ort保持；中间CPU浮点非逐字节事实仍保留。
- 真实相机→候选→DSI DONE：采集3620.396ms/推理7251.590ms/采集至分类12158.208ms/屏幕内存发布14930ms，16复制0拒绝、模块卸载成功；同新输入原ORT回放最终数值零差，用户实体屏“正常”。不同画面没有视频整体提速对照，识别质量与拒识仍NOT_CALIBRATED。
- 证据sol_float_dw_cpu_20261007/board_{mixed,live}_verification.json，USB完整board_evidence_1.tgz SHAc3962e40...已sync/RO。当前匹配alignreset临时Linux/capture0/display1/modules空，无待恢复、goal active；此前14:17 PL未核验状态已被本轮下载/主链运行替代。
- 下一PENDING：复用现CPU NEON实现到第5/6块C192/28×28，直接服务下一次同16帧整链运行；不扩展新常驻PL引擎、资格框架或重复全量验证。完整产品速度/质量/持续运行未完成。

## 2026-10-07 14:17 原float DW CPU替换候选DOING

- 原16帧混合空间/CPU时序/实体DSI三窗仍已BOARD通过，新CPU候选未改默认。复用已有节点profile，12/13 DW向量实现及图内固定C576/H14算子CODED/BOARD CPU单层DONE；原float32参数不变，单层字节精确/max0，9.256→2.714ms。
- 完整CPU尾部同保存block4张量重复16 BOARD：3077.390→2876.171ms，但float max1.132488e-5、非字节精确；不视为整混合链数值/收益通过。一次尾部CPU实际32层计数DONE，主入口显式library/ort-neon选择CODED，默认ort保持。下一匹配bit/DTB恢复后，以同真实16帧跑原入口ort与neon，检查最终features/logits及实际收益，不重新资格NPU。
- 临时父init shell因遗留set -e及ls路径失败退出，用户已实际冷恢复；正常Ubuntu/gcc/CPU编译成功、模块空。串口ChildShell修复已接，复合命令不再改变父进程errexit。当前正常Linux/PL身份UNKNOWN、无待物理恢复，目标active；候选/实测USB保存RO，证据sol_float_dw_cpu_20261007/{board_layer_verification,board_graph_verification,board_counter_check}.json。

## 2026-10-07 真实16帧采集→混合识别→实体DSI三个窗口DONE

- alignreset临时上板DONE：用户实际冷恢复、JTAG100%、匹配保留DTB/GPIO/setup/overlay通过。固定画面用户确认“不分块”，三个真实16帧窗口原位更新后用户确认“正常”；显示对齐与连续三窗口验收DONE。每窗rc0/16复制0拒绝/Hard与共享PL成功卸载，无待物理恢复，goal active。
- 同新bit第一窗实际输入CPU对照DONE：features[1,16,128]字节精确/logits零差，混合7472.811ms/CPU16428.557ms。三窗混合7472.811/7492.481/7493.611ms，采集3848.488/3766.461/3802.763ms；整窗至屏幕内存提交16470/15230/15280ms，不称光学延迟。证据sol_camera_dsi_result_20261006/board_20261007/alignreset_three_windows.json，USB完整证据已保存并恢复RO。
- 当前下一热点PENDING：同候选CPU空间约4.74秒/16帧、复制/预处理约2.8秒；先保持模型数学寻找真实收益。显示渲染CPU实测222ms、打包38ms、PNG默认318ms/无损level1为155ms，仅微基准，不称整窗收益。质量与拒识仍NOT_CALIBRATED、CSL-500暂不下载；三窗预测无动作真值。更长持续运行/产品质量验收未完成。

以下13:06等待项与此前DOING仅为历史，已由上述恢复及BOARD结果替代：

- 当前WAITING_HUMAN_COLD_RESTORE：goal blocked（13:06工具实返）；本轮代码/仿真/P&R/STA/BIT及软件准备完成，已连续三个goal turn待同一恢复确认。回复已重启后继续BOARD及三个实体窗口，无新任务扩展。
- 最新实体结果PARTIAL：scanfix R_SYNC0版BIT/临时Linux/显示提交DONE，final+.100/+.023ns、46182/150/174；用户见中文和图像，但报告四象限互换，显示缓冲读回精确，完整显示验收FAIL。dsi_scan_start起点对齐CODED/SIM DONE（原时序3相位9帧，旧接法35/40失败），SYNTH DONE43013/150/174，P&R DONE33670但最终STA reset recovery失败；最小摄像头本地复位释放CODED/SIM/SYNTH/P&R/STA/BIT DONE，alignreset物理46194/150/174、final+.102/+.024ns/TNS0/覆盖63.50%、34端口44pad一致；新bit SHAbffe38f89114d913d1f4b41417da4342a979eb9e86376d7958b96e118333ff0a，已请求实际冷恢复，收到确认后上板→固定真实图不分块→三窗口更新。原位更新和整窗至显示提交时间CODED，不称已BOARD；最新脚本及居中真实结果帧已保存USB screen_stage，恢复脚本覆盖安装最新入口，不覆盖旧证据。
- 最新预览模式BOARD DONE：仅缩小保存PNG，16张模型输入保持；两次原实时入口13.256/12.114秒，第二次真实脸和手输入采集3.556秒/推理7.377秒，复制拒绝0。第一窗同CPU特征字节精确/logits零差。该采集/识别运行时首版显示0；后续scanfix BIT/BOARD已有内容但四块错位，alignreset BIT已合格待冷恢复。下一临时启动→同一真实结果图→完整实体确认。
- 去除RGB同模式整图复制CODED/BOARD CPU微基准DONE：真实1080p图16重复、交替两对1555.037→1448.166ms，张量byte exact，约107ms收益仅限预处理。已接采集package/USB保存，完整真实窗口收益PENDING，模型数学不变。
- 原--capture-fdma入口默认freeze-copy：16帧采样预处理约3.33～3.44秒，含无损PNG/NPY约6.53～6.58秒；三个窗口复制拒绝0、采集至分类15.22～15.26秒，均正常卸载。freeze16独立真实输入features字节精确/logits零差；保持模型、预处理数学及NPU驱动。
- 实测修复：Pillow raw解码替代大NumPy颜色拷贝；PNG移出采样并level1；结束当前帧及B响应后停止循环槽重写，复制仍核验代数。当前约4.6～4.8个模型输入帧/秒，稳定8FPS和更低整链延迟PENDING。生产显示可另减少大PNG落盘，但不将漏采/缩短窗口当提速。
- DSI P&R/STA/BIT DONE：同placed DB恢复，34原管脚一致、47127/150/174，final+.034/+.021ns，覆盖63.52%。实体屏DOING，下一匹配临时bit/DSI no-map DTB→既有真实结果图→本次真实结果。
- 质量与拒识NOT_CALIBRATED，屏幕连续三个窗口PENDING；既有C128资格保持，不重做NPU/Soft/T01。goal active，无待恢复，无Flash/原工程构建/数据下载/提交。

## 2026-10-06 真实帧与原16帧入口DONE；实体DSI结果DOING

- 真实1920×1080单帧取回DONE；原版清晰实时对照保持DONE。先release_dw16_reset再GP读的启动修正实际PASS，原首次挂起根因仍INFERRED。
- 实际16帧采集→原混合入口DONE，features[1,16,128]字节精确/logits零差；7476.559ms，含输入/初始化8588.597ms，同候选CPU16363.241ms。模型输出咳嗽49.748%，NOT_CALIBRATED，不是有真值的识别质量验收。Hard160、三个空间PL各16、CPU Add16、CPU direct时序；Soft/V4R硬件0，本次未改模型或NPU驱动。
- DSI固定结果DOING：原扫描/屏幕配置/TX接独立4MiB显示槽，实际结果1024×600已生成；综合42973/150/174通过，P&R会话13666运行，STA/BIT/实体屏PENDING。下一合格bit＋新显示保留DTB→固定结果图→现场屏幕确认。
- 采样时间PENDING：本次16帧采集含预处理/PNG31425.064ms，接受间隔不均，非8FPS。实体结果后测复制/丢弃重试/预处理/PNG各实际开销，先移出热路径PNG保存，不能以隐式跳帧称等间隔动作窗口。
- 实体屏三个连续窗口、质量与拒识仍PENDING。模块已全部正常卸载，无待用户物理恢复；无Flash/原工程构建/CSL下载/提交。目标工具当前paused，本轮结果不改变其状态。

## 2026-10-06 原版实时对照DONE；受控PW32采集DOING

当前更新：管脚正确候选P&R/STA/BIT DONE，final+0.100/+0.021ns、TNS0，覆盖63.04%边界保留；匹配24MiB no-map临时Linux BOARD启动PASS。首次单帧进程后命令无应答，图像未取回/NPU未运行；setup漏接新bank所需既有GPIO复位释放（INFERRED根因），用户冷恢复后正在以修正setup重试同bit。唯一直接阻塞为采集寄存器访问及真实一帧验收，未重做原版对照或NPU资格。

- 原platform/bit/ELF匹配运行DONE，用户确认画面实时且清晰；cache清理交接及明确resume修复已实际执行。原零帧根因不做单因定论，不再阻塞于原版黑屏。
- 控制采集接空闲HP1、原CSI/ISP/PLL/管脚保留，网络HP0/80MHz保持；新bank SIM DONE、SYNTH DONE（42007slice/143ERAM/174DSP），P&R RUNNING，STA/BIT/BOARD PENDING。入口status-offset及24MiB no-map DTB已准备。
- 下一：合格bit后正常软件重启U-Boot、临时匹配Linux单帧取回目视，随即16帧进入原识别入口；真实识别结果DSI和连续三窗口PENDING。不得在当前原常开FDMA bit下直接启动Linux。
- 内部PW32数值与7426.202ms保存帧证据保持；不重做Soft/T01、不修改模型/V4R/NPU驱动、不下载CSL-500。当前无待用户物理恢复，goal active。

## 2026-10-06 共享PW32 BOARD DONE；原视频匹配debug对照PENDING

- R3共享点卷积CODED/SIM/SYNTH/P&R/STA/BIT/BOARD DONE。旧模型及16不同保存帧features字节精确/direct logits0差；两个稳态7426.202ms对原7718.701ms减少3.789%，含输入/初始化减少3.374%，不同启动边界保留。Hard160、三个空间PL块各16、CPU Add16；CPU桥接保留。证据experiments/sol_shared_pw32_soc_20261006/board_verification.json，旧bit保持、root MAC默认16。
- 实验第12块逐通道M16/floor真实适配数值max1、非精确，REJECTED该载荷，未START/未换默认模型，不推断全部Hard模式。C576共享执行PENDING，不阻塞视频。
- 下一直接动作：saved原DSI phy_1 bit/ELF/platform init匹配SDK debug运行，ELF实际EL3入口；原常开FDMA bit不能在Linux加载。原版画面对照BOARD NOT_RUN；成功后单帧→原16帧入口→DSI，不重做Soft Pool/T01。
- R4质量拒识、R5真实摄像头屏显持续运行PENDING。CSL-500依用户暂不下载，申请/下载NOT_EXECUTED。当前模块空、无待物理恢复；goal active。

## 2026-10-06 CPU热点接入：固定16批量BOARD DONE，进一步空间收益DOING

- CPU三个前段可选固定16，节点/权重/精度不变；修复符号batch导致实际初始化拒绝（START0）。两批量/两逐帧同环境完整16不同帧features/精确logits零差；运行中位7718.701对7846.389ms，含输入/初始化8369.368对8469.513ms，减少1.627%/1.182%。收益较小，保留可选及原回退，证据experiments/sol_cpu_batch16_fix_20261006/verification.json。
- NEON转换边界精确、微基准更快，但整链中位7794.024对7784.972ms没有收益；默认保留原转换，证据experiments/sol_neon_codec_20261006/verification.json。
- 下一针对CPU after_block4尾部约3.05秒/16帧，兼容Hard优先，格式阻塞时复用共享PL；第12块新量化保持独立，禁止新增12/13两套常驻引擎。所有模块正常卸载，无待恢复；原84064继续收尾，最终STA/BIT PENDING。
- R4质量/拒识、R5视频/DSI PENDING；用户选CSL-500且明确不下载，尚无新增训练数据，goal active。

## 2026-10-06 最新异构任务：R1/R2及精确CPU时序整链BOARD DONE，R3空间热点PENDING

- R1 DONE：OC16 C128保持数学/证书/位宽，真实预算0/32输出与金样全精确；紧凑SoC P&R/STA/BIT及BLOCK34首图通过，三个完整16帧窗口同候选features/logits零差。资源压缩不能称核心加速，cache16384读实际报告。
- R2 DONE：同bit/model/input CPU Add7986.779ms、Soft8241.046ms，各一个窗口减少3.085%；独立无Soft bit实际完整16帧8211.739ms精确。新综合83ERAM/21994slice/111DSP，物理67ERAM/24500slice/111DSP；原回退bit保留，Soft不加载，成功设备正常卸载。
- BLOCK34放置比较DONE：同bit同模型PL三个窗口中位8136.717ms，CPU block3＋4窗口9471.174ms，减少14.090%；同候选全CPU16621.451ms另列。新增量化质量边界仍保留，非旧7.905候选直接比较。
- 精确CPU TCN整链DONE：同bit相同空间模型交替各两次，fixed-cpu整16帧中位7760.101ms，对照Hard前缀＋PL V4R8091.391ms（运行减少4.094%）；输入至分类含初始化8417.954对8658.676ms（减少2.780%）。时序实际30.367对50.701ms，硬件切换/初始化194～212ms在运行窗口内，不能将总收益写为V4R核心收益。空间features逐字节精确，时序logits分别对自身参考精确，direct在V4R证书内、类别相同；Hard空间160、CPU时序三层、CPU Add16，TCN/C128 START0，原硬件路径保留可选。
- R3空间热点PENDING：CPU空间仍约4.77秒/16帧，下一不改变模型的CPU计算优化或实测划算的兼容Hard/shared PL迁移；现ORT allow_spinning=0已存在，不能再作为新工作重做。
- CPU线程比较BOARD DONE：原尾部真实张量5次，双线程199.050ms、单线程305.111ms，输出精确；保留双线程、不修改主链该配置。此微基准无设备START、不是新增整链提速。
- 第12块新量化不启用默认，不新增12/13常驻引擎；下一空间迁移须有同模型收益。R4完整质量/拒识、R5相机/DSI/持续真实动作仍PENDING。
- 证据experiments/sol_cpu_h6_main_20261006/verification.json、sol_v4r_oc16_soc_20261006/board_verification.json、sol_cpuadd_oc16_soc_20261006/{board_verification.json,fixed_cpu_main_verification.json}。无Soft bit同启动共5窗口通过；原大84064构建正常收尾，未改输入；无待物理恢复，goal active。

## 2026-10-06 异构审查优先：R1资源SYNTH DONE/P&R DOING；R2 CPU Add部分BOARD

- 最新目标覆盖旧全FPGA要求，以同模型速度和质量决定CPU/Hard/PL放置，12块量化不启用为默认，资源预算只是验收目标。
- R1：OC16复用C128区间，原预算0/32全输出/区间/证书及DMA精确，默认128回归通过。独立48 ERAM；完整SoC157 ERAM（净减121），Slice42681/DSP160。99548新P&R运行，时序/BIT/BOARD待验；原84064仍正常收尾，输入未改。
- R1周期预算32增加3.8836%、缓存读增8倍，不宣传计算提速；同资源直接/精确CPU端到端比较仍PENDING，精确回退保留。
- R2：原入口CPU H6选项PC16帧features/logits零差；ARM微基准对已资格Soft输出精确，p50=1.089ms/p95=1.156ms，无设备START。完整硬件主链+CPU Add待测，准备14KB软件补丁，复用已存在模型和qualified bit即可运行；先CPU Add，随后同bit Soft比较并处理固定缓冲。
- R2删除通用Soft IP PENDING：先取得完整主链收益与依赖证据，再做独立bit，不把74 ERAM写为已释放。当前仍保留Soft。
- R3热点Hard适配/划算CPU路径、R4完整质量与拒识、R5相机显示持续运行仍PENDING；不要求全部空间层硬件化再接视频。

## 2026-10-06 第12块真实整数与原主链PC DONE，BOARD/PL PENDING

- 可选CPU block12接原16帧，原生/独立整数features与logits零差；电脑原生2.797506秒，仅PC指标。新增量化对浮点存在误差，已有12段分类全保持/正确9→9，非完整质量验收。
- CPU板端运行包约3.48MB已准备，后续用U盘到新私有目录测其实际ARM耗时，入口run_cpu.sh只CPU、无加载模块/寄存器/START；未执行。
- 第12块参数150528B；现Hard工具仅scalar量化、旧槽尺寸不匹配，共享PL须宽化C576计数和分组参数缓存。下一迁移复用现共享引擎，经实际仿真和测量决定收益，不复制新常驻引擎。
- 原BLOCK34同P&R继续，下一硬件验收仍最终时序→合格bit→首图→原16帧。无重复Soft/T01资格、无新增设备START，goal active。

## 2026-10-06 第12块切分与真张量PC DONE，量化/硬件PENDING

- 原CPU尾部已实际切分回放，真实输入96×14×14、扩张/DW576×14×14、投影/残差96×14×14；max1.0967e-5浮点误差，不写零差或新整链BOARD。
- 训练参数及既有Q/DQ域已保存；下一直接准备第12块量化CPU计算并接主链质量对照。H4/H5固定槽不能直接复用C576尺寸；共享PL也须调整固定几何，执行路线仍待实际候选测量。
- 原BLOCK34布线继续，最终时序/BIT/BOARD待验。当前无新增设备START或待重启状态。

## 2026-10-06 CPU尾部热点BOARD DONE，下一候选12/13块PENDING

- 小包22141B实际传输/校验，3次板端CPU尾部median207.516662ms含profile，重复输出精确，无设备START。
- 12/13块节点耗时28.154/28.043ms居首，实际C96→576→96、14×14；后续先查其真实参数与现有引擎匹配条件，不能把C192块视为唯一后续方向或宣称已加速。
- BLOCK34最终时序仍为下一硬件验收直接等待项，同一84064进程仍活跃；按用户要求不频繁盯。证据next_cpu_hotspots.json及原始板端profile，板卡无模块、不需重启。

## 2026-10-06 后续热点定位准备CODED/PC，BOARD PENDING

- 原布线任务继续，按用户要求不频繁轮询。下一硬件验收仍为合格bit→BLOCK34首图→原16帧，不重做已有资格。
- 已准备CPU after_block4节点计时脚本与22KB真实输入包；电脑重复输出一致，板端计时未执行。选择下一迁移节点时采用ARM实测，不能用PC热点排序代替。
- 后续C192第5/6块须扩展并复用现有固定引擎，不复制新常驻引擎。V4R已有共享缓存/逐输出停止；直接逐点硬件基线、时序尾部硬件、精确CPU回退替换仍PENDING。证据experiments/sol_block34_20261006/next_work_research.json。

## 2026-10-06 BLOCK34＋V4R核心流水SIM/SYNTH DONE，P&R DOING

- AXI寄存版raw时序实际失败SWNS-0.190ns，未bit/START。按实际路径拆分PW缓存读取/乘法、V4R残差末项/区间提交；未豁免数据路径。
- 新六层完整AXI零差、6447806cycles；V4R预算0/32的2048输出/区间零差，原MAC与采样计数保持。仅SIM，非新的板端耗时/提速。
- 新综合42319 slices、278 ERAM、160 DSP通过，corepipe P&R会话84064/PID52284运行。唯一直接阻塞：最终时序，合格后首图→原16帧板测；复用已通过CPU16.621秒参考及未受改动影响的驱动/模型。
- goal active，完整空间硬件、完整V4R/质量、实时视频/屏显/拒识未完成，无待物理恢复的新设备状态。

## 2026-10-06 BLOCK34时序修复SIM/SYNTH DONE，P&R DOING；原生CPU入口DONE

- 实际负setup路径已定位，DW读地址/长度与PW写数据寄存后，真实六层AXI全部输出精确，背压/完整响应/守卫通过；6383596cycles仅SIM。
- 新综合42353 slices、278 ERAM、160 DSP；block34_pipe_physical.tcl会话85250/PID65984运行。直接阻塞为最终时序/BIT，尚未新START；完成后首图→原16帧实际硬件耗时，不豁免数据时序。
- 原生CPU PW96/block4接原16帧实际通过，16.621451秒/init0.567666秒，特征及logits对同候选39.471秒参考零差；仅CPU软件收益，硬件调用0。旧7.905/8.442秒硬件链保留，新硬件尚无速度结论。
- 正常Linux、模块为空、无需物理恢复；goal active。视频/实体屏/拒识及完整空间硬件未完成。证据experiments/sol_block34_20261006；下一板测可复用本轮模型/运行包及原生CPU结果。

## 2026-10-01 BLOCK34连续六层完整DMA/SYNTH DONE，P&R DOING

- 新连续六层真实首图完整AXI逐字节正确，30765写/响应、6224629cycle；C24缓冲安全复用及28宽/32字节行距已实际验证。组合桥接原16帧CPU特征精确，未当成硬件运行。
- 综合42276/52480 slices、278/280 ERAM、161/240 DSP通过。匹配ABI60001驱动目标编译完成，首图及整16帧运行包已备，尚无新START。
- 当前直接阻塞：最终布线/时序尚未完成；会话91834运行block34_physical.tcl。完成后查真实时序→合格临时bit→首图→原16帧与已取回的同候选板端CPU比较及实际耗时，不重做T01/Soft/V4R资格。
- 板卡正常Linux、模块为空，不需重启；goal active，视频/屏幕/拒识未完成。证据experiments/sol_block34_20261001/axi_verification.json及experiments/sol_block34_soc_20261001。

## 2026-10-01 第4块CPU整链与真实算术DONE，连续DMA DOING

- 新增可选第4块真实整数计算，直连第3块输出，原16帧入口电脑CPU2.617秒/板端CPU39.471秒；后者为慢整数参考，不作为提速。板端实际输入重算输出25088B零差；跨平台整链非零差，输入差异在新块之前已存在，详见cpu_tensor_verification.json。
- 有限12样本标签12/12相同，正确9/12不变；新量化不是对旧浮点零差，不等于完整质量/拒识验收。三层真实算术SIM已精确：扩张/投影各3行及stride2 DW全112896B。
- 当前唯一直接阻塞：新增块尚无DMA接入；继续复用原逐点/DW/AXI接固定BLOCK3＋BLOCK4串行通路，处理28宽行布局与C24存活中间缓冲，不新增调度框架。SYNTH/P&R/BIT/新硬件START未做。
- 本轮正常LinuxCPU运行、模块为空，不需重启；旧合格硬件链保留。证据experiments/sol_block34_20261001；goal active，摄像头/屏幕/拒识未完成。

## 2026-10-01 融合前段BOARD通过；下一剩余CPU连续块DOING

- 本阶段DONE：首图PW96＋DW96硬件301056B金样精确、device44.079ms；原16帧8.441524s，features/logits对同候选CPU0差，16融合/16BLOCK3/16DW16/162Hard/16Soft/1真实C128 V4R实际运行。
- 本次比8.732382s候选少0.290858s，仍慢于旧7.905177s；旧最快默认链不替换。CPU仍30普通Conv/14DW/8残差；保存帧、拒识未校准、无实时相机/实体屏验收。
- 已完成P&R/最终STA/BIT，精确PS首级复位例外后SWNS+0.100/HWNS+0.020；新bit SHA224f66e4172ed26d7d7e58d9562fe4bd68900a3850e7990c50c7767b6d65feae。完整板测输出/日志已取回board/evidence.tgz243586B/SHAd594cea64b9b4f42a7ba10145959faa98eb5dbe60766f990c5054ac27416d18f。
- 用户已确认物理恢复；Hard/TCN/PL成功卸载后Soft固定实例须用cold_ready.log实际清空证明。持续goal active；当前下一直接任务复用真实profile处理CPU after_block3约234ms段，先backbone.4连续块实际张量/质量/接入，不重新验证T01或V4R。

## 2026-10-01 当前任务：前段融合候选DOING，布局布线→原16帧BOARD

- 实际已完成：signed16 PW96真实CPU接原16帧入口，板端30966.127508ms/features[1,16,128]；12段现有样本标签12/12不变、正确9/12不变，有限检查而非完整验收。
- 固定PW96＋DW96融合真实单图完整AXI SIM输出301056B零差；3520035周期仅仿真。新驱动目标编译、新原入口fused后端CODED，未运行设备。
- 实际ERAM313→310失败已定位并修复：固定16通道系数寄存器＋分布式行缓存；最新综合278/280、slice80.32%、DSP158。P&R运行中，BIT/BOARD PENDING。
- 下一可运行交付：合格新bit/匹配ABI50001下真实首图逐字节比较，随后原16帧Hard/Soft/PL/C128入口输出及实际耗时。保留现有8.732秒和旧7.905秒，不用慢整数CPU参考单独证明加速。
- 证据：experiments/sol_front96_fused_20261001、sol_front_pw96_int16_20261001/clip_quality.json、sol_front96_soc_20261001/front96_coeff_soc_gate.area。当前板卡正常Linux、模块空，无新START；不暂停goal。摄像头/实体屏/拒识延后仍PENDING。

## 2026-10-01 张量转换接入主链：16帧8.732秒、数值零差

原完整16帧入口新增CPU原生float32/UINT8转换（同除法/RNE/裁剪，不开fast-math），以及DW96客户端去除tobytes/create_string_buffer中间复制、复用用户输出数组；驱动coherent DMA、CRC、守卫、最终AXI完成判据及超时处置不改。板端16帧实际中间张量、四实际量化域半整数/饱和/全部256输出码精确；量化median38.532645→14.315190ms。完整Hard/Soft/PL/真实C128 V4R再运行通过：total8732.382386ms（前版9138.761221ms），128维特征逐字节精确、logits0差、分类不变。beforeDW96 median94.873681→70.490311ms，ioctl median37.3707→37.71303ms无改善；不能将CPU边界收益称NPU核心提速。仍慢于旧最佳7905.177ms，最快默认链不替换。

证据experiments/sol_tensor_codec_20261001/{verification.json,board/verification.json,board/clip_result.json,board/features.npy,board/evidence.tgz}；完整归档22973B/SHA4300fc7fac0df2e0206f4b98363be9cb30f9c631e5d6a6d315124234dba31a8c。合格ARM libtensor_codec_native.so8112B/SHA72867692fad4f7555473201462eff2b5164b755379ffae89d3d21663234ef25b，差异包79705B/SHA56f4fd70fa1981065b3748cdafc6e9ab8692acd8125025123121ff05d0a01cf0。旧差异包/bit/模型保留；新增包包含这次实际代码。Hard安全卸载、net_pl实际rmmod成功，Soft固定DMA；用户已再次确认物理重启，下一板测前只读核对，未再START。

等待期间新增pointwise_expand_row.v：一个量化银行与下一个点积重叠，仍用原RNE核。signed16真实第0/56/111三行10752B均精确、有背压；overlap_sim.log累计56058cycles，旧104537cycles。稳态行约18044cycles含输入装载/停顿，112行80MHz约25.26ms仅SIM估算，无新综合/布局/bit/BOARD，仍不单凭核心迁移宣称快于CPU23.491ms。PW96输出平均0.191909码/max41的整链质量仍PENDING，不采用未经质量验证的替代层。

下一直接动作：先将signed16 PW96真实CPU计算接原16帧入口检查整链质量，再做PW96与DW96固定16通道组行缓冲融合，省去1.2MB中间量化张量和DDR边界；复用已有MAC/RNE/AXI完成规则，不为单层再建资格框架。整图仍CPU31普通Conv/14DW等混合，时序沿用真实C128，CSI/DSI延后。goal active；未Flash/原工程构建/提交，原工程与外部快照整体哈希未重验UNKNOWN。

## 2026-10-01 冷恢复后144连续块完整16帧BOARD通过

用户确认物理恢复，正常Linux模块空；按原临时DTB/80MHz合格bit及GPIO释放流程加载。原16帧入口实际完成，features[1,16,128]与同候选CPU逐字节一致、logits0差，total9138.761ms/init1035.375ms；同候选CPU15102.841ms，但旧最佳7905.177ms仍更快，因此不替换最快默认链。16次BLOCK3、16次DW96、16次DW16、162次Hard（含2次TCN）、16次Soft及真实C128 V4R1次均实际运行；仍有CPU31普通Conv/14DW/8残差，不称全空间硬件。分类咳嗽0.985838，拒识未校准，保存帧不等于实时视频。

完整输出和日志已取回experiments/sol_block3_recovery_20261001，verification.json为数值比较，evidence.tgz22875B/SHA965ba79c19f2d3d7c5effb62ba410ad60e94af51affb82e79e15798dd3206108。Hard自动安全卸载、共享PL实际rmmod成功，Soft固定DMA；用户已再次确认冷恢复，尚待下一只读实查。未改驱动空闲条件、未Flash/原工程构建，整体基线哈希状态仍UNKNOWN，goal active。

下一PW96候选signed16输入基于前级Clip[0,6]和投影权重推导范围，不用验收样本调范围；真实首图平均误差0.191909码/max41（旧2.21578/max139），三行RTL逐字节通过。仅CPU/SIM候选，尚未采用/未整链质量验证。当前行核SIM折算约47.9ms仍不能证明快于23.491ms CPU节点，先处理真实主链量化/搬运开销，再推进融合，避免把硬件迁移本身当提速。

## 2026-10-01 下一PW96候选行SIM通过，未采用原量化误差

当前Hard物理恢复仍未确认，不热重试。前段真实最大节点PW16→96/112×112约23.491ms；等待期间新固定配置复用16路逐点核心，三行10752B全部精确，默认block3六行也通过。工具进程本地PATH缺依赖导致0xc0000139，补工具目录后编译/仿真成功，自有进程已结束。参数/CPU前段切图已生成，但原输入量化域产生max139/mean2.21578码差，不能直接采用或称质量通过。下一静态动作改善该层输入表示并保持模型规模/质量，随后PW96→DW96串接；BOARD及完整16帧仍需用户冷恢复。证据experiments/sol_front_pw96_20261001及sol_block3_board_20261001/current_profile。goal active，存在直接实现可继续，不因等待暂停。

## 2026-10-01 CPU固定块原入口已加速，Hard冷恢复仍待确认

等待期间新增本地固定CPU block3计算并接原CPU入口，四输入块比较/整16帧特征逐字节精确与logits0差；BOARD CPU total15102.841ms/init480.622ms，旧CPU30145.580ms。CPU单块108～119ms，当前PL固定夹具51.477ms仅块级数据，整链PL尚未通过，不算新整体优势。compiled ARM so与runtime纳入76439B差异包（SHAa0e75025249431e0da3f48c06865e25a16c8922f7fd54c8a7e40b3e7fd629898），未改模型/帧数/量化或硬件idle条件；原Python金样保留。Hard引用1/未知恢复未确认，不再START；下一动作冷恢复后16帧实际验收。证据native_cpu_evidence.tgz及native_cpu_evidence/sol_native_cpu_clip_verify.json，位于experiments/sol_block3_board_20261001。goal active。

## 2026-10-01 16帧候选CPU通过；第0帧前段PL正确，Hard空闲拒绝待冷恢复

BOARD CPU16×128 total30145.580ms/init941.139ms，咳嗽0.985838；CPU整数实现较慢，不用作唯一最优CPU速度比较。70082B差异包恢复两原样ONNX，哈希正确，U盘请求取消。混合第0帧DW96/BLOCK3已完成且对真实输入的独立CPU计算零差；Hard H4首次RUN在START前reason14/writes0/pre2→last3拒绝，与历史首次idle失败一致，原因UNKNOWN。Hard/DMA固定，日志输出已取回，已请求物理断电，确认未到前不再提交设备。静态补上前段失败统计和native FNV脚本接入，新70150B包准备好。下一动作物理恢复确认→匹配临时boot/先GPIO释放→原16帧PL重跑及同板比较。完整硬件链、速度/质量仍未完成，goal active。

## 2026-10-01 Sol接回：144块固定夹具BOARD通过，整16帧待搬运

加载阻塞已解除：同合格bit/driver补上PS GPIO bit0释放，probe正常。BLOCK3首次一次真实作业输出75264B精确，device51.476760ms/host55.765170ms；输出已取回，未超时，无需物理恢复。整链BOARD/速度/质量仍PENDING，旧7.905秒最快默认链保持，真实C128沿用，视频延后。新包3933514B已准备，用户U盘移到电脑尚待完成；下一动作复制/解包、同候选CPU16帧及Hard/Soft/PL16帧比较。新准备脚本固定先复位释放再加载，未改运算/预算/驱动或新增通用定位框架。证据experiments/sol_block3_board_20261001/verification.json及docs/records/worklog/2026-10/2026-10-01-sol-block3-board.md；goal active，不暂停。

> 2026-10-01 最新用户指令：取消此前“账户剩余额度46%时停止”的限制，持续实现即可。本条覆盖旧目标/交接中的额度停止条件；原工程、known-good和实际硬件失败处置规则继续有效。

## 2026-10-01 最新交接：Astra停止，6.1 Sol接回

用户要求移交回6.1 Sol；Astra已停止实现和板卡操作。完整入口为根目录ASTRA_TO_SOL61_HANDOFF_20261001.md。最新trace2已捕获insmod后自动复位，FSBL AXI-MONITOR sx2x_m0=0x1，无probe日志、无BLOCK3 START；准确故障指令UNKNOWN。用户在该次故障后已再次确认物理重启，尚未重新实查。拟议“不注册设备的模块加载模式”未实现，net_pl.c仍module_platform_driver。当前所有构建/仿真已结束，COM4关闭，JTAG服务已关闭；本聊天get_goal返回null。新bit最终时序及SIM通过仍有效，但新块BOARD/16帧未通过，旧最快链保持。以下“待用户确认”等旧描述由此段覆盖。

## 2026-10-01 流水化版时序/BIT通过；新板测在probe阶段异常返回普通登录

整图新增BOARD仍未通过，尚未发送BLOCK3 START；C128 V4R未修改、视频仍延后。流水化完整144块及连续两作业SIM全部逐字节通过。恢复布线会话13247正常完成，raw SWNS+0.100ns/HWNS-0.799ns；唯一负hold从PS reset到一级cdc_synchronization_external[0]，报告18597起及RTL157～166确认实际.ie端点。仅纠正该异步入口例外，final SWNS+0.100ns/HWNS+0.028ns，STNS/HTNS=0。bitgen真实完成，新bit SHA256 e5a3b586636270eb245608afd725db2dcfe62e9335aa6ed070fbf1dea03e7cfa，位于experiments/astra_block3_soc_pipe_20261001，旧bit保持撤回。

板卡实际已在普通Linux登录界面（非此前记录的U-Boot），用用户授权账号登录后uptime约11min/lsmod空，阶段打印driver hash仍bcdf876277bd487b2e678dc01a83e199c9443b0574f32d7b4cdbe04c0bba8c0a。正常reboot停止U-Boot，临时DTB CRC4f533a68/reset1e1/div07070904实查；JTAG芯片校验成功、下载100%并完成。关闭JTAG服务后释放reset1f1，加载原内核与临时DTB，最小只读Linux启动成功并挂载proc/sys/run/tmp。

仅执行一次insmod阶段打印driver allow_run=1，15秒连续抓取只见命令回显，无PIPE_PROBE_RC或阶段打印。随后只读echo/uptime却出现Password，取消后明确返回Ubuntu20.04 bionic-arm64 login。说明已脱离临时init=/bin/bash环境；重启时间、触发原因及probe停点UNKNOWN，不能简单宣称地址截断是重启根因。未再次装载、未提交运算、未卸载/释放未知缓冲。已请求用户物理断电重启，尚待确认。下一次必须保持串口连续捕获覆盖probe及可能重启全过程，并在之前显式核查/提高console printk级别，先定位实际停点，不继续盲试计算。

证据集中在该独立目录board_pipe_reboot/dtb/clock/boot/prepare/probe/after_probe/login_check.log及block3_pipe_download.log。原7.905秒默认链保留，新块SIM48.47305ms不代表板端提速；新16帧硬件链未执行。额度停止条件已由用户取消，后续持续推进；原工程和外部快照全量哈希未重验仍UNKNOWN。

## 2026-10-01 addr12布线结束：残差长路径实失败，流水化修复中

修正地址宽度后的完整块P&R会话49080已正常结束，block3_raw.ts为SWNS -7.558ns、STNS -7238.429ns、HWNS -0.715ns，不能生成可部署候选或上板。最差真实路径为pointwise core qreceived→skip寻址/读存储→残差双缩放/求和/舍入→输出行缓冲（24级）；不是可用时序例外掩盖的数据路径。

已修改implementation_pl/front_block3/pointwise_row_core.v，将残差寻址、读数、两乘积、求和、舍入与裁剪分级，附带通道标签并统一背压；保留原完整定点公式及模型规模。旧源码已保存。residual_pipeline_sim.log实际BLOCK3_CHAIN_PASS，扩张451584B/DW451584B/输出75264B全部逐字节正确，35548读/17678写与响应/3877844周期（80MHz折算48.47305ms，仅SIM，未提速）。首次编译因信号声明顺序报错已修复。新独立experiments/astra_block3_soc_pipe_20261001综合会话44014已成功结束，布局布线会话84153在用户中断后丢失，提升权限只读检查确认没有TD进程；无最终route.db/时序报告。旧日志最后中间SWNS+0.100ns仍非通过。保留日志和block3_place.db，从该布局检查点以block3_route_resume.tcl恢复布线，新会话13247运行中，不重做综合/布局；控制接口连续两作业仿真31513已通过：residual_pipeline_repeat.log实际BLOCK3_REPEAT_CONTROL_HP0_PASS，两次三段输出均逐字节一致，71096读/35356写与响应/7755707周期，等待末次写响应后完成。旧addr12失败报告保留，不复用旧bit。

整图：本阶段修复新连续块的实际时序失败，尚无新增BOARD；时序模型C128 V4R未修改；视频仍延后。板卡最后实查为U-Boot，无新驱动/作业，用户已完成物理恢复。下一步取得流水化数值与综合结果，再布局布线；仅最终时序通过后继续诊断probe及固定夹具。原7.905秒最快链仍是基线，未声明新性能收益。账户最新剩余51%。未重新全量核验原工程/外部快照哈希，其全局未变状态UNKNOWN。

## 2026-10-01 实际上板接续：probe未返回；地址截断已复现修正，重新构建中

addr12修正版综合实际完成，P&R新会话49080运行中。对比gate area：旧block3仅6 LUT/0 DSP，已被优化删除；新block3为4711 LUT、17 ERAM、50 DSP，证明旧“bit已生成”不能作为完整144块存在证据。新总资源Slice44413/52480(84.63%)、ERAM276/280(98.57%)、DSP135/240(56.25%)，时序/bit仍待完成。此次明确撤回旧候选可部署判断，不更改旧证据文件。当前U-Boot已确认，未继续加载诊断模块，goal实查active。

用户提供root登录授权后已实际登录：正常Linux6.1.111-rt42、lsmod空。新driver板端/root/astra_block3_20261001_1编译，ko SHA929cb20b2f6cc55fcb6bb3038ad3c463cd4724babb25bd1a1d88baf687cd4621；继承缺Module.symvers/clock skew告警，非运行通过。旧候选bit 0ff30d...ba1fc7实际易失下载完成，临时DTB CRC4f533a68、reset1e1/div07070904与旧流程匹配，启动只读最小Linux成功。夹具传输第一次0B，补/tmp tmpfs后122750B/SHAf50d13fef255b0268d934b0a236b5e322985946871956e60ccc74dd0fd201e42成功。

加载新net_pl后未返回，后续只读shell命令无执行结果；未发送任何BLOCK3 START，未卸载/重试未知设备。用户确认物理冷恢复后，正常Linuxuptime约1分钟且模块空再次核验。新增最少probe阶段打印，独立/root/astra_block3_trace_20261001_1编译ko SHAbcdf876277bd487b2e678dc01a83e199c9443b0574f32d7b4cdbe04c0bba8c0a；尚未加载。第二轮旧bit尝试连接失败/芯片校验失败，不能按进程exit0当下载成功；随后停止使用旧候选。

实际发现SoC system.v仍为7位控制地址与25位补零，新寄存器0x80..0xac不可达。address_sim.log证明旧7位读0x90000080返回DW16 ID44573136，新12位返回正确BLOCK3 ID424c4b33。矩阵ds0既有范围4KiB（addr width0x0c），因此在新experiments/astra_block3_soc_addr12_20261001仅修正顶层AR/AW为12位及20位补零，旧bit/源码保留但BLOCK3用途撤回。先前模块级SIM/P&R不证明顶层新寄存器可达；首次失去响应确切停点仍UNKNOWN，不能将地址缺陷直接写成挂死唯一原因。

修正版综合会话5778运行中，未新P&R/BIT。当前板卡经version实际确认停在U-Boot；本次JTAG服务关闭，无驱动/计算作业，无需再冷恢复才构建。下一动作修正版完整构建后使用阶段打印driver核验probe，成功后固定夹具及16帧对照。整图/时序/视频系统目标均未完成，旧7.905秒通过链保持。

## 2026-10-01 144通道连续块整合已SIM/SYNTH/P&R/BIT，未BOARD

当前直接阻塞：板端root登录尚未确认。电脑端仿真、完整构建和部署准备已结束，无仍在运行的构建。新block3_source_stage2.tar.gz为3919530B/SHA256 819a82dcae799bf4701fd113b6816a5cb39b5cfa3a20e83a531906e95a10bf06，55个成员逐项回读校验，包含最终统计补丁和run_block3_fixture.py；stage1保持历史，不用于本次最新部署。目标驱动编译与BOARD未执行，NPU未启动。下一必要外部条件是用户完成root登录并释放COM4；不以额外静态报告替代板测。登录阻塞已持续多轮，设置goal BLOCKED以停止自动空转，收到恢复后继续原目标，不代表项目完成或达到额度阈值。

experiments/astra_block3_soc_20261001完整80MHz构建结束：block3_final.ts为SWNS+0.101ns/HWNS+0.020ns、STNS/HTNS均0。raw hold -0.923ns仅PS异步复位到cdc_synchronization_external_reg[0]_syn_2.id；新报告输出net和源码第157～166行确认是第一级同步器，精确例外由旧.ie改为真实.id，未放宽数据和后级。net_pl_soft_80mhz_block3.bit SHA256 0ff30d21486fb0a1d51ceab4b755d7a16d223f799aea6f868261901964ba1fc7；bitgen真实完成，未下载。

repeat_fixed_sim.log实际BLOCK3_REPEAT_CONTROL_HP0_PASS：两次完整任务均三段逐字节一致，总71096读/35356写及响应/7341775周期；完成状态检查通过。首次失败为测试台混淆内部状态1与总线状态2，原失败日志保留，RTL未因此修改。先等待新作业busy再等done，避免第二次误读旧完成。

当前整图推进：真实连续块已完成PC侧整合构建，原16帧调用代码已接，尚无新BOARD或端到端提速结论。C128 V4R逻辑未改、视频仍延后，旧最快7.905秒路径保留。板端仍等待用户完成root登录并释放串口；当前模块状态UNKNOWN，未加载新模块、未NPU START、未Flash。下一动作登录后检查uptime/模块/匹配环境，在新目录编译driver；准备冷恢复与易失下载后做固定夹具及原16帧对照。source_stage1不含最后统计补丁，传送前重打包。账户剩余53%，goal未完成。

## 同日接续：完整SoC综合通过，布局布线运行中

重复提交测试首次因测试台将内部c_status=1误当作寄存器编码2而失败；已修正判据并等待新作业busy，重复SIM会话37592进行中，尚未通过。SoC P&R仍为同一会话83576，不能重启。新增run_block3_fixture.py待板端执行；主入口已补actual_pl_block3_starts、逐帧设备耗时及CPU/PL层统计，语法通过但未板测。source_stage1包早于此次统计补丁，实际部署前须制作新包，不能称旧包包含最新源码。

从experiments/network_n3_v4r_soc_20260930已通过DW96板测来源，仅复制uisrc/al_ip和配置至新experiments/astra_block3_soc_20261001；增加block3连线与源码，未Generate、未修改旧bit或原工程。block3_synthesis.log实际BLOCK3_SYNTHESIS_COMPLETE，gate数据库已导出。gate统计Slice32267/52480、ERAM259/280、DSP85/240；非最终布局资源和时序验收。

block3_physical.tcl已启动，当前工具会话83576，block3_physical.log持续记录；尚未完成P&R/最终STA/BIT，不能重复启动同一构建。block3_reset_entry.sdc沿用旧首次同步级路径，应用前仍须核对新布线报告真实端点，不扩大例外。

block3_source_stage1.tar.gz已封存3918524B，SHA256 46a4cfb53a852a6c96d8c961405b05ebf4a01519952fa4aed1ce4c84e02c77b4；包含driver/runtime/匹配block3模型及参数，source_package_manifest.json有逐文件清单；未上传/目标编译。原16帧程序--help实际成功并展示新增参数。

串口COM4当前bionic-arm64 login，输入既有root账号后等待Password；已释放串口并请用户自行登录后释放。未猜测密码、未NPU提交、未装模块，板内驱动状态UNKNOWN。账户已用47%/剩余53%，仍可继续。下一动作跟踪同一P&R会话；用户登录后只读检查状态并目标编译新驱动。

## 同日接续：控制接口与HP0整合SIM通过，驱动和主入口已CODED

net_pl_control新增0x80..0xac（ID 0x424c4b33/ABI 0x40001），net_pl_datapath新增owner3连接连续块；原三作业接口保持。control_sim.log实际BLOCK3_CONTROL_HP0_PASS，三段逐字节一致，35548读/17678写及响应、3670892周期；本测试通过真实寄存器写启动和真实HP0复用，不含其它三个算子的切换回归，尚非BOARD。编译有原V4R RAM输入64→32截断告警，未修改原运算。

net_pl.c/net_pl_uapi.h新增NET_BLOCK3_RUN及/dev/block3，31488B参数包依次23040/4608/3840B；两块451584B独占coherent中间缓冲，保留守卫、CRC、最终完成、超时固定。驱动目标编译PENDING，不可将源码作为可装载产物。新driver要求新增ID，因此不配旧bit；旧冻结driver/bit继续作为回退。

block3_executor.py新增PL客户端，接DepthwisePrefix→HardSoftSpatial→原run_hard_soft_clip；显式--front-block-backend pl及--front-block-parameters，默认cpu保持，validate对定点参考逐元素比较，product无重复CPU金样。Python语法检查通过，尚无真实设备调用或整16帧新路径运行。参数目录必须为与--front-block-assets匹配的冻结记录，当前来源experiments/network_front_block3_20260930/row_fixture。

下一步准备匹配的SoC连接/构建来源（旧prepare_net_pl_soc.py尚未包含DW96，不可盲目使用），目标编译驱动，新增作业重复/切换检查后完成新bit与易失板测。板卡本阶段未访问，重启后状态仍UNKNOWN；不改变质量结论或最快默认链。

## 2026-10-01 Astra：144通道完整连续块已SIM及RTL综合，未BOARD

新增implementation_pl/front_block3/dw144_axi_master.v与block3_axi_chain.v，串接真实24→144扩张、144通道56×56 stride1深度卷积、144→24投影及残差；复用原定点运算，不改层/通道/帧数/预算。测试DDR仅预装原始输入和参数，中间结果由RTL实际写回供后段消费。

experiments/astra_block3_chain_20261001/chain_sim.log：BLOCK3_CHAIN_PASS，扩张451584B、DW451584B、最终75264B对冻结定点金样逐字节一致，35548读事务、17678写事务及响应、3670852周期；含DDR停顿、末次B完成与64B守卫。80MHz折算45.88565ms仅SIM估算，接近原CPU块47.048ms，尚无板端速度优势证据。旧7.905秒最快整链保持，原候选量化误差和9/12质量限制不变。

td/rtl_attempt3.log与block3_rtl.db证明elaborate/optimize_rtl完成，无锁存器；不是gate综合/P&R/BIT。首次项目Name与文件名不一致已修正，失败日志保留。Windows阻止vvp，用户关闭相关控制后同一程序实际执行成功。电脑重启使旧构建进程消失，新命令行构建已退出0。

整图：连续块内部数据链新增SIM通过，尚未接共享GP/HP0及驱动和16帧硬件入口。时序：C128 V4R未改。视频：仍延后。下一动作接现有控制接口owner=3及owned scratch客户端，完成SoC构建后授权易失板测；不能用SIM替代BOARD或质量验收。

本阶段未访问板卡、未Flash、未原工程构建、未Git操作；电脑重启后板卡状态UNKNOWN。旧源码/bit未主动覆盖，基线整体和外部快照未全量核验，UNKNOWN。Sol已交出执行权；账户窗口已用46%/剩余54%，尚未达到剩余46%的停止阈值。

## 2026-09-30 C24/C144连续空间块CPU主链与逐点DMA已SIM，未BOARD

prepare_front_block3.py提取真实backbone.3扩张24→144、DW144/56×56、投影144→24、残差Add，包含两个Clip和实际四个量化域。零权重/非零折叠bias导致I32溢出的实际报错已修正：weight scale同时满足真实bias范围，全部实际M/S仍S30。新增front_block3.py固定CPU计算，通过原run_hard_soft_clip --front-block-assets接入DW96前段；真实16帧128D完整输出，PC运行1676.185ms（不是板端耗时），相对DW96候选PCfeature max0.926588/mean0.101340，咳嗽0.985641。已有12真实测试子集分类12/12保持，两候选均9/12正确，不能代替全质量/拒识验收。

新增pointwise_row_core.v 16路MAC＋复用原RNE核心，以及pointwise_axi_master.v：只读24/144通道56像素行、固定160B参数记录、投影内接实际量化残差；最多16拍/4KiB拆分、最终B才done。首次行SIM投影通道16发生weight读索引8位回绕，已修正为足够位宽并保留失败log。真实0/17/55行六次扩张/投影模式切换及输出停顿逐字节通过；完整图DMA扩张451584B、投影＋残差75264B对独立CPU金样精确，读11215次、写/响应9519次，累计2668531 SIM cycles。未综合/布局/bit/BOARD，不宣称板端加速；实际生产最快旧链仍7.905秒，新DW96已BOARD候选8.978秒。

证据experiments/network_front_block3_20260930/verification.json、clip_quality.json、row_fixed_sim.log、dma_sim.log。下一可执行动作：现有DW DMA接144×56/stride1模式，串接两个逐点DMA与DW，固定owned scratch内存下完成三作业，再目标构建和原16帧BOARD。当前正常Linux115.13s/模块空已核验，未在本阶段触发NPU START；goal active。修改仅工作副本，未Flash/原工程构建/提交，整体基线/外部快照UNKNOWN。

## DW96匹配缓冲修正版已BOARD（同日接续）

修正当前实际开销：DW16/V4R/DW96分别固定三个匹配大小的owned coherent缓冲，仍单mutex串行、全尾部守卫/CRC/地址校验和失败固定，无bit/model/ABI改动。目标ko459808B，首次新driver保留driver_shared_large_before.c，补丁3343B SHA70c5997666cda00001b84b8647d41aa2c5e37cde9dad84e9bf7991f268b2b356。16帧BOARD总8978.214ms/init1188.047ms；同候选CPU15826.074ms减少43.27%，feature byte-exact/logits0差/16DW96/16DW16/162Hard/16Soft/1C128V4R。DW16主机累计503.162→97.433ms，V4R ioctl47.203→21.042ms，前段CPU仍6055.911ms，DW96主机633.666ms。本路径仍慢于旧前段7.905秒，不将候选默认化为最快产品。

证据buffer_board_verification.json、buffer_board_evidence.tgz（28273B/SHAfff1881d64cfb0830d1872a1f8c45163611ca63b210f7d72f84a8a2fd3e98ec1）。Hard/TCN/NET正常卸载、Soft固定，已请求物理恢复。下一动作以当前CPU切段真实输入做热点测量，再扩大对应连续硬件块；旧资格不重做。原合格dwparallel bit SHAfbf8e3...297cc25实查未变，整体原工程/外部快照UNKNOWN，无Flash/原工程构建/提交。持续goal active。


用户再次冷恢复已实查正常Linux115.13s/模块空。用当前切段的真实DW输出做CPU后段ORT实际profile，双线程median296.295ms；最大单节点为backbone.3/conv/conv.1/conv.1.0/Conv：C144×56×56/3×3/stride1，均22.881ms。相邻同块扩张24→144（11.817ms）、投影144→24＋残差（12.350ms）均已定位；下一实现选该固定连续空间块以减少CPU↔PL边界，优先复用当前DMA/并行核心及固定入口。profile证据profile_evidence/after/summary.json，归档SHA3e406fa4c5999e7d1769567207cc06616531d9aa69d13fce976af83b18a58d4b；只是CPU实测，不是该块硬件完成。当前无实验模块，尚未提交下一块START，goal active。

## 2026-09-30 前部DW96已BOARD，完整16帧9.426秒

固定C96 112×112→56×56的3行缓冲/DMA已接入现有入口。真实301056B输出逐字节金样精确，设备11.342ms；共享接口DW96→DW16→V0→V32→DW16 SIM通过。隔离80MHz SYNTH/P&R/BIT/BOARD完成，setup+0.108/hold+0.020ns；raw hold-0.729仅PS异步复位到实际首同步级cdc_synchronization_external_reg[0]_syn_2.ie，端点/输出net已核对，新bit SHA c96365dc29bdabb88c895c59c6e0be45268474093f8be52852402222c5aa87dd。

同板同候选CPU16帧15826.074ms/init925.677ms，新硬件16帧9425.657ms/init1162.061ms，减少40.44%；16×128特征byte-exact，logits0差，咳嗽0.985071/证书通过/无fallback。实际162 Hard（空间H4/H5＋2 TCN）、16 DW96＋16 DW16、16 Soft、1真实C128 PL V4R；CPU仍33普通Conv/15 DW/9 Add及尾部与时序辅助。拒识NOT_CALIBRATED、视频/DSI未接通，非全空间硬件或实时产品。前段量化候选不是旧7.905秒路径，当前9.426秒更慢，不能替换为更快默认路径的结论。

已定位小DW调用104→503ms/16次：扩大共享缓冲造成重复清理与守卫扫描。下一实测：三个固定算子分别使用匹配大小的owned DMA缓冲，保留单锁串行、全尾部守卫/CRC和失败固定。修正版driver已CODED/目标编译进行中，不改bit/模型/ABI。BOARD日志输出归档28617B SHA4db0af2c792b46d06834228d0540b941db1577fdea1d0e8832b790ef57b3aa7c，experiments/network_dw96_20260930/board_verification.json；CPU证据8658B SHA285960b031a265137b8cf765c98f38704adf4dd55c1439a0853617ad59a10f4f。Hard/TCN/NET卸载成功、Soft固定后用户冷恢复，正常Linux154.33s/模块空。目标active，继续必要板测，无Flash/原工程构建/提交，整体基线/外部快照UNKNOWN。

## 2026-09-30 并行深度卷积已BOARD，完整16帧7.905秒

九乘加并行流水保留原RNE/符号位/输出停顿语义，47040真实值与连续流水/停顿SIM通过，原DMA最终B与守卫回归通过。隔离SoC SYNTH/P&R/BIT/BOARD完成，80MHz setup+0.101/hold+0.023ns；仅PS异步复位至实际首同步级例外，报告确认同一cdc_synchronization_external[0]。bit SHAfbf8e3ea8c5dd626fc9413b8a5b4ee3e091bb40d3f51f3d12b67b873f297cc25。真实DW47040B逐字节金样通过，device3.649ms；主链16次3.713～3.744ms（原约7.8ms）。原16帧空间＋Hard TCN＋PL V4R再次完成，feature byte-exact/logits0差；运行7905.177ms/init1121.193ms另计，对同板CPU候选下降25.46%。这是末块DW优化，前部DW96尚未硬件化，仍非全空间/实时系统。

新增depthwise_prefix.py及prepare_front_depthwise.py，真实C96 112×112/stride2/pad1→56×56参数与CPU计算接回原--front-dw-assets入口，16×128D已实际CPU运行，较N4feature max0.710601/mean0.048455；当前不是生产默认路径。既有12真实测试子集与N4分类12/12一致，baseline/candidate均9/12正确，三个错误与历史float分类相同，不能认作全产品质量验收或拒识完成。直接下一实现：DW96大图行缓冲/受控DMA/对应新作业入口，接现有前段桥接。

全部输出日志42359B已取回SHA2d033338cf9d5f844cc37af113ca6b7a58c9082ebdc24af265498f9e28c526c0，experiments/network_n6_dw_parallel_20260930/board_verification.json及front_clip_quality.json。Hard/TCN/NET卸载0，Soft固定后用户再次物理恢复，最新实查正常Linux68.34s/模块空；持续goal active，当前准备DW96行缓冲和DMA。无Flash/原工程构建/提交，旧合格bit保留，原工程整体/外部快照UNKNOWN。视频/屏显仍延后。

## 2026-09-30 V4R预取版已BOARD，完整16帧7.950秒

用户再次物理恢复后实查正常Linux88.45s、无模块，沿匹配临时DTB/80MHz下载prefetch bit，复用驱动和全部模型。真实2048组输出在零/预算32逐字节精确，fixture分类也通过；设备29.599500→18.118201ms、28.755451→17.578440ms，分别减少38.79%/38.87%，运算数和证书不变。原H4/DW/H5/Soft＋Hard两层TCN＋C128 PL V4R整16帧入口再次通过，特征byte-exact/logits0差，无CPU fallback；运行7949.696ms/init1119.546ms另计，时序58.586ms。相比同板CPU候选10604.890ms减少25.04%，单次端到端改善不能全部归因于V4R（包含初始化切换和运行波动），仍非实时/全空间硬件/质量验收。

证据experiments/network_n3_v4r_prefetch_20260930/board_verification.json，完整输出日志54639B/SHAf3eb005c2b2044f8ece382657523fcdcb2c5b4fbe0fb3d0550fd11ec13106836。Hard/TCN/NET成功卸载，Soft固定，下一轮物理恢复已请求。期间新增无设备CPU前段profiling实际运行：双线程369.890ms、单线程547.967ms，输出0差；最大单算子为96通道112→56深度卷积，现有线程设置保留。证据experiments/network_n5_prefix_profile_20260930/board_summary.json。下一动作扩大实际DW层接入，不重做原资格；持续goal active，视频仍延后；原工程整体/外部快照UNKNOWN，无Flash/原工程构建/提交。

## 2026-09-30 N4完整16帧组合已BOARD通过并实现候选整链提速

用户确认物理重启后实查Linux uptime43.34s、模块空，持续目标恢复active。复用旧合格80MHz/16拍bit和匹配DTB，修正版H4/H5驱动目标编译602104B；原16帧入口实际完成96次H4＋64次H5＋16次PL DW＋16次Soft，自动卸载空间模块后接2次Hard TCN和1次真实C128 PL V4R。16×128特征对同板CPU候选逐字节精确，logits0差，咳嗽/0.985962，证书通过且无CPU fallback。运行8000.377ms、初始化1152.870ms另计；同板CPU候选10604.890ms、初始化933.266ms，运行时间减少24.56%（1.326倍），不是全空间硬件或实时速度/数据集质量验收。

普通卷积33层、深度卷积16层、残差Add9层及尾部仍CPU；末块H4/DW/H5/H6实际设备执行。Hard/TCN/NET正常卸载，Soft按现有设计固定DMA缓冲，已取回全部输出日志并请求下一次物理恢复；等待期间只准备下一轮，不重复资格验证。下一动作冷恢复后用已构建V4R预取bit实测设备与原16帧整链耗时。证据experiments/network_n4_expansion16_bridge_20260930/cold2_verification.json及cold2_evidence.tgz，归档SHA6248636c81fb25ab5c42a1fc00084fa905e5e2b5df682c861d7aa9d92b47fdf5。视频/屏显仍延后；无Flash/原工程构建/提交，基线整体与外部快照UNKNOWN。


## 2026-09-30 N3 V4R读取流水已SIM/SYNTH/P&R/BIT（未BOARD）

等待N4首次空闲失败后的用户物理恢复期间，针对已测V4R设备约29ms的实际计算开销，核心在16通道dot内消费当前RAM返回的同时预取下一通道，仍保留状态入口等待及不可变区间原子替换。真实零/预算32的2048组center/lower/upper对原金样精确；DW→V0→V32→DW共享DMA、4KiB拆分/16拍上限/输出守卫/最终B全部通过。核心仿真cycles2286271→1364672（减少40.31%）、2211520→1324959（减少40.09%），运算数/模型/ABI不变。这是SIM加速，不是已测设备或整链提速。

完整SoC新流水SYNTH/P&R/BIT完成，80MHz最终setup+0.104/hold+0.023ns，gate slice27923/ERAM259/DSP65；新bit SHA32271009746f2ef1c9bdcef4ac2787c9b2c3c795da32270b3abab2ec30144d07。raw hold-0.860仅为PS异步复位到实际第一级cdc_synchronization_external_reg[0]_syn_2.id；报告证明输出net为cdc_synchronization_external[0]，仅此入口例外、后级和数据检查保留。首次final TCL因工作目录相对路径未生成SDC而失败，已修正、日志保留；最终marker及ts均通过。旧合格16拍bit SHA1571ac...1b152实查未变，旧核源码保存在prefetch实验结果目录。

证据experiments/network_n3_v4r_prefetch_20260930/verification.json和core/net_prefetch_sim.log，构建prefetch_*独立结果。无新板端START；当前直接阻塞仍是已请求的物理冷恢复，用户回复待确认。下一板测先复用旧合格bit运行N4组合（修正版16kB源码已准备），再独立测新V4R实际耗时及整链效果。真实质量/全空间硬件/视频屏显仍PENDING，不制造替代目标；持续goal实查active。原工程整体/外部快照UNKNOWN、无Flash/原工程构建/暂存提交。


## 2026-09-30 N4实际CPU16帧通过，首次组合板测阻塞于启动空闲

新float前段→CPU固定H4→DW/H5/H6→真实C128 CPU时序的16帧候选在板端已通过，10604.890ms、初始化933.266ms另计，128D×16相对N2max0.323735/mean0.037508，仍咳嗽/0.985962；单片段不是质量验收。U盘4.10MB传入完成。首次runner的CRLF解析错误已修LF；首次模型LOAD EBADMSG由block_frozen_config缺H10_MULTISHARD_CONFIG_H导致旧H10宏覆盖（目标编译redefined告警与实际加载失败一致），已补guard后新编译602024B模块，十个slot全装载成功。

实际首RUN在START前空闲检查reason14拒绝：pre_work2、pre_irq0、last_work3、100000polls没有16个连续0；未经过作业寄存器写入路径，不能称H4/DW/H5混合数值或性能通过。已触及TOP时钟/软复位，模块DMA固定，无自动重试/放宽判据；日志输入完整取回first_attempt.tgz SHAa0e9fa98a5769170ed4dd50d37bfb2cfa07d21e069fd0382671cc6a36f02335c，CPU归档SHA89e36efa3fe8aab8e50177947122a311de1edf85b191d499aaa436afd6c1cbf4。已请求物理恢复，回复待确认。

旧合格H4/H5/H10激活顺序与当前组合相同（TOP enable→SRAM clock→soft reset→稳定idle0），没有根据本次work3将未知状态重新定义为idle。下一动作冷恢复后只传guard修正版小源码包并复用已通过bit/模型；重跑新组合入口，保留旧成功整链。未改模型/保护规则、未作Flash/原工程构建，无暂存提交；基线整体/外部快照UNKNOWN。


## 2026-09-30 同入口Hard＋PL时序通过，N4连续块待真实运行

- DONE/BOARD：同一次16帧空间后自动切换Hard TCN前缀＋PL V4R，66Hard/16DW/16Soft/1V4R，特征精确/logits0差，11127.278ms（init1003.636另计），尚未整体提速。
- CODED/目标编译：固定6H4＋4H5常驻模型/ABI48450100及原--hard-block-assets入口；无匹配节点默认加载卸载成功。未作新START，质量验收PENDING。
- 下一动作：用户移回新4.10MB运行包U盘后，实际CPU候选→匹配原bit/DTB运行新增块并比较特征/耗时。原单层资格及Soft Pool复用。


## 2026-09-30 原入口Hard时序切换与H4真实前段桥接

- CODED/下一板测：原16帧入口空间结束后串行卸载H5/装既有TCN，执行Hard0/1＋PL末层；只传改动脚本与依赖，复用已通过bit/模型/驱动。BOARD等待已请求的Soft固定后物理恢复。
- DONE/CPU实际单图：真实前段→旧H4固定算法→DW/H5/H6→128D，max0.246065/mean0.032699对N2；现有--expansion-assets可接原入口，非新Hard板证/非质量验收。
- PENDING/固定H4＋H5组合：复用6＋4片资格与常驻资产，一帧中切真实输入，补齐前扩展→DW→投影→Add块；不每帧卸载装模块，不重复已有六片资格。

## 2026-09-30 N3真实C128 BOARD已接主链

- DONE/BOARD：预算0/32真实2048组区间精确，device29.60/28.76ms，MAC残差减少4.75%。原16帧PL DW＋Hard＋Soft＋CPU前缀/PL末层10783.779ms，特征/logits对N2精确。
- DONE/BOARD保存特征变体：Hard前两TCN层＋PL末层69.903ms，logits0差，证书5.35e-12边界差。尚未同一整图入口自动切Hard时序前缀。
- PENDING整体提速：同板完整时序CPU48.384ms，对CPU前缀PL59.406ms；空间其余层仍CPU、拒识未校准、视频屏显延后。
- Hard/TCN/NET安全卸载，Soft固定，已请求冷恢复；等待期间继续直接加速实现，不暂停目标。

## 2026-09-30 N3当前直接阻塞：HP0四位读突发匹配

- 首次临时bit/DTB/GPIO/probe通过；START152周期status4/读取失败，未进入V4R数值验收，日志已完整取回。
- DONE/CODED+SIM+SYNTH：64→16拍读burst修复，DW→V0→V32→DW真实输出/守卫/最终B正确；DOING修正版P&R/BIT→同fixture BOARD→原主入口。
- 用户已物理恢复，实际normal Linux2min/模块空；不重复模型/驱动/Soft资格。

## 2026-09-30 N3真实C128硬件接口接主链

- DONE/SIM：共享HP0 DW→V4R0→V4R32→DW正确，真实6144 INT64值/守卫/最后B及原分类logits/证书一致。
- DONE/SYNTH：修复实际存储资源超量，完整SoC slice53.21%、ERAM92.5%；驱动目标编译及无节点加载/卸载通过。
- DOING：P&R/时序→临时bit→真实V4R末层及原16帧入口BOARD；前两层CPU，Hard时序前缀待接，性能和质量未验收。
- 未新增板端START；当前恢复已确认，继续已授权实验。

## 2026-09-30 N3真实C128 RTL实际仿真

- DONE/CODED+SIM：真实N2板端特征导出的末层输入/权重，2048 center/lo/hi在预算0/32对原算法精确；预算残差MAC减少37376、模拟周期少3.27%，非BOARD性能。
- DOING/N3：HP0 DMA与GP独立V4R接口、目标客户端及原分类入口接入；尚无SYNTH/BIT/BOARD。Hard前两层复用待接，不用CPU准备fixture冒充Hard。
- 板端冷恢复已确认uptime848.56s/模块空，可继续已授权构建/必要实验。完整N2四层块、整体提速/质量验证、视频屏显PENDING。

## 2026-09-30 N2首个PL DW邻接块BOARD通过

- DONE/BOARD功能：16帧PL DW→Hard H5→Soft H6对同板CPU候选特征/logits精确，10805.344ms；DW路径165.075ms对CPU554.473ms。
- PARTIAL/N2：DW之前普通扩展Conv仍CPU，未完成完整四层连续块；整链慢于CPU9816.436ms10.07%，整体提速及独立质量验证PENDING。
- DONE/实际故障修复：4KiB burst拆分、启动HP0 PL GPIO复位释放、shell LF；Hard/DW安全卸载，Soft固定后用户确认冷恢复。
- DOING/N3：接真实16×128特征的末层V4R，先零预算精确，再预算/共享残差/窗口独立停止及证书。空间其余层随后推进，视频/屏显延后。

## 2026-09-30 N2下一次实际运行已准备

- DONE/BIT：GP控制/HP0 DW集成，4KiB拆分、连续两次真实张量SIM精确；修正版完整SoC 80MHz时序+0.102/+0.021ns及bit。
- DONE/BOARD软件：固定DMA客户端编译，缺匹配节点时加载/卸载成功；未访问DW/未START。
- DOING/N2：传入主链前段模型并临时启动匹配bit/DTB，测DW真实输出/耗时，再原16帧PL DW→Hard→Soft。N1/T01复用，N3真实C128 V4R随后；视频延后。

## 2026-09-30 N2实际DW16进展

- DONE/CPU集成：--dw16-assets接原16帧入口；当前逐通道量化max特征差0.148361/同片段类别相同，PC290.277ms，非BOARD/非验证集质量验收。旧单尺度0.932145不采用。
- DONE/SIM：实际960×7×7全部47040输出与独立整数参考精确；AXI输入/参数读、输出写及最后B完成、守卫通过。CODED/RTL优化：dw16_axi_master；独立gate超外部IO数量，不能称综合/bit完成。
- DOING/N2：实现GP控制包装与HP0连接、匹配DMA客户端，完整SoC构建后单帧/16帧上板。此为下一直接运行所缺路径，非扩展诊断。
- 板卡已物理恢复并确认无模块，未新增START；N1默认生产路径和旧资格产物保留。真实V4R PL随后推进，视频/显示延后。

## 2026-09-30 N1可运行优化已交付

- DONE/BOARD：原product16帧接本地C FNV，完整输出对CPU/旧product精确；总10666.786ms、初始化508.581ms，64 Hard/16 Soft完成。相较历史product降低11.19%，同板CPU9327.561ms，真实加速仍未完成。证据experiments/network_n1_fnv_20260930/verification.json。
- DOING/N2：针对现有CPU前段6033.589ms和Hard路径3461.627ms，复用实际相邻张量实现PL DW/Clip及连续空间块，接原入口；随后真实C128 V4R，不等待全空间覆盖。
- 当前板卡：Hard已卸载，Soft固定，已请求冷恢复；恢复前不再次硬件提交。视频预检/单帧软件草稿保留CODED，视频/DSI延后，不新增视频bit。

## 2026-09-30 用户恢复：内部网络优先，交由6.1 Sol持续执行

本次最新用户指令替代下文历史暂停和摄像头优先顺序。先优化保存帧内部空间链并接真实V4R，再接预处理/摄像头/屏幕；T01已通过不重做。用户允许继续隔离实现及必要易失板测，可配合重启；板卡实际状态待执行任务确认。详见SOL61_NETWORK_FIRST_HANDOFF_20260930.md。新N1～N6为待执行目标，此交接本身无新增硬件结果。

## 2026-09-30 用户要求工程分析后暂停（当前最新）

- DONE/BOARD只读定位：用户冷恢复和重插IMX415后，FST1 ABI10003仍见I²C无ACK锁存、RX时钟/HS有效/CSI/ISP帧/AXI写全部0；PS PL GPIO复位未释放已定位并按既有固件释放。没有运行采集DMA或NPU。证据`experiments/video_capture_probe_board_20260930_1/after_reseat_probe.log`。
- DONE/工程分析：核对用户指定两个可行demo。真正CSI→DSI编译顶层为`11_csi_dsi_imx415_7cun/soc_prj/uisrc/01_rtl/system.v`，4lane和1024×600 DSI；`01_fdma_vdma_20251010`提供当前HDMI/ISP基础。完整结论`docs/reports/VIDEO_CSI_DSI_DEMO_ANALYSIS_20260930.md`。
- CODED/未板测：`implementation_video/capture_model_clip.py`补充PL GPIO复位释放、ABI10003和I²C预检，语法检查通过；不称实际采集成功。
- PAUSED/下一直接动作：以真正DSI顶层保留其物理I_sysclk/PLL/复位/屏输出，再整合当前受控FDMA与主链，先实采真实帧。用户明确要求本次分析完成后暂停；实体屏显、真实视频16帧、拒识校准和加速收益均PENDING。

## 2026-09-30 DSI帧软件出口

- DONE/CPU实际运行：原16帧入口--display-dsi-frame产生1024×600 B,G,R,0帧，2457600B与PNG逐像素精确；128维特征/logits对既有CPU product差0，255.726ms，NPU0。
- PENDING/实体屏显：当前采集bit仍是HDMI顶层/读回关闭，须实现保留缓冲的DSI扫描输出并上板；不把软件帧文件认作屏幕已亮。当前唯一实际板测阻塞仍是CSI采集0帧后的物理冷恢复确认。证据experiments/display_dsi_software_20260930_1/verification.json。

## 2026-09-30 本地定位构建

- DONE/BIT：针对实际CSI采集0帧，FST1 ABI10002只读定位版本独立综合/P&R/最终STA/BIT，时序+0.140/+0.020ns；现有采集入口支持ABI10001/10002，仅读工具已实现。
- PENDING/BOARD：在用户确认物理冷恢复且继续上板后，读配置/CSI/ISP/AW/B定位第一个断点；当前未下载、未采集、未NPU START。仍不称摄像头/DSI功能完成。证据experiments/video_capture_probe_20260929_1/{capture_final.ts,capture_bitgen.log}。

## 用户暂停时接续（2026-09-29）

- T01 DONE/BOARD：product16帧、特征与validate精确、12011.346ms，详见下节。
- T02 PAUSED/实际阻塞：CSI/DSI已连接，但首次实际采集0完整帧/8秒超时、NPU0。采集关闭，物理恢复尚未确认。定位候选仅完成综合，未P&R/BIT/BOARD；恢复后先定位0帧。DSI未接入当前HDMI采集顶层。
- T03 PAUSED/部分实现：固定box＋双线性软件参考已接实际CPU空间128维，候选特征相对Pillow max2.021，不替换默认；双线性RTL及测试激励CODED/SIM待做。
- 目标按用户“先暂停吧”明确暂停；无继续运行或轮询。证据video_capture_board_20260929_1/failure.tgz、preprocess_20260929_1/verification.json。

## T01生产模式验收（2026-09-29最新）

- DONE/BOARD：product同进程16帧，64 Hard/16 Soft完成，金样调用0；16×128与既有validate字节精确、logits差0。整链12011.346ms、初始化1398.807另计；仍无相对CPU加速。
- DONE/释放：Hard卸载0。Soft结束固定，物理恢复已请求；不热重试，首次reason14根因UNKNOWN。
- DOING/T03准备：固定全帧预处理软件参考/双线性RTL，等待物理条件期间直接实现。PENDING/T02实际摄像头与屏幕、T04～T07。证据experiments/product_20260929_T01_cold2/verification.json；以下T01未验收文字为历史。

## T01当前执行（2026-09-29）

- DONE/CODED及CPU运行：原clip/image入口product|validate；H5静态资产一次加载、同进程16帧同执行器，product移出CPU金样/逐层大文件，Soft驱动同样移出金样；保留DMA/完成/故障固定。PC两模式16×128/logits逐值相同，板端CPU product9314.887ms且与旧BOARD CPU字节相同。
- DONE/目标编译：H5 ABI48350001，Soft1000b，核心/驱动版本对齐，旧二进制保留。真实product首次Hard第0片START前reason14/作业writes0/CPU oracle0，Soft未执行，模块固定。
- DOING/T01：物理冷恢复后完成product硬件16帧与已资格validate输出/CPU-only耗时对照；不把CPU回归或构建写成T01硬件完成。入口experiments/product_20260929_T01/run_product_board.sh，证据product_vs_validate.json。
- PENDING/T02～T07：真实摄像头/屏幕与逐块预处理、空间、真实V4R PL，沿用施工单与既有模型；不重做Pool/parser资格。

## 当前现场阻塞（2026-09-29）

- BLOCKED：连续三轮仍同一次开机/旧Soft固定，最新uptime5250.44s，无正在运行的capture/clip进程。需要物理冷恢复及IMX415连接才能执行已准备采集bit/保留DTB/16帧主入口；屏幕接口待确认。现有功能接线准备已完成，不增加重复静态前置。
- 目标范围保留：实时采集、实体屏显、动作切分/拒识和多窗口持续运行尚未验收；已有START授权持续。此状态为外部条件阻塞，非完成或用户主动暂停。

## 当前视频入口接续（2026-09-29）

- DONE/接线代码及PC运行：run_hard_soft_clip --capture-fdma连接实际采集→私有16帧→原空间/TCN-V4R→末帧结果渲染；实时分支未BOARD。修改后保存图片CPU运行305.491ms/16×128及logits与旧PC逐值相同，NPU0；板端入口--help通过。只修复实际旧包runtime路径，无重拷模型。外部阻塞仍冷恢复/相机连接。

- DONE/BOARD软件：私有Pillow复用旧USB包；真实PNG预处理106.022ms/3×224×224与PC字节相同；中文结果PNG板端生成并修复数字字体缺失，已取回目视通过。无新NPU提交，非实体显示。
- DONE/BIT准备：采集＋原Soft候选综合/P&R/STA/bit生成通过，SWNS+0.103/HWNS+0.022ns；新保留DTB生成。未下载/启动，屏幕读回仍关闭。
- DOING：冷恢复后启动候选、实际IMX41516帧进入已通过Hard＋Soft链。串口4097.95s/旧Soft仍固定，用户重启回复尚未对应可观察冷启动，已再次请求物理恢复；相机/屏幕连接仍待回复。
- PENDING：真实采集数值/耗时、实体屏显、动作切分/拒识校准和多窗口持续运行。吞吐优化延后Astra；下节已通过空间/时序证据复用。证据video_demo/2026-09-29-soft-capture/stage_receipt.json。

## 当前连续Hard＋Soft16帧已通过（2026-09-29）

- DONE/PC可运行显示：真实板端分类报告＋真实末帧→1024×600中文结果图，布局目视通过；同clip入口--display-font完成16PNG→空间CPU参考→V4R→result.png。未写实体屏幕、未采摄像头。
- 当前外部条件：只读串口uptime1371s，Soft仍固定、/dev/video与/dev/fb均无；用户物理恢复及摄像头/屏幕连接回复未收到。主链直接接入的软件准备已可运行，不制造新静态前置，目标active。

- DONE/BOARD：同进程CPU→实际Hard H5→实际Soft H6→128维×16→真实CPU TCN/V4R，64 Hard/16 Soft START全成功，实际空间22728.142ms/整链22847.785ms，初始化1103.892另计；非实时或加速证明。
- DONE/数值：所有实际两算子独立整数精确、完整Soft缓冲与严格IRQ/完成通过，同实际Soft尾部max2.50340e-6，同特征时序logits max4.44e-16；前段PC/板34字节差1LSB、完整候选特征max0.0120914边界保留。
- DONE/BOARD：新实际Hard＋Soft16×128保存特征接2层Hard TCN＋CPU末层V4R，51.738ms、2释放/卸载0，原始输出独立INT64精确、预算区间覆盖/零预算精确，不称V4R FPGA。
- DONE/实现及PC实际运行：同入口--frames-dir/--raw-layout复用真实预处理与离线FDMA解码。真实16PNG与冻结输入精确、特征/logits精确同PC参考；313.043ms（预处理59.199/初始化66.753另计），实际NPU0，非相机。
- DOING：接实际采集帧与显示；相机/屏幕当前未连接，已询问可连接性。Soft会话结束固定，证据完整保存后已请求物理恢复；不因等待暂停目标。
- PENDING：实际IMX415连续采集/动作切分/拒识校准/屏显与识别质量；多窗口持续运行尚未验证。DEFERRED：吞吐优化后续Astra。
- 证据hard-soft-clip-board/{hardware_verification,hard_prefix_pc_verification}.json、hard-soft-saved-frames/{input_verification,cpu_verification}.json。以下为历史阶段。

## 当前空间特征接TCN/V4R（2026-09-29）

- DONE/BOARD：当前空间CPU16×128保存特征→真实C128/budget32 CPU V4R，61.295ms，类别区间确认/无回退/零预算精确；主入口复用原时序实现，不是V4R FPGA。
- DONE/BOARD：同特征→TCN前两层实际Hard→末层native CPU V4R→分类，53.239ms、2 START/释放/卸载0。两实际输出全部独立INT64精确、同输出PC logits max4.44e-16。不是连续Hard＋Soft16帧或新的整链耗时。
- DONE/实现：run_hard_soft_clip新增onnx/pointwise-cpu/v4r-batched-cpu参数，默认onnx；2989B入口补丁可接连续空间候选，无重编/重传原模型。
- DOING：物理重启仍待回复，旧Soft单次模块固定且未再START；Hard已释放卸载，Soft原三缓冲经TCN后仍同捕获。随后实际16帧Hard＋Soft空间，目标active。
- PENDING：连续空间验收/完整TCN-V4R串接、相机屏幕、切分拒识、产品质量；吞吐优化交后续Astra。证据hard-soft-current-v4r/verification.json。

## 当前Hard＋Soft单图通过，下一项为连续16帧（2026-09-29）

- DONE/BOARD：现场CPU→Hard H5四片→Soft H6残差→CPU128维，1506.721ms；两个实际算子独立定点精确，同实际Soft尾部max差2.265e-6。实际1普通Conv＋1Add NPU，其余CPU；Hard4释放/卸载0，Soft1严格成功但仍固定。无提速结论。
- DONE/BOARD CPU：新入口16帧→16×128→真实TCN，9514.647ms/咳嗽0.985463，实际NPU0。同实际输入定点精确、同实际Soft尾部max2.503e-6、同特征TCN logits差0。前段跨平台共34字节各差1LSB，最终PC候选特征max差0.0120914；不是跨平台相等或识别率。
- DONE/实现及native编译：独立h6_serial ABI1000a，成功后复用同DMA、失败拒绝再次提交、结束仍固定；16帧入口/实际模块冷恢复包已封存，新模块未加载/START。
- DOING：用户物理重启待回复，清除当前单次Soft固定实例；随后实际16帧Hard＋Soft→真实TCN，核验各帧输出/耗时。等待期间直接服务此运行的实现/编译/CPU集成已完成，目标active，不因未回复暂停。
- DEFERRED：分片/吞吐提速交后续Astra。PENDING：连续Hard＋Soft验收、已有TCN/V4R后端串接、相机/屏幕连接、切分拒识和产品识别质量。
- 证据：hard-soft-live-board/hardware_verification.json；hard-soft-serial/{cpu_verification,receipt}.json。以下小节是历史阶段。

## 当前现场Hard＋Soft可运行入口（2026-09-29）

- DONE/实现及BOARD CPU：训练浮点CPU前段→H5定点参考→Soft残差参考→浮点CPU尾部，128维，614.672ms；实际NPU0。原始定点数组精确，PC/板量化输入相同，尾部max2.265e-6/allclose。
- DONE/目标编译：实时H5接口复用现有四片ABI，Soft固定二输入ABI10009；两模块编译完成，native UAPI尺寸一致，新模块未加载/START。
- DONE/当前候选质量边界：单图对全浮点特征max0.460721；现有12真实片段软件类别12/12同浮点，最高特征差0.777864/logits0.446760，不称产品准确率或浮点特征一致。
- DOING：等待已请求的物理恢复，随后用已编译冷恢复包执行现场Hard→Soft→板端128维；目前旧Soft模块仍固定，禁止热卸载/重复START。
- DEFERRED：分片/实际加速优化，按用户最新安排后续交Astra。PENDING：持续16帧Hard/Soft、时序全链、实采/切分拒识/实体屏幕。
- 证据：hard-soft-live-board/verification.json与receipt.json；hard-soft-float/clip_verification.json。目标active。

## 当前Hard＋Soft配合优先（2026-09-29，用户最新要求）

- DONE/BOARD限定：保存的真实Hard H5输出＋模型skip→现场Soft残差Add；1 START、IRQ0x4，输入/packet/守卫不变，原始7840B独立定点精确。
- DONE/PC接续：实际Soft输出进入真实量化网络尾部，128维；对同Hard＋ONNX Add尾部max差0.0483776。不是连续整图或板端尾部。
- 实际差异已解释：Soft对ONNX Add12字节差1LSB；初模块reason5固定，独立定点金样更新下一源码未重编。START到IRQ0.07053ms，不称加速。
- DOING：物理恢复后接通现场Hard卷积→Soft Add→板端后续空间网络，报告完整128维、数值误差及实际耗时。当前等待用户物理恢复，同时复用已取得原始输出做尾部集成。
- DEFERRED/用户安排：HardNPU分片与稳定加速优化交由后续Astra处理，不作为当前功能阻塞。
- PENDING：同进程持续Hard/Soft链、真实16～32帧主链、实采/切分拒识/屏幕；相机和屏幕尚未连接。
- 证据：2026-09-29-hard-soft-residual/verification.json及board_run.log，目标active。

## 当前两层空间整图实际结果（2026-09-29）

- DONE/BOARD候选：CPU→H7六片→真实CPU桥接→H10八片→128维；14原始片独立整数精确，特征PC/板allclose max1.40e-6，正常卸载。
- DONE/BOARD连续单图：ABI0x48470101每层共享输入，三对42START/释放全部通过；首14独立验收，后28板端字节重复比较通过。实际两层NPU，CPU33普通/17depthwise/10Add。
- 未达到性能验收：首次474.325对CPU432.422ms；同进程三对混合504～515ms/CPU424～458ms，无稳定加速，不替换默认路径。
- DONE/CPU质量边界：12真实片段两层预测类别均同浮点；特征最高差0.311739/logits0.154113，不称浮点数值相同/产品精度。两层16帧板端分类未运行。
- DEFERRED（本日最新用户要求）：针对已测14分片运行开销复用更大厂家分片候选减少提交，进行实际对照；保留真实超时固定/物理恢复，不以覆盖数量代替收益。
- PENDING：稳定空间提速、V4R FPGA收益、Soft真实模型接入、实采/切分拒识/实体屏幕。证据2026-09-29-dual-spatial与本日工作日志。

## 当前真实V4R接入结果（2026-09-29）

- DONE/BOARD：真实空间保存特征→前两层TCN HardNPU→末层C128非零预算V4R CPU→训练分类，咳嗽0.978935；实际输入/输出复用资格字节结果，两次释放/卸载0。
- DONE/软件及BOARD CPU：批量V4R与纯C核已接主特征入口；25真实用例11区间确认/14精确回退且类别全部相同，native三层实际输入预算0/32整数数组精确等于Python。不是V4R FPGA验收或产品识别率。
- 未达到性能验收：Python混合389.503ms→native混合51.140ms，仍慢于三层TCN NPU约29ms/原CPU；预算32摘要开销抵消残差节约。保留原默认路径，不称提速完成。
- 下一空间主线：复用已有NPU层扩大真实CPU桥接的有效覆盖并实测，当前仅H10；Soft两个尺寸Pool历史通过，但真实模型没有MaxPool，停止重复该实验。H12仍专项未解，不阻断CPU首层。
- PENDING：V4R FPGA/实际收益、稳定空间提速、连续采集、切分/拒识和实体屏幕。用户确认相机/屏幕未连接；上板授权仍有效。
- 证据：real-tcn-grid7-fixed-board资格结果、2026-09-29-v4r-batched-real-tcn/{verification,board_verification}.json；本日工作日志。

## 当前真实TCN产品接口通过（2026-09-29）

- DONE/BOARD：保存的真实空间16×128→真实C128三层TCN Conv NPU→CPU残差/池化/分类，咳嗽0.978550。三层原始输出独立整数精确、PC/板logits max8.88e-16，成功释放/卸载。不是C4演示或V4R专利硬件。
- DONE/BOARD：7×7有效16token路径通过，4×4第16通道起数值错误保留历史；厂家实际权重与源相同，深层原因UNKNOWN。
- DONE/BOARD产品：固定三模型ABI0x54430107预加载、每层真实输入、保留DMA/内容守卫/IRQ/work/失败固定；运行时oracle0。诊断292.168→28.324ms，加载8.104ms另计，尚慢于CPU。
- DONE/BOARD主入口：run_temporal_features --backend pointwise-hardnpu-fixed实际3START/释放/卸载，29.378ms；该次CPU冷16.442ms、类别相同、浮点logits差0.0385352，原始字节与资格结果相同。
- DOING：复用已资格TCN接口继续真实V4R/专利预算适配及主链集成；不把当前NPU计算正确当加速收益完成，不长期阻断相机/显示产品链。
- PENDING：空间/时序稳定加速、V4R非零预算/硬件收益、IMX415实采、动作切分/拒识、实体屏幕；H12定点专项保留。
- 证据：2026-09-29-real-tcn-grid7-fixed-board/{verification,main_entry_verification}.json；工作日志2026-09-29-real-tcn-integration.md。

## 当前真实TCN硬件接入（2026-09-29）

- DONE/产品复用：板端混合128维及真实16帧分类已通过，不重跑普通层全套；PC新pointwise-cpu时序接16图完整计算647.345ms、咳嗽，actual NPU0。
- DONE/软件：厂家三层真实776B包捕获；标量量化25/25用例类别一致，真实C128全部通道；TCN ABI0x54430000目标模块编译和默认关闭板测通过。
- DONE/首次硬件完成：物理恢复后TCN首层writes8/IRQ1/work5/guard0，RUN4.026ms；前16通道精确，但全输出1323B差异，未数值通过。
- DOING：捕获实际CMA权重与源常量对比、修复第16通道起的实际差异，然后运行三层并测分类/耗时。后两层未START；不自动重试未知设备，超时/未验收状态继续保留DMA并物理恢复。
- PENDING：V4R非零预算/硬件加速收益、空间稳定提速、IMX415实采、切分/拒识/实体屏幕。H12专项保留，不阻断CPU首层主链。
- 证据：2026-09-29-real-tcn-first-prestart/cold_retry_1_evidence.tar.gz；本日real-tcn-integration工作日志。

## 当前串行主链与真实时序接入（2026-09-28）

- DONE/BOARD：dfc9d4固定模型复用映射/IRQ、4KiB包、加载及完成验证、输入/守卫前检，真实16帧与三组同图152原始片独立整数精确，152释放、卸载0；128维特征与上版相同。
- DONE/BOARD：16帧6935.251ms/TCN3.753ms、咳嗽0.979300，同片CPU7143.087ms；三组单图混合仍慢，稳定整体提速未验收。
- DONE/BOARD CPU：run_temporal_features.py复用实际16×128，INT8 TCN35.563ms/完整C128 V4R软件59182.525ms，logits逐值相同、PC INT8一致。时序硬件未完成，默认ONNX。
- DONE/CPU：真实TCN展开为三层C384→O128的1×1/4×4张量，每层6144B输入/49152B权重，INT64和最终logits逐值匹配完整INT8；保存实际张量，不伪造包或板证。
- DOING：真实TCN点卷积厂家包及每输出requant适配，验证批量多通道时序硬件，再接专利预算收益；避免28672小任务MMIO演示替代产品。空间稳定提速按实际瓶颈处理，不阻断时序适配。
- PENDING：IMX415实采接统一空间入口、动作切分/拒识、实体屏幕；H12历史首层超时定点修复。
- 证据：docs/records/hardnpu_system/2026-09-28-product-fixed-serial-board/verification.json；本日阶段工作日志。

## 当前固定模型主链（2026-09-28）

- DONE/BOARD：独立产品ABI0x48400100固定八包/权重一次预加载、共享帧输入，运行时保留DMA内容/守卫、完成/CRC/故障固定；主链cpu-h10-fixed-model不计算CPU卷积金样。旧诊断版保留。
- DONE/BOARD：单图8START数值精确、128维及原始输出与诊断版字节相同；网络472.268ms，加载14.365ms另计，仍慢于CPU440ms。
- DONE/BOARD：真实16帧只加载一次，128原始片全精确/128释放，特征与诊断路径字节相同，TCN咳嗽且PC/板logits相同。端到端18.659→8.248s（55.8%减少），卸载成功。
- NOT_SELECTED：宽读取内容比较试验无提速，已回退，不部署试验模块。
- DOING：针对剩余模型内容重复检查/提交及CPU前段继续减时，测同模型CPU对照与实际收益；后续真实TCN/V4R硬件、相机/拒识/屏幕。不是全图NPU或实时系统完成。
- 证据product-fixed-model-board/及本日日志。

## 当前诊断提交转固定模型运行（2026-09-28）

- DONE/BOARD：保留完整FNV和守卫，DMA校验改8字节读取；同图8原始输出及128维特征字节一致，默认关闭/完成/释放/卸载通过。RUN174.563→40.220ms，客户端390.295→122.704ms；单图714.934ms。
- DONE/BOARD耗时定位：START到完成中断线程八片合0.51618ms，含IRQ延迟，非纯核心；测时轮网络649.520ms，仍慢于CPU440ms。现阶段耗时主因已定位为提交/检查和CPU前段，不能据此称端到端加速完成。
- DOING：固定模型预加载八包/权重，每帧一次输入、实际输出完整性/守卫和完成验收，停止每帧重复全层CPU金样；首先同图实测，再真实16帧。保留故障固定和已通过诊断版。
- 未完成：空间更多有效加速、TCN/V4R硬件收益、IMX415连续采集、切分/拒识/实体显示。H12不是CPU耗时最大层，专项不阻断已跑通整图。
- 证据product-dma-hash-board/；详细当前范围以下节及本日工作日志为准。

## 当前板端混合空间与真实时序（2026-09-28）

- DONE/BOARD：单图真实CPU前段→H10八START→CPU尾部128维；八片精确且尾部allclose。实际NPU一层、其余34普通/17depthwise/10Add CPU。与完整浮点特征max_abs0.0573455，不称全图NPU或浮点数值相同。
- DONE/BOARD：真实16帧预处理输入→128START→16×128特征→正确训练TCN咳嗽分类。原始片128/128精确、同特征TCN PC/板logits相同，模块卸载成功。端到端18.659s、TCN27.129ms，含逐帧验算，不是实时速度或产品精度。
- DONE/BOARD软件优化：精确BLAS验算与原整数参考16真实输入/3边界相同；单图网络1132.132→916.274ms，输出逐字节相同。纯CPU439.906ms，混合尚无速度收益。新BLAS未重跑16帧总耗时。
- DOING：针对已测混合开销与空间加速瓶颈继续实现；真实TCN/V4R仅软件映射，尚无产品硬件收益。保留H12超时和冷启动空闲拒绝专项，不阻断整图CPU桥接。
- 后续：IMX415实际连续帧/切分/拒识/屏幕；本次无新实时视频BOARD。用户已恢复上板授权，下文历史限制被本次授权替代。
- 证据：product-mixed-board/{verification,blas_verification}.json、product-sequence-board/verification.json及原始归档；本日日志。

## 当前原始帧入口（2026-09-28）

- DONE/PC：单图--raw-frame/--raw-layout及序列--raw-layout实际接同一空间/TCN链；合成BGRX布局内真实像素的16×128与PNG逐字节一致，咳嗽，530.155ms。单帧CPU特征相同，网络6.427ms。
- 边界：只文件，不是IMX415实采/DDR所有权；当前已找到样例均合成布局，实采像素/stride/ROI需板端确认。
- 首要DOING仍单图真实CPU＋H10正确128维与板端耗时，暂不上板有效；之后再实际相机、切分/拒识/实体显示。未新增通用状态机或复制整工程。
- 证据experiments/product_raw_input_20260928/verification.json；日志2026-09-28-spatial-temporal-integration.md。

## 当前主链回放接入（2026-09-28）

- DONE/PC：连续回放接已有空间执行器，288源帧→36真实TCN窗口→12事件；CPU/H10定点预测事件类别和触发帧12/12相同，均弱标签匹配9/12。空间p50 3.211/30.312ms，非板端加速。
- DONE/PC字幕：中文字幕视频实际解码376帧/8fps，首事件视觉检查；不是相机/屏幕板证。
- CODED：回放显式cpu-h10，每源帧8START，未执行；设备失败停止并保留现场日志，无自动重试/装卸。当前暂不上板保持。
- 首要DOING仍单图真实CPU＋H10/128维/板端耗时；后续相机实际帧、自动动作边界、拒识、实体显示。不能以人工黑场或9/12弱标签宣称产品完成。
- 证据：experiments/product_replay_20260928_{cpu,h10_prediction}/；日志2026-09-28-spatial-temporal-integration.md。

## 当前真实定点时序接入（2026-09-28）

- DONE/PC：44训练片段真实空间特征校准INT8 TCN；24测试特征类别全与浮点一致，max logits差0.0121291、无输入截断；残差/池化/分类明确CPU浮点。
- DONE/PC映射：一个真实片段完整C4 V4R整数参考拆分（相位/跨组累加/一次偏置），28672任务结果与直接INT8逐值一致，非硬件完成。
- 性能：INT8 CPU中位3.185ms，C4参考1724.977ms，没有加速收益；ONNX默认保留。后续硬件方向需批量多通道，不做28672次MMIO调用来冒充加速。
- 当前首要DOING：单图真实CPU＋H10正确128维及板端耗时，用户暂不上板限制保持。视频/拒识未完成。
- 证据：real-tcn-int8-train、real-tcn-int8-c4-verification、sequence-cli-int8-tcn；当前日志2026-09-28-spatial-temporal-integration.md。

## 当前单图部署接续（2026-09-28）

- DONE/PC：精简自包含运行目录，CPU及H10定点CPU预测128维与此前对应输出逐字节相同，网络4.216/31.569ms。复用冻结目标模块，无内核重建。
- CODED：新客户端分片RUN计时，Python区分验收金样/文件准备/客户端/RUN耗时。新客户端尚未目标编译，电脑无本地Linux编译环境，待恢复上板后native GCC。
- DOING：单图真实CPU＋H10正确128维及实际耗时；暂不上板限制保持。H12先CPU，其余层不作独立板证前置。
- 下一动作：恢复上板后直接使用experiments/h10_product_runtime_20260928_1；先目标编译与CPU基线，再按既有冷态/模块/合法DMA条件运行八片，实际失败固定/请求物理恢复。
- 证据：该目录pc_verification.json、runtime_manifest.json及PC结果；当前日志2026-09-28-spatial-temporal-integration.md。

## 当前真实V4R时序适配（2026-09-28）

- DONE/PC：真实128通道三层TCN以V4R零预算块残差结算实际计算；24组真实特征logits对照max_abs1.34777e-6、24类别一致，mask池化通过。已接入序列CLI，非C=4演示。
- 性能：CPU V4R参考中位57.753ms，ONNX0.197ms，无加速；零预算补算全部残差，默认仍ONNX。现有C=4 INT8硬件不支持此浮点多通道膨胀路径，不写硬件完成。
- 当前直接阻塞：用户暂不上板，单图实际H10混合及板端耗时未验收。待解除后优先完成该里程碑，沿用已通过载荷与成功释放/失败固定路径。
- 后续：真实时序量化/硬件适配及有收益的预算测量、拒识、IMX415连续视频与显示。未新增通用调度/防御框架。
- 证据：2026-09-28-real-tcn-v4r-zero/、2026-09-28-sequence-cli-h10-v4r-zero/；日志2026-09-28-spatial-temporal-integration.md。

## 当前可运行交付（2026-09-28）

- DONE/PC：统一单图与16帧入口，实际真实图像→16×128→训练TCN，CPU及H10定点CPU预测均与前轮对应特征逐字节相同。首片均为咳嗽，端到端102.314/543.816ms，仅PC单次。
- DOING：单图CPU＋真实H10输出正确128维及板端耗时。当前暂不上板；已实现的硬件模式未执行，实际NPU0。只H10候选NPU，其余34普通Conv/17depthwise/10Add及投影CPU。
- 后续：真实128通道TCN/V4R适配和测量、拒识校准、摄像头显示。H12首层超时专项修复继续后移，不阻断整图入口。
- 证据：2026-09-28-sequence-cli-{cpu,h10-prediction}/；当前日志2026-09-28-spatial-temporal-integration.md。

## 当前产品时序接入（2026-09-28）

- 实际PC运行：12真实片段×16帧×128维→训练三类TCN。浮点9/12；旧诊断量化4/12全过敏，不能继续作产品空间输入。
- 已实现并运行：正确浮点前段/尾部，只替换H10真实倍率/移位CPU预测，9/12且12分类与浮点全一致；新默认图片CPU使用训练浮点模型，非退化量化图。
- 下一DOING：单图真实CPU＋H10板端混合正确性/实际耗时，仍受用户暂不上板限制。浮点handoff候选不需先通过所有普通层；已有硬件packet不变。
- 后续：真实128维TCN/V4R适配、拒识校准，再视频显示。当前TCN仅CPU，V4R未执行，75%为弱对齐小测试集不是产品验收。
- 证据：2026-09-28-spatial-temporal-16frame/results.json、2026-09-28-float-prefix-h10/results.json，日志2026-09-28-spatial-temporal-integration.md。


## 当前里程碑：单图实际CPU＋HardNPU混合空间链

- DOING：用户明确要求的单图混合链。CPU桥接实际失败已修复，完整串行CPU链两图128维与源图逐字节一致；CLI单图片入口已运行。当前实际NPU0，不能称混合通过。
- 可运行CPU准备完成：2会话最小H10Spatial前段/尾部，用当前图片输入计算真实H10定点预测，128维与逐层预测一致；CLI显式h10-fixed-cpu通过，实际NPU0。预测特征相对CPU源图max_abs0.046371/0.049754，分类影响未验收。
- CODED待目标构建/板测：cpu-h10 CLI及H10Executor，复用现有模块/八片客户端；作业携带真实packet/weight及动态input/oracle，原成功释放/失败固定保留，无自动CPU回退。
- 当前外部限制：用户暂不上板持续。等待解除前继续直接用于这一链的接入；没有为所有35层分别板测设前置，H12先CPU，专项超时另行修复。
- 下一产品阶段：固定16～32帧真实128维特征→实际TCN/V4R分类/拒识→IMX415连续采集及屏幕；本阶段尚未完成这些。
- 运行证据与PC耗时：2026-09-28-serial-spatial-cpu/verification.json；首轮15.646/18.698ms，后续中位37.167/8.440ms，非板端耗时、无加速结论。日志2026-09-28-serial-spatial-integration.md。
- 新最小入口PC定点预测30.562ms（前段3.499、CPU定点26.823、尾部0.209），真实板端混合耗时未知；证据2026-09-28-minimal-h10-cli/timing.json。


## 2026-09-28 执行优先级修订（用户要求）

- 下一推荐任务：修复prepare_hardnpu_cpu_bridges.py的实际退出1，产出真实张量计算结果；接现有NPU层形成单图完整特征。暂不自动标记DOING或通过。
- 然后：固定16～32帧时序/TCN/V4R适配与误差、耗时对照；再接IMX415与屏幕，报告实际NPU/CPU分工。
- H12实际超时保留针对性修复；可先CPU首层完成混合链，不把全35普通层单独板测作为首次混合整图的强制前置。
- 后移：非当前必要的通用状态机扩展、多线程、跨帧票据、错误注入、全量重复哈希/打包、更多Pool诊断。不删除已有成果。
- 具体实验权限依当前任务最新用户指令；本次未恢复上板、未启动测试。当前工作副本以C:/Users/16429/.codex/worktrees/19de/fdma_imx415_20251008为准，原目录旧状态不作为新进展依据。


## 2026-09-28 所有权账本实现

- CODED/HOST状态流通过：tensor_ownership.py；374节点/304激活/10残差，707错误拒绝无改写；遗漏消费者声明拒绝，独立frame/nonce阻止旧回执，DEVICE不能CPU完成，失败固定预约。
- 未实现：实际数据allocator/算子执行输出检查、设备完成适配器、DMA排空/生产驱动。账本RELEASED不代表实际释放硬件内存，事件须单线程串行。
- DOING：完整HardNPU，当前只静态；H12和其余真实包/全图/质量/SoftNPU/视频仍未完成。
- 证据：`docs/research/HARDNPU_TENSOR_OWNERSHIP_HOST_20260928.md`。


## 2026-09-28 全图静态调度合同

- 静态完成：374节点拓扑/52Conv量化边界、66动态Q/DQ参数精确核对、10真实解量化残差分支、78模型/360作业源图精确绑定。
- CODED/语义准备：304激活tensor消费者完成和设备访问结束要求，最终[1,128]float32特征须外部释放。
- 未实现：实际张量所有权状态机/内存管理、backend融合/分配、DMA排空及全图运行；六匹配普通层历史报告计数保持。
- DOING：HardNPU，用户恢复实验前继续静态；H12、新厂家包/驱动及质量/SoftNPU/视频仍未完成。
- 证据：`docs/research/HARDNPU_GRAPH_HANDOFF_CONTRACTS_STATIC_20260928.md`。


## 2026-09-28 普通层输入取块

- CODED/HOST_COMPILED：pw_tensor_extract及28层两帧360输入/56输出主机核验入口；新增extract长度/范围/溢出检查及编译后静态核对。
- HOST_RUNTIME_NOT_VERIFIED：WinError4551应用控制拒绝首个新程序启动，未取块比较/拼接重验；保留失败和编译证据，不记通过、不绕过系统控制。
- DOING：完整HardNPU，静态元数据合同继续；ARM目标构建及取块实测待恢复实验，H12/其余真实包/全图/质量/SoftNPU/视频仍未完成。
- 证据：`docs/research/HARDNPU_POINTWISE_C_INPUT_EXTRACT_STATIC_20260928.md`。


## 2026-09-28 普通层张量布局代码

- CODED/主机核验完成：common/pointwise_tensor_layout.c/h；28层两帧360分片乱序插入，56完整CPU输出逐字节一致，缺块/重复/尺寸/越界/溢出拒绝。
- 未执行：Linux ARM目标编译、输入动态裁剪、通用生产调度/驱动、层间量化交接及连续硬件运行。新代码不定义DMA/ABI。
- DOING：完整HardNPU；等待用户恢复上板通知时继续静态推进。H12、其余层厂家包、生产恢复、质量/SoftNPU/视频仍未完成。
- 证据：`docs/research/HARDNPU_POINTWISE_C_LAYOUT_STATIC_20260928.md`。


## 2026-09-28 pointwise真实载荷静态工具

- CODED/主机核验完成：通用真实载荷解析、孤立1×1模型合同核对、分包偏置/通道范围及定点预期工具；H5/H10十八组历史数据复核精确，78模型元数据通过，三类损坏拒绝。
- 未执行：其余78模型厂家软件捕获/硬件；没有给待捕获模型冻结合成packet或硬件金样。
- DOING：完整HardNPU；用户恢复通知前只静态推进。多包DMA基址重定位/生产ABI、H12及全图/质量/SoftNPU/视频仍未完成。
- 证据：`docs/research/HARDNPU_POINTWISE_PACKET_STATIC_CONTRACT_20260928.md`。


## 2026-09-28 普通层剩余范围静态批量准备

- DOING：HardNPU完整系统路径，仍先H12真实首块/整层，再扩其余普通层；当前按用户要求只静态。
- CPU准备完成：28个尚未准备的1×1层、两帧56次源图对照和独立整数参考精确一致；不重复六个历史报告和H12。
- CPU分区准备完成：78子模型、360作业，全区域恰好一次并逐字节拼回28整层；775文件哈希复核通过。
- CODED/输入准备：参数化未来厂家隔离批处理、86文件包/78模型、shell和PowerShell语法、VerifyOnly。未目标编译/厂家支持性或packet捕获/BOARD；不得使用H12T固定ABI提交这些不同形状。
- 提出128KiB输入/64KiB权重/32KiB输出/160输出通道准备预算，仅候选数据分片，不是硬件能力或生产接口。
- 硬件覆盖计数未变：35普通Conv中六个匹配历史报告，其余29（含H12）未新通过；depthwise/全图/生产调度/质量/SoftNPU整合/视频仍未完成。
- 证据：`docs/research/HARDNPU_REMAINING_POINTWISE_STATIC_PREP_20260928.md`。


## 2026-09-28 H12完整首层静态推进

- DOING/CODED：64空间块同模块整层用户调度，共享客户端、输出证据预检查、全夹具预检查、失败后不再提交、逐块释放成功后才继续；不是BOARD通过。
- 主机核验通过：实际C裁剪拼接代码两帧各64块非顺序归位，与此前冻结整层定点预期逐字节一致；重复/越界块拒绝。
- 准备通过：275文件整层恢复包逐成员/当前源码身份、VerifyOnly、暂存脚本语法。首块暂存改为14文件。Linux用户目标编译/Kbuild/小块和整层START未执行。
- 原整层超时新增静态定位：前16通道行0/56精确匹配，不证明其余张量或根因。等待用户恢复硬件实验期间继续静态推进。
- 证据：`docs/research/HARDNPU_H12_LAYER_SCHEDULER_STATIC_20260928.md`；全图/生产调度/SoftNPU整合/视频仍未完成。


## 2026-09-28 H12静态阶段当前任务

- DOING：H12首层完成路径。32×32对齐空间块64块CPU/定点裁剪拼接通过、厂家软件支持/Load/Unload及真实包静态核验通过。
- CODED/静态通过：独立h12t_tile ABI0x48421000；FNV常量修正、暂存就绪等待和VerifyOnly、主机地址边界/身份核验。候选只准备两帧首块，未64块硬件调度。
- BOARD未执行：小块暂存完整复制/目标构建/默认拒绝/START。用户要求暂只静态，待其通知恢复硬件实验；保持静态推进，不标目标暂停或完成。
- 原整层一次START超时根因UNKNOWN；29×29/pad0厂家拒绝证据已保留，32×32成功软件路径不代表硬件修复。
- 当前证据 `docs/research/HARDNPU_H12_ALIGNED_TILE_STATIC_READY_20260928.md`。全图、生产调度与视频未完成。


**历史29×29候选失败（不是当前32×32候选状态）：** H12小块软件捕获后续：6/6暂存通过，但隔离partition输出文件报错、Load进程signal11；无设备ioctl/分配、无START，无真实小块packet。失败归档已取回，根因待定位，不能记厂家支持或板证通过。

## 2026-09-28 H12当前推进项

- DOING：首层3×3/stride2 HardNPU验证。CPU/厂家软件/固定预期完成；默认关闭及卸载守卫通过；首次第0帧START超时、原始证据已归档，未通过BOARD。
- 已完成静态子项：64块halo输入、两帧CPU与定点拼接逐字节核验，小块厂家捕获脚本准备/语法通过。
- 下一步：冷恢复后厂家隔离捕获小块载荷、静态核验、独立候选构建及首块START；等待恢复期间继续审查。根因、整层BOARD、统一调度/全图/视频未完成。
- 证据：`docs/research/HARDNPU_H12_STEM_TIMEOUT_AND_SPATIAL_PREP_20260928.md`。不重复H4–H11已有通过测试。


## 2026-09-28 H11实际交接与后续覆盖（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H10→H11板端CPU尾部 | `TWO_FRAME_FLOAT_TOLERANCE_PASS_LIMITED` | 两帧实际硬件张量输入，512B特征误差2.98e-7/3.58e-7，明确容差通过，主机原始向量复核。 |
| 全图普通Conv覆盖 | `INVENTORIED/OPEN` | 35个普通Conv中6层有匹配单层板测报告，29层未匹配；不能视作35层实测。 |
| 首层3×3 Conv几何 | `DOING/P0` | 输入3通道224×224/输出32通道112×112，先提取金样和厂家分区再建立硬件合同。 |

## 2026-09-28 H10成功与H11交接诊断（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H10末尾普通Conv | `EIGHT_SHARD_TWO_FRAME_SINGLE_MODULE_BOARD_PASS_LIMITED` | 16次真实START/输出/释放通过，同实例双帧拼接和主机归档复核通过。 |
| H10→H11 CPU尾部 | `FLOAT_DIFFERENCE_DIAGNOSTIC` | 实际H10输入身份匹配，首轮CPU尾部逐字节检查未过；保存原始输出量测，不能提前称交接成功。 |
| 生产驱动、全图和视频 | `OPEN/P0` | 单层冻结包诊断证据不可外推全图；故障排空、量化质量、SoftNPU融合和实时视频仍需验收。 |

## 2026-09-28 H10恢复效率准备

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H10冷恢复整包 | `LOCAL_BUNDLE_HASH_VERIFIED/NOT_STAGED` | 43文件538502B，复用同SHA目标二进制，本地解包逐哈希检查通过；传输脚本语法检查通过，未板端运行。 |
| H10重新验证 | `WAIT_PHYSICAL_COLD_RECOVERY` | 当前仍固定模块引用1；先物理断电再上电，冷恢复核验后才能加载和尝试。 |

## 2026-09-28 H11尾部准备

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H11池化/投影CPU尾部 | `PC_CPU_FULLGRAPH_BYTE_EXACT_LIMITED` | 原始CPU帧尾部与完整图逐字节一致，H10两帧预测输入的特征预期保存；非板测。 |
| H10→H11真实张量交接 | `WAIT_H10_BOARD_OUTPUT` | H10尚待物理冷恢复和START板证，不能用定点预测冒充真实硬件输入。 |

## 2026-09-28 H10启动前拒绝（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H10八片真实包/定点预期 | `VENDOR_PACKET_VERIFIED/NO_HARDWARE` | 八片软件包和bias/几何/量化通过，完整图CPU与提取层零差。 |
| H10首次硬件提交 | `PRESTART_REFUSED/WAIT_COLD_RECOVERY` | 空闲读末值3，reason14、提交写入0；无START。证据已取回，待用户物理断电恢复后核状态。 |
| H10双帧八片与尾部流水 | `OPEN/P0` | 本轮无H10硬件输出；保留空闲门槛，先明确冷启动状态。 |

## 2026-09-28 H10末尾普通Conv（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H10八片CPU模型 | `CPU_SPLIT_PASS_LIMITED` | 八片160通道子模型拼接与提取完整层CPU逐字节一致；原完整图对照待补。 |
| H10真实厂家片包 | `DOING/P0` | 第0片904B软件包已核bias/几何/定点比例，余七片待捕获；恢复板端隔离环境中。 |
| H10硬件及尾部流水 | `OPEN/P0` | 无H10 START；须先闭合各片真实包与DMA合同，再接pool/projection等后继算子。 |

## 2026-09-27 H8/H9进展（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H8第17块depthwise | `TWO_FRAME_BOARD_CPU_HANDOFF_PASS_LIMITED` | H7两帧板输出交给板端CPU子图，逐字节匹配电脑预期；本层厂家后端尚未直接核验，无Hard START。 |
| H9第17块后置普通Conv | `FIVE_SHARD_TWO_FRAME_SINGLE_MODULE_BOARD_PASS_LIMITED` | 五片厂家包、10次START/释放均通过，原始输出与两帧拼接逐字节匹配板前定点预期，主机归档验证通过；逐作业文本日志仅首片和每帧末片留存。 |
| 第17块后继与完整图 | `OPEN/P0` | 提取后续残差/尾部、核验CPU与厂家分区，建立板上真实张量流水及故障恢复，再接视频；当前仅文件交接。 |

## 2026-09-27 H7六片真实板证（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H7第17块前置普通Conv | `SIX_SHARD_TWO_FRAME_SINGLE_MODULE_BOARD_PASS_LIMITED` | 六片真实904B包、12次START与释放均通过，两帧47040B原始输出和拼接与板前定点预期逐字节一致；见H7板测报告。 |
| H7较大规格三包 | `SOFTWARE_CAPTURE_ONLY` | 隔离厂家软件捕获3×386字、每包320通道，未硬件START；沿用H4成功的160通道路线。 |
| 第17块depthwise与后置普通Conv | `TODO/P0` | 先提取CPU张量并判定厂家后端；不能从H7普通Conv推断depthwise支持。 |

## 2026-09-27 H5到残差Add交接（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H5板输出到残差Add | `TWO_FRAME_BOARD_CPU_HANDOFF_PASS_LIMITED` | 两帧H5真实板原始输出各7840B与完整图CPU跳连组合，板端CPU Add结果与电脑端预期逐字节一致；跳连仍为CPU捕获、文件交接。 |
| 第17块后续普通Conv | `TODO/P0` | 需提取真实输入、单层CPU金样、厂家后端/packet与硬件合同；本轮未开始START。 |

## 2026-09-27 H5后置1×1 Conv（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H5四段厂家packet及定点预期 | `VENDOR_CAPTURE_VERIFIED` | 当前板隔离软件捕获四段114/114/114/82字，packet/权重/bias/量化字段和分段输出已逐SHA核验；厂家Execute未调用。 |
| H5四段真实计算 | `TWO_FRAME_FOUR_SEGMENT_BOARD_PASS_LIMITED` | 两张真实帧分别以同模块同DMA缓冲连续4次START，8/8 IRQ1/work5、原始输出逐字节与各自板前预期相同、逐段释放冷态、两次最终卸载守卫PASS；拼接7840B SHA分别 `317b8874…af121`、`b8a5173a…34a63`，见H5板测报告。 |
| H5多帧与后继残差Add交接 | `DOING/P0` | 两帧单层板证已通过，但各自独立加载模块；下一步将H5板输出与跳连张量接到后继Add，确认全图量化交接。 |
| 生产驱动、失败恢复及全图 | `DOING/P0` | 旧H4跨作业work3超时未解释，失败仍固定DMA等待冷恢复；当前H5是诊断协议，不能作为完整空间图或视频实时服务。 |

## 2026-09-27 H4六片共用模块双帧（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H4六片同模块双帧 | `TWELVE_JOB_SINGLE_MODULE_BOARD_PASS_LIMITED` | 一次装载/一组DMA缓冲，2帧×6片12次START、输出逐字节零差、各次释放冷态、最终卸载守卫PASS；见六片共用模块报告。 |
| H4六片同模块重复稳定性 | `SIXTY_JOB_BOARD_PASS_LIMITED` | 又一次装载后5轮×12次均IRQ1/work5，60份输出逐SHA与预期相同、60次释放回冷态；旧偶发work3仍未解释。 |
| HardNPU生产接口与完整空间图 | `DOING/P0` | 现阶段依赖冻结六包、文件输入、板前预期CRC和软件拼接；下一步定义真实上游张量与下游消费接口，覆盖其它Hard算子、失败恢复及量化质量。 |
| 旧work3超时根因/事务排空 | `OPEN/P0` | 曾发生一次真实超时，当前故障仍固定DMA并要求物理冷恢复；本轮12次成功不能证明故障已消除。 |

## 2026-09-27 H4同模块双帧进展（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 第0片同模块两帧输入与生命周期 | `TWO_FRAME_SINGLE_MODULE_BOARD_PASS_LIMITED` | 相同packet/权重、同一模块和DMA缓冲下两张真实帧连续START、输出逐字节通过、两次释放冷态、最终卸载守卫PASS；见同模块双帧报告。 |
| 六片共用同模块/多帧 | `DOING/P0` | 目前仅第0片可在同一模块内更换输入；下一步逐片换真实packet/权重并核验六片同实例完成与输出拼接，再扩两帧。 |
| 真正超时后的事务排空与恢复 | `OPEN/P0` | 旧0→1 work3超时根因未知；当前故障路径仍固定DMA，只允许物理冷恢复。 |

## 2026-09-27 H4变化输入与真实第二帧（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H4确定性变化输入 | `SIX_SHARD_BOARD_PASS_LIMITED` | 7×7逐行循环平移诊断输入，六片真实START/输出/释放通过；完整输出等于原输出相同平移，见动态输入报告。 |
| 第二张真实测试帧H4层 | `SIX_SHARD_BOARD_PASS_LIMITED` | 原完整量化图捕获本层输入；六片板输出拼接47040B与运行前定点预期零差，SHA `02e7406bdb7e07b90df8c9b5c1c11acd9b145b94737f27b215d6098e9f7dd1ed`。完整图与单层ONNX CPU零差，独立浮点参考1字节差异单独记录。 |
| 多帧HardNPU生产接口 | `DOING/P0` | 目前每片重装一次特化模块，离线拼接。需同一可复用驱动内的六片、多帧、失败保持DMA及安全回收合同；此前真实work3超时根因仍未知。 |

## 2026-09-27 H4 六片真实板测与连续作业（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 六片厂家包及定点预期 | `VENDOR_CAPTURE_VERIFIED` | 六片真实904B packet、13项、权重/bias身份与定点预期已逐片核验；拼接预期等于旧完整层三包预期。见H4六片板测报告。 |
| 六片冷启动独立计算 | `BOARD_PASS_LIMITED` | 第0～5片各自冷启动后IRQ1/work5、7840B输出逐字节匹配、释放/卸载；拼接47040B与完整层冻结定点预期零差异。 |
| 六片连续计算 | `THREE_CONTINUOUS_CHAINS_BOARD_PASS_LIMITED` | 同一上电周期第5片后顺序0～5片，再两轮0～5片，共18次计算/释放均通过；12次重复的原始输出和日志取回核验。六片拼接SHA `c5c686a2403ff29abff8f1b5c6edd24bb969eb8998abfb791267dde48c4df3dd`。此前0→1同周期真实work3超时仍未解释，下一步诊断间歇性故障并验动态输入。 |
| HardNPU生产可复用路径 | `DOING/P0` | 需量化连续作业可靠性、异常排空/恢复、动态输入与通用缓冲生命周期；当前六片为一次性诊断模块和软件拼接，不能作为视频实时驱动。 |

## 2026-09-27 H4六片包核验静态准备（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 六片包逐片身份/定点核验 | `SYNTHETIC_END_TO_END_PASS/NO_REAL_PACKET` | 冻结六片清单接入同一核验器；六份临时合成包逐片通过，拼接定点结果与旧H4全层预测逐字节一致，错分片编号被拒绝。真实厂家包仍须逐片捕获并验比例/偏置，不能提交合成包。 |
| 六片硬件START | `USER_HOLD/OPEN` | 用户回来通知前不做；后续先第0片厂家软件包，真实START仍需运行前合同。 |

## 2026-09-27 H4完整层六分片候选（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 真实H4层6×160通道CPU金样 | `CPU_GOLDEN_PASS_LIMITED` | 六片各7840B均与原层对应区间逐字节一致，拼接47040B与原层完全相同；源模型与板载荷权重/bias身份锁定。见 `docs/research/HARDNPU_H4_SIX_SHARD_CPU_20260927.md`。 |
| 六片厂家分区、packet和定点输出 | `OPEN/P0` | 目前仅第0片有未来隔离捕获工具，六片均无真实厂家packet；先取第0片真实包并核验，再扩其余五片。 |
| 六片硬件计算与整层交接 | `USER_HOLD/OPEN` | 用户回来通知前不做START；即使第0片将来成功，也须逐片取得完成态、原始输出及释放证据，并拼接完整层再与独立定点预期比较。 |

## 2026-09-27 H4 160通道核验工具链（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 未来厂家包的本地完整核验 | `SYNTHETIC_END_TO_END_PASS/NO_REAL_PACKET` | 临时合成226字包经真实核验器产生7840B定点结果，与旧比例候选逐字节一致；CRLF解析故障已修复并复验。厂家成功标记和包均为合成，不能标作厂家捕获。下一步待静态限制解除后做隔离软件捕获并用同核验器验真实包。 |
| HardNPU START | `USER_HOLD` | 用户回来通知前不做；目前只本地静态工作。 |

## 2026-09-27 H4 写回几何静态门槛（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 派生160通道包的整层/单段几何 | `STATIC_CHECK_READY/NO_VENDOR_PACKET` | UG1215与旧H4三段包核对整层960、单段320和每段15680B各自含义；新核验器要求派生整层160×7×7及7840B，并以合成好/坏包自检。真实厂家包仍缺；待用户解除静态限制后先做隔离软件捕获，不直接START。 |
| 超时输出守卫解释 | `EVIDENCE_REVIEWED/ROOT_CAUSE_UNKNOWN` | 旧板端10秒快照`integrity=0`仅证明当时15680B之后A5守卫未检测到写入，不能证明设备排空或H4完成。 |

## 2026-09-27 H4 静态准备增量（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 160通道命令包捕获与量化字段门槛 | `SOURCE_READY/STATIC_REVIEW_LIMITED` | 捕获改为按旧厂家包首两字识别，不依赖CMA序号；核验输入/权重零点、真正filter_OC及手册tile周期关系。H2/H4旧包对照及合成解析正反自检通过，已修正前次误读的`0x3004`。源码仍未目标编译/传板/运行；下一步仅在用户回来后决定是否开展隔离的厂家软件捕获，之后再审真实硬件合同。 |
| HardNPU START | `USER_HOLD` | 用户回来通知前不做；当前仅本地静态改动。 |

## 2026-09-27 H4 160通道缩界（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| 真实层前160输出通道CPU夹具 | `CPU_GOLDEN_PASS_LIMITED` | 派生模型、7840B输入/输出、权重/bias封存；CPU输出与原完整层对应通道逐字节一致。见 `docs/research/HARDNPU_H4_REDUCED160_STATIC_DIAGNOSTIC_20260927.md`。 |
| 厂家后端/新packet与静态合同 | `OPEN/P0` | 仅准备隔离软件解析和LoadNetwork捕获；须验证Alnpu归属、packet、单包定点预期，再审物理缓冲/完成态。 |
| 160通道或其它H4 START | `USER_HOLD` | 用户要求回来通知前不做START；当前板已冷恢复，模块0。 |

## 2026-09-27 H4 第0包超时诊断（当前最新）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H4第0包真实START/完成态 | `STARTED_TIMEOUT_PARTIAL_OUTPUT/RECOVERED_BY_COLD_POWER` | 三次受控START均无完成IRQ；10秒后work3、IRQ0，已写11030B与定点金样逐字节一致但全包未完成；故障缓冲始终固定，三次均物理冷恢复。见 `docs/research/HARDNPU_H4_TILE0_TIMEOUT_BOARD_20260927.md`。 |
| H4故障边界缩小 | `DOING/P0` | 用厂家软件生成较小输出通道数的独立packet，封存对应定点金样和缓冲合同后再作单次板测；审实际Execute控制值、芯片/IP修订及MAC停滞原因。不可直接修改旧packet猜测。 |
| H4三包全层输出 | `OPEN/P0` | 第1/2包未执行，47040B全层无硬件输出；须先解决第0包完成态及错误后排空边界。 |

## 2026-09-27 H4 冻结载荷无启动板证（历史阶段）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H4 五份冻结载荷装填/释放 | `H4_PAYLOAD_STAGE_BOARD_PASS_LIMITED` | 当前板三段packet、输入和权重逐SHA传输，coherent缓冲装填/守卫PASS；受控改1字节得到`Bad message`且无模块残留，恢复后再次通过。无真实NPU事务。见 `docs/research/HARDNPU_H4_PAYLOAD_STAGE_BOARD_20260927.md`。 |
| H4 三段提交控制与异常生命周期 | `PARTIAL_TIMEOUT/P0` | 第0包已三次START且重复MAC态超时，故障固定/冷恢复遵守；实际控制值、根因和排空仍未定，见最新H4超时节。 |
| H4 真实三段输出 | `OPEN/P0` | 第0包只取得不完整诊断输出，第1/2包未执行；47040B完整结果仍需取得并与冻结packet定点预期逐字节比较。 |

## 2026-09-27 H4 四缓冲无启动板证（历史阶段）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H4 四缓冲真实分配/三段地址 | `H4_ALLOC_ONLY_BOARD_PASS_LIMITED` | 当前板分配 16384/8192/155648/49152B；三段32位子范围核对、卸载守卫PASS、模块0。无载荷和 START。见 `docs/research/HARDNPU_H4_ALLOC_ONLY_BOARD_20260927.md`。 |
| H4 固定载荷无启动装填 | `OPEN/P0` | 逐 SHA 装入 H4 input/weight/三段 packet，验证每段及尾部守卫，卸载释放；当前尚未执行。 |
| H4 真实三段计算 | `OPEN/P0` | 装填与完成态门槛后受控执行并取回47040B与冻结定点预期比较；错误/超时保持缓冲直到物理冷恢复。 |

## 2026-09-27 H4 三段提交地址静态审计（历史阶段）

| 任务 | 状态 | 证据及下一门槛 |
| --- | --- | --- |
| H4 同 SHA 厂家三段地址与顺序 | `STATIC_AUDIT_PASS_INFERRED_PLAN_LIMITED` | `Split`、`r_HardNPUDriver`、`Execute` 关键指令和冻结三 packet 核验；推导权重0/51200/102400 B、输出0/15680/31360 B，逐段提交/等待。实际 `Execute` 分支与真实 DMA 地址未知。见 `docs/research/HARDNPU_H4_VENDOR_SUBMIT_STATIC_AUDIT_20260927.md`。 |
| H4 物理四缓冲与三段装填 | `OPEN/P0` | 先建立默认无 START 的分配、内容、偏移范围、守卫和成功释放合同；各段权重/输出地址可不在4 KiB页界，须上板核验。 |
| H4 三段真实计算 | `OPEN/P0` | 无 H4 START/输出。待物理合同通过，再按冻结定点预期取回并逐字节验收，失败固定缓冲并提醒用户物理重启。 |

## 2026-09-27 H4 大通道普通Conv（历史阶段，当前硬件结果见首节）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H4 第16块1×1/160→960通道 PC夹具 | `CPU_GOLDEN_PASS_LIMITED` | 完整图、截取单层、独立NumPy逐字节一致；H4输出等于H3输入。 |
| H4厂家Hard分区及三段packet | `VENDOR_HARD_THREE_PACKET_CAPTURED_SIMULATED_DEVICES_LIMITED` | Alnpu归属、Load/Unload成功、三段各1544B packet及分段bias逐项核对，独立定点预测已封存；无Execute/真实设备。 |
| H4真实硬件作业 | `STARTED_TIMEOUT_PARTIAL_OUTPUT/P0` | 第0包真实START三次均停在work3且无IRQ，部分字节与预期相同；已冷恢复。第1/2包和完整层仍开放，见最新H4超时节。 |


## 2026-09-27 H3 depthwise 后端判定（历史阶段）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| 第16块3×3/group960 depthwise CPU夹具 | `CPU_GOLDEN_PASS_LIMITED` | 完整图、截取单层及独立NumPy逐字节一致；输入/输出各47040B，权重/bias有封存哈希。见 H3 报告。 |
| 厂家 Alnpu 后端判定 | `ALNPU_UNSUPPORTED_FOR_THIS_DEPTHWISE` | 隔离板端 parser 常量与夹具逐SHA相同；Optimize明示QAsymmU8 depthwise不受仅请求的Alnpu支持，无packet/硬件START。下一步查CPU/Soft归属，不强行提交Hard。 |
| HardNPU 下一扩面 | `RECOMMENDED/OPEN` | 改选真实图中可由 Alnpu 接受的普通Conv量化/几何，再建独立定点预期和缓冲合同；旧H2单层成功不等于完整HardNPU。 |


## 2026-09-27 H2 真实单层首算与后续验收（历史阶段）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H2 第二种普通 Conv 单次真实 START/输出/成功释放 | `H2_ONE_LAYER_BOARD_PASS_LIMITED` | 8笔写、IRQ1/work5、25088B 原始输出与独立 packet 定点预期逐字节一致；输出已取回并验 SHA，成功释放、卸载守卫 PASS、最终模块0。见 `docs/research/HARDNPU_H2_FIRST_START_BOARD_20260927.md`。下一步扩到 depthwise/层间张量，明确异常排空和共享DDR保护。 |
| H2 首次候选异常路径 | `PRESTART_REJECTED/RECOVERED_BY_PHYSICAL_RESET` | 一次 work3 导致0笔写、模块/缓冲固定；物理重启后新候选成功。冷态 NPU 寄存器只读探针另触发自动重启，已停用。原因未定，不能认作故障路径自动恢复已通过。 |
| 第16块 3×3/group960 depthwise 扩面候选 | `RECOMMENDED/STATIC_ONLY` | 历史UINT8图只读确认QDQ算子、`[1,960,7,7]`输入/输出、8640B权重、960个INT32 bias；先建立独立CPU夹具并验证厂家分区和packet，尚无板端运行，不自动标 `DOING`。 |
| 完整空间量化图及系统 | `DOING/DEPLOY_REJECTED` | 旧/新校准图数值质量仍不足；厂家真实 Execute、SoftNPU协同、视频流及持续帧率未验。 |

## 2026-09-27 H2 固定载荷无 START 装填（历史阶段）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H2 固定输入/权重装填与守卫 | `BOARD_PAYLOAD_STAGE_PASS_LIMITED` | 板端私有目录，源与载荷逐 SHA 一致；正向装卸0、内容/尾部守卫 PASS。1字节权重篡改触发 `-EBADMSG`、`insmod` 非0且无模块残留；原始正反记录已取回。见 H2 固定载荷报告。 |
| H2 DDR/MPU、真实 START、完成态和双预期输出 | `PREP_STATIC/START_OPEN/P0` | 已整理 H1 已板证状态门槛和 H2 单次候选步骤，见 `docs/research/HARDNPU_H2_FIRST_START_PREP_20260927.md`；仍需核设备 master 对四块物理地址的真实访问边界、受控8笔写与完成态、故障后冷恢复；取得输出后同时比对 ONNX CPU 与独立定点预测。 |

## 2026-09-27 H2 四缓冲无 START 板测（历史阶段，后续真实运行见首节）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H2 目标构建、coherent DMA 四缓冲与卸载 | `BOARD_ALLOC_PASS_LIMITED` | 私有 `/run` 目标构建，`insmod/rmmod` 返回0；16384/114688/8192/28672B 分配地址通过合同、packet和 A5 守卫卸载检查 PASS、最终模块0。原始板端记录与构建日志已哈希取回；见 H2 无 START 板测报告。 |
| H2 载荷装填、缓存/DDR访问、START与双预期输出 | `PAYLOAD_STAGE_PASS_LIMITED/START_OPEN/P0` | 固定输入/权重已装填并验成功/篡改拒绝释放；缓存/DDR设备访问、START和输出仍开放。完整量化图部署另行开放。 |

## 2026-09-27 H2 物理缓冲前置代码（历史阶段，独立合同分支仍固定拒绝）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H2 四缓冲地址/packet写序主机合同 | `CODED/HOST_TEST_PASS/ACTIVATION_FIXED_DENY` | 逻辑与分配尺寸、4KiB/32位/不重叠、冻结98字、8笔顺序及故障截点已测；内核分支固定返回拒绝且0笔写。见 H2 主机合同报告。 |
| H2 目标内核、真实DMA与无START板测 | `BOARD_ALLOC_PASS_LIMITED` | 已在新私有目录目标构建、分配/地址/守卫/装卸通过；缓存同步、真实 NPU 访问和异常生命周期未验。见上节。 |


## 2026-09-27 H2 厂家软件链与下一板测（历史阶段，真实运行见首节）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H2 厂家 parser/Optimize/LoadNetwork 与 Hard归属 | `TARGET_SOFTWARE_PASS_SIMULATED_DEVICES_LIMITED` | 当前板独立私有环境，唯一 `ALHardNPU` 层、`Alnpu` 后端，Load/Unload通过；真实设备与 Execute 未调用。 |
| H2 392B packet 与定点预测 | `CAPTURED/PC_VERIFIED` | 98字、13项独立核对；权重/bias与源图相同，packet SHA `e79c1f8adb3712dcd26fbadee21d6586fc7bbef552e000d13c5421f1a1544b40`。预测输出与CPU ONNX金样12458B各低1，硬件结果待验。 |
| H2 真实物理缓冲、START、输出和释放 | `PARTIAL_ALLOC_PASS/START_OPEN/P0` | 四块 coherent 缓冲分配和成功卸载已过；载荷装填、故障隔离、真实 START/输出仍开放，不可复用H1固定尺寸。获真实输出后双预期核对，失败不自动复用缓冲。 |


## 2026-09-27 HardNPU H2 扩面（历史阶段，真实运行见首节）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H2 第二种普通 1×1 Conv 真实图来源夹具 | `CPU_GOLDEN_PASS_LIMITED` | H2 `[1,144,28,28]`→`[1,32,28,28]`，完整图/单层/独立 NumPy 0 字节差；最终源模型、输入、输出 SHA 和逐项验证见 H2 报告。先前误标测试帧的草稿不可传输。 |
| H2 厂家后端与硬件 | `SOFTWARE_PACKET_PASS/BOARD_ALLOC_PASS_LIMITED/START_OPEN` | 隔离虚拟设备下完成 parser、Optimize、LoadNetwork 和 packet 核验；真实 H2 缓冲分配/卸载已过，载荷与 START 仍开放。H1 固定尺寸驱动不可直接复用。 |
| 完整空间图和产品语义 | `OPEN/P0` | 旧量化图的单层 CPU 金样不使完整图可部署；仍须量化质量、完整图后端归属、SoftNPU 联合及视频整链。 |


## 2026-09-27 量化图非校准片段评估

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| v2历史测试split 12段/192抽样帧 | `PC_DIAGNOSTIC_DONE/REJECTED_FOR_DEPLOYMENT` | 与48张校准图文件哈希交集0；新Pillow QDQ特征平均cosine0.645798（旧0.626333），但Top-1仍0.75、Macro-F1约0.739（旧约0.750），两次回放逐字一致。真实表演者不明、弱标签，仍缺独立产品验收。 |
| 满足产品语义的空间量化/Hard后端 | `OPEN/P0` | 先修正全图PTQ或受约束QAT，使独立完整动作特征与词级结果达到预设门槛；再验厂家parser/逐层后端、不同Hard层和板端输出。当前两图均不可部署。 |

## 2026-09-27 预处理一致性与新量化基线

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| 旧PTQ与产品输入合同核对 | `PC_DIAGNOSTIC_DONE` | OpenCV/Pillow同48图输入135万元素不同，FP32特征平均cosine0.817；H1另为letterbox诊断路径。新Pillow校准QDQ平均cosine0.652，仍拒绝部署。详见预处理量化报告。 |
| 统一Pillow全图金样及量化 | `OPEN/P0` | 以冻结`sign-rgb-preprocess-1`对独立完整动作生成空间中间张量/特征，再定位量化误差、词级识别与拒识；不能继承旧OpenCV或H1 letterbox的字节金样。 |

## 2026-09-27 第16块depthwise定向数值排查

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| 残差双支及饱和率定位 | `PC_DIAGNOSTIC_DONE` | 第16块相加前旁路/卷积分支平均cosine 0.738/0.509；后段量化rail最高约0.107%，末端大量零值本来存在于FP32。机器报告与量化边界报告已归档。 |
| 第16块单层敏感性 | `PC_DIAGNOSTIC_DONE/REJECTED_FOR_DEPLOYMENT` | 单独保留该块3×3 group960 depthwise浮点，最终平均cosine 0.632070→0.678313；另两层1×1各仅到约0.635。DW权重反量化对FP32整体cosine约0.999993，但该层输入已只有0.895594；基线/候选408共同initializer相同。下一步沿前序和后续残差误差传播检查，不能直接判权重根因或宣称HardNPU完成。 |
| 独立完整动作数值/词级验收 | `OPEN/P0` | 现48张图兼作校准与诊断；需独立动作和受试者的128维特征、时序分类/拒识，随后厂家parser/后端归属和真实硬件输出。 |

## 2026-09-26 空间量化边界诊断结果

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| NPU-001 48帧逐边界定位 | `PC_DIAGNOSTIC_DONE` | 46个共同 Add/Clip 边界逐帧比较，残差链误差累积；块18单独留浮点几无提升，块15+16四个新增Conv留浮点使输出平均cosine 0.632070→0.678150，仍拒绝部署。见量化边界报告。 |
| NPU-001 数值修复与独立验收 | `OPEN/P0` | 先定量核查残差双支激活范围、scale/截断和后段误差，形成可解释量化修正或受约束QAT；随后以独立完整动作/受试者验证特征、词级准确率与拒识，并检查厂家parser/后端/板端输出。48张校准图不能代替该验收。 |

## 2026-09-26 空间模型量化与HardNPU扩面

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| NPU-001 完整空间量化数值 | `OPEN/P0` | Astra/Sol既有V6/V7解析候选有限通过，但bias INT32越界与代表性48帧低余弦仍拒绝部署。先修复隔离量化图并以独立验证集检验中间特征及词级语义，不重复parser已解对照。 |
| H1后续不同Hard层 | `PENDING_VALID_MODEL` | 当前H1为真实校准图派生单层；完整图有35普通Conv/17 depthwise。待量化质量及全图后端归属可信后选不同几何/量化的新层，上板验证通用驱动与算子覆盖。 |

## 2026-09-26 HardNPU 扩面下一验收

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1 冻结单层成功路径 | `BOARD_PASS_LIMITED/STOP_SAME_FIXTURE_REPEAT` | 原图像中间张量、两份扰动、十次成功重用和两帧动态诊断已足够支撑当前packet/权重的成功路径；除源码变更风险外不再重复同样H1样本。 |
| HardNPU 真实空间模型覆盖 | `OPEN/P0` | 完整空间图历史审计35普通Conv/17 depthwise，当前仅最小普通Conv一层获板证。下一步取得当前量化全图逐层parser/Optimize归属与数值，选择不同几何/量化的下一层；随后验证真实运行时和系统内张量所有权。 |

## 2026-09-26 H1 板端动态串联

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 逐帧CPU预期→硬件→释放 | `BOARD_PASS_TWO_FRAMES_DIAGNOSTIC` | XOR55/XORAA逐帧现场算预期、绑定、真实START、输出0差、释放；61.8/62.1ms短样本，最终模块0。下一步为去除生产路径的全量CPU复算、模型准确率与真实流整合。 |
| 完整系统 | `DOING` | Hard单层成功路径扩展已板证，SoftNPU、相机视频、模型整链、共享DDR保护及异常恢复尚未完成。 |

## 2026-09-26 H1 短时重复性

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 同实例十次交替输入运行 | `BOARD_PASS_10_SUCCESS_JOBS_LIMITED` | 两份输入交替，十次输出0差、十次成功释放、最终卸载/模块0；电脑端归档10/10独立核验。板端作业段369ms，不含CPU预期/视频。见十次作业报告。 |
| H1-04 长时和失败恢复 | `OPEN` | 尚未运行长时连续流、其它权重/算子或异常AXI/超时恢复；当前故障仍固定DMA，不能据十次成功推断故障可回收。 |

## 2026-09-26 H1 板端预期当前验收

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 冻结packet板端CPU预期生成 | `TARGET_BUILD/BOARD_CPU_PASS_TWO_INPUTS` | XOR55/XORAA预期与主机预期各12544/12544相同，样本计算约15.30/15.49ms；需测整链延迟与持续工作。 |
| H1-04 板端CPU预期→硬件绑定 | `BOARD_PASS_LIMITED_ONE_INPUT` | 最终模块对XOR55完成绑定、START、输出一致、成功释放及卸载；未证明模型准确率或视频流。见通用输入报告。 |

## 2026-09-26 H1 自定义输入当前验收

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 固定packet/权重任意输入的预期绑定 | `BOARD_PASS_LIMITED_TWO_NEW_INPUTS` | XOR55与XORAA输入输出各12544/12544匹配事先生成的定点预期；同实例两次成功释放。最终收紧源码又一次XORAA正向板测通过。见通用输入报告。 |
| H1-04 未预期输入与权重的提交门槛 | `CODED/TARGET_BUILD/POSITIVE_BOARD_PASS` | 最终源码在RUN_ONCE前拒绝非冻结权重和未预先绑定的未知输入；故意漏绑定的武装拒绝分支未实际板测，不能称负例已验。默认关闭负例已板测。 |
| H1-04 可持续实时推理 | `OPEN` | 自定义输入两次成功重用已证；尚无多帧压力、耗时/帧率、错误路径排空、DDR地址隔离或真实模型链执行。 |

## 2026-09-26 H1 模型链当前进展

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-03 冻结模型→厂家packet→板端结果桥接 | `ONE_LAYER_PACKET_FIXED_BOARD_EXACT_LIMITED` | 复用已完成的模型/LoadNetwork证据，新增原始packet与Linux输出桥接文件；下一步为真实运行时接入独立驱动或受控厂家Execute、模型语义/准确率验收。见模型到板端桥接报告。 |

## 2026-09-26 H1 Linux 当前验收

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 冻结1×1 Conv 同实例重复运行 | `BOARD_PASS_LIMITED` | 原输入连续两次、变体→原输入连续两次均各自输出与预先生成的packet定点预期12544/12544一致；成功释放、卸载通过。见两份Linux repeat/mixed报告。 |
| H1-04 成功释放和异常生命周期 | `SUCCESS_PATH_BOARD_PASS / FAULT_PATH_OPEN` | 成功作业仅两组CRC允许释放；错误/超时仍固定缓冲。待建立异常AXI排空或可靠冷恢复边界，不得标为通用重用。 |
| H1-04 共享Linux DDR隔离及内核来源 | `OPEN` | 现有板测使用默认关闭的DDRS1-disabled受控诊断模式；没有地址隔离。历史源码树可编译/加载，但当前Image精确同源、`Module.symvers`仍未知。 |
| H1-05 模型量化语义及其它算子 | `OPEN` | 原CPU/ONNX金样仍6267字节各差1；变体无模型金样，其他权重/shape/算子未测。下一验收为模型级容差及受控扩展。 |
| HardNPU 完整系统 | `DOING` | 先解决共享DDR、故障回收、模型链与量化合同；再接SoftNPU，最后视频。下方“未执行Linux START”条目为历史快照。 |

## 2026-09-26 H1 Linux 双层输出判据

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 packet 定点与 CPU 模型双层验收程序 | `TARGET_USERSPACE_BUILD/OFFLINE_BOARD_PASS` | `--compare-fixed` 对首算真实输出定点差异0、CPU差异6267，坏1字节拒绝；`--execute-fixed` 尚未运行，见 `docs/research/HARDNPU_H1_LINUX_DUAL_ORACLE_VERIFIER_20260926.md`。 |
| H1-04 Linux RUN_ONCE 与重复推理 | `FIXED_DENY/OPEN` | DDRS1 live gate仍拒绝；共享DDR安全边界、故障排空、复位/IRQ合同及可重复缓冲生命周期未完成。任何新 START 需新许可。 |

## 2026-09-26 H1 Linux 激活门槛对齐

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 TOP/复位后空闲门槛 | `TARGET_COMPILED_DISASSEMBLED/NOT_LOADED` | 驱动改为保留TOP原位按位或3、拒绝旧IRQ、连续16次idle；目标反汇编确认。见 `docs/research/HARDNPU_H1_LINUX_ACTIVATION_ALIGNMENT_20260926.md`。 |
| H1-04 内核产物兼容性 | `COMPILE_PASS/LOADABILITY_UNKNOWN` | 历史私有输出树vermagic匹配，但Module.symvers缺失、modpost未解析符号及时钟偏差；未装载。 |
| H1-04 Linux RUN_ONCE | `FIXED_DENY/NO_NEW_START` | DDRS1 live policy继续返回`-EOPNOTSUPP`，默认参数关闭；共享DMA、CRP所有权、成功重用与异常排空未闭合。 |

## 2026-09-26 H1 定点预期与Linux路径

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-05 独立packet定点预期 | `PC_ORACLE_MATCH_BOARD_12544` | 冻结input/weight/bias与packet独立生成预期，之后与首次板测原始输出比较0差；见 `docs/research/HARDNPU_H1_PACKET_FIXED_ORACLE_20260926.md`。 |
| H1-05 CPU/ONNX量化语义 | `STRICT_GOLDEN_FAIL_MAX1/OPEN` | 6267点差1；需模型级量化容差/准确率合同，不能把设备层吻合当成模型通过。 |
| H1-04 Linux成功/故障生命周期 | `OPEN/P0` | 当前驱动DDR S1 live policy固定拒绝，TOP_ENABLE激活实现与成功U-Boot路径不同。先修复源码差异、约束DMA及失败缓冲隔离，再目标构建；本轮无新START。 |

## 2026-09-26 H1 首次单次 START 结果（取代下方待授权历史状态）

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 冻结 packet 首次执行 | `BOARD_EXECUTED/IRQ1_WORK5` | 用户授权的一次START已返回；报告status34，输入/权重/packet/守卫通过。没有第二次START。 |
| H1-05 原始输出 | `FIXED_PACKET_EXACT_12544 / CPU_GOLDEN_FAIL_MAX1` | 原始输出与 packet 定点公式全长0差；相对原CPU金样6267点低1、6277点相同。需先完成量化语义/容差合同，不自动改bias或重跑硬件。 |
| H1-04 故障后恢复 | `PHYSICAL_RESET_CONFIRMED/LINUX_READY` | 失败后未由U-Boot启动Linux或复用DDR；用户现场断电上电，COM4复核Linux 6.1.111-rt42、模块0、U盘未挂载。异常事务排空机制本身仍未知。 |
| HardNPU 完整系统 | `DOING` | 单层一次作业证据不覆盖重复执行、Linux驱动、异常AXI排空、多算子/模型精度、SoftNPU协同或视频。详见 `docs/research/HARDNPU_H1_FIRST_START_BOARD_20260926.md`。 |

## 2026-09-26 H1 首算证据抓取准备

| 任务 | 状态 | 证据与下一步 |
| --- | --- | --- |
| H1-04 武装产物反汇编复核 | `STATIC_AUDIT_PASS/NOT_RUN` | 八笔白名单及最终START前IRQ/work零门槛与ELF一致；见 `docs/research/HARDNPU_H1_ARMED_STATIC_AND_OUTPUT_CAPTURE_20260926.md`。 |
| H1-04 完成/排空手册复核 | `MANUAL_AUDIT_DONE/AXI_DRAIN_UNKNOWN` | UG1215明确work5/IRQ bit0完成，但未规定软复位、CRP复位或XMON计数可证明异常后在途事务排空。首算沿单次U-Boot与冷恢复路径；Linux驱动恢复契约仍OPEN。见 `docs/research/HARDNPU_H1_AXIDRAIN_EVIDENCE_AUDIT_20260926.md`。 |
| H1-04 输出抓取全长模拟 | `PC_PARSE_PASS/BOARD_OUTPUT_NOT_RUN` | 用冻结金样模拟784行，脚本同逻辑还原12544字节并匹配SHA；地址断裂及截断被拒。仍待单次真实作业后的串口抓取。见 `docs/research/HARDNPU_H1_ARMED_STATIC_AND_OUTPUT_CAPTURE_20260926.md`。 |
| H1-04 当前板卡只读就绪核验 | `LINUX_IDLE/START_PENDING_USER` | COM4响应、Linux 6.1.111-rt42、内核模块0，U盘`/dev/sda1`可见未挂载。没有切换U-Boot或执行START。 |
| H1-04 完整输出原始证据 | `TOOL_READY/NO_HARDWARE_OUTPUT` | 12544B金样哈希已核；仅在IRQ1/work5的完成态从U-Boot只读抓取并逐字节比对，尚未实际运行。 |

## 2026-09-26 H1 四页整合预检

| 任务 | 状态 | 证据与下一步 |
| --- | --- | --- |
| H1-04 四页EL3映射往返 | `U-BOOT_BOARD_PASS_NO_START_LIMITED` | 页0/1/2/6读写翻译正确、撤销后原L2表项0；见 `docs/research/HARDNPU_H1_FOUR_PAGE_MAPPED_PREFLIGHT_20260926.md`。 |
| H1-04 冻结四缓冲＋映射＋复位整合预检 | `U-BOOT_BOARD_PASS_NO_START_LIMITED` | 状态8、CRC/130字packet/八笔记录/23页缓存准备/连续空闲通过，TOP及页表恢复；没有packet寄存器写或START。 |
| H1-04 一次首算候选 | `TARGET_BUILT/START_NOT_AUTHORIZED` | 6248B武装BIN SHA-256=`18e05b355d5b5534cc141d5db0f65d96730dacb01de2a9b0fbc32da44b08d769`仅隔离保存；首次START前需当时明确许可，之后必须单次运行、保持故障状态并物理恢复。 |

## 2026-09-26 H1 U-Boot 无启动控制面

| 任务 | 状态 | 证据与下一步 |
| --- | --- | --- |
| H1-04 NPU MMIO只读与软复位 | `U-BOOT_BOARD_PASS_NO_START_LIMITED` | 两页映射下工作/IRQ读0，一次软复位自清，TOP与页表恢复；见 `docs/research/HARDNPU_H1_UBOOT_MMIO_READ_RESET_BOARD_20260926.md`。 |
| H1-04 首算提交程序整合 | `OPEN/P0` | 八笔计划还访问偏移0x2000/0x6000，需将页0/1/2/6精确映射并逐页核验；整合冻结四缓冲、START前状态、失败分支和冷恢复；首次真实START需当时明确许可。 |

## 2026-09-26 H1 U-Boot NPU MMIO 页表缺口

| 任务 | 状态 | 证据与下一步 |
| --- | --- | --- |
| H1-04 首算激活专用验证 | `BOARD_ABORT_BEFORE_START/RECOVERED` | 首次 NPU 软复位写入触发同步异常并自动复位；未写 packet 或 START。见 `docs/research/HARDNPU_H1_UBOOT_NPU_MMIO_TRANSLATION_20260926.md`。 |
| H1-04 EL3 NPU 地址翻译与临时映射 | `BOARD_PASS_MAP_ROUNDTRIP_LIMITED` | NPU 原L2表项0；只映射两页时读写PAR=`0x63f00900/0x63f01900`，撤销后PAR=`0x80d`、原表项0；下一步映射期间的无START寄存器/复位响应。 |
| H1-04 真正首算 | `NO-GO/P0` | 仍无 NPU START、IRQ、设备 DMA 或输出证据；武装 BIN 未放入 U 盘、未运行；首次 START 前需当时明确许可。 |

## 2026-09-26 H1 U-Boot 缓存与翻译预备

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-04 EL3四缓冲逐页映射与缓存准备 | `U-BOOT_BOARD_PASS_NO_START_LIMITED` | 23页R/W地址翻译匹配、64B行、清/失效指令执行，冻结CRC/packet/计划仍通过；见 `docs/research/HARDNPU_H1_UBOOT_CACHE_NOSTART_BOARD_20260926.md`。 |
| H1-04 可回收首算路径 | `OPEN/P0` | 需设计并目标核验U-Boot阶段的受控硬件激活、单次START、结果/IRQ或状态轮询、输出缓存与异常后AXI停机；首次真实START仍需用户当时明确许可。 |
| H1-05 共享Linux DDRS1补集策略 | `REJECTED_AS_LIVE_SHARED_DDR_POLICY` | 已证实影响PL330；不能把本轮U-Boot缓存通过当作NPU隔离。 |

## 2026-09-26 DDRS1 源页读取与补集候选

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-05 RW0/group0x20 源页 PL330 对照 | `BOARD_FAULT/RECOVERED` | 目的页不受保护、源页命中规则仍故障；DDRS1回滚、软件重启后PL330/DDR S1/模块基线通过。见 `docs/research/HARDNPU_H1_DDRS1_RW0_SOURCE_READ_AND_POLICY_REJECTION_20260926.md`。 |
| H1-05 四缓冲外 RW3/group0x8 补集候选 | `REJECTED_AS_LIVE_SHARED_DDR_POLICY` | 同配置曾拦 PL330，不能称NPU专属；纯几何/形状代码保留供诊断，RUN_ONCE继续拒绝。需新的可验证策略或独占启动方案。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | 保护、NPU路由、故障后排空仍未闭合；首次真实START仍需用户当时明确许可。 |

## 2026-09-26 DDRS1 RW=0 组选择性

| 任务 | 当前状态 | 证据与下一验收 |
| --- | --- | --- |
| H1-05 PL330 GroupID 单变量对照 | `BOARD_PASS_LIMITED/SELECTIVITY_SUPPORTED` | 相同RW0目的页规则下0/0x8通过、0x20/全1故障；本轮0x8模块已卸载、DDRS1基线恢复。见 `docs/research/HARDNPU_H1_DDRS1_GROUP_SELECTIVITY_RW0_BOARD_20260926.md`。 |
| H1-05 确认 DDRS1 实例级掩码极性、NPU 主AXI和异常排空 | `UNKNOWN/P0` | 用本次可区分的正反例审查当前硅片资料与路由，建立可安全保护共享DDR的方案；不得仅凭PL330结果推断NPU。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | RUN_ONCE固定拒绝，首次真实START仍需用户当时明确许可。 |

## 2026-09-26 DDRS1 区域命中控制

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 全局开、全部区域禁用 | `BOARD_PASS_LIMITED` | PL330自有64字节复制成功；DDR S1区域与全局CTRL恢复。见 `docs/research/HARDNPU_H1_DDRS1_REGION_HIT_MATRIX_BOARD_20260926.md`。 |
| H1-05 区7启用但目的不命中 | `BOARD_PASS_LIMITED` | 区7只覆盖独立guard页；复制成功、guard整页保持哨兵，回滚/卸载通过。 |
| H1-05 全组位/RW开放的安全与特权四组合 | `BOARD_FAULT_ALL_FOUR/RECOVERED` | 命中目的页时 `SECURE/PRIVILEGE=00/10/01/11` 均同型写错误；本轮后两次回滚并软件重启，最终 DDRS1/PL330基线通过。下一验收转向实例级 GROUPID 规则、实际 AWPROT 与区域内部错误理由，停止重复安全/特权组合。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | PL330限定证据不证明 HardNPU 主设备安全；RUN_ONCE固定拒绝，真实START仍需用户当时明确许可。 |

## 2026-09-26 XMON PL330 GroupID 限定板证

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 当前 PL330 写路径 GroupID | `BOARD_PASS_LIMITED/GROUP5_SUPPORTED` | DDR_S1/DMACX 两 XMON 在宽域和单值5计数各64、空闲0，两次64字节复制通过；见 `docs/research/HARDNPU_H1_XMON_PL330_GROUP5_BOARD_20260926.md`。下一验收需确认 MPU 组字段比较与安全/权限极性。 |
| H1-05 全组位开放仍拒绝的原因 | `UNKNOWN/P0` | 已知 PL330 写路径 GroupID=5，不能单由此解释 `GROUPID=0xffffffff/RW=0` 的 Region7 写故障；需厂家实例级真值表/可辨故障理由。 |
| H1-04 HardNPU 主设备 GroupID 与首算 | `UNKNOWN/NO-GO` | 尚无 NPU 主设备事务；RUN_ONCE 继续固定拒绝，首次真实 START 仍需用户当时明确许可。 |

## 2026-09-26 DDRS1 SECURE 位单变量与 XMON

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 区7 SECURE=1、GROUP全1、RW=0对照 | `BOARD_FAULT/RECOVERED_BY_REBOOT` | 与SECURE=0同样 AXI 写错误；DDRS1回滚、故障缓冲固定，软件重启后模块/故障归零。见 `docs/research/HARDNPU_H1_DDRS1_SECURE1_XMON_BOARD_20260926.md`。 |
| H1-05 DDR_S1/DMACX XMON 错误路径 | `BOARD_READ_LIMITED` | DDR_S1 捕获目的页起点写错误，DMACX 捕获同页附近写错误；AXI ID `0x1d0/0x7`不等于已知 GROUPID，不能单独区分 MPU 或后端错误。 |
| H1-05 实例级安全/权限/组真值表 | `UNKNOWN/P0` | 安路 AI 无答案；需客户支持原始资料或可辨 fault reason/AxPROT/GroupID 的受控证据。停止重复单变量故障试验。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | RUN_ONCE 固定拒绝；首次真实 START 需用户当时明确许可。 |

## 2026-09-26 DDRS1 全组允许设定的失败对照

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 全组位1、RW=0、目的页 PL330 对照 | `BOARD_FAULT/RECOVERED_BY_REBOOT` | 目标构建、默认门槛通过；显式一次仍产生 AXI 写错误，4096字节目的页未变；DDRS1恢复、软件重启后模块/故障清零。见 `docs/research/HARDNPU_H1_DDRS1_ALL_GROUP_RW_OPEN_BOARD_20260926.md`。 |
| H1-05 安全/特权属性和实际 AxPROT | `UNKNOWN/P0` | 先核 DDRS1 SECURE/PRIVILEGE 位的实例语义及 PL330 非安全事务 sideband，再设计可判别的正对照；不盲试其它 GROUPID 掩码。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | RUN_ONCE 固定拒绝，首次真实 START 仍需用户当时明确许可。 |

## 2026-09-26 DDRS1 GROUPID 手册重释

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 GROUPID 位图机制 | `MANUAL_CONFIRMED/BOARD_GROUP_UNKNOWN` | UG1214 v1.3明确 ID 位授权；旧四组试验同时以 RW=3 拒绝所有读写，不能判定组位。见 `docs/research/HARDNPU_H1_DDRS1_GROUPID_MANUAL_RECONCILIATION_20260926.md`。 |
| H1-05 全组允许、RW开放的目的页正对照 | `BOARD_FAULT/RECOVERED_BY_REBOOT` | 已目标构建并单次实传，仍因 AXI 写错误失败；具体证据及恢复见上方最新记录。此项不包含 NPU START。 |
| H1-05 具体主设备组位及 NPU→DDR 路由 | `UNKNOWN/P0` | 正对照通过后还需固定 RW开放，只改变组位作可区分试验；核查共享路由、区优先级及故障后排空。`MPU_NPU` 是访问 NPU 的入口保护，不代替 DDRS1。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | RUN_ONCE 固定 `EOPNOTSUPP`；IRQ bit2、NPU路由、共享 DDR 保护与异常排空未闭合。首次真实 START 需用户当时明确许可。 |

## 2026-09-26 H1 迟到中断诊断

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-04 超时后首次迟到 IRQ 原始值 | `CODED/HOST_PASS/TARGET_BUILD/BOARD_DEFAULT_NO_START_PASS` | 超时后仅记录首个非零 IRQ/工作状态，仍拒绝完成和释放；主机/板端状态测试、新模块默认加载卸载通过。见 `docs/research/HARDNPU_H1_LATE_IRQ_DIAGNOSTIC_20260926.md`。 |
| H1-04 真实迟到 IRQ、IP bit2、AXI 排空 | `UNKNOWN/NO-GO` | 此轮未运行真实 IRQ/START；须匹配当前硬件修订的中断与停止合同。 |

## 2026-09-26 DDRS1 GROUPID 零值对照

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 PL330 目的页 GROUPID=0 | `BOARD_COUNTEREXAMPLE/FAULT_RECOVERED_BY_REBOOT` | 单次目标构建、默认门槛、显式实验：FSRC bit7/FTR7 bit17、目的整页不变；DDRS1恢复，软件重启后模块和故障清零。见 `docs/research/HARDNPU_H1_DDRS1_GROUP0_COUNTEREXAMPLE_20260926.md`。 |
| H1-05 DDRS1 GROUPID 比较语义 | `UNKNOWN/P0` | 0、0x1、0x8、0x20在相同拒绝形状下均拦截 PL330；不再重复替换组值，需当前芯片直接比较/主设备路由证据。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | 组隔离、NPU主AXI、IRQ bit2、异常排空仍未闭合；首次真实 START 前需用户当时明确许可。 |

## 2026-09-26 U-Boot x18 与 DDRS1 group0x8 对照

| 任务 | 当前状态 | 证据与下一验收 |
|---|---|---|
| H1-05 U-Boot 临时 C 调用约定 | `ROOT_CAUSE_SUPPORTED/NO_WRITE_PREFLIGHT_PASS` | BOOT.bin 的 U-Boot 路径读取 x18；旧程序改写 w18且异常现场 x18=0x20。`-ffixed-x18` 后静态无 x18/w18、无写入预检 `go` 返回0；见 `docs/research/HARDNPU_H1_UBOOT_X18_AND_GROUP8_HANG_20260926.md`。 |
| H1-05 U-Boot DDRS1 group0x8 显式对照 | `HANG_RECOVERED_BY_USER_POWER_CYCLE/QUARANTINED` | 写入变体在 `go` 后静默，未获阶段报告；复位后 DDRS1/PL330 基线正常。变体构建已封禁；须先有可读的停机阶段和恢复设计，再决定是否有必要做新实验，不重复原程序。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | 组选择、NPU主AXI路径、IRQ bit2、异常排空仍未闭合；首次真实 START 前仍须用户当时明确许可。 |

## 2026-09-26 U-Boot EL3 PL330 缓存见证

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 U-Boot 缓存维护与 PL330 实传 | `U-BOOT_EL3_PL330_64B_CACHE_WITNESS_PASS_LIMITED` | EL3物理页翻译匹配、行64B，`dc cvac/civac/ivac`后通道7完成64B复制，完整页哨兵/微码尾通过、无故障；回 Linux。见 `docs/research/HARDNPU_H1_UBOOT_PL330_CACHE_WITNESS_20260926.md`。 |
| H1-04 HardNPU 数据可见性与首算 | `OPEN/P0` | PL330特定路径通过不证明 NPU 主 AXI 或全部缓冲访问；组隔离、IRQ bit2、复位/异常排空仍待证。首次 NPU START 须当时明确许可。 |
| H1-05 U-Boot 无提交非零返回异常 | `RECOVERED/CAUSE_UNKNOWN` | 一次 rc7 后 U-Boot 同步异常/自动重启；结果页状态+rc0 预检通过，不能认定根因已查清。 |

## 2026-09-26 H1 U-Boot 四缓冲无启动验收

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-04 固定缓冲数据与八笔计划 | `BOARD_CPU_NOSTART_PASS_LIMITED` | U-Boot 执行返回0，输入/权重 CRC、packet130字、三尾部/输出哨兵、八笔计划一致；回 Linux、模块0。回调没有 MMIO 写。见 `docs/research/HARDNPU_H1_UBOOT_NOSTART_STAGE_20260926.md`。 |
| H1-04 缓存、地址保护和实际设备计算 | `OPEN/P0` | EL3 缓存开启，CPU验收不等于 NPU 所见内存；需缓存维护、实际主 AXI 路由、DDRS1 组选择、IRQ bit2、复位及故障排空证据。首次 START 仍须当时明确许可。 |

## 2026-09-26 H1 U-Boot 执行预检

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 U-Boot 临时代码、阶段组号和缓存状态 | `BOARD_READONLY_PREFLIGHT_PASS` | FAT 加载168字节、`go`返回0，EL3、组号3/5、DDRS1=`0x800`、SCTLR_EL3=`0x00c5383d`；正常回 Linux、模块0。见 `docs/research/HARDNPU_H1_UBOOT_EL3_PREFLIGHT_20260926.md`。 |
| H1-04 U-Boot 隔离运行器无启动准备 | `OPEN/P0` | 须审计缓存/DMA一致性、缓冲布局、DDR保护、超时与异常保留，再完成无 START 静态/板端预检；首次真实 START 前仍须用户当时明确许可。 |
| H1-04 Linux 精确内核源码身份 | `UNKNOWN/P0` | 官网 SDK `linux` 子模块可取得；已有 2025.07 完整候选与当前 Image AMBA 布局不符，较新官网标签不得直接视为当前镜像源码。 |

## 2026-09-26 H1 组路由门槛

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 DDRS1 候选形状误放行保护 | `CODED/TARGET_BUILD/BOARD_DEFAULT_NO_START_PASS` | RUN_ONCE 专用核验在形状匹配后固定 `EOPNOTSUPP`，只读诊断保留；未以匹配策略触发该分支。见 `docs/research/HARDNPU_H1_DDRS1_GROUP_ROUTE_FAIL_CLOSED_20260926.md`。 |
| H1-05 恢复可执行组路由核验 | `OPEN/P0` | 必须先证明当前硅片组比较、Linux实时主设备路由、共享DDR影响与故障排空，再以有证据的检查替换固定拒绝。 |

## 2026-09-26 DDRS1 第三组对照

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 PL330 目的页 group0x1 对照 | `BOARD_COUNTEREXAMPLE/FAULT_RECOVERED_BY_REBOOT` | CSU候选0x1与0x8、0x20一样拒绝PL330目的页写入；DDRS1恢复且软件重启回收，见 `docs/research/HARDNPU_H1_DDRS1_GROUP1_COUNTEREXAMPLE_20260926.md`。 |
| H1-05 地址匹配与组选择拆分 | `ADDRESS_DENY_BOARD_PASS_LIMITED/GROUP_UNKNOWN` | 闲置页0x20允许；目的页0x20/0x8/0x1均拒绝。先查比较语义/运行路由和共同配置因素，再考虑新板测。 |

## 2026-09-26 DDRS1 组选择反例

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 PL330 目的页 group0x8 负对照 | `BOARD_COUNTEREXAMPLE/FAULT_RECOVERED_BY_REBOOT` | 与 group0x20 一样出现通道7 AXI 写错误，目的整页不变；DDRS1 恢复、软件重启后模块0及故障0。见 `docs/research/HARDNPU_H1_DDRS1_GROUP8_COUNTEREXAMPLE_20260926.md`。 |
| H1-05 DDRS1 GROUPID 比较与当前主设备路由 | `UNKNOWN/P0` | U-Boot 只读 NPU/DMA_AXI 组号3/5与手册默认一致，但静态编号和 SDK 掩码无法解释 group0x8 仍拦截 PL330；须取得组选择语义和 Linux 运行时路由的独立证据，重新评估 H1 策略。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | 组隔离、IRQ bit2、复位/资源和故障排空仍未闭合；首次实际 START 前须用户明确授权。 |

## 2026-09-26 DDRS1 DMA_AXI 保护效果

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 DMA_AXI group0x20 未命中允许路径 | `BOARD_PASS_LIMITED` | DDRS1 `0x801`时规则在自有闲置页、64B复制通过，八区恢复并卸载。见 `docs/research/HARDNPU_H1_DDRS1_DMA_AXI_ALLOW_DENY_BOARD_20260926.md`。 |
| H1-05 DMA_AXI 配置group0x20命中目的页拒绝 | `BOARD_PASS_LIMITED/FAULT_RECOVERED_BY_REBOOT` | 目的整页不变、FSRC bit7、FTR7 bit17 AXI写错误；DDRS1恢复，缓冲固定后正常软件重启回收，模块数0。组选择性未证。 |
| H1-05 group0x8 负对照及 NPU 路由 | `COUNTEREXAMPLE/ROUTE_UNKNOWN` | group0x8 指向目的页时 PL330 仍被拒绝；无法区分 GROUPID 语义和实时路由，NPU 主 AXI 仍未证。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | IRQ bit2、CRP/复位、NPU保护配置和故障排空尚未闭合；首次实际 START 前须用户明确授权。 |

## 2026-09-26 DMA_AXI 普通 DDR 实传

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 非安全 PL330 64B 普通 DDR 复制 | `BOARD_PASS_LIMITED` | 显式通道7、源/目的 coherent 页，修正版自动通过且独立只读确认数据/尾部/寄存器，模块卸载资源释放。见 `docs/research/HARDNPU_H1_PL330_64B_DDR_COPY_BOARD_20260926.md`。 |
| H1-05 首次软件验收器误判恢复 | `RESOLVED_AFTER_SOFTWARE_REBOOT` | 首次复制成功但 CSR CNS bit21 造成假故障保留；按设计保留缓冲，正常软件重启回收；新版以低状态位验收。 |
| H1-05 DDRS1 对 PL330 自有目的页允许/拒绝 | `BOARD_PASS_LIMITED/GROUP_UNKNOWN` | 上方已记录闲置页通过、目的页0x20/0x8/0x1均拒绝和故障重启回收；不能据此认定组隔离或 NPU 路由。 |
| H1-04 HardNPU 保护与首算 | `NO-GO/P0` | DMA_AXI group0x20不能代替 NPU group0x8；NPU IRQ bit2、复位/资源、AXI排空及实际输出仍待证。首次 Hard START 前须用户明确授权。 |

## 2026-09-26 PL330 Linux 资源申请

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 非安全 PL330 MMIO 独占申请 | `BOARD_CLAIM_RELEASE_PASS_LIMITED` | 最小模块申请完整4 KiB窗口成功、持有期间 `/proc/iomem` 出现子项、卸载后消失。仅 Linux resource tree 本次证据；见 `docs/research/HARDNPU_H1_PL330_MMIO_CLAIM_BOARD_20260926.md`。 |
| H1-05 受控传输所有权 | `BOARD_PASS_LIMITED/SHARED_OWNER_UNKNOWN` | PL330 自有通道7及Linux资源持有已完成普通DDR与DDRS1受限实传；固件/其它主设备并发及故障后无重启排空未证。 |

## 2026-09-26 PL330 安全位与纯编码候选

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 非安全 manager 的 DMAGO 编码 | `BOARD_DNS_READ/SDK_STATIC_MISMATCH` | DSR bit9=1；SDK `DMA_Exec_DMAGO` 固定 ns=0，ARM 手册说明此组合会报 manager fault，未实测执行。见 `docs/research/HARDNPU_H1_PL330_DMAGO_SECURITY_MISMATCH_20260926.md`。 |
| H1-05 64B 复制微码与非安全 GO | `OFFLINE_PASS/SUPERSEDED_BY_BOARD_COPY` | 当时28B离线候选后已改26B无事件微码，普通DDR真实复制见上方板测记录；旧离线结果不能替代新版运行证据。 |
| H1-05 有界普通 DDR DMA 实传 | `OPEN/P0` | 先证明通道所有权、目标运行接口与故障后缓冲保留，随后在隔离模块受控提交并核对完整数据；不得直接使用 SDK 无界 HAL/全局 DeInit。 |

## 2026-09-26 非安全 AXI DMA 只读前置核验

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 非安全 AXI DMA 只读配置 | `BOARD_READONLY_PASS` | 固定白名单探针在 `0xF8419000` 实读8通道 CSR、状态和配置；八通道仅在采样时为0，未传输。见 `docs/research/HARDNPU_H1_AXI_DMA_NONSECURE_READONLY_20260926.md`。 |
| H1-05 有界 DMA_AXI DDR 流量及 DDRS1 允许/拒绝 | `OPEN/P0` | 需先证明通道所有权、超时/故障后缓冲生命周期与普通 DDR 最小复制，再测试 DDRS1 生效及路由；当前只读值不是保护证明。 |
| H1-04 HardNPU 首算 | `NO-GO/P0` | NPU group/主 AXI 路由、IRQ bit2、复位/资源和故障排空仍未闭合；首次实际 START 前仍须用户明确授权。 |

## 2026-09-26 SDK 源码位置核验

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-04/05 SDK `linux` 子模块定位 | `DECLARED/LOCAL_CHECKOUT_EMPTY` | SDK `.gitmodules` 与官方仓库列出 `linux`，本地 2026.01 快照目录为空；2025.07 归档为6.1.111源码候选，非当前 Image 的精确构建。见 `docs/research/HARDNPU_H1_SDK_LINUX_SUBMODULE_AND_RISCV_SCOPE_20260926.md`。 |
| H1-04/05 DR1V RISC-V 指南适用性 | `SCOPE_CHECKED/NOT_CURRENT_APU_ABI` | APUG1210 的 Linux 章节针对 RPU/OpenSBI；当前板是 AArch64 APU。不能据此解决 AMBA、HardNPU IRQ 或 DDRS1。 |

## 2026-09-26 当前内核 AMBA 资源反汇编

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 PL330 资源错位定位 | `LIVE_IMAGE_DISASSEMBLY_CONFIRMED` | 当前 Image 在偏移472写/读 AMBA 资源，历史模块按480读取并得到实际 end；解释 probe 失败，见 `docs/research/HARDNPU_H1_PL330_LIVE_IMAGE_RESOURCE_OFFSETS_20260926.md`。 |
| H1-05 用 PL330 建立 DDRS1 受控流量 | `NO-GO/P0` | 局部偏移证据不能代替精确内核 ABI；不以硬编码补丁发 DMA。仍需匹配当前 Image 的源码、配置和构建产物或另一可证受控主设备。 |

## 2026-09-26 当前内核镜像身份

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-04/05 运行内核镜像身份 | `BOARD_BOOT_IMAGE_HASH_MATCH` | 启动分区压缩载荷及解压 Image 与既有隔离副本哈希一致，版本字符串一致；见 `docs/research/HARDNPU_H1_RUNNING_KERNEL_IMAGE_IDENTITY_20260926.md`。 |
| H1-04/05 精确源码、配置和构建输出 | `UNKNOWN/P0` | 同一 Image 没有提供编译配置或结构 ABI；历史树 AMBA 布局不兼容。需匹配该 Image 的构建证据或其它经验证的运行接口。 |
| H1-05 PL VDMA 作为 DDRS1 证明 | `NOT_ESTABLISHED` | 有 DMAengine 通道，但没有确认经过 DDRS1/NPU group 0x8；不可将其访问结果外推为 HardNPU 保护。 |

## 2026-09-26 PL330 运行内核 ABI 门槛

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 PL330 作为 DDRS1 受控流量源 | `TARGET_BUILD/BOARD_PROBE_FAIL_ABI_MISMATCH` | 历史树模块能加载但设备 probe `invalid resource/-22`；独立只读诊断显示 AMBA 结构字段与运行 sysfs 错位。未绑定、无通道、未执行 DMA。见 `docs/research/HARDNPU_H1_PL330_AMBA_ABI_MISMATCH_BOARD_20260926.md`。 |
| H1-04/05 运行内核精确构建接口 | `OPEN/P0` | 同 release/vermagic 不保证 AMBA 结构 ABI；需当前运行内核精确源码/配置/输出或对实际使用接口的兼容证明，禁止硬编码偏移绕过。 |

## 2026-09-26 受控 DDRS1 主设备与内核来源

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 AXI DMA 保护测试流量源 | `AMBA_PRESENT/NO_BOUND_DRIVER` | `arm,pl330`设备被识别但无绑定驱动，DMAengine仅 PL VDMA；不能直接进行已知 group 的内存拒绝试验。见 `docs/research/HARDNPU_H1_PL330_LIVE_KERNEL_PROVENANCE_20260926.md`。 |
| H1-04 目标内核构建树精确身份 | `UNKNOWN/P0` | 输出树与运行内核 release相同，但编译者/编译器信息不同，运行配置未导出；模块可装载不证明精确同源，需补来源证据。 |

## 2026-09-26 H1 DDRS1 短时使能读回

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 DDRS1 全局使能位短时切换/恢复 | `BOARD_ENABLE_READBACK_RESTORE_PASS_NO_START` | 一次 CTRL=`0x801`读回，随后`0x800`及八区原值恢复；系统响应、模块数0。无 NPU START。见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_READBACK_BOARD_20260926.md`。 |
| H1-05 实际保护效果与受控主设备 | `NO-GO/P0` | 没有受保护主设备访问或拒绝响应；PL330 AMBA 设备无绑定 DMA 驱动，现有 PL VDMA 不能直接代替 HardNPU 路由。需受控流量、未命中/group和排空实证。 |

## 2026-09-26 H1 START 前旧事件门槛

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-04/05 START 前 IRQ=0、工作状态=0 | `CODED/TARGET_BUILD/BOARD_NO_START_REGRESSION_PASS` | 最后一笔 START 前读两状态，非零拒绝并固定缓冲；当前只做目标构建与默认无启动回归，真实分支未运行。见 `docs/research/HARDNPU_H1_PRESTART_STALE_IRQ_GUARD_20260926.md`。 |
| H1-04/05 当前 IP/IRQ/超时排空 | `NO-GO/P0` | bit2 版本冲突、读回到 START 的竞态及 AXI 排空仍待实证；DDRS1 生效与路由未验。首次 START 仍需用户新的明确许可。 |

## 2026-09-26 H1 DDRS1 短时使能探针准备

| 任务 | 状态 | 证据与验收边界 |
| --- | --- | --- |
| H1-05 短时使能入口与默认门禁 | `CODED/TARGET_BUILD/BOARD_DEFAULT_DENY_PASS` | ABI 2 命令0x1a、新默认关闭参数、目标构建及默认 `EPERM`，只读快照 CTRL仍`0x800`，卸载后模块数0。见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_PROBE_PREP_20260926.md`。 |
| H1-05 全局使能与真实保护语义 | `NO-GO/P0` | 当前手册版本对未命中和区域字段有冲突；未武装、未写 CTRL=0x801，需先闭合共享 DDR 主设备影响及可靠恢复，再验证生效隔离。首次 NPU START 仍需用户新的明确许可。 |

## 2026-09-26 H1 DDRS1 八区候选事务

| 任务 | 状态 | 验收与剩余 |
| --- | --- | --- |
| H1-05 当次 DMA 布局八区配置口读写/恢复 | `BOARD_FULL_REGION_WRITE_READBACK_RESTORE_PASS_DISABLED` | 默认拒绝、显式一次事务候选与恢复均逐字段匹配，CTRL全程`0x800`、80次区域写，后续独立快照原值、模块数0。见 `docs/research/HARDNPU_H1_DDRS1_FULL_DISABLED_TRANSACTION_20260926.md`。 |
| H1-05 生效的 DDRS1 地址保护与首算 | `NO-GO/P0` | 仍需受控启用后的区间比较/未命中、实际 NPU AXI/group、共享影响及异常事务排空证据；首次 START 需用户新的明确许可。 |

## 2026-09-26 DDRS1 关闭状态字段读写

| 任务 | 状态 | 验收与剩余 |
| --- | --- | --- |
| H1-05 DDRS1 APB 区域字段可写/恢复 | `BOARD_REGION7_SAR_WRITE_RESTORE_PASS_DISABLED` | 严格基线后一次写1/读1/写0/读0，CTRL始终`0x800`；后续独立 H1 八区快照不变、模块数0。见 `docs/research/HARDNPU_H1_DDRS1_DISABLED_WRITE_READBACK_20260926.md`。 |
| H1-05 完整候选配置与生效 | `NO-GO/P0` | 其它字段、跨度/比较、全局使能、主 AXI 路由、共享影响与异常排空均未验证；在此之前不可把单字段读回当成地址保护。首次 START 仍需用户新许可。 |

## 2026-09-26 H1 DDRS1 资源冲突负例

| 任务 | 状态 | 验收与剩余 |
| --- | --- | --- |
| H1-05 Linux DDRS1 地址资源互斥 | `BOARD_DIAGNOSTIC_CONFLICT_PASS_NO_START` | 占位模块登记资源后 H1 只读诊断返回 `EBUSY`；占位卸载后诊断恢复，最终模块数0、无资源残留。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CONFLICT_BOARD_20260926.md`。RUN_ONCE 分支未执行。 |
| H1-05 真实保护/AXI 路由/故障恢复 | `NO-GO/P0` | Linux 互斥不覆盖固件及 raw MMIO；需匹配当前硅片/固件的 DDRS1 区域生效、共享影响、NPU 主路由和排空证据。首次 START 仍需用户新许可。 |

## 2026-09-25 H1 DDRS1 Linux 资源申请

| 任务 | 状态 | 证据与下一步 |
| --- | --- | --- |
| H1-05 DDRS1 配置口协作占用 | `CODED/TARGET_BUILD/BOARD_POSITIVE_DIAG_PASS` | 诊断可短暂申请并释放资源，候选运行路径先申请、失败拒绝并在错误回滚；占位冲突反例因 COM4 无输出未验。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CLAIM_20260925.md`。 |
| H1-05 固件/硬件所有权与首次计算 | `NO-GO/P0` | `/proc/iomem` 空缺和 Linux 申请成功不能排除固件或 raw MMIO 访问；区域生效、AXI 路由及故障排空仍待证。首次 START 需用户新的明确许可。 |

## 2026-09-25 H1 group 对照和策略生成

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 TOP_S 编号与 MPU 掩码 | `STATIC_7_OF_7_MATCH/UBOOT_NPU_3` | 手册七项编号与 SDK 七项掩码均为 `1<<编号`；U-Boot 实读 NPU=3。见 `docs/research/HARDNPU_H1_GROUP_ROUTE_MAPPING_20260925.md`。Linux 实时路由仍未证。 |
| H1-05 当次四缓冲 DDRS1 候选生成 | `CODED/HOST_AND_TARGET_C11_PASS/BOARD_NO_START_PASS` | 新纯 C 生成器与独立七区预期逐字节一致，原校验复用生成结果，12反例通过；改动后目标模块构建、只读 DDRS1 诊断与冻结载荷回归通过。无寄存器写入或 START。见 `docs/research/HARDNPU_H1_DDRS1_BUILDER_TARGET_20260925.md`。 |
| H1-05 可用保护与首次真实计算 | `NO-GO/P0` | 先闭合配置所有权、硬件比较/AXI 路由、共享影响和故障排空；首次 START 还需用户新的明确许可。 |

## 2026-09-25 U-Boot 阶段 DDRS/NPU group 只读

| 工作 | 当前状态 | 证据与下一步 |
|---|---|---|
| H1-05 第一区预置是否仅 Linux 写出 | `PRE_LINUX_PRESENT` | 当前 U-Boot DDRS0/1 CTRL/区0 与 Linux 先前快照同值；实际写入者仍未知。见 `docs/research/HARDNPU_H1_UBOOT_DDRS_GROUP_READ_20260925.md`。 |
| H1-05 TOP_S NPU 组编号 | `UBOOT_READ_3_LINUX_RUNTIME_UNKNOWN` | U-Boot 同次读 `GROUPID_NPU=3`；与 SDK 区域选择值0x8可能为 bit3 对应，尚无当前硅片的匹配证明，且 Linux 下该地址此前只读故障。 |
| H1-05 DDRS1 受控配置及首算 | `NO-GO/P0` | 全局使能仍0，需继续闭合实际主 AXI 路由、区域语义、配置所有权、复位/IRQ及故障后排空；实算前另需用户明确许可。 |

## 2026-09-25 H1 驱动内实时 DDRS1 诊断

| 工作 | 当前状态 | 证据与下一步 |
|---|---|---|
| H1-05 驱动自身八区只读、同次 DMA 地址核对 | `BOARD_READONLY_PASS_NO_START` | 新 ioctl 返回四活动缓冲和八区原值；当前 CTRL=`0x800`、软件匹配0、COLD/零写。见 `docs/research/HARDNPU_H1_DDRS1_DRIVER_LIVE_READ_20260925.md`。 |
| H1-05 实际保护/路由/所有权与故障排空 | `NO-GO/P0` | 不重复相同无启动快照；优先找当前芯片/固件的可控配置、实时 group/AXI 生效及异常排空证据。首次 START 仍需用户新的明确许可。 |

## 2026-09-25 H1 DDRS1 动态区域匹配

| 工作 | 当前状态 | 证据与下一步 |
|---|---|---|
| H1-05 四缓冲外 DDR 补集与活动分配匹配 | `CODED/HOST_AND_TARGET_PURE_C_PASS/BOARD_NO_START_PASS` | 逐项核对 CTRL/八区 RASR/SAR/EAR/GROUPID，任何缺口、错误权限/组及额外活动区拒绝；见 `docs/research/HARDNPU_H1_DDRS1_POLICY_MATCH_20260925.md`。 |
| H1-05 DDRS1 生效及资源所有权 | `NO-GO/P0` | SDK 编码和读回形状不能证明当前硅片比较语义、NPU group/AXI 路由、共享影响及异常排空；当前 CTRL 关闭。继续找匹配当前板固件的配置/所有权证据。 |

## 2026-09-25 H1 驱动运行前 DDRS1 门槛

| 工作 | 当前状态 | 证据与下一步 |
|---|---|---|
| H1-05 RUN_ONCE 前实时 DDRS1 CTRL 只读核对 | `CODED/TARGET_BUILD/BOARD_NO_START_PASS` | 仅 ENABLE=1 且8区可继续；当前板 `0x800` 不满足。默认参数无启动回归通过，未测试 START；见 `docs/research/HARDNPU_H1_DDRS1_LIVE_GATE_20260925.md`。 |
| H1-05 全部 region 权限、NPU group/路由和异常排空 | `NO-GO/P0` | 新门槛只是必要条件。继续取得与当前芯片和固件匹配的保护、复位、IRQ及排空证据；实算前另需用户明确许可。 |

## 2026-09-25 手册、Sol 与 demo 对 Hard 首算的复核

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 复用已审资料与示例 | `REVIEWED_NO_CURRENT_ROUTE_PROOF` | Sol 的 MPU 版本冲突和默认放行结论已复用；D21.1 G484 BOOT 静态清 DDRS0/1 使能，D20.1 为 PL SoftNPU 参考，公开 Hard 驱动无 DDRS1 配置。见 `docs/research/HARDNPU_H1_BOOT_DIRECT_ADDRESS_INVENTORY_20260925.md`。 |
| H1-05 当前板的独占地址保护/复位排空 | `NO-GO/P0` | demo 与手册没有补齐实时 TOP_S group、Hard 主 AXI 路由、DDR S1 区域语义、共享影响及排空；继续寻找匹配固件/所有权证据，不因示例存在而放行 START。 |

## 2026-09-25 DDRS0/1 非复位预置来源

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 比对 DDRS0/1 第一区 | `BOARD_READONLY_IDENTICAL_NONRESET` | 两者 CTRL=`0x800`、第一区=`0x301/0/0xffffffff/0`；UG1215 RASR/EAR 复位均为0。见 `docs/research/HARDNPU_H1_DDRS0_DDRS1_PRESET_ORIGIN_20260925.md`。 |
| H1-05 确定区域配置写入者及生效合同 | `UNKNOWN/NO-GO` | 同哈希 BOOT 仅定位全局 enable 清除，邻近调用及简单常量扫描不能锁定第一区写入者；当前控制器关闭，NPU group/主 AXI 路由、区域语义和故障排空仍待证。 |
| H1-05 TOP_S DDRS1 protection 状态只读 | `TWO_TOP_S_READ_FAULTS/UNKNOWN` | `PROTEN_SET@0xF88060B0` 固定只读受控故障，既有 `GROUPID_NPU@0xF8806110` 亦故障；未获 bit1 实时值，不写清保护寄存器。详见同上研究。 |

## 2026-09-25 DDRS1 区域实时快照

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 八区 RASR/SAR/EAR/GROUPID 只读 | `BOARD_READONLY_32_REGISTERS` | 区0=`0x301/0/0xffffffff/0`，区1–7全0，CTRL 前后 `0x800`；目标构建与源码哈希一致。见 `docs/research/HARDNPU_H1_BOARD_DDRS1_REGION_READ_20260925.md`。 |
| H1-05 有效 Hard 主 AXI 地址约束 | `NO-GO/P0` | 全局 MPU 关闭，NPU 实时 group/主设备路由、region 硬件跨度与端点、共享影响、配置所有权及故障排空均未闭合。固定 DMA 缓冲不证明 AXI 排空；首次真实 START 仍需新明确许可。 |

## 2026-09-25 H1 DDRS1 SDK 地址字段

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 补集到 SDK SAR/EAR 页编号 | `SDK_STATIC_OFFLINE_ROUNDTRIP_PASS` | 公共 SDK 的4 KiB起点/包含式末页公式已核；8区边界和已失效实板7区快照编码/反解通过。只输出离线地址字段，无 RASR/GROUPID/CTRL 配置。见 `docs/research/HARDNPU_H1_SDK_REGION_ADDRESS_FIELDS_20260925.md`。 |
| H1-05 可用 DDRS1 保护 | `NO-GO/P0` | 当前 CTRL 显示8区但未启用，实时 NPU group 读故障；硬件跨度/端点、主 AXI 路由、共享影响、资源所有权与故障排空尚缺。SDK 算法不能替代实板隔离验证。 |

## 2026-09-25 当前 DDRS1 只读状态

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 DDRS1 region 数和当前使能 | `BOARD_READONLY_REGION8_DISABLED` | 固定只读映射实读 CTRL `0x800`，UG1215 字段为8区、ENABLE=0；4缓冲补集的区数条件实板成立，但无任何保护配置或 NPU 作业。见 `docs/research/HARDNPU_H1_BOARD_DDRS1_CTRL_READ_20260925.md`。 |
| H1-05 NPU group ID 和配置所有权 | `BOARD_GROUP_READ_FAULT/NO-GO` | CRP与LOCK固定只读成功；TOP_S `GROUPID_NPU` 固定只读触发受控故障，不能以文档复位值3当实时 group。需匹配当前固件/资源所有者的受控证据。 |
| H1-05 首次 Hard Conv | `NO-GO/P0` | DDRS1 当前未使能，尚缺 region 跨度/端点、组/主 AXI 路由、共享影响、故障排空、复位/IRQ合同；真实 START 仍需用户新的明确许可。 |

## 2026-09-25 H1 当前板 DMA 地址快照

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 四缓冲实际地址接入补集规划 | `BOARD_NO_START_SNAPSHOT_GEOMETRY_7_REGIONS` | 既有 `PLAN_TRACE` 本次板端返回四块4 KiB对齐 DMA 基址，冻结载荷测试及默认三项禁止参数通过；抽象规划得到7区。模块已卸载，快照地址失效，不代表硬件保护已配置。见 `docs/research/HARDNPU_H1_BOARD_DDR_ADDRESS_SNAPSHOT_20260925.md`。 |
| H1-05 同次持有的地址隔离与首算 | `NO-GO/P0` | 需要在同一次分配/持有期间重算并受控配置，且当前硅片 DDRS1 所有权、region/group/路由、共享影响、IRQ/复位和故障排空仍缺实证；首次 START 需用户新的明确许可。 |

## 2026-09-25 H1 DDRS1 配置口所有权

| 任务 | 状态 | 证据与验收 |
| --- | --- | --- |
| H1-05 DDRS1 配置口保护、锁和 NPU group | `STATIC_REGISTER_MAP/BOARD_VALUE_UNKNOWN` | UG1215 给出 TOP_S protection set/clear bit1、LOCK 写锁 bit10、NPU group ID 编号字段及复位值；当前 BOOT 同哈希备份只读复核。无实时读回，不能将既有 bus error 归因于该保护。见 `docs/research/HARDNPU_H1_DDRS1_CONFIG_PORT_20260925.md`。 |
| H1-05 受控读回与首次 Hard 首算 | `NO-GO/P0` | 找当前固件/资源所有者提供的受控配置证据；另需 DDRS1 路由/region 语义、复位/IRQ和故障排空。真实 START 前需用户另行明确许可。 |

## 2026-09-25 H1 DDRS1 非重叠补集候选

| 任务 | 状态 | 证据与下一步 |
|---|---|---|
| H1-05 四缓冲外 DDR 补集几何 | `GEOMETRY_FEASIBLE_CONDITIONAL` | 实板只读确认1 GiB System RAM；抽象规划器证明四缓冲补集在单区最多256 MiB假设下至多八个互不重叠区，恰8区边界和10,000布局通过。尚需匹配当前硅片的 region 数/跨度、SAR/EAR 端点、NPU 主 AXI/group ID、其它主设备影响和受控寄存器访问；无 MPU 写入或真实 NPU 作业。见 `docs/research/HARDNPU_H1_DDR_COMPLEMENT_GEOMETRY_20260925.md`。 |

## 2026-09-25 H1 模拟设备完整加载与软件包

| 任务 | 状态 | 证据与下一步 |
|---|---|---|
| H1-02 冻结模型厂家 `LoadNetwork` | `SOFTWARE_LOAD_NETWORK_PASS_SIMULATED_DEVICES` | 私有无设备环境下 parser→Optimize→runtime→LoadNetwork 获网络 ID 0，输入37,632/输出12,544字节，UnloadNetwork 成功。受限 CMA 模拟分配两块、四次区间内同步；未执行 Execute。见 `docs/research/HARDNPU_H1_VIRTUAL_CMA_LOAD_PACKET_20260925.md`。 |
| H1-03 模型到厂家 packet 血缘 | `SOFTWARE_PACKET_EXACT_MATCH_SIMULATED_DEVICES` | 在 LoadNetwork 的520字节设备同步前只读捕获130字，与 Sol/Astra 独立捕获逐字相同，差异0；见 `docs/records/hardnpu_h1/2026-09-25-virtual-cma/load_packet_bridge.json`。这闭合软件生成血缘，不证明真实提交或结果。 |
| H1-04/05 首次真实 HardNPU Conv | `NO-GO/P0` | 软件 packet 已核；继续闭合 Hard 主 AXI 地址约束、当前 IP/IRQ、复位资源及故障/超时事务排空，之后使用独立 H1 驱动与冻结金样做受控板测。真实 START 前另需用户明确许可。 |

## 2026-09-25 H1 厂家 CMA 软件链

| 任务 | 状态 | 证据与下一步 |
|---|---|---|
| H1-02 `LoadNetwork` CMA ABI 定位 | `SOFTWARE_BOUNDARY_RESOLVED_SIMULATED_DEVICES` | 冻结公开 `cma_mem.c` 的独立 fd/ioctl/mmap 已审；在私有无设备环境中用精确、有界的虚拟 CMA 请求/匿名映射使 LoadNetwork 通过。旧 `std::bad_alloc` 的唯一抛出点仍未证，真实 H1 四缓冲与厂家 CMA 尚未集成。见 `docs/research/HARDNPU_H1_CMA_LOADNETWORK_CONTRACT_20260925.md` 与最新软件链报告。 |
| H1-04 厂家 CMA 与独立 Hard 驱动合流 | `OPEN/NO-GO` | 在首次计算安全合同闭合后，明确 DMA 缓冲所有权、地址范围、映射与缓存同步，并验证真实模型链。公开 CMA 同步 ioctl 未见分配区间检查，不能原样作为 H1 安全执行入口。 |

## 2026-09-25 H1 DDRS1 默认放行版本门槛

| 任务 | 状态 | 证据与下一步 |
|---|---|---|
| H1-05 四缓冲 DDRS1 允许区域作为首算隔离 | `REJECTED_AS_CONTAINMENT/NO-GO` | Sol 已核 UG1214 v1.3 第33章说明未命中区域默认放行；UG1214 的 RASR bit10 未配置区域保护与 UG1215/BSP 保留位定义冲突。当前芯片实际语义仍 `UNKNOWN`。先取得匹配版本的默认拒绝及 HardNPU 主设备路径证据，或确定其它有效地址约束；仍需单独闭合复位、IRQ 和超时排空。见 `docs/research/HARDNPU_H1_DDRS1_MPU_CANDIDATE_20260924.md`。 |

## 2026-09-24 H1 图到 packet 身份

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-03 优化图与既有 packet 交叉核对 | `IDENTITY_AND_RAW_VALUE_MATCH_LIMITED` | 同一 ONNX、四类张量几何/量化、优化常量与旧夹具逐字节、64 bias 字及13项130字 packet 匹配；见 `docs/research/HARDNPU_H1_OPTIMIZE_PACKET_IDENTITY_BRIDGE_20260924.md`。不重做捕获；真实 `LoadNetwork→workload→packet` 血缘仍因 CMA 停点未证。 |

## 2026-09-24 H1 runtime 后续边界

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-02 模拟设备 runtime 构造 | `TARGET_RUNTIME_REGISTERED_SIMULATED_DEVICES` | `IRuntime::Create` 成功，设备列表含 `Alnpu`；两次寄存器查询及映射仍仅在匿名虚拟层。见 `docs/research/HARDNPU_H1_VIRTUAL_RUNTIME_LOAD_BOUNDARY_20260924.md`。 |
| H1-02 2026-09-24 无 CMA 的 `LoadNetwork` 尝试 | `HISTORICAL_FAILED_AT_CMA` | 当时 parser/Optimize/runtime 通过，私有根缺 `/dev/cma_mem` 导致多次 `-ENOENT`，随后抛 `std::bad_alloc`；该历史停点已由上方 2026-09-25 受限虚拟 CMA 软件实验越过。仍未执行 `Execute` 或真实硬件作业。 |

## 2026-09-24 H1 厂家软件分区

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-02 厂家 Optimize 驱动查询阻点 | `SOFTWARE_OPTIMIZE_PASS_SIMULATED_DEVICES` | 仅在私有普通文件与匿名寄存器窗口的显式虚拟模式下，真实 Arm NN Optimize 完成，单 Conv 改写为 `ALHardNPU`，五层后端均为 `Alnpu`，常量哈希与冻结输入相同；默认隔离器仍拒绝首个 ioctl。原始输出见 `docs/research/HARDNPU_H1_VIRTUAL_OPTIMIZE_20260924.md`。下一步在同等无真实设备条件下核验 workload/packet 生成。 |
| H1-04/05 真实 HardNPU 驱动与首次计算 | `NO-GO/P0` | 虚拟软件分区不证明当前实板驱动、MMIO、DDR/AXI 隔离、IRQ、复位或超时排空。真实 START 前继续闭合这些合同并取得用户新的明确许可。 |

## 2026-09-24 Sol DDR 成果复用边界

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 复用 Soft DDR 所有权和故障策略 | `APPLIED_TO_H1_CANDIDATE_NO_START` | Sol v0.5.4 固定 Pool 的自有 coherent 缓冲、padding/guard、单作业与冷恢复方法已对照 H1 四缓冲/故障固定候选；不重复 Soft 板测或 H1 无写入地址轨迹。 |
| H1-05 Hard 主 AXI 与 DDRS1 实测 | `NO-GO/P0` | Sol 的 SoftNPU 经 PL HP1 的固定 Pool 通过不证明 HardNPU 经 DDRS1 的组 ID 匹配、地址隔离、Conv 输出/IRQ 或异常排空；继续补 Hard 专属证据。见 `docs/research/HARDNPU_H1_DDRS1_MPU_CANDIDATE_20260924.md`。 |
| H1-05 DDRS1 软件配置复核 | `SDK_STATIC_ONLY/NO-GO` | SDK 仅给普通 MPU 8 个区域，初始化会暂时禁用目标 MPU；当前芯片初始化配置的是 APU device ID 6，不是 DDRS1 device ID 1。未命中区域行为仍未知，不能直接构造 H1 四缓冲白名单。 |

## 2026-09-24 当前启动镜像 DDRS1 路径

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-05 当前 BOOT 的 DDRS1 初始化 | `CURRENT_IMAGE_STATIC_CLEAR_BIT0/BOARD_VALUE_UNKNOWN` | 同板同哈希 BOOT.bin 的 AArch64 指令在上层调用的函数内依次对 DDRS0/1 CTRL 读后清 bit0 写回；没有实时读回或执行轨迹。见 `docs/research/HARDNPU_H1_CURRENT_BOOT_DDRS1_INIT_20260924.md`。 |
| H1-05 DDRS1 用于 H1 地址隔离 | `NO-GO/P0` | 需证明 NPU 对 DDRS1 的精确路径和 group ID、其它主设备影响、区域未命中动作及超时后在途事务。当前 TF 静态路径倾向禁用 MPU，不能擅自开启或据此放行 START。 |

## 2026-09-24 H1 主 DDR 保护候选

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-05 DDRS1 MPU 与 NPU 主访问 | `INFERRED_CANDIDATE/NO-GO` | UG1214 把非 APU/RPU 访问 DDR 的 S1 通路归 DDRS1 MPU；通用 SDK 给 NPU group ID=`0x8`，尚未实证当前硅片匹配。板端 `/dev/mem` 只读 CTRL 发生用户态 bus error，配置值仍 `UNKNOWN`，已停止该直读路径。先找受控资源所有权与区域未命中行为，不启用保护或 START。见 `docs/research/HARDNPU_H1_DDRS1_MPU_CANDIDATE_20260924.md`。 |

## 2026-09-24 H1 手册适用性核对

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04/05 IPUG166 对 HardNPU 合同 | `DOCUMENT_SCOPE_EXCLUDED` | 全13页只读核对：它描述 PL Video NPU/可定制 SoftNPU；其复位、IRQ 和 AXI 规则不能放行 PS HardNPU。见 `docs/research/HARDNPU_H1_VIDEO_NPU_MANUAL_SCOPE_20260924.md`。继续找与当前 HardNPU IP 修订直接匹配的官方寄存器/互连证据。 |
| H1-05 首次硬件计算 | `NO-GO/P0` | 当前 IP/IRQ bit2、复位资源、主 AXI/超时排空合同未闭合；真实 START 前仍需用户新的明确许可。 |

## 2026-09-24 H1 无桩软件分区

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-02 parser 常量身份 | `BOARD_PARSER_PASS_LIMITED` | 私有无设备环境导出五层；12,288字节权重和256字节 bias 与冻结夹具 SHA-256 完全一致。只证明 parser 输入到 Optimize 的图身份。 |
| H1-02 无桩 Optimize→Alnpu | `BLOCKED_AT_DRIVER_IOCTL_0x4801` | 未创建 runtime 的真实探针仍在 Optimize 内 `O_RDWR` 打开私有 Hard 占位并请求 `0x4801`；监督器拒绝，未生成优化图。同库静态调用链还要求 Soft `0x5301` 与两个可写共享映射，而当前实时 DTB 未见 Soft 节点。下一步须明确真实安全驱动/后端实现方案；任何虚拟化实验只算模拟软件条件，实板能力另证。 |

## 2026-09-24 H1 首算故障诊断

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04/05 首个终止故障原因 | `CODED_TARGET_BUILD_DEFAULT_PREFLIGHT_PASS_NO_START` | ABI 2 追加 `failure_reason`，候选在激活、提交、IRQ、超时或完整性失败时保留首因；新版目标构建、默认拒绝和预检通过，旧版验收程序被版本检查拒绝。真实故障分支未运行。 |
| H1-05 首次硬件计算 | `NO-GO/P0` | 继续核准当前 IP/IRQ bit2、复位资源、AXI/Cache/超时排空和量化合同；真实 START 前仍需用户新的明确许可。 |

## 2026-09-24 H1 IRQ 启用顺序

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 软复位 bit0 清零语义 | `MANUAL_STATIC_CONFIRMED_BOARD_NOT_RUN` | UG1215 标为写高脉冲/自动清零；候选轮询有依据，但当前芯片时序未实测。见 `docs/research/HARDNPU_H1_SOFT_RESET_IRQ_ARM_ORDER_20260924.md`。 |
| H1-04 IRQ 使能时点 | `CODED_TARGET_BUILD_PREFLIGHT_PASS_NO_START` | 最后一笔 START 后才使能已登记 IRQ；目标构建、无启动预检通过。快速完成/迟到 IRQ 仍无设备证据。 |

## 2026-09-24 H1 权重尾部与地址边界

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 权重分配尾部哨兵 | `CODED_HOST_TARGET_BUILD_PREFLIGHT_PASS_NO_START` | 权重 coherent 容量16,384、逻辑12,288，尾部4KiB检查及完成故障位已接入；主机测试、目标构建/预检通过。无设备写坏注入，见 `docs/research/HARDNPU_H1_WEIGHT_GUARD_AXI_LIMIT_20260924.md`。 |
| H1-05 AXI 范围与排空 | `NO-GO/P0` | packet 的 burst/outstanding=8不是地址白名单；尾部哨兵不检测只读越界或分配外访问。仍需设备主 AXI 边界和超时后排空证据。 |

## 2026-09-24 H1 可选复位路径

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 当前设备 reset 句柄 | `BOARD_OPTIONAL_RESET_ABSENT_NO_START` | 无启动目标模块 probe 实测 `reset provider absent`，与当前 DTB 缺 `resets` 及公开驱动 optional 语义一致；bit12 释放解释仍 `INFERRED`。见 `docs/research/HARDNPU_H1_OPTIONAL_RESET_ROUTE_20260924.md`。 |
| H1-04 不碰 CRP 的一次性候选 | `CODED_TARGET_BUILD_DEFAULT_DENIAL_PASS_EXPERIMENTAL` | `trust_boot_reset_release` 默认0；仅显式启用且无 reset provider 才跳过 CRP。单独启用此参数时其余两门禁仍拒绝 RUN，TOP/CRP 未变。真实分支未运行，不视作复位合同完成。 |

## 2026-09-24 H1 一次性原始输出

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-05 保存首算原始输出 | `CODED_TARGET_BUILD_DEFAULT_DENIAL_CLEANUP_PASS_NO_START` | `--execute` 需独占新输出路径；完成后写入12,544字节再逐字节比较。新板端构建、预检和默认拒绝时空文件清理通过；真实 READ_OUTPUT/保存分支未执行。见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。 |

## 2026-09-24 H1 当前资源持有者与启动 DTB

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 TF DTB 到实时 NPU 绑定 | `BOARD_READONLY_EXACT_NODE_MATCH` | 当前 TF DTB 与实时 FDT 的 NPU 节点全属性逐字节相同，均无 `resets`；DTB 原始源码/PL 修订仍未知。见 `docs/research/HARDNPU_H1_BOOT_DTB_CRP_OWNER_GATE_20260924.md`。 |
| H1-04 CRP 资源独占门禁 | `CODED_TARGET_BUILD_DEFAULT_PREFLIGHT_PASS_NOT_EXERCISED` | `/proc/iomem` 显示 FPGA manager 持有覆盖 NPU 第三资源的窗口。一次运行候选在映射前请求独占、失败拒绝；目标构建和无启动预检通过，实际 RUN_ONCE 分支未调用。 |
| H1-04/05 当前复位/资源所有权 | `NO-GO/P0` | 需要匹配当前 TF DTB/内核的受控复位接口或明确的资源协同方案；不得靠裸 `ioremap` 绕过已持有窗口。并行解决 IRQ/AXI/超时等合同。 |

## 2026-09-24 H1 结果验收准备

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-05 冻结金样输出验收程序 | `CODED_TARGET_BUILD_PREFLIGHT_COMPARE_TEST_PASS_NO_START` | 三份冻结文件 CRC/长度、地址轨迹、COLD/零命令、持有/释放在板端通过；离线自比和单字节破坏判别通过。未来 `--execute` 将逐字节比较硬件输出与 CPU 金样。本次未运行 `--execute`，没有硬件输出结果，见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。 |
| H1-05 首次硬件计算 | `NO-GO/P0` | 仍需当前 IP/IRQ bit2、复位资源归属、AXI/Cache/超时排空及量化合同审查；满足后还需用户新的明确硬件启动许可。 |

## 2026-09-24 H1 完成数据门禁

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 完成 IRQ 后 CRC/哨兵故障隔离 | `CODED_HOST_TARGET_BUILD_DEFAULT_DENIAL_PASS_LIMITED` | DONE 后5类数据破坏会转 FAULT_PINNED；主机/板端状态机测试、目标构建与默认拒绝回归通过。实际 IRQ/坏数据硬件路径未执行，见 `docs/research/HARDNPU_H1_DONE_INTEGRITY_GUARD_20260924.md`。 |
| H1-05 首算结果与 AXI 边界 | `NO-GO/P0` | 零异常掩码不能证明 AXI 全部访问范围、全局排空或量化结果；还需当前 IP/IRQ、复位和受控首算证据。 |

## 2026-09-24 H1 一次运行候选

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 限定一次运行驱动路径 | `CODED_TARGET_BUILD_DEFAULT_DENIAL_PASS_NO_START` | `RUN_ONCE`、激活、IRQ/超时、状态和输出诊断已编译；两个参数默认0，板端实际拒绝执行且状态 COLD/零写，旧装载/轨迹回归通过。实际硬件分支未执行，见 `docs/research/HARDNPU_H1_GATED_FIRST_RUN_CANDIDATE_20260924.md`。 |
| H1-04/05 硬件合同与首次提交 | `NO-GO/P0` | 需复位绑定/资源所有权、IP/IRQ bit2、AXI/Cache/超时排空、输出合同及新的明确硬件启动许可；人工参数不能替代证据。 |

## 2026-09-24 H1 复位绑定

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 当前 NPU reset 绑定与 CRP 现状 | `BOARD_READONLY_SOURCE_MISMATCH_CONFIRMED` | 实时 DTB 无 NPU `resets`/CRP provider，另有第三段 CRP 窗口与 FPGA manager 资源重叠；只读 CRP `+0x74` bit12=1。私有源码的复位解释属 `INFERRED`，见 `docs/research/HARDNPU_H1_LIVE_RESET_BINDING_20260924.md`。 |
| H1-04/05 真实激活和首算 | `NO-GO/P0` | 需当前启动 DTB 来源、CRP 资源共享/复位控制合同；不能直接套用公开驱动的 optional reset 或无锁写第三段。并行解决 IP bit2、AXI 与超时排空。 |

## 2026-09-24 H1 资源门禁

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 当前 DT 寄存器窗口与 IRQ 解析 | `BOARD_RESOURCE_MATCH_AND_IRQ_RESOLVE_PASS_NO_START` | 原始大端 `reg` 确认为主区 `0x63F00000/0x100000`、TOP `0xF8800000/0x200`、第三段 `0xF8801000/0x100`；内核解析 IRQ 31。无启动模块严格匹配并通过板上装载、载荷/轨迹回归和卸载，见 `docs/research/HARDNPU_H1_LIVE_RESOURCE_GATE_20260924.md`。 |
| H1-04/05 IP 修订、AXI 与受控首算 | `NO-GO/P0` | 当前 DT 和 IRQ 编号不证明 bit2、设备主 AXI 可达性、实际 IRQ 清除或超时排空；资源2用途仍待核对。 |

## 2026-09-24 H1 激活顺序

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 激活前 DMA 所有权固定 | `CODED_HOST_TARGET_SOFTWARE_PASS_LIMITED` | `h1_run_submit_once` 在激活回调前进入不可释放状态；激活失败零命令、故障固定，主机和板端纯软件测试通过。见 `docs/research/HARDNPU_H1_ACTIVATION_PIN_ORDER_20260924.md`。 |
| H1-04/05 实际激活与首算 | `NO-GO/P0` | 当前回调仅测试追踪；需 IP/IRQ bit2 修订、受控 TOP/复位、AXI 与超时排空合同，再连接真实内核 START/IRQ。 |

## 2026-09-24 H1 顶层时钟现状

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 当前 TOP NPU 时钟控制 | `BOARD_READONLY_ZERO_CONFIRMED` | `CFG_CTRL_NPU` 实读0，UG1215 bit0/bit1 分别为功能/RAM 时钟使能；公开驱动写3。首算候选需受控使能/复位及复核，当前只读证据见 `docs/research/HARDNPU_H1_LIVE_TOP_CLOCK_READ_20260924.md`。 |
| H1-04/05 硬件修订与 IRQ bit2 | `OPEN_CONFLICT/P0` | TOP 时钟实读不能识别 HardNPU IP 修订；厂家 packet `0x1020=7` 与本地手册保留 bit2 仍冲突。 |

## 2026-09-24 H1 实际模块引用

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 持续模块引用与无启动释放 | `BOARD_OWNER_HOLD_PASS_NO_START_LIMITED` | 真实 coherent 缓冲校验后获取模块引用；板端测试进程退出仍拒绝普通卸载，独立释放后卸载成功。未装载/重复 HOLD/重复 RELEASE 均拒绝。见 `docs/research/HARDNPU_H1_PERSISTENT_OWNER_HOLD_20260924.md`。 |
| H1-04 状态机到实际 START/IRQ | `OPEN/P0` | 状态机已链接模块，但未执行 `prepare/submit` 或 MMIO；需当前 IP 修订、IRQ/AXI/超时合同及受控首算准备。 |

## 2026-09-24 H1 模块所有权保护

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 手动解绑入口关闭 | `BOARD_BIND_ATTRS_ABSENT_PASS_LIMITED` | `suppress_bind_attrs` 目标构建并板端实测，bind/unbind 不存在；原装载/轨迹通过，空闲卸载正常。见 `docs/research/HARDNPU_H1_MODULE_LIFETIME_GUARD_20260924.md`。 |
| H1-04 模块引用前置门禁 | `CODED_HOST_TARGET_SOFTWARE_PASS_LIMITED` | 状态机拒绝未持有引用时进入 READY；板端实际持有设备 FD 时 `rmmod` 失败，关闭后成功。未来 START 路径仍须取得独立持续引用，并保护其它设备移除路径。 |

## 2026-09-24 H1 目标地址轨迹

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 实际分配地址进入 8 笔提交字段 | `BOARD_PLAN_TRACE_PASS_NO_START_LIMITED` | `/run` 新模块一次装载/测试/卸载成功，装载前拒绝，装载后 CRC/哨兵、计划及轨迹通过；只记录返回值，无 MMIO/IRQ/NPU 作业。见 `docs/research/HARDNPU_H1_BOARD_DMA_PLAN_TRACE_20260924.md`。 |
| H1-04/05 真实提交与首算 | `NO-GO/P0` | 仍需当前 IP 修订、bit2/IRQ 清除、顶层使能/复位、AXI 范围、超时排空及输出合同。 |

## 2026-09-24 H1 提交状态接线

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 一次性提交生命周期包装 | `CODED_HOST_SOFTWARE_PASS_LIMITED` | READY/完整计划后，首写前锁定缓冲；8 个回调失败点均故障固定，正常 8 写后等待 IRQ，禁止重试。主机严格 C11 测试通过；尚未接内核 MMIO/IRQ。见 `docs/research/HARDNPU_H1_SUBMIT_STATE_AND_IRQ_MASK_20260924.md`。 |
| H1-04 中断使能与 IP 修订 | `OPEN_CONFLICT/P0` | 冻结厂家包 `0x1020=7` 涉及本地 UG1215 保留 bit2，厂家等待函数又检查状态 bit2。需当前 IP/寄存器修订及对应清除语义；不得由软件包推断硬件。 |

## 2026-09-24 H1 一次性中断/缓冲生命周期

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1 首算候选完成与错误分类 | `CODED_HOST_TARGET_SOFTWARE_PASS_LIMITED` | 只接受 IRQ 原始值1、工作状态5；其他非零隔离，超时/完成后均禁止缓冲释放。主机/板端纯软件测试通过；尚未接内核 MMIO。见 `docs/research/HARDNPU_H1_ONESHOT_IRQ_AND_BOOT_AUDIT_20260924.md`。 |
| 当前 TF 启动文件身份 | `READONLY_HASH_MATCH_20260914_BACKUP` | BOOT、脚本、DTB 哈希与旧同板备份一致；仍不能证明 bit/IP 构建或运行期配置身份。 |
| H1 多次作业与超时排空 | `OPEN/P0` | 一次性状态机不能代替产品重复推理；需可证明的停止/AXI 排空或隔离机制及 IRQ 代数。 |

## 2026-09-24 H1 中断位版本冲突

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 IRQ 错误位及当前 IP 身份 | `OPEN_CONFLICT/P0` | UG1215 列 `0x1018` bit1 地址错误；冻结厂家等待函数检查 bit2。需当前 bit/IP 版本及对应 RTL/寄存器实证，首算前解决；见 `docs/research/HARDNPU_H1_IRQ_BIT_CONFLICT_20260924.md`。 |

## 2026-09-24 H1 目标端数据装载

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1 固定输入/权重进入 coherent 缓冲 | `BOARD_COHERENT_PAYLOAD_STAGE_PASS_LIMITED` | 一次板端加载/测试/卸载，输入及权重从目标缓冲回算 CRC 与电脑独立复算相同，错误 CRC/重复装载拒绝，输出 16 KiB 哨兵完整。见 `docs/research/HARDNPU_H1_TARGET_PAYLOAD_STAGING_20260924.md`。 |
| H1-04/05 实际提交及首算 | `NO-GO/P0` | 继续寄存器/bit 身份、设备 AXI 范围、权重物理顺序、IRQ 代数、超时排空及量化结果合同；当前装载接口没有 NPU 启动路径。 |

## 2026-09-24 H1 冻结数据与包字段

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1 输入/权重/bias/输出声明几何 | `PACKET_GEOMETRY_AND_BIAS_MATCH_LIMITED` | 真实软件包解出输入 37,632、权重 12,288、输出 12,544 字节，bias 64 字与原文件逐字一致；见 `docs/research/HARDNPU_H1_PAYLOAD_PACKET_GEOMETRY_20260924.md`。下一步建立目标端数据装载/回读与尾部哨兵门禁。 |
| H1 实际线性布局、量化及 AXI 边界 | `OPEN/P0` | `0x004C=119` 但 `0x0048=0` 的量化语义、权重/输入设备读取顺序、DMA 尾拍与全局排空均未由软件包证明；不得据静态尺寸放行首算。 |

## 2026-09-24 H1 分配模块目标构建

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 四块 coherent 缓冲分配候选 | `BOARD_ALLOCATION_RELEASE_PASS_LIMITED` | 板端私有 6.1.111-rt42 输出树构建返回 0，vermagic 匹配；一次加载完成四块分配/校验，一次卸载恢复未绑定。无 `Module.symvers` 且 clock skew；未启动 NPU，AXI 可达性未知。见 `docs/research/HARDNPU_H1_ALLOCATION_MODULE_TARGET_BUILD_20260924.md`。 |
| H1-04 独立运行/提交驱动 | `OPEN/P0` | 复核权重/输入实际布局和 DMA 范围，完成隔离分配验证、MMIO/IRQ/超时排空合同与 bit 身份；硬件首算仍 `NO-GO`。 |

## 2026-09-24 H1 packet-DMA 提交核心

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1-04 固定 H1 packet-DMA 提交核心 | `CODED_HOST_AND_TARGET_SOFTWARE_PASS_LIMITED` | 冻结 packet 130/130、四 DMA 区域校验、8 次精确写序列和故障截断；主机与板端 `/run` 纯软件测试通过。见 `docs/research/HARDNPU_H1_DMA_SUBMISSION_CORE_20260924.md`。 |
| H1-04 独立 HardNPU 驱动完整合同 | `OPEN/P0` | 接入真实 DMA 分配与 Cache 所有权、当前硬件身份、IRQ 代数及超时隔离/排空；核心回调尚未接 MMIO。板端有历史私有构建树，缺 `Module.symvers` 且精确源码同一性未知。 |
| H1-02 无桩后端与 H1-05 硬件首算 | `OPEN/NO-GO` | 完成真实 `Optimize→Alnpu` 归属、权重布局/范围、bit/DTB 身份与驱动，再审一次受控提交。视频按用户顺序后置。 |

## 2026-09-24 H1真实Execute提交入口软件捕获

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1直接构造夹具Execute模式与`pkg_info` | `TARGET_PRE_SUBMIT_CAPTURE_PASS_DEVICE_BLIND_LIMITED` | 实际选择packet-DMA；`+0x10=130`，`+0x1c/+0x20/+0x24`与三种输入/权重/输出哨兵相符；13项/130字包未变。提交入口截断、硬件未运行；见`docs/research/HARDNPU_H1_PRE_SUBMIT_RUNTIME_CAPTURE_20260924.md`。 |
| H1-02真实无桩后端分配 | `OPEN/P0` | 当前捕获仍直接构造；需真实parser→Optimize→Alnpu支持与workload工厂证据，禁止把typed-stub分区当验收。 |
| H1-04独立packet-DMA安全驱动 | `OPEN/P0` | 按本次实际分支，建立真实DMA包/输入/权重/输出分配和范围、Cache、IRQ代数、超时隔离与停止/排空合同；公开驱动不得原样加载。 |
| H1-05硬件首算 | `NO-GO` | 等真实缓冲所有权、当前bit/DTB身份和独立驱动证据后，再审单次受控硬件试验。 |

## 2026-09-24 HardNPU有界CMA软件探针与前人进度核对

| 任务 | 状态 | 证据/下一动作 |
| --- | --- | --- |
| H1打包后Pool/CMA分配 | `TARGET_HOST_SUBSTITUTE_TO_PHY_BOUNDARY_PASS_LIMITED` | 同哈希13项/130字packet后，目标一次申请16 KiB主机替身并在`Pool::GetPhyAddr`入口退出；监督器PASS，硬件未运行。见`docs/research/HARDNPU_H1_POSTPACK_HOST_CMA_TARGET_20260924.md`。不把哨兵当DMA地址。 |
| H1-02无桩真实Alnpu分配 | `OPEN/P0` | 既有目标parser通过、typed-stub分区仅条件结果，真实runtime在驱动`ioctl 0x4801`前受阻；按Astra/Sol交接补真实支持判断、partition与workload工厂归属。 |
| H1-04～06真实执行合同及首算 | `NO-GO/P0` | 真实`pkg_info`/模式、重排和DMA地址范围、Cache、IRQ、超时停止及独立安全驱动未闭合；先做合同审查，再评估一次性截断探针和受控硬件试验。 |

## 2026-09-24 HardNPU打包后目标端观察

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| H1打包后首个副作用边界 | `TARGET_POOL_ACQUIRE_TRIPWIRE_OBSERVED_LIMITED` | 五项负探针通过；厂家包13项/130字与前次完全一致；packer返回后首先遇到`Pool::Acquire`，未到GetPhyAddr。候选整体退出3/监督器FAIL是保护性中止，不能记PASS。原始日志及哈希见`docs/records/hardnpu_h1/2026-09-24-postpack-pool-target-audit.json` |
| H1有界Pool/CMA主机替身（当时状态） | `SUPERSEDED_BY_LATER_TARGET_PASS_LIMITED` | 本行记录先前Pool tripwire阶段；后续目标端有界主机替身已到`Pool::GetPhyAddr`入口，见本页首节。真实`pkg_info`仍未观察。 |

## 2026-09-24 HardNPU打包后软件边界候选

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| H1打包后首个Pool入口截断 | `HOST_SYNTAX_PASS_TARGET_NOT_RUN` | 派生门禁在packer返回后把`Pool::GetPhyAddr`改为记录并退出，其余23项tripwire保留；主机严格语法通过。需目标私有根AArch64构建、合成负探针和一次设备遮蔽运行，验证实际调用顺序 |

## 2026-09-24 HardNPU Execute边界静态核对

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| H1-04 两处提交调用/重定位 | `STATIC_ELF_BOUNDARY_PASS_RUNTIME_NOT_RUN` | 同哈希ELF在两处读取模式并通过JUMP_SLOT调用normal或DMA，之后等待IRQ；`docs/records/hardnpu_h1/2026-09-24-execute-submit-sites.json` |
| H1-04 提交前Pool/CMA副作用闭包 | `OPEN/P0` | 先证明打包后的`GetPhyAddr`、`GetPointer`、`memcpy`、CMA同步、容量不足Acquire及退出路径在设备遮蔽环境中可安全截断；未闭合前不得调用Execute或接入真实设备 |

## 2026-09-24 HardNPU优先顺序与首算门禁

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| H1首算证据交叉核对 | `OFFLINE_GATE_7_OF_7_HARDWARE_NO_GO` | 冻结软件packet、校验、同哈希静态分支/字数审计一致；`docs/records/hardnpu_h1/2026-09-24-first-run-gate.json`。只是证据完整性检查，不是设备运行或首算许可 |
| H1实际Execute与pkg_info | `OPEN/P0` | 在设备遮蔽、提交函数前中止的隔离条件下实测模式及`pkg_info`；需处理Pool替身和设备副作用门禁，不能直接越过已有packer截断点 |
| H1独立驱动与首算 | `NO_GO/P0` | DMA范围/Cache所有权、寄存器别名、IRQ/超时停止、bit/DTB身份及无CPU回退仍缺；完成审查后才决定受控首算 |
| VID-001后续集成 | `DEFERRED_BY_USER_PRIORITY` | 先完成HardNPU；既有视频候选不提升为实时采帧证据 |

## 2026-09-24 VID-001视频状态复位同步器

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 UI/PS状态域复位 | `CODED_STANDALONE_SYNTH_PASS_SIM_NOT_RUN` | 异步断言、p2f_clk0两拍释放模块与状态路径独立综合378 LUT/345寄存器；需复位/AXI行为仿真与SoC连线 |
| VID-001 uidbuf多时钟复位及在途写 | `OPEN` | 保存uidbuf将同一复位用于UI/摄像头写/显示读域和FIFO；PLL失锁时FDMA AXI仍可能运行。需逐域释放、FIFO重启、B响应排空及旧帧失效验证 |

## 2026-09-24 VID-001同域状态与视频复位

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 GP0状态时钟方案 | `P2F_CLK0_SAME_DOMAIN_CANDIDATE_GP_NOT_GENERATED` | uidbuf帧状态、FDMA AXI与写响应保护器均使用p2f_clk0；隔离GP0及从端须明确同接该时钟，并检查生成HDL，否则需跨域快照 |
| VID-001 AXI/视频会话分离复位 | `CODED_STANDALONE_SYNTH_PASS_SIM_NOT_RUN` | 桥增FRAME_RESETN，隔离TD展开/综合377 LUT、343寄存器、359 slice；74端口无约束及未驱动归零警告。需复位同步释放、AXI及帧序列RTL仿真、SoC集成 |

## 2026-09-24 VID-001视频SoC隔离源阶段

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 视频项目隔离源副本/路径重绑 | `SOURCE_STAGE_REBASED_NOT_GENERATED` | 306项源文件核对，项目入口及两份IP元数据路径重绑，68项项目源引用均存在；生成HDL未变化。需在隔离副本中启用GP/地址、核对输出路径并受控生成，再做完整系统验证 |

## 2026-09-24 VID-001状态桥SoC接入前门禁

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 视频SoC GP/地址/路径审计 | `READONLY_AUDIT_PASS_INTEGRATION_OPEN` | 两层PS GP关闭、活动总线连接0、地址源0、生成HDL无GP0；旧绝对路径已定位。需在隔离副本重绑并生成，建立非冲突地址和完整SoC证据 |
| VID-001 视频事件至PS总线时钟 | `SAME_DOMAIN_CONDITIONAL` | 视频帧事件与FDMA同在p2f_clk0；若GP0与AXI从端也接p2f_clk0可省跨域桥。实际GP0生成连线未有，异域时仍需原子快照/握手 |

## 2026-09-24 VID-001状态总线独立综合

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 只读AXI-Lite帧状态桥 | `STANDALONE_SYNTH_PASS_WITH_WARNINGS_SIM_NOT_RUN` | TD独立展开/综合导出DB，378 LUT/343寄存器；未驱动网归零及73端口无管脚约束警告。需AXI仿真、隔离视频SoC的PS GP启用/地址映射/完整综合与驱动，不能独立bitgen |

## 2026-09-24 VID-001三槽状态生产者草案

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 帧事件与三槽状态生产者 | `CODED_STATIC_MAP_14_OF_14_SIM_NOT_RUN` | RTL草案含每槽代数、故障和读复用；与C偏移14项静态匹配。需接顶层、AXI从设备、同域时钟与复位设计及RTL仿真 |
| VID-001 故障帧拒绝 | `HOST_13_AND_12_CHECKS_PASS_LIMITED` | 读取器增读故障位，防覆盖消费者在故障时拒绝开始/完成；仍无硬件状态来源或板测 |

## 2026-09-24 VID-001多字段状态读取增量

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 多字段状态软件读取器 | `CODED_HOST_10_CHECKS_PASS_LIMITED` | 候选ID/ABI及32位偏移合同、双读版本一致性和错误拒绝经严格主机编译通过；等待同布局PL寄存器/AXI从设备及Linux驱动 |
| VID-001 PS GP主口 | `OPEN_REFERENCE_GP_DISABLED` | 参考视频PS配置GP0/GP1均关闭；主工程启用但属另一系统。需隔离视频设计启用GP并验证地址、时钟、复位、总线响应与原子快照 |

## 2026-09-24 VID-001 PS故障位候选

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 AXI写故障至PS GPIO输入 | `CODED_STATIC_8_OF_8_NOT_BOARD` | 原PS包装模块的1位输入在参考生成顶层接0；隔离候选改接保护器故障位，8项静态检查通过。需RTL仿真、综合、实际bit与Linux GPIO回读 |
| VID-001 多字段完整帧状态通道 | `OPEN` | 单比特只能传故障，不能承载帧序号/槽号/代数；需隔离设计PS可读状态、原子快照及驱动与`frame_guard`联调 |

## 2026-09-24 VID-001 AXI写响应完成候选

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 FDMA写响应完整性 | `CODED_STATIC_BRIDGE_PASS_SIM_NOT_RUN` | 原core最后W握手即撤销busy且忽略B响应；隔离保护器与生成system端口候选10/10静态连线核查通过。下一门槛为延迟B/错误B/复位/连续帧RTL仿真、综合及PS故障状态 |

## 2026-09-24 VID-001设备树保留区候选

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 当前运行设备树固定帧槽核验 | `DONE_READONLY_NO_RESERVATION` | COM4回传20,480字节live FDT，板端/PC SHA相同；只有动态CMA，三块参考槽没有固定保留 |
| VID-001 固定地址帧槽DTB候选 | `CODED_OFFLINE_VERIFIED_NOT_BOOTED` | 隔离候选增加24 MiB `no-map`，解析与结构差异核验通过；需和实际bit/驱动/Cache/PS帧状态共同集成，审查启动内存图后才可考虑受控启动 |

## 2026-09-24 VID-001帧交接防覆盖增量

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 三槽CPU复制防覆盖判定 | `CODED_HOST_11_CHECKS_PASS_LIMITED` | 纯C状态快照、复位/同槽重写检查已通过严格主机编译和11项检查；需接入真正硬件状态生产者及Linux驱动，并验证总线写完成与Cache顺序 |
| VID-001 PS可读帧状态通道 | `OPEN` | 参考顶层没有PS可读状态；需要隔离设计中的寄存器/中断、跨时钟域、丢帧和复位验收；当前Linux DDR所有权仍`NO-GO` |

## 2026-09-24 离线原始帧输入增量

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| MODEL-001/VID-001 离线FDMA帧到空间ONNX | `PC_SYNTHETIC_PADDED_FRAME_TO_SPATIAL_ONNX_PASS_LIMITED` | 显式行步长/ROI/像素字节序的合成帧与直接PNG在RGB、FP32和128维特征逐字节一致；完整槽填充通过，截断文件拒绝。下一步必须从具有DDR所有权和完整帧交接的隔离设计采一帧真实IMX415图，实证字节序/裁剪/缓存后再板端运行 |
| VID-001 PS可读帧状态通道 | `OPEN` | 保存生成`system`只有FDMA→PS HP0内存接口，`uidbuf`完成IRQ和槽号在有效顶层未接PS；需要隔离集成中的PS状态/中断通道及丢帧、复位验证 |

## 2026-09-24 VID-001当前Linux内存门禁

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| VID-001 IMX415参考FDMA接入Linux | `NO_GO_CURRENT_LINUX_MEMORY_OWNERSHIP` | 保存顶层三槽`0x0A000000..0x0B7FFFFF`均落当前Linux System RAM、无对应保留区；写完成IRQ及缓存编号未接PS，当前无视频采集节点。先在隔离系统设计中解决DDR所有权、完整帧通知、Cache同步/防覆盖并绑定BOOT/bit/DTB，再验收原始帧；未运行参考bit |

## 2026-09-24 模型导出合同增量

| 项目 | 状态 | 证据与下一门槛 |
| --- | --- | --- |
| MODEL-001 模型导出预处理合同 | `PC_EXPORT_AND_REPLAY_CONTRACT_PASS_LIMITED` | 从冻结v2 checkpoint隔离重导出，ONNX字节哈希与旧版相同，新清单显式记录RGB/缩放/FP32归一化/224×224；回放376帧/12事件与前轮事件类别帧位一致。旧清单必须显式配置，错误尺寸在输出前拒绝。下一门槛为摄像头逐像素输入、独立手语者评估与板端实时链路 |

## 2026-09-24 模型连续回放完整复测

| 项目 | 状态 | 当前证据与下一门槛 |
| --- | --- | --- |
| MODEL-001 对齐后12段公开数据回放 | `PC_RERUN_PASS_EVENT_CHANGE_LIMITED` | 隔离环境完整运行376帧/12事件；弱标签相符数旧10/12、新9/12，仅第9段预测与出事件帧改变；288帧Pillow/OpenCV RGB解码一致。仍需真实手语者独立评估、动作边界/拒识及摄像头输入，9/12不是产品准确率 |
| H1板端运行条件只读复核 | `NO_GO` | COM4原Linux实读模块为空、Hard/Soft/CMA设备节点缺失、U盘未挂载；未加载模块或运行硬件 |

## 2026-09-24 模型连续回放输入增量

下表保留首次黄金核对的历史状态；完整回放的当前状态见上表。

| 子任务 | 状态 | 验收与下一门槛 |
| --- | --- | --- |
| MODEL-001 训练与连续回放逐帧预处理统一 | `CODED_PC_GOLDEN_EXACT_16_OF_16_LIMITED` | 共享Pillow RGB双线性缩放和FP32归一化；冻结真实视频16帧与原黄金张量逐元素完全相等。当前工具环境缺OpenCV/ONNX Runtime，修改后的完整回放未运行；真实摄像头输入、动作边界与精度仍`OPEN` |

## 2026-09-24 视频/显示demo身份增量

| 子任务 | 状态 | 验收与下一门槛 |
| --- | --- | --- |
| VID-001/DISP-001 参考demo选定文件清单 | `DONE_READONLY_INVENTORY_LIMITED` | 15项SHA-256、保存顶层和P&R报告已清点；原工程对应15项哈希一致。根BOOT内有完整`fdma_en.bin`，但两份BOOT与两种bit版本不能合并 |
| DISP-001 用户实际显示组合绑定 | `OPEN / IDENTITY_UNKNOWN` | 需要实际使用的BOOT哈希和准确面板型号，再核对bit/固件/源码；旧BIF外部绝对路径且缺FSBL，不能证明现存BOOT的分区身份 |
| VID-001/DISP-001 产品迁移 | `OPEN` | 待组合身份闭合后在隔离副本迁移并验收真实帧、显示、复位和长稳；本轮未构建或板测 |

## 2026-09-23 H1运行模式只加载实读增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-04 厂家模式对象板端只加载读取 | `TARGET_VENDOR_LOAD_MODE_1_DEVICE_BLIND_LIMITED` | 同哈希库在空设备私有根只加载后`run_npu_in_dma_mode=1`，`dlsym/dladdr`归属通过，监督器零拒绝/零异常；五项负探针仍获`EPERM`。载荷/模型构造及真正`Execute`时的值仍`UNKNOWN` |
| H1-04 packet-DMA真实提交及首算 | `NO_GO` | 未执行提交；pkg_info真实地址/字数、DMA/Cache、IRQ/超时停止、当前bit和独立驱动合同仍未闭合 |
| H1-04 实捕packet字数到`pkg_info+0x10`的静态桥接 | `STATIC_COUNT_BRIDGE_PASS_LIMITED` | 同哈希驱动指令从vector首尾字节差右移2位写字数；实捕520字节对应130字。没有真正到达该store，实际`pkg_info`值仍`UNKNOWN` |

## 2026-09-23 H1厂商模式与packet-DMA静态分支增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-04 Execute模式选择/静态默认 | `STATIC_DEFAULT_DMA_MODE_1_LIMITED` | 同哈希ELF导出`run_npu_in_dma_mode`初值1，GOT和Execute条件分支已复核；运行时值未捕获，真实Execute未调用 |
| H1-04 packet-DMA提交序列 | `STATIC_DMA_SUBMIT_SEQUENCE_PASS_LIMITED` | 8次写调用的偏移、常量和pkg_info来源逐指令核对；包物理地址/长度实际值、DMA访问、完成IRQ和停止恢复未验证，设备启动仍`NO_GO` |

## 2026-09-23 H1实捕包normal-mode偏移审计增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-04 重放偏移与前置写交叉核对 | `STATIC_REPLAY_EXPANSION_PASS_LIMITED` | 实捕13项离线展开为104个payload写调用参数；5个包内重复偏移及`0x0050`与前置控制值的顺序重叠已列出。`Execute`尚未调用，实际normal/packet-DMA模式未知；寄存器别名、副作用、DMA和独立安全驱动仍`NO_GO` |

## 2026-09-23 H1真实厂家软件packet捕获增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-03 厂家workload构造 | `TARGET_REAL_VENDOR_CONSTRUCTOR_PASS_DEVICE_BLIND_LIMITED` | 冻结前缀派生载荷在目标保护页中调用同哈希厂家构造函数并返回；无driver调用；tripwire负测试和精确规则通过 |
| H1-03 冻结v2真实厂家软件packet | `VENDOR_PACKET_CAPTURED_DEVICE_BLIND_LIMITED` | 完整载荷直接进入`r_HardNPUDriver`并由厂家packer截获mode-0的13项/130字；原始日志已保存，独立验证packet编码及bias夹具一致。未做parser/Optimize无桩ownership或硬件提交 |
| H1-03 静态预测纠偏 | `STATIC_ORACLE_FALSIFIED_AND_LOCALIZED` | 原12项/127字遗漏`0x5040`一字（值`0x00611118`）；剩余12项一致。冻结静态包不改，新的实捕报告为审查依据；该差异不得默默并入硬件白名单 |
| H1-02 捕获隔离 | `PASS_BOUNDED_CAPTURE_PROBES / FULL_EQUIVALENCE_OPEN` | 精确默认拒绝下捕获零拒绝/异常退出；合成设备tripwire和五项负探针通过。目标seccomp仍`EINVAL`，ptrace原型不是通用等效门禁 |
| H1-04/H1-05/H1-06 驱动、动态基址、硬件首算 | `NO_GO` | 缺无桩Alnpu分区、真实pkg_info物理地址与权重布局、DMA/Cache/IRQ/停止合同、独立安全驱动、当前bit身份和单独硬件放行；不得回放含`0x1004=1`的捕获包 |

## 2026-09-23 H1构造前预检增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-03 冻结Conv夹具板端读取和派生载荷构造前路径 | `TARGET_FIXTURE_AND_PRECONSTRUCTOR_PREFLIGHT_PASS_LIMITED` | 三份冻结张量哈希一致；派生源码保留冻结前缀，在厂商构造函数调用前返回；目标端句柄槽位、描述符校验、保护页和构造函数符号解析通过。没有真实workload或packet |
| H1-02 预检专用精确规则 | `PASS_TARGET_PREFLIGHT_ALLOWLIST_LIMITED` | 派生载荷和三份fixture仅精确只读路径放行；目标运行零拒绝/零异常退出，五项负探针均得`EPERM`。仍不是完整捕获隔离门禁 |
| H1-03 真实workload/packet和H1-04～H1-06 | `NO_GO` | 下一验收须独立审计厂商构造/driver的系统调用、内存及tripwire闭包，再取得真实packet合同；硬件首算仍待独立放行 |

## 2026-09-23 H1载荷只加载增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-03 冻结v2载荷`dlopen`与入口符号 | `TARGET_PAYLOAD_LOAD_AND_SYMBOL_PASS_LIMITED` | 目标隔离根下`RTLD_NOW`加载同哈希厂家库和v2载荷，`dlsym/dladdr`确认入口；载荷函数没有调用 |
| H1-02 载荷只加载规则 | `PASS_TARGET_PAYLOAD_LOADONLY_ALLOWLIST_LIMITED` | 在厂家规则上仅扩充载荷精确只读路径及`PR_GET_NO_NEW_PRIVS`，目标只加载零拒绝通过；五项负探针与厂家原规则回归通过。未审计fixture、厂家构造或完整捕获调用面 |
| H1-03 真实workload/packet | `NO_GO / NOT_CAPTURED` | 需要独立软件捕获规则、tripwire和真实entry/packet证据；本轮只有加载与符号解析 |

## 2026-09-23 H1 load-only调用面收敛

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-02 当前load-only系统调用审计 | `DONE_TARGET_TRACE_LIMITED` | 114次入口/22种号、17个精确只读`openat`路径；该计数只覆盖一次成功load-only运行，未覆盖payload或workload |
| H1-02 load-only默认拒绝模式 | `PASS_TARGET_LOADONLY_ALLOWLIST_LIMITED` | 修正身份调用漏列后，厂家load-only零拒绝通过；负探针五个操作均得`EPERM`，原19项默认门禁和`openat2`单独重试通过。不能推广为完整seccomp等效或捕获规则 |
| H1-03 真实载荷软件捕获 | `NO_GO / NOT_CAPTURED` | 必须为载荷、fixture和厂家构造建立独立审计与隔离规则，再谈真实entry/packet |

## 2026-09-23 H1厂家load-only门禁增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-03 冻结门禁源码目标编译 | `TARGET_BUILD_PASS_WITH_LINK_CLOSURE` | 源码哈希匹配；`-U_GNU_SOURCE`消除编译器重复宏；显式链接`libpthread.so.0`后门禁产物AArch64构建通过。此改动只在`/run`编译参数中，未改冻结源 |
| H1-03 厂家库load-only | `PASS_DEVICE_BLIND_LIMITED` | 私有根空`/dev`、降权、FD关闭、监督器下返回成功并核对packer偏移`0x401b10`；无载荷`dlopen`、workload、packet或硬件。完整隔离仍`PARTIAL` |

## 2026-09-23 H1隔离系统调用覆盖增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-02 `openat2`及不可读路径 | `GAP_REPRODUCED_AND_FIXED_LIMITED` | 旧监督器允许私有普通文件`openat2`；修正版返回`EPERM`，不可读`openat`路径触发125终止，原19项负探针仍PASS。其它系统调用变体、别名、异常与并发路径未穷尽 |
| H1-02 等效隔离 | `PARTIAL / NO_FULL_GATE` | 两项缺口修复不等于seccomp完整等效；当前禁止真实workload/packet捕获 |

## 2026-09-23 H1原生载荷目标构建增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-03 冻结native-v2载荷AArch64构建 | `TARGET_BUILD_PASS_LIMITED` | 源码/支持头哈希与冻结输入一致；板端`/run`严格编译退出0，ELF64 AArch64、导出入口、BIND_NOW/GNU_RELRO和厂家主库哈希均核对。尚未加载或执行载荷 |
| H1-03 厂家真实entry/packet | `NO_GO / NOT_CAPTURED` | 当前隔离监督器仍仅部分验证；未完成载荷加载/调用、真实workload和packet审计，不能把构建或独立槽位自检提升为真实捕获 |

## 2026-09-23 H1目标ABI与平台资源增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-03 派生句柄`GetPhyAddr`目标槽位 | `TARGET_VTABLE_SLOT_PASS_LIMITED` | AArch64板端独立自检的四个哨兵均经`vtable[15]`返回；完整native-v2载荷和厂家调用仍`NOT_RUN`，不计真实地址、packet或DMA证据 |
| H1平台资源身份 | `LIVE_DT_RECONFIRMED_LIMITED` | 当前live DT有Hard三段资源及SPI112、无Soft节点；只读80MHz候选DTB含相同Hard及Soft资源。当前bit身份、驱动绑定及运行时闭包仍`UNKNOWN` |
| H1-03～H1-06 | `NO_GO` | 真正厂家workload/packet、受控独立驱动、DMA/IRQ、停止恢复和Hard Conv首算仍未验证 |

## 2026-09-23 H1 runtime入口增量

| 子任务 | 状态 | 目标实证与下一门禁 |
| --- | --- | --- |
| H1-02 Hard驱动初始化入口 | DONE_TARGET_SYSCALL_SEQUENCE_LIMITED | 私有普通文件只读时`openat(O_RDWR)=-EROFS`；仅`/run`可写普通文件时返回FD 3，下一步`ioctl 0x4801`被监督器拒绝，runtime失败。与公开`GET_REGISTER_INFO`相符；未得到真实资源地址/长度或映射 |
| H1-02 功能性Alnpu runtime | BLOCKED_BY_REAL_DRIVER_ABI | 真实Hard/Soft/CMA驱动及安全映射契约均未建立；条件factory注册不可提升为功能性runtime |
| H1-03～H1-06 | NO_GO | 无真实workload、packet、寄存器白名单、DMA/IRQ/停止恢复或Hard首算证据；不得把普通文件或软件桩当硬件 |


## 2026-09-23 H1直接factory对照增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-02 Alnpu静态注册条件 | DONE_TARGET_CONDITIONAL_REGISTRATION | 同一厂家库在路径缺失/私有普通文件占位时直接factory表`3→4`、`Alnpu no→yes`；这是注册机制，不是功能性设备backend |
| H1-02 runtime初始化 | BLOCKED_BY_DRIVER_OPEN | 私有regular-file占位下既有runtime探针报告无法打开HardNPU驱动；不得将factory存在提升为Optimize/workload可用 |
| H1-02 继承FD和设备名负门禁 | PASS_NEGATIVE_LIMITED | pre-exec关闭FD≥3，目标核查3～4095均关闭；空`/dev`和私有普通文件占位两种配置均通过，ioctl/共享mmap仍被拒绝；完整等效隔离继续PARTIAL |
| H1-03～H1-06 | NO_GO | 真实workload/packet、独立驱动、DMA/IRQ与Hard首算均未执行 |


## 2026-09-23 H1隔离原型增量

| 子任务 | 状态 | 验收与剩余门禁 |
| --- | --- | --- |
| H1-02 AArch64 ptrace系统调用改写 | PROTOTYPE_PASS_LIMITED | 无害`getpid`改写后观察`ENOSYS`；仅证明当前内核的寄存器接口可用 |
| H1-02 私有根负门禁 | PARTIAL / NEGATIVE_PROBES_PASS | 原19项负探针、fork/pthread各4项、再次exec阻断通过；继承FD、挂载别名、全部系统调用变体及异常并发路径未审计，不能标等效隔离PASS |
| H1-03真实厂家路径及H1-04～H1-06 | NO_GO | 没有借实验监督器启动厂家库或硬件；待完整隔离和真实backend/packet契约后重新审查 |


## 2026-09-23 板端只读复测增量

| 子任务 | 状态 | 新鲜证据与下一门禁 |
| --- | --- | --- |
| H1目标身份和运行库 | DONE_READONLY_LIMITED | COM4确认Ubuntu 20.04.1 / `6.1.111-rt42`，无NPU/CMA模块与节点；三份厂家库哈希与冻结输入匹配，U盘未挂载、根分区`rw`。文件时钟错误，不能依赖mtime |
| H1-02 seccomp/等效隔离 | BLOCKED / SECCOMP_EINVAL_REPRODUCED | 既有最小允许filter探针本次返回EINVAL；`bwrap`存在但未通过等效负门禁，不提升`PARTIAL_DEVICE_BLIND`。下一动作是隔离环境实现和负门禁，不在当前根分区运行真实workload |
| H1-02 无桩backend ownership | BLOCKED / FACTORY_NOT_REGISTERED | 既有目标registry日志为`ALRef/CpuAcc/CpuRef`、`alnpu_registered=no`；typed-stub分区只保留软件对照。需先恢复有证据的真实注册与完整隔离 |
| H1-03～H1-06 | NO_GO | 本次没有厂家库运行、workload、packet、驱动或Hard首算；地址/DMA/IRQ/生命周期门禁未变 |


## 2026-09-23 H1只读接管：factory注册原因收敛，硬件门禁未变

| 子任务 | 状态 | 证据与下一验收 |
| --- | --- | --- |
| H1包接管核验 | DONE_LISTED_HASHES / INCOMPLETE_DIRECTORY_SEAL | 六包最终清单内分别148/148、265/265、251/251、182/182、149/149、10/10匹配；重定位包85个`__pycache__`与stub包3个后增文件不在最终清单，不能声称目录整体封存完整；冻结包保持只读 |
| H1-02 Alnpu factory恢复 | PARTIAL_STATIC_CAUSE_IDENTIFIED | 冻结库`0x3b3e10`的静态注册器先`lstat(/dev/hard_npu)`，ENOENT/ENOTDIR跳过`Register`；设备遮蔽下失败与普通文件占位下桩化成功相符。下一验收：在完整无设备直通隔离中验证注册分支、准确运行库闭包及真实支持判断；占位只记条件软件结果 |
| H1-02 等效隔离 | OPEN / NO_EQUIVALENT_GATE_PROVEN | seccomp `EINVAL`仍阻塞；现有板端namespace/降权门禁只`PARTIAL`。需独立AArch64无设备直通环境或经负探针证明的等效系统调用限制，先于真实workload |
| H1-03 真实workload/entry/packet | NO_GO / NOT_CAPTURED | 当前只有CPU、parser、静态oracle和stub分区；不从stub或静态127-word预测提升。等注册、隔离和真实backend证据闭合后再捕获并逐项审查 |
| H1-04～H1-06 独立驱动与真实首算 | NO_GO | 动态地址、DMA范围、寄存器白名单、padding/scratch、IRQ和失败保留未闭合；无本轮硬件授权或执行 |

详细可证伪条件见`docs/research/HARDNPU_H1_BACKEND_FACTORY_AUDIT_20260923.md`。NPU-001原状态不因只读分析改变。

## 2026-09-22 H1-03 增量：桩化厂家路径准备

| 子任务 | 状态 | 优先级 | 当前证据与下一验收 |
| --- | --- | --- | --- |
| H1-03-STUB 软件门禁变体 | DONE_SOFTWARE_PREPARATION_LIMITED | P1 | 主机语法通过；板端私有命名空间的 typed-stub parser/Optimize 已观察到唯一 `ALHardNPU`/`Alnpu` 分区；未证明真实 backend、workload、packet 或硬件，故不提升真实 H1-03 状态 |
| H1-03-TARGET 传输与原生运行 | BLOCKED_BY_TARGET_TRANSFER | P0 | 电脑当前未枚举 COM/UART；恢复一次性传输后，需在目标私有命名空间完成 AArch64 build、stub run 和原始日志封存；不得进入硬件首算 |

## 2026-09-22 HardNPU H1目标端门禁与Optimize阻塞

| 子任务 | 状态 | 优先级 | 当前证据与下一验收 |
| --- | --- | --- | --- |
| H1-02 AArch64目标构建 | DONE_TARGET_BUILD_LIMITED | P0 | 板端私有目录生成launcher、负探针、Arm NN探针和capture gate；`SYS_close_range=436`为目标头文件兼容定义；产物哈希及命令记录在`docs/records/worklog/2026-09/2026-09-22-sol-hardnpu-h1-target-gates.md` |
| H1-02 完整隔离门禁 | PARTIAL / SECCOMP_UNAVAILABLE | P0 | namespace、空`/dev`/`/sys`/`/proc`、降权、capability清零、no-new-privs和FD关闭已观察；原始launcher及独立最小seccomp探针均返回`EINVAL`，必须恢复seccomp或等效系统调用门禁后才能宣称PASS |
| H1-02 loader self-test | DONE_TARGET_LIMITED | P0 | 修正`-rdynamic`后interpose观察值41；首次错误构建结果保留为失败记录，不纳入最终通过 |
| H1-02 厂家库load-only | PASS_DEVICE_BLIND_LIMITED | P0 | 在降级设备遮蔽变体中返回`PASS_DEVICE_BLIND`，`hardware_execution=NOT_RUN`；不等同于完整隔离，也不等同于后端注册或硬件执行 |
| H1-03 ONNX parser | PASS_TARGET_PARSER_LIMITED | P0 | 冻结模型在目标AArch64环境生成`parser_bindings.json`、`original_layers.json`和常量文件；目标Conv形状/量化与夹具一致 |
| H1-03 Optimize/partition/backend ownership | BLOCKED / ALNPU_FACTORY_MISSING | P0 | `Optimize([Alnpu])`报告`Alnpu has no IBackend factory registered`；当前运行库目录未发现独立Alnpu backend共享库；下一验收是恢复匹配的backend注册闭包并重复设备遮蔽验证 |
| H1-03 真实entry/packet捕获 | NO_GO / NOT_RUN | P0 | 由于Optimize和workload路径未闭合，未捕获真实Hard entry、packet、重定位、权重布局、DMA范围或scratch；不得套用Soft packet或静态预测 |
| H1-04 独立Hard驱动 | NO_GO | P0 | 等待真实Hard packet和完整DMA/IRQ/超时/缓冲生命周期契约；公开驱动不得原样加载 |
| H1-05/H1-06 Hard Conv首算 | NO_GO | P0 | 未取得Alnpu分区、真实packet和完整隔离证据，不得上板启动HardNPU |

NPU-001仍为`DOING/P0`。SoftNPU第二尺寸Pool的`BOARD_PASS_LIMITED`保持不变；HardNPU H1当前不是硬件失败，而是目标端运行库闭包和隔离能力尚未闭合。

## 2026-09-21 SoftNPU第二尺寸参数化闭环

| 子任务 | 状态 | 优先级 | 当前证据与下一验收 |
| --- | --- | --- | --- |
| Soft Pool参数编码恢复 | DONE_STATIC_AND_PC_LIMITED | P0 | 独立软件门禁闭合20/20参数、16/16厂家反汇编、36/36静态安全、162/162状态机、21/21 trace、15/15 UAPI；限定Max/NCHW/UINT8/zero-pad/方形kernel/同stride |
| v0.6.0目标构建 | DONE_TARGET_BUILD_PASS_LIMITED | P0 | 匹配`6.1.111-rt42 preempt`；模块/探针SHA分别为`3f49b6e5...83a5`、`564013df...16b`；缺Module.symvers等警告保留，非发布构建 |
| 第二尺寸PREPARE-only | DONE_BOARD_PREPARE_LIMITED | P0 | 新分配三缓冲、包/输入/哨兵/guard、地址对齐和零旧IRQ共21/21；未start实例安全卸载 |
| 第二尺寸normal-DDR单次RUN | DONE / BOARD_PASS_LIMITED | P0 | `[1,1,4,6] -> [1,1,2,3]`精确金样、三块完整dump、guard、严格NN IRQ及21条trace通过；只运行一次、无重试；软件Power down后用户于2026-09-22确认物理断电，冷恢复完成；证据35项清单逐项通过，清单SHA=`f94a2eda...e276f` |
| Soft packet-DMA/更多shape/通用Pool ABI | OPEN / DEFERRED | P1 | 本轮未授权也未执行；需新的参数、写回容量、DMA/IRQ/停止和生命周期契约 |
| HardNPU H1 | DOING / 见下方最新H1表 | P0 | 本次Soft结果不改变H1 parser/partition/packet/重定位/独立驱动与首算门禁 |

NPU-001保持`DOING/P0`，因为HardNPU、真实模型与产品链仍未完成。只有“第二尺寸Soft Pool normal-DDR参数化实验”按限定证据闭环；不得写成通用SoftNPU实现完成。

## 2026-09-21 Sol H1-03重定位与native v2更新

新增封存包 `hardnpu_h1_relocation_contract_20260921_1`（182/182，清单SHA-256=`e5bc0c1b23e78ee04db700ca477b8ae4cd892d7aa8c5c316b2bdfbfbb89d296f`）和 `hardnpu_h1_native_capture_v2_20260921_1`（输入114/114、最终149/149，清单SHA-256=`b1267e0f323239b9a7cb163b05ccb3f453d1897d8d2bc0d0e25048fd45156f20`）。旧plain `PassthroughTensorHandle` payload因缺少已证明的隐藏`GetPhyAddr`槽被否决为native-ready；v2只获得PC语法、静态安全、厂家边界和host对象ABI限定通过，尚无AArch64或厂家运行证据。

新版一次性传输包位于`F:/My_proj/_isolated_builds/hardnpu_h1_native_gate_transfer_20260921_3/`；三归档源与解包后的内部清单均通过，目录7/7，清单SHA-256=`1d05b4438090567d38dfb09d63a9c29ae0c2b0a54baf635c785920e7519bb9f4`。状态仅`READY_FOR_AARCH64_DEVICE_BLIND_SOFTWARE_GATES`。

| 子任务 | 状态 | 当前证据与下一验收 |
| --- | --- | --- |
| H1-01 单层冻结与CPU语义 | DONE_PC_LIMITED | 冻结诊断夹具不变；产品预处理/训练一致性另行修复 |
| H1-01 库加载前隔离 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 原生目标依次证明loader抢占、namespace/设备遮蔽、fd、权限、capability和seccomp |
| H1-02 parser/Optimize/分区 | CODED_HOST_SYNTAX_PASS_NOT_RUN | 设备遮蔽目标运行，记录真实backend ID、partition、内部类型、唯一ALHardNPU及无CPU/ALRef回退 |
| H1-03 entry形状与动态基址 | DONE_STATIC_CONTRACT_LIMITED | 12项/127-word预测不含`0x2000/0x2004/0x6000`动态基址；真实pkg_info和DMA范围仍UNKNOWN |
| H1-03 v2真实载荷捕获 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 先AArch64构建和`vtable[15]`哨兵自检，再运行设备遮蔽capture；需取得真实entry/packet，不能把host ABI当目标通过 |
| H1-04 独立驱动 | OPEN / NO_GO_PENDING_RUNTIME_PACKET | 公开驱动不得原样复用；等待真实packet、最终重定位、DMA/IRQ/timeout/生命周期契约 |
| H1-05 一次Hard normal Conv | OPEN / BLOCKED_BY_H1_CONTRACT | 未单独放行，不执行HardNPU |

NPU-001保持`DOING/P0`。总状态更新为`GO_FOR_TARGET_BUILD_AND_DEVICE_BLIND_GATES_ONLY / HARDWARE_NO_GO_PENDING_H1_CONTRACT`，推荐任务未自动标记为DOING。

## 2026-09-21 Sol H1-03冻结payload entry契约更新

新增封存包 `F:/My_proj/_isolated_builds/hardnpu_h1_entry_contract_20260921_1/`，最终清单251/251，清单SHA-256=`e90e48307f99a7169f850138bef75ccbfeac5bc4f3c84dc1c87ee09cb069f518`。冻结形状的output split `[0,63]`和单tile路径已由静态算术闭合；正确H1量化分支为`QAsymmU8=2`，预测单包12项/127 words/508字节。真实原生捕获仍未运行，该预测不是寄存器白名单或BOARD证据。

新版一次性传输包位于 `F:/My_proj/_isolated_builds/hardnpu_h1_native_gate_transfer_20260921_2/`，把offline、capture和entry oracle三包合并；归档3/3、目录6/6通过，清单SHA-256=`febeabb097d97637a131ee75cc54d9ee6d945f019446c580e184924a7c53ac1e`。状态仅`READY_FOR_DEVICE_BLIND_SOFTWARE_GATES_ONLY`。

| 子任务 | 状态 | 当前证据与下一验收 |
| --- | --- | --- |
| H1-01 单层冻结与CPU语义 | DONE_PC_LIMITED | 冻结模型及诊断语义不变；产品预处理/训练一致性另行修复 |
| H1-01 库加载前隔离 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 原生目标先通过loader、namespace、设备遮蔽、fd、权限、capability及seccomp门禁 |
| H1-02 parser/Optimize/分区 | CODED_HOST_SYNTAX_PASS_NOT_RUN | 设备遮蔽目标运行；证明真实Alnpu分区、唯一ALHardNPU及无CPU/ALRef回退 |
| H1-03 entry形状静态契约 | DONE_STATIC_PREDICTION_LIMITED | 纠正type-6误判；H1预测12项/127 words，等待真实捕获逐项证伪 |
| H1-03 真实载荷捕获 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 获取真实entry、packet、寄存器值、重排常量及重定位；任何预测差异即NO-GO |
| H1-04 独立驱动 | OPEN / NO_GO_PENDING_RUNTIME_PACKET | 公开驱动不得复用；等待真实packet、DMA、IRQ、超时停止及生命周期契约 |
| H1-05 一次Hard normal Conv | OPEN / BLOCKED_BY_H1_CONTRACT | 未单独放行，不执行HardNPU |

NPU-001保持 `DOING/P0`。总状态仍为 `GO_FOR_DEVICE_BLIND_NATIVE_GATES / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。

## 2026-09-21 Sol H1-03静态packet ABI更新

新增封存包 `F:/My_proj/_isolated_builds/hardnpu_h1_packet_abi_20260921_1/`，最终清单265/265，清单SHA-256为 `ff6ab241e172e876e8c1ba2a327ac05d520d3084e2afeaf96ede4e4830b90d47`。静态指令断言29/29、公开驱动缺口门禁14/14、有界codec 4111项检查通过；没有加载厂家库、没有目标端parser/Optimize、没有真实H1 packet或硬件执行。

目标传输包已准备在 `F:/My_proj/_isolated_builds/hardnpu_h1_native_gate_transfer_20260921_1/`，4/4清单SHA-256=`d0aba4aa2178185793048f9a8c6abd13a646dd304ec787fb0a73dbb03d36fdf2`；仅含两个已核验用户态源/证据归档。当前Windows无COM枚举，故“传入板端并执行设备遮蔽门禁”保持OPEN，未自动标为完成。

| 子任务 | 状态 | 当前证据与下一验收 |
| --- | --- | --- |
| H1-01 单层冻结与CPU语义 | DONE_PC_LIMITED | 冻结对象不变；诊断夹具与产品预处理/训练一致性分开修复 |
| H1-01 库加载前隔离 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 目标端必须先通过namespace、设备遮蔽、fd、权限、capability及seccomp门禁 |
| H1-02 parser/Optimize/分区 | CODED_HOST_SYNTAX_PASS_NOT_RUN | 目标隔离下证明实际Alnpu分区、唯一ALHardNPU及无CpuRef/CpuAcc/ALRef回退 |
| H1-03 packet格式与基础组 | DONE_STATIC_LIMITED | 已恢复entry/list ABI、mode 0编码和7组pre-special快照；这些不是最终packet或硬件白名单 |
| H1-03 真实载荷捕获 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 依次通过目标构建、loader自测、负门禁、load-only后，才捕获真实ctor/driver至packer；entry、常量、relocation、workspace仍UNKNOWN |
| H1-04 独立驱动 | OPEN / NO_GO_PENDING_RUNTIME_PACKET | 公开驱动确认不可原样复用；等待最终packet、DMA范围、寄存器白名单、IRQ/超时/生命周期契约 |
| H1-05 一次Hard normal Conv | OPEN / BLOCKED_BY_H1_CONTRACT | 未单独放行，不执行HardNPU |

NPU-001保持 `DOING/P0`。总状态为 `GO_FOR_DEVICE_BLIND_NATIVE_GATES / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。

## 2026-09-21 Sol H1-03真实载荷捕获器更新

新增独立封存包 `F:/My_proj/_isolated_builds/hardnpu_h1_packet_capture_20260921_1/`：103项输入与来源哈希一致，最终133项逐项复核通过，清单SHA-256为 `9cf1eaa45918f2b6a2560e812242fd886b5065aa9b117aed2db5821242441d9a`。PC语法4/4、静态安全门禁34/34、厂家调用边界14/14通过；没有AArch64目标构建、厂家库加载、真实packet或硬件运行。

| 子任务 | 状态 | 当前证据与下一验收 |
| --- | --- | --- |
| H1-01 单层冻结与CPU语义 | DONE_PC_LIMITED | 保留原冻结诊断夹具；预处理/训练一致性另修，不改变首个Hard诊断对象 |
| H1-01 库加载前隔离 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 复用launcher/负探针；目标端必须先通过namespace、设备遮蔽、fd、权限、capability及seccomp门禁 |
| H1-02 parser/Optimize/分区 | CODED_HOST_SYNTAX_PASS_NOT_RUN | 目标隔离门禁通过后运行；真实绑定、唯一ALHardNPU、无CpuRef/CpuAcc/ALRef回退仍待证 |
| H1-03 静态调用边界 | DONE_STATIC_LIMITED | packer PLT调用 `0x3cc0d8`、mode=0、首次GetPhyAddr `0x3cc224`、非SYMBOLIC及752字节对象均已复核 |
| H1-03 安全真实对象/packet捕获 | CODED_PC_GATES_PASS / TARGET_NOT_RUN | 先目标构建、loader自测、负门禁、load-only；再运行真实ctor/driver至packer hook。packet、entry、重排常量、relocation/workspace仍UNKNOWN |
| H1-04/H1-05 | NO_GO | 捕获后仍须闭合寄存器白名单、DMA地址/长度/对齐/padding/生命周期、IRQ及超时停机；未单独放行前不得执行HardNPU |

NPU-001保持 `DOING/P0`。总状态为 `GO_FOR_NATIVE_DEVICE_BLIND_GATES / HARDWARE_NO_GO_PENDING_H1_CONTRACT`；编码完成不等于H1-03完成。

## 2026-09-21 Sol H1离线实施更新（H1-03编码前历史快照）

H1已按用户明确指令领取。新隔离根 `F:/My_proj/_isolated_builds/hardnpu_h1_offline_20260921_1/` 的123项冻结输入复核123/123，CPU语义复核为 `CPU_GOLDEN_PASS_LIMITED`；148项最终包清单复核148/148，清单SHA-256 `89dfdb8bb2630636cc68d542b344263b172f4d0d237a3cd123f4c4cd595f99f5`。隔离launcher、负探针和parser/Optimize探针已编码，静态门禁31/31；Arm NN探针主机C++17严格语法检查通过，但原生AArch64构建/负门禁/厂家parser/Optimize均未运行。Hard packet生成早于观察到的物理地址/CMA/Acquire调用只获静态确认，不等于安全捕获接口或真实packet。

| 子任务 | 当前状态 | 下一验收 |
|---|---|---|
| H1-01 单层冻结与CPU语义 | DONE_PC_LIMITED | 保留冻结诊断对象；产品预处理/校准另修，不改变首算夹具 |
| H1-01 库加载前隔离 | CODED_NOT_TARGET_RUN | 原生AArch64严格构建；先单独通过设备遮蔽、fd、权限、capability、seccomp负门禁，失败即不加载厂家库 |
| H1-02 parser/Optimize/分区 | CODED_HOST_SYNTAX_PASS_NOT_RUN | 负门禁通过后运行；记录真实绑定、优化层和DOT中的Alnpu归属；禁止CpuRef/CpuAcc/ALRef回退，Optimize不冒充workload |
| H1-03 静态调用边界 | DONE_STATIC_LIMITED | 已确认packet生成先于观察到的GetPhyAddr/CMA/Acquire；仍需证明可安全截断且析构无设备副作用 |
| H1-03 真实载荷捕获 | OPEN / NO_GO_PENDING_SAFE_OBJECT_PATH | 真实workload、entry/packet、重排权重/常量、tile/scratch、relocation和独立解码均未取得 |
| H1-04/H1-05 | NO_GO | H1-03契约闭合前不设计板端提交，更不执行HardNPU |

NPU-001保持`DOING/P0`。当前总状态为 `GO_FOR_DEVICE_BLIND_NATIVE_CPU_GATE / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。

## 2026-09-21 Astra方向决策（覆盖下面过期的首算等待状态）

审查 `DONE / EVIDENCE_REVIEW_ONLY`：v0.5.4 `BOARD_PASS_LIMITED(fixed Pool normal DDR)`获独立接受，板测清单15/15、三缓冲重新比较均0差异；21条为4 common、15 normal配置、1 NN start、1 IRQ clear。S0～S7不重跑。下一主线 **H1**；S8不是Hard首算前置，完整R1后移；当前Hard硬件仍NO-GO。详见根 `SOFTNPU_ASTRA_DIRECTION_REVIEW_20260920.md`，实际审查日期2026-09-21。

| 子任务 | 状态 | 优先级 | 下一交付与验收 |
|---|---|---|---|
| H1-01 单层语义与隔离边界 | SUPERSEDED_BY_SOL_UPDATE_ABOVE | P0 | 以本页最前实施状态为准 |
| H1-02 单层真实转换/分区 | SUPERSEDED_BY_SOL_UPDATE_ABOVE | P0 | 以本页最前实施状态为准 |
| H1-03 Hard实际载荷捕获 | SUPERSEDED_BY_SOL_UPDATE_ABOVE | P0 | 以本页最前实施状态为准 |
| H1-04 独立驱动与首算决策 | OPEN / RECOMMENDED | P0 | probe无副作用、固定ABI/Hard自有DMA、严格flag=1/work=5、超时保留；软件反例、目标构建及具体GO/NO-GO |
| H1-05 一次Hard normal Conv | OPEN / BLOCKED_BY_H1_CONTRACT | P0 | H1-04及单独板测放行后，一次真实提交/严格IRQ/完整输出与缓冲核对，冷恢复；本轮不授权、不执行 |
| S8 Soft packet-DMA/多输入 | OPEN / DEFERRED | P1 | 为Soft控制路径或后续算子集成提供覆盖，不代证Hard取包/权重/IRQ |
| R1 完整runtime集成 | OPEN / DEFERRED | P1 | 单层证据之后再适配双设备/CMA、全图分区和性能；必要的单层Optimize已纳入H1-02 |
| 模型质量/预处理对齐 | OPEN | P0（产品门禁） | 当前夹具仅诊断；修复训练/校准预处理差异、量化精度并独立词级评估，不能用单层正确关闭 |

NPU-001保持DOING。现有Hard夹具PC复核通过不提升厂家或硬件等级；本轮没有新增板测、Git操作、模型/RTL/bit/DTB修改。下文旧`WAITING_EXPLICIT_APPROVAL`及v0.3/S7隔离状态仅对应历史版本；以本节和v0.5.4正式结果为当前事实。

## 2026-09-20 traceable one-shot v0.5.4

- `DONE_NATIVE64_SURFACE_HARDENING`：移除未经 AArch32/真实 Linux ioctl 编码证明的 `.compat_ioctl`，INFO 明确 `NATIVE_64BIT_ONLY`，ABI `0x00010006`；首轮原生 AArch64 探针路径不变。
- `DONE_SOFTWARE_TESTS_ONLY`：状态机 162/162、追踪 21/21、静态门禁 35/35、native与主机 `-m32` 各15项布局编译断言、native探针语法检查通过。`-m32` 结果不重新放行 compat；硬件仍 `NOT_RUN`。
- `SUPERSEDES_V0.5.3_FOR_TARGET_BUILD`：下一目标构建只使用 v0.5.4 源码归档 SHA-256 `76591fc04e62c9563a59ecc77e945051616f6b0920fa048dfde3782127172a7c`；v0.5.3保持不可变历史证据。
- `DONE_TARGET_BUILD_PASS_LIMITED`：首次 RT defconfig 产物因 `preempt_rt` vermagic 被运行内核拒绝，未强制装载；在板端私有 SDK 副本内用普通 DR1M90 defconfig 干净重建后，模块 vermagic 匹配 `preempt`，模块/探针 SHA-256 分别为 `9ade02c508855b949dcba6708cc43d4f9867438638db3f5f8604612ee5c0f0a4`、`2e09c7f8f13fb3192153ea8e1349de158f67e7f2fec2fe7ea2448816e374076c`。缺 `Module.symvers`、modpost未解析符号和1104字节栈帧警告均保留，状态不是发布构建通过。
- `DONE_VOLATILE_JTAG_AND_IDENTITY`：用户明确授权后完成一次80MHz bit易失下载，TD芯片校验通过；未写Flash。原TF内核、临时DTB大小/CRC、reset/divider、Linux版本和实时设备树资源均匹配，JTAG工具进程已关闭。
- `DONE_DDR_PREPARE_PASS_LIMITED`：run gate关闭的INFO与唯一一次`prepare-only`通过；三块DDR缓冲对齐/独立/低4GiB，packet SHA、输入和非黄金输出初值匹配，IRQ前后为0，关闭后回到IDLE并安全卸载模块。没有start、MMIO提交、NPU运算或硬件输出。
- `WAITING_EXPLICIT_APPROVAL/P0 / READONLY_ROOT_RUN_ONCE`：若继续真实 fixed normal RUN，必须重新以 `rootfstype=ext4 ro init=/bin/bash` 启动并复核只读根、零旧IRQ、`pre_status=0`及新分配；用户需明确接受未知DMA边界、可能挂起及作业后无论成败都需物理冷恢复。不得在当前可写根直接运行。

隔离包31/31，`FINAL_SHA256SUMS.txt` SHA-256 `efe179ad17a90dfac2dd931aa8638e2955409976b349e0e87da8f99c81bf9e1f`。

## 2026-09-20 traceable one-shot v0.5.3

- `DONE_SOFTWARE_PASS`：封闭 wait 已返回超时、严格完成 IRQ 随后在停用窗口到达的竞态；超时后仍 RUNNING 记 `TIMEOUT`，已观察到严格完成记 `TIMEOUT_LATE_IRQ`，既有 `IRQ_ERROR` 保持不变，三者均隔离且不得验证输出。
- `SUPERSEDED_BY_V0.5.4`：v0.5.3保持不可变历史证据；其源码归档 SHA-256 `a9a75f2590ed52b3a0d11304159fd3630d238cae42b42eb0d6a534c3e7d323aa`，不得再作为下一目标构建候选。
- `DONE_SOFTWARE_TESTS_ONLY`：状态机 162/162、追踪 21/21、静态门禁 34/34、15 项 UAPI 编译期断言及探针语法检查通过。Windows 策略阻止新 UAPI EXE 启动，未绕过；目标 AArch64 构建和硬件执行仍 `NOT_RUN`。
- `DONE_SUBMISSION_SEQUENCE_AUDIT`：独立发射器与冻结厂家捕获逐笔比对 17/17；normal 后16笔和 packet helper 六笔完全一致，fixture packet 字节一致。packet-DMA 仍 NO-GO；`0x80c/0x100c=0` 的证据范围仍限候选 IP-XACT 和一次历史有限执行。
- `OPEN/P0 / TARGET_BUILD_NO_GO_NOW`：等待物理冷断电确认后在板端新私有目录目标构建；匹配 SDK 源码只证明 API 兼容性有限成立，不能替代 prepared kernel output。
- `OPEN/P0 / PREPARE_THEN_REVIEW`：目标构建通过后只做匹配 80MHz 身份和 run-gate-closed PREPARE；证据复审后才决定唯一一次 fixed normal RUN。packet-DMA、重试、其它输入/shape 和产品模型继续 NO-GO。

隔离包 31/31，`FINAL_SHA256SUMS.txt` SHA-256 `541a51cd296dde19e6901090a5b220624120a423ebec6c35e363825221dd3c89`。
提交序列审计包 20/20，`FINAL_SHA256SUMS.txt` SHA-256 `1efa66183e6d50857190e03ce65173fd6269f6e77c3aac6bc7b3e858ccf41629`。

## 2026-09-20 traceable one-shot v0.5.2

- `DONE_SOFTWARE_PASS`：补齐 enable-IRQ 至第一笔提交写窗口的早到事件隔离；严格 NN 早到变为 `EARLY_IRQ`，错误事件保留 `IRQ_ERROR`，均不再提交设备写。状态机 153/153、追踪 21/21、静态门禁 32/32、UAPI 布局 15/15。
- `SUPERSEDED_BY_V0.5.3`：v0.5.2 保持不可变历史证据；其源码归档 SHA-256 `e63df86a3cb65f1e9b5bc6089c745be0ff52f2e2a1fa9435108b9a5c74492feb`，不得再作为下一目标构建候选。
- `OPEN/P0 / TARGET_BUILD_NO_GO_NOW`：等待物理冷断电确认后在板端新私有目录目标构建；当前 `NOT_TARGET_BUILT/NOT_HARDWARE_RUN`。
- `DONE_SOURCE_API_AUDIT_LIMITED`：找到精确 6.1.111 + `-rt42` SDK 源码，v0.5.2 所用关键 API 签名/导出均存在，RT/module/CMA defconfig 条件成立。归档不是 prepared output tree，仍缺实际 `.config`/generated headers/`Module.symvers` 和本机 Linux/AArch64 工具链，不能替代目标构建。
- `OPEN/P0 / PREPARE_THEN_REVIEW`：构建通过后先做匹配 80MHz 身份和 run-gate-closed PREPARE，另行审查才决定唯一一次 fixed normal RUN。packet-DMA、重试和其它模型继续 NO-GO。

隔离包 27/27，`FINAL_SHA256SUMS.txt` SHA-256 `3fb1c718373b7ebcc363c3ef4934cb22412eb884fe78030a5a9832cc80047bea`。
匹配内核 SDK/API 审计包 15/15，`FINAL_SHA256SUMS.txt` SHA-256 `4b49b73ffff305cdcd19534a224a061b33463844ecb856416b0262386d20b638`。

## 2026-09-20 traceable one-shot v0.5.1

- `DONE_CODED_PC_ONLY`：隔离 v0.5.1 ABI `0x00010003` 已实现 20 次提交写及严格 NN IRQ 清除写的有界顺序/阶段/单调时间追踪；所有 `writel` 集中到唯一记录入口。
- `DONE_SOFTWARE_PASS`：状态机 143/143、追踪契约反例 21/21、静态门禁 31/31，失败均为 0；MinGW 用户探针语法检查通过。只能记软件通过。
- `DONE_PC_UAPI_AUDIT_LIMITED`：64 位主机固定结构布局 15/15，result/dump 为 1096/4112 字节；v0.3→v0.5.1 驱动差异已冻结。AArch64/ioctl/符号/vermagic 仍未确认，不能关闭 S4。
- `DONE_LIFECYCLE_HARDENING`：任何可能 start 的作业，即使数值成功，也保留三块 coherent 缓冲并自锁模块至物理冷恢复；仅 never-started PREPARE 可清理。
- `OPEN/P0 / TARGET_BUILD_NO_GO_NOW`：本机未找到匹配 `6.1.111-rt42` 的 kernel output tree，WSL 不可用；v0.5.1 尚未目标构建。物理冷断电确认后，在板端新私有目录实读 kernel/compiler/`Module.symvers` 后构建，保存完整日志、哈希与 vermagic。
- `OPEN/P0 / PREPARE_AFTER_TARGET_BUILD`：目标构建通过后恢复已核验 80MHz bit/临时 DTB，只以关闭 run gate 的方式执行 `info` 和 `prepare-only`，验证新分配、fixture、初值、零旧 IRQ 与无 start。
- `CONDITIONAL_GO_AFTER_REVIEW`：新的 fixed normal 单作业只有在 PREPARE 证据再次审查通过后才可执行。成功仍限于 `SOFT_POOL_DDR_NORMAL_PASS_FIXED_FIXTURE_LIMITED`；packet-DMA、重复提交、其它 shape/算子、HardNPU 和完整模型继续 `NO_GO`。

隔离包：`F:/My_proj/_isolated_builds/softnpu_ddr_traceable_20260920_1/`；源码归档 SHA-256 `f133c583d9f4b2bff9c4c77f5767767e3979f4efebb37e3e56db0379accd10a4`；27 项清单 27/27，清单 SHA-256 `c3198fc277b96a89073512c9d36346e385fe2650e602e0cb705f1699ff655590`。
API/UAPI 审计包：`F:/My_proj/_isolated_builds/softnpu_ddr_traceable_api_audit_20260920_1/`；6/6，清单 SHA-256 `a950aa4d6710184fe0830475291a2f855a7619ce5dfe72935810a0cad280dd63`。

## 2026-09-20 output-granule v0.4 后续诊断

- `DONE_CODED_PC_ONLY`：新隔离 v0.4 明确区分 4 字节 logical output、8 字节 experimental write capacity、零 padding 和偏移 8 后 guard；ABI/flag/version 均标记假设性质。
- `DONE_SOFTWARE_PASS`：状态机 143/143、静态门禁 24/24；源码包已生成并核验 SHA。
- `DONE_STATIC_EVIDENCE_LIMITED`：只读查询已实现 80MHz board DB，确认 HP1 `AWSIZE=2'b11`（8 字节 beat），八路 `WSTRB` 均为动态逻辑。该证据不等于尾拍全字节有效或通用 ABI。
- `DONE_STATIC_REVERSE_ENGINEERING_LIMITED`：冻结运行库的 `fill_soft_pool_driver_data()` 已做指令级恢复；固定块明确编码输入 `C/H/W=1/4/4`、输入元素数 16、Pool/量化参数，但没有独立 output-byte-count。该结果加强固定 fixture 的 8 字节容量假设，不证明运行时 strobe、AXI 排空或其它 shape/算子。
- `OPEN/P0 / BUILD_GO_AFTER_COLD_RECOVERY`：目标 `6.1.111-rt42` 构建。必须在冷恢复后的板端私有目录或匹配的离线 kernel tree 完成，保留 `Module.symvers` 缺口证据。
- `BLOCKED_BY_COLD_RECOVERY / CONDITIONAL_GO`：第二次 normal-mode 固定 Pool 硬件诊断。上一轮模块处于自锁隔离态，用户尚未确认物理断电；不得在同一上电周期重试。冷恢复后还须满足匹配启动、只读根、PREPARE-only、零旧 IRQ 和 `pre_status=0`。
- `NO_GO`：packet-DMA、额外输入、通用 ABI、HardNPU 和产品模型不能由 v0.4 软件通过自动放行。

## 2026-09-20 SoftNPU DDR 单作业第一轮

NPU-001 继续 `DOING`，但证据边界更新如下：

- S0 输入冻结与隔离目录：`DONE`。两个冻结包内部清单逐项通过；DDR 包给定总清单哈希按 LF 归一化匹配，原始 CRLF 文件哈希另有记录，未修改冻结包。
- S1 契约/启动决策：`DONE`。首算只放行一次 normal-mode fixed Pool；packet-DMA 未放行。
- S2 固定单作业驱动：`DONE_CODED`。无 probe start、mmap、任意寄存器、用户地址/packet；失败进入隔离并保留缓冲。
- S3 软件状态测试：`DONE_SOFTWARE_PASS`，139/139；静态门禁 21/21。它们不构成硬件结果。
- S4 目标构建：`DONE_WITH_KNOWN_SYMBOL_TABLE_GAP`。内核/模块 vermagic 匹配且实际装载成功；目标 kernel output 缺 `Module.symvers`，不可提升为发布构建。
- S5 80MHz PREPARE：`DONE_DDR_PREPARE_PASS_LIMITED`。固定 packet、输入、非黄金初值、三块独立低 4GiB coherent 缓冲及零 IRQ 已验证。
- S6 首算放行：`DONE_EXERCISED`。常规系统根分区只读切换失败的一次尝试在 start 前安全停止；最小只读 Linux 下门禁通过。
- S7 normal-mode 首算：`EXECUTED_ONCE_PARTIAL_QUARANTINED`。严格 IRQ `0x4`、四字节黄金输出、packet/input 不变；output 偏移 4～7 破坏 guard，驱动隔离、保留缓冲、未重试。不得标为 BOARD_PASS。
- S8 packet-DMA/更多输入：`BLOCKED_P0_OUTPUT_WRITE_CONTRACT`。先证明实际输出写入粒度、valid bytes 与 capacity 的契约，并继续保留 IRQ 后排空/失败停止未知项。
- S9 Hard Conv/产品链：`OPEN_P1`。Pool 证据不能替代 HardNPU、空间模型、动态手语或 V4R 产品验收。

下一项 P0：完成物理冷恢复后，在板端新私有目录目标构建 v0.4，并按 `v04_target_build_decision.md` 逐项复核后只运行一次 normal-mode fixed Pool。实现 DB 已证明 8 字节 beat，运行库反汇编已证明固定配置不提供独立 output-byte-count，但动态 WSTRB 和完成后排空仍 `UNKNOWN`；因此 v0.4 必须继续把 8 字节容量标为实验假设，成功也只能记固定 fixture 限定通过。不得直接放行 packet-DMA、更多输入或通用 ABI。

## 2026-09-19 S2固定fixture子项

DONE_PC_ONLY：`softnpu_ddr_fixture_20260919_1` 提供真实packet派生的头文件和四组输入金样；1,284 CPU对照、640位变异拒绝、AArch64语法检查通过。仅关闭S2的数据/配置准备子项，S2驱动、S3作业状态机与并发测试、S4内核模块构建仍OPEN；本次没有设备操作。交接S2已给Sol明确复用入口。

## 2026-09-19 Sol详细任务安排

交接细化DONE_DOC_ONLY：根交接新增S0输入冻结、S1缺口表、S2驱动实现、S3反例测试、S4目标构建、S5匹配启动/PREPARE、S6首算决策、S7普通DDR首算、S8包DMA/多输入、S9 Hard及产品链。各实现/实验任务仍OPEN，未因安排详细而置DONE/DOING；G4b仍BLOCKED_BY_CONTRACT。验收/失败处置/预期交付与第一轮收工要求均已明确，详见交接“Sol详细工作包”。

## 2026-09-19 晚间最新：DDR提交路径对照与Sol交接

NPU-001维持DOING，目标仍为真实SoftNPU及手语识别加速。用户选择系统DDR，私有RAM实验保留OPEN备选，不再等待其构建授权才能推进DDR。

- DONE_LIMITED：normal/DMA厂家helper设备遮蔽软件轨迹，16/6写调用与真实packet独立解码一致，19份结果回收SHA通过；状态SOFTWARE_WRITE_TRACE_ONLY，无真实寄存器写。
- DONE：更新根 `SOFTNPU_ASTRA_HANDOFF_20260919.md`，加入V6/V7、真实包、IRQ反例、DDR候选、匹配启动、单次驱动/缓冲隔离、冷恢复与产品优先级。
- OPEN/P0：恢复80MHz候选环境。当前运行设备树没有Soft节点；不能直接加载Soft平台驱动。当前bit身份UNKNOWN。
- OPEN/P0：独立固定Pool驱动、公共AXI启动/IRQ/故障处置审查，再受控normal模式DDR首算及任务包DMA首算。尚未编码完整驱动或放行，G4b仍BLOCKED_BY_CONTRACT。
- OPEN/P1：Hard Conv真实执行、空间模型数值恢复、词级独立评估；V4R接口继续冻结，不能用Pool/CPU结果替代。

证据根 `softnpu_ddr_handoff_20260919_1`；V2 17/17。未新增硬件执行验收，未自动领取全部建议任务。下面私有RAM等待记录和V5未回收等均为历史状态。

## 2026-09-19 私有RAM实验提案

范围确认仍待回复；保护复核17/17、46/46、34/34一致，不提升硬件验收状态。

新增OPEN/PROPOSED项：隔离NPU私有RAM+有界控制mailbox+独立复位；研究提案SOFTNPU_PRIVATE_RAM_BRINGUP_PROPOSAL_20260919.md明确静态、仿真、构建、首算、恢复及最终DDR验收。未编码/未构建，不自动置DOING。实施硬件版本需用户解除仅针对新隔离副本的构建限制。NPU-001和旧G4b状态不变。

## 2026-09-19 MPU默认规则核验

NPU-001仍DOING。MPU文档/示例审阅DONE_LIMITED：三个允许窗构成白名单的设想REJECTED，未命中默认允许；bit10、区域数及容量存在版本冲突。HPM隔离仍UNKNOWN，需精确版本说明或另行授权受控总线验证；不启用MPU/不启动NPU。六项具体厂商问题仅为未发送草稿。证据docs/research/SOFTNPU_MPU_DEFAULT_ALLOW_AND_VERSION_CONFLICT_20260919.md。

## 2026-09-19 HP1/MPU候选

NPU-001继续DOING。35根主AXI直连HP1静态核验DONE_LIMITED，MPU寄存器及BSP编码调查PARTIAL；HPM1对应、未命中/重叠/burst及排空仍UNKNOWN。推荐下一项为官方MPU行为/示例调查，尚未启动配置或板测；G4b仍BLOCKED_BY_CONTRACT。历史三缓冲已释放，不可复用地址。详见docs/research/SOFTNPU_HP1_MPU_CONTAINMENT_20260919.md。

## 2026-09-19 中断归属审计

NPU-001继续DOING；公开原函数CPU反例验证DONE_LIMITED：错误YOLO完成、超时后迟到NN污染下一次等待，两项复现；正常NN/超时控制通过。运行库静态接受0x0c任一位。新增下一执行驱动验收：严格NN位、单任务归属、超时后禁止重提和释放，恢复须有真实停止/AXI排空证明。尚未编码或加载修复驱动，G4b保持BLOCKED_BY_CONTRACT。证据docs/research/SOFTNPU_IRQ_OWNERSHIP_COUNTEREXAMPLES_20260919.md。

## 2026-09-19原始Pool配置路径补证

NPU-001继续DOING。PostAllocationConfigure→r_SoftNPUPoolDriver原始链在打包后、Acquire前受控捕获DONE_LIMITED：80字节与旧包逐字节一致，两个Acquire保护断点0次，目标终止，14文件SHA回收。此项不等于配置返回或硬件计算；不再把原始固定Pool包来源作为完全未知。下项优先级为实际设备DMA/AXI、完成IRQ、超时停机/缓冲生命周期，仍OPEN且G4b保持BLOCKED_BY_CONTRACT。证据docs/research/SOFTNPU_NATIVE_POOL_PATH_CAPTURE_20260919.md。

## 2026-09-19 晚间真实Pool对象补证

NPU-001继续DOING，G4b继续BLOCKED_BY_CONTRACT。真实厂家构造+真实host句柄+厂家填充打包已完成隔离板端验证，3entry/80字节及SHA冻结，13日志回收、94原头文件匹配。只记REAL_WORKLOAD_OBJECT_PACKET_CAPTURE_LIMITED，不能记ONNX全链、DMA或算子通过。下一验收为原始配置路径在Acquire之前受控捕获，并闭合DMA/AXI、完成IRQ、停止与缓冲生命周期。详见docs/research/SOFTNPU_REAL_POOL_CONSTRUCTOR_CAPTURE_20260919.md；不因包匹配启动设备。

## 2026-09-19 V7 板端最新验收

- BN折叠FP32厂商解析：**DONE / PARSER_PASS_LIMITED**，上板返回0。
- 三种混合图厂商解析：**DONE / PARSER_PASS_LIMITED（补声明版本）**。原版同在+0x41164崩溃；新增中间value_info、48帧CPU不变后，三图全部板端返回0；27个日志回收SHA通过。
- 量化导出中间声明强制门禁：**OPEN / RECOMMENDED**，full checker本身不能替代此冻结厂商parser所需完整声明，尚未修改原工程导出工具。
- 混合模型产品精度：**OPEN / REJECTED_FOR_DEPLOYMENT**，本轮不改变约0.632的最佳平均cosine，不是准确率或NPU执行通过。
- 主动G4b：**OPEN / BLOCKED_BY_CONTRACT**；真实packet、DMA/AXI、IRQ完成、停止恢复、缓冲生命周期未闭合。

证据根 `F:/My_proj/_isolated_builds/softnpu_astra_v7_board_20260919_1/`，交接见根 `SOFTNPU_ASTRA_BOARD_PROGRESS_20260919.md`。用户本轮上板推进已执行到上述验收层级；后续建议不自动标DOING。

## 2026-09-19 Astra V6 最新验收

NPU-001维持DOING/P0；以下仅关闭明确子项，不提升为NPU完成。

| 子项 | 状态 | 验收与证据 |
|---|---|---|
| V5独立回收/解释复核 | DONE | 24/24原始日志哈希匹配；八图结果独立核对，尾部触发解释限定到冻结图/库 |
| V6严格value_info单变量及48帧PC | DONE_PC_ONLY | 六文件full checker；仅新增两声明；删除新增项恢复原图；48×128元素相等；inferred与手工版同哈希 |
| V6四图板端parser-only | DONE / PARSER_PASS_LIMITED | 双控制139，双修正版parse_return/0；独立进程、遮蔽设备目录、降权；15/15日志回收，无backend/runtime |
| FP32末端BN折叠 | DONE_PC_ONLY | 权重按输出列缩放；最大误差1.1921e-6、平均cosine约1；未验证厂商部署 |
| bias warning及DW敏感度根因审计 | DONE_PC_DIAGNOSTIC | 无保护INT32强转溢出，12层18通道；DW排除后6层9通道；只恢复bias不足以修复精度 |
| 三组混合精度PC对照 | DONE_PC_DIAGNOSTIC / REJECTED_FOR_DEPLOYMENT | 平均cosine约0.42223/0.63207/0.62963；后两组无cast warning但仍不合格 |
| 下一组逐block/激活饱和与代表性校准 | OPEN / RECOMMENDED | 以无越界Conv候选作诊断起点，冻结CPU设置；补独立完整动作片段词级/拒识验证，未自动DOING |
| 受约束QAT/更小空间网络 | OPEN / CONDITIONAL | 有限PTQ边界与校准修复后仍失真再推进，尚未训练 |
| 主动G4b真实packet/DMA/IRQ/停止恢复 | OPEN / BLOCKED_BY_CONTRACT | 解析成功不改变该门禁；不能直接加载公开驱动或executor |

证据根 `F:/My_proj/_isolated_builds/softnpu_astra_v6_20260919_1/`；完整交接见根 `SOFTNPU_ASTRA_RESPONSE_20260919.md`。板卡原TF Linux保持上电空闲，COM4已释放；V2基线17/17匹配。下面旧记录中的“V5待回收”“V6待进行”等为当时历史状态，以本节为准。

2026-09-19 最新恢复记录：用户已恢复 NPU-001/P0。V4真实空间模型parser-only板端矩阵完成：FP32返回，UINT8/INT8均在冻结parser `LoadGraphQuantORT()+0x42954` 的 `NodeConnections` vector空数据指针处退出139；这是解析器兼容故障，不是NPU执行。反汇编现已把偏移0/24分别闭合为生产者/消费者索引vector：起始节点的消费者先被判空，但随后沿包含BN/Relu的可跳过算子集合追踪时，循环未判空就读取游标节点的第一个消费者。两失败图共同的唯一非Constant零消费者节点是终端Relu，故“DQ→BN→Relu链在图输出终止触发追踪缺陷”是待V5证伪的最强 `INFERRED` 根因，不能写成BN/ReLU普遍不支持。V4结果已回收29/29。V5八图 parser-only 已完成：两种 control 重现旧 `+0x42954` 崩溃，两种 tail-bypass 解析返回；两种 terminal-QDQ 因新增中间张量缺 `value_info` 命中 V3 `TensorInfo +0x730bd4` 空指针；两种 legacy 完整QDQ被明确拒绝 INT32 BN bias。下一验收为 V6 仅补终端Q/DQ两个中间声明的单变量矩阵、末端BN折叠数值验证和量化bias/混合精度审计；推荐项保持推荐/OPEN，不自动标记DOING。V5原始日志尚未回收。P0-H1真正NPU packet、DMA/AXI、中断、恢复契约继续 `OPEN/BLOCKED_BY_CONTRACT`；不得由解析通过直接进入设备执行。

2026-09-18 晚间 NPU-001/Astra P0-S1：A0/A1/B0/B1 四格规格和文件已在工程外隔离目录生成，ONNX checker/shape inference/CPU 金样均通过，配对 value_info 唯一差异已核验；子项 `DONE_PC_ONLY`，不代表厂家解析通过。P0-S2：V3 故障 PC/load-bias 采集源码已备、V2隔离差异已审，尚未目标编译，`SOURCE_READY`。P0-S3：原DR1 U盘 `G:` 旧清单核验后，在全新目录暂存八文件、源/USB回读8/8且旧清单不变，`USB_STAGED_ONLY/NOT_BOARD_BUILT/NOT_RUN`；待用户安全弹出并插回断电板卡，不自动标记 `BOARD_PASS`。P0-H1 恢复/AXI 契约仍 `OPEN`，主动设备 G4b 仍 `BLOCKED_BY_CONTRACT`。NPU-001 总任务维持 `DOING/P0`。

2026-09-18 NPU-001 缺中间value_info假设：失败QDQ图`graph.value_info=0`，`q_input/q_output`无中间声明；官方CRNN目标Pool周边有声明，FP32通过图仅用graph端点。冻结`AddPoolingLayer 0x4e1d0–0x4e1ec`取Pool输入`TensorInfo*`后构造TensorShape，局部未见空检查。下一验收只在授权隔离环境做“仅补value_info”单变量图、checker/CPU金样及有界parser对照，或取得崩溃栈；目前只是`INFERRED`、未定因。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 IR版本交互：9个官方ONNX为IR6/7/8，失败QDQ为IR9，但成功FP32对照也IR9，排除“IR9一概不受支持”这一单因；量化分支与IR9交互仍UNKNOWN。下一验收保持其余字段一致作D/E配对的未来有界解析，不在本轮运行。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 raw量化参数入口：`SetTensorQuantInfoFromQuantNode`静态上按Q/DQ input(1/2)获取scale/zero，含raw存储读取与`SetQuantizationScales/Offset`路径。下一验收是针对具体CRNN与故障图追定初始化张量映射、内部TensorInfo和实际解析阶段；不能由辅助函数存在推定运行通过或根因。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 Pool入边类型差分：ONNX声明类型下，故障图Pool入边UINT8，官方CRNN对应DQ输出为FLOAT；但冻结解析器在DQ输出资源指针非空的条件下于`0x41150`把内部DQ输出类型复制为输入类型，故声明差异不等于解析器内部桥接差异。下一验收静态追定具体边的TensorInfo赋值/桥接分支，并在将来授权的有界解析中定位阶段或崩溃栈；不能据此宣布根因。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 DQ类型改写门槛：`SetupInfo`对`value_info`的`OnnxTensor+8`资源字段初设为空、`+0`的`TensorInfo`非空；因此官方CRNN该DQ输出有`value_info`不等于`0x410fc`资源门槛已通过。下一验收只读定位量化加载期间哪一步填充资源字段，再判断具体边的类型复制是否静态可证；未有实际解析轨迹，`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 DQ guard 补证：门槛前当前仅见预加载资源于`0x40d6c`转移；官方CRNN目标DQ输出不在其106个initializer中。推断普通DQ输出在`0x410fc`仍可能为空，但预加载集合/别名未闭合。下一验收完整追资源字段写入并以受控解析轨迹核实，不能宣称官方Pool已量化；`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 桥接方向静态限定：冻结parser已确认当前UINT8/INT8、追溯FLOAT选`ALQuant`，反向选`ALDequant`；下一验收仍是具体QDQ边的内部类型赋值、实际调用轨迹与无崩溃解析。仅静态代码路径，真实分支及139原因`UNKNOWN`，`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 官方最邻近Pool参照：全量23个官方Pool里15个DQ参数也用标量`raw_data`，故手写图的存储方式单独不足以解释退出139。CRNN `/pool3/MaxPool` 为IR7/opset14、2×2/stride2、标量raw_data，可作下一离线对照源；需分别控制IR、显式属性、DQ→FLOAT Pool拓扑和上下游scale/zero。未裁剪/解析新图，根因`UNKNOWN`，`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 QDQ桥接子项：冻结内部 `ParseALQuant/ParseALDequant` 各要求1输入/1输出，官方KWS原生Q/DQ为3输入/1输出；`FindRealInputName` 在量化模式会跳过原生Q/DQ，`LoadGraphQuantORT` 比较原输入和真实输入类型，仅不同时合成1/1的AL桥接节点。下一验收只读追清具体官方节点的参数绑定、插入条件及内部AL解析调度，再设计官方风格极小对照。尚无崩溃栈，不把1/3输入差异当根因；`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 Pool失败恢复静态补证：冻结库等待中断常量为1000ms/掩码`0x0c`，Pool normal/dma执行路径均可调用；等待失败抛异常，内核超时只回`-ETIME`。同库`r_*_reset`只清零软件镜像，不能作为硬件复位证据。下一验收是完整异常/动态packet、硬件停止与AXI排空、缓冲寿命契约；当前`UNKNOWN`，`DOING/P0`，主动G4b`BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 packet边界：`soft_npu_write`自身不检查偏移，normal-mode packet分支有动态MMIO偏移；下一验收是在不接设备条件下取得真实生成packet并逐条核对偏移、映射长度与启动副作用，然后才讨论受控硬件试验。当前合成packet不可直接上板。`DOING/P0`，G4b`BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 转换split预筛：原始空间ONNX的35个普通Conv全部小于冻结`split_convFC.py`的输入/滤波tile阈值，depthwise在该脚本被跳过，原图没有其它会触发split的Gemm/ReduceMean/Slice；但正式onnxsim后的图未取得。下一验收需在隔离副本逐产物核对simplify/split/opset/量化输入模型的一致性，不在基线目录运行脚本。当前`INFERRED/DOING/P0`，21:00暂停。

2026-09-18 NPU-001 校准数据契约：厂家reader默认letterbox＋0..1缩放，不匹配当前模型直接224×224缩放及ImageNet归一化。下一验收是在隔离副本固定训练一致的RGB/几何/均值/方差，校准输入与训练/板端张量逐像素对照，并核对量化后金样；静态候选mean为`[123.675,116.28,103.53]`、scale约`[0.01712475,0.01750700,0.01742919]`。未执行量化，`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 depthwise层型：冻结parser对`group=Cin>1`的Conv创建独立`DepthwiseConvolution2dLayer`；现有空间图17层符合，Alnpu该类型支持槽默认拒绝。下一验收需在真实量化图解析/优化后逐节点记录层型、融合、后端与CPU回退；不能预填17层全部CPU或已NPU。`DOING/P1`，21:00暂停。

2026-09-18 NPU-001 ReLU6融合候选：原图35个Clip均为0..6，18个在普通Conv后、17个在depthwise后；parser映射`BoundedReLu`，Hard Conv转换器局部`checkAct`接受。下一验收须对真实量化图核查18个普通Conv邻接激活是否实际融合、边的量化参数和数值；17个depthwise后Clip仍单独处理。当前仅静态候选，`DOING/P1`，21:00暂停。

2026-09-18 NPU-001 官方Pool局部对照：冻结KWS ONNX的2×2/stride2节点为DQ→FLOAT Pool→Q，Q复用DQ标量参数。未来可在授权实验中从该真实局部逐步裁剪、checker/CPU金样/隔离parser逐阶段核验；当前仅静态定位，未裁剪或运行。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 Add后端路径：parser将ONNX Add建为ElementwiseBinary，Alnpu新式支持入口有Soft能力位4的专门门槛及workload；不能因旧式Addition虚表默认拒绝而认定10个Add都在CPU。下一验收是量化图逐层类型/参数、候选硬件能力位及无回退分配证明。当前`UNKNOWN/DOING/P1`，21:00暂停。

2026-09-18 NPU-001 Add局部预筛：新式入口要求量化8位类型并检查相同总元素数/类型；原图10个Add无显式广播、两输入与输出形状一致，但源FP32不满足类型。下一验收量化后的张量类型、各边scale/zero-point、实际capability bit4和逐层分配，不能据此宣布Soft Add通过。`DOING/P1`，21:00暂停。

2026-09-18 NPU-001 量化分支选择：冻结脚本UINT8/INT8两种QDQ设置不同（INT8启用per-channel及对称选项），本轮不运行。下一验收需在授权隔离副本分别检查生成图opset/类型/QDQ/权重量化、CPU金样及厂商parser接受，再决定真实网络路径；不能仅凭局部Hard/Soft类型门槛宣布兼容。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 packet地址域：候选IP-XACT内部寄存器块从`0x91000000`起，冻结normal-mode软件对packet条目地址加`0x6f000000`得到映射偏移。下一验收仍需对真实packet、DMA模式CLP解释、候选硬件窗口和所有副作用逐项审计；不能把编码地址当PS物理基址。`DOING/P0`，G4b`BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 双设备初始化边界：冻结Alnpu backend工厂注册方法顺序调用Hard/Soft驱动初始化；未来任何后端分配或packet探针都需隔离并审查双设备访问，不能把Soft模型路径视为只碰Soft节点。此前dlopen异常具体调用栈仍未知。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 完成判据：公开等待结构的work_status在Soft驱动等待分支未填充，运行库只检查NN/YOLO中断标志；下一验收须建立单算子专用中断身份、状态/错误、DMA范围、数值金样和迟到中断隔离的证据。当前真实完成`UNKNOWN`，主动G4b`BLOCKED_BY_CONTRACT`，`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 parser 分支线索：`LoadGraph` 静态上按预加载张量类型码2/3转入量化路径；失败QDQ图含UINT8 zero初始化值，成功FP32图无初始化值。下一验收仍是官方风格QDQ单变量受控解析、崩溃栈/阶段证据和量化Arm NN Pool形成；当前仅 `INFERRED`，未做板测。`DOING/P0`，设备 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 量化类型传播：冻结 `LoadGraphQuantORT` 静态上可在设置 scale/offset 后把内部 TensorInfo 类型直接写为 `QAsymmU8/QSymmS8`；下一验收需确定这些写入是否对应官方 Pool 边及后续优化/后端实际分配。当前不把此线索当作 QDQ 段错误根因或 SoftNPU 完成证据。`DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 后端检查副作用：冻结 `soft_npu_op_supported(0)` 从映射 SoftNPU 寄存器 `0x20` 读能力位，初始化链含 `/dev/soft_npu` 读写打开、ioctl和mmap。下一验收在独立安全契约下证明该只读能力位和后端分配，不能在现有 parser-only 设备遮蔽探针中直接调用 Optimize，也不能直接加载原始驱动。`DOING/P0`、主动 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 能力位元数据缺口：候选和 D20.3 示例 IP-XACT 的 TOP 寄存器表均止于相对 `0x18`、未列库读取的 `0x20`；候选 `define.v` 有 `NN_POOLING`，但不能替代运行时位义/读值。下一验收需恢复该寄存器可信 ABI，并在授权隔离硬件中受控只读核验；当前 `UNKNOWN`，不推断不存在。`DOING/P0`，21:00 暂停。

2026-09-18 NPU-001 Pool几何必要条件：冻结后端静态检查可确认NCHW、输入4维/batch1、Max、方形核2/5/9/13、等X/Y stride 1或2；2×2/stride2极小图仅满足这些已列子项。下一验收仍须完整解码padding/输出条件、形成内部量化Pool并证明能力位及分配；当前不以局部条件推出可运行。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 官方示例不保证全NPU：23个MaxPool中2个CRNN节点stride(2,1)不满足冻结Alnpu Pool等stride条件，CRNN demo默认允许CpuAcc/CpuRef。下一验收必须逐节点确认后端归属，不能用demo输出代替；当前实际分配`UNKNOWN`。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 Pool输入范围：冻结支持检查另要求C在1..2047、H/W在1..1023，诊断4×4与产品空间输入3×224×224在范围内；产品网络实际无MaxPool。下一验收仍是完整Pool条件及真实模型相关算子链，不以范围匹配推进设备完成状态。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 真实普通Conv预筛：当前FP32空间ONNX的35个group1 Conv对冻结`checkConv`已解出的dilation、方核1/3/5/7、受限stride/padding和权重乘积条件为35/35，最大输入通道×核面积960≤4736；FP32类型却明确不满足量化8位门槛。下一验收是隔离量化产物、完整优化路径与逐层Alnpu/CPU归属，不将静态候选当硬件完成。17个depthwise另列。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 优化入口：冻结`armnn::Optimize`在偏好后端有`ALRef`或`Alnpu`时静态调用Conv/FC专用转换流程。下一验收须先证明ALRef离线探针无设备副作用，再于未来授权隔离环境验证项目量化图实际转换计数和后端分配；当前均`UNKNOWN`。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 ALRef离线对照候选：其BackendContext构造仅返回空上下文，注册工厂/优化子图及Pool/ALHardNPU支持函数中未见直接设备系统调用；全局优化、间接调用和库构造链尚未审完，不能现在宣称ALRef-only安全或运行。下一验收是完整副作用闭包与隔离门禁。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 真实模型最小Hard Conv候选：源ONNX `/backbone/backbone.7/conv/conv.2/Conv` 在batch1下输入[1,192,14,14]、权重[64,192,1,1]、输出[1,64,14,14]，三者共62464个8位元素，为35个普通Conv最小。下一验收须在隔离副本导出/量化/CPU金样、完成真实后端分配与设备安全契约；当前仅静态候选，不是已生成硬件包。`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 混合后端成本：源图17个depthwise在普通Conv之间，batch1输入＋输出合计6043072元素。若仅普通Conv进NPU、depthwise留CPU且完整8位特征跨边界，原始搬运约6MB/帧；下一验收需取得实际逐层分区、零拷贝/缓存契约及系统延迟，不能以93%普通Conv MAC估算8fps。当前仅条件预算，`DOING/P0`，21:00暂停。

2026-09-18 NPU-001 故障复位 P0：IPUG166 v1.0 正文第6页写配置侧先于系统侧、各至少10周期；当前候选生成 `system.v` 将NPU两复位端绑同一共享网，且与Design.xml不一致，安路公开示例也有同网。不得据此断言冷启动错误，但现有bit无已证实NPU-only故障停止/AXI排空。下一验收先厘清内部复位寄存器忙时语义，若无法闭合，再在未来隔离硬件副本设计独立恢复并验证；当前只读、未改硬件。`DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 参考驱动安全契约：只读复核 `soft_npu.c` 超时返回 `-ETIME` 但不停止/排空，且原始 MMIO ioctl 与 mmap 未见完整偏移/长度门禁。未来主动G4b放行前须有独立NPU-only停止、AXI排空与缓冲寿命契约，并重做受控访问驱动；不能直接启用参考驱动。`DOING/P0`，设备 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 解析隔离边界：官方 `executor.cpp` 先在成员初始化列表创建 runtime、后解析 ONNX、再创建 runtime，故标准 demo 不可作为 parser-only 无设备探针。未来任何优化/后端分配实验须独立设计设备遮蔽及初始化副作用门禁；当前没有执行。`DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 QDQ fanout 边界：23个官方Pool的输入DQ输出中18个被两个节点消费、5个被一个节点消费；parser 的误导性“DQ输出不应被其他节点使用”文本已静态定位至DQ输出名重复检查，不能作为单消费者限制。下一验收回到官方QDQ Pool经解析/优化如何成为量化Arm NN Pool，以及真实图逐层分配；当前未运行。`DOING/P0`，设备 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 Pool 类型门槛：冻结 Alnpu Pool 支持检查先受 `soft_npu_op_supported(0)` 门禁，输入输出须为相同的 8 位量化类型（QAsymmS8/QSymmS8/QAsymmU8）；FP32 Pool 解析通过不满足后端通过的证据要求。下一验收是静态厘清官方 QDQ 图解析/优化后的 Pool 张量类型，未来在隔离环境验证逐层后端分配和数值；目前均未完成。`DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 Hard Conv量化门槛：冻结库 `ConvertConv2dIntoALHardNPUImpl::checkConv` 对张量类型静态只接受 QAsymmU8(2)/QSymmS8(6)，当前 FP32(1) 空间图不能直接满足。下一验收为隔离转换出数值正确的量化真实图，再证明专用层与Alnpu-only分配；脚本/转换未运行。`DOING/P0`，主动G4b `BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 厂商运行库转换符号补证：`ConvertConv2dIntoALHardNPUImpl::checkConv/Run/RunOptimization` 与专用层类实际导出，静态转换实现存在；下一验收仍是候选真实图在Optimize后有多少专用层、深度卷积归属及CPU回退证明。未调用运行库，`DOING/P0`、G4b设备`BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 Alnpu ABI静态收窄：冻结库 vtable 中通用 Conv2d/Depthwise 支持入口指向默认拒绝，专用 ALHardNPU/Pool 有 Alnpu 实现。下一模型验收不能只看 Conv 几何是否符合公开脚本，还需证实优化生成专用层、逐层后端分配及无CPU回退；此时未运行优化或设备。总任务 `DOING/P0`、主动G4b `BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 真实候选普通卷积静态细化：35个普通Conv的核/步长/pad符合公开检查器列出的尺寸条件；17个3×3 depthwise触发警告。该结果仅用于选择未来 Hard Conv＋Soft 辅助小链，不是模型后端分配或速度证据。后续必须对简化/量化后的真实图逐节点确认融合与Hard/Soft/CPU归属、数据搬运和数值。任务 `DOING/P0`，设备G4b `BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 真实模型算子静态审计：manifest哈希匹配的空间ONNX有52 Conv（35普通/17 depthwise）、10 Add、35 Clip、**0 MaxPool**；Pool诊断不得记为真实网络覆盖。公开检查器警告DWConv不能 ALNPU 加速，实际Hard/Soft/CPU分配及融合 `UNKNOWN`。下一验收在安全模型解析后取得真实模型逐层后端分配、CPU回退排除、数据搬运与延迟证据；当前用户限定仅静态，`DOING/P0`，设备G4b `BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 转换入口静态审查：公开 `AL_onnx_pass.py` 的校准器固定 RGB 三通道图，不能直接拿 1 通道极小Pool图跑全流程；README要求输出与输入模型同目录，须在隔离副本运行。无split分支预检的内存opset19模型与实际量化读取的先前 `*_sim.onnx` 可能不一致；未来验收需逐产物核对opset、shape、QDQ拓扑、数值和后端分配。当前只读，`DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`，21:00暂停。

2026-09-18 NPU-001 公开模型全量静态对照：冻结 SDK 的 9 个示例 ONNX 中，8 个模型的 23 个 MaxPool 均为 `DQ→Pool→Q`，且显式含 `ceil_mode/kernel_shape/pads/strides`；手写 QDQ 图为 uint8 直入 Pool 且缺 pads/ceil_mode。冻结检查脚本要求 pads，但同样缺属性的 FP32 对照已被 parser 接受，故不能单独归因。下一验收需把 dtype/拓扑与属性做单变量有界对照；当前用户禁止板测，总任务 `DOING/P0`、主动 G4b `BLOCKED_BY_CONTRACT`，21:00 暂停。

2026-09-18 NPU-001 追加只读 parser 反汇编：冻结库的普通 `ParseMaxPool` 转调 `AddPoolingLayer`，其 `ComputeOutputInfo` 实参经重定位确认为 `onnx::TensorProto::FLOAT`；这是静态调用路径证据，支持优先核验直接 UINT8 Pool 与官方浮点池化 QDQ 结构差异。无崩溃栈，未证明实际触发函数或修复效果。用户要求本轮只做电脑静态分析，21:00 暂停；总任务仍 `DOING/P0`，主动 G4b 仍 `BLOCKED_BY_CONTRACT`。

2026-09-18 NPU-001 parser 静态差分子项：冻结官方三个 QDQ 示例的 MaxPool 输入均为 `DequantizeLinear` 输出，而本项目崩溃极小图把 uint8 `QuantizeLinear` 输出直接接入 MaxPool；冻结 parser 具有量化专用路径，但无崩溃栈，故仅 `INFERRED_PRIORITY_HYPOTHESIS`，不是根因判定。官方风格极小图已在 PC 内存中经 checker/shape inference 验证静态结构，未保存/未上板解析。下一项继续电脑只读审查 parser 分支与图结构，不做板测。已建立根目录 `SOFTNPU_ASTRA_BRIEF_20260918.md` 供 Astra 协助；总任务 `DOING/P0`，今晚 21:00 按用户要求暂停，主动 G4b 仍 `BLOCKED_BY_CONTRACT`。

2026-09-18 NPU-001 parser V2 板端差分：U 盘新包 3/3、旧包 7/7、头文件 94/94，严格目标构建和双门禁通过。FP32 MaxPool 图仅 `FP32_ONNX_PARSE_PASS_LIMITED`（退出 0）；QDQ/UINT8 图在 `parse_enter` 至 `parse_return` 之间段错误复现（退出 139），内部根因 `UNKNOWN`。下一验收优先离线定位 QDQ parser 崩溃、审查可解析的模型表示和冻结转换链；如需再上板，应制定新的有界非设备实验，不重复当前 QDQ 调用。总任务 `DOING/P0`；真实模型包、Alnpu-only 算子分配、NPU 主 AXI/DMA/IRQ 和安全停止仍未验收，主动 G4b 保持 `BLOCKED_BY_CONTRACT`。详见 `docs/research/SOFTNPU_G4B_ONNX_PARSE_STAGE_V2_BOARD_20260918.md`。

2026-09-18 NPU-001 parser V2 U 盘暂存：原 DR1 盘旧清单匹配，V2 独立新目录四文件源/回读 4/4、包内 3/3，旧 V3 清单不变。子阶段 `USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`；下一验收是用户断电安全插回、COM4 监听与上电前置核验，然后板端重新核冻结三库/QDQ/94头文件、严格私有构建、非 root/root 门禁，先一次有界 FP32 解析，只有通过且健康才考虑 QDQ。总任务 `DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`。见 `docs/records/worklog/2026-09/2026-09-18-softnpu-v21-parser-usb-stage.md`。

2026-09-18 NPU-001 parser V2 电脑隔离暂存：四文件源/副本 4/4、清单 3/3，状态 `PC_STAGED_ONLY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`；未转移 U 盘或上板。下一验收为用户断电转移 U 盘后新目录暂存/回读，再目标私有构建与双门禁，先 FP32 对照、后视结果审议 QDQ。总任务 `DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`；不把电脑包验收扩大为模型或硬件通过。见 `docs/records/worklog/2026-09/2026-09-18-softnpu-v20-parser-pc-stage.md`。

2026-09-18 NPU-001 parser 差分诊断准备：原 QDQ ONNX checker 再过；FP32 MaxPool 对照在工程外隔离目录生成，checker/PC CPU 黄金输出通过、输入输出与 QDQ 逐字节相同。V2 阶段标记探针＋说明＋FP32 图三载荷源端 3/3，状态 `SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一验收在一次 U 盘往返中，板端重验已有三库/QDQ/94头文件、目标私有编译与双门禁，然后先有界 FP32 解析，只有成功且健康才审议 QDQ 解析；任何 parser 成功也不等于 Alnpu/SoftNPU 成功。总任务 `DOING/P0`，主动 G4b `BLOCKED_BY_CONTRACT`。见 `docs/research/SOFTNPU_G4B_PARSER_CONTROL_PREP_20260918.md`。

2026-09-18 NPU-001 parser-only V1 板端结果：USB/私有副本七载荷 7/7、头文件 94/94，目标严格编译及非 root/root 门禁通过；唯一一次限时调用退出 139，**解析未通过**，崩溃阶段 `UNKNOWN`。子阶段状态 `PARSER_ONLY_ATTEMPT_CRASHED`，不得升级为模型或硬件完成。保持隔离门禁的 V2 阶段标记源码/说明/两载荷清单已离线准备、源端 2/2，状态 `SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一验收须按前置哈希和门禁定位崩溃阶段，尽量一次 U 盘往返；主动 G4b `BLOCKED_BY_CONTRACT`，总任务 `DOING/P0`。见 `docs/research/SOFTNPU_G4B_ONNX_PARSE_ONLY_V1_BOARD_20260918.md`。

2026-09-18 NPU-001 parser-only U盘暂存：独立新目录八顶层文件回读一致、七载荷清单7/7、头文件94/94，旧V3包不变。状态`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`；下一验收仅一次板端私有构建及隔离parser调用，不能借此启动NPU。考虑用户不愿频繁切换U盘，后续可离线准备的检查应成批完成；本轮传输不再覆盖其它包。总任务`DOING/P0`、主动G4b`BLOCKED_BY_CONTRACT`。见`docs/records/worklog/2026-09/2026-09-18-softnpu-v17-onnx-parse-usb-stage.md`。

2026-09-18 NPU-001下一软件子阶段：固定QDQ+MaxPool ONNX的Arm NN **parser-only**探针源码、README、94项头文件清单及七载荷清单已备，公开库动态依赖/导出符号已静态核对；状态`SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一验收需用户断电转移U盘后新目录暂存、源/USB/板端逐项哈希、目标严格构建、非root/root无库门禁、最多一次限时解析。即使解析成功也**不**表示Alnpu独占分配或Soft设备可执行；主动G4b仍`BLOCKED_BY_CONTRACT`、总任务`DOING/P0`。见`docs/research/SOFTNPU_G4B_ONNX_PARSE_ONLY_PREP_20260918.md`。

2026-09-18 NPU-001 V3固定描述符软件包限定验收：U盘/板端私有副本清单各3/3、目标严格构建及非root/root隔离门禁通过；一次限时厂家软件填充+打包输出20字/80字节，原始JSON 237字节SHA已保存且离线解析与修正候选一致。子阶段`VENDOR_FIXED_DESCRIPTOR_SOFTWARE_PACKET_PASS_LIMITED`，**不是**真实ONNX→Alnpu包或NPU计算。下一P0验收仍是实际模型后端分配/张量布局、Soft设备拥有三缓冲的主AXI地址与缓存契约、NN专属完成IRQ以及超时后NPU-only停止/AXI排空/缓冲保留；这些未闭合前禁止把含`NN_start`的字提交设备。总任务`DOING/P0`，主动G4b`BLOCKED_BY_CONTRACT`。见`docs/research/SOFTNPU_G4B_POOL_FILL_V3_BOARD_20260918.md`。

2026-09-18 NPU-001 V3有界全字诊断U盘暂存：新目录源端/回读4/4 SHA、清单3/3通过，旧V2清单未变；状态仅`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一验收依次用户断电安全插回、COM4监听、上电前置核验、只读核包/私有构建/非root及root无库门禁，再允许一次15秒上限软件调用。设备G4b仍`BLOCKED_BY_CONTRACT`、NPU-001`DOING/P0`。见`docs/records/worklog/2026-09/2026-09-18-softnpu-v14-pool-fill-v3-usb-stage.md`。

2026-09-18 NPU-001有界全字差异V3准备：冻结V2基础上仅修正已实测首字预期并改为最多报告14字差异；不一致仍无包、无设备提交。V2→V3 diff审查及源码/README/冻结库清单3/3完成，状态`SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一验收需用户在物理断电时转移U盘→新目录暂存回读→板端只读核包/私有构建/双门禁→一次限时软件调用；不自动上电或运行。NPU-001`DOING/P0`、主动G4b`BLOCKED_BY_CONTRACT`。见`tools/npu/G4B_VENDOR_POOL_FILL_CAPTURE_V3_README.md`。

2026-09-18 NPU-001固定Pool填充V2限定验收：USB/私有目录清单各3/3、目标编译与非root/root隔离门禁通过；唯一一次厂商**软件**填充发现首字`0x1834`实际`0x00101004`、旧候选`0x00401001`，退出2且无包。离线反汇编支持旧静态C/H/W位序推导错误，候选工具已修正、自测通过。其余13字、真实ONNX包、CLP/NPU执行、DMA/IRQ与超时恢复仍`UNKNOWN`；不得把这个软件差异定位写成算子通过。下一验收先设计一次有界全字差异诊断并静态审查，需用户断电转移U盘后再传输；主动G4b保持`BLOCKED_BY_CONTRACT`，总任务`DOING/P0`。见`docs/research/SOFTNPU_G4B_POOL_FILL_V2_BOARD_20260918.md`。

2026-09-18 NPU-001首字差异定位V2传输：新U盘目录`DR1_SOFTNPU_G4B_POOL_FILL_CAPTURE_V2_20260918_1`源端/回读4/4、清单3/3哈希匹配，旧V1清单未变。状态`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`；用户已收到安全弹出并在物理断电板卡插回的请求，完成状态待确认。下一验收依次为U盘枚举及只读核包、板端新私有目录、目标严格构建、非root负门禁、root无库门禁，再审议一次15秒上限的软件填充差异诊断；任何失败中止，不放行NPU设备。总任务`DOING/P0`、主动G4b`BLOCKED_BY_CONTRACT`。详见`docs/records/worklog/2026-09/2026-09-18-softnpu-v12-pool-fill-v2-usb-stage.md`。

2026-09-18 NPU-001首字差异定位：V1未输出包的具体差异仍`UNKNOWN`；V2仅在不一致时向stderr给出首个entry/offset/word/expected/actual，保留拒绝与无包结果。V1→V2 diff已审查，三载荷清单3/3，状态`SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一验收是用户断电转移U盘→全新目录回读→板端只读核验/私有构建/双门禁→一次限时软件调用；之后依据实际数值查反汇编，不自动修改期望或启动NPU。总任务`DOING/P0`，主动G4b`BLOCKED_BY_CONTRACT`。

2026-09-18 NPU-001固定Pool填充V1验收：U盘重插后板端只读/私有目录清单各4/4、目标构建及隔离门禁通过；一次厂商**软件**填充在entry逐字校验处退出2，JSON 0、无包输出，故子阶段为`VENDOR_POOL_FILL_SOFTWARE_MISMATCH/NO_PACKET`。未知是哪一字、静态推导还是ABI外壳错误；不放宽校验、不提交NPU设备。下一项先用V2限界诊断定位首个差异，再做反汇编/头文件对照。NPU-001仍`DOING/P0`、主动G4b`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_G4B_POOL_FILL_V1_BOARD_20260918.md`。

2026-09-18 NPU-001固定Pool填充探针板端前置：原TF Linux启动成功、无NPU/CMA模块，但U盘**未枚举**（无`/dev/sda`，`lsusb`仅集线器/Wi-Fi），因此清单、目标Linux构建及厂家函数均`NOT_RUN`；阶段为`USB_STAGED/BOARD_PREFLIGHT_ABORTED_USB_NOT_ENUMERATED`，不是计算失败。已软件关机至`Power down`且电脑端COM4空闲；等待用户物理断电后重插同一U盘、再独立确认上电。NPU-001仍`DOING/P0`，主动G4b`BLOCKED_BY_CONTRACT`；不因此改动探针、驱动或bit。证据见`docs/records/worklog/2026-09/2026-09-18-softnpu-v9-usb-enumeration.md`。

2026-09-18 NPU-001固定Pool填充探针传输：已在原DR1 U盘全新目录暂存五文件，源/U盘5/5 SHA一致、清单4/4通过。子阶段仅`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`；下一验收为断电插回后板端只读核验、私有目录目标构建、非root负门禁和root无库门禁，再审议一次限时无设备软件填充。NPU-001仍`DOING/P0`，设备G4b仍`BLOCKED_BY_CONTRACT`；不能把USB暂存或手工fixture元数据写成ONNX模型包/算子完成。详见`docs/records/worklog/2026-09/2026-09-18-softnpu-v8-pool-fill-usb-stage.md`。

2026-09-18 NPU-001下一非设备子阶段：固定UINT8 MaxPool厂商`fill_soft_pool_driver_data`探针已`SOURCE_READY/ABI_STATIC_CHECK_PASS`，四文件清单4/4；仍`NOT_TARGET_LINUX_BUILT/NOT_USB_STAGED/NOT_RUN`。先在用户确认板卡断电后转移U盘至电脑，新目录暂存与回读哈希；目标Linux私有构建后依次非root负门禁、root无库门禁，系统健康无异常才考虑一次限时软件填充捕获。验收仅限固定描述符的厂家软件镜像与entry/包一致性；**不等于ONNX图解析/Alnpu分配/NPU设备Pool**。真实模型包及NPU-only停机/AXI排空仍为P0阻塞，主动G4b`BLOCKED_BY_CONTRACT`。证据见`docs/research/SOFTNPU_G4B_VENDOR_POOL_FILL_PROBE_PREP_20260918.md`。

2026-09-18 NPU-001 G4b软件包子阶段：V1在目标Linux的私有目录构建与隔离门禁通过，单次冻结厂家打包函数取得**合成reset/Pool-bit镜像**的20字/80字节、3组type0软件raw字；精确JSON和板端SHA已固化，离线逐字检查`STRUCTURE_ONLY`。修正先前类型0头字段误判为`0xff000000+字数`。子阶段验收`VENDOR_SYNTHETIC_SOFTWARE_PACKET_CAPTURE_PASS_LIMITED`；**固定ONNX模型真实包、CLP接受、NPU主AXI、DMA、完成IRQ及故障停机仍未验收**。NPU-001保持`DOING/P0`、主动G4b仍`BLOCKED_BY_CONTRACT`。下一验收为离线真实固定模型包、Soft设备三缓冲地址/所有权及可审计的NPU-only停止/AXI排空；不得提交当前合成字到设备。证据：`docs/research/SOFTNPU_G4B_VENDOR_SYNTHETIC_PACKET_CAPTURE_20260918.md`。

2026-09-18 NPU-001软件包探针传输：新U盘目录`DR1_SOFTNPU_G4B_PACKET_CAPTURE_V1_20260918_1`已完成四文件源/回读哈希核对和清单3/3校验；状态`USB_STAGED_ONLY/BOARD_NOT_TARGET_BUILT/BOARD_NOT_RUN`。下一验收先在用户确认物理断电、U盘安全插回后只读核包，复制至板端新私有目录、卸载USB，目标G++严格构建，再做非root拒绝及无厂家库`--gate-only`；不能把传输成功视为厂家raw包或NPU执行。NPU-001仍`DOING/P0`、G4b设备执行`BLOCKED_BY_CONTRACT`。

2026-09-18 NPU-001下一子阶段：厂家软件raw包隔离捕获V1探针与离线检查器已`CODED_ONLY`，清单3/3、自测通过；目标Linux编译、U盘暂存、厂家打包函数运行均`NOT_DONE`。以V3实测entry和静态编码推导的20字/80字仅为待证伪预测。下一验收是新目录U盘暂存、目标Linux严格构建、非root负门禁、无库隔离门禁，之后单次限时软件包捕获并与原始entry逐字对照；即使通过仍不等于ONNX模型包或设备Pool。NPU-001总状态`DOING/P0`，G4b设备执行`BLOCKED_BY_CONTRACT`。见`docs/research/SOFTNPU_G4B_PACKET_CAPTURE_PREP_20260918.md`。

2026-09-18 NPU-001增量验收：V3隔离门禁目标Linux `PASS_LIMITED`，冻结厂家库对合成reset/Pool-bit镜像返回3个实际软件entry，原始286字节JSON的板端/工程内SHA一致；原先3组/14数据字静态预测得到该条件下实测支持。首编译因旧头文件缺`SYS_close_range`失败，核验v6.1内核符号和AArch64编号436后仅板端私有构建兼容编译通过；不形成通用构建命令。**真实模型分配、厂家raw packet、DMA/IRQ、设备Pool与超时排空仍未验收**。NPU-001维持`DOING/P0`、G4b设备执行`BLOCKED_BY_CONTRACT`。下一验收先审计并隔离捕获厂家打包函数的raw软件包，再闭合NPU-only复位与主AXI停机/缓冲所有权，方可审议设备启动。证据见`docs/research/SOFTNPU_G4B_V3_VENDOR_ENTRY_CAPTURE_20260918.md`。

2026-09-17 V3传输子阶段：用户称U盘已插电脑，`G:`既有DR1目录核对后在全新`DR1_SOFTNPU_G4B_ENTRY_CAPTURE_V3_20260917_1`目录写入四文件；源与回读4/4 SHA一致，清单3/3通过。状态`USB_STAGED_ONLY/BOARD_NOT_LINUX_BUILT/BOARD_NOT_RUN`，未把门禁、厂家库加载或设备执行记为通过。下一验收：用户安全弹出并在板卡物理断电下插回；板端只读核验后在新私有目录编译，先运行非root负例和`--gate-only`，不自动运行厂家库捕获路径。NPU-001仍`DOING`，G4b设备执行`BLOCKED_BY_CONTRACT`。

2026-09-17 V3门禁候选：PC未发现现成隔离AArch64 Linux环境；候选和D20.3的TOP/AXI_READ/AXI_WRITE元数据均未给出busy时AXI排空契约，transfer_limit不能当停止开关。新增不加载厂家库的`--gate-only`、继承FD关闭和输出普通文件门禁；源码/README/清单3/3哈希匹配，状态`CODED_ONLY/NOT_LINUX_BUILT/NOT_USB_STAGED/NOT_RUN`。用户报告板卡上电、U盘在板卡；COM4确认Linux后只读检查U盘未挂载、NPU/CMA模块未加载，正常`sync; poweroff`到达`Power down`并关闭串口。物理断电仍待用户确认。下一验收由用户物理断电后把U盘转电脑，再以新目录暂存候选包；板端首先仅编译、非root失败门禁和gate-only，成功也不批准厂家库加载或设备start。NPU-001继续`DOING`，G4b设备执行`BLOCKED_BY_CONTRACT`。见`docs/research/SOFTNPU_G4B_V3_ISOLATION_AND_AXIRECOVERY_20260917.md`。

2026-09-17 厂家entry ABI增量：冻结库的16字节列表头、24字节entry、各字段偏移及672字节Pool镜像已由机器码与AArch64结构编译检查交叉核验。V3探针加入编译期布局断言和关闭继承FD门禁，但尚未Linux编译/运行，厂商构造函数其它副作用和真实ONNX模型包仍未知；当前板端抓包不放行。下一验收先建立无真实设备直通的AArch64 Linux环境，验证库加载和合成entry，再区分真实模型packet；另需AXI停机/缓冲所有权证据才可审议设备start。NPU-001`DOING`、G4b`BLOCKED_BY_CONTRACT`；见`docs/research/SOFTNPU_G4B_ENTRY_ABI_STATIC_AUDIT_20260917.md`。

2026-09-17 两个官方问答未答问题的本地推断：公开Soft驱动`WAIT_INTERRUPT`超时只报`-ETIME`，不能据此释放/复用设备DMA缓冲；内部reset名称和IPUG166上电顺序均未提供忙时AXI排空契约。固定UINT8 Pool三entry/80字节只属静态条件化预测；厂家真实ONNX→Alnpu packet仍未捕获，默认样例允许CPU回退。V3私有可搜索空tmpfs探针仅`CODED_ONLY/NOT_RUN`，需完整隔离审计，不移至当前板上直接运行。下一验收为无真实设备的厂家输出捕获及NPU-only停机/缓冲生命周期证明；NPU-001继续`DOING`、主动G4b继续`BLOCKED_BY_CONTRACT`。见`docs/research/SOFTNPU_G4B_TWO_QUESTIONS_INFERENCE_20260917.md`。

2026-09-17 D21.1 rootfs盘点：内存解包得到892个非trailer条目，`npu_demo/` 有演示程序/模型/脚本，但没有独立保存的单Pool packet或黄金输出；固定图手势脚本未限定Alnpu-only，不能用其输出排除CPU回退。下一验收仍是无真实设备的厂家生成函数真包捕获，或官方提供最小真包与安全恢复契约；不在当前板上放宽设备隔离。NPU-001`DOING`、G4b设备计算`BLOCKED_BY_CONTRACT`；见`docs/research/SOFTNPU_D21_1_ROOTFS_CONTENT_AUDIT_20260917.md`。

2026-09-17 NPU复位来源漂移：G400 80MHz候选的 `Design.xml` 与生成 HDL 对 `Video_NPU_0.M_AXI_AResetn` 的连接不一致；原工程及D20.1/D20.3示例对照一致。新增只读检查器可在未来隔离构建前阻止把两种拓扑混用。下一验收先冻结准确XML/HDL/bit关系，再验证复位时序及故障时AXI排空/缓冲保留；不要直接Generate当前候选。NPU-001仍`DOING`，G4b设备执行`BLOCKED_BY_CONTRACT`；见`docs/research/SOFTNPU_RESET_METADATA_HDL_DRIFT_20260917.md`。

2026-09-17 D20.1两份示例增量：TD/HPF与SD镜像DTB的G484配置相互吻合但BOOT/bit未绑定；镜像库与冻结库可装载机器码相同。固定UINT8 Pool的`0x181c`零值及类型0局部包头规则可静态复核；三entry/80字节仍为条件化预测、非真实包。下一验收依旧是真实厂家包和Soft设备DMA/IRQ/超时安全恢复，不直接移植G484示例。NPU-001`DOING`、G4b设备计算`BLOCKED_BY_CONTRACT`；见`docs/research/SOFTNPU_D20_1_DEMO_POOL_REUSE_20260917.md`。

2026-09-17 Arm NN 库对照：D20.1镜像库与冻结SDK库完整SHA不同，但25个可装载ELF分节、关键Pool函数机器码与加载期初始化表均相同；此前静态逆向可转用于该镜像版本，无需仅因`.comment`差异重做。下一验收仍是真实单Pool packet及DMA/IRQ/超时恢复契约；同机器码不代表G400可运行。NPU-001`DOING`、G4b设备计算`BLOCKED_BY_CONTRACT`；详见`docs/research/SOFTNPU_VENDOR_RUNTIME_ALLOCATED_SECTION_EQUIVALENCE_20260917.md`。

2026-09-17 D20.1 2025.7 补证：本地TD/HPF与SD镜像DTB均为G484、SoftNPU `0x80000000`/SPI82，uImage CRC通过；rootfs包含NPU程序/静态手势模型/Arm NN库。库整体SHA虽不同，后续可装载分节逐字节比较已证明Pool代码相同；此项只读比较已完成，不把G484示例bit/DTB或同基址套到G400；仍需官方解释失败恢复。NPU-001维持`DOING`、设备Pool`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_D20_1_2025_7_SD_IMAGE_AUDIT_20260917.md`。

2026-09-17本地D20.3增量：用户下载的2026.1 TD/HPF已只读审查，G484、`0xA0000000`/SPI83、YOLOV8，与当前G400候选不匹配；两份IP-XACT的148项寄存器元数据完全一致，仍不证明运行兼容。D20.1/D20.2/D20.3均共享NPU两路外部复位，收窄此前`STATIC_CONTRACT_CONFLICT`为手册/示例待澄清差异。下一验收请官方回答冷启动时序、运行期NPU-only停机/AXI排空/缓冲释放和无设备的最小Pool离线导出/Alnpu验证方法；问题草稿已备，网站读取超时尚未提交。若无官方答案再做本地隔离设计。NPU-001保持`DOING`，G4b设备计算仍`BLOCKED_BY_CONTRACT`；详见`docs/research/SOFTNPU_D20_2026_1_LOCAL_DEMO_AUDIT_20260917.md`。

迁移来源：`docs/handoff/ASTRA_OPEN_ITEMS.md`。更新日期：2026-09-17。

状态约定：`OPEN` 表示尚未领取；`DOING` 表示已明确执行；`VERIFYING` 表示主要产物已形成但验收尚未闭合；`BLOCKED` 表示无法推进；`DONE` 必须附验收证据。

| ID | 状态 | 优先级 | 版本 | 子系统 | 任务 | 已完成部分 | 剩余/阻塞 | 验收条件 | 相关路径/下一动作 |
|---|---|---|---|---|---|---|---|---|---|
| SYS-001 | DONE | P0 | V2板测 | 系统 | 固化 known-good Git 源码/验证基线 | 17项哈希匹配；manifest 已提交；源码/精选证据位于 `7397b2cd9e2465edac37f2b4afcc4f0c6a161ced`；`v2-board-20260907` 指向该提交；三个二进制使用精确 LFS 路径 | 隔离重建属于 SYS-003，仍 `UNKNOWN`；压缩包/用户备份按本轮范围未检查 | 17项 manifest 通过；源码/精选证据提交；tag 建立；原基线不变 | 验收完成；`COM4.log` 因 Windows 保留设备名为 manifest-only，限制已记录 |
| SYS-002 | VERIFYING | P0 | 全部 | 接口 | 冻结版本、频率和地址边界 | V2 DUC2、普通 TCON 和 V4R-1 已按 ID/version 分开；V4R-1 ABI 及 100/50MHz 边界已写入正式接口文档 | V4 仍 `UNKNOWN`；NPU 历史地址冲突；V4R DMA/Cache 层未定义 | 同基址不混 ABI；默认/板测频率分开；未定项显式为 `UNKNOWN` | `docs/architecture/HW_SW_INTERFACE.md`；下一步冻结 PS-003 协议 |
| SYS-003 | VERIFYING | P0 | 全部 | 构建管理 | 建立可复现隔离构建和后续版本控制 | Git 基线已验收；V4R-1 已在独立目录完成仿真、综合、P&R、最终时序、bitgen 和 SDK 构建，构建前后 V2 guard 通过 | 尚未做第二个全新隔离副本的字节级可复现对照；通用自动隔离流程 `UNKNOWN` | 隔离构建不改基线；差异可解释；适用回归通过；第二次干净重建一致或差异有清单 | 保留本轮 manifest；后续另做 clean rebuild，不在原工程构建 |
| SYS-005 | BLOCKED | P0 | 全部 | Git远端 | GitHub私有远端与恢复验证 | `origin` 已配置；初始 main、annotated tag 和3个 LFS对象已成功推送并由远端 refs 核对 | 独立 clone 连续三次因 GitHub 443 连接失败；未执行 LFS pull；`COM4.log` 为 manifest-only，Git-only clone 不能自然达到17/17 | main/tag/LFS推送；独立 clone 和 LFS pull；tag目标正确；恢复副本17/17哈希匹配 | 网络恢复后在工程外重试；先制定不改原证据的 COM4 可恢复方案，未满足前不得标 DONE |
| PROD-001 | DOING | P0 | 产品MVP | 需求 | 冻结助诊手语产品和模型契约 | 长期目标已确认；三类本地演示输出暂定为咳嗽/过敏/发烧，形成DRAFT manifest、训练/接板计划并完成公开数据试训 | 中国手语标准/地区、动作定义、拒识指标、隐私、目标屏准确型号仍待用户/手语专家确认；三类暂定不等于标准手语验收 | 产品/模型manifest经用户和手语专家确认；所有TBD有责任人和验收值 | `model_pipeline/product/medical_mvp_v1.DRAFT.json`；采集目标场景孤立动作后再冻结正式classes |
| VID-001 | OPEN | P0 | 端到端 | 视频输入 | 验证IMX415到ISP/DDR真实帧 | 主工程有MIPI D-PHY、CSI/RAW10、ISP和FDMA写结构；新增 demo 有4-lane IMX415、ISP、DDR三帧缓存读写的有效综合源，用户确认可显示 | 主工程读回关闭；demo 的帧格式/裁剪、错误计数、长稳及产物绑定未独立验收 | 固定帧与实拍帧逐像素可核；无错帧/越界；证据可追溯 | 先为 demo 建只读manifest，再在新隔离副本迁移；不直接构建demo原目录 |
| DISP-001 | OPEN | P0 | 端到端 | 显示 | 确认并实现目标屏输出 | `demo/11_csi_dsi_imx415_7cun/` 含1024×600 DSI packet、显示初始化、4-lane D-PHY TX、管脚、bit和正时序报告；用户确认7寸屏正常显示 | 主工程仍为HDMI；准确面板型号、用户验证所用BOOT/bit/ELF绑定、复位/长稳和主工程集成未验收 | demo组合manifest冻结；固定图和视频稳定显示；复位可恢复；产品集成通过 | 记录屏幕型号/连接，核对root BOOT与对应源码/bit/ELF后在隔离副本移植 |
| PS-001 | OPEN | P0 | V2 | 固件 | 消除 `prepare_sdk.py` 覆盖板测应用风险 | 已确认脚本覆盖 `main.c`、应用元数据、Makefile 和 lds；旧模板缺板测补丁 | 脚本未修；本阶段禁止开发和运行 | 新准备流程不破坏主源/元数据/lds；隔离编译和适用板测通过 | `implementation_v2/prepare_sdk.py`、`implementation_v2/sdk_main.c`、`soc_sdk/duration_v2/main.c`；在 SYS-001 后设计唯一源策略 |
| PL-001 | OPEN | P1 | V2 | 时序/CDC | 完整约束、CDC/PVT 及原频率闭合 | 100/50MHz 限定配置有正裕量报告和有限复位回归 | 默认约 200/133.32MHz 报告有负裕量；全 CDC/PVT 未签核 | 物理时钟与 SDC 一致；例外端点有依据；目标工况全部满足 | `implementation_v2/soc_v2/soc_v2_pr.timing`、`reset_cdc_board.sdc`；先静态审查未覆盖路径 |
| PL-002 | DONE | P1 | V4R-1 | RTL | 实现固定块结算及本地协议 | RTL/AXI、整数参考、100 个 core 用例及 AXI 仿真、完整 SoC 综合/P&R、100/50MHz 正时序、bit/ELF、DDR 回读及限定板测均通过 | 当前只有 MMIO 装载；DDR DMA/Cache/多通道/真实模型不在 V4R-1 范围 | 已满足：8 用例及复位重跑通过；每例固件检查 25 输出证书；身份/频率实读匹配 | `implementation_v4r/`、`V4R_BUILD_MANIFEST_20260909.json`、隔离板测目录；后续能力扩展另立 PS-003/MODEL-001 |
| PL-003 | OPEN | P1 | V2 | IP集成 | 解决适配生成副本可被 Generate 替换 | 当前适配版本有限板测通过 | 正式 IP 打包和确定性生成关系未完成 | 隔离重生成后 ID、接口和仿真一致；原基线不变 | `implementation_v2/prepare_soc_variant.py`、`implementation_v2/soc_v2/`；先建立权威源映射 |
| PS-002 | OPEN | P2 | 原NPU | 驱动 | 查明SOFT_NN异常与版本配套 | 公开hard/soft NPU和CMA驱动及初始化可读；当前历史npu_drv仍缺失 | 参考DT为0x1F0000000/SPI97，与当前BSP不匹配；SLVERR根因UNKNOWN | 冻结实际bit/HPF/DT/驱动后，以授权实验事务证据归因 | `docs/research/NPU_PUBLIC_STACK_INVESTIGATION_20260913.md`；禁止把公开初始化当unlock直接试写 |
| PS-003 | OPEN | P1 | V4R后续 | DMA/Cache | 定义 ARM/FPGA 所有权及传输 | V4R-1 已冻结本地 MMIO ABI 和作业计数 epoch，但明确不声称 DMA/Cache 协议 | 缓存维护、代次、布局、乱序/重试/复位协议 `UNKNOWN` | 乱序、迟到、重复和复位不误提交；数据一致 | V4R 技术稿与 `implementation_v4r/README.md`；先定义协议，不借用 V2 MMIO |
| NPU-001 | DOING | P0 | 端到端 | 空间模型 | 验证公开NPU栈与固定图/自定义模型 | G0/G2/G3/G4a证据保留；真实80字节Pool packet已冻结。v0.5.4原生AArch64模块/探针目标构建后，在80MHz候选bit/临时DTB、只读最小根和三块驱动自有4KiB coherent DDR上完成唯一一次fixed Pool normal-mode作业：strict IRQ `0x4`、IRQ 0→1、21项完整写追踪、输出`05 07 0d 0f 00 00 00 00`、packet/input/padding/guards全通过，回收三块缓冲电脑逐字节0差异，冷断电已确认 | 当前仅为`BOARD_PASS_LIMITED(fixed Pool normal DDR)`。分配区外访问、IRQ后全局AXI排空、超时/错误停机、packet-DMA、其它Soft算子/shape、Hard Conv/GEMM、官方runtime后端分区与CPU回退排除、模型级精度/性能仍`UNKNOWN`；既有parser阶段按最新证据追溯，不重复V5矩阵 | 2026-09-21方向审查选择H1：先执行主报告H1-01～03的单层隔离、真实Alnpu分区及Hard载荷审查，再闭合独立驱动、地址、IRQ和生命周期契约。S8后移；不重复已完成Pool和parser矩阵。Hard仍HARDWARE_NO_GO_PENDING_H1_CONTRACT；详见SOFTNPU_ASTRA_DIRECTION_REVIEW_20260920.md | `F:/My_proj/_isolated_builds/softnpu_ddr_targetbuild_v054_20260920_1/evidence/board_run_v054_1/v054_real_run_evidence.md`；`docs/records/worklog/2026-09/2026-09-20-softnpu-ddr-oneshot.md` |
| IF-001 | OPEN | P0 | 模型接口 | 张量契约 | 冻结空间特征到TCN接口 | V4R-1已有小规模INT8输入语义；PC固定视频已验证16×128 FP32特征；DR1 PS CPU已用同一manifest逐元素核对16×128空间特征和TCN输出通过；连续回放验证了逐帧128维特征缓存和16帧滑窗调用顺序 | NPU/V4R实际特征层与布局、INT8 scale/zero-point、帧时间戳、padding/dilation和跨后端模型版本仍`UNKNOWN` | PC/NPU/PS使用同一feature manifest并逐元素对照通过 | PS CPU的FP32契约已有板端证据；仍依赖NPU-001及真实V4R映射闭合跨后端契约 |
| MODEL-001 | VERIFYING | P0 | 手语模型/V4R | 目标/评估 | 建立真实数据和空间＋TCN黄金模型并冻结性能边界 | 合成全流程、CSL-Clinic三轮试训、PC浮点ONNX/黄金向量和连续回放通过；真实DR1 Linux用CPUExecutionProvider完成固定预处理张量，空间特征、TCN logits及类别均与黄金结果一致；报告哈希已冻结 | 当前数据许可证未声明、真实signer未知、动作窗口为弱标签；视频解码/预处理、自动动作切分、拒识、INT8、Arm NN/NPU、V4R收益、功耗和成本仍`UNKNOWN` | 已满足DR1 CPU固定张量数值/分类条件；任务保持VERIFYING，直至按真实手语者隔离测试并闭合拒识 | `model_pipeline/board_fixed_onnx_probe.py`；下一步接入板端真实帧并建立解码/预处理基线，不把固定张量PASS扩大为产品验收 |
| PL-004 | OPEN | P1 | V4R后续 | TCN硬件 | 将V4R扩展为真实模型所需算子 | V4R-1固定C4/T32/K8/F1、VALID、dilation1的限定实现通过 | 多输入/输出通道、偏置、量化、padding/dilation、残差连接、DMA和真实特征未实现 | 仅实现模型所需子集；逐层参考一致；板测含非零残差；相对强基线收益达标 | 依赖IF-001和PS-003；不得先按旧256维预估开发 |
| APP-001 | VERIFYING | P1 | 端到端 | PS应用 | 实现窗口、分类/解码、拒识和恢复状态机 | PC回放状态机通过；COM4已确认并登录真实DR1 Linux；私有PYTHONPATH包未安装系统组件即在DR1完成固定张量空间网络和TCN运行 | 当前输入仍是预处理FP32张量；空闲边界由测试夹具提供；没有板端视频解码/预处理、自动动作切分、校准阈值、unknown/idle类别、摄像头输入或目标显示集成 | 固定视频与实时流语义一致；超时/低置信度不误输出 | 保留固定张量报告作为CPU基线；下一步只在隔离方案中接入真实帧，不覆盖当前板端结果 |
| OSD-001 | OPEN | P1 | 端到端 | UI/显示 | 中文文本叠加与缓冲同步 | 当前HDMI视频输入端口和候选帧缓冲结构存在 | 字体、中文编码、OSD位置、双/三缓冲、MIPI屏路径未实现 | 中文短语/拒识/状态稳定显示且无明显撕裂 | 依赖DISP-001和APP-001 |
| MODEL-002 | VERIFYING | P2 | V4R | 专利 | 建立特征—文献—实验对应 | 已形成板测后技术交底与12项权利要求讨论稿；按现行CNIPA口径收敛FPGA本地主线；已区分数学、RTL仿真、实现和8用例板测证据 | 非零残差路径尚无板测；完整CN/WO/US检索、权属/公开时间线及代理判断 `UNKNOWN` | 来源、日期和差异可追溯；独立项有说明书/实现支撑；未实现效果不冒充实测 | `patent_application_package/V4R_技术交底与权利要求草案_20260910.md`；先补 `residual_products>0` 定向板测并核对公开历史 |
| VER-001 | OPEN | P1 | V2 | 系统验证 | 验证固定用例以外的系统表现 | 10 组及 100 次 GDB 任务有日志 | 满带宽、长稳、真数据、功耗和装载时间未测 | 同条件对照，正确率/性能/误差满足预定指标 | `implementation_v2/board_test_20260907/`；仅在隔离基线副本制定计划 |
| VER-002 | OPEN | P0 | 视频/NPU/V4R/显示 | 端到端 | 验证摄像头到中文显示的完整链路 | 顶层含MIPI/ISP/FDMA，V4R-1有独立限定板测 | 读回、显示、NPU、真实模型、TCN接口、分类/解码和OSD均未闭环 | IMX415真实输入经实际模型和TCN后在目标屏输出；逐层可追溯；含拒识/故障/长稳/延迟 | `docs/ROADMAP.md` Phase 8；不得以合成输入或局部BOARD_PASS替代 |
| VER-003 | OPEN | P2 | 原段核 | 边界 | 处理容量等反例 | 固定样例和证书测试修订有记录 | 原核容量、无效 K 和阈值语义仍有反例 | 若继续使用，所有合法边界断言通过；否则明确历史用途 | `soc_prj/uisrc/01_rtl/temporal_conv/`、`review_20260907/edge_run.log`；先决定用途 |
| VER-004 | DONE | P0 | V4R-1 | 板级验证 | 下载指定 V4R-1 bit/ELF 并执行限定自测 | 2026-09-10 指定哈希 bit/ELF 下载；DDR 261 段/120474 字节回读通过；实读 100/50MHz、ID/version/capabilities；8 用例首轮和显式 P2F 复位重跑均为 pass；同 ELF reload 后第二份完整 UART PASS | 视频、DMA、NPU、真实模型、长稳、满带宽、功耗和 Flash 冷启动仍 `UNKNOWN`，不属于本任务 | 已满足：四种块大小×两模式；每例 25 输出由固件校验证书；复位重跑；UART/GDB/分频日志保存 | `implementation_v4r/BOARD_TEST.md`；证据根 `F:/My_proj/_isolated_builds/fdma_imx415_v4r_board_20260910_1` |
| DOC-001 | OPEN | P1 | 全部 | 文档 | 处理过期入口、源码清单和路径 | 审计、交接及本次正式基线保留了冲突 | 旧文档尚未迁移；本阶段禁止移动/删除/重命名 | 无跨版本混用；关闭问题附证据；原日志保留 | `docs/_audit/`、`docs/handoff/`；后续按授权逐项整理 |
| DOC-002 | DONE | P0 | 端到端 | 路线图 | 建立助诊手语翻译本地部署完整规划 | 已按当前源码和历史记录形成产品、视频、模型、NPU、V4R、PS、显示、验证和发布阶段及依赖 | 实现任务均保持OPEN/BLOCKED，不因规划存在而完成 | 路线图明确当前事实、缺口、阶段闸门、任务ID和验收条件 | `docs/ROADMAP.md`；验收完成 |
| SYS-004 | OPEN | P3 | V2及后续 | 启动 | 验证 Flash 持久启动 | JTAG 临时配置和 ELF 运行有证据 | 无 Flash 冷启动验收 | 冷启动可重复；产物版本可读；恢复方法明确 | 板测目录 README；基线固定后另立任务 |
| REL-001 | OPEN | P2 | 产品发布 | 固化 | 建立系统镜像、模型、bit和回退发布包 | Git/manifest已有局部基础 | 冷启动、系统镜像、设备树、runtime、模型、词表和恢复演练未完成 | 指定release manifest可在同型号硬件独立恢复并回退 | 依赖VER-002；与SYS-004合并验收 |

## 推荐顺序

项目主线已切回端到端产品。首先完成 PROD-001，并把用户确认可显示的 `demo/11_csi_dsi_imx415_7cun/` 固化为只读参考组合；随后在新隔离副本推进 VID-001/DISP-001 的产品集成，并建立 MODEL-001/NPU-001 固定图基线。只有 IF-001 冻结后才进入 PS-003 和 PL-004。GitHub 推送按用户要求暂停；demo 局部视频显示不等于 NPU、真实模型、OSD或完整系统通过。

## 2026-09-17 NPU-001 离线核心算术与启动门槛

最新静态增量：固定样例软件镜像的条件化3个entry/14数据字结合厂家`gen_dma_pkg_from_entry_list`两头字/entry规则，**预测**20字/80字节，离线Temp副本自测通过；这不是捕获到的厂家真实包。候选IP-XACT确认四个内部复位寄存器名称/偏移，但未给忙时主AXI中止与排空语义，公开驱动也无可审计故障恢复流程。NPU-001仍`DOING`，G4b设备执行仍`BLOCKED_BY_CONTRACT`；下一验收为真实包核对与设备安全停止/缓冲生命周期契约，不要求用户现在改线。

加载期异常的静态链已缩到`.init_array`→Alnpu静态登记→`__lxstat('/dev/hard_npu')`→权限错误时`filesystem_error`；该链不要求先执行已知的Hard驱动init。下一步不再把“找出哪一处自动触及路径”当成未知，改为在**没有真实NPU直通**的独立AArch64 Linux环境中审计完整加载与获取厂家真实单Pool包；其它构造函数是否有副作用仍待核验。当前板上不得伪造/开放节点重试。详见`docs/research/SOFTNPU_G4B_DLOPEN_CONSTRUCTOR_20260917.md`。

NPU-001总状态仍为`DOING`、P0；G4b设备执行子阶段仍为`BLOCKED_BY_CONTRACT`。已新增8位MaxPool CPU参考和测试源码，Windows/AArch64编译检查通过，既有ONNX固定样例的量化字节对齐；**C运行自测未执行**（Windows应用控制策略阻止新程序）。离线packet解析器合成自测和固定配置的三个软件镜像候选字脚本自测通过。验收条件仍为：可解释的**真实**单Pool packet/entry、Soft设备持有并经主AXI验证的DMA地址与缓存所有权、只接受NN完成位的IRQ判据、超时后设备停止访问缓冲的恢复契约、实际Pool数值逐项对照。CPU算术和软件镜像均不能替代上述验收。下一步优先只读静态追踪；必要时另行准备CPU-only板端核验，不自动上电。

同日静态续查：AArch64 GCC `-fanalyzer -Werror` 对核心与测试源码检查通过；固定样例的软件镜像候选扩至六字，并确认公开Pool填充只读取窗口宽度与纵向stride，不能由此推广至任意长方形/非对称配置。公开驱动的probe立即启动AXI、超时无可审计停止路径，G4b启动许可仍未满足。用户外出时板卡保持连接和上电；本轮不访问板端，待用户返回后再决定仅CPU算术核验所需的安全传输与运行步骤。

再续静态追踪从公开库确认Soft NN寄存器列表类型0及相邻地址合并规则；固定Pool仅能条件化推断`0x181c`单字、`0x1834..0x1860`连续12字、末尾`0x1814`单字三组。仍未取得真实packet、模型解析/后端分配、CLP解释或安全超时恢复；验收条件不变，设备执行保持`BLOCKED_BY_CONTRACT`。不因分组可推断而自动板测。

CPU-only小验证包状态`PC_STAGED_ONLY/USB_NOT_STAGED/BOARD_NOT_RUN`：三源码及SHA清单已在电脑Temp独立目录4/4复制一致、清单3/3匹配。用户在板旁且板卡上电；COM4核验当前为Linux，U盘`sda1`未挂载。下一步用户将U盘移至电脑，再以新目录暂存、回读哈希；此子阶段不涉及NPU设备，不能提升NPU-001验收。

用户随后把U盘插入电脑；CPU-only四文件已写入新目录`G:/DR1_G4B_POOL_CPU_ONLY_20260917_1/`并回读4/4一致、清单3/3通过。状态`USB_STAGED_ONLY/BOARD_NOT_RUN`；下一步Windows安全弹出并插回板卡，在板端只读核验后仅在新私有目录构建CPU自测，不运行NPU。

CPU-only子阶段已完成一次DR1 Linux限定验收：USB只读与板端私有副本各3/3哈希通过，GCC 9.3.0严格告警编译退出码0，AArch64测试ELF哈希`dd110fe2...bddc9`，一次运行输出`G4B_POOL_CPU_REFERENCE_PASS`且退出码0，USB已卸载。子阶段为`CPU_REFERENCE_BOARD_PASS_LIMITED`；NPU-001仍`DOING`，设备Pool仍`BLOCKED_BY_CONTRACT`。下一验收是独立恢复真实packet、NPU主AXI DMA与安全停止契约，不得把CPU结果记为Soft NPU结果。

复位契约新增P0门槛：IPUG166要求配置侧复位先于系统侧且各至少十周期；当前80/40MHz隔离候选生成HDL把NPU两侧复位都接到共享`Processor_System_Reset_0.peripheral_aresetn`，同时复位AXI Matrix等模块，静态上没有独立的NPU-only恢复路径。先在隔离副本冻结当前bit/HDL绑定、设计并验证双侧时序与AXI事务停止/排空，再考虑设备启动。状态`PARTIAL/STATIC_CONTRACT_CONFLICT`，不是已修复；证据见`docs/research/SOFTNPU_G4B_RESET_CONTRACT_20260917.md`。

离线对照工具`tools/npu/g4b_pool_register_candidate.py`新增条件化3组/14字软件镜像JSON并通过隔离自测，状态仍`INFERRED_SOFTWARE_MIRROR_ONLY`，不是真实packet或NPU运行。厂家库板端`dlopen`触及被遮蔽设备导致路线停止；已形成`docs/research/SOFTNPU_ASTRA_ASSIST_REQUEST_20260917.md`供独立协助，但不把推荐任务或Astra未完成工作标成通过。下一验收仍是真实包、DMA主口及安全停止证据。

传输方式待选：外部`06_eth_udp_loop`为PL UDP回环，不能直接充当Linux文件传输。板端`eth0`有链路且`sshd`运行，但PC当前只有`10.15.77.56/16` WLAN可用、无已连接有线接口，板端`192.168.137.100`从PC未通。确认RJ45实际接向及可达路由后，优先验证SSH/SCP加SHA-256，避免反复切换U盘；此前不更换bit、不改持久网络配置、不宣称网络传输已完成。

## 2026-09-13 调查验收

- NPU公开资产只读调查：DONE；报告、选择性资产版本/哈希清单、模型结构和接口差异已保存。NPU部署本身仍BLOCKED。
- 推荐下一实验：隔离PS Linux固定视频运行现有MobileNetV2＋CPU TCN，测精度、延迟和特征接口；此建议为OPEN，未自动开始。
- 官方NPU固定图、公开脚本自定义转换、目标执行、板卡操作均NOT_EXECUTED；不扩展V4R，直到IF-001验收。

## 2026-09-15 NPU-001方向复核

审查DONE。G0静态兼容核验、G1诊断v2编码和G2受限板测均已执行：v2删除任意用户MMIO、probe DMA-start和IRQ使能路径，使用独立只读ABI；权威源、PC隔离输入、U盘和板端复制均通过清单核验。板端模块/探针构建成功，默认无IRQ固定只读和`IRQF_NO_AUTOEN`登记两级均通过，且能正常卸载。当前只允许提升为`BOARD_PASS_LIMITED(v2-control-plane)`；CMA、DMA、实际IRQ、Soft算子、Hard Conv和模型执行仍OPEN。报告：`docs/research/SOFTNPU_DIRECTION_REVIEW_20260915.md`、`docs/research/NPU_STACK_COMPATIBILITY_MATRIX_20260915.md`；板测日志：`docs/records/worklog/2026-09/2026-09-15-softnpu-v2-board.md`。NPU-001保持DOING。

## 2026-09-16 NPU-001 G4a传输更新

G4a 7文件包已复制到U盘新目录`DR1_SOFTNPU_IRQ_DIAG_V1_20260916/`，源端/隔离输入/U盘7/7哈希一致，U盘清单6/6通过，已安全弹出。任务状态仍为`DOING`，G4a子阶段仅`USB_STAGED`，不得写为BUILD或BOARD通过。下一验收是板端私有目录清单核对、内核/设备树/频率/driver-unbound前置核验、隔离构建及一次250ms空闲IRQ窗口；出现事件或异常立即停止。完成IRQ、DMA、Soft/Hard算子和模型均仍`UNKNOWN`。

## 2026-09-16 NPU-001 G4a板测验收

上述传输包已在真实板端新私有目录完成清单6/6、构建及唯一一次250ms空闲IRQ观察。ABI/资源/频率和Linux IRQ→GIC硬件IRQ映射均匹配，探针退出码0、状态前后0、event_count=0，`/proc/interrupts`双核计数仍0；卸载后设备未绑定并正常关机。G4a子阶段接受为`IRQ_IDLE_WINDOW_PASS_LIMITED`，NPU-001继续`DOING`。下一任务为G4b静态契约，不自动进入DMA或算子板测。

## 2026-09-16 NPU-001 G4b启动门槛复核

IPUG166手册、当前隔离候选IP参数、冻结公开驱动和G3/G4a板测记录已只读对照。`NN_POOLING=1`与NPU配置/系统80MHz同频成立，但手册未提供Pool packet寄存器字段，也未说明超时后局部停止。G4b设备执行子阶段保持`BLOCKED_BY_CONTRACT`；NPU-001总任务维持`DOING`，未将推荐板测自动提升为执行中。下一验收工件为可双向解析的单Pool packet manifest、黄金输入/输出、三个DMA缓冲地址表、IRQ状态机和故障恢复策略，详见`docs/research/SOFTNPU_G4B_PREFLIGHT_20260916.md`。

进一步离线反汇编发现公开Pool packet生成路径把Soft寄存器偏移与`0x91000000`合成命令地址；同一公开栈的参考设备树却使用`0x1F0000000`主机侧基址，当前候选为`0x80000000`。三者不可简单视为同一地址空间；“基址不同即不兼容”的推论已撤回。内部命令地址解释和当前裁剪IP是否接受仍`UNKNOWN`，继续纳入完整packet语义验收；不得未经证明直接改写常量或启动设备。

后续静态核验确认当前候选AXI Matrix生成参数为16KiB译码，临时DTB一致，`system.address.xml`仍旧为4KiB；公开参考窗口为1MiB，兼容矩阵笔误已修正。公开Pool的packet采用CMA分配/复制/同步，随后启动并等待；等待超时只有错误/异常，尚无设备停机、复位与缓冲保留契约。NPU-001仍`DOING`，G4b执行仍`BLOCKED_BY_CONTRACT`；下一验收重点是完整packet与异常后设备不再访问内存的可审计证明，不因静态写序已知而批准板测。

新增离线packet解析器并用合成样本自测，只作为将来真实packet的结构交叉检查；没有真实包或板端算子证据。用户确认板端连接齐全且断电，无需改线，保持断电直到另行给出受控上电步骤。

G4b固定QDQ+MaxPool的ONNX/输入/输出已在隔离目录形成，PC CPU黄金算术逐值通过；尚无Arm NN解析/Alnpu分配/真实packet。公开运行库含大量自动构造函数，仅`dlopen`仍不可视为无副作用。G4b执行继续`BLOCKED_BY_CONTRACT`，下一验收不得从该CPU样本直接跳到设备start。

单Pool静态参数流已追到包地址/字数及输入/输出寄存器，且发现packet末尾另有`0x1814`项、常规包会排除start/ack寄存器；公开等待的`0x0c`掩码不能排除YOLO bit3误报。验收须取得真实包并逐entry复核、以Soft设备拥有的DMA地址核对三个不重叠缓冲、只接受NN bit2、建立超时后缓冲保持与设备停机/整板断电策略。当前均未达到设备启动许可。

软件寄存器镜像已通过公开库跳转表与枚举函数交叉核对：Soft NN `0x1800..0x18c8`逐字对应`r_SoftNPU+0x6c`，Pool标记寄存器`0x1858/5c/60`及门控`0x1854`已能追溯到填充函数。NPU-001保持`DOING`、G4b设备执行仍`BLOCKED_BY_CONTRACT`；下一步是完整entry过滤/分组和真实packet生成的离线可审计路径，不把软件镜像映射当成板测许可。

DMA地址契约新增明确约束：临时DTB仅声明`/soc`空`dma-ranges`，G3使用的公开CMA驱动绑定misc device而非Soft NPU设备。G4b三缓冲必须由Soft设备DMA API分配/映射，不能复用CMA驱动返回的裸地址或未核验的sync ioctl；随后才能核对主AXI地址/数据响应。此项仍`UNKNOWN`，不触发上板start。

Pool mode 1的公开库静态筛选已得到条件化候选entry分组（`0x181c`、`0x1834..0x1860`及追加`0x1814`），但条目数据、类型和真实包未捕获；故只把该分组记为`INFERRED`，不改变G4b`BLOCKED_BY_CONTRACT`。下一验收仍是离线真实包对照、Soft设备持有三缓冲及可审查失败恢复，而不是直接上板。

新增`tools/npu/g4b_vendor_entry_capture.c`作为下一步非设备执行的厂家entry结构捕获源码，状态`CODED_ONLY`：先私有mount/network namespace遮蔽`/dev`/`/sys`/`/proc`并降权，才加载冻结库；目标Linux编译、失败门禁与输出交叉核验均未执行。此工具只以复位镜像置Pool bit0探测结构，不代表ONNX模型真实packet。用户下一项明确操作是在板卡断电状态把U盘移至电脑供制作/校验传输包；**不是上电**，也不是批准设备start。

2026-09-17：用户已将U盘接回电脑，`G:`中确认历史DR1诊断目录；新`DR1_SOFTNPU_G4B_ENTRY_CAPTURE_20260917`目录为空。复制源码、README、SHA清单和公开`libarmnn.so.32.1`被安全审查拒绝，需用户明确确认具体介质、目的地和文件后方可重试；不以其它路径绕过。NPU-001保持`DOING`，非设备执行捕获仍`CODED_ONLY/NOT_STAGED`，G4b设备执行仍`BLOCKED_BY_CONTRACT`。

同日收到明确授权后，仅将四个指定文件复制至上述G盘新目录；回读4文件，SHA清单所列3载荷`3/3`匹配。非设备执行探针阶段为`USB_STAGED_ONLY`，下一验收是板端私有目录复制/哈希、目标Linux隔离编译和隔离失败门禁；`BOARD`与真实Pool packet仍`NOT_RUN/UNKNOWN`。G4b设备执行继续`BLOCKED_BY_CONTRACT`，不得因U盘包就请求设备start。

同日G4b**非设备执行结构捕获**首试：原TF Linux启动、U盘只读3/3哈希、板端私有目录3/3哈希、GCC 9.3编译和非root失败门禁均通过。唯一一次隔离运行因公开库未声明`libpthread`、`pthread_create`未解析而在`dlopen`停止，退出码2、JSON为0；未调用厂家entry函数，更未触发NPU设备。此子阶段记为`ABORTED_DEPENDENCY/NO_JSON`，不得写作`BOARD_PASS`。工程内源码已修订为降权后加载系统pthread，但U盘旧包未更新；下一验收为新目录传输、修订版板端编译与失败门禁、再做一次隔离结构捕获。NPU-001总任务仍`DOING`，G4b设备执行仍`BLOCKED_BY_CONTRACT`，真实packet/DMA/IRQ/恢复契约仍`UNKNOWN`。

同日修订版四文件已进入U盘独立新目录`DR1_SOFTNPU_G4B_ENTRY_CAPTURE_V2_20260917/`，目录4/4文件、清单载荷3/3哈希回读一致，旧包清单哈希未变。子阶段更新为`V2_USB_STAGED_ONLY`，不是板端捕获完成；下一动作由用户确认板卡**物理断电**、安全弹出U盘并插回板卡。随后只允许先核对新版清单、板端私有目录与隔离门禁。G4b设备执行仍不得启动。

用户确认修订包已插回断电板卡并按请求上电，但FSBL在SD卡初始化返回`0xA6000103`、`Boot device init failed`/`fsbl error: 2000007`，未进入U-Boot/Linux。串口停止监听且用户确认再次断电。非设备结构捕获子阶段现为`BLOCKED_BOOT_MEDIA_INITIALIZATION`；修订版仍未上板编译/运行，entry JSON仍无。下一验收先恢复原TF正常启动并确认稳定，不对卡写入/重刷；NPU-001总任务仍`DOING`，G4b设备执行继续`BLOCKED_BY_CONTRACT`，不能把启动故障归因于NPU包。

TF卡重新就位后的单次启动进入Linux，但FSBL有相位重试，长期稳定仍`UNKNOWN`。修订包只读/板端私有目录3/3、GCC `-Werror`编译、非root失败门禁通过。唯一一次隔离`dlopen`厂家库时因访问被遮蔽的`/dev/hard_npu`抛异常，退出码134、JSON 0字节；未调用entry函数、未加载NPU驱动或运行设备。非设备捕获子阶段改为`BLOCKED_VENDOR_LIBRARY_INITIALIZATION`。下一验收改为不触碰板卡的静态解析/隔离主机方案；不得通过恢复真实`/dev/hard_npu`、放宽namespace或直接加载公开驱动来“解决”此阻塞。NPU-001保持`DOING`、G4b设备执行保持`BLOCKED_BY_CONTRACT`。

PC静态复核确认厂家库的Hard/Soft驱动初始化函数包含设备节点读写打开、ioctl和读写映射，且另有依次调用二者的路径；本次`dlopen`异常的精确调用栈仍`UNKNOWN`。板端entry捕获路线停止，不再把旧runbook视为可执行步骤。NPU-001继续`DOING`，下一验收为PC侧可审计的entry/packet结构推导及DMA、IRQ、失败恢复契约；在这些证据闭合前G4b仍`BLOCKED_BY_CONTRACT`。

新增G4前置三缓冲子实验，状态`SOURCE_READY/NOT_STAGED/NOT_BUILT/NOT_RUN`，不改变NPU-001总状态。源码`tools/npu/soft_npu_three_buffer_diag_v1/`静态guard通过、清单4/4匹配；拟仅验证Soft设备同时拥有packet/input/output三块独立4KiB coherent缓冲，全部32位可达、64字节对齐、互不重叠，并在卸载时释放。下一验收先在新U盘目录暂存和回读哈希，再按`docs/research/SOFTNPU_G4_PRESTART_THREE_BUFFER_PLAN_20260917.md`在隔离板端目录编译/受控装载。即使通过也仅为`THREE_BUFFER_CPU_ALLOCATION_PASS_LIMITED`，不能提升为NPU master、Pool、模型或G4b启动许可。用户需在断电状态将当前U盘插到电脑，暂不要求上电。

用户已将原DR1 U盘插回电脑；新`DR1_SOFTNPU_G4_PRESTART_THREE_BUFFER_V1_20260917/`目录五文件已复制并回读，清单载荷4/4匹配。此前G4b修订包清单、80MHz候选bit/临时DTB哈希保持记录值；V2 guard为17/17。三缓冲子阶段改为`USB_STAGED_ONLY/NOT_BUILT/NOT_RUN`，NPU-001仍`DOING`，主动Pool仍`BLOCKED_BY_CONTRACT`。下一步用户安全弹出U盘、在物理断电状态插回板卡；上电/构建仍需单独前置核验。

2026-09-17三缓冲子阶段已完成一次限定板测，状态更新为`THREE_BUFFER_CPU_ALLOCATION_PASS_LIMITED`：原TF先正常启动；80/40MHz临时bit/DTB路径核验后，U盘只读及板端私有目录清单各4/4，模块目标构建退出码0、vermagic匹配；一次加载取得packet/input/output三块独立4KiB、32位且64字节对齐的Soft设备coherent缓冲，一次卸载释放并恢复未绑定。模块SHA-256=`1e1a0c8e8ac52758ec1b34ea9bbeb03a7ca10c697fee1c81f001d8b78d328d2b`；详见当日板测日志。NPU-001总任务维持`DOING`，主动Pool子阶段仍`BLOCKED_BY_CONTRACT`。下一验收先离线冻结真实Pool packet、设备主AXI地址/缓存契约及超时停止恢复，不把三缓冲CPU分配当成DMA或算子通过；暂不要求板卡接线或上电。

2026-09-17寄存器映射复核：候选 IP 元数据确认 Soft NN 的读包启动、NN 启动、Pool 配置及只读中断状态偏移；生成 HDL 为16KiB译码，但矩阵`Design.xml`仍为4KiB，之前将二者说成一致的记录已更正。基于这个冲突，本次限定验收只批准针对`0x800018b8`的一次只读响应板测，前提是原TF正常启动、候选bit/DTB/时钟复核及用户可物理断电。该测试不放行 DMA/Pool；主动G4b保持`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_G4B_REGISTER_MAP_RECONCILIATION_20260917.md`。

同日高偏移只读板测已完成：候选bit易失下载后，U-Boot单次读`0x800018b8=0`，提示符仍响应；低偏移`0x80000008=0`。该子阶段验收为`HIGH_OFFSET_RO_RESPONSE_PASS_LIMITED`，只确认该字本次可读，不等于全窗口、NPU master、完成IRQ或Pool。用户已确认物理断电。NPU-001维持`DOING`，主动G4b维持`BLOCKED_BY_CONTRACT`；后续优先恢复可审计真实packet及失败恢复契约，不自动再次上板。

同日用户新增NPU资料的官方仓库目录核验确认 `2026.1` 分支有 D20.1/D20.2/D20.3 示例，新增**只读**对照线索；D20.3 实际文件、版本配套及用户文本中的性能数值未独立核实。下一验收先取得示例的实际文件/提交并比对复位、AXI、设备树和软件栈；它不替代真实单Pool packet、Soft设备DMA及故障恢复契约。NPU-001仍`DOING`，G4b仍`BLOCKED_BY_CONTRACT`；详见`docs/research/NPU_USER_MATERIAL_REVIEW_20260917.md`。

后续本机补查得到**旧版**D20.3 `2025.1` HPF而非上述`2026.1`实际文件：其器件`DR1M90GEG484`，自带Soft NPU DTS窗口64KiB、SPI97；同批通用Linux DTS同址1MiB，当前G400候选为16KiB、SPI85。接下来须按精确HPF/TD提交与软件版本建立配套矩阵，不从旧参考bit/DTB移植到现板。该发现收紧NPU-001兼容验收，不改变`DOING`及G4b`BLOCKED_BY_CONTRACT`；见`docs/research/SOFTNPU_D20_3_HPF_VERSION_COMPARISON_20260917.md`。

同日固定Pool调用点复核：厂家库在该路径对entry生成传模式1、对打包传内部命令基址选择1，且函数遍历跳过YOLO/CSC/Resize大块。三entry/80字节预测的调用路径适用性增强，但仍未从厂家实际运行捕获任何entry或packet；本机未发现可用AArch64隔离模拟环境。NPU-001仍`DOING`，G4b仍`BLOCKED_BY_CONTRACT`。下一验收不变：独立真实包、Soft设备DMA、完成IRQ、超时停机与缓冲生命周期。

新增G4b已有包的**离线证伪器**`tools/npu/g4b_pool_packet_compare.py`，在隔离副本以合成内存包正例及五种变异通过自测；只对照条件化固定Pool镜像，不生成设备命令或证明厂家来源。真实包仍缺，NPU-001总任务`DOING`、设备执行`BLOCKED_BY_CONTRACT`不变。下一步优先取得独立厂家包供该工具解析，任何差异先查模型优化/entry语义，不可改数值凑通过。

## 2026-09-18 Astra协助交接

独立静态审阅与回复文档DONE：`SOFTNPU_ASTRA_RESPONSE_20260918.md`。推荐的P0-S1差分规格、P0-S2故障采集/ABI、P0-S3授权后解析差分、P0-H1恢复设计以及P1-M1产品层/校准、P1-E1分配/packet证据均为OPEN建议，未自动领取或运行。NPU-001状态不变，主动G4b仍BLOCKED_BY_CONTRACT；不存在本次parser修复或硬件PASS。

## 2026-09-20 NPU-001 system-DDR v0.5.4 限定板测

用户明确授权唯一一次真实RUN并接受物理冷恢复。v0.5.4/ABI `0x00010006` 在匹配80MHz bit、临时DTB、只读最小根、零旧IRQ和三块Soft设备自有coherent DDR前提下完成一次fixed Pool normal-mode作业：严格NN IRQ `0x4`、IRQ事件1、完整21项写追踪、输出`05 07 0d 0f 00 00 00 00`，packet/input/padding/guards均通过。三块4096字节缓冲回收后在电脑逐字节比较均为0差异；未卸载、未重试、未运行packet-DMA，用户已确认物理断电。子阶段更新为 `BOARD_PASS_LIMITED(fixed Pool normal DDR)`，NPU-001总任务仍为`DOING`；不得扩大到其它算子/shape、packet-DMA、HardNPU、官方runtime或模型。下一验收先定义最小Hard Conv/GEMM或受控Soft扩展的地址范围、黄金输出、错误/超时冷恢复和无CPU回退证据，再决定是否申请新的单次板测。

## 2026-09-20 NPU-001 Sol→Astra方向决策交接

已更新根 `SOFTNPU_ASTRA_HANDOFF_20260919.md`，把旧S0～S7待执行状态替换为当前证据表，并登记真实模型派生最小Hard Conv夹具：CPU金样通过，厂家parser/Optimize/packet与硬件均未运行。当前请求Astra在H1（优先Hard Conv）、S8（先补Soft packet-DMA）和R1（先做正式runtime受控分区）间给出证据化判断，随后由Sol实现。NPU-001继续`DOING`；推荐路线不得在Astra回复前自动写成硬件GO或BOARD_PASS。







