# 2026-10-09 常驻C128环与实时重叠

## 2026-10-09 常驻C128环接续

experiments/sol_resident_ring_20261009：最小stream_consumer回调复用通过的逐帧入口、bit/驱动/冻结模型，未改量化。一次初始化706.840207ms，32张不同真实保存图像各算一次，512 Hard START、FRONT96 32、DW144 64、DW16 32，Soft/V4R硬件0；其余空间/残差/真实C128 TCN由CPU。64x128环32768B；两个完整16帧窗口原观察跨度3.011690460/2.825742328秒，分类不重复空间计算。两段4096特征与分类对独立板CPU零差，第二段实际新算参考。处理12181.133341ms，单图中位377.262259/p95 380.135433ms，非实时持续fps/自动动作结束，质量NOT_CALIBRATED。

只读相机预检camera_preflight2.log已确认CSI/ISP增长、I²C历史error false。实时live_input1相对导入preprocess失败，未START；live_input2已修复。核验ABI0x42341910/phase0/writes0/irq0/work0/MODEL_READY1后旧模块guard PASS卸载；修正版新实验CPU0 PID1066 python3异步SError code bf000002、PC4b7f6c，Linux panic。host串口日志live_run_serial4.log保留；具体START数/首帧完成及根因UNKNOWN，不认定并发或DDR。32原始结果尚未备份，panic后暂不能取回；host运行/独立零差核验日志可用，证据边界明确。

实时重叠DOING/物理恢复PENDING，已请求用户，确认前不重试未知DMA。下一候选live_input3/resident_resume3 CODED/生成Python编译通过、BOARD PENDING：仅对实际失败访问加少量可选UART阶段标记，RESIDENT_CAPTURE_FIRST=1先运行模型仅加载的采集对照，通过后再重叠并以新输入独立CPU验收。restore_resident.sh只恢复文件，不加载模块或START；复用USB span编译包、现有模型和工具，不新增驱动/bit。CPU单图约380ms仍超33ms；T30-5数据条件不变，不以排队或弱样本称30fps/质量达标。

HEAD实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空，无提交；整体基线/原工程/外部snapshot完整性UNKNOWN。总目标保持active，显示延后。详情见docs/records/worklog/2026-10/2026-10-09-sol-resident-ring.md。

## 修改与准备

- prepare.py/candidate/run_hard_soft_clip.py：仅加入原factory回调；feature_ring.py/run_resident.py：有限真实特征历史及完整跨度采样；prepare_reference.py/run_reference2.py复用独立CPU算术计算新输入。
- prepare_live.py：原headless冻结采集接私有小图/原预处理与来源信息，固定最多16份spool，单采集子进程加串行空间执行。独立导入修复是普通软件错误；早期状态脚本路径缺模块/numpy，没有设备提交，最后按准确ABI标准库读取状态通过。实际SError不绕过保护、不自动重试。
- next live_input3.tgz：9889B/SHA4ac028a1d3e8f5083099d293fbe67b91fe9e239957a6249930e01c22f9ccd8b2；RESIDENT_CAPTURE_TRACE=1直接留UART访问标记，防panic后无法取回/run。RESIDENT_CAPTURE_FIRST=1明确capture_compute_overlap=false，不冒充重叠验证。
- prepare_resume.py/restore_resident.sh：文件恢复包resident_resume3.tgz 18696B/SHAaf034a71737ee712d243104434ada05f93ef028ee0146a482a9eccc8f7d09e23，生成编译通过，未上板。原始live_input1/2保留。
- 新候选待用户恢复后执行：既有临时bit/DTB/80MHz恢复→已编译span文件恢复→模型仅加载的采集对照→明确首个坏访问/通过后重叠→新16帧独立CPU比较→及时归档USB。非泛化诊断平台。

AGENTS/status/backlog/前一阶段日志/30fps施工单相关条款已读或复用。未写Flash/saveenv，未改原工程/基线，无数据下载/模型训练/新bit/新驱动/提交。当前硬件故障需用户物理恢复，未暂停或完成总目标。

### 2026-10-09 后续：共享GP冲突已确认，最小互斥CODED

现用sol_block34_dw_split_20261008/net_pl_control.v:96在任一PL任务pending/fault时拒绝所有写，包含0x140采集控制。新生产者在PL作业期间暂停/恢复采集确有接口冲突；是否为本次SError原因仍INFERRED，未板测确认。

下一候选更新为live_input4/resident_resume4。gp_write_gate.py仅在实时入口使完整FRONT96、两DW144、DW16调用与四处采集控制写互斥；CPU/只读/Hard独立寄存器继续重叠。实际PL异常后拒绝进一步GP写，保留原DMA/完成/失败pin；锁等待计时进入结果，不包装为吞吐提升。未改bit/驱动/数学。生成Python编译通过、BOARD PENDING，归档哈希见本stage qualification.json。

恢复后先运行probe_gp_gate.py /run/gp_probe1.lock（仅Linux跨进程文件互斥/失败拒写、零设备访问），再TRACE/CAPTURE_FIRST采集对照→真实重叠→新输入独立CPU比较。WSL查询返回REGDB_E_CLASSNOTREG，无可用本机Linux环境，不安装系统，probe未运行。用户新物理恢复确认仍PENDING，未知设备不重试，总目标active。

