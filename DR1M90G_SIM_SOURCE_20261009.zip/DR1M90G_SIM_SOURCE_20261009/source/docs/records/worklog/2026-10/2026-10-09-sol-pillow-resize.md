# 2026-10-09 T30-3原滤波的小图缩放核

## 后续：实际接入四像素CDC、小图写入与原识别入口

阶段末P&R完成（会话92977/79063均已结束，无运行构建）：47971 slices/156 ERAM/186 DSP。raw SWNS-0.317/HWNS-1.198全为原FIFO灰码/复位一级、flags一级和PS复位外部一级；物理打包名可能与实际寄存器不同，prepare_first_stage.py同时读取reg或LUT1(reg)的接收输出网定位原external[0]，没有按reg[1]名字误判后级。31条实际一级路径，首次复核只剩原FIFO写侧asy_w_rst0.asr removal-0.159，再纳入同一复位一级规则，first_stage_small2 SWNS+0.103/HWNS+0.024/TNS0。新缩放、网络和AXI路径保持timed；STA coverage64.82%、外部MIPI接收clock不在clock summary，不宣称全部IO/接收域时序通过。未bit/下载/BOARD。

原camera_preflight2日志每0.1s计数5~6，说明约50fps来源；其全量像素平均预算超过80MHz一像素服务。此次32us/行28.94fps仿真不能代表实际行突发，单请求不能自动消除单帧内积压。已明确不拿此80MHz候选直接做完整采集验收，下一直接提升处理吞吐并保持原Q22数学/匹配现有时钟、复用FIFO；或用实际行节奏匹配足够处理预算。不能只改纵向空白后假定活跃行间隔改变，也不能藏丢帧或加完整高清缓存宣称30fps。目标仍active，本轮属于实际CODED/SIM/SYNTH/P&R进展；故障板卡确认条件未满足，不操作。

本轮新增isp_pixel_serial.v，原sfifo宽度104/26转换，第一像素SOF和第四像素行末随数据存储；BGRX→低字节R的RGB顺序已由实际原图验证。固定完整1920×1080/480拍每行，单请求一整帧；无背压源溢出或畸形行粘滞报错，不向缩放核继续发布有效数据。此版本不声称处理全部50fps源，也不隐藏丢帧；实际相机配置/速率与容量需板测确认。

isp_sim1.log：两张不同真实1080p原图、100MHz写/80MHz读、每行480拍突发加空白总32us（28.94fps）仿真，两份源各2073600像素、输出各50176/共100352像素与Pillow参考零差，原/小图标记通过，连续两次请求不复位。isp_fault1.log：小FIFO人为满和首拍错误行末均明确粘滞停止输出。small_fdma3.log：直接喂第一张真实224输出验证原uidbuf新W_DATAWIDTH32/W_XSIZE224/W_YSIZE224，50176像素、448次56拍、200704B、地址0xa800000首槽1全部正确；假FDMA仅RTL、不等于真实DDR。原uidbuf重复声明/声明晚于使用导致Icarus编译失败，prepare_uidbuf_sim.py仅对仿真副本做声明清理，厂家项目仍原文件。

prepare_integration.py生成integrated项目，读取现有隔离DWsplit源码，仅新top与net_pl_control版本/三个小图标识寄存器单独生成。原PS/PLL/管脚、Hard/PL/NPU驱动、commit guard和三槽保留区不改。新文件初次无CompileOrder使厂家打开工程失败，补120/121后build_small2.log真实整合gate通过，44916 slices、156 ERAM、186 DSP；旧同gate43045/150/174，不能和旧P&R46932直接比较。physical_small.tcl沿既有物理流程已启动，输出physical_small1.log/后续place-route至独立目录，P&R仍进行中，无bit/下载/BOARD。

small_frame.py将完整200704B BGRX直接原FLOAT32归一化为独立CHW。prepare_small_runtime.py派生已准备live_input4入口，强制新FST1 0x10006和224几何/AA22标识，原状态/世代/冻结完成/GP锁保留，拒绝第二次mapped resize。small_runtime1.tgz18229B/SHA9d5c43d5d367c27a30bbf7493ccd57030ba289213188529922436fc003c30389；生成Python编译通过，BOARD NOT_RUN。verify_small_tensor.py三张真实完整1080p与原Pillow+归一化比较，451584浮点元素零差，PC归一化0.609~0.719ms，不是板端或整链提速。原模型/NPU数学及默认入口未更改；此前约380ms/图问题不因小图仿真通过自动解决。

本轮用户消息引用旧Hard超时重启问题，无法确认在最新实时重叠panic之后物理恢复；已一次请求澄清，无设备访问/自动重试。收到关联最新故障恢复确认后，先复用旧bit做GP文件互斥及模型加载采集对照，再真实重叠/及时备份。缩放候选先取得实际时序验收，随后板端一帧与原输入对照，不替代故障修复或全网30fps/质量验收。

阶段证据integration_qualification.json；run_first_small.sh仅供实际时序验收/正确bit/恢复配置完成后，调用原采集入口保存一帧224 PNG及原模型输入；脚本CODED、未板测，不下载bit/加载NPU/复位/释放保留DDR。目标active。无Flash/原工程构建/覆盖基线/提交；整体基线与外部snapshot完整性UNKNOWN。阶段末实查HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c、cached diff空，无新增提交。P&R运行会话92977可续取，当前已进入实际route，不重复启动。

物理恢复确认尚未收到，不重试此前panic的设备；目标active。上一轮共享GP互斥是实际代码进展，本轮沿30fps施工单T30-3推进真实像素数据通路，不创建额外诊断平台。

## 新增功能及实际验证

experiments/sol_pillow_resize_20261009/pillow_aa_224.v固定1920x1080→224x224，水平/垂直两遍UINT8舍入，Q22系数、边界归一化，与当前Pillow双线性抗混叠匹配。两个水平累加槽、两个小图行累加银行，不存完整高清帧；串行1像素/时钟。系数高4位用明确移位加法保持精度，低18位乘法，不通过减精度凑资源。

prepare.py从真正1080p相机记录读取三张不同图像，不扩张256输入伪造原图。SHA及来源保留reference.json：camera_frame1首帧、camera_clip16首/末帧。PC Pillow12.3.0与独立整数参考三张全部零差；RTL sim1.log三张各50176像素、共150528像素全部零差，帧起点/行结束标记通过，加入每行气泡且不重置核连续跑三帧。不是板端采集率或持续30fps证据。

现有iverilog/vvp 13.0实际可运行，沿用现有允许工具，不修改Windows策略/安装软件。仅worktree仿真。厂家TD6.2.1独立elaborate/RTL/gate综合已完成：1834 slices、17 ERAM、12 DSP。当前整工程46932/52480 slices、150/280 ERAM、174/240 DSP；单核理论资源有余量，但不能把数值相加当作整工程布局布线/时序通过。读取两份ROM hex在综合日志有明确记录；ROM无driver警告及无独立IO管脚警告保留，未新增端口管脚约束/未做bit。独立core SYNTH与已有整工程BOARD不能合并宣称新候选上板。

## 边界与下一动作

未改主链默认输入、模型、V4R或NPU驱动，未生成/下载新bit，不访问故障板卡、Flash或原工程。CPU/Hard/PL层分工和已通过常驻32帧结果不变。25.92ms仅80MHz下1920x1080个串行输入像素的算术下限，非实际板端预处理、传感器fps或整网速度；任务独立质量仍NOT_CALIBRATED，板端Pillow输入比较PENDING。

当前独立核尚缺真实128位四像素ISP→串行像素的弹性跨时钟接入，以及224小图写入现有受控FDMA/匹配ABI。原ISP输出不受下游I_tready约束，不能只用移位寄存器假装四像素可直接降成1像素/时钟；下一必须沿现有FIFO/帧边界接入，记录溢出而不隐藏丢帧。实际sensor速率与80MHz服务预算需用原探针/真实帧号核验，再决定接法，不能宣称全相机速率已处理。

下一板测优先仍是用户物理恢复后probe_gp_gate文件互斥→已加载模型采集对照→真实重叠与独立CPU；不要为新缩放候选跳过已发生总线故障恢复或替换已通过PS关系。T30-3继续隔离实现，不整体替换SoC。

读取AGENTS/status/backlog/当前日志/施工单和现有camera/FDMA/area接口；算术依据[Pillow原始实现](https://github.com/python-pillow/Pillow/blob/11.3.0/src/libImaging/Resample.c)，本机12.3实际对照，不把来源版本当作板端版本。无Git提交；此前实查HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，当前未重查，整体现有基线/原工程/外部snapshot完整性UNKNOWN。
