# 2026-10-09 缓冲修正版与逐帧混合整链

## 实际跑通

- 用户物理重启已确认；恢复root/root登录及既有易失80MHz/保留DTB/CRP脉冲/同dwsplit bit。第一次JTAG因5555服务未运行未下载，复用已有OpenOCD/D2XX后下载完成并关闭服务。新临时boot39c9c0f4-6301-4a36-81eb-1aab7a309a67。
- /run清空后从USB恢复既有冻结包，重新目标编译之前已CODED的block34_span_fixed/space16_span_fixed。block ko SHA9bc4d9627a4118ec6f6a55136404cb4e633591d444ee4399e0b7e4835d450769；main SHAa6c4edb8690f0289f5dc19413dcd32ef641ca9bf369872df4b2481bc3b713c0d。原Module.symvers/clock-skew警告保留。
- ABI0x42343410/0x42341910，固定input153216/allocated155648，large output454656、small28672按冻结slot使用；全部活动缓冲同步/guards/地址/IRQ/失败pin保持。packet/weight/量化不改。prepare_resume.py修复块运行脚本缺import json并复制真正已通过runtime匹配新ABI。
- 完整块三次62.848950/57.083791/56.906940ms，四逻辑PW/六Hard START、两PL DW、一CPU Add；输出逐字节零差，全部18 START/release通过。
- 同真实16保存图像SHA4701269159219088f9f0cf17a1a16872b3b81c6403bbc7c383d550fb9edc8113，整链6047.195100ms，较同数学6393.125194ms少345.930094ms/5.410970%。完整2048特征/C128及logits对既有独立板CPU参考零差。256 Hard（前段96），PL DW14432、FRONT96/DW16各16，Soft/V4R硬件0，CPU剩余空间/残差及真实C128 TCN。初始化1219.491ms/准备64.301ms单列。结果“过敏”仅候选回归，无动作标签/独立质量，NOT_CALIBRATED。
- prepare_batch_probe.py：冻结首段CPU节点/权重、仅改批维1/2/4，对同16真实输入，与batch16输出零差；三次中位每图31.942206/30.207927/30.014475/29.683197ms，不宣称小batch提速或全网fps。
- prepare_framewise.py：三CPU图仅批维16→1、参数/节点原样、NEON9复用；一次加载16组Hard参数，0..5和6..15仅在已release边界交替。每张图片完整空间计算后进入原16x128入口，已实际BOARD通过。6158.306791ms，中位单帧381.818584ms/p95 386.220762ms；2048特征/分类对独立CPU与6047批量结果均零差。较批量慢111.112ms；保留逐帧接入用途，非加速默认，未把保存帧回放宣称持续视频fps。
- 两次整链guard PASS/正常卸载，模块为空，无需要物理恢复的状态。未新增Flash/bit/原工程构建/数据下载/模型训练。

## 修改与证据

- experiments/sol_block34_buffer_20261008/prepare_resume.py、prepare_batch_probe.py、prepare_framewise.py、restore_span_from_usb.sh；原prepare.py/candidate缓冲源码沿用上一轮，不重新改模型。文件恢复脚本CODED/板端sh语法通过并保存USB，完整冷启动重放未执行。
- board_20261009/evidence1.tgz 82261B/SHA2c332d784ef584154a8d0808607f1b5b21b8ba7e8f6cf09a39a44f7373e5a139，实际runtime、块与整链输出已取回/evidence。
- board_20261009/framewise_evidence1.tgz 61352B/SHAf371b7413a5ddb3d133261d7ffb5ec45445a8ca89c27645c0e593f7accbf1e51，逐帧runtime/输出与CPU批量报告已取回/framewise_evidence；host再次比较两条整链features零差。
- USB BLOCK34_SPAN_20261009_1新增目录，所有源包/编译包/证据已sync/只读；span_compiled1.tgz353911B/SHA1d64cffe490714c60490575ccdc7937942f67d0e17ab8d9d7b667e1286cc90b2。

## 边界与下一动作

当前模型分支改善5.411%，仍慢于另一数学候选5803.249ms；原数学6354.254ms回退保留，未覆盖默认/质量基线。10/15/30fps未达；显示DEFERRED。

CPU中段2428.092ms/16、总CPU前段3309.813ms/16，完整前块仍约57ms/图。下一直接复用逐帧入口做有限常驻/真实C128特征环，不通过复制图片、压缩动作跨度或队列掩盖服务时间；T30-5若触发则选硬件友好学生/量化。CSL-500尚未提供，用户禁止代下载，独立质量训练/验收数据仍是外部条件；12段弱样本只作回归。

已读取工作副本AGENTS/current status/backlog/最新相关日志/接口及30fps计划。HEAD实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c、cached diff空，无提交；整体基线/原工程/外部snapshot完整性UNKNOWN。目标active，本轮无暂停/完成操作。
