# 仿真源码与硬件接口交付记录

## 2026-10-09 单帧ASL转向讨论与仿真源码交接包

用户最新方向为单帧ASL英文24字母（排除J/Z），前一轮仅方案分析；本轮仅要求整理硬件接口/RTL/testbench/约束源码包。新24类模型、持续帧率和实体显示均未新增验收；原空间/时序/视频已有成果保持原证据边界，不自动继续旧动态词优化任务。

DELIVERY：[DR1M90G_SIM_SOURCE_20261009](C:/Users/16429/.codex/visualizations/2026/10/09/01a11f12-9dd9-7002-a5d5-ce9b311f58fc/DR1M90G_SIM_SOURCE_20261009/README_CN.md)。来自活跃副本逐文件哈希导出，包含当前0x42341910/独立0x42343410驱动、16项实际packet/weight、张量/量化参考、DWsplit集成RTL/SDC、单像素缩放及真实向量、双像素失败候选与相关日志。便携离线入口run_sim.py和check_bundle.py；本次最终仿真/依赖/哈希验收以包内verification为准。HardNPU内部RTL/周期精确模型未找到，不能把接口数学或PL模块仿真升级为硬核周期/完整SoC性能证明；厂商库与许可证不打包。

未上板、未写Flash、未构建原工程或覆盖基线，只有交付副本离线检查与本条文档记录。Git命令在受限环境拒绝访问，工作树HEAD元数据读得2685d5f4e21bb91b31a52dbde8527c59acd0964c；未创建branch/commit/tag。整体基线、原工程与外部快照完整性未全量复核，UNKNOWN。下一步为接收方据本包对齐新单帧模型，芯片周期/资源/时序待相应环境和实际证据，不因打包自动启动。

读取：活跃副本AGENTS、PROJECT_STATUS、BACKLOG、最新工程汇总/常驻/缩放日志、HW_SW_INTERFACE、BUILD，以及当前驱动/作业/RTL/SDC/bench原文。

修改：工程可执行源码未修改。交付根目录新增中文README、接口与时序说明、跨主机离线仿真入口、依赖/资产核验入口、manifest和验证记录。记录更新本文件及status/backlog。

验证：源码逐文件SHA-256与归档CRC、16项packet/weight长度及已有hash、两个主要工程File引用闭合检查、模块级RTL复跑；实际结果见交付包verification。初次图像bench编译器在受限环境0xC0000005异常，不归为RTL数值失败；后续隔离复跑结果单列。

未执行：真实设备访问、加载模块、下载bit、Flash、厂商综合/P&R、完整SoC仿真、新模型训练。风险：原脚本可能保留绝对路径，完整SoC仍需厂商原语/设备库；独立PL bench不能预测HardNPU内部时序或真实DDR争用。
