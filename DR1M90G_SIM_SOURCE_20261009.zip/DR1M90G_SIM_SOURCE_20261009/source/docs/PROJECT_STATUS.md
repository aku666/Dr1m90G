# Project Status

## 2026-10-09 单帧ASL转向讨论与仿真源码交接包

用户最新方向为单帧ASL英文24字母（排除J/Z），前一轮仅方案分析；本轮仅要求整理硬件接口/RTL/testbench/约束源码包。新24类模型、持续帧率和实体显示均未新增验收；原空间/时序/视频已有成果保持原证据边界，不自动继续旧动态词优化任务。

DELIVERY：[DR1M90G_SIM_SOURCE_20261009](C:/Users/16429/.codex/visualizations/2026/10/09/01a11f12-9dd9-7002-a5d5-ce9b311f58fc/DR1M90G_SIM_SOURCE_20261009/README_CN.md)。来自活跃副本逐文件哈希导出，包含当前0x42341910/独立0x42343410驱动、16项实际packet/weight、张量/量化参考、DWsplit集成RTL/SDC、单像素缩放及真实向量、双像素失败候选与相关日志。便携离线入口run_sim.py和check_bundle.py；本次最终仿真/依赖/哈希验收以包内verification为准。HardNPU内部RTL/周期精确模型未找到，不能把接口数学或PL模块仿真升级为硬核周期/完整SoC性能证明；厂商库与许可证不打包。

未上板、未写Flash、未构建原工程或覆盖基线，只有交付副本离线检查与本条文档记录。Git命令在受限环境拒绝访问，工作树HEAD元数据读得2685d5f4e21bb91b31a52dbde8527c59acd0964c；未创建branch/commit/tag。整体基线、原工程与外部快照完整性未全量复核，UNKNOWN。下一步为接收方据本包对齐新单帧模型，芯片周期/资源/时序待相应环境和实际证据，不因打包自动启动。

## 2026-10-09 用户要求的工程总览已整理

总览：[ENGINEERING_COMPLETION_SUMMARY_20261009.md](C:/Users/16429/.codex/worktrees/19de/fdma_imx415_20251008/docs/ENGINEERING_COMPLETION_SUMMARY_20261009.md)。汇总已完成的单图128D、真实16帧/常驻32帧、Hard/Soft/PL分工、真实C128 V4R和历史摄像头→实体屏三窗成果；当前约2.6fps，质量/拒识与持续30fps未完成，最新实时panic后的恢复仍待确认。本次仅整理，不新增板测或暂停目标。

补充最新双像素候选证据边界：sol_pillow_resize_pair_20261009实际整合gate完成46113 slices/156 ERAM/192 DSP，尚未P&R/BIT/BOARD。sim1.log四处readmemh失败，长文件名截断使真实输入/参考未加载，随后PASS标记无效，数值SIM不能记通过；下一修复bench文件名、文件打开/未知值拒绝并重跑。下节单像素版有效SIM/P&R成果不受影响。

## 2026-10-09 T30-3小图入口SIM/整合P&R完成，输入服务预算仍待修复

后续实际P&R已结束：47971/52480 slices（91.41%）、156 ERAM、186 DSP。原始SWNS-0.317/HWNS-1.198ns全属既有同步器第一级；按本次实际接收输出网复用31个精确原CDC/复位一级例外，后级及缩放/DW/AXI数据路径不豁免。first_stage_small2最终SWNS+0.103/HWNS+0.024ns、TNS均0；STA coverage64.82%，外部MIPI接收时钟不在clock summary，不能声称完整IO时序证明。未bit/BOARD。

当前吞吐限制不能由单请求掩盖：既有camera_preflight2实测0.1s约5~6帧，约50fps输入完整像素量超过80MHz串行预算。28.94fps仿真通过不证明当前源帧内不会溢出；下一直接提升缩放处理吞吐/实测行突发匹配，先不生成并下载该80MHz候选做完整帧验收。模型/原数学不变，原GP恢复板测仍待最新panic后恢复确认。目标active，不暂停。

sol_pillow_resize_20261009已新增isp_pixel_serial：复用原sfifo，128位BGRX四像素→104/26位弹性CDC→串行RGB原Q22缩放；一次enable请求只接收一张完整1080p，低电平重装，不隐藏溢出或错误行。两个100/80MHz时钟、每行32us的仿真输入（28.94fps，非实际sensor）下，两张不同真实原图全部100352输出像素零差；溢出与错误行均粘滞停止有效输出。小图uidbuf仿真50176像素/448次56拍/200704B/首槽1全部正确；仅仿真副本调整重复声明及五项声明位置，综合原uidbuf未改。

integrated候选只修改视频输入、小图几何和匹配FST1 ABI0x10006；现有PS/PLL/管脚/NPU/完整AXI B完成及三块8MiB保留槽复用。实际整合厂家gate综合44916/52480 slices、156/280 ERAM、186/240 DSP（对应旧gate43045/150/174，不能和P&R资源混比）；P&R结果及服务预算见本节顶部，未生成/下载新bit，BOARD PENDING。small_runtime1仅接受224 BGRX/新ABI，复制200704B并CPU原归一化；三张真实原图完整预处理共451584浮点元素零差，PC0.609~0.719ms，不是板端耗时。模型、数学、默认运行入口未变；整网仍约380ms/图，30fps及独立质量未达到。证据integration_qualification.json。

最新实时重叠panic尚未收到可关联的物理恢复确认；本轮用户重启消息引用旧Hard超时问题，已请求确认是否在最新panic后恢复，不操作未知设备。恢复后先用既有bit验证GP互斥/采集对照，再考虑已完成时序验收的小图bit。目标active，未暂停。

此前单核证据仍保留：sol_pillow_resize_20261009固定1920x1080→224x224 Q22双线性抗混叠，两遍原UINT8舍入，两个小图行银行，无全高清帧缓存。三张不同真实相机1080p保存图，整数参考及RTL共150528输出像素与当前PC Pillow全部零差，行/帧标记通过；独立综合1834 slices、17 ERAM、12 DSP。当前集成进展以上述两段为准；25.92ms仍只是80MHz串行输入像素数下限，不是实测提速。原默认预处理/数学/NPU未改，当前panic仍待关联物理恢复确认。目标active，质量/持续fps尚未达，日志2026-10-09-sol-pillow-resize.md。

总目标active。2026-10-09常驻32张真实保存帧/C128环已BOARD通过，两个窗口共4096特征及分类与独立CPU零差；一次加载，12181.133ms，单帧p95 380.135ms。实时重叠修复导入后触发异步SError/内核panic，实时16帧未验收，已请求物理恢复；确认前不重试设备。缓冲版6047.195ms/16与其他数学候选/原数学回退保留，持续10/15/30fps、独立质量未达到，显示DEFERRED。

### 2026-10-09 后续：共享GP冲突已确认，最小互斥CODED

现用sol_block34_dw_split_20261008/net_pl_control.v:96在任一PL任务pending/fault时拒绝所有写，包含0x140采集控制。新生产者在PL作业期间暂停/恢复采集确有接口冲突；是否为本次SError原因仍INFERRED，未板测确认。

下一候选更新为live_input4/resident_resume4。gp_write_gate.py仅在实时入口使完整FRONT96、两DW144、DW16调用与四处采集控制写互斥；CPU/只读/Hard独立寄存器继续重叠。实际PL异常后拒绝进一步GP写，保留原DMA/完成/失败pin；锁等待计时进入结果，不包装为吞吐提升。未改bit/驱动/数学。生成Python编译通过、BOARD PENDING，归档哈希见本stage qualification.json。

恢复后先运行probe_gp_gate.py /run/gp_probe1.lock（仅Linux跨进程文件互斥/失败拒写、零设备访问），再TRACE/CAPTURE_FIRST采集对照→真实重叠→新输入独立CPU比较。WSL查询返回REGDB_E_CLASSNOTREG，无可用本机Linux环境，不安装系统，probe未运行。用户新物理恢复确认仍PENDING，未知设备不重试，总目标active。

## 2026-10-09 常驻C128环接续

experiments/sol_resident_ring_20261009：最小stream_consumer回调复用通过的逐帧入口、bit/驱动/冻结模型，未改量化。一次初始化706.840207ms，32张不同真实保存图像各算一次，512 Hard START、FRONT96 32、DW144 64、DW16 32，Soft/V4R硬件0；其余空间/残差/真实C128 TCN由CPU。64x128环32768B；两个完整16帧窗口原观察跨度3.011690460/2.825742328秒，分类不重复空间计算。两段4096特征与分类对独立板CPU零差，第二段实际新算参考。处理12181.133341ms，单图中位377.262259/p95 380.135433ms，非实时持续fps/自动动作结束，质量NOT_CALIBRATED。

只读相机预检camera_preflight2.log已确认CSI/ISP增长、I²C历史error false。实时live_input1相对导入preprocess失败，未START；live_input2已修复。核验ABI0x42341910/phase0/writes0/irq0/work0/MODEL_READY1后旧模块guard PASS卸载；修正版新实验CPU0 PID1066 python3异步SError code bf000002、PC4b7f6c，Linux panic。host串口日志live_run_serial4.log保留；具体START数/首帧完成及根因UNKNOWN，不认定并发或DDR。32原始结果尚未备份，panic后暂不能取回；host运行/独立零差核验日志可用，证据边界明确。

实时重叠DOING/物理恢复PENDING，已请求用户，确认前不重试未知DMA。下一候选live_input3/resident_resume3 CODED/生成Python编译通过、BOARD PENDING：仅对实际失败访问加少量可选UART阶段标记，RESIDENT_CAPTURE_FIRST=1先运行模型仅加载的采集对照，通过后再重叠并以新输入独立CPU验收。restore_resident.sh只恢复文件，不加载模块或START；复用USB span编译包、现有模型和工具，不新增驱动/bit。CPU单图约380ms仍超33ms；T30-5数据条件不变，不以排队或弱样本称30fps/质量达标。

HEAD实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空，无提交；整体基线/原工程/外部snapshot完整性UNKNOWN。总目标保持active，显示延后。详情见docs/records/worklog/2026-10/2026-10-09-sol-resident-ring.md。

## 2026-10-09：缓冲修正版接整链与逐帧入口BOARD通过

用户确认物理重启后恢复COM4 root登录，普通Linux boot01a0be32确认无模块；沿用授权恢复既有保留DTB/80MHz/CRP启动脉冲、临时JTAG dwsplit bit，进入只读临时Linux boot39c9c0f4-6301-4a36-81eb-1aab7a309a67。JTAG第一次因5555服务不存在未下载，复用已有厂家OpenOCD/D2XX服务后chip validation及下载完成，服务随后关闭；没有Flash/saveenv/新bit/原工程构建。重启已清空/run，故恢复旧USB包并重新目标编译新候选，历史Module.symvers/clock-skew警告保留。

sol_block34_buffer_20261008：独立block ABI0x42343410、整链ABI0x42341910，仅输入分配155648B和两种真实输出分配454656/28672B，按冻结slot选择；全活动缓冲同步/guard/真实DMA/IRQ/失败pin均保留，冻结packet/weight/量化未变。修复原块脚本缺import json的实际运行路径。完整块三次输出逐字节零差，62.849/57.084/56.907ms，18 START全部完成/release；同真实16帧256 Hard（前段96）、32 PL DW144、FRONT96/DW16各16、Soft/V4R硬件0，剩余空间及真实C128 TCN由CPU完成。完整2048特征及logits与既有独立板端CPU参考零差，6047.195ms vs同数学6393.125ms，少345.930ms/5.411%。这仍慢于另一数学候选5803.249ms；不以不同模型相互替代质量或速度基线。初始化1219.491ms、输入准备64.301ms单列，6047.195ms不是冷启动用户耗时。

T30-4最小逐帧入口prepare_framewise.py已实际运行：全部CPU模型仅批维16→1、节点/权重原样、复用已有NEON9；一次加载16组Hard参数，每帧在已释放0/6边界串行切组，完整空间计算后进入原C128 TCN。没有先算16张前段再分配平均时间。16张原真实图像各算一次、特征/分类仍零差，6158.307ms，单图中位381.819ms/p95 386.221ms，初始化706.793ms。它比批量版慢111.112ms，保留为逐帧接入候选，不宣称提速或持续fps/特征环完成。首段CPU固定batch1/2/4/16对照均零差，中位每图31.942/30.208/30.014/29.683ms；小批量无显著吞吐收益。

两条整链guard PASS/正常卸载，当前modules空，无恢复请求。USB BLOCK34_SPAN_20261009_1已sync/RO，编译归档353911B/SHA1d64cffe490714c60490575ccdc7937942f67d0e17ab8d9d7b667e1286cc90b2；主证据82261B/SHA2c332d784ef584154a8d0808607f1b5b21b8ba7e8f6cf09a39a44f7373e5a139，逐帧证据61352B/SHAf371b7413a5ddb3d133261d7ffb5ec45445a8ca89c27645c0e593f7accbf1e51已取回board_20261009。restore_span_from_usb.sh文件恢复入口已CODED/板端sh语法核验通过并保存USB，完整冷启动重放未验收；已通过实际运行入口在证据目录。当前独立质量与拒识NOT_CALIBRATED，真实持续10/15/30fps未达到。

直接瓶颈已从失效START转为原网络服务时间：本分支CPU中段2428.092ms/16、CPU前段总3309.813ms/16，完整前块仍约57ms/图。下一按T30-4/5把当前逐帧入口用于有限常驻/真实特征环，不靠线程隐藏超预算；若完整流优化仍不能接近33ms，转入计划允许的学生/量化路线。CSL-500尚未提供、用户禁止代下载，独立训练/验收数据是质量阶段实际外部条件；不以12段弱回归代替质量。总目标保持active。

AGENTS/current status/backlog/相关接口及最新30fps施工单已复用读取。HEAD实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c、cached diff空，无提交；整体基线/原工程/外部snapshot完整性UNKNOWN，不声称干净。

## 2026-10-08 20时后：BLOCK34成本分解与复制修正版已实际接整链；无确认整链收益

sol_block34_cost_20261008/run_cost.py复用已通过块fixture/bit/驱动，六Hard/两PL DW输出零差且正常释放；单块69.047ms。Hard SET输入1.926、RUN12.693、export1.211、release2.228、cold状态0.322ms，PL DW host18.421/9.337ms、CPU Add3.328ms，其余约19ms用户态处理。CPU现有CRC451584B约1.867ms/次；不把剩余全部归因CRC或AXI，设备核心和调用耗时已分清。

修改prepare_io生成同ABI同步输入直接传连续numpy指针、输出copy_to_user直达独立numpy数组、原CRC/释放保留；用户数组不是DMA别名，SET_INPUT仍由内核同步复制并持有自己的DMA/ref。单块63.596ms/逐字节零差，仅两次fresh单样本，不作持续提速结论。prepare_main_io把相同改动直接接原head23全16入口：全部2048特征/C128、前段tail_inputs零差，368 Hard/new112、原PL各16。整链5804.641 vs5803.249ms，未确认收益，NOT_ADOPTED，保留此前5803.249ms可运行候选及原数学6354.254ms回退；不包装成核心NPU提升。

两次块和整链已guard PASS卸载，boot00e3dee3-402f-4f7b-86ff-1b299862a7f9/modules空，不需要重启。USB BLOCK34_IO_20261008_1已sync/RO，host board_evidence1.tgz240837B/SHAa684409125ba10b7f0fa35a5db7671c339facb9b819998d55ed5b2d5c4eeabc5，实际IO runtime与host一致。无新bit/驱动/模型/量化/Flash/原工程构建；新头量化独立质量仍未通过，持续10/15/30fps未达到。下一仅针对BLOCK34超过33ms的实际DMA搬运及固定缓冲全span成本做最小修正，复用当前成本结果，不再堆尾部低收益层。

AGENTS/status/backlog/日志及施工单相关T30-2/5已读。整体基线与外部snapshot完整性UNKNOWN。HEAD仍detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff实查空；git status因Git LFS/msys启动0xc0000022失败，不能称工作树干净，无提交。目标active，显示DEFERRED。

## 2026-10-08 20时后：Conv18接原16帧入口，BOARD零差，5803.249ms

sol_head_pw_20261008/main_candidate/run_main.sh已实际完成同真实16帧。尾部320→1280 PW由Hard新增112 START执行，原Hard256及PL FRONT96/BLOCK34/DW16各16保留；DW17/剩余空间、池化/128D投影、真实C128仍CPU，Soft/V4R硬件0。新层实际七packet覆盖全部1280通道，权重与厂家CMA逐字节一致；倍率26518/19，Load/Unload PASS、Load-only Execute未调用。新ABI0x42341720/head23_fixed、23槽，分组0/6/16仅冷边界软件切换；原16包/数学保持，weight padding66560/allocated69632，真实DMA/CRC/guard/失败pin保留。

完整2048特征/C128与板端实际整数尾部CPU参考零差，前段真实tail_inputs与上一版逐字节相同。整链5803.249 vs5872.753ms，只减少69.504ms/1.183%；尾部652.111→536.905ms，新Hard client141.877ms。普通逻辑层每图Hard7/PL5/CPU23，分片START另计。旧12段仍9/12、分类12/12一致，但特征相对原数学有新增量化差异，独立质量/拒识NOT_CALIBRATED、新量化NOT_ADOPTED、不覆盖默认。约2.757图/秒仅单保存窗换算，非持续吞吐，仍未达到10/15/30fps。

Hard及PL guard释放/正常卸载，当前modules空，无待重启。USB HEAD23_HARD_20261008_1已保存并sync/RO；host证据429612B/SHA0efe78b1b5a0f837bab5a1f07a70746e5372085a8211b6e1a65b4df9689cee55，ko SHA6601749778a29ca6299c63e0a510838260bd642acf2adeecdb5eb5b4f50d2be8，实际runtime与host一致。历史Module.symvers/clock-skew警告保留，无新bit/PL资源/Flash/原工程构建。原数学6354.254ms回退入口保留，整体基线/外部快照UNKNOWN，HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached空，目标active。

下一回到未消除的BLOCK34约66ms/图：已通过Hard+PL DW路径核心约22ms而完整块约63ms，直接测其输入/输出/释放开销后修复主链搬运，不继续只堆低收益尾部层。sol_block34_cost_20261008/run_cost.py已接已有固定块入口，仅追加本次必要阶段计时，复用fixture/原驱动/bit；实际运行PENDING。显示DEFERRED。

## 2026-10-08 20时接续：CPU最终尾部固定16/NEON17接原两入口，BOARD零差

新入口 `experiments/sol_tail_batch16_20261008/candidate/run_main.sh`（TAIL_BATCH_MODEL指向cpu_tail_b16_neon.onnx）及 `run_original_math.sh` 已实际跑同真实16帧。收齐H6输出后才完成一次CPU尾部计算，保留全部三PW、一DW、池化、128D投影/BN/ReLU，无占位特征、重复帧或少算层。尾部权重与原cpu_after_h6.onnx不变；原16次调用760.076ms、纯batch16 710.546ms、复用既有CPU NEON17 648.223ms（纯CPU合成16独立张量，三轮中位，逐字节零差）。真实整链尾部652.111/653.046ms。

连续12/13块整链5872.753ms vs5979.310ms，原数学6354.254ms vs6462.317ms；两条分别对对应已通过参考2048特征和C128 logits零差。前者Hard256（新块各48）/后者Hard160，PL三个块均各16，Soft/V4R硬件0；两DW576/残差/剩余空间/真实C128为CPU。普通层分工报告补入真实新增四Hard PW：联合入口每图Hard6逻辑层、PL5普通层、CPU24普通层；START按分片另计。尾部batch时间按16分摊，明确非单帧延迟。新量化仍NOT_ADOPTED；旧12段9/12非独立质量或拒识验收，持续10/15/30fps未达。原数学CPU优化可独立使用，不覆盖旧入口。

本轮已产生真实尾部张量，并只对改变的尾部做节点profile：最大Conv18 320→1280/7×7为288.329ms/16，project17 215.831ms、expand17 109.291ms、NEON DW17 31.392ms，含profiling。下一直接PW已在sol_head_pw_20261008生成实际409600B权重、TensorInfo完整模型ordinary_09（415544B/SHAee517bc753af74a13509a2bb61455a427c342ad1fec9fefce96f51c08e0ddef4）及CPU前后段；Load/BOARD/量化质量PENDING。下一复用已通过Load-only工具取得实际packet→完整128D/C128质量→同owner主链。它尚未解决PL BLOCK34约66ms/图，不能称30fps已具备。

USB TAIL_BATCH16_20261008_1已sync/RO保存两条入口、CPU对照、真实张量和结果；host board_evidence1.tgz366131B/SHAb848c54b8239d20fc618c81a3db6190301563afe3b0f33243a3940ad2c242719，实际运行源码与host候选逐字节一致。详细恢复及数值见stage qualification.json；输入SHA4701269159219088f9f0cf17a1a16872b3b81c6403bbc7c383d550fb9edc8113不变。两个模块guard释放/正常卸载，同boot00e3dee3-402f-4f7b-86ff-1b299862a7f9，当前modules空，无新bit/驱动/Flash/原工程构建。全量基线及外部快照完整性UNKNOWN；HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空，总目标active。

## 2026-10-08 19时：第12→13块连续Hard/CPU整链BOARD零差；CPU向量版5979.310ms

新增可运行入口 `experiments/sol_block13_hard_20261008/main_candidate/run_main_neon.sh` 已运行同真实16帧（输入SHA4701269159219088f9f0cf17a1a16872b3b81c6403bbc7c383d550fb9edc8113）。Hard执行第12/13块四PW与原H4/H5，256 START/两新块各48；PL FRONT96/BLOCK34/DW16各16；两DW576、残差、其余空间和真实C128 TCN为CPU，Soft/V4R硬件0。全部2048特征及logits与相同目标固定16/NEON9、独立整数CPU参考零差。正常guard PASS释放/卸载，当前modules空，同boot00e3dee3-402f-4f7b-86ff-1b299862a7f9，无待重启。

连续两块scalar版6184.527ms，比第12块6212.008ms只少27.481ms；并非增加Hard层就显著提速。随后CPU NEON只向量化DW八个独立像素累加，保留原S30 ties-even舍入/权重/边界/残差数学；两块各全0/全255/随机张量与scalar及整数参考逐字节零差，DW由12.631/12.601降到6.133/6.138ms。接入整链5979.310ms，较本轮scalar减少3.318%，较原数学缓存6462.317ms减少7.474%；为单保存窗，非持续fps，包含CPU优化而非全归NPU核心。CPU reference耗时含未优化整数矩阵和初始化，不作生产性能基线。

独立ABI0x42341620、/dev/space16_b1213_fixed、16常驻槽：0..5循环0，原H4/H5为6..15循环6；冷态无input选0/6，输入边界0/2/3/5/6/12。12→13直接UINT8，无中间float转换；原十项H4/H5 packet/weight不变，既有真实DMA/CRC/guard/完成/超时pin保留。CPU before12 1237.847ms、after13 529.479ms、128D尾部765.083ms，PL BLOCK34约66ms/图仍阻塞30fps；下一沿已有节点profile选择before12最大实际PW，不再重做全层资格。当前新量化与原数学有max0.655770特征差；旧12段9/12、12/12同分类，独立质量及拒识NOT_CALIBRATED，新量化NOT_ADOPTED，默认原数学入口不变。

修改位于本stage：prepare_main/package_main、batch_bridge、cpu_gaps_neon/probe_gaps、固定owner/入口/CPU参考/后验验证；无需新bit/布线。USB BLOCK13_HARD_20261008_1保存原始两轮结果、CPU参考、实际ko/runtime并sync/RO，host已取回board_evidence1.tgz（42536B/SHA37a3bb68cb1acf695175d464c502dcb2ad9b6e7499971e9abf54051eb228e074）及compiled1.tgz（239972B/SHAa8b118992e49dd1147be19ec0a2ce4e6e373e8b0b6b144971ac82b5aea09ac3e）。实际ko SHAbfd7a01038b0b756e374341690cb76c70594fb969cc1add42561de8c2bd5fb4c；NEON so SHA2c1a7b94d2f668716123300d457c1f1548ef1132e218f79e45a8f2d76783ae7b；完整恢复顺序/产物/分工见本stage qualification.json。全量基线/外部快照完整性UNKNOWN，本轮未写原工程/Flash、未构建新bit、未提交；实际HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空。目标active，显示DEFERRED，持续10/15/30fps尚未达到。

## 2026-10-08 18时：第12块Hard＋CPU完整16帧BOARD零差，6212.008ms

新增可运行入口为 `experiments/sol_block12_hard_20261008/main_candidate/run_main.sh`：第12块两普通PW由Hard三作业/帧执行，DW576和Add为已有本地CPU数学；原H4/H5仍Hard，FRONT96/BLOCK34/DW16仍共享PL，其余空间及真实C128 TCN仍CPU。完整同真实16帧208 Hard START（其中新块48）、三个PL块各16，Soft/V4R硬件0。128D共2048值和logits与相同目标固定16/NEON9、实际厂家缩放参数CPU参考零差。6212.008052ms vs原数学缓存DMA6462.317224ms，单窗时间减少3.873%；原数学对原BOARD零差入口继续保留，新量化不切默认。12段现有弱对齐样本仍9/12、12/12分类与原整数相同，独立质量/拒识NOT_CALIBRATED，非持续10/15/30fps。

本轮实际失败已修：厂家LoadGraphQuantORT在offset0x41164 NULL TensorInfo写入崩溃；补齐input_f/weight_f/bias_f/conv_f四项ONNX value_info后，原14×14几何两模型Load/Unload成功，nodes/weights/bias/输入输出未改。16×16尝试仍失败且已停止，无新探针平台。捕获PW扩展两包2248/584B、投影648B，实际倍率/右移25301/20与23503/24；CMA权重与模型逐字节相同。完整块首次105.320ms/零差，但Python DW76.866ms；复用原C DW/Add修为29.141ms/零差，正常卸载。整链首次两Hard作业已成功释放后发生tuple解包错误；修正并读取COLD/flags513、guard PASS卸载，未请求无必要重启；随后208 START主链成功。

候选ABI0x42341310、/dev/space13_fixed、13常驻槽：新0..2循环0，原H4/H5为3..12循环3，只在冷态无输入边界切组；输入更换0/2/3/9。packet padding2248/allocated4096、weight padding55296/allocated57344、输入输出allocated114688，均真实DMA、同步、guards/CRC/完成/实际超时pin保留。既有H4/H5十包身份不变。提速同时包含较小缓冲带来的复制/guard开销减少，不能全称NPU核心收益。原clip_result.spatial_batch16.cpu_prefix_ms字段把新Hard client89.719ms包含其中；最终cpu_spatial_ms已扣除，原记录保留，qualification提供范围说明。

第13块接续：sol_block13_hard_20261008/prepare.py已生成两真实模型和CPU DW/Add参数，model_contract PASS、显式TensorInfo与原14×14保留；12块输出和13块输入均scale0.34880006313323975/zero112，可直接UINT8串接。厂家Load/Unload已PASS/Execute未调用，实际PW包2248/584与648B、倍率23347/20和17608/23、权重与模型一致；第12→13块直接整数串接CPU完整128D/C128回归仍9/12、分类12/12一致。连续两块BOARD仍PENDING、独立质量NOT_CALIBRATED，下一接一个固定16槽所有者和原16帧入口。capture1 95272B/SHAedf0109a5a671c141dc9e106cbe6775a9ce2c3a52445a079b07129b70e243dd5已USB新目录sync/RO并host取回。

当前一个直接瓶颈：新块Hard client全16仅89.719ms，但其CPU DW约12.6ms/图；第12块前CPU批处理1237.637ms、之后866.048ms，特征尾部仍约0.77秒。下一复用相同14×14厂家通路迁移第13块，并保留16批处理；不重做Soft/时序资格、相机或显示。板卡同boot00e3dee3...，两模块正常卸载、modules空、USB sync/RO，无待物理恢复。goal active。

证据USB `BLOCK12_HARD_20261008_1`：metadata_capture1 SHAcbc91533be8d36b218887b7d904c13cd6a0b4f7990568523dd85a5453d4a805d；board evidence299891B/SHA1691f7441fedd34995da0503bee78b95d45fe70cd1d78c09b2ce1a12d62eb766；compiled195199B/SHA31c7d21052adbadfe87eb9670ea4a9bcab5c8a99048a58dd3cf9d69cd7750df7。initial main_input1需叠加overlay及compiled实际runtime，不能直接用首次tuple草稿；实际修正文件在compiled包及host main_candidate中。编译的缺Module.symvers/clock-skew历史警告保留；本轮实际加载、计算、卸载通过。未Flash/saveenv、未原工程构建/基线覆盖/数据集下载/提交；原工程及外部snapshot整体完整性UNKNOWN。HEAD实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空。

## 2026-10-08 17时：缓存DMA原模型16帧BOARD零差；新增四Hard层整链完成

`experiments/sol_block34_cached_main_20261008/run_original_cached.sh` 是原模型DMA候选入口：原PL BLOCK34、FRONT96和DW16各16次，原Hard H4/H5共160 START，CPU Add及真实C128 fixed CPU TCN；Soft/V4R硬件0。只使用已通过的noncoherent allocation与显式同步，不改原量化、权重或数学。same-input原BOARD features[1,16,128]和logits均0差，6462.317ms vs6782.880ms（时间减少4.726%，单次窗比较，非持续吞吐）；Hard guard PASS、两模块成功卸载、/proc/modules空。原默认、旧bit和回退入口保留。本轮第一次该脚本被CRLF导致set选项错误拦下，模块加载/START均0；修正LF后运行成功。

新增四层Hard连续块也已进入整图：256 Hard START（其中BLOCK34六作业/帧共96）、32 PL DW144、16 FRONT96、16 DW16，CPU其余普通/深度卷积与残差、真实C128 CPU TCN；完整16帧6393.125ms。最初对PC逐帧/普通ORT参考991特征不同/max0.164378、logits max0.016352，原失败记录保留。采用无设备的板端整数CPU参考、相同固定16批处理与NEON9后，2048特征和logits均0差。该对照验证硬件执行等价，不消除候选对原模型的量化质量差异；不能拿35.947秒的未优化整数CPU验证器作原生产CPU速度基线。相较6462.317ms原模型缓存路径，本轮候选仅少69.192ms，不因多了四层Hard而切默认。

直接瓶颈：CPU after_block4批处理2433.738ms/16，最终CPU特征尾部约0.77秒/16；原BLOCK34 device仍约66ms，新Hard/PL块client约61ms，均不满足33.33ms/帧。复用已有CPU节点profiling，下一迁移第12块C96→576→96的两个普通Conv；DW及Add先用已有CPU，先Load-only取得实际厂家包，再跑候选128D/C128质量回归，不重做Soft/T01或盲改tile。`sol_block12_hard_20261008/prepare.py` 已生成两真实DQ-Conv-Q模型，权重、bias及固定shape通过现有model_contract；这是新量化候选CODED，不是BOARD或产品质量通过。

本轮证据在USB `SPACE16_CACHED_20261008_1`，host已取回：board_evidence2.tgz SHA75ef0026babaaa7871ad99c8b3143bdb9e519f34ed45fdf97272661808432b34；compiled1.tgz SHA100c793a023406aaf3a133e4b9a4b3fbcf6871b2d5073355bfdb081558e3069d；original_dma_evidence1.tgz SHAd179f40fb614bda21c8596610cd5a2a7244ff5e31b903e70046e54728c7ad755。候选ABI实际0x42341610，早期clip_result.json中硬编码旧ABI0x42341600只是报告字段，原件保留；runtime_fix2已修正报告及复用四个已通过CPU依赖。候选、依赖补丁、编译产物、原数学入口及两方结果均USB sync/RO保存。当前boot00e3dee3...，无失败DMA待恢复。

## 2026-10-08 16时后：原厂家C32完整块BOARD零差，缓存DMA生产三次通过；整图接入DOING

完整BLOCK34现已实际跑通：同原厂家C32 packet/权重，六Hard PW作业（四卷积层）＋两PL DW＋CPU Add，最终[1,32,28,28]逐字节零差。匹配内核CRP源码确认NPU复位为0xf8801074 bit12低有效；在已确认无DMA的U-Boot启动阶段脉冲后进入Linux。原C32源码/ko SHA8b95b204...不变，六START全部irq1/work5/guard0/成功RELEASE。单块285.336ms，Hard START→IRQ线程合计约1.168ms；这不是NPU核心计算慢，也不证明旧三次超时唯一根因。完整证据USB BLOCK34_PAD32_20261008_1/controller_evidence1.tgz（671982B/SHA60cb5b436bbc3d1af427144e3ee3750d613b7f26c14a8c9a2d3adb1ce014a3f5），工作副本串口verification见sol_block34_tile8_20261008/board1/pad32_controller_evidence_saved.log。

新独立cached候选ABI0x42343300采用匹配Linux6.1 dma_alloc_noncoherent＋BIDIRECTIONAL显式device/CPU同步；所有完整守卫、输入/参数CRC、完成及实际失败pin保留，不删除扫描换速度。相同六PW与两DW validate零差77.932ms；product同实例三次零差69.472/63.020/63.030ms，18Hard START全部释放。PL DW3/4 device约15.450/6.014ms，host ioctl约17.784/8.042ms。三次重复输入是缓冲同步/块性能对照，不能算独立真实视频吞吐。相对旧PL块66.159ms收益有限且首轮仍更慢；默认未切换，不声称30fps。候选/ko/紧凑输出及product证据已USB BLOCK34_CACHED_20261008_1保存，Hard ko SHAa6cb48b9...、PL ko SHA8655fae4...。

手改4×2内部tile候选NOT_ADOPTED：首次空闲拒绝START0，CRP复位后一次START仍work2/10.100s超时、451584B全A5；证据tile8/board_evidence2.tgz SHA4f488b419aa9d1418d4bd6868c5b3c4d45e6fb477cb383d35ea08a1a79dfd4a8。用户随后实际冷恢复，未重试旧失败实例。U-Boot直接读取63f01014触发地址访问异常/CPU自动重启，无START/DMA；删除该未映射地址读取，状态仅由Linux驱动读取。CRP寄存器复位读回正常，未弱化空闲检查。

下一可运行交付已经CODED：sol_block34_cached_main_20261008，ABI0x42341610，把通过的C32六作业与原H4/H5十作业接回既有16帧入口和真实C128 CPU TCN；共256Hard/32DW144/16FRONT96/16DW16。只精确补零与缓存同步，原旧十作业/固定组0、6及原CPU批处理保留；待目标编译/BOARD整图输出对照与耗时。候选量化相对默认的特征/质量差异仍NOT_ADOPTED/NOT_CALIBRATED，不因本块B↔C零差证明A↔B质量。

## 2026-10-08 早期历史：两PL DW已BOARD零差；Hard大图三种形状超时，转内部tile修复

已运行的新功能是原共享DW核的独立DW3/DW4模式，实际输出均逐字节零差。DW3 device15.440370ms/client34.494990ms，DW4 device6.023610ms/client27.666720ms；不能用核时间代替完整块收益。证据sol_block34_dw_split_20261008/board1/gap_fixture/pl_dw_verification.json。新bit已P&R/BIT/下载/BOARD，physical46932/52480 slice、150ERAM、174DSP，SWNS0.108/HWNS0.023，coverage63.52%。

普通卷积完整块尚未通过：原C24扩张、精确零补齐C32、C32紧凑14行均首作业START1后work3/irq0超时，后续DW/Add未执行。C24与C32原始输出相同，3574字节改变；14行3575字节改变且全部与同地址CPU定点预期相同，但总109112字节未匹配，不能称卷积完成。通道补齐与外部行分片不足以修复。匹配16槽驱动的一次原H4控制作业正常完成、数值零差及安全卸载，缩小到新几何/执行问题；不是重新资格验证。每次失败日志/原始输出已取回并保存USB，未自动重试或释放未知DMA；用户随后确认冷恢复。

最新14行候选ABI0x42341400、固定12作业、目标编译ko SHA54565fe25cf258be0cde64d6acbf3995dc12922a42fa5c5de16866a6bc1ba2eb；真实厂家capture/dump及CPU四片拼接均通过，BOARD首片仍10080.329ms超时。证据sol_block34_row14_20261008/board_evidence1.tgz（3526B/SHA5022e2914ca9df0eafc2412d107a976acdee7a9fab639d9884fad8abf80ac0a9）及board1/output_analysis.json。它不是原16槽整图候选，不能混用作业计数或ABI。

下一具体运行：复用完整C32六作业、两PL DW与CPU Add，只将内部tile改为原H4已通过的4×2，避免继续增加外部碎片/START。这属于明确标记的手册字段派生指令候选，不冒充原厂未修改packet；数值/缓冲及完成检查保留。当前根因仍UNKNOWN，完整块BOARD与同16帧整图收益PENDING；默认不变。

## 2026-10-08 11:45 同真实16帧CPU候选参考已运行；下一步必须实际冷恢复

本轮实际CPU计算用原已通过headless_copy16_1的全部16帧，不重采集/预处理/重采样：输入[16,3,224,224]、16个不同(epoch,sequence)、原normalized_frames.npy SHA4701269159219088f9f0cf17a1a16872b3b81c6403bbc7c383d550fb9edc8113。候选整数空间到[1,16,128]及精确真实C128 TCN已跑通，CPU PC空间2001.674ms（不是BOARD性能），device START0。分类仍“过敏”，但1159/2048特征不同、max2.418784/RMSE0.496238、logits max0.682688，得分原65.713%→49.217%。无动作真值，不称识别正确或质量保持；NOT_ADOPTED/NOT_CALIBRATED/default不变。

next BOARD数值验收应与此候选CPU128D/logits零差比较；与原默认/FP32的量化变化另行验收。prepare_real_reference.py实际运行结果real_reference1/{features.npy,reference.json}；verify_main.py仅用于完成后的同输入比较与本次256 Hard/32 DW144/16 FRONT96/16 DW16计数，不在product每次调用热路径执行golden。新7KB参考/输入恢复小包7299B/SHA2c7b596d5cb6d1db1a21e88dc5c9bf6c0d0359f5153c7631fc2d8ce54cbf1c05已USB新候选目录sync/RO。原大CPU模型、Neon9图与权重复用，无全量重封装。

大文件只读取回初次40s观察超时（1.54MB实际需约180s），未把它误归因NPU/启动故障：先只读排空UART并确认shell响应，使用已有TimeoutSeconds240参数重取成功，压缩包1537563B/SHAf248841d9931c34b54a6a568340eae652a05b10b7b9c3caa48e806fb51258227。未重启、复位、卸载固定模块或触及设备。

外部状态实际复核：同boot_id4528d917-6db5-4411-99ee-0a8d3fba5a29，block34_hard_fixed ref1仍固定；用户未确认这次物理冷恢复。自11:06/11:25到本阶段同一恢复条件连续存在，必要的bit/驱动/原整图候选/同输入CPU参考都已准备；不再靠增加不服务下一次运行的静态任务维持进度。已再次明确请求物理断电上电；确认后直接继续已有临时启动→两DW/完整块→原整图16帧。目标未完成，默认16帧6767.772ms、持续10/15/30fps未达。当前goal状态仍以工具实际结果为准。

## 2026-10-08 11:25 T30-2整图固定16作业候选CODED/目标编译，未BOARD；等待冷恢复

本轮实际交付是可直接接原16帧入口的独立候选，不改默认：sol_block34_main_20261008合并新BLOCK34六PW作业与原H4六/H5四为同一个HardNPU所有者，模型只加载一次。十项原H4/H5 packet/weight FNV与既有冻结配置全部匹配。针对原固定16批处理的真实顺序，0..5作业循环完成16帧前段后，显式在已释放且无input的冷边界切到6；6..15循环执行原H4/H5。无新并发、自动恢复或通用调度；一次预期整窗256 Hard START/32 PL DW144，实际本轮0 START。

独立ABI0x42341600/dev/space16_fixed、SELECT_GROUP K/0x29仅选0或6，软件cursor切换不写MMIO；现有DMA存活/完成/CRC/释放和实际失败pin保留。匹配整图入口复用原neon9固定16 CPU图、FRONT96/DW16、CPU Add、原CPU尾部及精确真实C128 TCN；Hard层/CPU层/PL层和START统计已按候选修正，不把新增普通卷积Hard执行计成原PL全块。当前量化质量仍NOT_ADOPTED/NOT_CALIBRATED，原模型/default未切换。

BOARD CPU编译成功（没有加载）：space16_fixed.ko SHA838f3aaae8565d1ead00d2df19a3dc5876d6813578304b3dc4bc2d33d44c53a7，历史缺Module.symvers的modpost警告保留。候选280584B/SHA9f7486351b4dcadb22f90df4669e0543a7a95f908f30be5f49f2d8a857a9eeaf，编译证据173145B/SHA360173307b127461bdabc09c50863fe4957ea0d77e0f37b2e9bb21f9d3a8a84d，恢复/实际整图脚本overlay4088B/SHAabad2c95fdcce61478667253318fa71bfeb4fe951deff1bb113e60896085bf74已USB SPACE16_MAIN_20261008_1保存sync/RO。CLI实际导入/帮助和Python编译通过，板端shell语法通过；这些不是整图计算或提速验收。

一个直接外部条件未变：需用户实际物理冷恢复确认，现Hard模块/DMA仍按首次空闲拒绝固定，未重试设备。上一轮PL DW bit已生成；下一冷恢复→合格临时启动与新bit→两DW/六PW完整块实测→运行本次16帧原整图候选，对照同候选CPU128D/logits和同输入默认耗时。默认已测6767.772ms/16不变，目标active，无本轮新增整链速度或持续10/15/30fps证据。

## 2026-10-08 10:58 T30-2桥接已BOARD零差；复用PL DW两模式SIM/SYNTH完成，布线中

整图/真实C128/无屏视频默认成果保持：6767.772ms/16，尚无本轮整链提速，目标active。当前一个外部条件仍是首次Hard RUN前拒绝后的实际物理冷恢复确认；没有再次START、卸载失败模块或释放固定DMA。显示DEFERRED。

实际板端CPU桥接已用保存真实中间张量核验：DW3 53.221531ms、DW4 12.064710ms、Add 3.412620ms，三者逐字节零差（board_cpu_gaps_verification.json）。单次合计68.699ms已超过旧完整PL BLOCK34约66.159ms，因此Hard PW+CPU DW候选不足以提供所需收益；不是重复调CPU，而是将两DW直接接回原PL计算核。

sol_block34_dw_split_20261008新增0/1/2模式：保留原完整块、仅C144 DW3、仅C144 DW4。复用同一DW核和已有scratch3/4 coherent缓冲，无新增计算引擎/ERAM/DSP，不改原PS/PLL/CSI接线。真实张量串行两模式SIM零差/步长2行填充正确/最后B后完成；原完整块回归SIM也零差。SYNTH 43045/52480 slice（82.02%）、150/280 ERAM、174/240 DSP；P&R运行中，尚无本轮BIT、PL BOARD或实际速度结论。

匹配驱动已在板卡CPU编译：net_pl.ko SHA f25f240e8e3c039013901115dc4e4a27cc0b75cbd35cb8f2d60b9fe51001dc59；同历史缺Module.symvers的modpost警告保留，未加载。编译包141103B/SHA b90488cb9a749977488334e02846fe2260f05baa0b4c0c9dfeb6ae01ef1ef5ed、运行补丁6082B/SHA 64031302380b88f3a46df111eb179a4d67ee3ed8475efb4eb09e204b42e189d3已USB新目录sync/RO保存。Hard标量质量候选仍NOT_ADOPTED，不改默认模型。

11:06更新：P&R/BIT已完成，实际physical 46932/52480 slice（89.43%）、150 ERAM、174 DSP。按本轮route实际首级同步器输入保留29条精确CDC例外，再核对唯一剩余PS reset external[0]（综合物理名称和逻辑net不同），补该首级精确一条，非全时钟/数据路径例外。最终SWNS0.108ns/HWNS0.023ns、TNS均0；STA coverage63.52%，继承ERAM异步reset输入警告保持，不声称所有异步/I/O路径已验证。候选bit4052202B/SHA1e4005f6eaccb50c9bc4af5738732cdc002c0acd2a9943a983f6339f9c661ac8，尚未下载或BOARD。两DW验收/文件恢复入口已USB保存RO。下一实际动作：用户确认冷恢复→已通过临时80MHz/保留DTB环境→临时JTAG新bit及匹配PL驱动→真实两DW/完整混合块数值和耗时；目标active，不能以本次构建称已提速。

## 2026-10-08 10:22 T30-2真实厂家包/固定连续块候选已编译；首次提交前空闲检查拒绝

目标仍active，用户明确“允许本次登录和无屏易失板测”并要求开始后不要自行停止。整图/真实C128时序/无屏真实视频的默认成果不变：neon9、Hard H4/H5、现有空间PL、精确CPU TCN，16帧推理6767.772ms；约2.36仅单窗推理等效，不是持续吞吐。显示继续DEFERRED。本阶段尚无新增硬件提速或候选采用。

T30-2新增可运行软件：四个真实PW模型已经在既有无设备bwrap/ptrace环境完成厂家解析、优化、加载和原始指令/权重捕获，Execute未调用。此前“Invalid(null) filename”实为临时模型0600权限导致隔离进程无法打开；chmod644后通过，节点命名/标量编码变体未解决根因。实际4层共6包；第二层为19/19/18行空间分片。额外捕获19/18行紧凑模型，CPU拼接与完整PW逐字节一致，无猜测DMA偏移。修正pointwise_packet_contract中非正方形通道形状字段H/W解码；旧正方形判断不变。

CPU整链按真实包m/s（25133/18、24048/24、18483/18、17055/23）到[1,16,128]及真实C128固定TCN已跑完：FP32/旧整数/候选均9/12，候选与旧10/12分类相同，一例原正确变错、一例原错误改善，NOT_ADOPTED、NOT_CALIBRATED；分组32候选8/12已REJECTED，不再扩展该量化变体。原preparation.json的块误差曾用非Hard的四舍五入参考，属于已被本轮floor参考替代的早期结果，不能作为厂家实际数值。证据quality_vendor.json、quality_group32.json。

独立候选ABI0x42340100/dev/block34_hard_fixed，6固定Hard PW作业+复用原CPU两DW/一Add，准备输出[1,32,28,28]进入原CPU尾部；尚未接默认或整图BOARD。完全复用H10固定驱动生命周期/完成/缓冲保护，不改原H4/H5 ABI、NPU驱动默认或bit。板端已实际编译及加载分配缓冲，kernel同6.1.111-rt42；仍有历史缺Module.symvers的modpost警告，不声称内核源身份完全验证。ko SHAacd7d0cf2cd937d26a8891441e6a954e48847dc8960a1b7deccdbbbf3b3685a5；CPU gaps库SHA609b3d845fbab522da19a2aff48d2539640579bf45c1e462f6621ca064bc8a6c。

首次运行实际FAIL_BEFORE_START：当前普通Ubuntu启动boot_id4528d917-6db5-4411-99ee-0a8d3fba5a29，预复位work2、复位后work3、idle_samples0、phase4/reason14、作业寄存器写0/实际START0。不能归因新卷积数值/shape失败；不得在未知状态重试。模块及DMA仍固定，失败日志已取回并请求用户物理冷恢复；等待期间继续CPU桥接核验及小恢复入口，不暂停目标。早期last_run.json将一次RUN尝试误计hardware_starts1，源文件已修正按writes==8统计；原始证据不改写，实际为0。

板端候选及编译产物/失败证据保存在USB新目录BLOCK34_HARD_20261008_1并sync/RO：board_candidate.tgz119445B/SHA407a5744531937c1253a2d5f23c322c995d9b72a216f573764b02727eedabce2，compiled_candidate.tgz SHA564d37d334375adad3350d35849dcdef3686410e5f77ec7424072d8ccef6371a，prestart_evidence.tgz2120B/SHA0c54c2ae82ee70494df072017401d71159d7eb5217a586d5820628e958edebce。软件原始捕获43877B/SHA9db8994e...、紧凑捕获5271B/SHAc0354ca1...已取回。下一：实际冷恢复后复用已通过的临时80MHz/保留DTB/bit启动配置，复用已编译候选，连续块一次运行→真实数值及耗时；结果前不采用候选。HEAD仍detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached空，整体原工程/外部快照UNKNOWN，无Flash、原工程构建、下载数据集或提交。

## 2026-10-07 22:34 T30-1真实无屏入口BOARD通过；T30-2连续普通卷积候选DOING

最新施工顺序以用户30fps目标及`F:/My_proj/fdma_imx415_20251008/SOL61_30FPS_HEADLESS_EXECUTION_PLAN_20261007.md`为准，已完整读取。显示排线损坏，显示修复DEFERRED；此前frame_align的P&R已正常完成，但未继续STA/BIT/BOARD，不能称实体修复。此前暂停及15:52串口UNKNOWN已被用户明确本次无屏恢复/板测授权、实际两次冷恢复及本轮运行替代。第二次重启是用户断电接回摄像头，非NPU故障。

整图/时序：原neon9、Hard160/窗、FRONT96/BLOCK34/DW16各16、CPU Add16、真实C128精确CPU TCN保持；Soft/V4R硬件0，既有OC16证据保持。真正off入口不再传字体/渲染/DSI打包参数，关闭匹配ABI未来显示读帧，保留独立DDR、不复位在途读流、不动共享相机时钟。新增采集no-snapshots仍保存原normalized16输入和帧号JSON，不保存PNG；图像/模型/时序数学未变。

实际第一真实窗口推理6782.880ms、同输入CPU参考15897.023ms；最终features[1,16,128]字节精确/logits0差，无PNG/RGBX、16个不同发布帧/复制拒绝0。统计脚本首次把off作为浮点时间解析而失败，计算与卸载已经成功；修正sys.argv切片后第二真实窗完整rc0：采集3150.594ms、推理6767.772ms、采集到分类11134.850ms、含模块装卸整窗13010ms。第一窗采集到分类11888.147ms，cold模型初始化1085.699ms；第二窗566.978ms。不同场景/窗口不作为旧DSI速度对照。推理窗等效约2.36帧/秒，非持续流吞吐、10/15/30fps均未验收；第二窗主机接受约5.308fps/首末2.826s，CSI Gray计数不作为曝光时间或准确传感器fps证明。

视频：摄像头最初断开时预检无I²C ACK/CSI0、未使能采集；用户确认相机也断并随后断电接回，当前真实采集恢复。单张真实冻结帧mapped/原224张量0差，但mapped2407.850ms vs原copy87.842+decode24.491+resize/normalize91.244ms，明确拒绝mapped速度默认、保留copy，转T30-3 PL小图路线。无重新资格相机/Soft/T01或新显示构建。

当前瓶颈实测：BLOCK34平均设备66.159ms/图、FRONT9644.084ms/图，均已超过33.33ms；CPU空间4082.981ms/16，CPU batch after_block42433.789ms。T30-2已从原FP32参数生成block3/4四个普通Conv的标量DQ-Conv-Q模型及CPU整数候选，沿用既有DW/Add；现packer模型结构检查通过，不等于Hard shape支持或BOARD通过。一个已保存真实块边界上，候选vs旧整数19506值不同/max11码，vs FP32块RMSE0.579/旧0.301，不能接默认或称质量通过。下一直接动作是整链任务回归及厂家packer真实捕获/连续块运行，不盲改寄存器。证据`experiments/sol_block34_hard_20261007/preparation.json`。

常驻CPU会话最小入口CODED/OFFLINE：同一进程三个保存帧窗口复用CPU模型，原CPU桥接→[1,16,128]→真实C128固定时序输出均0差，PC初始化31.817→5.281/5.850ms；不是neon9混合BOARD收益或T30-4完整常驻流水。设备加载/释放流程保持，尚未改成常驻DMA/按帧特征环。

阶段证据`experiments/sol_headless_20261007/board/{verification1,window2,window2_wall}.json`及串口日志；完整3,189,823B证据已保存USB `CAMERA_SPEED_DSI_20261007_1/headless_stage/board_evidence_1.tgz` SHA5c13f70b3847680c02cc9b20407378c4c722d4b9bc880f9e2cad178868b1e546，最终运行包24,732B/SHA39e6e406d5b91c81b03e2222861fb638e347ffcf85af4ffd65fc4e9826154d91；已sync并恢复USB RO。当前匹配临时Linux/capture0/display0/模块空，无待物理恢复。质量/拒识NOT_CALIBRATED、未下载CSL。goal active；HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached diff空，旧qualified bit SHA bffe38...333ff0a本轮再次核对相同，原工程/外部快照整体UNKNOWN，无Flash/saveenv/原构建/提交。

## 2026-10-07 15:44 实体屏持续上下循环错位，修复候选SIM/SYNTH通过、P&R运行

15:52最新板端状态：主要15999B运行补丁此前已保存并确认USB RO；后续小验证helper传输未确认成功，COM4只读存活命令也无返回。没有新NPU START，原因UNKNOWN；已经请求实际物理断电上电，确认前不再提交设备操作。helper最终USB挂载状态UNKNOWN。goal仍active，本地P&R/时序收尾继续；以下无待重启描述是更早采样状态。


整图/时序仍是九层CPU DW默认：同真实16帧推理中位6812.292ms/较原ORT减少9.038%，最终128D特征与分类零差。点卷积原float32 C576→96加残差原型实际BOARD CPU 12.094ms，对原ORT11.028ms，max1.23978e-5/15673值不同；无收益且非精确，拒绝接默认，设备START0，证据sol_float_pw_cpu_20261007/board_verification.json。

视频/显示新实际失败：用户先确认正常，随后明确底部到上方且一直循环移位；此前短期三窗通过不代表长期稳定。当前板端capture0/display1/modules空，2457600B显示缓冲对本次原文件仍字节精确、CPU正常。旧RTL只有首次VS起点对齐，缺数后会累积流位置错位，板端具体缺数原因仍INFERRED。针对该路径新增implementation_video/rtl/dsi_frame_align.v：损坏帧余部送黑，保留在途AXI和独立缓冲，消耗该帧剩余字后在VS/垂直后廊恢复零点；隔离副本uidbuf仅读侧加受容量约束的预取阈值，原默认参数仍1。新增两个16位Gray事件计数用于本次BOARD定位（FST1 ABI1.5/0x90000164），不扩展通用探针。

真实原扫描源仿真复现旧路径429错位像素；新路径缺数与长中断2次后11完整帧/0错位，恢复2次。候选SYNTH43142 slice/150 ERAM/174 DSP，P&R运行会话74111；尚无新BIT/BOARD/实体正确判据。已通过bit及原PLL/管脚/PS时钟/HP0/模型/驱动保持；候选位于sol_dsi_frame_align_20261007，不能将SIM写成实体修复。软件ABI补丁15999B SHA77e4b7b3...已保存USB/RO，下一布线/实际STA→合格bit→用户实际冷恢复→相同结果屏显及负载期间事件/实体确认。

原采集整图复制热点的可选mapped resize已CODED，离线真实图/两布局/两stride与原224预处理字节精确，独立张量生命期检查通过；尚未BOARD，默认copy保持，先修复用户当前显示故障。无当前挂死或待重启请求，goal active；未写Flash/原工程/快照或提交。

## 2026-10-07 15:09 九层原float32 CPU DW已成为默认主链，整推理减少9.04%

整图/时序：原模型和当前alignreset bit/80MHz/显示1保持，两对交换顺序的同真实16帧对照通过。原ORT7471.643/7506.695ms；九层NEON6811.928/6812.657ms，中位7489.169→6812.292ms（减少9.038%），含输入/初始化8155.270→7439.620ms。CPU空间4750.432→4091.834ms。最终features[1,16,128]逐字节精确、分类logits零差；原float32参数及其余节点字节不变，没有新增量化/FPGA资源或NPU驱动变化。CPU实际9层×16=144，Hard160/三个空间PL块各16/CPU Add16保持，快路径时序仍精确CPU，Soft/V4R硬件0，既有真实C128资格保留。已采用neon9默认，显式ort回退保留；旧neon/neon4仅为历史实验选项。

实际修复：最初四层候选7.128秒但特征122值不同/max0.0155783、logits max0.00129631，未采用。补声明外部DW算子的四处固定输出形状后，同计算库/原参数的CPU尾部逐字节精确、整链7.140秒/最终零差；此前两层尾部1.132488e-5的差异在该四层对照中消失。内部具体融合节点变化仅INFERRED，未称所有输入数学位等。随后同实现覆盖5/6、8～13、15九个stride1 DW，固定C192/H28、C384/H14、C576/H14、C960/H7；CPU尾部同真实block4张量重复16精确，直接接原主入口。临时gcc绝对路径解决cc1定位，首次链接找不到ld；子进程标准PATH后编译成功，没有PID1退出或新硬件故障。

视频/显示：默认参数真实新16帧运行，采集3639.133ms/采样3243.861ms/复制16拒绝0，推理6802.985ms，采集至分类11642.512ms，整窗至屏幕缓冲读回/扫描使能14360ms（非光学时间）。同新输入原ORT回放7500.324ms，最终特征及logits零差。显示路径复用此前用户“正常”的相同实现，本轮原位发布读回PASS；没有新光学测时。默认运行包30995B已保存USB并实际安装恢复，模型用现原参数重建元数据，不重复传权重；当前capture0/display1/modules空，无待恢复，goal active。

证据experiments/sol_float_dw9_cpu_20261007/board_{mixed,live,tail}_verification.json，四层实际失败/修复见sol_float_dw4_cpu_20261007/board_{rejected,shape_fix}_verification.json。USB float_dw9_cpu_stage/runtime.tgz SHA3655f8913fb5828a0ef5ffd0a178f05341d0d5415f9cb5b8c2b378e52cddf135（host同文件board_runtime.tgz），完整新输入/输出/日志board_evidence_1.tgz2424804B/SHA72d389053d36fb1ee5efe715ff8d4a67452137a64f320eb24436a3f8e6f6a2a4，已sync/RO。下一具体热点：第12/13块点卷积投影，沿已有CPU约10.4ms/帧profile做原float32实现对照；没有收益则保留ORT。识别质量/拒识仍NOT_CALIBRATED、无新有标签数据、CSL不下载，速度与持续运行产品目标未完成。HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached diff空，无Flash/原构建/提交，原工程/快照整体UNKNOWN。

## 2026-10-07 14:36 CPU浮点DW候选已接整链和真实相机/屏幕

整图/时序：沿原模型、当前alignreset bit/80MHz/保留DTB，两个交换顺序的同真实16帧对照均运行成功，模块正常卸载。原ORT推理7452.219/7461.998ms，新NEON候选7230.142/7263.490ms；中位7457.108→7246.816ms，减少2.820%。四次最终features[1,16,128]逐字节一致、分类logits零差；CPU空间中位4744.332→4528.896ms。每窗新增CPU float DW实际32层，Hard160/FRONT96、BLOCK34、DW16各16保持；Soft/时序硬件/V4R硬件仍0，原C128资格不变。没有新增量化或模型权重变更。首轮原ORT初始化1066ms、后续约607～623ms，不能把两个样本的含初始化中位差全部归因算子。

视频/显示：新候选直接经原相机入口采16帧，采集3620.396ms/采样3210.038ms/复制16拒绝0，推理7251.590ms，采集至分类12158.208ms，整窗至屏幕内存读回/使能14930ms（非光学时间）。这组新真实输入再经原ORT回放，最终特征及logits仍零差；用户明确回复实体屏“正常”。不同画面不能据此声称视频整窗相对旧三窗提速。当前capture0/display1、模块空，独立屏幕保留区持续拥有，无待物理恢复，goal active。

候选保留显式第三参数neon；默认ort及回退不变。完整CPU尾部此前1.132488e-5的中间浮点差仍是事实，本次仅签两组真实16帧的最终零差，不宣称所有中间张量或所有输入逐位一致。质量/拒识仍NOT_CALIBRATED、无动作真值，CSL-500不下载。下一直接热点复用既有节点profile：第5/6块C192/28×28的CPU DW约8ms/帧，拟复用当前NEON计算及原入口扩大收益；不能只用微基准替代整链验收。

证据：experiments/sol_float_dw_cpu_20261007/board_mixed_verification.json、board_live_verification.json及mixed/live串口日志；本轮临时恢复download_relative.log/boot.log/setup_ready.log。完整原始输入/输出/日志保存USB CAMERA_SPEED_DSI_20261007_1/float_dw_cpu_stage/board_evidence_1.tgz，SHAc3962e4003a43ed3a00fc7fbbec86d7694470b6e538e1bd3b2a89e0e054ffce1，sync/RO确认。无Flash/saveenv、原构建、数据下载或提交；HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached diff空，整体原工程/快照UNKNOWN。

## 2026-10-07 14:17 CPU浮点DW候选板测；原混合主入口已接可选项

当前整图/时序默认成果与三个实体屏窗口保持下节BOARD证据；新候选未切默认。复用已有after_block4板端profiling，选择12/13块C576/H14 DW，不重跑线程数/Soft资格。新增CPU NEON float32九tap FMA及原Conv+Clip图内自定义算子，原权重/其它节点字节保持；没有新增量化、NPU/PL硬件或bit。板端ORT1.16.2同保存真实单层输入，native逐字节精确/max0，中位9.256→2.714ms。完整原浮点CPU尾部batch16同一保存block4张量重复，3077.390→2876.171ms，最大浮点差1.132488e-5（118944值不同），不能签逐字节或整混合链收益。API计数器在一次batch16 CPU尾部实际记录32个DW层执行。原run_hard_soft_clip/HardSoftSpatial已接显式--cpu-depthwise-library，run_live_window.sh第三参数ort/neon、第四参数可选同16保存张量；默认ort及原16帧数学/已有驱动保持。下一直接运行：匹配alignreset临时bit/保留DTB恢复→同真实16帧ort与neon原入口，检查最终128D与分类输出、整链收益；不以单层提速替代验收。

本轮实际环境失败：临时init=/bin/bash中的父shell被先前裸set -e改变；gcc相对搜索未找到cc1后，查询不存在目录的ls失败触发PID1退出，kernel panic（无新DW/NPU START）。用户已实际冷恢复，正常Ubuntu root登录及boot_id5b90298a-188c-442f-ab83-afbdbe5f6b98/modules空确认；正常环境gcc绝对路径/cc1可用，CPU编译与验证完成。h1_serial_command新增显式ChildShell，先关闭父errexit，再在sh子进程执行并返回BOARD_CHILD_RC；今后的临时复合命令使用此项。本轮当前正常Linux、PL身份未核验，不称仍已载alignreset或显示1，无待恢复。候选已保存USB float_dw_cpu_stage/candidate.tgz SHAde87489b847291a1c04a47920908d53dc220b35b365c536a57dcc5cdd0c12355，sync/RO；实测JSON见experiments/sol_float_dw_cpu_20261007/board_layer_verification.json、board_graph_verification.json、board_counter_check.json。整体基线/快照UNKNOWN，无Flash/原构建/数据集下载/提交，goal active。

## 2026-10-07 真实16帧识别与DSI整图更新连续三窗口BOARD通过

13:44最新：用户实际回复“已重启”后目标恢复active；冷启动root登录、modules空确认，临时JTAG下载alignreset bit100%，匹配DTB/保留区Linux正常启动，既有GPIO释放与最新USB overlay恢复成功。固定居中真实结果图提交后用户确认“不分块”；同启动原run_live_window.sh第二参数dsi依次运行三个真实16帧窗口，rc均0、复制各16/拒绝0、模块成功卸载、屏幕原位更新读回成功，用户最终确认“正常”。四象限错位本次实际验收已修复，不再等待冷恢复。整图/时序沿原候选，第一窗features[1,16,128]与同实际输入CPU逐字节精确、logits零差；混合7472.811ms对CPU16428.557ms。三窗采集3848.488/3766.461/3802.763ms，混合7472.811/7492.481/7493.611ms，采集至分类13023.744/12501.226/12537.919ms；含模块装载、渲染、内存发布的整窗16470/15230/15280ms。最后一个计时终点为内存读回/扫描使能，非屏幕光学时间。当前显示1、采集0、模块空，独立显示reservation保持，无待物理恢复。

实际分工保持每帧Hard两普通层、PL五点卷积/四DW/一Add，CPU普通28/DW13/Add9及固定点TCN；本快路径Soft/TCN/V4R硬件START0，既有C128硬件成果保留。三窗候选均“过敏”但无动作真值，拒识NOT_CALIBRATED；不能作为产品准确率验收。新RGB预处理完整入口已运行，但不同实际画面不能据此声称整窗提速。下一直接热点为CPU空间约4.74秒/16帧及采集复制/预处理约2.8秒；模型、位宽与16帧保持，按同输入收益选择后续实现。证据experiments/sol_camera_dsi_result_20261006/board_20261007/alignreset_three_windows.json与alignreset_window1/2/3.log；完整输入及输出USB alignreset_board_stage/evidence.tgz（SHA0b3a218c9c44f74ef1003f87ab0bc89e2372cadcb194a83197d056d4994b0337），已sync/RO。HEAD仍detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached diff空；整体原工程/快照UNKNOWN，无Flash、原工程构建、数据集下载或提交。

以下13:06恢复等待状态已被上述实际恢复与BOARD证据替代：

当前目标状态（13:06）：blocked，等待用户实际确认物理断电上电；这不是完成或用户暂停。冷恢复请求及相同阻塞已连续三个goal turn，独立代码/仿真/构建/软件准备均已完成，CAD会话已正常终态且当前无TD构建进程。未收到人工确认，不将设备视为已恢复、不换bit。用户回复“已重启”后继续临时上板→整图对齐→三个真实屏显窗口。

最新可执行产物：camera_dsi_alignreset_result.bit已实际完成SYNTH/P&R/STA/BIT，4052202B/SHAbffe38f89114d913d1f4b41417da4342a979eb9e86376d7958b96e118333ff0a。最终受约束路径setup+0.102/hold+0.024ns、TNS0，覆盖63.50%不称全路径签核，物理46194 slices/150 ERAM/174 DSP，34端口/44 pad行与scanfix完全一致。原摄像头计数器recovery保持计时且违例消失；30精确首级输入例外（接收net识别，PSreset共享slice实际输出external[0]），同步后级/数据计时保留。匹配DSI DTB不变。当前板卡仍旧scanfix/display1、modules空、USB已sync/RO；已请求用户物理冷恢复，未收到确认前不换bit。下一确认后临时下载→同一居中真实结果图→实体完整图验收→原入口三个屏显窗口。证据alignreset_verification.json。

上一版实体屏：R_SYNC=0版scanfix完成P&R/STA/BIT、临时Linux及显示提交，物理46182 slices/150 ERAM/174 DSP，34端口/44 pad行与前版一致，final +0.100/+0.023ns、TNS0、覆盖63.59%。bit SHAbd17a415f7bd8f873a87ac688f0de8b00c588913cde8aacfac624298ea22be7e。用户确认内容可见，随后明确报告四象限互换；花屏用户认为是接触并已恢复。显示缓冲2457600B实际读回仍与原图逐字节一致、模块空，不能称完整屏显验收通过。

一个当前问题：软件在扫描已运行后启用DDR读取，缺少首像素与新屏幕帧起点对齐（与象限移位的因果INFERRED）。最小dsi_scan_start先确认读回预取，再在原VS上升沿允许FIFO按DE消费，不复位AXI或改模型。实际原video_source/video_tpg仿真旧接法首帧35/40像素失败，新接法3启用相位/9完整帧通过；对齐版综合43013 slices/150 ERAM/174 DSP，P&R会话33670已完成；精确首级CDC后摄像头复位计数器recovery仍违例，高优化后setup-1.019/hold-0.265ns，未生成该版bit。复用已有fdma_frame_reset_sync在摄像头S_clk本地释放，原PLL reset不变；3释放相位/原99周期配置脉冲及PLL失锁复位SIM通过，alignreset综合95900已通过43013/150/174，P&R/STA/BIT已完成如上，BOARD待冷恢复确认。下一合格bit后冷恢复→同真实结果图确认不分块→原入口三个屏显窗口。软件预览竖向居中、标题居中已板端重新渲染，host result2_centered.png目视正确（文件验证，非实体屏证明）；最新show/helper/wrapper/恢复脚本及完整结果帧已另存U盘screen_stage并sync/恢复RO，旧preview_stage证据不覆盖；显式单保留缓冲原位更新及采集至显示提交计时已接包装，尚未实际更新运行，过渡可能短暂撕裂。

预处理后续：去除已为RGB源图的Pillow同模式convert整图复制（非RGB仍转换、resize/归一化数学不变）。板端同真实1920×1080 RGB图重复16次、交替两对微基准，旧中位1555.037ms/新1448.166ms，减少106.871ms（6.873%），224张量逐字节精确；这不是整窗提速证据。已接现有采集package并另存USB screen_stage/preprocess.py，旧baseline/manifest保留；下一实体对齐通过后原16帧入口测整窗实际收益。证据preprocess_rgb_copy_benchmark.json，NPU START0。

最新BOARD：生产模式仅把保存预览缩为384×216，实际16张1920×1080源图及224模型张量不变。DSI resume bit显示使能0下，窗口1采集/预处理/保存4.084秒、整入口13.256秒，features对同输入CPU逐字节精确/logits零差；用户调整相机后窗口2图像可见脸和手，采集3.556秒、推理7.377秒、采集至分类12.114秒，16复制0拒绝、模块正常卸载。候选咳嗽51.56%、拒识NOT_CALIBRATED，无动作真值。中文结果图已生成并显示全入口耗时；后续scanfix已上实体屏但出现上述四块错位，完整屏显仍未通过。证据preview_window1/2.json、preview_verification.json、preview_latest2.png；输入/结果及最新脚本已保存U盘preview_stage，恢复RO。

首版显示阻塞已修：首次DSI bit继承uidbuf默认R_SYNC=1但I_R_sync接0，无法连续扫描；显式R_SYNC=0版已出实体内容，但上述起点对齐尚未通过。首版bit/DB及scanfix全部产物保留；下文resume时序/资源仅属于首版bit。

视频：用户移动扩展坞接口后，COM4实际命令恢复；冷恢复已确认。复用原受控camera/PW32 bit、保留DTB和模型，仅改CPU复制/解码/保存。Pillow raw解码对真实BGRX/RGBX、完整/带stride的ROI图像RGB及224张量逐字节精确。PNG移出采样循环并用无损level1，板端同图1.528秒对原6级5.813秒，像素精确。连续复制仍产生55/71、95/111次重写拒绝；增加最小freeze-copy，在uidbuf停止接收新帧、当前帧完成/活动槽0/AW=B后复制，原代数检查保持；未改硬件/驱动/模型。

整图/时序：freeze-copy真实16帧采样预处理3.400秒，含两张1080p PNG/NPY6.671秒；特征[1,16,128]对同CPU字节精确、logits零差，混合运行7.464秒、含输入/初始化8.129秒，同输入CPU15.900秒，各一次。随后原--capture-fdma入口接默认freeze-copy，同启动三个完整窗口均PASS：采样3.330/3.329/3.443秒、含保存6.584/6.585/6.528秒、推理7.406/7.446/7.483秒、从采集入口至分类15.219/15.257/15.238秒，复制拒绝均0。Hard160、FRONT96/BLOCK34/DW16各16、CPU Add16、CPU direct TCN；仍有CPU空间层，Soft/V4R硬件0。未到稳定8FPS，NOT_CALIBRATED且无现场动作标签，三个窗口不等于识别质量或实体屏连续验收。

显示首版：发现旧会话13666及TD进程已不存在，旧日志中断原因UNKNOWN；从未变camera_dsi_place.db恢复布线，不重综合。首版实际P&R/STA/BIT完成，物理47127 slices/150 ERAM/174 DSP，原34管脚匹配；真实PW32数据setup违例-0.056ns由post-route high优化修复。只对实际报告接收net所证实的FIFO/flags/reset首同步级施加精确例外，final SWNS+.034/HWNS+.021ns、TNS0、覆盖63.52%不称全路径签核。camera_dsi_result_resume.bit SHA397e9905a24d937e637474a2b8baf3cc19e38faaf1e1547b3d097a80e25b25e5；匹配DSI DTB另保留4MiB，已临时启动并跑通真实采集/识别。显示保持0，等待上述R_SYNC修正版。

修改入口：implementation_video/capture_model_clip.py、model_pipeline/src/sign_model/fdma_frame.py、implementation_hardnpu/runtime/run_hard_soft_clip.py；直接运行包装位于experiments/sol_capture_cpu_20261007/run_live_window.sh。证据freeze16_verification.json、live_three_windows.json及sol_camera_dsi_result_20261006的resume_*报告。全部窗口后Hard/共享PL正常卸载，无Soft固定DMA、无待物理恢复。goal实际active；旧paused声明为历史。HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/cached diff空；无Flash/原构建/提交/数据下载，整体基线UNKNOWN。

## 2026-10-06 真实IMX415单帧及16帧识别BOARD通过；DSI结果候选布线中

视频：复用受控PW32 bit，先执行既有release_dw16_reset.py，实际GPIO0→1后新FST1 ID/ABI读取正常。CSI/ISP连续增长、IIC错误标志0；单帧1920×1080完整复制、代数检查和PNG取回通过，人物双手清晰可见。原图和16帧输入已经U盘取回，证据experiments/sol_dsi_camera_pw32_20261006/board/real1。首次挂起与遗漏复位步骤的因果仍INFERRED，修正启动顺序实际通过；未改bit/模型/NPU驱动。

整图/时序：真实16帧NPY送原入口，features[1,16,128]对同候选CPU逐字节一致，分类logits零差。混合运行7476.559ms，含输入/初始化8588.597ms；CPU对照16363.241ms（运行窗口，各一次）。实际Hard160、FRONT96/BLOCK34/DW16各16、CPU Add16，较快时序用CPU direct TCN，Soft/TCN硬件/V4R硬件0；既有C128硬件资格保留。本次模型候选“咳嗽”49.748%，拒识NOT_CALIBRATED，没有动作标签真值，不能称手语正确识别或全系统完成。

当前实际瓶颈：16帧采集连预处理和两次PNG保存31425.064ms，首末接受时刻1.512→25.381秒，间隔不均匀，未达到8FPS；不能把目标采样率或传感器计数写成模型实际帧率。采集结束enable0、AW/B相等，Hard/共享PL正常卸载，modules空，无待物理恢复。下一先完成实体屏固定结果图，随后按实际开销修复采样时间。

显示：复用原DSI扫描/配置/TX和PLL/管脚，独立4MiB no-map显示缓冲0b800000..0bbfffff，与摄像头三个槽/NPU缓冲分离。1024×600真实结果图及2457600B BGRX已生成，尚未显示到实体屏。experiments/sol_camera_dsi_result_20261006综合42973 slices/150 ERAM/174 DSP，P&R会话13666运行；当前编译bank为兼容1.3加display-enable90000160/reset0，后续fresh builder生成1.4，不将其写成已BOARD。不能使用采集专用bit开启显示。

相关修改：setup_linux.sh复位顺序；capture_model_clip.py新增可显式延长的实际采集deadline；prepare_camera_dsi_result.py及show_dsi_result.py接固定屏显。源码和qualified原产物保留，无Flash/原工程构建/提交/数据下载；整体基线UNKNOWN。HEAD detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，cached diff空。目标工具当前返回paused，本轮用户物理恢复后授权操作已完成，不擅自修改目标状态。

## 2026-10-06 原版CSI/DSI通过；受控采集bit完成，修复首次寄存器访问启动顺序

当前更新：正确管脚候选已P&R/STA/BIT完成，19个原端口匹配；物理45802 slices/143 ERAM/174 DSP，final SWNS+0.100/HWNS+0.021ns、TNS0，STA覆盖63.04%，不称全路径签核。bit SHA8408fb59cfa323b60dbfcb1a3e8babc908b8682a3166521d0743b4f50ea3a205；临时Linux启动及24MiB no-map保留验证通过，私有Pillow和原模型恢复成功。首次单帧进程启动后命令无返回，未取回图像、未运行NPU；源码核对发现新bank继承dw16_resetn，而setup遗漏已有GPIO复位释放，根因仍INFERRED。用户已实际物理恢复；setup复用原release_dw16_reset.py、置于GP读取前，正在重试同bit。真实单帧/16帧识别仍未通过。证据experiments/sol_dsi_camera_pw32_20261006/board及pins_final3.ts。

视频实际跑通：用户断电重插CSI并冷恢复后，原11_csi_dsi_imx415_7cun的platform init、原phy_1 bit和原ELF匹配运行，main命中并明确resume，PC08000238/reset1f1/ports1133；用户确认“有实时摄像头画面”“完全清楚”。原板、IMX415和DSI屏已具备实际工作条件。Linux端完整帧取回、真实16帧识别、识别结果实体屏显示仍NOT_RUN。整图/时序沿用PW32保存帧两稳态中位7426.202ms、features字节精确/direct logits零差，未改模型/NPU驱动。

实际修复：重插后的ELF加载读回虽曾通过，但_start关闭缓存后指令变为旧数据并异常；用户物理恢复后，在OCM执行原SDK的cache clean/invalidate例程，实际SCTLR 00c5383d→00c52838（M/C/I关闭），再加载/比较118366B实际sections并运行成功。GDB detach不保证继续，运行脚本改明确resume/disconnect；此次成功有额外Tcl resume日志。不能把缓存加载故障或现场重插单独定为旧零帧的全部根因，也不以此前局部缓存读样本否定现在的实时画面。证据experiments/sol_original_dsi_debug_20261006/board/cache_clean_retry/及source.json。

下一可运行交付：experiments/sol_dsi_camera_pw32_20261006保留当前PS80MHz/HP0网络，移植原实际system.v的CSI/ISP、管脚和PLL（原输入100MHz、输出50/24/约70MHz），HP1接现受控FDMA，reset默认capture0、显示读回关闭。FST1 ABI10003位于90000100；原完成响应/帧代数检查复用。新增bank仿真通过，综合42007slice/143ERAM/174DSP；布局布线运行，时序/bit/板测待验。capture_model_clip及原识别入口新增status-offset，匹配80MHz DTB保留24MiB no-map槽且禁用已移除Soft节点，17KB补丁已部署板卡和U盘。一个直接等待项为候选合格bit，之后正常软件重启U-Boot→受控bit及匹配保留DTB Linux→CSI/ISP增长→单帧目视→真实16帧原入口。原版实时画面对照后已按用户确认冷恢复至正常Linux，modules空；后续正常软件重启U-Boot，下载受控bit并加载保留DTB，不能在原常开FDMA bit上直接启动Linux。

无Flash/原工程构建/数据下载/提交，goal active；整体基线完整性UNKNOWN。

## 2026-10-06 后续：共享PW32完整16帧BOARD通过，同模型整链减少3.79%

整图：旧模型、16张不同保存帧、80MHz、CPU批量16及fixed-cpu保持，共享BLOCK34点卷积MAC由16扩为32。首图25088B逐字节精确，device66.199ms（旧85.727ms；CPU核验1569.139ms另列）。三个完整窗口7405.386/7394.587/7457.818ms，128维features字节精确、direct TCN logits零差。后两稳态中位7426.202对原PW16相同batch profile7718.701ms，减少3.789%；含输入准备/初始化8086.984对8369.368ms减少3.374%。相同板/model/input/profile、不同启动、每版两个稳态窗口；冷首窗总8636.573ms另列。实际Hard160、FRONT96/BLOCK34/DW16各16、CPU Add16，Soft/TCN硬件/C128/oracle0，仍有CPU桥接。证据experiments/sol_shared_pw32_soc_20261006/board_verification.json。

第二进程沿用了已装载模型的Hard实例，初始化拒绝、START0；guard PASS卸载后按既有每窗新实例流程通过，未改驱动门槛。全部模块正常卸载，无待物理恢复。原16路六层AXI仿真6447806cycles保持，新32路4875178（减少24.390%）不替代整链收益。综合22919slice/99ERAM/126DSP，物理25561slice/83ERAM/126DSP，final SWNS+0.108/HWNS+0.021ns，沿用实际PS复位首同步器精确例外；bit4052202B/SHA482fe992763b0935f2d655514137a6c491b98391c69350cf4416cd4cd37ec7ce。root仍默认MAC16，独立候选32，未扩为C576。

真实第12块实验量化逐通道M16/floor适配运行后仍扩张27574/112896、投影9415/18816值不符/max1，拒绝该具体载荷、未START；不是证明全部Hard模式不支持。时序真实C128资格保持，较快profile用精确CPU。原视频FD saved debug组合phy_1 bit＋fdma_en.elf＋soc_plat.tcl已隔离暂存；实际ELF入口访问EL3寄存器，须匹配SDK调试启动，不能直接从Linux/U-Boot跳入。下一直接任务恢复原演示运行环境、观察画面，不等待全空间迁移；BOARD尚未运行。CSL-500依用户要求不下载/不代发申请。

原大84064/PID52284最后route43/over424、CPU18495.80s仍运行，输入未改，未有其最终bit。无Flash/原工程构建/提交；整体基线与外部快照UNKNOWN，HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c detached、cached diff空。内部整链有收益，摄像头/实体屏/产品质量拒识仍未完成，goal active。

## 2026-10-06 后续：固定16 CPU批量前段整链BOARD通过；NEON未取得整链收益

整图/时序：同无Soft OC16 bit、旧空间候选、16张不同保存帧及fixed-cpu时序，CPU三个前段批量16、PL仍串行。首次整链7768.407ms/init886.349ms精确，但重复创建会话；改为直接创建所选会话后，第一模型符号batch引发初始化拒绝，硬件START0、正常卸载。修为固定16后两窗口7703.076/7734.326ms，对照逐帧7849.691/7843.087ms；运行中位7718.701对7846.389ms（减少1.627%），含输入准备/初始化8369.368对8469.513ms（减少1.182%）。节点/权重/精度不变，128维features逐字节精确、direct TCN logits零差。收益较小，批量保留可选，原逐帧/硬件时序回退保持。每窗Hard160、FRONT96/BLOCK34/DW16各16、CPU Add16、Soft/TCN硬件/C128/oracle0；分摊的CPU帧耗时不是逐帧延迟。证据experiments/sol_cpu_batch16_fix_20261006/verification.json。

NEON边界转换实际精确，微基准5.378→2.800ms；整16帧交替各两窗中位7794.024对原7784.972ms，含输入/初始化8445.128对8441.808ms，无整链收益，默认保留原转换。证据experiments/sol_neon_codec_20261006/verification.json。

本阶段全部模块正常卸载、无待物理恢复。下一CPU尾部批量约3.05秒仍是空间热点，先适配划算Hard或复用共享PL，不新增12/13常驻引擎。视频/实体屏/质量拒识未新增验收。用户选中国手语CSL-500，并明确暂不下载；只查阅官方资料，未下载或代发申请。原视频演示FD选bit并debug启动，匹配程序仍待复现。原大84064/PID52284仍正常运行，阶段末route42/over421、CPU16384.53s，最终STA/BIT未完成、输入未改。HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c、cached diff空；整体基线/快照UNKNOWN，无Flash/原工程构建，goal active。

## 2026-10-06 最新：CPU Add、OC16及无Soft独立bit完整16帧BOARD通过

整图：同一旧qualified bit/model/input，CPU H6 Add完整16帧7986.779ms、Soft路径8241.046ms，features逐字节精确/logits0差；运行窗口减少254.267ms（3.085%，各一次，初始化另列）。首次Hard在START前被空闲门槛拒绝，写0次但触及时钟/复位，按实际未知DMA状态取回日志后用户物理恢复；原因UNKNOWN，没有降低门槛或自动重试。证据experiments/sol_cpu_h6_main_20261006/verification.json。

紧凑OC16＋BLOCK34独立SoC已P&R/STA/BIT/BOARD：最终SWNS+0.102/HWNS+0.020ns；实际物理41863 slices/141 ERAM/160 DSP。真实首图BLOCK34输出25088B零差，device85.727ms（CPU核验1621.160ms另列）；原16帧三个PL窗口8211.204/8026.035/8136.717ms、同启动中位8136.717ms，features对同候选ARM CPU逐字节精确/logits0差。同bit相同模型以CPU执行block3＋4为9471.174ms（一次），PL中位减少14.090%。不能与不同量化候选的旧7.905/8.442秒混作同模型速度对照。证据experiments/sol_v4r_oc16_soc_20261006/board_verification.json。

无Soft独立bit同样实际BOARD：8211.739ms/init1110.693ms，Hard160＋TCN2、FRONT96/DW16/BLOCK34各16、C128 V4R1、CPU Add16、Soft0、oracle0，features/logits零差。综合21994 slices/83 ERAM/111 DSP，较保留Soft的紧凑综合净释放20687 slices/74 ERAM/49 DSP；物理24500 slices/67 ERAM/111 DSP，最终SWNS+0.100/HWNS+0.024ns，bit SHA5df15706ef4acc86912f51263a0b79f751101e4696095f215845bb8e18599524。Soft旧GP端口只返回DECERR，无HP1事务，实际端口SIM通过；CPU Add是真实计算。该新bit已一个窗口通过，三个窗口属于前一含Soft但未用Soft的bit。证据experiments/sol_cpuadd_oc16_soc_20261006/board_verification.json。

时序：OC16预算0/32的49152B输出、区间及分类对原资格金样精确，残差cache实际16384读，资源压缩不当作核心提速。同真实特征5次CPU计时：精确三层固定TCN中位27.606ms、原生CPU V4R48.296ms。随后fixed-cpu已实际接原完整16帧入口：两次7747.996/7772.205ms，对照同bit交替Hard前缀＋PL V4R两次8143.328/8039.454ms；中位7760.101对8091.391ms，运行窗口减少4.094%。计入输入准备和初始化后中位8417.954对8658.676ms，减少2.780%。CPU时序中位30.367ms、硬件路径50.701ms；硬件模式运行窗口还含194～212ms串行切换/初始化，不能将全部差值归于V4R核心。精确CPU logits与原精确参考相同、在预算32证书内，同咳嗽类别；预算32与精确logits存在正常差值。对当前profile优先使用fixed-cpu，保留硬件C128显式选择，第12块新量化未启用。证据experiments/sol_cpuadd_oc16_soc_20261006/fixed_cpu_main_verification.json。

视频/实体屏/质量拒识未新增验收，保存输入类别咳嗽、NOT_CALIBRATED。无Soft bit同启动共5个完整窗口通过，Hard/TCN/共享PL均成功卸载，无Soft固定DMA，无待物理恢复；goal active。下一针对剩余CPU空间约4.77秒选择不改变模型的实际计算优化，复用现已关闭ORT空闲自旋配置，不重复实现该项。原大BLOCK34布线84064/PID52284正常收尾、输入未改，本阶段最后迭代39/CPU13249.52s；其结果不替代上述独立候选。无Flash/原工程构建/提交，基线整体完整性UNKNOWN。以下为历史阶段记录，未完成项以本节覆盖。

同真实block4输出、原CPU尾部模型、关闭空闲自旋的5次交替计时已完成：双线程中位199.050ms，单线程305.111ms；输出逐字节相同、无设备START。保留现有双线程，不采用较慢设置，不将该独立张量微基准当整链收益。证据experiments/sol_cpuadd_oc16_soc_20261006/board/cpu_tail_threads.json。

## 2026-10-06 按异构复审完成紧凑V4R资源改造，精确CPU Add接入口

当前目标以用户最新DR1M90G_HETEROGENEOUS_REDESIGN_REVIEW_20261006.md为准：同模型、同输入的端到端速度及质量优先，合理保留CPU，不要求全部计算迁移到FPGA；内部网络/C128先行，视频最后。第12块新量化保持独立实验，未替换默认模型，12段9/12不作产品质量验收。

整图：原入口新增--soft-backend cpu，复用原H6整数M/S、zero、舍入与饱和，Hard硬件可保留而H6用CPU，报告实际CPU/Soft次数及CPU耗时。PC原16帧对原block4候选features逐字节一致/logits0差（3096.196ms仅PC）；实际ARM上对已资格Soft保存输入/输出执行CPU Add，输出7840B逐字节一致，200次p50=1.088895ms/p95=1.155588ms/mean=1.105610ms，START0/lsmod空。现Soft硬件旧16帧调用总350.254ms只能作定位依据，不能与该微基准直接相减宣称整链提速。14240B主链补丁已准备；下一用已通过bit做同候选CPU Add与Soft完整16帧比较，Soft替代尚未整链BOARD。

时序：C128新增OUTPUT_GROUP=16，只复用当前输出通道组的两端区间，模型/INT32及INT64位宽/预算/精确回退不变。预算0/32各2048 center/lower/upper对原金样全精确，证书包含精确值；默认128组回归保持原周期。修复分组输出与DMA旧顺序检查冲突，保持对预期索引的严格核对和T16/C128外部布局；完整DDR仿真、64B守卫及最终B通过。预算32周期1418592→1473685（+3.8836%），残差缓存读2048→16384，不能称计算提速。

独立模块综合48 ERAM；完整SoC综合实测157/280 ERAM（原278，净减121），42681/52480 slices（原42319，增加362），160/240 DSP保持；通用Soft仍占74 ERAM，未删实例。新experiments/sol_v4r_oc16_soc_20261006布线99548已启动并进GP iteration，最终时序/BIT/BOARD PENDING。原BLOCK34 84064/PID52284输入未改、仍活跃（本阶段查看迭代33/CPU9140.67秒），正常收尾，不重启。证据sol_v4r_oc16_20261006/{verification.json,cpu_h6_board_result.json,cpu_h6_verification.json}及独立SoC综合报告。

视频/实体屏/拒识未新增验收。下一直接运行是已资格bit上的CPU H6整链，紧凑版同时收尾时序后再测；暂不叠加C576引擎。没有新NPU START/Flash/原工程构建/提交，无待物理恢复状态，goal active；整体基线完整性UNKNOWN。

## 2026-10-06 第12块整数/原生CPU接原16帧入口通过，后续迁移包准备完成

复用既有UINT8/S30逐输出通道量化及Add算法，将实测热点第12块96→576→96/14×14接入原HardSoftSpatial入口（可选--front-block12-assets，默认不启用）。真实保存16帧输出[1,16,128]，分类咳嗽；电脑整数参考3669.761ms、原生CPU2797.506ms，原生与整数参考features逐字节相同/logits0差。新增量化对原浮点第12块max0.584748/RMSE0.162838；整128维特征对原block4候选max0.398079/logits0.059568，不能写成对浮点零差。12段已有弱对齐三类样本分类保持12/12，正确数9→9，仅有限质量对照。

新参数150528B；原生C复用现有有符号S30 ties-even舍入，真实/全0/全255/随机输入对独立整数参考全零差。纯CPU板端包block12_cpu_board1.tar.gz3478370B/SHA509508edc7ae0db64e217f73e2db6d38edeff1153759da1be7002a1e4ba96e22及run_cpu.sh已准备，未传输/未执行，不能用PC2.798秒替代板端耗时或硬件加速证明。证据experiments/sol_block12_20261006/{main_verification.json,clip_quality.json,native_real1/verification.json,board_package.json}。

核阅现pointwise_packet_contract仅支持scalar DQ；新参数per-channel S30不能直接装入旧Hard槽，这不等于硬件本身不支持。共享PL当前8位channel、4位group和固定C144缓存也不能直接执行C576；下一迁移采用共享引擎分组参数缓存/新固定几何，并实际SIM/资源/耗时核验，不新增常驻整套引擎。原BLOCK34候选不变，阶段末一次查看同84064/PID52284仍活跃（route迭代26/CPU5691.53秒），无新bit/START。旧混合BOARD8.442秒、最快7.905秒与CPU16.621秒保留。完整空间/时序尾部/质量/视频屏显未完成；goal active，无待物理恢复新状态。

## 2026-10-06 第12块真实模型切分与计算张量准备完成

新增prepare_block12_probe.py，复用现有extract切出before/block12/after，并从已取回真实第4块输出运行当前CPU前段，获得1×96×14×14输入/输出、两个1×576×14×14激活、投影、训练权重/bias和现有量化域。电脑实际切分回放对原CPU尾部max1.0967e-5、非逐字节精确；这是浮点切分结果，不是新整数块、128维整链或硬件通过。当前H4/H5固定槽仅支持既定904/456/328B packet、输入7840/47040B等布局，不能直接下发C576新块；新块须实际匹配配置。证据experiments/sol_block12_20261006/probe/probe.json。原BLOCK34布线同84064/PID52284阶段末一次查看仍活跃（迭代24/CPU5013.44秒），无新bit/START。下一准备为第12块真实量化计算及主链质量对照，硬件验收仍等待BLOCK34最终时序。goal active，旧整链BOARD结果不变。

## 2026-10-06 CPU尾部真实板端节点计时完成

使用已取回的真实第4块UINT8输出和现有cpu_after_block4模型，仅CPU运行，3次207.451/207.517/207.646ms（含profiling），重复输出1×160×7×7精确，设备START0。热点第12块节点总28.154ms、第13块28.043ms，实际为C96→576→96、14×14残差块；第5/6块18.338/17.818ms。后续迁移候选优先检查12/13真实张量与现有Hard packet/共享PL引擎容量，不能仅按模型顺序或PC排名选择，也不先保证迁移后提速。完整混合8.442秒与CPU16.621秒结果未变；没有新增六层硬件BOARD。原布线84064/PID52284一次查看仍活跃，迭代23/CPU4542.66秒，无新bit。板卡正常、lsmod空，无需物理恢复。证据experiments/sol_block34_20261006/{after_block4_board_profile.json,next_cpu_hotspots.json}；goal active，完整空间/时序尾部/质量/视频屏显未完成。

## 2026-10-06 后续资料核对与CPU节点计时入口准备

按用户要求停止频繁盯布线，转查原V4R方案、当前C128源码与真实后续模型。当前C128已包含块摘要不变、残差缓存跨重叠tap复用、逐输出预算停止与区间同时提交；不能把这些再列为全部未实现。仍缺同资源直接逐点硬件基线、硬件时序尾部及CPU精确回退替换。最新SIM预算32较预算0仅少3.034%周期，不代表对直接硬件或整链提速。第5/6空间块实为C32→192→32、28×28、stride1和Add，现固定C144核心不能直接运行；当前ERAM278/280，后续复用共享引擎。新增tools/npu/profile_after_block4.py，用已取回真实UINT8输出计时CPU尾部节点；电脑实际运行重复输出精确，输出1×160×7×7，仅PC准备验证，板端未执行。22KB后续运行包与next_work_research.json已准备。原8.442秒混合、16.621秒CPU结果沿用；摄像头/屏显/拒识未完成。原布线会话84064不重启、不修改其候选，准备后再检查；goal active，无新增设备START。

## 2026-10-06 核心缓存/残差提交流水SIM与综合通过，新P&R运行

上轮AXI寄存版布局布线已实际终止：raw SWNS-0.190/STNS-9.732/HWNS-0.845ns，未生成bit、未START。剩余setup实际在PW核心缓存读取→乘法，以及V4R权重乘法/末项累加→区间检查/写入；不能靠PS复位例外消除数据失败。新增PW像素/权重读寄存、有效位对齐；V4R末项先存acc_exact，再在固定pair地址提交两区间端点。模型、ABI、80MHz及原独立金样保持。

修正版六阶段真实首图AXI输出全精确，53531读/30765写与响应、6447806cycles（80MHz80.597575ms仅SIM），背压/守卫/最终B检查通过。V4R预算0和预算32各2048个center/lower/upper全部精确，采样2048次及MAC/跳过计数不变，周期1462976/1418592；新增提交周期不能称V4R提速。新综合42319/52480 slices、278/280 ERAM、160/240 DSP通过。block34_corepipe_physical.tcl会话84064/PID52284实际运行，最终时序/BIT/BOARD仍PENDING；先前失败报告和原qualified产物保留。

整图沿用本日BOARD CPU16621.451385ms、features/logits0差；真实C128硬件沿用旧资格，新修改仅SIM尚待同bit板测。相机/实体屏/拒识未完成。当前下一动作同一P&R最终报告→合格临时bit→真实首图→原16帧对本次原生CPU；不重做Soft/T01。证据experiments/sol_block34_20261006/{axi_corepipe_verification.json,v4r_corepipe_verification.json}及isolated corepipe gate/db/log。goal active，无新设备START/Flash/原工程构建/提交，整体基线UNKNOWN。

## 2026-10-06 六层AXI时序修复SIM/SYNTH通过；原生CPU整16帧16.621秒零差

实际修复10月1日布线报告的两条setup失败：DW stride/address/page计算到HP0 ARLEN（-0.010ns），PW分布式结果缓存到HP0 WDATA（-0.001ns）。仅新增DW请求地址/长度寄存与PW写数据寄存，80MHz、模型、ABI60001、最终B响应和失败固定缓冲保持。修正版真实首图六阶段完整AXI SIM输出零差、53531读、30765写/响应、6383596cycles，AR/W背压稳定及64B守卫通过；79.79495ms仅仿真折算。综合42353/52480 slices、278/280 ERAM、160/240 DSP通过，新布局布线会话85250/PID65984仍运行，最终时序/BIT/新硬件START尚未完成。原失败报告与gate/route数据库保留。

等待构建期间，复用已验证S30舍入实现原生CPU PW96与block4并接原入口。板端真实PW96输出对独立整数参考零差，1030.098→75.403ms；block4真实输入636.523→57.088ms，另三边界输入均零差。仅block4原生整16帧31903.352ms；两项原生整16帧16621.451385ms/init567.665585ms，对同候选39471.341492ms CPU参考features逐字节一致、logits0差，分类咳嗽。此为CPU软件优化，设备START均0，不是新硬件、V4R收益或旧7.905秒候选的加速结论。时序沿用真实CPU TCN/V4R；相机/实体屏/拒识仍未完成。

证据experiments/sol_block34_20261006/{axi_verification.json,native_board_verification.json,pw96_native_board_verification.json,native_front_clip_verification.json}及原始输出/日志。正常Linux已实际登录、lsmod为空，无待恢复设备状态。新运行包及CPU补丁位于/root/sol_block34_main_20261006_1，不覆盖已资格目录；临时只读Linux运行时须复制到/run，避免主入口写运行文件到只读root。下一动作取得合格新bit→首图独立比较→原16帧新硬件与本次原生CPU对照；不重复旧NPU资格。goal active，未Flash/原工程构建/提交；HEAD2685d5f，整体基线状态UNKNOWN。

## 2026-10-01 BLOCK3＋BLOCK4完整AXI与综合通过，布局布线运行中

固定六层连续DMA已实现并复用逐点/DW核心，一次作业输出C32/28；第3块C24输出暂存输出DMA，扩张4完整读完后才覆盖，未增加中间DMA分配。28宽内部及最终输出采用32字节行距，用户端解包为25088B有效图像。真实首帧全六阶段写回逐字节正确，53531读、30765写/响应、6224629cycles（80MHz折算77.8078625ms仅SIM），64B守卫和最终B完成判据通过。

新BLOCK34 ID424c4b34/ABI60001、参数64256B、输入75264B、物理输出28672B；输出DMA实际75264B供C24暂存，驱动检查完整物理缓冲守卫、仅拷贝最终28672B，保留超时固定缓冲。原16帧入口新增pl34后端与计数，组合输出桥接的CPU整16帧features逐字节一致，2767.5354ms为电脑参考。目标驱动467560B/SHAaac7f5f27a2ec89bd369a04abbd8c550fa94cf3e27719ee8e93fbe45b553ed71编译完成，尚未加载。

隔离experiments/sol_block34_soc_20261001综合通过：42276/52480 slices、278/280 ERAM、161/240 DSP。当前physical.tcl会话91834实际运行，最终时序/BIT/BOARD PENDING。首图金样与原16帧匹配包block34_board1.tar.gz265883B/SHAbc1c6395be5b2b622113f20d55c6945a442cba0dfc1d882a2a0f2dc063990d7c已准备，旧包保留。下一动作检查实际布线时序→生成合格临时bit→首图独立CPU金样→同候选板端16帧数值及耗时；不以仿真折算替代板测或宣称已提速。

证据experiments/sol_block34_20261001/{axi_verification.json,combined_adapter_verification.json,driver_build_result.log}及隔离gate db/area。板卡实查正常Linux、模块空/uptime5481.51s，本轮无设备START、无需物理重启。时序C128沿用已通过结果，摄像头/实体屏/拒识仍未完成；最快7.905秒及8.442秒硬件链保留。goal active，未Flash/原工程构建/提交，整体基线状态UNKNOWN。

## 2026-10-01 第4块真实CPU接原16帧入口，三层算术SIM通过；DMA接入中

紧邻BLOCK3的backbone.4 C24/56→C144/56→C144/28→C32/28已提取真实权重/偏置/S30参数，新增可选front-block4-assets直连真实UINT8张量，原默认链保留。参数提取曾因生成器变量遮蔽选到错误节点，已按实际Conv修复。原16帧入口在电脑CPU运行2617.0184ms；板端CPU运行39471.341492ms/init1029.685720ms，完整features[1,16,128]、分类咳嗽0.983352。第4块Python整数参考约0.54秒/帧，不作为加速或速度基线；当前新增块尚未硬件运行。

板端第4块实际输入取回后在电脑重新计算，输出25088B逐字节精确。跨平台整链feature max0.257924，不能写零差；差异在第4块输入之前已存在（358码不同/max2码），其上游具体原因尚未定位。相对上一候选板端CPU feature max0.511336/mean0.048408，属于新增量化变化。现有12段弱对齐三类样本标签12/12不变、正确9/12不变，只是有限质量检查，拒识仍NOT_CALIBRATED。

复用pointwise_row_core，只新增默认0的展开输出零点参数：扩张3真实行各8064B、投影3真实行各896B精确；现有dw3x3_patch_core在真实stride2整图112896B精确、有背压。只算术SIM，不是DMA/SYNTH/BIT/BOARD。证据experiments/sol_block34_20261001/{cpu_board_verification.json,cpu_tensor_verification.json,clip_quality.json,sim_verification.json}；完整板端CPU归档10535B/SHA0b62262127f97587b21fd25554ec9dbae38f8aabaa6de8048628991dbfe86f1a，真实输入输出归档75143B/SHA25a884273df56e1a64582cfd77c450f24201d67ee441fe95ac1cb62da4d23fdd。

用户物理恢复后实际正常Linux、模块空；本轮仅CPU运行，无设备START、无需再重启。新增差异包262623B复用板端模型字节重建3952045B CPU后段，无大模型重复传输。下一直接动作：复用BLOCK3的逐点/DW与AXI完成规则，接固定BLOCK3＋BLOCK4连续DMA，正确保留C24中间缓冲；28宽行的读写布局是本次具体接入项，不重做旧资格。时序沿用已通过真实C128，视频/实体屏延后；旧8.442秒与最快7.905秒保留。goal active、未Flash/原工程构建/提交，整体基线状态UNKNOWN。

## 2026-10-01 前段PW96＋DW96融合BOARD：完整16帧8.442秒、同候选数值零差

原16帧入口实际完成16次FRONT96融合（旧DW96独立START为0）、16次BLOCK3、16次DW16、162次Hard含2TCN、16次Soft及1次真实C128 V4R。features[1,16,128]与本阶段同候选CPU逐字节一致、logits0差；total8441.524494ms/init780.330578ms，比前版8732.382386ms本次减少290.857892ms，仍慢于旧最佳7905.177ms，最快默认链保留。分类咳嗽0.984462、拒识NOT_CALIBRATED、输入为保存帧，非相机/实体屏验收。CPU仍30普通Conv/14DW/8残差，cpu_spatial_ms5251.590285，不称全空间硬件。

新融合首图301056B独立CPU金样零差，device44078520ns/3521504cycles、host ioctl54.951870ms；16帧前段CPU before median35.495805ms、融合ioctl55.159365ms。product cpu_oracle_calls0，无重复CPU金样。新bit最终SWNS+0.100/HWNS+0.020ns，ERAM278/280；唯一负raw hold为实际PS复位同步器首级，复用精确端点例外、数据保持计时。bit4052202B/SHA224f66e4172ed26d7d7e58d9562fe4bd68900a3850e7990c50c7767b6d65feae。临时DTB CRC4f533a68、80/40MHz分频、JTAG芯片校验和完整下载及GPIO0→1释放实际通过，未Flash。

完整原始输出和日志在experiments/sol_front96_fused_20261001/board，verification.json及evidence.tgz243586B/SHAd594cea64b9b4f42a7ba10145959faa98eb5dbe60766f990c5054ac27416d18f。Hard/TCN安全卸载，net_pl实际rmmod成功，Soft固定DMA；用户已确认再次物理恢复，后续需按cold_ready.log实查状态。goal active，原工程/快照整体仍UNKNOWN，无提交。

下一直接实现针对剩余CPU最大段：复用已有after_block3真实ORT逐算子profile（该段约234ms/帧，本次仍约230ms），首先处理紧邻的backbone.4 C24/56扩张与DW stride2（原profile约11.72/11.60ms），沿原入口扩大连续计算块；先实际张量及有限质量，再接已有MAC/RNE/AXI，不重做T01/V4R资格。下列CPU/SIM/综合记录为本阶段历史，BOARD已由本节覆盖。

## 2026-10-01 前段PW96＋DW96融合：CPU整链、真实图SIM、综合通过，布线中

新signed16 PW96实际计算已接原16帧入口。板端CPU完整features[1,16,128]通过，total30966.127508ms；相对前版候选feature max1.007915/mean0.084305、logits max0.065126，分类仍咳嗽。该整数CPU参考每帧约1.01秒，不作为优化CPU速度基线。现有12段弱对齐三类样本全部保持原标签，正确9/12不变；只是有限质量检查，不等于拒识或完整产品质量验收。

新增固定16通道组PW→三行缓存→DW融合，一次START覆盖C96/112→C96/56，消除1.2MB中间DDR图。使用厂家公开DRAM功能模型的真实单图完整AXI仿真逐字节正确：301056输出、22128读事务、5439写与响应、3520035周期（80MHz估算44.0004375ms，仅SIM）。首次综合313/280 ERAM，行缓存改分布式后仍310；实际剩余32来自通用系数寻址，修成固定16通道系数寄存器后新综合278/280 ERAM、42154/52480 slices、158/240 DSP。原输入缓存归因已纠正，失败报告保留。

CODED/SIM/SYNTH通过；P&R正在experiments/sol_front96_soc_20261001/front96_physical_coeff.tcl运行，尚无最终时序/BIT/BOARD。新front96 ABI50001、驱动目标编译通过且尚未加载，原入口新增fused后端；启动脚本第四参数在set --前保存，避免丢失后端。下一动作布线实际时序→合格临时bit→真实单图金样→原16帧数值/实耗时。现有8.732秒和旧7.905秒板测链保持，不宣称新候选提速。

证据experiments/sol_front96_fused_20261001/{cpu_verification.json,cpu_clip_result.json,coeff_axi_sim.log,net_pl.ko}、experiments/sol_front_pw96_int16_20261001/clip_quality.json及隔离综合front96_coeff_soc_gate.area/db。用户确认冷恢复后正常Linux实查，模块空，本阶段仅CPU计算和目标编译，无新硬件START。时序/V4R沿用真实C128，视频/实体屏/拒识仍未完成；goal active，未Flash、原工程构建或提交，原工程与快照整体状态UNKNOWN。

## 2026-10-01 张量转换接入主链：16帧8.732秒、数值零差

原完整16帧入口新增CPU原生float32/UINT8转换（同除法/RNE/裁剪，不开fast-math），以及DW96客户端去除tobytes/create_string_buffer中间复制、复用用户输出数组；驱动coherent DMA、CRC、守卫、最终AXI完成判据及超时处置不改。板端16帧实际中间张量、四实际量化域半整数/饱和/全部256输出码精确；量化median38.532645→14.315190ms。完整Hard/Soft/PL/真实C128 V4R再运行通过：total8732.382386ms（前版9138.761221ms），128维特征逐字节精确、logits0差、分类不变。beforeDW96 median94.873681→70.490311ms，ioctl median37.3707→37.71303ms无改善；不能将CPU边界收益称NPU核心提速。仍慢于旧最佳7905.177ms，最快默认链不替换。

证据experiments/sol_tensor_codec_20261001/{verification.json,board/verification.json,board/clip_result.json,board/features.npy,board/evidence.tgz}；完整归档22973B/SHA4300fc7fac0df2e0206f4b98363be9cb30f9c631e5d6a6d315124234dba31a8c。合格ARM libtensor_codec_native.so8112B/SHA72867692fad4f7555473201462eff2b5164b755379ffae89d3d21663234ef25b，差异包79705B/SHA56f4fd70fa1981065b3748cdafc6e9ab8692acd8125025123121ff05d0a01cf0。旧差异包/bit/模型保留；新增包包含这次实际代码。Hard安全卸载、net_pl实际rmmod成功，Soft固定DMA；用户已再次确认物理重启，下一板测前只读核对，未再START。

等待期间新增pointwise_expand_row.v：一个量化银行与下一个点积重叠，仍用原RNE核。signed16真实第0/56/111三行10752B均精确、有背压；overlap_sim.log累计56058cycles，旧104537cycles。稳态行约18044cycles含输入装载/停顿，112行80MHz约25.26ms仅SIM估算，无新综合/布局/bit/BOARD，仍不单凭核心迁移宣称快于CPU23.491ms。PW96输出平均0.191909码/max41的整链质量仍PENDING，不采用未经质量验证的替代层。

下一直接动作：先将signed16 PW96真实CPU计算接原16帧入口检查整链质量，再做PW96与DW96固定16通道组行缓冲融合，省去1.2MB中间量化张量和DDR边界；复用已有MAC/RNE/AXI完成规则，不为单层再建资格框架。整图仍CPU31普通Conv/14DW等混合，时序沿用真实C128，CSI/DSI延后。goal active；未Flash/原工程构建/提交，原工程与外部快照整体哈希未重验UNKNOWN。

## 2026-10-01 冷恢复后144连续块完整16帧BOARD通过

用户确认物理恢复，正常Linux模块空；按原临时DTB/80MHz合格bit及GPIO释放流程加载。原16帧入口实际完成，features[1,16,128]与同候选CPU逐字节一致、logits0差，total9138.761ms/init1035.375ms；同候选CPU15102.841ms，但旧最佳7905.177ms仍更快，因此不替换最快默认链。16次BLOCK3、16次DW96、16次DW16、162次Hard（含2次TCN）、16次Soft及真实C128 V4R1次均实际运行；仍有CPU31普通Conv/14DW/8残差，不称全空间硬件。分类咳嗽0.985838，拒识未校准，保存帧不等于实时视频。

完整输出和日志已取回experiments/sol_block3_recovery_20261001，verification.json为数值比较，evidence.tgz22875B/SHA965ba79c19f2d3d7c5effb62ba410ad60e94af51affb82e79e15798dd3206108。Hard自动安全卸载、共享PL实际rmmod成功，Soft固定DMA；用户已再次确认冷恢复，尚待下一只读实查。未改驱动空闲条件、未Flash/原工程构建，整体基线哈希状态仍UNKNOWN，goal active。

下一PW96候选signed16输入基于前级Clip[0,6]和投影权重推导范围，不用验收样本调范围；真实首图平均误差0.191909码/max41（旧2.21578/max139），三行RTL逐字节通过。仅CPU/SIM候选，尚未采用/未整链质量验证。当前行核SIM折算约47.9ms仍不能证明快于23.491ms CPU节点，先处理真实主链量化/搬运开销，再推进融合，避免把硬件迁移本身当提速。

## 2026-10-01 下一前段逐点核心已SIM，量化误差阻止直接采用

Hard冷恢复尚未确认；只读实查uptime2377.60s/Hard引用1，未新START。等待期间CPU真实张量profile：beforeDW96 median62.33ms，最大PW16→96/112×112均23.491ms；block3后median234.35ms。复用pointwise_row_core增加静态ROW_WIDTH/EXPAND_INPUTS/OUTPUTS/ZERO/ONLY参数，默认144块六次真实行回归通过，新PW96三行0/56/111每行10752B对固定金样精确、背压正常。仅CODED/SIM，无新SYNTH/P&R/BIT/BOARD/整链提速。

真实原量化域PW96相对浮点输出max139码/mean2.21578码，因此仅保留为候选，没有接生产模型；下一直接静态工作为改善这层输入量化表示并核验质量，然后融合DW96减少边界搬运。原16帧恢复路径及合格流水化bit不变。Icarus缺DLL入口点0xc0000139由本进程PATH缺自身ucrt64/bin造成，正常依赖路径下compile/SIM通过，不更改系统安全策略；自有停滞编译已结束，当前无Icarus作业。证据experiments/sol_front_pw96_20261001/{pw96_sim.log,default_sim.log,fixture/rows/result.json}及experiments/sol_block3_board_20261001/current_profile。

## 2026-10-01 等待冷恢复期间：固定块CPU主链提速且保持数值

新增front_block3_native.c/.py，串行固定shape、无设备访问，保留原RNE及残差公式；真实参数界限检查保证signed32累加/signed64缩放可容纳。板端gcc -O3编译，真实夹具/0/255/随机四输入与原整数参考零差；单块约108～119ms（旧约1.07s）。原16帧CPU入口实际15102.841ms/init480.622ms，对旧30145.580ms候选特征逐字节精确、logits0差；这只是CPU软件改进，不算NPU核心或专利提速。硬件16帧仍待Hard首次idle失败后的物理恢复，未再START或放宽idle。

证据experiments/sol_block3_board_20261001/native_cpu_evidence/sol_native_cpu_clip_verify.json及sol_native_cpu_verify.json。已回收合格ARM so12576B/SHA934fcc0256b94c59127513a967749010676ebf75015732cafcb6a21b7e2d1da4并纳入下一76,439B差异包；模型/bit不变，CPU原参考保留，PL executor存在时不切换为CPU。下一动作确认冷恢复→原16帧PL→与15.103秒同候选CPU及旧7.905秒最佳链分别比较。goal active，无新硬件作业。

## 2026-10-01 同候选CPU16帧及真实前段PL通过，Hard首次idle拒绝

无需U盘：利用板端已有模型相同张量字节，将新CPU切段和当前runtime压缩至70082B传入，板端恢复10433/3992975B两ONNX后SHA与电脑原文件完全一致。CPU固定候选16×128通过，total30145.580ms/init941.139ms，咳嗽0.985838；其中CPU整数块较慢，不能将此参考单独视为最优CPU基线。

新混合整链第0帧DW96和BLOCK3完成；Hard首次H4被原idle0条件拒绝：pre_work2/pre_irq0/last_work3、writes0/reason14。未放宽门槛/未重试，Hard引用1及DMA固定，已请求物理恢复。独立CPU仅计算核对保留的第0帧DW96与BLOCK3，两输出逐元素零差，因此新的直接阻塞为Hard启动状态，非前段PL数值。整16帧硬件未通过，无新总耗时。证据clip_attempt_evidence.tgz、prefix_verify.log、clip_attempt_verification.json，均在experiments/sol_block3_board_20261001。新增failure.json记录frame_index/BLOCK3完成数和实际设备统计，启动脚本复用native FNV库；冷恢复后的70KB新包已备，不需要移动U盘。goal保持active，等待期间已完成上述实际CPU核验和修改。

## 2026-10-01 Sol接回：复位流程修正，144连续块首次BOARD通过

完整144块一次固定真实夹具输出75264B逐字节正确，4112251周期/device51.476760ms/host55.765170ms，原16帧新链尚未运行，不能声称超过旧7.905秒最佳链。复用Astra合格流水化bit和同一驱动，只补上成功历史流程中的PS GPIO bit0释放（0→1），四ID/ABI及DMA分配正常，无重启。此前未注册设备模式不必新增，历史精确复位指令仍UNKNOWN。C128 V4R不改，视频延后。

已取回输出和日志，匹配golden SHA。新16帧包3.93MB及启动脚本已就绪，等待U盘移到电脑后复制；板卡当前匹配临时Linux、NET_PL正常加载，无Soft、不需要额外重启。goal实查active。证据experiments/sol_block3_board_20261001/verification.json；工作日志docs/records/worklog/2026-10/2026-10-01-sol-block3-board.md。下列Astra交接中的probe阻塞由此次结果覆盖。

> 2026-10-01 最新用户指令：取消此前“账户剩余额度46%时停止”的限制，持续实现即可。本条覆盖旧目标/交接中的额度停止条件；原工程、known-good和实际硬件失败处置规则继续有效。

## 2026-10-01 最新交接：Astra停止，6.1 Sol接回

用户要求移交回6.1 Sol；Astra已停止实现和板卡操作。完整入口为根目录ASTRA_TO_SOL61_HANDOFF_20261001.md。最新trace2已捕获insmod后自动复位，FSBL AXI-MONITOR sx2x_m0=0x1，无probe日志、无BLOCK3 START；准确故障指令UNKNOWN。用户在该次故障后已再次确认物理重启，尚未重新实查。拟议“不注册设备的模块加载模式”未实现，net_pl.c仍module_platform_driver。当前所有构建/仿真已结束，COM4关闭，JTAG服务已关闭；本聊天get_goal返回null。新bit最终时序及SIM通过仍有效，但新块BOARD/16帧未通过，旧最快链保持。以下“待用户确认”等旧描述由此段覆盖。

## 2026-10-01 流水化版时序/BIT通过；新板测在probe阶段异常返回普通登录

整图新增BOARD仍未通过，尚未发送BLOCK3 START；C128 V4R未修改、视频仍延后。流水化完整144块及连续两作业SIM全部逐字节通过。恢复布线会话13247正常完成，raw SWNS+0.100ns/HWNS-0.799ns；唯一负hold从PS reset到一级cdc_synchronization_external[0]，报告18597起及RTL157～166确认实际.ie端点。仅纠正该异步入口例外，final SWNS+0.100ns/HWNS+0.028ns，STNS/HTNS=0。bitgen真实完成，新bit SHA256 e5a3b586636270eb245608afd725db2dcfe62e9335aa6ed070fbf1dea03e7cfa，位于experiments/astra_block3_soc_pipe_20261001，旧bit保持撤回。

板卡实际已在普通Linux登录界面（非此前记录的U-Boot），用用户授权账号登录后uptime约11min/lsmod空，阶段打印driver hash仍bcdf876277bd487b2e678dc01a83e199c9443b0574f32d7b4cdbe04c0bba8c0a。正常reboot停止U-Boot，临时DTB CRC4f533a68/reset1e1/div07070904实查；JTAG芯片校验成功、下载100%并完成。关闭JTAG服务后释放reset1f1，加载原内核与临时DTB，最小只读Linux启动成功并挂载proc/sys/run/tmp。

仅执行一次insmod阶段打印driver allow_run=1，15秒连续抓取只见命令回显，无PIPE_PROBE_RC或阶段打印。随后只读echo/uptime却出现Password，取消后明确返回Ubuntu20.04 bionic-arm64 login。说明已脱离临时init=/bin/bash环境；重启时间、触发原因及probe停点UNKNOWN，不能简单宣称地址截断是重启根因。未再次装载、未提交运算、未卸载/释放未知缓冲。已请求用户物理断电重启，尚待确认。下一次必须保持串口连续捕获覆盖probe及可能重启全过程，并在之前显式核查/提高console printk级别，先定位实际停点，不继续盲试计算。

证据集中在该独立目录board_pipe_reboot/dtb/clock/boot/prepare/probe/after_probe/login_check.log及block3_pipe_download.log。原7.905秒默认链保留，新块SIM48.47305ms不代表板端提速；新16帧硬件链未执行。额度停止条件已由用户取消，后续持续推进；原工程和外部快照全量哈希未重验仍UNKNOWN。

## 2026-10-01 addr12布线结束：残差长路径实失败，流水化修复中

修正地址宽度后的完整块P&R会话49080已正常结束，block3_raw.ts为SWNS -7.558ns、STNS -7238.429ns、HWNS -0.715ns，不能生成可部署候选或上板。最差真实路径为pointwise core qreceived→skip寻址/读存储→残差双缩放/求和/舍入→输出行缓冲（24级）；不是可用时序例外掩盖的数据路径。

已修改implementation_pl/front_block3/pointwise_row_core.v，将残差寻址、读数、两乘积、求和、舍入与裁剪分级，附带通道标签并统一背压；保留原完整定点公式及模型规模。旧源码已保存。residual_pipeline_sim.log实际BLOCK3_CHAIN_PASS，扩张451584B/DW451584B/输出75264B全部逐字节正确，35548读/17678写与响应/3877844周期（80MHz折算48.47305ms，仅SIM，未提速）。首次编译因信号声明顺序报错已修复。新独立experiments/astra_block3_soc_pipe_20261001综合会话44014已成功结束，布局布线会话84153在用户中断后丢失，提升权限只读检查确认没有TD进程；无最终route.db/时序报告。旧日志最后中间SWNS+0.100ns仍非通过。保留日志和block3_place.db，从该布局检查点以block3_route_resume.tcl恢复布线，新会话13247运行中，不重做综合/布局；控制接口连续两作业仿真31513已通过：residual_pipeline_repeat.log实际BLOCK3_REPEAT_CONTROL_HP0_PASS，两次三段输出均逐字节一致，71096读/35356写与响应/7755707周期，等待末次写响应后完成。旧addr12失败报告保留，不复用旧bit。

整图：本阶段修复新连续块的实际时序失败，尚无新增BOARD；时序模型C128 V4R未修改；视频仍延后。板卡最后实查为U-Boot，无新驱动/作业，用户已完成物理恢复。下一步取得流水化数值与综合结果，再布局布线；仅最终时序通过后继续诊断probe及固定夹具。原7.905秒最快链仍是基线，未声明新性能收益。账户最新剩余51%。未重新全量核验原工程/外部快照哈希，其全局未变状态UNKNOWN。

## 2026-10-01 实际上板接续：probe未返回；地址截断已复现修正，重新构建中

addr12修正版综合实际完成，P&R新会话49080运行中。对比gate area：旧block3仅6 LUT/0 DSP，已被优化删除；新block3为4711 LUT、17 ERAM、50 DSP，证明旧“bit已生成”不能作为完整144块存在证据。新总资源Slice44413/52480(84.63%)、ERAM276/280(98.57%)、DSP135/240(56.25%)，时序/bit仍待完成。此次明确撤回旧候选可部署判断，不更改旧证据文件。当前U-Boot已确认，未继续加载诊断模块，goal实查active。

用户提供root登录授权后已实际登录：正常Linux6.1.111-rt42、lsmod空。新driver板端/root/astra_block3_20261001_1编译，ko SHA929cb20b2f6cc55fcb6bb3038ad3c463cd4724babb25bd1a1d88baf687cd4621；继承缺Module.symvers/clock skew告警，非运行通过。旧候选bit 0ff30d...ba1fc7实际易失下载完成，临时DTB CRC4f533a68、reset1e1/div07070904与旧流程匹配，启动只读最小Linux成功。夹具传输第一次0B，补/tmp tmpfs后122750B/SHAf50d13fef255b0268d934b0a236b5e322985946871956e60ccc74dd0fd201e42成功。

加载新net_pl后未返回，后续只读shell命令无执行结果；未发送任何BLOCK3 START，未卸载/重试未知设备。用户确认物理冷恢复后，正常Linuxuptime约1分钟且模块空再次核验。新增最少probe阶段打印，独立/root/astra_block3_trace_20261001_1编译ko SHAbcdf876277bd487b2e678dc01a83e199c9443b0574f32d7b4cdbe04c0bba8c0a；尚未加载。第二轮旧bit尝试连接失败/芯片校验失败，不能按进程exit0当下载成功；随后停止使用旧候选。

实际发现SoC system.v仍为7位控制地址与25位补零，新寄存器0x80..0xac不可达。address_sim.log证明旧7位读0x90000080返回DW16 ID44573136，新12位返回正确BLOCK3 ID424c4b33。矩阵ds0既有范围4KiB（addr width0x0c），因此在新experiments/astra_block3_soc_addr12_20261001仅修正顶层AR/AW为12位及20位补零，旧bit/源码保留但BLOCK3用途撤回。先前模块级SIM/P&R不证明顶层新寄存器可达；首次失去响应确切停点仍UNKNOWN，不能将地址缺陷直接写成挂死唯一原因。

修正版综合会话5778运行中，未新P&R/BIT。当前板卡经version实际确认停在U-Boot；本次JTAG服务关闭，无驱动/计算作业，无需再冷恢复才构建。下一动作修正版完整构建后使用阶段打印driver核验probe，成功后固定夹具及16帧对照。整图/时序/视频系统目标均未完成，旧7.905秒通过链保持。

## 2026-10-01 144通道连续块整合已SIM/SYNTH/P&R/BIT，未BOARD

当前直接阻塞：板端root登录尚未确认。电脑端仿真、完整构建和部署准备已结束，无仍在运行的构建。新block3_source_stage2.tar.gz为3919530B/SHA256 819a82dcae799bf4701fd113b6816a5cb39b5cfa3a20e83a531906e95a10bf06，55个成员逐项回读校验，包含最终统计补丁和run_block3_fixture.py；stage1保持历史，不用于本次最新部署。目标驱动编译与BOARD未执行，NPU未启动。下一必要外部条件是用户完成root登录并释放COM4；不以额外静态报告替代板测。登录阻塞已持续多轮，设置goal BLOCKED以停止自动空转，收到恢复后继续原目标，不代表项目完成或达到额度阈值。

experiments/astra_block3_soc_20261001完整80MHz构建结束：block3_final.ts为SWNS+0.101ns/HWNS+0.020ns、STNS/HTNS均0。raw hold -0.923ns仅PS异步复位到cdc_synchronization_external_reg[0]_syn_2.id；新报告输出net和源码第157～166行确认是第一级同步器，精确例外由旧.ie改为真实.id，未放宽数据和后级。net_pl_soft_80mhz_block3.bit SHA256 0ff30d21486fb0a1d51ceab4b755d7a16d223f799aea6f868261901964ba1fc7；bitgen真实完成，未下载。

repeat_fixed_sim.log实际BLOCK3_REPEAT_CONTROL_HP0_PASS：两次完整任务均三段逐字节一致，总71096读/35356写及响应/7341775周期；完成状态检查通过。首次失败为测试台混淆内部状态1与总线状态2，原失败日志保留，RTL未因此修改。先等待新作业busy再等done，避免第二次误读旧完成。

当前整图推进：真实连续块已完成PC侧整合构建，原16帧调用代码已接，尚无新BOARD或端到端提速结论。C128 V4R逻辑未改、视频仍延后，旧最快7.905秒路径保留。板端仍等待用户完成root登录并释放串口；当前模块状态UNKNOWN，未加载新模块、未NPU START、未Flash。下一动作登录后检查uptime/模块/匹配环境，在新目录编译driver；准备冷恢复与易失下载后做固定夹具及原16帧对照。source_stage1不含最后统计补丁，传送前重打包。账户剩余53%，goal未完成。

## 同日接续：完整SoC综合通过，布局布线运行中

重复提交测试首次因测试台将内部c_status=1误当作寄存器编码2而失败；已修正判据并等待新作业busy，重复SIM会话37592进行中，尚未通过。SoC P&R仍为同一会话83576，不能重启。新增run_block3_fixture.py待板端执行；主入口已补actual_pl_block3_starts、逐帧设备耗时及CPU/PL层统计，语法通过但未板测。source_stage1包早于此次统计补丁，实际部署前须制作新包，不能称旧包包含最新源码。

从experiments/network_n3_v4r_soc_20260930已通过DW96板测来源，仅复制uisrc/al_ip和配置至新experiments/astra_block3_soc_20261001；增加block3连线与源码，未Generate、未修改旧bit或原工程。block3_synthesis.log实际BLOCK3_SYNTHESIS_COMPLETE，gate数据库已导出。gate统计Slice32267/52480、ERAM259/280、DSP85/240；非最终布局资源和时序验收。

block3_physical.tcl已启动，当前工具会话83576，block3_physical.log持续记录；尚未完成P&R/最终STA/BIT，不能重复启动同一构建。block3_reset_entry.sdc沿用旧首次同步级路径，应用前仍须核对新布线报告真实端点，不扩大例外。

block3_source_stage1.tar.gz已封存3918524B，SHA256 46a4cfb53a852a6c96d8c961405b05ebf4a01519952fa4aed1ce4c84e02c77b4；包含driver/runtime/匹配block3模型及参数，source_package_manifest.json有逐文件清单；未上传/目标编译。原16帧程序--help实际成功并展示新增参数。

串口COM4当前bionic-arm64 login，输入既有root账号后等待Password；已释放串口并请用户自行登录后释放。未猜测密码、未NPU提交、未装模块，板内驱动状态UNKNOWN。账户已用47%/剩余53%，仍可继续。下一动作跟踪同一P&R会话；用户登录后只读检查状态并目标编译新驱动。

## 同日接续：控制接口与HP0整合SIM通过，驱动和主入口已CODED

net_pl_control新增0x80..0xac（ID 0x424c4b33/ABI 0x40001），net_pl_datapath新增owner3连接连续块；原三作业接口保持。control_sim.log实际BLOCK3_CONTROL_HP0_PASS，三段逐字节一致，35548读/17678写及响应、3670892周期；本测试通过真实寄存器写启动和真实HP0复用，不含其它三个算子的切换回归，尚非BOARD。编译有原V4R RAM输入64→32截断告警，未修改原运算。

net_pl.c/net_pl_uapi.h新增NET_BLOCK3_RUN及/dev/block3，31488B参数包依次23040/4608/3840B；两块451584B独占coherent中间缓冲，保留守卫、CRC、最终完成、超时固定。驱动目标编译PENDING，不可将源码作为可装载产物。新driver要求新增ID，因此不配旧bit；旧冻结driver/bit继续作为回退。

block3_executor.py新增PL客户端，接DepthwisePrefix→HardSoftSpatial→原run_hard_soft_clip；显式--front-block-backend pl及--front-block-parameters，默认cpu保持，validate对定点参考逐元素比较，product无重复CPU金样。Python语法检查通过，尚无真实设备调用或整16帧新路径运行。参数目录必须为与--front-block-assets匹配的冻结记录，当前来源experiments/network_front_block3_20260930/row_fixture。

下一步准备匹配的SoC连接/构建来源（旧prepare_net_pl_soc.py尚未包含DW96，不可盲目使用），目标编译驱动，新增作业重复/切换检查后完成新bit与易失板测。板卡本阶段未访问，重启后状态仍UNKNOWN；不改变质量结论或最快默认链。

## 2026-10-01 Astra：144通道完整连续块已SIM及RTL综合，未BOARD

新增implementation_pl/front_block3/dw144_axi_master.v与block3_axi_chain.v，串接真实24→144扩张、144通道56×56 stride1深度卷积、144→24投影及残差；复用原定点运算，不改层/通道/帧数/预算。测试DDR仅预装原始输入和参数，中间结果由RTL实际写回供后段消费。

experiments/astra_block3_chain_20261001/chain_sim.log：BLOCK3_CHAIN_PASS，扩张451584B、DW451584B、最终75264B对冻结定点金样逐字节一致，35548读事务、17678写事务及响应、3670852周期；含DDR停顿、末次B完成与64B守卫。80MHz折算45.88565ms仅SIM估算，接近原CPU块47.048ms，尚无板端速度优势证据。旧7.905秒最快整链保持，原候选量化误差和9/12质量限制不变。

td/rtl_attempt3.log与block3_rtl.db证明elaborate/optimize_rtl完成，无锁存器；不是gate综合/P&R/BIT。首次项目Name与文件名不一致已修正，失败日志保留。Windows阻止vvp，用户关闭相关控制后同一程序实际执行成功。电脑重启使旧构建进程消失，新命令行构建已退出0。

整图：连续块内部数据链新增SIM通过，尚未接共享GP/HP0及驱动和16帧硬件入口。时序：C128 V4R未改。视频：仍延后。下一动作接现有控制接口owner=3及owned scratch客户端，完成SoC构建后授权易失板测；不能用SIM替代BOARD或质量验收。

本阶段未访问板卡、未Flash、未原工程构建、未Git操作；电脑重启后板卡状态UNKNOWN。旧源码/bit未主动覆盖，基线整体和外部快照未全量核验，UNKNOWN。Sol已交出执行权；账户窗口已用46%/剩余54%，尚未达到剩余46%的停止阈值。

## 2026-09-30 C24/C144连续空间块CPU主链与逐点DMA已SIM，未BOARD

prepare_front_block3.py提取真实backbone.3扩张24→144、DW144/56×56、投影144→24、残差Add，包含两个Clip和实际四个量化域。零权重/非零折叠bias导致I32溢出的实际报错已修正：weight scale同时满足真实bias范围，全部实际M/S仍S30。新增front_block3.py固定CPU计算，通过原run_hard_soft_clip --front-block-assets接入DW96前段；真实16帧128D完整输出，PC运行1676.185ms（不是板端耗时），相对DW96候选PCfeature max0.926588/mean0.101340，咳嗽0.985641。已有12真实测试子集分类12/12保持，两候选均9/12正确，不能代替全质量/拒识验收。

新增pointwise_row_core.v 16路MAC＋复用原RNE核心，以及pointwise_axi_master.v：只读24/144通道56像素行、固定160B参数记录、投影内接实际量化残差；最多16拍/4KiB拆分、最终B才done。首次行SIM投影通道16发生weight读索引8位回绕，已修正为足够位宽并保留失败log。真实0/17/55行六次扩张/投影模式切换及输出停顿逐字节通过；完整图DMA扩张451584B、投影＋残差75264B对独立CPU金样精确，读11215次、写/响应9519次，累计2668531 SIM cycles。未综合/布局/bit/BOARD，不宣称板端加速；实际生产最快旧链仍7.905秒，新DW96已BOARD候选8.978秒。

证据experiments/network_front_block3_20260930/verification.json、clip_quality.json、row_fixed_sim.log、dma_sim.log。下一可执行动作：现有DW DMA接144×56/stride1模式，串接两个逐点DMA与DW，固定owned scratch内存下完成三作业，再目标构建和原16帧BOARD。当前正常Linux115.13s/模块空已核验，未在本阶段触发NPU START；goal active。修改仅工作副本，未Flash/原工程构建/提交，整体基线/外部快照UNKNOWN。

## DW96匹配缓冲修正版已BOARD（同日接续）

修正当前实际开销：DW16/V4R/DW96分别固定三个匹配大小的owned coherent缓冲，仍单mutex串行、全尾部守卫/CRC/地址校验和失败固定，无bit/model/ABI改动。目标ko459808B，首次新driver保留driver_shared_large_before.c，补丁3343B SHA70c5997666cda00001b84b8647d41aa2c5e37cde9dad84e9bf7991f268b2b356。16帧BOARD总8978.214ms/init1188.047ms；同候选CPU15826.074ms减少43.27%，feature byte-exact/logits0差/16DW96/16DW16/162Hard/16Soft/1C128V4R。DW16主机累计503.162→97.433ms，V4R ioctl47.203→21.042ms，前段CPU仍6055.911ms，DW96主机633.666ms。本路径仍慢于旧前段7.905秒，不将候选默认化为最快产品。

证据buffer_board_verification.json、buffer_board_evidence.tgz（28273B/SHAfff1881d64cfb0830d1872a1f8c45163611ca63b210f7d72f84a8a2fd3e98ec1）。Hard/TCN/NET正常卸载、Soft固定，已请求物理恢复。下一动作以当前CPU切段真实输入做热点测量，再扩大对应连续硬件块；旧资格不重做。原合格dwparallel bit SHAfbf8e3...297cc25实查未变，整体原工程/外部快照UNKNOWN，无Flash/原工程构建/提交。持续goal active。


用户再次冷恢复已实查正常Linux115.13s/模块空。用当前切段的真实DW输出做CPU后段ORT实际profile，双线程median296.295ms；最大单节点为backbone.3/conv/conv.1/conv.1.0/Conv：C144×56×56/3×3/stride1，均22.881ms。相邻同块扩张24→144（11.817ms）、投影144→24＋残差（12.350ms）均已定位；下一实现选该固定连续空间块以减少CPU↔PL边界，优先复用当前DMA/并行核心及固定入口。profile证据profile_evidence/after/summary.json，归档SHA3e406fa4c5999e7d1769567207cc06616531d9aa69d13fce976af83b18a58d4b；只是CPU实测，不是该块硬件完成。当前无实验模块，尚未提交下一块START，goal active。

## 2026-09-30 前部DW96已BOARD，完整16帧9.426秒

固定C96 112×112→56×56的3行缓冲/DMA已接入现有入口。真实301056B输出逐字节金样精确，设备11.342ms；共享接口DW96→DW16→V0→V32→DW16 SIM通过。隔离80MHz SYNTH/P&R/BIT/BOARD完成，setup+0.108/hold+0.020ns；raw hold-0.729仅PS异步复位到实际首同步级cdc_synchronization_external_reg[0]_syn_2.ie，端点/输出net已核对，新bit SHA c96365dc29bdabb88c895c59c6e0be45268474093f8be52852402222c5aa87dd。

同板同候选CPU16帧15826.074ms/init925.677ms，新硬件16帧9425.657ms/init1162.061ms，减少40.44%；16×128特征byte-exact，logits0差，咳嗽0.985071/证书通过/无fallback。实际162 Hard（空间H4/H5＋2 TCN）、16 DW96＋16 DW16、16 Soft、1真实C128 PL V4R；CPU仍33普通Conv/15 DW/9 Add及尾部与时序辅助。拒识NOT_CALIBRATED、视频/DSI未接通，非全空间硬件或实时产品。前段量化候选不是旧7.905秒路径，当前9.426秒更慢，不能替换为更快默认路径的结论。

已定位小DW调用104→503ms/16次：扩大共享缓冲造成重复清理与守卫扫描。下一实测：三个固定算子分别使用匹配大小的owned DMA缓冲，保留单锁串行、全尾部守卫/CRC和失败固定。修正版driver已CODED/目标编译进行中，不改bit/模型/ABI。BOARD日志输出归档28617B SHA4db0af2c792b46d06834228d0540b941db1577fdea1d0e8832b790ef57b3aa7c，experiments/network_dw96_20260930/board_verification.json；CPU证据8658B SHA285960b031a265137b8cf765c98f38704adf4dd55c1439a0853617ad59a10f4f。Hard/TCN/NET卸载成功、Soft固定后用户冷恢复，正常Linux154.33s/模块空。目标active，继续必要板测，无Flash/原工程构建/提交，整体基线/外部快照UNKNOWN。

## 2026-09-30 并行深度卷积已BOARD，完整16帧7.905秒

九乘加并行流水保留原RNE/符号位/输出停顿语义，47040真实值与连续流水/停顿SIM通过，原DMA最终B与守卫回归通过。隔离SoC SYNTH/P&R/BIT/BOARD完成，80MHz setup+0.101/hold+0.023ns；仅PS异步复位至实际首同步级例外，报告确认同一cdc_synchronization_external[0]。bit SHAfbf8e3ea8c5dd626fc9413b8a5b4ee3e091bb40d3f51f3d12b67b873f297cc25。真实DW47040B逐字节金样通过，device3.649ms；主链16次3.713～3.744ms（原约7.8ms）。原16帧空间＋Hard TCN＋PL V4R再次完成，feature byte-exact/logits0差；运行7905.177ms/init1121.193ms另计，对同板CPU候选下降25.46%。这是末块DW优化，前部DW96尚未硬件化，仍非全空间/实时系统。

新增depthwise_prefix.py及prepare_front_depthwise.py，真实C96 112×112/stride2/pad1→56×56参数与CPU计算接回原--front-dw-assets入口，16×128D已实际CPU运行，较N4feature max0.710601/mean0.048455；当前不是生产默认路径。既有12真实测试子集与N4分类12/12一致，baseline/candidate均9/12正确，三个错误与历史float分类相同，不能认作全产品质量验收或拒识完成。直接下一实现：DW96大图行缓冲/受控DMA/对应新作业入口，接现有前段桥接。

全部输出日志42359B已取回SHA2d033338cf9d5f844cc37af113ca6b7a58c9082ebdc24af265498f9e28c526c0，experiments/network_n6_dw_parallel_20260930/board_verification.json及front_clip_quality.json。Hard/TCN/NET卸载0，Soft固定后用户再次物理恢复，最新实查正常Linux68.34s/模块空；持续goal active，当前准备DW96行缓冲和DMA。无Flash/原工程构建/提交，旧合格bit保留，原工程整体/外部快照UNKNOWN。视频/屏显仍延后。

## 2026-09-30 V4R预取版已BOARD，完整16帧7.950秒

用户再次物理恢复后实查正常Linux88.45s、无模块，沿匹配临时DTB/80MHz下载prefetch bit，复用驱动和全部模型。真实2048组输出在零/预算32逐字节精确，fixture分类也通过；设备29.599500→18.118201ms、28.755451→17.578440ms，分别减少38.79%/38.87%，运算数和证书不变。原H4/DW/H5/Soft＋Hard两层TCN＋C128 PL V4R整16帧入口再次通过，特征byte-exact/logits0差，无CPU fallback；运行7949.696ms/init1119.546ms另计，时序58.586ms。相比同板CPU候选10604.890ms减少25.04%，单次端到端改善不能全部归因于V4R（包含初始化切换和运行波动），仍非实时/全空间硬件/质量验收。

证据experiments/network_n3_v4r_prefetch_20260930/board_verification.json，完整输出日志54639B/SHAf3eb005c2b2044f8ece382657523fcdcb2c5b4fbe0fb3d0550fd11ec13106836。Hard/TCN/NET成功卸载，Soft固定，下一轮物理恢复已请求。期间新增无设备CPU前段profiling实际运行：双线程369.890ms、单线程547.967ms，输出0差；最大单算子为96通道112→56深度卷积，现有线程设置保留。证据experiments/network_n5_prefix_profile_20260930/board_summary.json。下一动作扩大实际DW层接入，不重做原资格；持续goal active，视频仍延后；原工程整体/外部快照UNKNOWN，无Flash/原工程构建/提交。

## 2026-09-30 N4完整16帧组合已BOARD通过并实现候选整链提速

用户确认物理重启后实查Linux uptime43.34s、模块空，持续目标恢复active。复用旧合格80MHz/16拍bit和匹配DTB，修正版H4/H5驱动目标编译602104B；原16帧入口实际完成96次H4＋64次H5＋16次PL DW＋16次Soft，自动卸载空间模块后接2次Hard TCN和1次真实C128 PL V4R。16×128特征对同板CPU候选逐字节精确，logits0差，咳嗽/0.985962，证书通过且无CPU fallback。运行8000.377ms、初始化1152.870ms另计；同板CPU候选10604.890ms、初始化933.266ms，运行时间减少24.56%（1.326倍），不是全空间硬件或实时速度/数据集质量验收。

普通卷积33层、深度卷积16层、残差Add9层及尾部仍CPU；末块H4/DW/H5/H6实际设备执行。Hard/TCN/NET正常卸载，Soft按现有设计固定DMA缓冲，已取回全部输出日志并请求下一次物理恢复；等待期间只准备下一轮，不重复资格验证。下一动作冷恢复后用已构建V4R预取bit实测设备与原16帧整链耗时。证据experiments/network_n4_expansion16_bridge_20260930/cold2_verification.json及cold2_evidence.tgz，归档SHA6248636c81fb25ab5c42a1fc00084fa905e5e2b5df682c861d7aa9d92b47fdf5。视频/屏显仍延后；无Flash/原工程构建/提交，基线整体与外部快照UNKNOWN。


## 2026-09-30 N3 V4R读取流水已SIM/SYNTH/P&R/BIT（未BOARD）

等待N4首次空闲失败后的用户物理恢复期间，针对已测V4R设备约29ms的实际计算开销，核心在16通道dot内消费当前RAM返回的同时预取下一通道，仍保留状态入口等待及不可变区间原子替换。真实零/预算32的2048组center/lower/upper对原金样精确；DW→V0→V32→DW共享DMA、4KiB拆分/16拍上限/输出守卫/最终B全部通过。核心仿真cycles2286271→1364672（减少40.31%）、2211520→1324959（减少40.09%），运算数/模型/ABI不变。这是SIM加速，不是已测设备或整链提速。

完整SoC新流水SYNTH/P&R/BIT完成，80MHz最终setup+0.104/hold+0.023ns，gate slice27923/ERAM259/DSP65；新bit SHA32271009746f2ef1c9bdcef4ac2787c9b2c3c795da32270b3abab2ec30144d07。raw hold-0.860仅为PS异步复位到实际第一级cdc_synchronization_external_reg[0]_syn_2.id；报告证明输出net为cdc_synchronization_external[0]，仅此入口例外、后级和数据检查保留。首次final TCL因工作目录相对路径未生成SDC而失败，已修正、日志保留；最终marker及ts均通过。旧合格16拍bit SHA1571ac...1b152实查未变，旧核源码保存在prefetch实验结果目录。

证据experiments/network_n3_v4r_prefetch_20260930/verification.json和core/net_prefetch_sim.log，构建prefetch_*独立结果。无新板端START；当前直接阻塞仍是已请求的物理冷恢复，用户回复待确认。下一板测先复用旧合格bit运行N4组合（修正版16kB源码已准备），再独立测新V4R实际耗时及整链效果。真实质量/全空间硬件/视频屏显仍PENDING，不制造替代目标；持续goal实查active。原工程整体/外部快照UNKNOWN、无Flash/原工程构建/暂存提交。


## 2026-09-30 N4实际CPU16帧通过，首次组合板测阻塞于启动空闲

新float前段→CPU固定H4→DW/H5/H6→真实C128 CPU时序的16帧候选在板端已通过，10604.890ms、初始化933.266ms另计，128D×16相对N2max0.323735/mean0.037508，仍咳嗽/0.985962；单片段不是质量验收。U盘4.10MB传入完成。首次runner的CRLF解析错误已修LF；首次模型LOAD EBADMSG由block_frozen_config缺H10_MULTISHARD_CONFIG_H导致旧H10宏覆盖（目标编译redefined告警与实际加载失败一致），已补guard后新编译602024B模块，十个slot全装载成功。

实际首RUN在START前空闲检查reason14拒绝：pre_work2、pre_irq0、last_work3、100000polls没有16个连续0；未经过作业寄存器写入路径，不能称H4/DW/H5混合数值或性能通过。已触及TOP时钟/软复位，模块DMA固定，无自动重试/放宽判据；日志输入完整取回first_attempt.tgz SHAa0e9fa98a5769170ed4dd50d37bfb2cfa07d21e069fd0382671cc6a36f02335c，CPU归档SHA89e36efa3fe8aab8e50177947122a311de1edf85b191d499aaa436afd6c1cbf4。已请求物理恢复，回复待确认。

旧合格H4/H5/H10激活顺序与当前组合相同（TOP enable→SRAM clock→soft reset→稳定idle0），没有根据本次work3将未知状态重新定义为idle。下一动作冷恢复后只传guard修正版小源码包并复用已通过bit/模型；重跑新组合入口，保留旧成功整链。未改模型/保护规则、未作Flash/原工程构建，无暂存提交；基线整体/外部快照UNKNOWN。


## 2026-09-30 N3同一16帧入口自动Hard时序切换已BOARD

原run_hard_soft_clip入口已实际完成空间64次Hard＋16PL DW＋16Soft，成功释放H5后自动装既有TCN执行2层Hard，再1次真实C128 PL V4R。16×128特征逐字节一致、logits0差，label_certified=true/exact_cpu_fallback=false；运行11127.278ms、初始化1003.636ms另计，其中时序切换初始化313.880ms、实际时序75.779ms。整体仍未快于CPU，不称全空间硬件或实时识别完成。Hard/TCN/NET均成功卸载，Soft固定；日志输出完整取回SHA06e905647463d8f65496f0057f165b4a3e670259e47bbff3ae6a3efc76c19d35，用户再次物理恢复后实查正常Linux181s/模块空。证据experiments/network_n3_v4r_soc_20260930/integrated_verification.json。

N4下一可运行功能已接入：原入口--hard-block-assets配合--expansion-assets，常驻6个H4＋4个H5原资格资产，单帧H4→既有PL DW→H5→Soft。固定ABI48450100、各slot实际packet/input/weight/output长度及相应guards；共享已通过固定模型驱动的IRQ/完成/释放，失败继续固定缓冲。目标内核编译完成；普通Linux缺匹配节点环境默认加载/卸载0，尚未匹配probe或START，不能写N4 BOARD完成。新增CPU前段与候选量化质量边界仍保留。约4.10MB新包已复制G盘新目录并校验，等待用户移回U盘；下一动作同16帧CPU候选→匹配原80MHz bit/DTB的实际混合运行，不重做Soft Pool或原六片资格。

本阶段无Flash/原工程构建、未覆盖基线；原工程整体与外部快照UNKNOWN。持续目标active，无暂存提交。


## 2026-09-30 下一入口已修改，等待物理恢复（CODED/CPU）

已通过的保存特征Hard前缀＋PL V4R将由原16帧入口在空间H5成功释放后自动串行切换到TCN，代码/runner已完成，尚未BOARD，等待Soft固定后的冷恢复。同时复用早已有板证的H4扩展卷积真实参数，新的float前段→CPU固定H4→DW/H5/H6→128D单图实际运行完成，较N2特征max0.246065/mean0.032699；候选还未质量验收，不把本机耗时或CPU算法写成新硬件加速。下一板测复用现有bit/模型，只传改动脚本；随后的四算子块将复用H4资格及固定模型驱动，而非重跑单层。

## 2026-09-30 N3真实C128 V4R BOARD与原16帧主链通过

16拍修复bit SHA1571ac023ecbcf70bc3c6800a39799f0ab8ffc993717178d61d94e562711b152，匹配DTB CRC4f533a68/80MHz。P&R最终+0.106/+0.020ns；本次打包后复位第一同步级的实际引脚命名为dw/burst_end_reg[1]_syn_9.ie，时序报告输出明确仍是proc_sys_reset.../cdc_synchronization_external[0]，仅该PS复位→第一同步级路径例外，数据与后续同步级保留检查。旧负保持报告及首次失败bit/日志保留。

真实2048组center/lower/upper在预算0/32均与CPU settlement逐值精确，预算区间包含零预算精确值，最大certificate11716≤11726；设备29.5995/28.755451ms，残差MAC786432→749056，减少4.75%，完整设备周期2367020→2292312，减少3.16%。总乘法仍另含196608 base和393216 interval；不是全TCN或整体提速。四次fixture/分类作业连续成功，原16帧DW→Hard→Soft→CPU TCN前两层→PL V4R末层成功，特征对N2逐字节相同，logits0差，总10783.778567ms，初始化1143.972611ms另计，时序64.362931ms。

立即复用这些16×128特征接原run_temporal_features.py的新v4r-pl-hardnpu-prefix：Hard前两层＋真实C128 PL末层，时序69.903031ms，logits对CPU精确，证书边界最大差5.35e-12（周边FP64舍入余量差），label_certified=true/fallback=false。该项是保存特征变体，不能写成同一次整图已自动切换Hard时序前缀。CPU residual/requantization/pool/classifier保留。相同板端budget32完整时序CPU48.383881ms、CPU前缀＋PL59.40606ms，暂时慢于CPU，尚未完成整体加速。

Hard H5/TCN/NET_PL卸载0，Soft按既有设计固定；所有输出和日志取回54902B/SHA7b2a157795d74b34063f3cd4a0865de103c9fcca77b379b241e24263ecc38942，已请求物理恢复。证据experiments/network_n3_v4r_soc_20260930/board_verification.json及board_success。拒识未校准，单片段不是质量验证集，视频/屏显本轮未测。目标active，下一项直接内部加速按施工顺序推进，无Flash/原工程构建，基线整体与外部快照UNKNOWN，无暂存提交。


## 2026-09-30 N3首次BOARD读取失败及HP0实际长度修复

新C128完整SoC P&R/最终STA+0.102/+0.021ns及BIT完成，SHAaabef84856cc564d5937811b26e51826291706fa1e99578c51504ef38033ba0f；临时下载、匹配DTB CRC4f533a68及GPIO释放后，驱动probe成功，coherent input/parameter/output物理17c70000/17c80000/17c90000（设备有效地址均+64）。首次V4R START在152设备周期返回status4，驱动elapsed138390ns，未进入核心/无完成输出，模块及DMA保留。不是V4R数值验收通过。

故障日志完整取回board_failure.tgz/SHAe4340f953e159941b73f69cf05b2dfcd5b37753bb5c0543e17860da6165b1599。实际system.v/PS macro的HP0 ARLEN仅4位，原新DMA64拍ARLEN63被截成15，后端16拍RLAST而前端仍等64拍，根因由接口源码推定（INFERRED；未增总线故障探针）。已最小修改v4r_c128_dma读burst最大16，保留4KiB拆分及末B判据。模拟HP0长度上限的DW→V0→V32→DW全部真实输出再次精确，net16_sim.log；修正版综合完成，net16_physical正在进行。旧失败bit/日志保留，不覆盖；模型/驱动/DTB复用。

用户回复已完成物理恢复，重新登录后实查normal Linux uptime2min、模块空。下一动作修正bit时序通过后相同fixture重试，再原分类/16帧入口。没有自动重试未知设备、Flash、原工程构建；目标继续active。


## 2026-09-30 N3共享DDR接口与实际分类入口接通（SIM/SYNTH，非BOARD）

真实C128末层经HP0 DMA、GP独立V4R ABI20001接入原BatchedV4RTemporalSequence及run_hard_soft_clip.py的显式v4r-pl后端，前两层当前CPU。固定单进程串行共享DW接口，无新调度框架。DW→V4R零预算→预算32→DW仿真全部输出精确、4KiB拆分/输出守卫/末次B完成通过；仿真输出接原分类后两个预算logits及上下界与CPU完全一致。新驱动使用现有内核树编译并在无匹配节点环境加载/卸载成功，无MMIO/START。

实际综合暴露大数组映射分布式RAM超量；同步读取及显式DR1 ERAM修复后完整SoC gate完成：slice27923/52480，ERAM259/280，DSP65/240。核心零预算2286271、预算2211520模拟周期；存储修改增加周期，不把早期异步周期当当前性能。CPU金样的summary计数包含四项乘法，当前RTL选择正/负权重后计算两项，计数不能混为同一实现。P&R正在进行，BIT/BOARD及真实耗时尚未取得，尚未称V4R硬件完成或加速成功。

修改implementation_v4r/rtl/{v4r_c128_ram,v4r_c128_core,v4r_c128_dma,net_pl_control,net_pl_datapath}.v、implementation_v4r/driver、runtime/v4r_c128_executor.py及原分类入口。新DTB仅将旧DW节点compatible改为codex,net-pl-c128，Soft/保留内存不变；CRC4f533a68。约98kB运行包已取代多MB重复传输，串口SHA验证并写入U盘新NET_PL_TEMP_20260930_1目录；未覆盖N2包。板端正常Linux/no模块；尚未下载新bit/START。下一动作：完成时序与临时bit，运行真实零/预算fixture再原分类及16帧混合主链。原工程/外部快照整体UNKNOWN，未写Flash/暂存提交。


## 2026-09-30 N3真实C128末层V4R开始实现（CODED/SIM，非BOARD）

输入复用N2刚取回的真实16×128板端特征，按已通过定点模型前两层CPU计算产生末层INT8输入；未宣称本轮已接Hard时序前缀。新增prepare_v4r_c128_handoff.py及v4r_c128_core.v：固定T16/C128/O128/K3/dilation4、block4/channel group16，真实49152个权重与128个bias；缓存每个tile/group的4×16残差供三个重叠tap复用，不可变上下界按残差事件同时替换、各窗口/输出独立达到预算后停止。

真实2048输出在零预算及预算32（acc11726）两种模式的center/lower/upper逐值与现有settle_conv精确，输出背压下通过；zero1144330/预算1106953模拟周期，残差MAC786432→749056，减少37376/4.75%，周期少3.27%。另含196608 base及393216 interval乘法，不能拿残差减量当总MAC提速或真实周期；尚未SYNTH/P&R/BIT/BOARD，DMA/整链分类接入PENDING。证据experiments/network_n3_v4r_c128_20260930/verification.json与rtl_sim.log。旧C4模块未替换成名字上的C128。

用户确认再次物理恢复后实查uptime848.56s、模块空，N2 Soft固定状态已清除。本阶段无新START。下一可执行动作：以已打通HP0 DMA连接新C128 core，在现有GP低128B地址空间保留DW接口并新增独立V4R ID/ABI；固定串行作业，再真实零/预算输出对照及原分类入口。目标active，完整空间提速/真实V4R BOARD/视频屏显未完成。N2相对原N1板端特征max差实查0.144617，单片段不是质量验证集结论。

## 2026-09-30 N2新增PL DW→Hard→Soft已BOARD贯通

新增原16帧入口--dw16-assets/--dw16-backend pl：16次PL DW、64次Hard H5、16次Soft H6；16×128特征与本次同板CPU候选逐字节精确、logits差0，咳嗽0.984907。混合10805.344ms、初始化1172.393ms另计；同板新候选CPU9816.436ms。DW路径554.473→165.075ms（纯设备124.459ms/16帧），但整链仍比CPU慢10.07%，未达整体提速。实际覆盖1/17 DW PL、1/35普通Conv Hard、1/10 Add Soft；DW之前扩展Conv及其余空间仍CPU，真实C128 TCN/V4R目前CPU。不是全空间硬件或完整N2四层块完成。新DW量化相对旧模型PC max特征差0.148361，未做验证集质量验收。

两次独立DW真实47040B输出均逐字节精确，约7.8ms设备/10.1ms调用；随后同实例16帧成功。首probe无响应已由启动漏释放HP0的PL GPIO复位定位并修复：GPIO bank2 data0xf8411200 bit0从0→1，随后同bit ID/ABI、驱动probe成功；不重建bit、不盲重试旧挂起状态。4KiB拆分bit 80MHz最终STA+0.102/+0.021ns。Hard和DW均正常卸载，Soft固定；用户再次确认冷恢复，实际串口接续待确认。证据experiments/network_n2_dw16_soc_4k_20260930/board_verification.json及两个板端完整归档。

串口4.34MB传输失败校验且无响应，改为用户搬U盘，G盘新目录四文件校验和板端tar解包成功；Windows换行导致set错误已实修LF并CPU重跑通过。原默认生产/N1 native FNV保留，当前板测报告确认NATIVE_C_FNV1A。下一直接实现真实C128末时序层V4R PL，不等全空间迁移；视频/DSI延后，持续目标active。无Flash/原工程构建；原工程整体/快照UNKNOWN，Git实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，无暂存提交。

## 2026-09-30 N2 GP/HP0集成与修正版BIT（待BOARD实际作业）

原入口新增--dw16-backend pl及固定DW16 DMA客户端。GP/HP0共同使用原p2f_clk0/80MHz，PS与Soft配置保留；网络候选移除视频FDMA。板端客户端编译并无匹配节点加载/卸载成功，未作START，modpost缺Module.symvers/clock skew边界仍记录。针对真实49字节通道布局修复7beat burst跨4KiB：当前fixture11通道拆分；带64字节守卫偏移的连续两次仿真各47040输出精确，3862读/1942写及B，最终B后完成。完整SoC SYNTH/P&R/最终STA/BIT通过，setup+0.102ns/hold+0.021ns；旧未拆分bit未下载。证据experiments/network_n2_dw16_soc_4k_20260930/build_verification.json、network_n2_dw16_perchannel_20260930/control_guard_sim.log。

当前软件候选16帧PC292.321ms，特征与此前逐通道DW候选精确；沿用候选相对旧模型max0.148361质量边界，不称板端耗时或质量验证通过。正在串口传入新前段模型（压缩4.34MB），下一动作匹配临时bit/DTB→DW连续两次真实输出/耗时→原16帧Hard＋Soft主入口。当前无新DMA/START；持续目标active，原工程整体/外部快照UNKNOWN。

## 2026-09-30 N2真实DW16候选接原入口（CPU/SIM，未BOARD）

用户确认再次冷恢复，串口uptime65.40s、无加载模块；此后未新增DMA/START。新增可选--dw16-assets，以实际block16/960×7×7权重和输入替换原CPU前段末尾DW，继续原H5/H6→128维→真实CPU C128 V4R入口。默认product保持原路径。旧单尺度量化使16×128相对原PC链max差0.932145，已改逐通道UINT8权重/INT32 bias/独立multiplier：同16保存帧PC整链290.277ms，max差0.148361、L2=1.184799，类别咳嗽/score0.984744；不是原模型数值精确或验证集质量通过。DW目前CPU参考32.085ms，NPU0，不能称新DW已上板。

dw3x3_patch_core及dw16_axi_master已CODED/SIM：真实47040输出对独立INT64参考逐字节精确，带读写等待的DDR模型完成1920读burst、960写burst/960响应，最后B响应接受后才done、邻接守卫不变；602887模拟周期并非板端耗时。TD elaborate/RTL优化通过，独立gate把AXI端口当外部IO，超过器件126引脚而失败，-ip重试仍同错；尚无gate/SoC P&R/bit/BOARD。下一直接动作把DW控制与master接既有空闲GP/HP0，保留PS/Soft时钟与总线，完成匹配DMA客户端，再板测单帧→原16帧。证据experiments/network_n2_dw16_perchannel_20260930/{verification.json,axi_sim.log,rtl_sim.log,td/synthesis.log}。无Flash/原工程构建，原工程整体/外部快照UNKNOWN，目标继续。

## 2026-09-30 N1本地C校验接入保存16帧（BOARD）

用户本轮已恢复持续目标，内部网络与真实C128 V4R优先，视频/DSI延后。h5_serial_executor调用同算法本地C FNV，保持H5 ABI48350001、Soft1000b及全部DMA/完成/释放检查；没有修改模型或NPU核心。匹配原Soft80MHz临时环境，同板同16帧CPU9327.561ms，product10666.786ms；对历史product12011.346ms降低11.19%，仍慢于本次CPU14.36%，不算NPU加速目标完成。初始化508.581ms另计；每帧输入校验均值0.459ms（历史约84ms）。64 Hard/16 Soft成功，16×128对本次CPU及旧product逐字节一致，旧logits差0。证据experiments/network_n1_fnv_20260930/{verification.json,board_results.tgz,board_fnv_check.json}。

Hard已卸载0，Soft仍固定缓冲，已请求物理恢复；等待期间继续内部代码。下一直接任务针对CPU前段6033.589ms及Hard路径3461.627ms，接邻接实际DW/连续块，随后C128 V4R PL。此前视频临时修改仅CODED：历史I2C无ACK不再永久拒绝稳定出帧，加入单帧选项；本轮转向后未继续视频验证。PLL/启动时序仅假设，config_done不保证全部ACK，capture关闭AW/B=0正常，16位RX计数不变不能证明无时钟。目标继续，无Flash/原目录构建/基线覆盖；原工程整体与外部快照UNKNOWN。

## 2026-09-30 用户恢复：内部网络优先，交由6.1 Sol持续执行

本次最新用户指令替代下文历史暂停和摄像头优先顺序。先优化保存帧内部空间链并接真实V4R，再接预处理/摄像头/屏幕；T01已通过不重做。用户允许继续隔离实现及必要易失板测，可配合重启；板卡实际状态待执行任务确认。详见SOL61_NETWORK_FIRST_HANDOFF_20260930.md。新N1～N6为待执行目标，此交接本身无新增硬件结果。

## 2026-09-30 CSI/DSI 工程对照与板端定位（当前最新；用户要求分析后暂停）

保存16帧的Hard＋Soft→128维→真实CPU TCN/V4R生产链BOARD仍通过，12011.346ms，尚未实现实时相机或实体屏显。用户冷恢复后只读板测定位实际0帧：PS PL GPIO未释放使UI/摄像头链保持复位；按既有固件释放后，I²C引擎锁存至少一次无ACK，MIPI接收时钟/HS有效/CSI/ISP帧均0、AXI写0。用户确认IMX415并断电重插后复测不变。探针ABI10003 bit已完成BIT/BOARD只读，capture入口加入复位释放和I²C预检但未板测采集。详情与证据见`docs/reports/VIDEO_CSI_DSI_DEMO_ANALYSIS_20260930.md`。

用户提供的可见实时画面的`11_csi_dsi_imx415_7cun`真正编译顶层是`uisrc/01_rtl/system.v`（4 lane CSI＋1024×600 DSI），同目录`system_top.v`为另一HDMI顶层；另一个可行`01_fdma_vdma_20251010`提供当前HDMI采集/ISP来源。下一轮应沿真正DSI顶层的物理I_sysclk/PLL/复位/输出接线整合受控FDMA和既有Hard＋Soft链，不把50MHz PLL直接改接100MHz管脚。用户已要求完成本工程分析后暂停目标；本阶段不再上板。当前临时诊断Linux采集使能0、NPU未START；未写Flash。原工程/外部快照整体UNKNOWN，Git detached HEAD`2685d5f4e21bb91b31a52dbde8527c59acd0964c`，未暂存提交。

## 2026-09-30 固定DSI结果帧由现有主入口生成（最新）

run_hard_soft_clip.py保留原识别链，仅新增显式--display-dsi-frame；与--display-font同用时把1024×600结果画面按DDR 32位字0x00RRGGBB（小端B,G,R,0）生成result.rgbx。该排布对应已工作CSI/DSI示例读回取word[23:0]。同16张保存帧实际CPU空间＋真实TCN/V4R运行退出0，128维特征和logits与既有CPU product精确相同，结果帧2457600字节逐像素回解与PNG精确/高字节全0，整链255.726ms、NPU0。证据experiments/display_dsi_software_20260930_1/verification.json。这是可供DSI扫描输出的实际帧数据，尚无PL帧读出、保留显示缓冲或实体屏显BOARD，不能称显示完成。下一直接板测仍需上次采集超时后的物理冷恢复并用已生成定位bit读取CSI/ISP/AW/B；回覆尚未收到，不碰板卡。DSI硬件移植随后沿用已验证示例，不以PNG代替屏显。

## 2026-09-30 零帧定位版本本地BIT完成（最新）

接续现有实际0帧超时，只添加CSI/ISP帧起始灰码计数、配置/时钟状态及AXI写地址/响应只读寄存器（FST1 ABI10002，原ABI10001读布局/0x40使能语义保留），并让现有capture_model_clip.py显式接受两版。独立工作副本experiments/video_capture_probe_20260929_1完成综合、P&R、最终STA及BIT；最终SWNS+0.140ns/STNS0、HWNS+0.020ns/HTNS0、覆盖95.38%。新bit 4052202B/SHA3ab1b9d24bad8c321ad2847b44716dafeed697e0a6737ebdf7d076a0faabcd05；复用保留DTB SHA167e4c...5d21。只有本地构建证据，未下载或BOARD，实际0帧原因仍UNKNOWN。tools/video/read_capture_probe.py仅读合法状态偏移，已核验灰码解码全部65536值；下次上板需先确认上次超时后的物理冷恢复，已请求现场回复。上次用户暂停记录仍保留，未从本段推定新的板测许可。原工程和外部快照整体UNKNOWN，未触及基线产物。

## 2026-09-29 用户明确暂停（最新状态）

T01生产模式16帧已通过，数值和耗时见下节。用户后续确认CSI摄像头/DSI屏幕已连接；已首次下载采集bit75fcf1...851eb并用保留DTB167e4c...5d21临时启动（CRC51ecbde6，Linux0a000000～0b7fffff reserved/no-map通过，无Flash）。真实全帧采集8秒超时，完整帧0、未START NPU、使能已关闭，状态无完成/活动槽/故障；源头未出流或链路阻塞根因UNKNOWN。证据experiments/video_capture_board_20260929_1/failure.tgz，634B/SHA7822776e5c2096c2f87941b7c50c53fbb1255048c6d60b6b3d09ae697a171dce。已请求物理恢复，用户改为“先暂停吧”，因此不等待默认继续、不再次操作板卡。

针对实际0帧新增只读CSI/ISP/AW/B与配置状态定位候选experiments/video_capture_probe_20260929_1，RTL/门级综合已完成，保留告警；P&R/STA/BIT/BOARD未执行，未替换现场采集bit。当前基于HDMI顶层的采集候选没有DSI输出，不能把屏幕连接或PNG当实体屏显完成。另新增T03全帧box8×4＋固定双线性参考及RTL：真实保存图明确扩展为1920×1080后实际CPU产生128维，相对同源Pillow像素max11/mean0.298、特征max2.021，尚不能替代训练预处理；RTL仅CODED，SIM/集成未验收。见experiments/preprocess_20260929_1/verification.json。

目标按用户明确请求PAUSED，本地构建在收到暂停时已退出，无继续P&R或新板测。恢复后第一个问题是实际摄像头0帧，用定位候选区分摄像头配置、CSI/ISP和DDR写通路；须先确认已请求的物理冷恢复。未暂存/提交；基线证据复用、原工程整体/外部快照UNKNOWN。

## 2026-09-29 T01生产模式16帧BOARD通过（最新）

用户确认物理恢复后实查uptime178.16s/模块空，复用已资格80MHz临时bit及DTB（CRC0660312d），没有Flash写入。原run_hard_soft_clip入口product模式同进程完成64 Hard START/释放和16 Soft START，CPU oracle0、Soft未计算金样；16×128特征与此前validate BOARD逐字节相同，logits差0，咳嗽0.985143。实际整链12011.346ms、空间11946.733ms、初始化1398.807ms另计；此前validate22847.785ms为历史对照，非同次配对提速。仍慢于已有CPU-only9314.887ms，不能称NPU提速或全空间硬件。实际每帧1普通Conv Hard＋1Add Soft，其余空间CPU；真实TCN/V4R本次CPU。

T01功能验收通过，证据experiments/product_20260929_T01_cold2/verification.json，完整归档17266B/SHA9f14fbbb035714dbb961fa1b18cd86b1093bbbc5538f6f95270596d77d77ec74。Hard已正常卸载0，Soft仍固定，已请求冷恢复；此前prestart reason14根因UNKNOWN，冷恢复本轮成功不是热恢复证明。下一主线真实摄像头/屏幕及固定预处理，现场相机/显示连接未确认；等待期间推进直接入主链的T03参考与RTL。目标active。基线既有17/17未受本次改动影响证据复用，原工程整体/外部快照UNKNOWN；Git实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c，无提交/暂存。

## 2026-09-29 T01生产入口已运行，Hard空闲故障阻塞BOARD验收（当前）

用户新施工目标已接续，重读AGENTS施工约束/总单T01和技术依据。原入口新增--execution-mode product|validate，默认product；H5资产只加载/哈希一次、16帧复用同执行器，product不计算CPU金样、不逐层保存大张量；Soft同会话product也不分配/计算金样。validate保留金样与落盘。明确ABI变更H5 48350001（SET_JOB product位/释放对实际CRC）、Soft1000b（PREPARE product位/结果明确未比较金样），长度/合法DMA/完整性/IRQ及工作态/失败固定保护保留，不能混用旧模块。

新增实际运行：PC同16帧product253.700ms、validate317.719ms，特征及logits逐值相同，NPU0；板端CPU product9314.887ms、初始化1044.545另计，16×128与上一BOARD CPU结果逐字节相同。不是NPU速度。目标编译两模块通过，保留既有Module.symvers/modpost与clock skew边界。现场登录uptime299.80s/模块空，已确认旧状态清除；复用旧80MHz临时bit/DTB启动，无Flash写入。未启动新采集bit。

首次硬件product实际在Hard第0片START前reason14拒绝：prework2/reset后3，100000polls无idle、writes0，Soft未执行，oracle0。Hard模块/DMA固定，不自动重试；T01硬件输出与混合耗时尚未验收。证据experiments/product_20260929_T01/product_vs_validate.json与board_failure.json，下一动作物理冷恢复后执行已准备product命令。实际摄像头、实体屏显、全空间/真实V4R PL仍未完成；当前目标active，旧blocked是历史阶段。原工程整体/外部快照UNKNOWN，基线未参与新写入/未全量复验；Git实查detached2685d5f4e21bb91b31a52dbde8527c59acd0964c/no tag，无暂存提交。

## 2026-09-29 等待现场冷恢复与连接（当前状态）

连续三轮实查同一现场阻塞：uptime4097.95→5064.61→5250.44s，旧softnpu_pool_oneshot仍固定，未观察冷启动；最新无capture/clip运行进程，非等待活作业。前两轮已完成板端预处理/渲染及采集主入口接线，本轮无新运行功能。下一硬件步骤需用户物理断电恢复及IMX415连接；相机/屏幕连接确认仍无回复，屏幕接口UNKNOWN。目标保留完整范围，按三轮阻塞审计标记BLOCKED，待外部条件变化继续；不称完成或用户主动暂停。已授权START保持，无新提交/设备复位/未知缓冲释放。

采集bit/保留DTB/固定16帧主入口已准备，实际Hard＋Soft保存帧与真实TCN/V4R已通过；实时采集、实体屏显、动作切分/拒识校准、多窗口持续运行及加速收益仍未验收。基线/原工程边界和Git身份沿用下节，未产生新构建/Git写操作。

## 2026-09-29 采集bit完成、板端图像软件通过（当前接续）

主链新增--capture-fdma：同一进程先采16帧到私有NPY，再进入现有Hard＋Soft/真实TCN-V4R和实际末帧渲染；live/saved报告区分、采集至分类总时单列，尚未实际相机运行。修改后的保存图片CPU路径305.491ms，16×128与此前PC输出逐字节相同、V4R logits相同，NPU0；板端新入口已传并--help通过。第一次板端导入失败为PYTHONPATH误用implementation_hardnpu/runtime而旧空间包实际在runtime，已按现场目录纠正；不重传模型。证据integrated_entry_verification.json及board_integrated_help_fixed.log。最新串口uptime5064.61s/旧Soft仍固定，冷恢复及相机连接仍待现场变化，无START。

整图/时序复用下节实际16帧Hard＋Soft→128维→真实TCN/V4R、22847.785ms及独立数值验收，不新增START、不研究吞吐。新增BOARD软件：从只读U盘旧运行包提取私有Pillow10.4，真实保存图片→训练预处理3×224×224，106.022ms，与PC逐字节相同；实际板端报告→1024×600中文结果PNG。目视发现Droid字体不含数字，新增显式Latin字体并在板端修复运行、取回目视通过。不是新识别耗时或实体屏显。

视频新增BIT：工作副本experiments/video_soft_capture_20260929_1复用已资格Soft/PS通路，新增默认关闭采集控制FST1/ABI10001、三块8MiB保留槽与完整写响应完成判据；综合/P&R/最终STA/bit生成通过，SWNS+0.103ns/HWNS+0.022ns，coverage95.45%。新bit与24MiB no-map启动DTB已生成，未下载/启动；显示读回仍关闭。capture_model_clip板端--help通过，实际摄像头采集未运行。

本次“已重启”后实际串口uptime4097.95s且旧Soft仍固定，未观察到冷启动，已再次请求物理断电恢复及相机/屏幕连接确认。不能在旧固定实例上替换PL；没有新增硬件提交。下一实际运行为确认冷恢复后启动新采集bit/保留DTB、核对ID与保留内存，再取真实16帧进入已有主链。证据docs/records/video_demo/2026-09-29-soft-capture/stage_receipt.json。原工程整体/外部快照UNKNOWN，原Soft资格bit此前本阶段重哈希一致，无原工程构建/Flash写入；Git实查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c/no tag，未暂存提交。目标active。

## 2026-09-29 连续16帧Hard＋Soft主链通过（当前接续）

后续可运行屏显准备：新增sign_result_display，实际BOARD分类报告＋真实末帧生成1024×600中文结果画面，已目视检查；同16帧入口--display-font在PC完成图片→空间参考→真实V4R→result.png全链。画面标明保存片段/演示与拒识未校准，不把模型得分写成准确率。电脑渲染不是实体屏幕BOARD证据，中文字体需显式提供。接续只读板端uptime1371s/Soft仍固定，无/dev/video或/dev/fb；物理恢复与相机/屏幕连接回复未收到，未新增START。下一条件是实际设备连接和已请求的冷恢复，不再扩展无运行收益的静态任务。

整图新增BOARD：用户确认物理恢复后，复用H5模块与已编译h6_serial ABI1000a，在同一进程/同一模块实例连续处理16张真实保存图。CPU前段→Hard H5四片→Soft实际残差→CPU128维，64 Hard START/释放、16 Soft START全部成功，Soft同组三块DMA复用/generation1～16；没有逐帧重启。16×128→真实C128/budget32 CPU V4R/TCN→训练分类，总22847.785ms（空间22728.142、时序60.041；初始化1103.892另计），咳嗽0.985143。当前实际覆盖每帧1普通Conv＋1Add NPU，其余34普通Conv/17depthwise/9Add及投影CPU；包含参考/FNV/保存开销，不称实时、全图NPU或提速。

全部实际Hard/Soft输出独立定点逐字节精确，16帧Soft三完整20KiB缓冲/packet/守卫/IRQ4/无late/严格完成核验通过；同实际Soft张量PC尾部128维max差2.50340e-6，同实际特征V4R logits max差4.44e-16。PC/板CPU前段仍有19 Hard输入和15 skip字节各差1LSB，整特征对PC候选max差0.0120914；不是跨平台完全相等或原浮点相等。

时序继续BOARD：上述新Hard＋Soft实际16×128保存特征→前两层真实Hard TCN→末层native CPU V4R→分类，51.738ms（初始化74.011另计），2 START/释放/卸载0。两全部输出独立INT64精确、PC回放与实际输入匹配，budget32区间覆盖精确定点类别、零预算精确/无回退；V4R仍CPU。第二条时序是保存特征运行，不与前一整链时间相加作为新整链测量。

实际输入入口新增--frames-dir/--raw-layout，复用训练预处理和离线FDMA解码；16真实PNG→同入口CPU参考→V4R PC运行313.043ms、预处理59.199/初始化66.753另计，输入与冻结板测16帧逐字节相同、PC特征/logits差0，NPU次数0。离线保存帧不是实际摄像头。相机/屏幕仍未连接（已询问当前可连接性），动作切分/拒识未校准、产品质量未验收，吞吐优化延后Astra。

证据docs/records/hardnpu_system/2026-09-29-hard-soft-clip-board/{hardware_verification,hard_prefix_pc_verification}.json；完整空间归档1252589B/SHA16f2f0dab47d2cd1ebe5ee3776581589f80789692906efec0a5d159ff570fbc2，时序归档9370B/SHA91c47f3d628750b6aea8f07bfe7a58cdd47d6ef462c7f92c79499a8c6be5a106。保存图片证据hard-soft-saved-frames/{input_verification,cpu_verification}.json。

Hard两模块均正常释放卸载0，Soft会话结束仍固定，不宣称热释放/事务排空；已完整取回证据后请求物理断电恢复，目标active，等待期间已完成直接进入主链的保存帧入口。下一项是实际采集帧与显示接入，非重跑普通层或继续吞吐研究。基线既有17/17未受影响资格复用；原工程整体/外部快照UNKNOWN，无原工程构建/Flash写入/暂存提交。实查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c/no tag。以下为历史阶段。

## 2026-09-29 当前Hard/Soft空间特征接TCN/V4R（当前接续）

整图仍复用现场Hard H5＋Soft H6＋CPU128维/1506.721ms证据；旧Soft单次模块仍固定，物理恢复未收到，未新增Soft START或重复空间运行。用户优先级仍是功能配合，吞吐优化延后Astra。

时序新增BOARD：当前空间候选的实际CPU16×128保存特征→真实C128/budget32 CPU V4R，61.295ms、初始化62.566另计，类别区间确认/无回退/零预算精确。run_hard_soft_clip加显式onnx/pointwise-cpu/v4r-batched-cpu选项，复用原实现/模型/native库，默认onnx。不是C4演示、V4R FPGA或提速证明。

Hard此前已4次释放/成功卸载、当前无实例；复核实际驱动只操作Hard TOP/软复位且资格模块一致后，复用空闲Hard：同当前特征→TCN前两层实际Hard→末层native CPU V4R→训练分类，2 START/释放/卸载0，53.239ms、初始化71.326另计，咳嗽0.985143。两全部6272B输出对各自实际输入独立INT64精确，同输出PC回放logits max差4.44e-16。budget32区间覆盖精确定点类别，输出logits对精确定点max差0.011232、对同特征原浮点TCN0.038725，不称浮点相等或识别率。旧Soft三完整20KiB缓冲同首图捕获字节未变，仍SUCCESS/1 START/无late IRQ，未再提交或释放。

证据hard-soft-current-v4r/verification.json；硬件归档SHA319e991228e695c1b6ea68ee40faacf0ac88097700853053fe184da6afcf08d4、CPU归档SHA7a00ffd95a6c6c2e4954ae9359c669cdcd8ca83c46239cd3f942ffd9a804f7c8。该时序使用保存的CPU空间特征，不是连续16帧Hard＋Soft空间或新的整链测量；没有重跑旧25例或普通层资格。

下一条件仍为物理冷恢复，随后已编译h6_serial候选实际连续16帧Hard＋Soft。新时序入口补丁2989B、冻结旧包不覆盖；视频/屏幕未连接，切分拒识/产品质量/V4R硬件收益未完成，目标active。基线17/17既有记录复用未影响路径，原工程整体/外部快照UNKNOWN；未原工程构建/写Flash/Git暂存提交，detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c/no tag沿用实查身份。

## 2026-09-29 现场Hard＋Soft单图通过，连续16帧已准备（当前接续）

整图BOARD实际跑通：用户确认冷恢复后，复用已编译模块/训练浮点CPU段/80MHz临时Soft bit与DTB，无Flash写入。CPU前段→Hard H5四片→Soft H6残差→板端CPU尾部128维。4 Hard START全部完成/释放/安全卸载0，1 Soft START严格IRQ4/SUCCESS，两个算子对实际输入独立定点逐字节精确，全部Soft缓冲守卫完好；同实际Soft张量PC/板尾部max差2.26498e-6。首图handoff同已有CPU候选，对完整浮点max差0.460721仍是量化边界，不称全图NPU或浮点相等。

整图1506.721ms：前段386.652、Hard路径1041.825、Soft路径23.244、尾部54.967，含诊断CPU参考/FNV/复制，不称核心时间或提速。Soft START到IRQ0.0711ms不是整图对照。实际覆盖1普通Conv＋1Add NPU，CPU34普通Conv/17depthwise/9Add及投影。证据hard-soft-live-board/hardware_verification.json、hardware_image_evidence.tar.gz（SHA ac6fd04158121e2f0920fdc2a3f6b9357d48536a225bd652462b722b04371b99）。

时序新增可运行run_hard_soft_clip：16张既有真实归一化图→16×128→真实训练TCN；BOARD CPU模式9514.647ms（空间9435.048、TCN16.039、初始化500.187另计），咳嗽0.985463，实际NPU0。首次PC整链allclose失败后取回所有实际张量：前段量化跨平台合19 Hard输入/15 skip字节各差1LSB，浮点舍入差异原因为INFERRED；最终对PC候选max差0.0120914，不能称数值相等。按板端实际输入独立H5/H6定点全部精确、同实际Soft尾部max2.50340e-6、同实际特征TCN logits差0/类别相同。证据hard-soft-serial/cpu_verification.json、cpu_tensors_evidence.tar.gz（SHA9e162a9142e777442c396b77d8bc27a0a6f55f9eed1390008d93987423ed096b）。不是识别率或相机运行。

下一直接运行已准备：独立h6_serial ABI1000a/dev/softnpu_h6_serial，仅上一作业严格成功、IRQ关闭同步、状态空闲且原缓冲重验通过，才复用同组三块DMA接收下一输入；失败固定且禁止重试，成功会话结束仍固定，不声称热释放/事务排空。native编译通过，模块ad7fbb0949f867e5ff71782b5f5dc0d1b282d594b9bb7e3535ccb6a0e829b2c8，新模块未加载/START；冷恢复包及receipt已封存。当前旧单次Soft模块仍固定，已请求物理重启，目标active；已有START授权持续，不因未回复暂停，也不制造额外静态任务。

连续16帧Hard＋Soft、后接已有TCN/V4R、视频/切分拒识/屏显尚待完成，相机和屏幕未连接。加速按用户安排交后续Astra，原H10/TCN/V4R事实复用不重跑。基线既有17/17记录未受源/文档修改影响而复用，未重复全量复验；原工程整体/外部快照UNKNOWN。当前实查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c/no tag，无暂存/提交。

## 2026-09-29 现场Hard＋Soft单图入口与板端CPU核验（当前接续）

新增可运行入口run_hard_soft_image：训练浮点CPU前段→实际H5接口→实际Soft H6接口→浮点CPU尾部128维。H5直接复用已资格四片SET_JOB/完成/释放ABI，不扩分片优化；Soft新增固定形状实时输入ABI10009，输入由本次Hard输出和skip组成，内核独立定点金样按该真实输入计算。仍单次START、原失败固定/物理恢复，不宣称连续帧完成。保留前阶段保存Hard→现场Soft原始数值证据。

BOARD CPU实际核验：完全相同产品入口以CPU定点参考代替两设备算子，614.672ms（前段379.643/H5参考179.044/Soft参考1.243/尾部54.709），实际NPU0；Hard参考与Soft参考逐字节精确，PC/板前段量化输入相同，尾部对同实际张量max差2.26498e-6/allclose，输出128维。当前浮点CPU＋量化H5/H6候选对该图完整浮点特征max差0.460721；12既有真实片段软件分类12/12同浮点，特征max0.777864/logits0.446760，非产品精度或浮点特征相等。

新Hard/Soft模块均板端native构建通过（运行Image精确源码/Module.symvers限制仍保留），sizeof ABI与Python一致；尚未加载新模块或START。旧Soft实例仍固定，物理恢复待用户确认，目标active。本轮实际修复ro临时启动导致heredoc落盘失败及PATH未导出导致GCC找不到cc1；用/tmp内存挂载与显式PATH解决，无root remount。找到既有板端训练原模型后仅传302774B源/资产/字节恢复脚本，从已存在模型恢复两CPU段并按输出SHA确认，不再次传8MB模型。

证据hard-soft-live-board/{verification,receipt}.json/software_evidence.tar.gz；训练浮点候选hard-soft-float/{pc_verification,clip_verification}.json，早期全UINT8候选hard-soft-live仅保留比较。下一实际运行是冷恢复后现场Hard→Soft→板端尾部，核验128维/原始张量/整图耗时，之后继续真实16帧时序与视频；提速任务按用户要求延后Astra。新恢复包包含本轮实际模块，不重编；相机/屏幕未连接。基线17/17既有未受影响记录复用，原工程整体/外部快照UNKNOWN；未Git暂存/提交，身份复用最后实查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c/no tag。

## 2026-09-29 Hard＋Soft真实残差交接首次运行（当前接续）

用户最新要求先跑通Hard/Soft配合，提速优化交给后续Astra；因此不再把稳定提速作为当前阻塞。已复用既有Hard单图128维、真实TCN与V4R结果，本阶段未重跑这些主链。

新增BOARD限定交接：已保存的真实H5输出＋真实网络skip（两者UINT8[1,160,7,7]）→现场Soft shortcut Add。配置XML确认NN_SHORTCUT=1；冻结厂家Add fill真实生成23字参数，实际输入地址1824/1828由厂家normal函数确认。复用Sol已验证80MHz bit/临时DTB及DDR normal driver，不写Flash；默认关闭PREPARE/卸载通过，随后一次START收到NN IRQ0x4，START至IRQ0.07053ms，两个输入、packet与全部尾守卫精确不变。

数值：7840原始输出字节全部等于独立厂家M17968/27065、S15的合并取整参考；相对ONNX量化Add仅12字节差1LSB。初版内核以ONNX为金样因此reason5固定缓冲，不能改写为内核SUCCESS。原始三缓冲及日志已取回；独立定点金样已更新下一源码，未重新构建/提交。物理重启已请求，目标active，等待期间继续实际CPU尾部集成。

实际Soft输出→PC真实量化网络尾部已运行得到128维，对同Hard输入＋ONNX Add尾部max差0.0483776。该结果是保存Hard→现场Soft→PC尾部，不是同进程连续Hard/Soft整图、板端尾部或实时视频。Soft单次IRQ间隔不是端到端加速对照。下一直接任务：物理恢复后把已资格Hard卷积与该Soft残差接口接成现场串行计算链，取得板端128维及整图误差/耗时；不再扩分片提速实验。

证据：docs/records/hardnpu_system/2026-09-29-hard-soft-residual/verification.json、三完整20480B缓冲及board_run.log。首模块b23139de2cd5b057db9cff5d05fbcce8a83205cc2d363cd050b8d7b745b521f8；独立新源码implementation_softnpu/h6_residual、主链接口runtime/soft_residual.py。相机/屏幕仍未连接。基线17/17复用未受影响记录；原工程整体/外部快照UNKNOWN，未暂存/提交，Git身份复用最后已查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c，无tag。

## 2026-09-29 空间H7＋H10两层整图板端通过，提速未通过（当前接续）

整图BOARD新增：正确训练浮点CPU前段→实际H7六片→实际CPU depthwise/投影桥接→实际H10八片→CPU尾部128维。同一模块固定14份已资格厂家包/权重预加载，未重生成指令；H7仅补足自有输入/权重分配的零填充，冻结packet仍读取原C160内容，H10使用原C320。实际NPU覆盖两层，其余33普通Conv/17depthwise/10Add及投影CPU；这是显式候选，不替换原默认H10或CPU路径。

首次14START/释放/卸载0，全部原始输出对实际输入独立INT64逐字节精确；PC/板两个量化handoff相同，最终128维对同原始输出PC尾部max差1.40e-6/allclose。474.325ms，CPU该次432.422ms，未提速。随后针对重复复制输入改每层共享，ABI0x48470101；同进程三对CPU431.748/457.764/423.578ms、混合515.113/507.208/504.091ms。42提交均完成/释放，首14原始独立精确，板端断言后两轮输入和28输出与首轮字节相同，成功卸载，无需重启。去重未形成实测加速，不混用CPU前段波动称优化收益。

两层量化候选现有12真实片段CPU预测分类12/12与浮点相同，但特征max差最高0.311739/logits最高0.154113；不是浮点数值一致或产品识别率。当前两层16帧实际板端分类未跑，原一层16帧与三层TCN及V4R事实仍复用前节。下一直接阻塞为混合实际开销/稳定提速；复用已有厂家较大分片候选减少提交，并按真实运行结果选择，不继续仅增加NPU层数。

模块8046e8d6a341bfce66187df38b93e85ea6a9d0a877c8fd63f4a13ae9522e5413，证据2026-09-29-dual-spatial/{board_verification,grouped_verification,clip_verification}.json；grouped归档SHA94db75ca6e26938853650cc2a206cabf8859150fd3e0beaf69fadc035e13afca。相机/屏幕仍未连接；Soft限定Pool、V4R CPU边界未改变。基线17/17复用未受本次编辑影响的既有记录，原工程整体/外部快照UNKNOWN；当前实查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c，无tag/暂存/提交，文件状态UNKNOWN（既有LFS状态查询限制）。目标active。

## 2026-09-29 真实C128 V4R非零预算接入与板端运行（当前接续）

整图仍复用已通过的CPU＋H10：单图128维与16×128真实特征正确，实际空间NPU仅H10，其余34普通Conv/17depthwise/10Add及投影CPU。单图混合尚未稳定超过CPU；此前16帧6935.251ms不是实时相机速度。本阶段没有重跑空间。

时序已实际跑通三层TCN HardNPU约28～29ms，新增真实C128/K3/dilation1/2/4批量V4R：前两层NPU实际输出→最后一层非零预算V4R CPU→残差/池化/分类。budget32使用4时刻块/16通道组，不能称C4演示或V4R FPGA。该真实片段咳嗽0.978935，分类区间确认、无精确CPU回退；NPU前两层输入/输出与已资格版本逐字节相同，两次释放后卸载0，板卡无需重启。

实际板端Python混合389.503ms，新增纯C CPU核后51.140ms；初始化61.121ms另计，包含模型加载9.431ms。整数核在三层实际输入×预算0/32上逐值等于Python，零预算精确、区间覆盖独立INT64参考；25个真实特征软件用例11分类确认/14精确CPU回退，全部与资格定点类别相同，非产品识别率。当前片段logits相对精确定点max差0.0161083。末层虽跳过35328/786432残差乘积，但摘要/代表值开销更大，51ms仍慢于全三层NPU和CPU，不能声称专利加速收益。默认快速路径不改为V4R。

SoftNPU既有结论保留为两个尺寸MaxPool的限定DDR板测通过；当前真实空间模型没有MaxPool，不重复Pool实验来代替模型加速。下一NPU方向是将已有有效层进一步接入空间主链并测实际收益。用户本轮确认IMX415和屏幕尚未连接，视频/实体显示未验证；动作切分/拒识、V4R FPGA与稳定提速仍未完成。目标保持active。

证据：docs/records/hardnpu_system/2026-09-29-v4r-batched-real-tcn/{verification,board_verification}.json；native_board_evidence.tar.gz SHA7194d7a0b11b506e1f0a918dbb8cfc7be5df5947eaa25bbeb1537551523b6ec6。基线17/17复用未受本阶段修改的既有核验；原工程整体/外部快照UNKNOWN。无暂存/提交，Git身份沿用最近实查detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c、无tag。

## 2026-09-29 真实16帧TCN三层HardNPU通过并接主入口（当前接续）

整图：已通过的板端CPU＋H10空间网络仍产正确128维/16×128；本轮直接复用其保存的实际特征，没有重跑空间或推算新整图端到端耗时。空间实际NPU仍仅H10，CPU其余34普通/17depthwise/10Add及投影。

时序BOARD：真实训练C128/K3/dilation1/2/4展开为C384→O128点卷积，7×7中保留全部16有效token，剩余零点填充；三层Conv实际NPU，残差/ReLU/池化/训练分类CPU。4×4首层虽然完成但第16通道起错误；7×7厂家包实际三层完成/成功释放/卸载0，全部3×6272B输出对各自实际输入独立INT64参考逐字节精确，真实输出驱动下一层输入；同输出PC/板分类logits max差8.88e-16。根本硬件原因UNKNOWN；实际CMA权重与源完全相同，7×7是已验证运行路径，不称权重重排修复。

固定模型产品复用已通过H10预加载/IRQ映射/完成守卫：独立ABI0x54430107/dev/tcn_grid7_fixed、三模型一次加载、每层独立输入；停止运行时全CPU卷积金样和重复模型提交，但保留DMA地址/输入全文/所有守卫/完成后模型全文/实际CRC及失败固定。实际模块SHA2b9a2941ceb164e1756094c701e40b0685daba788618f240416fdf283c8b7d28。默认关闭与真实三层通过；输出/输入均与前诊断版本相同。诊断292.168→产品28.324ms，加载8.104ms初始化另计；三次RUN合5.462ms含检查/IRQ等待，不是纯核心时间。

主入口run_temporal_features新增显式pointwise-hardnpu-fixed：已有空间真实特征→三层实际NPU→咳嗽0.978550，29.378ms；同特征该次冷CPU16.442ms、类别相同，浮点logits差0.0385352。先前暖CPU3.753ms复用历史，不混成同次测量。主入口3输出/输入与独立资格版本全部字节相同，3释放/卸载0，无需物理重启。时序NPU功能已跑通，但尚无相对CPU加速收益。

实际V4R仍未参与本次硬件；专利非零预算/收益、空间稳定提速、IMX415连续实采、切分/拒识与实体屏幕未完成。下一产品接续将该资格时序入口复用到后续主链/真实V4R适配，不继续扩普通层全套前置验证。证据real-tcn-grid7-{board/first_verification,fixed-board/{verification,main_entry_verification}}.json及原始归档；本日工作日志。Git detached HEAD2685d5f4e21bb91b31a52dbde8527c59acd0964c、无tag，无暂存/提交；保护基线17/17复用未受影响记录，原工程整体/外部快照UNKNOWN。

## 2026-09-29 真实TCN首次硬件完成、数值差异待修复（当前接续）

整图已完成的事实复用下节：板端单图128维与16帧CPU＋H10→CPU TCN正确，实际NPU仅空间H10。新pointwise-cpu时序入口已接16帧真实PNG，PC总647.345ms/时序0.624ms、咳嗽0.978999，实际NPU0。

时序推进：真实三层C128/K3/dilation1/2/4转换为C384→O128/4×4点卷积；标量量化候选25/25特征用例类别与浮点一致，ONNX最大logits差0.0173243/厂家定点参考0.0405538，非产品识别率。厂家三层解析/优化/LoadNetwork及真实776B包捕获已通过；中间value_info缺失导致的解析SIGSEGV已修复。独立TCN模块f413290c...ab9d9实际编译、默认关闭拒绝/卸载通过。

首次武装运行START前work2→3/reason14/writes0拒绝；用户物理恢复后同一模块首层真正START成功完成：writes8、IRQ1/work5、guard0、RUN等待4.026ms。2048B输出中前16通道256B逐字节精确，后112通道差异1323B/max209；未完成数值验收，后两层未执行，不称完整TCN硬件分类或加速。输出和日志已取回，用户再次物理恢复；下一直接工作捕获厂家实际CMA权重载荷，区分重排与其他通道边界问题，不盲改寄存器。

新运行文件持久放板端/root/tcn_pointwise_product_20260929_1，复用已编译模块不重复构建。证据2026-09-29-real-tcn-first-prestart/{board_evidence,cold_retry_1_evidence}.tar.gz；工作日志2026-09-29-real-tcn-integration.md。TCN/V4R完整硬件收益、IMX415连续采集/切分/拒识/实体屏幕未完成。保护基线17/17既有证据复用；原工程整体/外部快照UNKNOWN，未暂存/提交。

## 2026-09-28 串行16帧与真实特征时序板端通过（当前接续）

整图/时序BOARD：固定模型ABI0x48400100复用寄存器映射与IRQ，释放后禁用IRQ；每次START仍重置completion并保留原空闲/IRQ/work门槛。产品包缓冲16KiB改4KiB，904B有效数据及整页尾守卫保留；模型加载时完整比对，之后每次完成完整比对，输入内容/全部守卫每次START前仍检查。CPU前段禁空闲线程自旋、尾部单线程，固定串行。

模块dfc9d4...9fb8c：真实16帧128START/128释放和三组同图24START/24释放，全部原始片独立INT64精确；相同原始输出的PC尾部最大误差1.79e-6/allclose。16×128与上版字节相同，同特征PC TCN logits逐值一致，咳嗽0.979300；卸载0。16帧6935.251ms（空间6912.997/TCN3.753），上版8248.336ms，减少15.92%；同片纯CPU7143.087ms，此次快2.91%，不是稳定提速结论。

同进程交替三组单图CPU441.790/428.785/426.123ms、混合455.724/452.462/430.097ms，混合仍慢；H10段约20.2ms（首图31.0）。实际NPU仅H10一层，CPU34普通Conv/17depthwise/10Add及投影。正确单图128维和真实16帧分类已完成，整体稳定加速未验收。

真实时序接入BOARD CPU：新增run_temporal_features.py直接复用已实际取得的16×128及mask，不重算空间；训练INT8 TCN35.563ms，完整C128/dilation1/2/4的V4R C4零预算映射28672任务59182.525ms，logits逐值相同、类别均咳嗽；同特征PC INT8 allclose，INT8相对浮点logits最大差0.0102103。时序硬件未运行，V4R软件明显较慢，默认仍CPU ONNX3.753ms。下一步实现真正批量多通道时序/专利预算收益，不继续用小任务演示替代完整产品。

证据product-fixed-serial-board/verification.json及七个原始归档；准备脚本复用资格模块和实际特征时序入口，无重打包冻结USB目录。相机连续采集、切分/拒识、实体屏幕及TCN/V4R硬件未完成。原工程整体/外部快照UNKNOWN，保护基线17/17未受改动记录复用；Git detached HEAD 2685d5f4e21bb91b31a52dbde8527c59acd0964c、无当前tag，未暂存/提交。git status因共享原仓Git LFS临时目录写权限失败，文件状态UNKNOWN，未绕过filter。

下一实际运行准备：pointwise_temporal_tensors将真实TCN三层K3/dilation1/2/4展开为C384→O128、4×4 token网格的1×1张量，零点128输入6144B/权重49152B。真实NPU特征通过三层INT64累加、偏置/每输出scale与完整INT8 TCN逐值相同，分类相同；原始张量和参考保存在real-tcn-pointwise-inputs。此为CPU数学准备，不是NPU指令包或上板；下一直接阻塞是厂家包生成与每输出requant适配，4×4形状也尚未板证。

## 2026-09-28 固定模型预加载及真实16帧通过（当前接续）

整图BOARD：新增固定H10产品入口，ABI0x48400100、/dev/h10_fixed_model，复用既有驱动提交/完成/成功释放/故障固定，诊断ABI0x48400000保留。八份包/权重一次加载并核冻结FNV、合法32bit DMA地址及每片大小；内核保留内容快照，输入每帧只复制一次。运行时逐片比较DMA内容/守卫，完成态检查、实际输出CRC与导出字节自校验；同一已完成作业的检查结果在无新提交时复用。每帧不再重复CPU卷积金样；数值独立资格验收在运行后做，不把CRC称数值证明。

首版模块SHA7e6b01...1f68f默认关闭RUN EPERM/冷态卸载通过。真实单图8START/8释放/卸载通过，原始输出与实际输入INT64参考精确，128维特征及八输出与诊断版字节相同。单图网络472.268ms（CPU前段436.655/H10含检查33.040/尾部2.244），预处理89.041，总561.309ms；模型加载14.365ms属初始化另计。还未超过纯CPU约440ms。宽读取memcmp替代试验正确但H10段42.904ms，无提速，已回退，未选为当前运行模块。

时序BOARD：首版固定模型只预加载一次，后15帧加载耗时0；真实16帧128START/128释放，全部原始片与独立参考精确，16×128与原诊断路径逐字节一致，CPU训练TCN仍咳嗽0.979300，PC用相同特征的logits逐值一致。端到端8248.336ms（空间8215.090/TCN13.755），由原诊断18.659s减少55.8%；包含真实CPU前段/NPU提交及取证保存，不含预处理张量载入/初始化，不是实时相机速度。模块成功卸载，无需重启。

下一直接瓶颈是固定模型运行中的内容检查/提交开销和CPU前段；保留资格验收诊断路径，继续减少不变模型的重复工作，再测与同模型CPU的加速收益。实际NPU仍一层；TCN/V4R硬件、IMX415连续采集、切分/拒识/实体屏幕未完成。未来运行目录准备脚本已带新执行器、明确产品模块/独立运行脚本，未重打包冻结USB目录。

证据product-fixed-model-board/{first_verification,sequence_verification}.json及原始归档，详细改动/未选试验在本日工作日志。原工程整体/外部快照UNKNOWN，保护基线17/17复用未受改动记录；无Git写操作，branch/commit/tag未查询UNKNOWN。

## 2026-09-28 混合链实际提交开销优化（当前接续）

产品链已完成单图CPU＋H10和真实16帧CPU TCN板测，范围见下节；本阶段针对已实测速度瓶颈。CPU ORT两次447.232/440.519ms，H10对应浮点Conv约19.15ms；最大单层为backbone.2的depthwise约29～31ms，非首层（约12～14ms）。不能仅因H12历史失败就把首层当最大瓶颈。

保留全部FNV字节/输入权重守卫、完成检查和失败固定，将DMA校验读取从单字节改为8字节读取后原顺序散列。native边界/非对齐校验通过，目标反汇编确认64bit ldr；新模块SHA317d712...76020严格构建/默认关闭RUN EPERM/冷态卸载通过。实际单图8START、8释放/卸载成功，八片原始输出及128维特征与上版逐字节相同。网络714.934ms（prefix483.196），RUN合40.220ms由上版174.563降低，客户端122.704ms由390.295降低；含验算仍比纯CPU慢。

为决定下一实际改动，加入默认关闭measure_completion测时，另建模块保留上版。开启时8START→中断线程观测合0.51618ms（含IRQ调度延迟，不是纯核心时间），网络649.520ms单次；128维特征与上版逐字节相同/8成功释放/卸载0。两次网络时间受CPU前段波动影响，不将715→650称新增加速。硬件计算与诊断提交开销已明确分开。

下一DOING：固定模型预加载八包/权重、共享实际帧输入、一次完成校验和输出完整性检查，减少逐片重复加载/CPU金样计算。仍保留完成判据、DMA存活/守卫、实际超时固定与物理恢复；先单图实际比较，再16帧，不扩通用调度状态机。现有准备脚本复用317d712已通过模块，冻结旧运行包/回退产物不覆盖。

证据product-dma-hash-board/{verification,completion_timing_verification}.json及两个原始归档；本日工作日志。实际NPU仍仅H10一层，CPU TCN/V4R软件边界、视频/拒识/实体显示未改变；整体目标未完成。

## 2026-09-28 板端单图混合及真实16帧分类通过（当前接续）

用户已明确恢复上板实验授权，替代下文历史“暂不上板”。USB运行包已传到板端独立/run目录；ARM客户端native GCC严格编译成功。先发生一次START前空闲拒绝（writes=0、prework2/reset后3、reason14），日志取回并由用户物理断电恢复；模块SHA与历史16作业成功版完全一致，根因仍UNKNOWN，未降低空闲门槛。

整图BOARD：正确浮点CPU前段→H10真实8片START→CPU尾部产出[1,128]。八片原始输出与实际输入INT64参考逐字节一致，逐片完成/释放，模块成功卸载。最终特征与同原始输出的PC尾部allclose（atol1e-6/rtol1e-5，max_abs1.22e-6）；与板端完整浮点模型max_abs0.0573455，量化差异不称浮点数值一致。实际NPU仅H10一层；CPU34普通Conv/17depthwise/10Add及投影。

单次板测网络：原验算版1132.132ms，纯CPU439.906ms；改用数值精确BLAS验算后混合916.274ms（预处理89.528ms，总1005.802ms），特征和八片输出与改动前逐字节相同。新验算88.824ms、8个RUN ioctl合174.563ms（包含提交/完成等待，非纯核心时间）、客户端390.295ms。当前混合比CPU慢，未完成NPU加速收益；保留逐片验算和DMA/失败恢复措施。

时序BOARD：复用既有真实测试0020预处理张量（SHA bb1d522...ad0d6）及训练TCN（d452b0f...de0dc），同一模块实例完成16帧×8片=128START/128释放，得到16×128真实混合特征，CPU TCN分类咳嗽、置信度0.979300。128原始片全部精确匹配实际输入参考；同原始输出PC尾部max_abs1.79e-6且allclose；相同特征PC TCN logits与板端逐值一致。原验算版本端到端18658.739ms（不含预处理张量载入/初始化），空间18610.380ms，TCN27.129ms。16帧未重跑新BLAS版，不据单图推算实测时间；该片段结果不是产品识别率。

视频/显示未新BOARD；IMX415实采、自动切分与拒识、实体屏幕、TCN/V4R硬件及实际加速收益仍未完成。下一直接工作：解决已实测的混合执行开销/空间层加速瓶颈，复用这些真实特征继续TCN/V4R适配，不重跑普通层全套检查。冷启动work2→3拒绝根因保留专项，不能自动重试未知设备。

证据：docs/records/hardnpu_system/2026-09-28-product-{first-prestart,mixed-board,sequence-board}/；详情见本日spatial-temporal-integration工作日志。保护基线哈希复用未受本轮修改的17/17既有证据；原工程整体/外部快照UNKNOWN。Git未暂存/提交，branch/commit/tag未查询UNKNOWN。

## 2026-09-28 原始帧文件接空间/时序入口（当前接续）

产品链：单图和16帧CLI接入现有FDMA离线解码器，明确布局JSON（width/height/stride_bytes/pixel_bytes/roi_xywh/可选slot_bytes），原始文件→裁剪RGB→训练预处理→同一CPU/H10入口。没有DDR或设备读取。找到的工作树帧样例是历史合成布局，尚无可绑定的实采快照。

16真实PNG像素按合成BGRX带行填充布局打包，实际原始帧序列→H10定点CPU预测→TCN输出咳嗽，16×128与原PNG入口逐字节一致，max_abs0，PC端到端530.155ms。单帧CPU raw网络6.427ms/解码预处理5.513ms，特征与对应PNG逐字节一致；旧PNG单图入口特征仍相同。单次PC测量，非NPU速度/实时采集。

当前实际NPU0，单图真实混合/板端耗时仍待解除暂不上板；IMX415像素顺序、完成帧/存活DDR缓冲、自动切分/拒识、实体显示未验证。既有自包含单图目录保持原版本，不重打包；准备脚本已列入新输入依赖以供未来构建。证据experiments/product_raw_input_20260928/verification.json；日志2026-09-28-spatial-temporal-integration.md。

## 2026-09-28 空间执行器接入连续回放（当前接续）

产品链PC推进：既有continuous_replay_onnx.py接spatial_factory的CPU/H10接口，真实288源帧逐帧实际空间计算，16特征缓存/4帧步长交训练TCN，36窗口/12事件；88人工黑场明确重置，非自动动作切分。CPU入口复现前轮12事件类别与触发帧位；浮点前段→H10定点CPU预测→浮点尾部也12/12事件类别/触发帧与CPU相同，弱标签匹配9/12，非产品精度。

PC CPU总1.941s、空间p50 3.211ms/TCN p50 0.143ms；H10预测及中文字幕视频总10.327s、空间p50 30.312ms/TCN p50 0.160ms。不同总耗时含视频编码差异，不能比较为NPU加速。实际NPU0；cpu-h10接口CODED而未执行。硬件RUN明细可传至报告，无计时记UNKNOWN。

生成中文字幕回放mp4并实际解码376帧/8fps，首事件预览已视觉检查。仅PC素材回放及字幕，不是IMX415连续采集/实体屏显/拒识验收；黑场边界由测试输入提供，阈值0/置信度未校准。当前单图真实CPU＋H10及板端耗时仍待用户解除暂不上板限制。证据experiments/product_replay_20260928_cpu/、product_replay_20260928_h10_prediction/integration_comparison.json及视频；日志2026-09-28-spatial-temporal-integration.md。

## 2026-09-28 真实TCN INT8与C4完整映射（当前接续）

时序：44个训练片段×16张真实图像经正确CPU空间模型得到128维，校准三层TCN输入范围（未用test），每输出通道权重INT8、输入对称INT8、INT64累加/偏置，残差/激活/池化/分类仍CPU浮点。24组测试特征（12浮点空间、12H10定点预测空间）类别全部与训练浮点TCN一致，logits最大差0.0121291，输入截断0。CPU定点TCN中位3.185ms，未比约0.2ms ONNX更快，默认仍ONNX。

一个真实16帧片段完整通过现有V4R-1整数参考：按dilation相位抽取序列，C128分32个C4组、128输出，跨组INT64累加后加偏置一次；三层分别4096/8192/16384任务，总28672，输出logits与直接INT8路径逐值一致。该C4参考耗时1724.977ms，仅CPU映射，不是RTL/BOARD。任务量说明直接旧MMIO接口调用不能被宣称为产品加速，后续应批量多通道，而非重复C4演示。

序列CLI已可选择int8-cpu/v4r-int8-cpu及训练校准目录；真实图像→H10定点CPU预测→INT8 TCN完成咳嗽分类，PC端到端542.856ms（初始化/保存另计）。整图仍实际NPU0，单图真实H10混合/耗时仍待用户恢复上板。拒识、视频/显示未推进。证据2026-09-28-real-tcn-int8-train/、2026-09-28-real-tcn-int8-c4-verification/、2026-09-28-sequence-cli-int8-tcn/；日志2026-09-28-spatial-temporal-integration.md。

## 2026-09-28 单图产品运行目录（当前接续）

整图：为下一次实际CPU＋H10运行准备自包含experiments/h10_product_runtime_20260928_1，复用现有模型/真实八包权重/已验证模块二进制，仅复制直接运行所需文件。目录PC实际CPU及H10定点CPU预测分别4.216/31.569ms，128维特征均与原入口对应结果逐字节一致；当前实际NPU0，不是板端速度。没有重建所有层或生成新研究框架。

客户端源码增加每片RUN ioctl时间；H10Executor分离实际输入验收金样、作业文件、客户端墙钟及八次RUN耗时，H10Spatial返回这些明细。RUN时间含驱动提交/轮询，不是纯核时间。旧客户端无时间标记时该项UNKNOWN，不拒绝已通过的输出。

板端H11历史已证明Python/NumPy/ORT尾部可用；当前新前段/客户端仍未板端执行。电脑没有可用WSL/Linux交叉编译器，新客户端待恢复上板后native GCC构建；运行目录build_client.sh只编译，run_cpu.sh只CPU，run_mixed.sh会八次START且要求模块已准备，不自动装卸或复位。用户暂不上板继续，本阶段没有板卡连接/START。时序/V4R复用前轮PC证据，视频/显示未推进。

证据experiments/h10_product_runtime_20260928_1/pc_verification.json与两份PC输出；日志docs/records/worklog/2026-09/2026-09-28-spatial-temporal-integration.md。最直接阻塞仍是恢复上板条件；下一步新客户端目标构建、单图真实H10/128维及板端耗时。

## 2026-09-28 真实128通道TCN的V4R软件接入（当前接续）

时序：v4r_temporal.py实际加载训练TCN三层128×128×3权重，处理dilation1/2/4、因果零填充、每层偏置/两次ReLU/残差、mask池化和3类分类。V4R软件按固定块代表值/不可变残差范围建立贡献区间，再逐块替换，零预算全部结算；不是把C=4演示作为真实网络。12原浮点特征及12H10定点CPU预测特征共24组与训练ONNX logits最大差1.34777e-6，分类24/24一致；真实特征的10有效帧mask也allclose通过。

PC软件V4R中位57.753ms，对照ONNX TCN0.197ms；零预算残差乘法不减少，还增加代表值与区间开销，不宣称加速。默认仍ONNX，序列CLI新增显式v4r-zero-cpu；实际图像→H10定点CPU预测→V4R CPU完成咳嗽分类，端到端609.241ms、其中TCN65.931ms（PC单次，初始化/保存另计）。

整图实际NPU0，单图真实H10混合和板端耗时仍待用户恢复上板；未板卡连接/START。V4R仅FLOAT64软件零预算真实模型适配，不是现有INT8 C=4 V4R-1硬件兼容/RTL/BOARD，非零预算和加速收益未验证。拒识、视频和显示本阶段未推进。证据2026-09-28-real-tcn-v4r-zero/verification.json、2026-09-28-sequence-cli-h10-v4r-zero/result.json；日志2026-09-28-spatial-temporal-integration.md。

## 2026-09-28 统一图片/16帧推理入口（当前接续）

整图/时序：重新读取当前AGENTS及最新记录后，复用已有CPU/H10Spatial和训练TCN，实现run_spatial_sequence.py；从真实图像目录抽16帧、实际计算16×128特征并分类，图片与序列共用spatial_factory。首个片段两模式均预测“咳嗽”，特征分别与前轮浮点/H10定点预测逐字节相同；共用入口的单图特征亦与前轮相同。PC浮点网络16帧52.580ms、TCN0.266ms，含读图/预处理/分类102.314ms；H10定点CPU预测空间494.660ms、TCN0.343ms，端到端543.816ms。单次测量，模型初始化与结果保存另计，不是板端性能。

当前实际NPU0。最直接未完成项仍是新浮点前段→真实H10→浮点尾部单图上板验收与耗时；用户暂不上板限制有效，未COM4/目标构建/START。CPU首层继续绕过H12故障，未要求其它普通层逐一通过。真实TCN CPU已可复用，V4R/拒识/IMX415连续采集及显示未完成。

证据：docs/records/hardnpu_system/2026-09-28-sequence-cli-cpu/result.json、2026-09-28-sequence-cli-h10-prediction/result.json及integration_verification.json。日志仍为docs/records/worklog/2026-09/2026-09-28-spatial-temporal-integration.md。

## 2026-09-28 实际16帧TCN与单层H10候选（当前接续）

整图/时序：真实12个测试片段各均匀采样16帧，逐帧实际128维特征交训练好的3类TCN，非C=4演示。浮点链9/12弱标签正确（75%）；旧诊断量化CPU及同图H10定点CPU预测都4/12且全部“过敏”，实证保持拒绝部署。直接按此故障调整为正确浮点CPU前段→仅H10现有packet定点CPU预测→浮点CPU尾部→TCN，恢复9/12，12个类别全部与浮点链一致。当前实际NPU0，硬件/拒识/V4R/摄像头显示未运行；75%仅12弱对齐片段，非产品精度。

最小H10Spatial新增float_handoff，按已冻结H10输入scale0.1773609519/zp130量化，输出scale0.0235294122/zp0解量化后进入原浮点尾部；没有换packet/权重或CPU金样注入。候选特征相对浮点最大差0.131074，logits最大差0.062594，但本组分类12/12不变。PC16帧中位空间计算486.739ms（包含INT64 CPU模拟H10），TCN约0.1ms；不能据此声称设备加速。浮点基线16帧空间中位52.350ms、TCN0.196ms。

图片CLI默认CPU改为正确训练浮点模型，单张网络3.942ms；h10-fixed-cpu及cpu-h10默认采用浮点前段/尾部候选，预测单张31.001ms。实际cpu-h10仍未目标构建/运行，暂不上板限制有效。下一步真实H10单图/16帧验证与V4R真实128通道适配；H12专项修复不阻断。视频/屏幕本阶段未推进。

证据：2026-09-28-spatial-temporal-16frame/results.json、2026-09-28-float-prefix-h10/results.json、2026-09-28-trained-float-image-cli/；日志docs/records/worklog/2026-09/2026-09-28-spatial-temporal-integration.md。


## 2026-09-28 单图H10接入可运行准备（当前接续）

整图：已实际计算当前图片CPU前段→真实H10包定点公式的CPU预测→复用H11尾部，输出128维；两图与上轮逐层定点路径特征逐字节一致。简化为2个CPU会话，单图片CLI预测运行30.562ms（前段3.499/INT64 CPU预测H10 26.823/尾部0.209ms；预处理另8.433ms），实际NPU0，不是板端速度。

数值变化已实测：H10定点预测替换原CPU H10后，相对原图两图128维最大绝对差0.046371/0.049754，余弦0.999898/0.999830；不是原图allclose通过或识别质量验收。实际NPU应先匹配当前输入定点结果，分类影响后续实测。已有诊断模型质量拒绝部署保持。

run_spatial_image.py提供cpu、h10-fixed-cpu及cpu-h10明确模式；硬件模式用H10Spatial/现有模块和新运行时C客户端，当前上游输入和实际厂家packet/weight随作业保存，只返回设备原始输出，无失败自动回退/热恢复。16个H10真实载荷资产从已有证据复用；未目标构建、未板端运行。暂不上板是当前单图实际混合/端到端耗时的外部限制。H12先CPU，不再阻断本里程碑。时序/视频本阶段未运行。

证据：docs/records/hardnpu_system/2026-09-28-minimal-h10-spatial/、2026-09-28-minimal-h10-cli/、2026-09-28-serial-h10-fixed-cpu/；日志2026-09-28-serial-spatial-integration.md。


## 2026-09-28 单图片空间链实际计算（当前接续）

整图：修复CPU桥接预处理缺参/图像类型错误，36桥接两帧实际计算通过；再实现固定串行SerialSpatial，将35普通Conv全部实际CPU计算接入桥接，不填入金样中间张量。两真实图片输出[1,128]float32与原图逐字节一致，max_abs=0；网络首轮15.646/18.698ms，三次后续中位37.167/8.440ms（PC，波动大，预处理/会话初始化另计）。可运行CLI run_spatial_image.py再次输出相同frame0特征，网络21.878ms。当前实际NPU=0，CPU普通35/depthwise17/Add10；这是CPU整链，不是板端混合通过，旧诊断图部署质量仍拒绝。

复用已通过H10八片客户端生成runtime/h10_serial_client.c及H10Executor输入接入源码：将当前上游真实张量送到现有H10模块，按实际输入计算验收金样，只返回设备原始输出；其它层明确CPU，无失败自动回退，保留原失败固定/成功释放。源码未目标编译或上板，暂不上板限制继续。下一步首个板端混合里程碑采用CPU前段+H10+CPU尾部，H12暂CPU且专项修复后移，不再等待全部层板证。时序/TCN/V4R及视频/显示本轮未新增通过。

证据：docs/records/hardnpu_system/2026-09-28-serial-spatial-cpu/verification.json、2026-09-28-single-image-cli/；本阶段日志docs/records/worklog/2026-09/2026-09-28-serial-spatial-integration.md。复用前轮已核基线身份，本轮不重复全量哈希；原工程整体/外部快照UNKNOWN。无Git暂存/提交，branch/commit/tag未查询UNKNOWN。


## 2026-09-28 用户调整执行方式：实现与集成优先

用户要求减少无实际收益的前置论证和防御性代码，先跑通功能、按真实报错修复。AGENTS.md已在原目录和当前开发worktree同步，历史全面门禁不再作为默认主线；基线、合法DMA内存和真实失败恢复仍保留，具体任务最新“暂不上板”等限制不因规则修改解除。

Astra只读检查任务“DR1M90G HardNPU H1 接管”和其工作副本，发现原目录9月22日状态滞后：新副本记录六个普通Conv匹配单层板测报告、H10两帧八分片16次START及H11硬件输出到CPU尾部；H12首层发生实际超时，尚非完整模型。上述为本轮文档/任务记录复核，未重验所有原始板测。最新CPU桥接生成脚本运行退出1，随后任务因额度限制中断，不能写桥接通过。近期静态工作也受该任务用户“暂不上板”限制，不能全部归为无用工作。

当前下一目标：修复CPU桥接实际失败，完成单张图的实际混合计算与完整特征比较；复用已验证NPU层，必要时首层暂CPU，明确实际加速范围。然后固定16～32帧接时序/专利方案，再接视频和显示。不新增通用防御框架或重跑Soft Pool。完整模型加速、专利方案真实接入、视频识别均未完成。本轮仅修改执行规则和记录，无板卡或Git操作。


## 2026-09-28 张量所有权状态机主机核验（当前最新）

用户只静态限制保持，无板卡连接。新增frame-local Python激活账本，依赖/输入预约/输出状态/全部消费者完成/外部释放门槛；失败帧停止且在途张量PINNED，设备作业不能CPU完成。实际源图374节点状态流、304张量账本释放、10残差保留、707次错误无改写拒绝及遗漏残差消费者声明拒绝均主机通过。未算子数学/实际buffer分配/设备适配器/DMA排空或BOARD；六匹配报告计数保持。见HARDNPU_TENSOR_OWNERSHIP_HOST_20260928.md。


## 2026-09-28 全图静态数据交接合同（当前最新）

只静态，无板卡连接。源图374节点/52Conv静态依赖核验，66条动态Q/DQ参数精确一致；完整激活分析定位10处float32残差分支，不能按量化单消费者提前释放。78子模型/360作业与实际源图tensor、形状和量化精确绑定。新增304激活张量的消费者完成/设备访问结束/最终输出外部释放语义要求，尚非内存管理或DMA排空实现。新工具均PC Python运行，未受阻C程序重试、无新BOARD。见HARDNPU_GRAPH_HANDOFF_CONTRACTS_STATIC_20260928.md。


## 2026-09-28 普通层C输入取块静态推进（当前最新）

保持用户只静态限制。common布局代码新增pw_tensor_extract，从完整NCHW UINT8张量取块，核精确长度/范围/乘法溢出。新主机输入/布局核验程序严格编译成功，首次extract启动被Windows应用控制WinError4551拒绝，未运行比较，不能记360输入通过。保留失败、编译产物及清单；编译后汇编核对检查在memcpy前、行/通道步长成立，属于静态推理。未改应用控制或连接板卡。新增函数CODED/HOST_COMPILED，运行UNKNOWN，目标继续；见HARDNPU_POINTWISE_C_INPUT_EXTRACT_STATIC_20260928.md。


## 2026-09-28 普通层实际C布局静态核验（当前最新）

用户只静态限制持续，本轮无板卡连接。新增可复用NCHW UINT8空间/通道拼接C代码，先核边界和全区域覆盖再写，重复/重叠拒绝，缺块不能完成；实际C严格主机编译，对28层两帧360个乱序分片生成56整层输出，均与冻结CPU源逐字节一致。775profile/225源文件逐哈希复核，尺寸/范围/重复/溢出拒绝核验通过。Linux目标编译、通用驱动/调度/全图和新BOARD仍未完成，硬件覆盖计数不变。见`docs/research/HARDNPU_POINTWISE_C_LAYOUT_STATIC_20260928.md`。


## 2026-09-28 真实pointwise载荷通用静态核验（当前最新）

保持用户只静态限制，未连接板卡。新增真实捕获结构/模型几何/量化/偏置/分包通道检查及按实际倍率移位生成CPU预期工具。复用H5两帧历史定点和H10八片两帧历史定点/板测输出，共18组逐字节一致；78待验证子模型元数据通过，截断/追加word/偏置改动三类拒绝。没有新的厂家捕获或START。多包调用方DMA重定位和通用生产提交合同仍未证明，六匹配硬件报告计数保持。见`docs/research/HARDNPU_POINTWISE_PACKET_STATIC_CONTRACT_20260928.md`。


## 2026-09-28 其余28个普通层静态批量准备（当前最新）

用户暂只静态限制持续，本轮未连接板卡。跳过六个已有匹配单层报告及另作H12的首层，剩余28个普通层全为1×1：两帧56次提取CPU/完整图逐字节一致，独立整数最近舍入参考也全部一致；完整图加中间输出前后终特征两帧逐字节一致。生成78个空间/通道子模型、360个CPU作业，逐元素覆盖一次并拼回全部28层；775文件清单重读匹配。78模型未来厂家软件捕获86文件包及暂存VerifyOnly/脚本语法准备完成，未厂家运行、无新真实packet或BOARD。硬件覆盖仍六个匹配报告，H12及其余28层未新通过；旧量化图质量拒绝部署保持。详见 `docs/research/HARDNPU_REMAINING_POINTWISE_STATIC_PREP_20260928.md`。


## 2026-09-28 H12整层调度静态推进（当前最新）

保持用户暂只静态限制，本轮未连接串口。新增64块整层用户调度及共享客户端/裁剪拼接代码，任一作业失败停止，不自动卸载；整层程序CODED，Linux目标编译未执行。实际C拼接代码在主机严格编译，两帧各64块打乱顺序仍与401408B冻结整层定点预期逐字节一致，重复/非法块拒绝。275文件整层包逐哈希核验及暂存VerifyOnly/语法通过，未上板。原超时原始数据新增定位：前16通道行0与56的3584B均匹配预期，其余仍预填值；根因UNKNOWN。报告 `docs/research/HARDNPU_H12_LAYER_SCHEDULER_STATIC_20260928.md`。


## 2026-09-28 H12对齐空间块静态就绪（当前最新）

用户最新限制：只做静态核验/推理/脚本修改，等用户明确通知后恢复上板实验；限制后未打开串口。此前已确认物理重启、uptime0分钟、模块空，首次小块暂存因标记等待超时仅创建空目录，无候选加载/START。32×32→16×16方案两帧64块裁剪拼接CPU/定点逐字节等价，厂家隔离软件分配HardNPU并Load/Unload成功、真实392B包已核。独立h12t_tile ABI0x48421000准备完成，修正FNV初值和暂存等待；13文件本地核验、脚本语法及主机地址/身份边界核验通过。没有小块目标构建/BOARD，原整层超时根因UNKNOWN。见 `docs/research/HARDNPU_H12_ALIGNED_TILE_STATIC_READY_20260928.md`。


**历史29×29候选失败（不是当前32×32候选状态）：** H12小块软件捕获后续：6/6暂存通过，但隔离partition输出文件报错、Load进程signal11；无设备ioctl/分配、无START，无真实小块packet。失败归档已取回，根因待定位，不能记厂家支持或板证通过。

## 2026-09-28 H12首层START超时与空间分块静态准备（当前最新）

H12首层3×3/stride2真实厂家392B包已核，双帧CPU及板前定点预期已冻结。独立驱动13文件板端SHA匹配、目标产物生成、默认关闭拒绝/卸载守卫PASS。第0帧实际START一次超时：现场work3/IRQ0、守卫mask0，输出仅部分写入且不匹配；模块/DMA固定，证据已完整取回并请求物理重启。未第1帧或成功释放，根因UNKNOWN。等待期间64空间块halo方案两帧CPU/定点拼接逐字节通过，新厂家包/硬件仍未运行。用户明确等待回复期间继续静态工作、持续START授权，不因等待本身暂停目标。详见 `docs/research/HARDNPU_H12_STEM_TIMEOUT_AND_SPATIAL_PREP_20260928.md`。


## 2026-09-28 H11实际交接及全图覆盖清单（当前最新）

H10两帧真实硬件输出已交给板端CPU尾部，128维float32特征相对电脑预期最大绝对误差2.98e-7/3.58e-7，atol1e-6/rtol1e-5通过，原始归档已在主机复核；不是逐字节一致。全图诊断模型52个Conv（35普通/17depthwise）仅6个普通层有匹配单层板测报告，其余29个普通层尚无匹配报告；不是全图板证。用户明确授权持续START、未回复期间继续静态审查，不因等待回复本身暂停目标。见 `docs/research/HARDNPU_H11_ACTUAL_BOARD_CPU_HANDOFF_20260928.md`。

## 2026-09-28 H10两帧八片真实板证（当前最新）

用户物理重启后同SHA恢复包43/43校验通过；同一H10模块实例和DMA缓冲完成两帧×八片16次START，全部IRQ1/work5、7840B逐字节匹配板前定点预期、逐次释放冷态、最终卸载守卫PASS。两帧各62720B输出SHA `9bae5e7f187b78bfd7bc8987859827c67cefd335544ea21dae70571ff2b452e1`、`06f72a527a5eb827d8ab68e688b162413a38cf6a7b7e57952daedd19d937525c`，原始归档主机复核通过。此前work3启动前拒绝根因仍未知。H11首轮板端CPU尾部逐字节检查未通过，正在量测跨平台浮点误差，尚不记交接成功。见 `docs/research/HARDNPU_H10_EIGHT_SHARD_BOARD_20260928.md`。

## 2026-09-28 H10冷恢复整包准备

串口只读核验uptime27分钟、h10模块引用1，仍未物理冷恢复。新增43文件恢复包，含冻结源码/载荷及已归档同SHA目标模块和用户程序，538502B，SHA `4f372ed1f51c2aedf12de846974aec091edf813fe9da99a8edb10ed9fc597d72`，本地解包逐哈希核验通过。整包传输脚本语法检查通过，但未板端暂存/执行；必须旧私有目录不存在、模块/设备节点不残留、内核匹配才开始，不自动加载或START。下一可用上板动作仍依赖用户物理断电恢复。

## 2026-09-28 H11尾部CPU准备与H10等待恢复

H10模块仍固定、尚未冷恢复；本轮仅查询uptime/模块状态，未START或读取NPU寄存器。UG1215核对work3为MAC，空闲门槛保留。已提取H10输出后的池化/投影CPU尾部，输入62720B UINT8，输出128维float32/512B；完整图原始CPU输入与尾部输出均逐字节一致。两帧H10定点预测输入的尾部预期已封存，明确非硬件输出；没有H11板端运行。见 `docs/research/HARDNPU_H11_CPU_TAIL_PREP_20260928.md`。

## 2026-09-28 H10首次尝试被启动前空闲门槛拒绝（当前最新）

八片904B真实厂家包全部软件核验、CPU完整图对照和两帧定点预期封存完成。独立H10诊断模块目标构建、默认关闭拒绝和卸载守卫PASS；首次武装第0片在软复位后因工作状态3被空闲检查拦下，提交写入0、无START/硬件输出，reason14。模块与DMA固定，原始证据已取回并请求物理断电恢复。原因尚未知，不能记为H10计算失败或通过。见 `docs/research/HARDNPU_H10_PRESTART_REFUSAL_20260928.md`。

## 2026-09-28 H10恢复与第0片软件核验（当前最新）

末尾普通Conv `[1,320,7,7]`→`[1,1280,7,7]` CPU提取及八个160通道分片拼接逐字节通过；厂家完整层软件分给HardNPU并捕获七包，Load/Unload成功，未Execute。中断前第0片捕获完整保存，恢复后已核904B真实包、320→160几何、bias及19225/右移19定点比例。H10仍无真实硬件START；正在恢复冷启动后清空的板端软件捕获环境。旧H9板证保持，完整图与视频仍未完成。

## 2026-09-27 H8 CPU 交接和 H9 五片双帧板证（当前最新）

H7 两帧真实板输出经板端 CPU H8 depthwise 处理，各47040B输出与电脑预期逐字节一致；H8 没有 HardNPU START，厂家支持性未直接核验。H9 第17块后置普通 Conv `[1,960,7,7]`→`[1,320,7,7]` 已取得五片真实厂家 packet；同一诊断模块和 DMA 缓冲完成两帧×五片10次真实 START，10/10 均 IRQ1/work5、3136B原始输出逐字节匹配板前定点预期、成功释放回冷态，卸载守卫 PASS。两帧拼接15680B SHA 分别 `de608dad77b51f111c1455e9da8457cdb81c9ba54d9f15bc3404a13ce3aa7cda`、`c62470b0b65cb9ce04bcedb71029fbb4a7bee496edf93f9cc5d0505386227294`，原始输出归档已由主机核验。批量日志文件名合并，只有首片和每帧末片文本日志归档；串口现场显示全部10次完成行。当前仍为文件交接、诊断驱动，完整图、统一调度、故障排空、视频未完成。见 `docs/research/HARDNPU_H8_DEPTHWISE_HANDOFF_20260927.md`、`docs/research/HARDNPU_H9_POINTWISE_BOARD_20260927.md`。

## 2026-09-27 H7前置1×1 Conv六片双帧板证（当前最新）

第17块`[1,160,7,7]`→`[1,960,7,7]`普通Conv提取模型在原始CPU帧与完整图逐字节一致；隔离厂家软件给完整层三包各320输出通道，但未将这一较大规格提交硬件。六个160通道模型及真实厂家packet已逐片核验，两帧板前定点预期封存。当前板同一诊断模块和同一组DMA缓冲顺序完成两帧×六片12次START，12/12均IRQ1/work5、原始输出逐字节等于预期、逐次释放回冷态，最终卸载守卫PASS。两帧47040B SHA分别 `d5403184e9be22e2f7d54b8f51ea8584b9070d6947820d10e75b8427915dbe60`、`c329b4054ab3dd067f420ba7fdd469fb949fa5095ef428404871cecac8999d4a`，证据已取回主机复核。仍为单层分片诊断、文件交接，完整图/SoftNPU/视频与异常排空未完成。见 `docs/research/HARDNPU_H7_SIX_SHARD_BOARD_20260927.md`。

## 2026-09-27 H5板输出到第16块残差Add双帧CPU交接（当前最新）

两帧H5真实板输出各7840B已在板端私有目录交给提取的残差Add CPU模型；跳连路采用旧完整图CPU捕获。提取模型用完整图原始两路输入时与完整图逐字节一致；替入H5板输出后，两帧板端残差输出与电脑端预期逐字节一致，SHA分别 `28610279511669378e3af56c0abee0ef600fb3d9a0fd87f486b35308c54bd2ee`、`c8b8d9d12bbf63d81f2b582d9396018a483b3acc0668f6b039b21a39faca93a4`。这证明文件式张量交接，跳连尚非硬件全链路，残差未跑NPU。见 `docs/research/HARDNPU_H6_RESIDUAL_HANDOFF_20260927.md`。

## 2026-09-27 H5后置1×1 Conv四段板证（当前最新）

第16块H4硬件输出经H3板端CPU depthwise后的两张47040B真实帧张量，分别在同一已加载H5诊断模块的四块coherent DMA缓冲中顺序完成四个厂家packet的真实START。各帧4/4均8笔写、IRQ1/work5、输出与板前整数定点预期逐字节一致、逐段释放回冷态；两帧拼接7840B SHA分别 `317b88749e37fa2fabcb12bdf678e6d0f5aa49386219e751a3fde858856af121` 与 `b8a5173a075ec7996cccefa48217546205bb9fad8d4c22dabdf5f85a47534a63`。两帧各自的最终卸载守卫PASS，原始证据已取回主机复核。每帧使用独立模块加载实例；H4→H3→H5仍靠文件交接。旧work3超时根因、完整图/SoftNPU/视频仍未完成。见 `docs/research/HARDNPU_H5_POINTWISE_BOARD_20260927.md`。

## 2026-09-27 H4六片共用模块双帧板证（当前最新）

同一已加载诊断模块及同一组四块coherent DMA缓冲，连续处理两张实际测试帧各六片，共12次真实START；12/12均8笔提交、IRQ1/work5、7840B输出与板前定点预期逐字节相同，作业间成功释放回冷态，最终卸载守卫PASS。两帧六片拼接47040B SHA分别 `c5c686a2403ff29abff8f1b5c6edd24bb969eb8998abfb791267dde48c4df3dd` 和 `02e7406bdb7e07b90df8c9b5c1c11acd9b145b94737f27b215d6098e9f7dd1ed`，与此前独立板证一致。随后同一模块五轮重复又完成60次作业，60/60输出与预期逐SHA一致、释放回冷态、最终卸载守卫PASS。该结果仍为H4单层诊断路径，完整空间图、SoftNPU、视频、旧work3超时根因及超时事务排空未完成。见 `docs/research/HARDNPU_H4_MULTISHARD_TWO_FRAME_BOARD_20260927.md`。

## 2026-09-27 H4第0片同模块连续双帧板证（当前最新）

新增可复用诊断模块在**同一加载实例及同一组coherent DMA缓冲**内依次接收第一帧和第二张实际测试帧的7840B H4输入；两次START均8笔写、IRQ1/work5，原始输出各与板前packet整数定点预期逐字节相同，每次成功释放后回到冷态，最终卸载守卫PASS。默认关闭RUN拒绝且没有START。两帧输出SHA依次 `2b2381bfd79790c79a4620b309cd565daa3a539fd0a656e84a20d2c84728a430`、`f0788a0abc8ba5cc88c352435be12996a74602f3edcfc7e75ba5d86c65b152b7`。这是第0片的同实例双帧证据，六片统一驱动、完整图、SoftNPU、视频、旧work3超时根因仍未完成。见 `docs/research/HARDNPU_H4_REUSE_TWO_FRAME_BOARD_20260927.md`。

## 2026-09-27 H4变化输入与第二张真实帧完整层板证（当前最新）

沿用六片真实904B厂家packet与权重，确定性7×7循环平移输入的六片硬件输出均逐字节等于独立定点预期；拼接47040B SHA `223a54c7a66d9fceeffe59a8e7e1079a0ca59dc98be661ead5bc3a0e595bcb9d`，与原完整层输出作相同空间平移一致。第二张实际测试帧从旧量化完整图捕获本层输入，完整图本层输出与提取单层ONNX CPU一致，独立浮点参考另有1字节差异并明确记录；六片真实板端START均IRQ1/work5，输出拼接47040B SHA `02e7406bdb7e07b90df8c9b5c1c11acd9b145b94737f27b215d6098e9f7dd1ed`，与运行前整数定点预期零差，相对ONNX CPU有8875字节各低1。各片输出取回后释放/卸载。仍为特化一次性模块和离线拼接，真实work3超时根因、完整图量化质量、SoftNPU与视频未通过。见 `docs/research/HARDNPU_H4_DYNAMIC_INPUT_BOARD_20260927.md`。

## 2026-09-27 H4 六片完整层一次连续板证（当前最新）

六个160通道真实厂家软件包均由当前板隔离捕获并逐片验证。板端六片分别冷启动的一次性作业均返回IRQ1/work5、7840B原始输出与预封存定点结果逐字节一致，输出拼接47040B与原完整960通道层三包定点预期零差异。另在同一上电周期完成第5片后，顺序运行第0～5片六次，再运行两轮0～5共12次；这18次均完成、输出一致、成功释放/卸载，完整层拼接SHA `c5c686a2403ff29abff8f1b5c6edd24bb969eb8998abfb791267dde48c4df3dd`。首次两轮脚本因旧输出文件名冲突停下，设备本身已完成，重新导出、核验与释放成功；修正后12次日志和原始输出均取回。此前同周期0→1确曾超时于work3并有部分正确输出，故长期稳定性和真正超时后的事务排空仍 `UNKNOWN`。该结果是冻结单层/输入、诊断模块及软件拼接的有限板证，不是完整量化图、SoftNPU、视频或系统验收。见 `docs/research/HARDNPU_H4_160_SHARD_BOARD_20260927.md`。

## 2026-09-27 H4六片packet核验器静态贯通（当前最新）

六片CPU清单已接入未来厂家包核验器：按冻结清单SHA和编号逐片绑定模型/权重/bias、13项包、几何与定点输出，第0片旧用法保留。只在临时目录构造六份合成160通道包并用真实核验器逐片处理，六份7840B定点结果拼接后与原3×320包封存的47040B定点预期逐字节一致；错误分片身份被拒绝，结果 `H4_SIX_SHARD_FULL_SELFTEST_PASS_SYNTHETIC_ONLY`。合成包并非厂家输出，六片真实包/硬件仍未验收；用户回来前不做START。见 `docs/research/HARDNPU_H4_SIX_SHARD_CPU_20260927.md`。

## 2026-09-27 H4完整960通道的六分片CPU金样（当前最新）

沿用冻结真实H4单层模型及板载荷权重/bias，离线生成6个连续的160输出通道QDQ模型。每片ONNX checker、shape inference和CPU运行通过，7840B输出各与原960通道CPU金样对应区间逐字节一致；六片拼接47040B与原输出完全相同，SHA `fdc9f23f1da19c32a28ee27f67047854794e6d809905dd70c58fee21e95576ea`。第0片模型SHA与先前缩界夹具相同；源模型/输入/权重/bias/输出身份逐SHA锁定。只接受为`H4_SIX_SHARD_CPU_GOLDEN_PASS_LIMITED`，**六片厂家packet、硬件输出及整层板证仍未取得**。用户回来前不做START。见 `docs/research/HARDNPU_H4_SIX_SHARD_CPU_20260927.md`。

## 2026-09-27 H4 160通道核验器端到端合成自检（当前最新）

仅本地用旧H4包构造临时226字合成包，完整跑通派生模型SHA、包13项、量化几何、偏置、定点输出与报告检查；合成定点7840B与旧比例候选逐字节一致。自检发现CRLF日志原会被仅LF的解析规则拒绝，现已修正并以显式CRLF样本复验 `H4R_FULL_SELFTEST_PASS_SYNTHETIC_ONLY`，临时包自动清理。测试中的厂家成功标记由自检合成，**仍没有160通道真实厂家packet、目标编译/板测或START**。用户回来前继续只做静态工作。见 `docs/research/HARDNPU_H4_REDUCED160_STATIC_DIAGNOSTIC_20260927.md`。

## 2026-09-27 H4 写回几何静态交叉核验（当前最新）

UG1215与冻结厂家包对照确认：旧H4三段每包 `filter_OC=320`、整层 `Out_fm_size.C=960`、本段 `Output_data_size=15680`；三者描述不同层级，不能混作同一通道数。160通道派生模型核验器现独立要求1×1/stride1、`Out_fm_size=(160,7,7)`、平面49、输出7840B，并继续核输入/权重零点与tile周期关系。合成正例及旧整层960通道误入的新反例均通过自检，仍没有厂家新包。回读旧超时驱动和板端日志：10秒时 `integrity=0` 对应第0包之后输出缓冲A5守卫未检测到写入；不能推出事务已排空。用户回来前仍不做 START。见 `docs/research/HARDNPU_H4_REDUCED160_STATIC_DIAGNOSTIC_20260927.md` 和 `docs/research/HARDNPU_H4_TILE0_TIMEOUT_BOARD_20260927.md`。

## 2026-09-27 H4 160通道软件捕获静态加固（当前最新）

用户要求回来通知前只做静态改动、不做 START。本轮修正隔离监督器的命令包识别：在有界同步缓冲中按冻结厂家包头 `0xff00000f/0x63f00004` 判别，不再依赖CMA分配序号；未来新包仍由13项核验器逐项检查。核验器补查 `0x3000/0x4000` 输入/权重零点133/129，并核 `0x3004 = 0x0054 × 0x0008` 的手册周期关系；输出通道仍由 `Filter_size.filter_OC` 检查。上一轮把 `0x3004` 误认作输出通道并要求160，已根据UG1215及H2/H4冻结包修正。旧包头及合成解析正反自检通过。**源码未传板、未目标编译/运行，160通道厂家packet、硬件START和输出均未取得**。见 `docs/research/HARDNPU_H4_REDUCED160_STATIC_DIAGNOSTIC_20260927.md`。

## 2026-09-27 H4 160通道静态缩界夹具与用户测试边界（当前最新）

用户要求先做静态改动，回来通知前不做 START 测试。已从冻结H4真实层权重/bias截取前160输出通道，生成独立 QDQ 单层模型；ONNX checker/shape inference、CPU运行通过，7840B输出与原960通道CPU输出前160通道逐字节一致。最终模型 SHA `3af6c772fc3e3d41ac5c62586ef57f97b178926000107f83e5659ca34dba5a31`。厂家新packet、硬件运行均未做；旧320通道包的超时不能凭该CPU结果归因于通道容量。见 `docs/research/HARDNPU_H4_REDUCED160_STATIC_DIAGNOSTIC_20260927.md`。

## 2026-09-27 H4 第 0 段真实 START 三次超时与部分输出（当前最新）

承接三包软件捕获及无 START 板证，当前板 Linux `6.1.111-rt42` 对 H4 第0包（320输出通道、1544B packet）先后执行三次受控单次 START，中间均由用户物理断电恢复。三次均尝试8笔提交写入，未得到完成IRQ或 `work=5`；延长至10秒的两次现场均为 `work=3`（UG1215 `do mac`）、`irq=0`、IRQ31计数0、输出CRC32 `0xe9e7b6fb`。第三次取回两份间隔2秒的15680B原始缓冲，SHA相同；11030个已改变字节与预封存定点金样同地址完全一致，其余尚不匹配，**不是完整输出通过**。错误/输出计数五寄存器读值0，不能排除其它故障。每次超时模块与DMA缓冲固定直至物理冷恢复；第三次恢复后核验模块0且私有`/run`目录已清。当前状态 `H4_TILE0_STARTED_TIMEOUT_PARTIAL_OUTPUT/RECOVERED_BY_COLD_POWER`，第1/2包未执行、H4层未通过。见 `docs/research/HARDNPU_H4_TILE0_TIMEOUT_BOARD_20260927.md`。

## 2026-09-27 H4 冻结载荷无 START 板测（当前最新）

最终 H4 独立模块在当前板真实 coherent DMA 缓冲中逐 SHA 对应装入7840B输入、153600B权重和三段各1544B厂家软件packet；两次正向装载/卸载成功，分段内容及尾部守卫 `PASS`。板端私有权重首字节受控改变后，`insmod` 返回 `Bad message`、探针 `-74` 且模块不残留；恢复冻结权重 SHA 后再次正向通过。最终模块0、真实NPU/CMA节点不存在。源码/载荷逐 SHA 传入新 `/run`，最终模块和构建日志已取回；`Module.symvers`缺失/时钟偏差仍限制内核源码同一性。仅 `H4_PAYLOAD_STAGE_BOARD_PASS_LIMITED`：没有MMIO、IRQ、START、设备DMA访问或硬件输出。见 `docs/research/HARDNPU_H4_PAYLOAD_STAGE_BOARD_20260927.md`。

## 2026-09-27 H4 三段四缓冲无 START 板测（当前最新）

依据同 SHA 厂家库静态地址计划，H4 独立诊断模块在当前板 Linux `6.1.111-rt42` 分配 packet/input/weight/output 四块 coherent DMA 缓冲 16384/8192/155648/49152B，基址为 `0x17c6c000/0x17c70000/0x17cc0000/0x17ca0000`；三段派生地址全部落在各自32位分配范围，装载/卸载返回0，四块守卫 `PASS`，最终模块0、真实设备节点不存在。板端源码逐 SHA 传入新私有 `/run`、目标构建、日志取回并同 SHA；`Module.symvers`缺失及板端时钟偏差仍限制内核源码同一性。仅 `H4_ALLOC_ONLY_BOARD_PASS_LIMITED`：没有装填输入/权重/packet、MMIO、IRQ、START或输出。见 `docs/research/HARDNPU_H4_ALLOC_ONLY_BOARD_20260927.md`。

## 2026-09-27 H4 厂家三段提交静态审计（当前最新）

同 SHA 冻结 `libarmnn.so.32.1` 的 `Split`、`r_HardNPUDriver`、`Execute` 反汇编与此前三段真实模型软件 packet 已核对。静态路径显示装载时填每段 packet/权重物理地址，执行时填输入/输出地址，逐段提交并逐段等待 IRQ。对本夹具推导 packet 偏移 0/1544/3088 B、权重偏移 0/51200/102400 B、输出偏移 0/15680/31360 B，输入偏移全为0；合计覆盖源153600B权重和47040B输出。审计脚本同哈希/关键指令/载荷核验通过，证据类别 `SAME_HASH_STATIC_ELF_AND_CAPTURE_INFERRED_H4_PLAN`。这不是厂家 `Execute` 动态捕获，也没有 H4 真实缓冲/START/输出；运行时分支、控制字、偏移地址对齐接受性和异常回收仍 `UNKNOWN`。见 `docs/research/HARDNPU_H4_VENDOR_SUBMIT_STATIC_AUDIT_20260927.md`。

## 2026-09-27 H4 大通道普通Conv三段厂家packet（当前最新）

第16块前置普通1×1 Conv 的PC夹具 `[1,160,7,7]`→`[1,960,7,7]` 已由完整图、截取单层和独立NumPy逐字节核对；47040B CPU输出正好等于H3 depthwise输入。当前板隔离厂家parser/Optimize将唯一计算层分给`ALHardNPU/Alnpu`，`LoadNetwork/UnloadNetwork`通过且未调用Execute。虚拟CMA捕获三段各1544B/386字packet，三段各含320个bias字，合计与源960个bias逐字节相同；153600B权重也与源模型逐SHA一致。packet乘数22461/右移20所预测的47040B定点输出SHA `c5c686a2403ff29abff8f1b5c6edd24bb969eb8998abfb791267dde48c4df3dd`，相对ONNX CPU有8877B各低1。**无H4真实START/输出**；三段动态权重/输出地址、提交顺序和失败回收未闭合，不能照搬H2单段驱动。见`docs/research/HARDNPU_H4_LARGE_CONV_VENDOR_PACKET_20260927.md`。


## 2026-09-27 H3 depthwise CPU 金样与厂家 Hard 后端边界（历史阶段）

历史UINT8空间图第16块3×3/group960 depthwise层已建立真实帧单层CPU夹具：`[1,960,7,7]` UINT8输入/输出各47040B，完整图同节点、截取模型与独立NumPy输出逐字节一致。隔离板端厂家 parser 提取的8640B权重和3840B bias与PC夹具逐SHA一致；但冻结 Arm NN 优化器明确报告该 `DepthwiseConvolution2d` 的QAsymmU8输入/输出**不受仅请求的 `Alnpu` 后端支持**，无法分配后端。没有packet、真实DMA、START或硬件输出；不为此层强行执行HardNPU。该结论仅针对当前库/量化几何，不外推其它后端或所有depthwise。下一步调查CPU/Soft归属，HardNPU继续选受支持普通Conv扩面。见 `docs/research/HARDNPU_H3_DEPTHWISE_CPU_AND_VENDOR_BOUNDARY_20260927.md`。

## 2026-09-27 H2 第二种真实空间 Conv 单次上板通过（历史阶段）

 当前板 Linux `6.1.111-rt42` 上，独立 H2 一次性诊断模块对 `[1,144,28,28]`→`[1,32,28,28]` 普通 1×1 Conv 执行一次真实 START，8笔写、完成 IRQ1/work5、25088B 原始输出 CRC32 `0xa2c9574d`。板端输出已取回，SHA-256 `42b4f0142c2d20ec287dd3b93afe66beda9b06ea350afca30a4b3d4f50ded9ad`，与事先独立计算的 packet 定点预期逐字节一致；相对 ONNX CPU 金样有12458B各低1，符合预期的截断差异。输出保存并核对后，显式成功释放、`rmmod` 和守卫检查通过，最终模块0、节点消失。此前一次候选在 START 前因 `work=3` 被拒绝，0笔写且保留缓冲，用户物理重启；冷态 NPU `/dev/mem` 只读探针另触发自动复位，已停用该探针。结果仅 `H2_ONE_LAYER_BOARD_PASS_LIMITED`：完整量化图、异常排空、共享DDR隔离、厂家真实 Execute、SoftNPU/视频均未通过。见 `docs/research/HARDNPU_H2_FIRST_START_BOARD_20260927.md`。

同轮只读审查历史UINT8图（SHA `50e645e5c6de7c3099d021298a073d28f3699899546fac764c1e13c749cc2956`）中第16块 depthwise Conv `/backbone/backbone.16/conv/conv.1/conv.1.0/Conv`：输入/输出各 `[1,960,7,7]` UINT8，权重 `[960,1,3,3]` UINT8 8640B，bias 960 个 INT32，group960、3×3、pad1、stride1，QDQ包围该算子。该层目前只为下一扩面候选的静态证据；尚无单层CPU夹具、厂家后端/packet或板端运行，不标为 `DOING`。

## 2026-09-27 H2 固定载荷无 START 板测（历史阶段）

在四缓冲分配通过后，H2 独立模块已于当前板私有 `/run` 将封存112896B输入和4608B权重装入 coherent DMA 缓冲，核长度、内容及尾部守卫；成功装卸均返回0、`guard=PASS`、最终模块0。受控改动权重首字节后，修正的模块初始化把 probe `-EBADMSG` 转为装载失败，模块不残留，恢复原文件后再通过。最终模块 SHA `7ae97416d71d4d1dd0ed8f3139c602c10ad4843ec7c6b34fa786a393f50d2912`，正反原始记录与构建日志已按板端 SHA 取回。**没有 MMIO、IRQ、START、NPU访问或 H2 输出**；完整空间量化图仍拒绝部署。见 `docs/research/HARDNPU_H2_PAYLOAD_STAGE_BOARD_20260927.md`。

## 2026-09-27 H2 四缓冲无 START 板测（历史阶段）

H2 独立诊断模块已在当前板 Linux `6.1.111-rt42` 的私有 `/run` 中目标构建并装卸。四块 coherent DMA 分配为 packet `0x17c6c000/16384`、input `0x17ca0000/114688`、weight `0x17c70000/8192`、output `0x17c78000/28672`；地址计划验证通过，卸载时冻结 packet 与 A5 守卫检查 `PASS`，`insmod/rmmod` 均返回0，模块最终不在列表。模块没有 MMIO、IRQ、用户入口或 START；未装填 H2 输入/权重、未取得硬件输出。原始板端记录和构建日志已按 SHA 取回，见 `docs/research/HARDNPU_H2_ALLOC_ONLY_BOARD_20260927.md`。构建树缺 `Module.symvers` 且时钟偏差，故源码与当前 Image 的精确同一性仍 `UNKNOWN`；成功装卸仅证明本次有限运行。

## 2026-09-27 H2 四缓冲主机合同（独立历史代码分支）

已依据 H2 392B packet 和112896/4608/25088B输入/权重/输出建立独立四缓冲地址计划，分配尺寸为16384/114688/8192/28672B；主机 mock 回调核对8笔寄存器写顺序、8个失败截点和8种非法计划，严格GCC编译运行通过。C packet 98字还原SHA与厂家捕获完全一致。**H2 内核激活分支当前固定拒绝并记0笔写**；后续无 START 板测已验证真实 coherent DMA 分配/卸载，未验证NPU访问或输出。详见 `docs/research/HARDNPU_H2_HOST_DMA_CONTRACT_20260927.md` 和上节。


## 2026-09-27 H2 模拟设备厂家软件分区与 packet（历史阶段）

H2 第二种普通 1×1 Conv 已在当前板 Linux `6.1.111-rt42` 的私有 `/run`、设备隔离环境中完成厂家 parser→Optimize→runtime→LoadNetwork→UnloadNetwork；优化图唯一计算层为 `ALHardNPU`、冻结库私有 ABI 后端为 `Alnpu`，输入/输出112896/25088B。厂家同步前捕获392B/98字packet，电脑独立核对13条寄存器项、权重和bias与源模型逐字相同，packet SHA `e79c1f8adb3712dcd26fbadee21d6586fc7bbef552e000d13c5421f1a1544b40`。按H1已板证的定点形式，H2预测输出相对ONNX CPU金样25088B中12458B各低1；该预测尚未获H2板证。探针明确未调用Execute，真实NPU设备节点不存在、模块表空，**H2 START/真实输出均未执行**。源完整量化图仍拒绝部署；下一步为H2独立物理缓冲/地址与异常生命周期审计后受控上板。详见 `docs/research/HARDNPU_H2_VIRTUAL_PACKET_20260927.md`。


## 2026-09-27 H2 第二种真实空间层 PC 金样（历史阶段）

已从历史 UINT8 空间量化图选取与 H1 不同尺寸的普通 1×1 Conv：`[1,144,28,28]`→`[1,32,28,28]`。源测试帧经权威 Pillow 预处理，完整图本层截取、提取单层 ONNX Runtime 和独立 NumPy 参考逐字节一致；单层 ONNX SHA `11d5f692f835c71df8f29ea9079503a044e15f5cee371f8387fce656a6c5e66e`，输入/输出 112896/25088 字节。此阶段仅 `CPU_GOLDEN_PASS_LIMITED`；同日后续厂家软件链/packet结果见上节。源量化图仍为旧 OpenCV 校准且不满足完整模型部署门槛，H2 实际 START、通用缓冲生命周期均未验证。用户确认板卡物理重启，不把冷恢复写成 H2 上板通过。详见 `docs/research/HARDNPU_H2_CPU_FIXTURE_20260927.md`。


## 2026-09-27 Pillow量化图历史测试片段回放（最新）

对训练报告绑定的12段v2测试片段，每段按原规则抽16帧，共192帧，文件哈希与48张PTQ校准图无交集。原空间FP32与BN折叠图最大差`9.54e-7`、词类预测12/12一致。Pillow输入下旧OpenCV校准QDQ与新Pillow校准QDQ的空间特征平均cosine为0.626333/0.645798，最低0.298546/0.381569；接同一原FP32时序头后Top-1均0.75，Macro-F1由0.750361变为0.738889，新图仍拒绝部署。两次完整回放JSON逐字相同。源测试split的真实表演者身份未知、动作窗口是弱标签，因此不是受试者独立产品验收。未触发NPU START；详见 `docs/research/HARDNPU_SPATIAL_PREPROCESS_QUANT_CONTROL_20260927.md`。

## 2026-09-27 空间模型预处理合同对PTQ的影响（最新）

9月19日完整空间图PTQ脚本用OpenCV直接缩放，9月24日训练/回放合同已冻结为Pillow RGB双线性缩放；同48张PNG在两路预处理下有1,354,289/7,225,344个输入元素不同，同一FP32空间模型输出特征平均cosine仅0.817348。仅把校准改为权威Pillow函数、保留同12个bias越界层排除及其余量化选项，Pillow输入下旧/新QDQ相对FP32的平均cosine为0.623785/0.652155，仍拒绝部署。H1另有OpenCV letterbox/RGB/除255的诊断预处理，原证据本来不等同训练/回放合同。新图只通过PC checker/CPU，未做厂家parser/后端、板端或词级验证。见 `docs/research/HARDNPU_SPATIAL_PREPROCESS_QUANT_CONTROL_20260927.md`。

## 2026-09-27 第16块depthwise量化敏感点（最新 PC 诊断）

48张原校准图的残差支路对照显示，第16块相加前旁路平均cosine约0.738、卷积分支约0.509。第15～18块15个激活量化点最高INT8 rail命中约0.107%；末端Clip的约91%零值在FP32图也存在，不能直接归因于饱和。以既有无bias越界基线平均cosine0.632070为起点，只让第16块group960、3×3 depthwise卷积保留浮点得到0.678313；该块另外两个1×1卷积单独留浮点分别仅0.635184/0.635492。追加局部审计显示该depthwise权重量化整体cosine约0.999993，而其输入已只有0.895594；不能把权重误差直接判为根因。基线/候选408个共同initializer逐值相同。此为本校准集合的定向敏感性，不是全图修复；所有候选仍拒绝部署，未验独立动作、厂家后端或板端。9月26日23:00自主START窗口已结束，本轮无新板端START。见 `docs/research/HARDNPU_SPATIAL_QUANT_BOUNDARY_AUDIT_20260926.md` 追加节。

## 2026-09-26 完整空间图量化边界定位（最新 PC 诊断）

复用 Astra/Sol 已封存的 FP32 折叠图、无 bias 越界 QDQ 基线和同48张校准图，对46个同名 Add/Clip 边界逐帧比较：残差块3/10/13/15/16 Add 的平均 cosine 约0.954/0.853/0.782/0.738/0.671，末端块18 Clip 约0.454，表明误差沿整链累积。只把块18一个Conv留浮点，整网平均0.632070→0.632178；把块15+16新增四个Conv留浮点，提高到0.678150，仍拒绝部署。两份候选均通过ONNX full checker且无bias越界cast警告，但48帧同时用于校准/对照，独立动作准确率、厂家后端及板端执行均未验证。用户已确认物理重启；本段仅PC实验，无新START。详见 `docs/research/HARDNPU_SPATIAL_QUANT_BOUNDARY_AUDIT_20260926.md`。

## 2026-09-26 从H1扩展到完整空间模型的现有阻点

复读 Astra/Sol 交接后确认，完整空间模型已有V6/V7量化parser修正候选、混合图有限解析成功；但旧UINT8/INT8量化候选存在bias量化INT32越界，代表性48帧的部分修正版与FP32余弦约0.63，历史记录明确拒绝部署。H1原图像中间张量的单层定点执行通过**不能修复整网量化质量**。下一主线先在隔离模型副本做完整图的数值修复和逐层后端归属，再扩展不同Hard算子/参数及Soft协同；不重跑已解的V5/V6/V7 parser矩阵。见 `SOFTNPU_ASTRA_HANDOFF_20260919.md` 最新交接G/H。

## 2026-09-26 HardNPU 总体覆盖边界

当前真实硬件结果集中于**产品空间网络派生的一层**1×1 UINT8 Conv。该原输入来自一张校准图的真实中间张量；两种XOR变体、十次交替及两帧串联证明固定packet/权重的输入变化与成功重复运行。产品空间ONNX历史静态审计有52个Conv（35普通、17 depthwise）、10 Add和35 Clip，且完整量化图的真实后端归属/运行仍未闭合；不能把单层板证写成完整空间模型或HardNPU子系统完成。下一硬件增量须转向新层/新量化参数及真实模型链，避免重复同一H1样本。见 `docs/research/SOFTNPU_G4B_ONNX_PARSE_STAGE_V2_BOARD_20260918.md` 和本轮H1报告。

## 2026-09-26 H1 双帧板端动态串联（当前最新）

同一冻结Conv模型下，板端脚本对两份输入逐帧现场生成CPU定点预期、在START前绑定、运行HardNPU、逐字节比对并成功释放；两帧均通过，最终模块0。两个短样本分别约61.8/62.1ms（包含CPU预期），整段约137.7ms。此为受控诊断路径，不是相机/SoftNPU/视频整链或持续帧率验证；共享DDR隔离和故障排空仍开放。见 `docs/research/HARDNPU_H1_DYNAMIC_TWO_FRAME_BOARD_20260926.md`。

## 2026-09-26 H1 十次连续作业（当前最新）

最终收紧驱动同一装载实例下，XOR55/XORAA两种输入交替完成十次真实START、逐字节输出比较和每次成功释放，10/10通过；原始结果/日志已取回并在电脑端独立核对，最终模块0、设备节点消失。板端十次作业段总耗时约369ms，**不含**逐帧CPU预期计算、装卸模块、相机或显示。成功路径短时重复性获板证；故障/超时后排空、共享DDR隔离和长时视频仍开放。见 `docs/research/HARDNPU_H1_TEN_JOB_REPEAT_BOARD_20260926.md`。

## 2026-09-26 H1 板端CPU预期生成接受控硬件（当前最新）

板端新纯CPU程序用冻结packet/权重对XOR55及XORAA两份输入分别生成12544B定点预期，均与电脑预期逐字节一致，两个样本的计算时间约15.30/15.49毫秒。随后把板端生成的XOR55预期在START前绑定，最终收紧版驱动实跑得到完全相同输出，成功释放、卸载且模块0/设备节点消失。这消除了本实验中逐输入从电脑拷贝预期的依赖；未测持续帧率、端到端延迟、真实厂家Execute、共享DDR隔离或故障排空。见 `docs/research/HARDNPU_H1_GENERIC_INPUT_ORACLE_BOARD_20260926.md`。

## 2026-09-26 H1 自定义输入同实例连续板测（当前最新）

固定1×1 Conv packet/权重下，新增运行前绑定输入CRC与独立计算的输出CRC的受控诊断接口；默认装载时该接口被拒绝且未START。两种新输入（原输入分别XOR `0x55`/`0xaa`）的12544B实际输出与事先生成的packet定点预期分别逐字节相同；同一模块实例先后执行两种新输入、每次成功释放，最后模块卸载、模块0、节点消失。收紧后的**最终源码**还要求冻结权重、未知输入必须预先绑定；该源码目标构建后再对XORAA做一次实际运行与成功释放，输出一致。源码拒绝分支未以故意漏绑定的武装START上板触发，不能记为板测通过。仍缺异常AXI排空、共享DDR隔离、厂家真实Execute、其它权重/shape/算子、持续帧率及模型准确率。见 `docs/research/HARDNPU_H1_GENERIC_INPUT_ORACLE_BOARD_20260926.md`。

## 2026-09-26 H1 模型到板端输出证据桥接

复用已完成的 Sol/Astra 冻结模型身份和模拟 CMA `LoadNetwork` packet 逐字匹配结果，本次对捕获的520B packet及已取得的Linux板端原输入输出重新做独立哈希/字节核对，得到 `ONE_HARD_LAYER_PACKET_FIXED_BOARD_EXACT`：优化图唯一 `ALHardNPU` 层、厂家130字 packet 与板端输出可追溯，板端12544B与事先计算的定点预期0差。`LoadNetwork` 是虚拟设备实验、实际START是独立驱动实验，此桥接不等于厂家真实 `Execute` 全链运行；原CPU/ONNX金样差异和共享DDR边界仍开放。见 `docs/research/HARDNPU_H1_MODEL_TO_BOARD_BRIDGE_20260926.md`。

## 2026-09-26 H1 Linux 同实例两种输入连续上板运行（当前状态）

在用户授权的当晚板测窗口，当前板 Linux `6.1.111-rt42` 上同一 H1 模块实例先执行变体输入、成功释放，再执行原输入、成功释放，最后 `rmmod` 成功、模块数0且设备节点消失。两次均为8笔写、IRQ1/work5、完整性0；12544B原始输出分别与**事先独立生成**的当前packet定点预期逐字节相同，SHA-256分别为`c77274321727994c5cf2f582523c4d3ad49bcc42499d33f8a2226565f5cb8cb4`与`d508fcd898b10c7b4dac298213ee863747053ae0fb8027b2380b2e5d83196322`。此前同实例原输入重复两次也通过。成功释放接口只接受两组已核对的输入/权重/输出CRC；错误或超时仍固定缓冲。此为冻结1×1卷积packet与权重的**受控诊断**，装载时需显式开启默认关闭的DDRS1-disabled诊断参数；没有共享DDR地址隔离、异常AXI排空、其它权重/shape/算子、模型精度或Arm NN/SoftNPU/视频联合运行证据。原CPU金样相对原输入硬件输出仍有6267字节各差1。见 `docs/research/HARDNPU_H1_LINUX_REPEAT_TWO_BOARD_20260926.md` 和 `docs/research/HARDNPU_H1_LINUX_VARIANT_AND_MIXED_BOARD_20260926.md`。下方历史“RUN_ONCE固定拒绝/未START”章节仅描述当时版本，不代表当前受控诊断路径。

## 2026-09-26 H1 Linux 双层输出验收

板端纯用户态验证程序新增 `--compare-fixed`/`--execute-fixed`，分别报告冻结 packet 定点预期和原 CPU/ONNX 金样，固定模式退出码只由定点预期决定。目标板严格编译通过；已有真实输出重放为定点差异0/12544、CPU差异6267/12544，修改1字节后定点门槛返回失败。没有加载模块或执行新 START；`--execute-fixed` 尚未板端运行，Linux驱动DDR S1门槛仍固定拒绝。见 `docs/research/HARDNPU_H1_LINUX_DUAL_ORACLE_VERIFIER_20260926.md`。

## 2026-09-26 H1 Linux 激活前门槛源码修正

隔离Linux候选已修正TOP_ENABLE直接写3的问题：现在读原值并按位或3；软复位后不清未知IRQ，连续16次工作idle且最终IRQ0才继续。板端私有构建返回0，反汇编确认目标`read/orr/str`和IRQ/idle门槛。`Module.symvers`缺失及modpost未解析符号仍限制可装载性判断；模块未加载、未调用RUN_ONCE、新START数0。DDR S1 live policy仍固定拒绝，完整Linux运行和可重复推理未放行。见 `docs/research/HARDNPU_H1_LINUX_ACTIVATION_ALIGNMENT_20260926.md`。

## 2026-09-26 H1 独立定点预期

新增只读源数据生成工具，从冻结input/weight/bias及packet的`Uint_scale`生成12544B定点预期，生成阶段不读取板端输出；随后对比首次板测原始输出全长0差，SHA均`d508fcd898b10c7b4dac298213ee863747053ae0fb8027b2380b2e5d83196322`。与原CPU/ONNX金样仍有6267点各低1，模型语义验收保持未通过。Linux驱动`RUN_ONCE`当前固定拒绝，不能直接用其替代U-Boot成功路径；无新的板端START。见 `docs/research/HARDNPU_H1_PACKET_FIXED_ORACLE_20260926.md`。

## 2026-09-26 H1 首次真实 START：定点包吻合，原 CPU 金样未通过

用户明确授权后，在 U-Boot 独占阶段仅执行一次 `go`/START。U 盘新 `H1ARM1.BIN` 与冻结6248B候选SHA匹配，input/weight/程序三段 `fatload` 长度及 U-Boot 内存CRC与电脑端一致。报告 IRQ=`1`、work=`5`、status=`34`，packet130/130及守卫均通过；原始12544B输出CRC与板端报告一致。对原CPU金样6267字节各低1、6277相同，严格金样验收失败。离线以冻结packet `Uint_scale=0x00611118` 的定点乘数24849/右移24及冻结 input/weight/bias 重算，**12544/12544字节与硬件完全一致**。因此单作业 HardNPU/packet 定点执行获得板证，但原ONNX/CPU最近整数语义不一致，不能写成完整HardNPU或系统完成。没有第二次START；用户确认现场断电上电，COM4复核已恢复Linux`6.1.111-rt42`、模块0、U盘未挂载。详见 `docs/research/HARDNPU_H1_FIRST_START_BOARD_20260926.md`。

## 2026-09-26 H1 武装产物静态复核与输出抓取准备

在首次START许可待答期间，只读核对6248B武装BIN仍为已冻结SHA，目标ELF反汇编确认八笔偏移/值双表、最后一笔START前空闲门槛及实际MMIO写指令。找到并哈希核对原始12544B CPU金样；新增只读U-Boot输出抓取/逐字节比较脚本，确认报告IRQ/work的结构偏移和当前板`md.b`每行16字节格式。脚本尚未对真实输出运行；本轮没有START。见 `docs/research/HARDNPU_H1_ARMED_STATIC_AND_OUTPUT_CAPTURE_20260926.md`。

## 2026-09-26 H1 当前板卡只读就绪核验

COM4 直接响应；板端内核`6.1.111-rt42`，`lsmod`只有表头（0个已加载模块），`/dev/sda1` 57.7G 可见且未挂载。仅执行只读状态命令，没有进入U-Boot、挂载U盘、放武装BIN或执行START。首次单次START仍待用户明确放行。

## 2026-09-26 H1 输出抓取全长模拟

冻结CPU金样已转换为784行U-Boot风格输出并按脚本同一解析逻辑还原，12544字节哈希完全一致；人为地址断裂、截断末行均被门禁识别。武装源码/BIN哈希仍与冻结值相同，未触发START。该模拟不证明真实串口和NPU输出；首次START许可仍待用户明确回复。见 `docs/research/HARDNPU_H1_ARMED_STATIC_AND_OUTPUT_CAPTURE_20260926.md`。

## 2026-09-26 H1 完成状态与排空边界复核

本地 UG1215 直接定义 HardNPU `work=5` 和 `IRQ bit0=1` 为作业完成；寄存器软复位仅描述复位寄存器状态，CRP NPU 复位亦未给出在途 AXI 排空保证。XMON 所查计数/错误寄存器不是 outstanding=0 证明。H1 首算维持 U-Boot 单次隔离路径，异常后不重试、不启动 Linux、不复用缓冲，物理断电恢复；Linux 可重复驱动的故障排空仍 `UNKNOWN`。没有渠道取得原厂解释时，先用现有手册和板测完成首算，不将推断写成保障。本轮未执行 START。见 `docs/research/HARDNPU_H1_AXIDRAIN_EVIDENCE_AUDIT_20260926.md`。

## 2026-09-26 H1 四页映射与完整无 START 预检

八笔 H1 CPU 寄存器计划所需页0/1/2/6在当前 U-Boot 的EL3临时映射往返板测通过，撤销后L2表项0。整合首版软复位后即时读到工作状态2，按门槛退出、未写packet/START；同轮第二次`go`出现指令字`0xa5a5a5a5`同步异常并自动复位，原因UNKNOWN，后续每轮U-Boot只运行一个程序。修订 TOP_ENABLE 为保留原值按位或3并有界等连续空闲；新启动下冻结输入CRC/packet/八笔记录、四页映射、软复位与恢复整体无START预检status8通过，Linux/DDR S1基线恢复。最终武装候选目标编译、静态检查并取回隔离工作树，**未放U盘、未执行START**。见 `docs/research/HARDNPU_H1_FOUR_PAGE_MAPPED_PREFLIGHT_20260926.md`。首算仍`NO-GO`，首次真实START需当时明确许可。

## 2026-09-26 H1 U-Boot NPU 控制寄存器与软复位无启动板测

复用已验证的两页EL3临时映射，当前板一次只读NPU工作/IRQ均0、TOP时钟/SRAM与页表恢复；另一次仅软复位写`0x63f00000=1`，复位位首次轮询即自清，前后工作/IRQ仍0、CRP_RESET=`0x73f0`、TOP与页表恢复，两个程序U-Boot`go`均返回0。软复位异常的CPU映射原因得到正向对照。没有packet写或START，尚无NPU DMA/算子/排空证据；Hard首算继续`NO-GO`。详见 `docs/research/HARDNPU_H1_UBOOT_MMIO_READ_RESET_BOARD_20260926.md`。

## 2026-09-26 H1 U-Boot NPU MMIO 页表故障定位

隔离首算准备程序的无启动变体已完成一次 U-Boot CPU-only 检查；激活专用变体在首次写 `0x63f00000` 软复位时发生同步异常并由固件自动复位，**未写 packet 或 START**。随后 EL3 探针实测 NPU 两向 `PAR_EL1=0x80d`（翻译失败、状态6），TOP/DDRS1 翻译成功。只读页表定位到 NPU所在L2表项为空；精确护栏下只临时映射两个4KiB NPU设备页，R/W地址翻译均成功，撤销后恢复原翻译故障且原L2表项读回0，`go`返回0、报告status0。回 Linux `6.1.111-rt42`、模块0。**CPU页表障碍已解决，但未在映射期间访问NPU寄存器、未执行START。** 详见 `docs/research/HARDNPU_H1_UBOOT_NPU_MMIO_TRANSLATION_20260926.md`。下一步无START寄存器/复位验证；首次真实START仍需当时明确许可，H1继续`NO-GO`。

## 2026-09-26 H1 U-Boot 四缓冲缓存/翻译无启动板测

继四缓冲内容与八笔计划验收后，新增 U-Boot EL3 纯CPU程序实测：报告/输入/权重/packet/输出共23个页经读写 `AT S1E3R/W` 逐页核对为期望物理页，缓存行64B、DDRS1关闭、NPU组号3；输入/权重/packet清缓存、输出清并失效、结果页清缓存。冻结CRC、130字packet、16KiB哨兵、八笔计划仍PASS，`go`返回0。正常回Linux后模块0、DDRS1基线。该程序未访问HardNPU MMIO、未执行START或证明NPU DMA；真实首算仍`NO-GO`，后续需可回收提交/IRQ/输出/异常方案。见 `docs/research/HARDNPU_H1_UBOOT_CACHE_NOSTART_BOARD_20260926.md`。

## 2026-09-26 DDRS1 源页读对照与 H1 补集候选裁决

`GROUPID=0x20/RASR=0x001` 命中自有 PL330 源页时，64字节复制也发生受控通道故障；DDRS1先回滚、故障缓冲固定，软件重启后板卡/模块/DDR S1/PL330基线恢复。此前RW=3、GROUPID=0x8命中目的页会拦 PL330，正是H1现有四缓冲补集候选的禁止区形状；因此该候选**不能作为共享Linux环境的 NPU 专属保护策略**。RW=0组选择性不能外推到RW=3。RUN_ONCE固定拒绝、NPU START未执行。见 `docs/research/HARDNPU_H1_DDRS1_RW0_SOURCE_READ_AND_POLICY_REJECTION_20260926.md`。

## 2026-09-26 DDRS1 RW=0 GROUPID 选择性板测

当前板同一 PL330 自有目的页规则 `RASR=0x001` 下，`GROUPID=0/0x8` 64字节复制通过，`0x20/0xffffffff` 产生目的写错误；早期四组都失败使用的是 `RASR=0x301`，不能混同。本轮 `0x8` 模块目标构建、默认关闭及显式一次板测通过，DDRS1 回滚后只读值 `CTRL=0x800/Region0=0x301/Region7=0`，模块数0。组字段对 PL330 路径有选择性，但精确允许/拒绝语义、NPU主AXI组路由和异常排空仍未闭合；首次 HardNPU START 未执行，RUN_ONCE固定拒绝、首算 `NO-GO`。见 `docs/research/HARDNPU_H1_DDRS1_GROUP_SELECTIVITY_RW0_BOARD_20260926.md`。

## 2026-09-26 DDRS1 区域命中与四组合板测收敛

新受控板测：DDRS1 全局使能、八区全部禁用时，PL330 64字节复制PASS；全局使能、只让区7覆盖独立guard页而目的页不命中时，复制及guard完整性PASS。命中自有目的页且 `GROUPID=0xffffffff/RW=0` 时，SECURE/PRIVILEGE 四种组合 `00/10/01/11` 均报同型写故障（前两种见既有实验，后两种为本轮）；两次新故障均先回滚DDRS1并固定缓冲，再正常软件重启。最终重新登录后DDR S1基线、PL330零故障/空闲、模块0。拒绝与区7命中相关；单独改变 SECURE/PRIVILEGE 不解释原因。原厂实例级组/权限判定、HardNPU主设备路由仍未知；已备好 `docs/research/HARDNPU_H1_VENDOR_SUPPORT_QUESTION_20260926.md`，未对外发送。H1 START未执行、RUN_ONCE固定拒绝。见 `docs/research/HARDNPU_H1_DDRS1_REGION_HIT_MATRIX_BOARD_20260926.md`。

## 2026-09-26 XMON 计数支持 PL330 写 GroupID=5

在 DDRS1 MPU 基线 `CTRL=0x800`、PL330 无故障条件下，隔离探针目标构建并完成默认无提交装载/卸载；显式一次用已验证的64字节 PL330 复制测 XMON。DDR_S1 与 DMACX 的 AW GroupID 宽范围 `0..255` 和窄范围 `5..5` 均各计64，空闲窗口均为0，两次复制成功且无故障。探针内恢复并读回 XMON 配置/范围/计数为0，卸载后模块数0、串口继续响应。当前 PL330 写路径 GroupID=5 获得限定板证；仍不能解释 Region7 全组位开放时写错误，也不能推断 HardNPU 自身 GroupID。卸载后 `devmem2` 直读计数器出现用户态 Bus error，未作为恢复证据。H1 RUN_ONCE 继续固定拒绝，首次 HardNPU START 未执行，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_XMON_PL330_GROUP5_BOARD_20260926.md`。

## 2026-09-26 DDRS1 SECURE 位单变量及 XMON 路径证据

安路 AI 对实例级真值表答复“无法检索，请联系客户支持”。隔离程序在前次全组位、RW=0对照上只翻区7 SECURE bit6（`RASR=0x041`），目标构建、默认无提交加载/卸载通过；显式一次 PL330 目的写仍报 `FSRC=0x80/FTR7=0x20000`、目的页4096字节完整。DDRS1先回滚、故障缓冲固定；重启后模块0、DDRS1/PL330基线与错误清零。故障未清时 XMON DDR_S1 `DEBUG_FLAGINFO=0x200100/ADDR=0x2757a000/ID=0x1d0`，DMACX 对同一目的页附近写错误也有记录，支持错误路径经过 DDR_S1；XMON ID 不可当 GROUPID，`INTR_MPU_STATE=0`在区域未开中断时不能排除 MPU。SECURE 0/1均拒绝，单独翻该位不足以放行。见 `docs/research/HARDNPU_H1_DDRS1_SECURE1_XMON_BOARD_20260926.md`。H1首算仍 `NO-GO`，未执行 NPU START。

## 2026-09-26 DDRS1 全组位、RW 开放仍发生 PL330 写错误

按 UG1214 位图规则准备的隔离正对照已在当前板目标构建、默认无提交加载/卸载通过；显式一次把区7设为自有目的页、`GROUPID=0xffffffff/RASR=0x001`，PL330 仍报 `FSRC=0x80/FTR7=0x20000/CS7低位0xf`，目的4096字节完整哨兵。DDRS1先恢复，故障模块/缓冲固定；随后正常软件重启，重新登录后模块0、DDRS1基线、PL330故障0。此结果说明全组位和 RW=0 **不足以**放行该非安全事务；SECURE/PRIVILEGE 极性与 AxPROT、区重叠优先级仍未闭合，不能据此否定 GROUPID 位图。见 `docs/research/HARDNPU_H1_DDRS1_ALL_GROUP_RW_OPEN_BOARD_20260926.md`。不再盲试掩码；H1 首算仍 `NO-GO`，未执行 NPU START。

## 2026-09-26 DDRS1 GROUPID 手册核对与旧试验重释

用户提供安路 AI 的 GROUPID 位图线索后，直接核对本地 UG1214 v1.3：手册明确主设备 groupid 对应允许 ID 字段的位，置1授权、置0拒绝；ID通过后还要检查权限。四次 PL330 目的页试验的区7均为 `RASR=0x301`（RW=3，即读写都保护），所以无论组位是否允许，写入都可能被拒绝。此前“0/0x1/0x8/0x20 均拒绝反驳组位图”的推断撤回；原始故障/回收数据仍有效，但只证明命中地址的拒绝。新隔离正对照源码设置全组位1、RW=0、仅自身目的页且默认关闭，已审查差异，**未目标构建或板测**。UG1214 还澄清 `MPU_NPU=0xF841C000` 保护其他模块访问 NPU，不是 NPU 访问 DDR 的独立保护；UG1215 的 `INTR_MPU_STATE` 是 `0xF8800214`，不是 AI 回答中的两种地址。见 `docs/research/HARDNPU_H1_DDRS1_GROUPID_MANUAL_RECONCILIATION_20260926.md`。H1 RUN_ONCE 固定拒绝、首算 `NO-GO`，首次真实 START 仍需用户当时明确许可。

## 2026-09-26 H1 超时后迟到 IRQ 原始状态保留

H1 状态机以前超时后仍固定 DMA 缓冲，但会丢弃后来 IRQ 的原始值；现在只保留首次非零 `irq_status/work_status` 用于诊断，仍拒绝 IRQ、保持 `TIMEOUT_PINNED`、不可释放缓冲。主机和板端严格 C11 状态测试通过；新目标模块构建、默认装载/卸载通过，`NPU not started`、最终模块0。真实 IRQ/START 未运行，DDRS1 RUN_ONCE 固定拒绝不变，IP bit2与 AXI 排空仍未知。见 `docs/research/HARDNPU_H1_LATE_IRQ_DIAGNOSTIC_20260926.md`。首算继续 `NO-GO`。

## 2026-09-26 DDRS1 GROUPID=0 仍拒绝 PL330 的新反例

沿用已经三次受控验证的 Linux PL330 64B目的页拒绝路径，只把区7 `GROUPID` 改为0；新模块默认关闭装载/卸载、目标构建和单次显式实验均完成。目的页4096/4096保持哨兵，PL330 `FSRC=0x80/CS7低位0xf/FTR7=0x20000`，源/微码尾完整；DDRS1 先恢复八区，故障缓冲固定，正常软件重启后 Linux可登录、模块0、DDRS1/PL330基线与故障清零。0、0x1、0x8、0x20 四个值均未出现预期的“排除 PL330”结果，不能把 SDK 位枚举直接当作当前 DDRS1 组选择证明；0 的硬件意义仍未知，停止同型故障对照。见 `docs/research/HARDNPU_H1_DDRS1_GROUP0_COUNTEREXAMPLE_20260926.md`。未执行 NPU START；H1首算继续`NO-GO`。

## 2026-09-26 U-Boot DDRS1 对照停机与复位核验

为区分 Linux 阶段组路由与 U-Boot 阶段静态组号，新增 U-Boot EL3 DDRS1 group0x8/PL330 对照程序。最初未保留 `x18` 的纯 C 构建在无 DMA 提交时出现两次 U-Boot 同步异常；当前 BOOT.bin 反汇编显示 U-Boot 函数读取 `[x18,#8]`，旧程序反汇编确有 `mov w18,#0x20`，崩溃现场 `x18=0x20`。所有本目录 U-Boot C 编译规则现加 `-ffixed-x18`，修正后的无写入程序静态检查无 x18/w18 引用，板端 `go` 正常返回且报告 `status7/submitted0`。因此旧“非零返回可能导致异常”的解释被反例推翻，x18 破坏是有直接证据支持的原因。

修正后的显式 DDRS1 写入程序在 `go` 启动后超过10秒无串口输出，未读到阶段报告，不能判定停在区域写入、使能、DMA还是回滚，也不能判定 group0x8 允许或拒绝。用户现场断电重上电；Linux `6.1.111-rt42` 可登录，`/proc/modules` 空。只读 `/dev/mem` 核验 DDRS1 `CTRL=0x800`、区0 `0x301/0/0xffffffff/0`、区1–7全0，PL330 `DS=0x200/FSRD=FSRC=FTR7=DBGSTATUS=0`。写入变体已从 Makefile 移除且源码编译门禁拒绝。见 `docs/research/HARDNPU_H1_UBOOT_X18_AND_GROUP8_HANG_20260926.md`。未执行 HardNPU START；DDRS1 组选择及 H1 首算继续 `UNKNOWN/NO-GO`。

## 2026-09-26 U-Boot EL3 PL330 缓存见证实传

当前板 U-Boot 在 DDRS1关闭、PL330八通道空闲、组号NPU/DMA_AXI=3/5且三临时页 EL3 翻译匹配后，显式清理源/微码缓存、清理并失效目的缓存，单次非安全通道7复制普通 DDR 64字节。报告提交1、目的64/64一致、源/目的尾和微码尾完整、PL330无故障且停止；独立寄存器/内存读回一致。回 Linux `6.1.111-rt42`、模块0。无提交预检的非零返回曾引发 U-Boot 同步异常并自动重启，改为结果页状态+正常返回后预检通过，根因仍未完全确定。详见 `docs/research/HARDNPU_H1_UBOOT_PL330_CACHE_WITNESS_20260926.md`。这是特定PL330路径的缓存见证，不等于 HardNPU DMA或DDRS1组隔离；NPU START未执行，首算仍`NO-GO`。

## 2026-09-26 H1 U-Boot 四缓冲无启动验收

复用冻结 H1 输入/权重和130字 packet，在 U-Boot 从 FAT 加载至固定临时 DDR 后运行2440字节纯 CPU 程序：输入/权重 CRC 与冻结记录相同、packet130/130字相同、输出16KiB哨兵及三块尾部逐字节完整、八笔写入计划精确记录，`go`返回0。回 Linux `6.1.111-rt42`、模块0。程序的回调仅记录，不写 NPU 寄存器；不证明设备 DMA/缓存一致性、DDRS1 路由或算子。见 `docs/research/HARDNPU_H1_UBOOT_NOSTART_STAGE_20260926.md`。真实 START 尚未执行，H1 首算仍`NO-GO`。

## 2026-09-26 H1 U-Boot EL3 只读预检

当前板 U-Boot 从 USB FAT 读取板端私有构建的 168 字节临时程序，`go 0x20000000` 返回0；程序只读两组 TOP_S 与 DDRS1 CTRL，并写临时 DDR 结果页。实测 CurrentEL=EL3、NPU/DMA_AXI 组号3/5、DDRS1 CTRL=`0x800`、SCTLR_EL3=`0x00c5383d`（MMU/缓存开启）。正常回 Linux `6.1.111-rt42`、模块0。此为 U-Boot 执行路径和阶段读值证据，不解释 Linux 实时组路由或 DDRS1 组选择反例，也不构成 NPU 计算。见 `docs/research/HARDNPU_H1_UBOOT_EL3_PREFLIGHT_20260926.md`。未执行 START；H1 首算仍 `NO-GO`，RUN_ONCE 固定拒绝保留。

## 2026-09-26 H1 RUN_ONCE 对组路由反例失败关闭

逐行对照三份 PL330 拒绝程序，除组值和名称/日志外执行路径相同。H1 原 RUN_ONCE 只读核对 DDRS1 软件候选形状，无法从寄存器匹配推断组隔离；现于该专用门槛在形状检查后固定返回 `EOPNOTSUPP`，防止手工配置候选和设置两个参数后误触 START。新源码目标构建、默认装载与冻结 H1 无启动预检、默认 RUN 拒绝、DDRS1 只读诊断均通过；卸载模块数0。未运行放行参数或新拒绝分支，未执行 START。详见 `docs/research/HARDNPU_H1_DDRS1_GROUP_ROUTE_FAIL_CLOSED_20260926.md`。首算仍`NO-GO`。

## 2026-09-26 DDRS1 group0x1 第三组对照

同一自有目的页规则只把 GROUPID 改为 CSU 候选0x1，PL330仍报告 AXI数据写故障，目的整页不变；故障固定、DDRS1八区恢复，正常软件重启后模块/故障清零。与此前0x20、0x8结果合看，证明地址命中拒绝，**未证明组选择性**；运行时组路由或比较语义仍`UNKNOWN`。见 `docs/research/HARDNPU_H1_DDRS1_GROUP1_COUNTEREXAMPLE_20260926.md`。停止继续堆叠相同故障对照，先找共同配置原因。H1策略与首算继续`NO-GO`，未执行START。

## 2026-09-26 DDRS1 组选择反例与回收

继 group0x20 目的页拒绝后，独立模块仅将同类区7 `GROUPID` 改成 NPU 候选 `0x8`、目标仍为自身 coherent 目的页。PL330 通道7仍出现 `FSRC=0x80/FTR7=0x20000/CS低位0xf`，目的整页保持`0xA5`。这与“0x8 不会拦截 DMA_AXI”的预期相反；GROUPID 硬件比较语义或实时路由仍 `UNKNOWN`。模块故障固定并恢复 DDRS1；独立只读验证后正常软件重启，重新登录确认模块数0、CTRL=`0x800`、八区基线、FSRC/FTR7=0。再正常重启截停 U-Boot 只读确认 NPU/DMA_AXI 组号3/5与手册默认一致，已执行默认启动，不能证明 Linux 运行时未改组。见 `docs/research/HARDNPU_H1_DDRS1_GROUP8_COUNTEREXAMPLE_20260926.md`。不能以静态组映射放行 H1 DDRS1 策略；Hard 首算仍 `NO-GO`，未执行 START。

## 2026-09-26 DDRS1 对 DMA_AXI 的允许/拒绝实测

基于已通过的 PL330 64B复制，在当前板短时启用 DDRS1：group0x20 规则放在自有闲置页时复制完成并恢复八区；同规则只改为指向自有目的页时，PL330通道7 `FSRC=0x80/CS低位0xf/FTR7=0x20000`（AXI数据写错误），目的整页保持哨兵。拒绝实验按设计固定缓冲，DDRS1先恢复，再正常软件重启回收；重新登录后模块数0、CTRL=`0x800`、FSRC=0。见 `docs/research/HARDNPU_H1_DDRS1_DMA_AXI_ALLOW_DENY_BOARD_20260926.md`。这实证当前板 DDRS1 **在该配置下对 PL330 目的页写入的地址拒绝效果**；后续 group0x8 对照同样拒绝，因此组选择性尚未证实，**不证明 NPU group0x8 路由或 Hard 首算安全**；首算仍 `NO-GO`。

## 2026-09-26 PL330 非安全普通 DDR 64B 实传通过

独立实验模块在当前板显式一次提交通道7 PL330 `DMAGO ns=1`，26字节微码从自有 coherent 源页向目的页复制64字节。首次硬件复制实际成功，但验收器误把 CSR bit21（非安全标志）当运行位，故障保留后正常软件重启回收；修正为仅看低状态位后再次显式运行自动 `PL330 COPY PASS`，独立只读检查目的64字节相等、源模式与目的/指令页尾完整、CPC/SAR/DAR前进预期、故障0，随后模块卸载/资源释放。DDRS1 CTRL事后`0x800`，无保护试验或 NPU START。见 `docs/research/HARDNPU_H1_PL330_64B_DDR_COPY_BOARD_20260926.md`。这仅建立 DMA_AXI 普通 DDR 受控流量源，Hard 首算仍 `NO-GO`。

## 2026-09-26 PL330 非安全 MMIO 独占申请实测

当前 AMBA `f8419000.dma-controller` 未绑定驱动。独立无 MMIO 的最小模块在板端 `request_mem_region(0xf8419000,0x1000)` 成功，装载期间资源树出现子项；卸载释放后只剩设备父项，模块数0。此为 Linux 资源树的本次独占申请/释放证据，不覆盖固件或绕开资源树的访问者。历史源码输出树构建仍有精确 ABI 告警，无 DMA/MMIO 写、DDRS1 写或 NPU START。见 `docs/research/HARDNPU_H1_PL330_MMIO_CLAIM_BOARD_20260926.md`；Hard 首算仍 `NO-GO`。

## 2026-09-26 PL330 非安全启动位修正与离线编码

ARM PL330 原厂手册定义 DSR bit9=DNS；当前板实读 `0x200` 确认 DMA manager 非安全。安路 SDK `DMA_Exec_DMAGO` 却固定 `ns=0`，按手册在此状态下会使 manager fault、不启动通道（源码加手册推断，未在板实测）。当时新增含事件的28字节离线候选及 `DMAGO ns=1`；后续依据 INTEN=0 事件规则改为26字节并完成普通DDR板测，以上方新记录为当前状态。见 `docs/research/HARDNPU_H1_PL330_DMAGO_SECURITY_MISMATCH_20260926.md`。

## 2026-09-26 非安全 AXI DMA 只读板端配置核验

SDK 裸机驱动提供 PL330 寄存器定义，但默认安全实例且部分等待无时间界限；未将它直接用于 Linux。新固定白名单探针在当前板非安全 `0xF8419000` 实读配置、状态、八通道 CSR：八通道在采样时均为0，故障/事件读值0，配置字段对应8通道/4外设/16事件。只读目标构建成功、模块数0，无 DMA 传输、DDRS1 写或 NPU START。此结果仅为准备有界 DMA 流量源，不能证明所有权或 DDRS1/NPU 路由。见 `docs/research/HARDNPU_H1_AXI_DMA_NONSECURE_READONLY_20260926.md`；首算仍 `NO-GO`。

## 2026-09-26 SDK linux 子模块与 RISC-V 指南核验

用户给的源码位置线索得到本地 `.gitmodules` 和安路公开 SDK 页面支持；但现有 SDK_2026.01 只读快照的 `linux` 子模块目录为空、无本地子模块对象。另有完整 2025.07 Linux 6.1.111 源码归档及 DR1M90 RT defconfig，仍与当前 Image 的 AMBA 资源偏移实证不兼容，不能代替精确运行 `.config`/输出。APUG1210 指南面向 DR1V RISC-V RPU/OpenSBI，不能证明当前 AArch64 DR1M90 HardNPU 接口。见 `docs/research/HARDNPU_H1_SDK_LINUX_SUBMODULE_AND_RISCV_SCOPE_20260926.md`。首算仍 `NO-GO`。

## 2026-09-26 当前 Image 反汇编直接定位 AMBA 资源偏移

用同哈希当前内核 Image 和运行 `/proc/kallsyms` 定位 `amba_device_alloc`：内核在对象偏移472/480写资源起止、496写`IORESOURCE_MEM=0x200`，`amba_request_regions`也从472读取。历史头文件编译的诊断按偏移480读起始，故实读成`0xf8419fff`（实际结束地址）；PL330 的`invalid resource`由8字节结构错位直接解释。该局部反汇编不能恢复完整内核 ABI，禁止硬编码偏移驱动 DMA。详见 `docs/research/HARDNPU_H1_PL330_LIVE_IMAGE_RESOURCE_OFFSETS_20260926.md`；Hard 首算仍 `NO-GO`。

## 2026-09-26 当前运行内核镜像逐哈希锁定

板卡只读启动分区 `uImage.lz4` 的 LZ4 载荷及解压 Image 分别与既有隔离副本逐哈希相同，解压 Image 的版本字符串也与 `/proc/version` 相同；两次只读挂载已卸载、模块数0。此证据锁定当前启动镜像身份，但运行配置、精确源码及构建输出仍 `UNKNOWN`；历史树 AMBA ABI 错位未解除。现有 PL VDMA 路由不能代替 HardNPU 的 DDRS1 保护证明。详见 `docs/research/HARDNPU_H1_RUNNING_KERNEL_IMAGE_IDENTITY_20260926.md`。Hard 首算仍 `NO-GO`。

## 2026-09-26 PL330 目标模块实证 AMBA ABI 不匹配

历史私有内核树的 PL330 源在新 `/run` 目录目标构建、模块可装载，但设备 probe 报`invalid resource/-22`，未绑定或生成 DMA 通道。独立只读 AMBA 诊断按该树头文件读取同一设备得`periphid=0`、资源`start=0xf8419fff/flags=0`，而运行内核 sysfs 为`AMBA_ID=00341330`、资源`0xf8419000–0xf8419fff/flags=0x200`；证实该树 AMBA 结构布局不兼容。两模块均卸载，最终模块数0，无 DMA、DDRS1写或 NPU START。详见 `docs/research/HARDNPU_H1_PL330_AMBA_ABI_MISMATCH_BOARD_20260926.md`。后续不能以此树直接驱动 PL330；Hard 首算仍 `NO-GO`。

## 2026-09-26 AXI DMA 与当前内核构建身份盘点

板端 AMBA 识别 `arm,pl330` AXI DMA、ID=`00341330`，但未绑定驱动；DMAengine 仅有 PL VDMA 通道。历史模块构建树配置标 `PL330=y`、生成头为 GCC9/root，本次运行内核 `/proc/version` 为 Linaro GCC7.5/uisrc，且无运行配置导出。相同 kernel.release/vermagic及模块可加载不足以证明精确编译同源；不能把 PL330 当成现成 DDRS1 流量源。详见 `docs/research/HARDNPU_H1_PL330_LIVE_KERNEL_PROVENANCE_20260926.md`。

## 2026-09-26 H1 DDRS1 短时全局使能读回与恢复

使用已目标构建的默认关闭探针，仅武装 `allow_ddrs1_enable_probe=1`，保持 NPU 两项运行参数关闭；一次无 NPU START 实测 CTRL使能读回`0x801`、关闭读回`0x800`、八区原值恢复、故障钉住0。后续独立只读快照仍为原基线，模块卸载后计数0，Linux持续响应。此证据仅覆盖使能位读回/恢复，不证明保护拦截或 HardNPU 路由。板上 PL330 AXI DMA 被 AMBA 识别但无绑定驱动，尚无现成受控 DDRS1 流量。见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_READBACK_BOARD_20260926.md`。首算仍 `NO-GO`。

## 2026-09-26 H1 START 前旧 IRQ/工作状态门槛

独立 H1 候选在最后一笔 START 前紧邻只读检查 IRQ 状态0、工作状态空闲0，非零拒绝并以新故障原因10固定 DMA 缓冲；这收窄激活清中断到 START 之间的旧事件窗口，不能消除读取后竞态。修正旧日志的“NPU idle”为“NPU not started”。新板端私有目录目标构建与无启动冻结载荷回归通过，模块卸载后计数0；真实检查分支未触发，也未执行 START。详见 `docs/research/HARDNPU_H1_PRESTART_STALE_IRQ_GUARD_20260926.md`。IP bit2、DDRS1及排空缺口仍使首算 `NO-GO`。

## 2026-09-26 H1 DDRS1 短时使能探针仅完成默认关闭验证

新增默认关闭的 H1 `DDRS1_ENABLE_PROBE`（ABI 2 命令0x1a），拟仅保护自有 DMA 的一个4 KiB页并短时使能/关闭 CTRL；尚未武装或执行。新板端私有目录目标构建、默认 `EPERM` 和八区只读基线通过，CTRL仍`0x800`、COLD/零NPU写，模块卸载后计数0。手册版本对未命中规则及区域字段存在冲突，短时全局使能可能影响共享 DDR 主设备，故本轮不执行。详见 `docs/research/HARDNPU_H1_DDRS1_ENABLE_PROBE_PREP_20260926.md`。Hard 首算仍 `NO-GO`。

## 2026-09-26 H1 DDRS1 八区关闭状态完整事务

新增默认关闭的 H1 `DDRS1_TRANSACTION`：按本次四块 DMA 地址生成八区补集候选，在严格当前基线/资源独占/COLD 门槛下，仅于 CTRL=`0x800` 时写区域字段、逐项读回并恢复进入前快照；绝不写 CTRL。板端目标构建、默认拒绝通过；显式一次事务 `candidate=1/restored=1/writes=80/fault_pinned=0`，CTRL前后`0x800`。独立只读诊断确认八区恢复原值，最终模块数0、无资源残留。仅证明关闭状态的配置口读写/回滚，不证明 MPU 生效或 HardNPU AXI 路由；未执行 START。详见 `docs/research/HARDNPU_H1_DDRS1_FULL_DISABLED_TRANSACTION_20260926.md`。首算仍 `NO-GO`。

## 2026-09-26 DDRS1 关闭状态单字段写入/恢复

新增默认不武装的独立测试模块，显式武装时先独占配置口并严格核对当前8区基线，仅将关闭的 region7 SAR 写1、读回、写回0，再完整核对基线。板端一次执行 `changed=1/CTRL=0x800/restored=0/result=0`；随后 H1 只读诊断确认八区与原值一致，最终模块数0、资源无残留。此证据只证明单字段在保护关闭时可写和本次恢复，不证明策略生效、NPU AXI 路由或故障排空；未执行 START。见 `docs/research/HARDNPU_H1_DDRS1_DISABLED_WRITE_READBACK_20260926.md`。首算仍 `NO-GO`。

## 2026-09-26 H1 DDRS1 Linux 资源冲突负例

用户确认此前重启或改动连接；本轮板卡重登原 Linux、模块数0，旧 `/run` 目录已清空。重新传输、目标构建后，测试占位模块只登记 `0xF840F000/0x100`；H1 只读诊断在冲突时返回 `EBUSY`，占位卸载后诊断成功，最终两模块卸载、资源条目消失、CTRL仍`0x800`、COLD/零提交。该实测只覆盖诊断入口的 Linux 资源互斥，不证明固件/其它主设备所有权，也未执行 RUN_ONCE/START。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CONFLICT_BOARD_20260926.md`。首算仍 `NO-GO`。

## 2026-09-25 H1 DDRS1 Linux 资源申请门槛

RUN_ONCE 候选在 DDRS1 策略读回前先独占申请 `0xF840F000/0x100`，申请失败拒绝，成功提交后保持到固定作业生命周期；只读诊断短暂申请并释放。新版目标模块构建、默认关闭参数下诊断、释放和卸载通过，CTRL仍`0x800`、COLD/零提交；占位冲突反例尚未验证。后续 COM4 突然无串口输出，板卡状态待核；未执行 START、未写 DDRS1。Linux 资源仲裁不能证明固件/其它主设备不使用该窗口，首算仍 `NO-GO`。见 `docs/research/HARDNPU_H1_DDRS1_RESOURCE_CLAIM_20260925.md`。

## 2026-09-25 H1 DDRS1 生成器目标无启动验证

新版15项输入在当前板新 `/run` 私有目录传输哈希15/15相同；目标严格 C11 生成/验证合同通过，H1 模块目标构建且 vermagic 匹配。默认三参数关闭，两次装载分别完成 DDRS1 八区只读诊断与冻结输入/8笔计划/所有权回归，均退出0并卸载，模块数0。CTRL仍`0x800`、策略匹配0、COLD/零提交，无 DDRS1 写入或 START。目标 `.ko` SHA 与限制见 `docs/research/HARDNPU_H1_DDRS1_BUILDER_TARGET_20260925.md`。首算仍 `NO-GO`。

## 2026-09-25 H1 group 映射与共享 DDRS1 策略生成器

本地 UG1215 TOP_S 七个主设备组编号与 DR1M90 SDK MPU 区域 GROUPID 掩码逐项满足 `mask=1<<编号`；U-Boot 实读 NPU 编号3，与候选掩码0x8一致。新增从当次四块 DMA 地址生成 DDRS1 八区候选的纯 C 函数，并让现有只读校验共用该结果；主机严格编译、独立七区期望值和12个反例通过。未重建板端模块、未写 DDRS1 或执行 START。映射仍属静态/启动阶段证据，Linux 实时路由、区域硬件语义、所有权和故障排空未证，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_GROUP_ROUTE_MAPPING_20260925.md`。

## 2026-09-25 U-Boot 阶段 DDRS 预置与 NPU group 编号

正常重启并截停当前板 U-Boot 后，只读 DDRS0/1 CTRL 均为 `0x800`、第一区均为 `0x301/0/0xffffffff/0`；因此相同预置在 Linux 启动前已存在。U-Boot 同次只读 TOP_S `GROUPID_NPU@0xF8806110=3`，而 Linux 下此前对该地址读取故障。默认启动回原 `6.1.111-rt42`、root 登录，模块数0；没有写寄存器或运行 NPU。公开带符号 FSBL ELF 把同型清使能路径定位到 `SoC_M90_DdrInit`，但与当前 BOOT 字节不等同，公开源码未写第一区。组编号3与 SDK 区域掩码0x8的对应和 Hard 主 AXI 路由仍未证明，保护仍关闭，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_FSBL_DDRS_SOURCE_BRIDGE_20260925.md` 与 `docs/research/HARDNPU_H1_UBOOT_DDRS_GROUP_READ_20260925.md`。

## 2026-09-25 H1 驱动自身 DDRS1 八区同次读回

新增只读 `DDRS1_POLICY` ioctl，使 H1 驱动在本次四块 coherent 分配仍活动时返回八区原始寄存器及软件补集匹配结果。板端私有构建、默认双运行参数 N 的一次装载/只读诊断/卸载通过：四 DMA 地址 `0x17c6c000/0x17c70000/0x17c7c000/0x17ca0000`，CTRL 前后 `0x800`，区0 `0x301/0/0xffffffff/0`、区1–7全0，匹配0，COLD/零写。卸载后模块数0。未调用 RUN_ONCE/START；保护仍关闭，Hard 首算继续 `NO-GO`。见 `docs/research/HARDNPU_H1_DDRS1_DRIVER_LIVE_READ_20260925.md`。

## 2026-09-25 H1 实时四缓冲补集策略形状匹配

独立 H1 驱动现在以同一次活动 coherent 分配的四缓冲为基准，计算1 GiB DDR内其它地址的至多8段候选拒绝区，并在任何 NPU/TOP 写入前，只读逐项核对 DDRS1 CTRL、八区 RASR/SAR/EAR/GROUPID 与候选完全相同；多余区必须全0。主机及板端纯 C 正例1/反例10通过，目标模块构建及默认关闭参数的无启动回归通过。当前板 `CTRL=0x800` 不匹配；没有配置 MPU 或执行 RUN_ONCE/START。验证器依据 SDK 字段提出**软件匹配条件**，尚无硅片容量/比较、实时 NPU group/路由、所有权或故障排空证据，不能放行首算。见 `docs/research/HARDNPU_H1_DDRS1_POLICY_MATCH_20260925.md`。

## 2026-09-25 H1 驱动实时 DDRS1 必要门槛

独立 H1 候选在 `RUN_ONCE` 中、CRP 资源申请/IRQ 登记/NPU 与 TOP 寄存器映射和任何硬件写入之前，新增 DDRS1 CTRL 只读核对：仅当 ENABLE=1 且 region 数为8才允许继续；否则返回错误。代码已在板端全新 `/run/h1_ddrs1_gate_20260925_1` 私有目录目标构建，无启动装载/冻结载荷/8笔计划轨迹/卸载通过。卸载后板端只读 CTRL 仍为 `0x800`，模块数0、设备节点不存在。未开启运行参数或调用真实 START 路径。此检查只阻止当前已知的“MPU 关闭仍可人工放行”漏洞，**不能证明** region 权限、NPU group/AXI 路由、共享主设备影响或故障后排空；首次 Hard 算仍 `NO-GO`。详见 `docs/research/HARDNPU_H1_DDRS1_LIVE_GATE_20260925.md`。

## 2026-09-25 用户所指手册、Sol 与 demo 的 HardNPU 路由复核

复用 Sol 已完成的 UG1214 第33章/FD25.1 MPU 示例审计：文档未命中默认放行，bit10、区域数及跨度与 UG1215/BSP 冲突；官方示例只配 APU MPU。D20.1/D21.1 demo 是不同 G484/PL SoftNPU 参考，D21.1 BOOT 虽同样含 DDRS0/1 CTRL 清使能代码，却没有给当前 G400 板的实时 NPU group、DDRS1 隔离或故障排空证据。对当前 BOOT 与 demo BOOT 的直接地址构造清点未定位第一区写入者；不能把负搜索当成不存在的证明。详见 `docs/research/HARDNPU_H1_BOOT_DIRECT_ADDRESS_INVENTORY_20260925.md`。首算仍 `NO-GO`。

## 2026-09-25 DDRS0/1 相同非复位预置与当前 BOOT 邻近调用

本地 UG1215 列第一区 RASR/EAR 复位均为0；当前板 DDRS0 与 DDRS1 只读实测却完全相同：CTRL=`0x800`、第一区 RASR/SAR/EAR/GROUPID=`0x301/0/0xffffffff/0`。这是非复位快照，共同初始化仅为推断。当前 TF BOOT 哈希再核一致，已证清 DDRS0/1 全局使能的调用相邻代码未定位第一区写入者；简单常量扫描也不能排除其它构址。TF 已卸载，未写硬件或 START。详情见 `docs/research/HARDNPU_H1_DDRS0_DDRS1_PRESET_ORIGIN_20260925.md`。两个控制器仍关闭，Hard 首算 `NO-GO`。

同日新增 TOP_S `PROTEN_SET@0xF88060B0` 固定只读探针，触发受控故障/退出3；此前同页 `GROUPID_NPU@0xF8806110` 也只读故障。DDRS1 CTRL 随后仍为 `0x800`。两点故障收窄了访问问题，仍不能证明 protection 位状态、整页不可达或所有权。没有写 `PROTEN_CLR`；首算 `NO-GO`。

## 2026-09-25 当前板 DDRS1 八区只读快照

固定只读探针在当前板读取 DDRS1 全部八区的 RASR/SAR/EAR/GROUPID；32次读取均成功。区0原始值分别为 `0x301/0/0xffffffff/0`，区1–7四字段全0；全局 CTRL 前后均为 `0x800`（8区、ENABLE=0）。区0虽有软件字段上的全范围禁止配置，但全局关闭且 group=0，不能作为现行隔离或可安全启用的证据。板端严格构建、源码哈希一致；未写寄存器或 START。详情见 `docs/research/HARDNPU_H1_BOARD_DDRS1_REGION_READ_20260925.md`。异常后 DMA 缓冲固定不等于 NPU AXI 排空；Hard 首算仍 `NO-GO`。

## 2026-09-25 DDRS1 SDK 区域地址字段离线核对

本地 DR1M90 SDK 以4 KiB页计算 region SAR 起点和包含式 EAR 末页。新增离线编码器复用补集规划器，对8区边界和已失效的实板7区快照做编码/反解一致性核对，均通过；只输出地址页编号，不写或生成保护使能与 group 配置。当前板已实读8区、ENABLE=0，但 region 最大跨度/硬件比较语义、NPU group与路由、资源所有权及故障排空仍未证。IRQ bit2 冲突的既有审查不重做。详情见 `docs/research/HARDNPU_H1_SDK_REGION_ADDRESS_FIELDS_20260925.md`，首次 START 仍 `NO-GO`。

## 2026-09-25 当前板 DDRS1 region 数和使能读回

采用固定地址 `O_RDONLY/PROT_READ` 目标探针实读 DDRS1 `CTRL=0x00000800`：按 UG1215，region 数为8、ENABLE=0。CRP `0xF8801074=0x73f0` 的 DDR 总线复位释放位为1；LOCK DDRS1 写锁位为0。TOP_S NPU group ID 的只读访问触发受控故障，实时 group 仍 `UNKNOWN`。当前 BOOT 同哈希反汇编还显示，清 DDRS0/1 enable 的同一函数随后释放 DDR 总线复位；这是静态路径，不能代替执行轨迹。区域数量门槛得到实板证据，但当前 MPU **未启用**，且地址/组匹配、访问所有权、保护语义与故障排空未闭合；首算仍 `NO-GO`。详见 `docs/research/HARDNPU_H1_BOARD_DDRS1_CTRL_READ_20260925.md`。

## 2026-09-25 H1 实际 DMA 地址快照

沿用现有 H1 `PLAN_TRACE`，只给无启动验收程序增加完整四缓冲地址/容量快照。当前板上私有构建后默认三项硬件运行参数均为 `N`，一次装载、冻结输入/权重测试、卸载均返回0；四基址为 `0x17c6c000/0x17c70000/0x17c7c000/0x17ca0000`，完整缓冲落当前1 GiB DDR。抽象补集规划对这次布局得到7个区间。模块卸载后地址已失效，绝非未来运行的 MPU 配置或真实 NPU 访问证据。细节见 `docs/research/HARDNPU_H1_BOARD_DDR_ADDRESS_SNAPSHOT_20260925.md`；首次 START 仍 `NO-GO`。

## 2026-09-25 H1 DDRS1 配置口所有权线索

UG1215 还列有 TOP_S 中 DDRS1 APB 配置口的 protection set/clear bit1、LOCK 中 DDRS1 写锁 bit10，以及可配置的 NPU group ID（文档复位编号3）。这提供了先前 DDRS1 读 bus error 的一种待核原因，但没有实时寄存器值或当前 BOOT 对这三处的执行证据，不能把原因判定为访问保护。当前 BOOT 同哈希备份复核通过；未做板上寄存器读写或 HardNPU START。静态细节见 `docs/research/HARDNPU_H1_DDRS1_CONFIG_PORT_20260925.md`。H1 首算仍 `NO-GO`。

## 2026-09-25 H1 DDRS1 补集保护几何候选

当前板只读 `/proc/iomem` 与设备树显示1 GiB DDR `0x00000000–0x3fffffff`。针对 UG1214 文档中的“region 未命中默认允许”，提出不依赖区域重叠优先级的候选：四块 H1 DMA 分配之外的 DDR 补集划为互不重叠禁止区。若每区至少支持任意4 KiB对齐且最多256 MiB的连续跨度，四块缓冲最多产生五段空隙，理论上至多八个 region。抽象规划器完成恰8区边界、10,000个确定性布局与无效输入拒绝；它不生成寄存器写值。当前芯片 region 数/跨度、SAR/EAR 端点、NPU group/路由、实时访问权及超时排空仍未验证；此前直接读 DDRS1 CTRL 发生 bus error，不重试。状态 `GEOMETRY_FEASIBLE_CONDITIONAL`，真实首算仍 `NO-GO`。见 `docs/research/HARDNPU_H1_DDR_COMPLEMENT_GEOMETRY_20260925.md`。

## 2026-09-25 H1 完整厂家 LoadNetwork 软件 packet

在板端私有无真实设备环境中，冻结 ONNX 经厂家 parser→Optimize→runtime→`LoadNetwork` 成功，网络 ID 0 的输入/输出分别为37,632/12,544字节，随后 `UnloadNetwork` 成功。受限虚拟 CMA 提供两次合成分配/匿名映射和四次区间内同步；在520字节设备同步前捕获的130个 packet 字与 Sol/Astra 先前独立厂家 packer 捕获逐字相同，差异0。软件链状态提升为 `SOFTWARE_LOAD_NETWORK_PACKET_EXACT_MATCH_SIMULATED_DEVICES`；`Execute` 未调用，真实 DMA/MMIO/IRQ 和 CPU 金样输出仍未验证。三只占位普通文件最终仍0字节，真实 NPU/CMA 节点不存在、模块表空、U盘卸载。原始板端日志与回收归档 SHA 对齐，详见 `docs/research/HARDNPU_H1_VIRTUAL_CMA_LOAD_PACKET_20260925.md`。首次硬件 START 仍 `NO-GO`，继续解决地址约束、复位/IRQ和故障排空。

## 2026-09-25 H1 厂家 CMA 与独立驱动接口边界

只读核对冻结公开 `cma_mem.c` 与 Arm NN `cma_mem_init.hpp`：厂家 `LoadNetwork` 路径所需的 CMA 驱动以自身 misc device 分配 coherent 内存，暴露独立 ioctl/mmap/物理地址接口；当前 H1 独立驱动的四缓冲及内核 packet 地址与此接口并未集成。旧日志中 `/dev/cma_mem` 打开失败后出现 `std::bad_alloc`，但头文件中明确的 CMA 分配失败派生异常文案是 `cma alloc failed`，不能从日志唯一定位异常来源。公开驱动的同步 ioctl 未见 fd 分配区间检查，不能原样作为 H1 安全运行入口。本节当时提出的受限虚拟 CMA 软件实验已由上节完成；真实首算继续走独立四缓冲候选并保持 `NO-GO`。见 `docs/research/HARDNPU_H1_CMA_LOADNETWORK_CONTRACT_20260925.md`。

## 2026-09-25 H1 DDRS1 未命中规则收窄

复用 Sol 已核验的 UG1214 v1.3 第33章 MPU 结论：文档规定区域未命中时默认放行；因此只配置 H1 四块 DMA 缓冲的允许区域，不能据此构成 DDR 地址白名单。该章的 RASR bit10 未配置区域保护说明又与本地 UG1215 HTML/BSP 的保留位定义冲突，不能在当前芯片直接写入。当前硅片/启动状态的实际未命中行为仍 `UNKNOWN`，DDRS1 仍仅是 HardNPU 主 DDR 保护候选。已审现有 H1 驱动控制路径，未发现可消除该地址边界缺口的现成机制；未运行硬件。首算保持 `NO-GO`，先解决匹配版本的地址约束、复位资源、IRQ 和故障排空，再单独审查首次 START。详见 `docs/research/HARDNPU_H1_DDRS1_MPU_CANDIDATE_20260924.md`。

## 2026-09-24 H1 Optimize 图与冻结 packet 身份核对

只读交叉验证新优化图、原 CPU 夹具及 Sol/Astra 先前厂家 packet：同一 ONNX 哈希、单个 `ALHardNPU` 层及五层 `Alnpu` 归属、输入/权重/bias/输出几何和量化字段、权重/bias 逐字节、旧包13项/130字与64个 bias 字均匹配；包内三个原始数值也与夹具对应值一致。见 `docs/research/HARDNPU_H1_OPTIMIZE_PACKET_IDENTITY_BRIDGE_20260924.md`。状态仅 `IDENTITY_AND_RAW_VALUE_MATCH_LIMITED`；旧包是独立直接构造 workload 捕获，当前 `LoadNetwork` 未通过，不能称已验证完整模型到 packet 运行链或硬件计算。

## 2026-09-24 H1 模拟设备 runtime 与 LoadNetwork 停点

在前述相同隔离/虚拟 ABI 下，厂家 `IRuntime::Create` 成功，设备列表包括 `Alnpu`。另一个仅到 `LoadNetwork` 的探针完成 parser、Optimize 和 runtime 构造后，多次遇到私有环境 `/dev/cma_mem` 缺失，最后抛 `std::bad_alloc`；`LoadNetwork` 未通过，也未执行 `Execute`。CMA 错误与异常相邻，完整因果仍 `INFERRED`。已回收两份目标日志并核对归档哈希，见 `docs/research/HARDNPU_H1_VIRTUAL_RUNTIME_LOAD_BOUNDARY_20260924.md`。已有独立 host-backed workload/packet 证据不重做；真实 H1 首算仍 `NO-GO`。

## 2026-09-24 H1 虚拟设备条件下的真实厂家 Optimize

在无真实设备节点的私有根、降权、关闭继承 FD 与 ptrace 默认拒绝规则内，新增仅对两个已审计普通文件 FD 响应 Hard/Soft 寄存器信息查询的显式虚拟模式，匹配的寄存器共享映射被改为匿名内存。板端独立 ABI 探针验证两次查询、两次匿名映射和错误 ioctl 拒绝；关闭虚拟模式后首个查询仍被默认拒绝。复用冻结 ONNX/厂家库重建目标探针后，真实 Arm NN `Optimize` 返回成功，产生5层优化图，其中单 Conv 为 `ALHardNPU` 且冻结私有 ABI 与 DOT 均标为 `Alnpu`；优化后权重/bias 哈希与冻结输入相同。CMA 节点在私有根不存在，打开失败仍未阻止此阶段完成。原始输出及日志已串口回收并按归档哈希核对，见 `docs/research/HARDNPU_H1_VIRTUAL_OPTIMIZE_20260924.md`。结论为 `SOFTWARE_OPTIMIZE_PASS_SIMULATED_DEVICES`，不代表真实驱动、workload、packet 或硬件计算；H1 首次 START 仍 `NO-GO`。

## 2026-09-24 Sol Soft DDR 与 H1 DDRS1 证据对照

复核 Sol 的 v0.5.4 固定 Pool normal-mode system-DDR 单次板测：三块 Soft 设备自有4KiB coherent 缓冲、严格 IRQ `0x4`、8字节输出和完整缓冲回收逐字节通过，结论限 `BOARD_PASS_LIMITED`。H1 已借用其自有 DMA 缓冲、guard、故障固定和冷恢复方法，现有四缓冲/无写入地址轨迹不需重复。Soft 走 PL HP1，不能证明 HardNPU 的 DDRS1 保护、真实 Conv/IRQ 或超时后排空。见 `docs/research/HARDNPU_H1_DDRS1_MPU_CANDIDATE_20260924.md`。

继续核查通用 MPU SDK：DDRS1 是 device ID 1，仅有普通区域 0–7；初始化会先禁用 MPU 再配置、启用。现有芯片初始化只配置 device ID 6 的 APU MPU，不能迁移为 DDRS1 已启用证据。DDR S1 未命中区域的行为仍 `UNKNOWN`，不得把区域配置当成 H1 四缓冲访问白名单。未执行 MPU 写入、真实 NPU START 或 Sol 板测重跑。

## 2026-09-24 当前 TF BOOT 的 DDRS1 初始化反汇编

找到与板卡当前 TF 逐字节同哈希的 BOOT.bin 电脑备份，并在板端只读挂载后复核相同 SHA-256。AArch64 反汇编确认其中被上层调用的启动函数先对 `0xF840E004`、再对 `0xF840F004` 读后清 bit0 并写回，即静态路径会关闭 DDRS0/DDRS1 MPU。未证明本次上电实际经过该分支或后续无人重配；实时 CTRL 仍因前述只读 bus error 而 `UNKNOWN`。已卸载 TF BOOT 分区。DDRS1 不得直接开启，H1 仍 `NO-GO`。见 `docs/research/HARDNPU_H1_CURRENT_BOOT_DDRS1_INIT_20260924.md`。

## 2026-09-24 HardNPU DDRS1 MPU 候选通路

UG1214 v1.3 将 HardNPU 描述为片上 AXI 主设备，直接读写 DDR；同版地址表把 DDRS1 MPU 归于 APU/RPU 以外设备访问 DDR 的 S1 通路，并列出 NPU AXI ID。结合 UG1215，这提示 DDRS1 可作为主 DDR 访问保护**候选**。通用 SDK 头文件给 NPU group ID=`0x8`，但当前硅片上的匹配、共享主设备影响、当前启用状态及故障/排空行为均未证。当前同哈希 BOOT 反汇编另见上节。板端一次 `devmem2` 只读该 CTRL 地址在实际读取时发生用户态 bus error，未取得值；串口/Linux 继续正常，无 NPU 节点或模块。已停止直接读该页，原因 `UNKNOWN`。首算仍 `NO-GO`。见 `docs/research/HARDNPU_H1_DDRS1_MPU_CANDIDATE_20260924.md`。

## 2026-09-24 Video NPU 手册与 HardNPU 边界

只读检查原工程 IPUG166 v1.0 全13页：该手册定义的是 DR1 PL 侧可定制 Video NPU，SoftNPU、CSC、Resize 的复位、IRQ 和 AXI 描述不能替代 PS HardNPU `0x63F00000` 的版本/bit2/复位/主 AXI 合同。当前 PL SoftNPU 配置身份仍 `UNKNOWN`；H1 首算维持 `NO-GO`。见 `docs/research/HARDNPU_H1_VIDEO_NPU_MANUAL_SCOPE_20260924.md`。

## 2026-09-24 H1 无桩 Optimize 首次驱动边界

复用冻结单 Conv ONNX 与目标探针，在板端私有普通文件占位和已通过19项负探针的设备遮蔽环境中推进真实 parser→Optimize。parser 导出的权重和 bias 哈希与 Sol/Astra 冻结夹具逐字节一致；进入 Optimize 后厂家库仍打开私有 `/dev/hard_npu` 并请求 `ioctl 0x4801`，被监督器按预定规则拒绝，未生成优化图。由此将 H1-02 的当前阻点精确定位为 Optimize 阶段的驱动初始化；没有无桩 Alnpu 归属，硬件首算继续 `NO-GO`。见 `docs/research/HARDNPU_H1_NOSTUB_OPTIMIZE_DRIVER_BOUNDARY_20260924.md`。

同版厂家库反汇编确认 `RegisterTensorHandleFactories` 相邻调用 Hard 与 Soft 初始化，两者分别需 `0x4801/0x5301` 及可写共享寄存器映射；软件分区不能只伪装 Hard 节点并称无桩真实后端。用户随后主动重启板卡，先前 `/run` 临时目录已清空；六项原始输出已在重启前回收至工作树。重启不是已证明的探针故障。

## 2026-09-24 H1 首次运行故障原因留存

沿用既有 H1 单次运行候选，给运行结果增加首个故障原因：复位路径/CRP 位、TOP 时钟读回、软复位超时、旧 IRQ 清除、寄存器提交、IRQ 状态、等待超时和数据完整性。`h1_stage_uapi.h` 升为 ABI 2，旧版程序在新版模块上被版本检查拒绝。新版源码传输哈希相同，目标模块与用户程序构建返回0；默认启动拒绝、冻结夹具预检、卸载均通过，状态 COLD、零写入。故障原因各真实分支及设备 IRQ/输出尚无板测，首算仍 `NO-GO`。板端本轮模块 SHA-256=`05bb0d4c02da8a1c4e6c95d2e15254d97118ca9b635e443b9f4ae0a059d04a88`，验收程序 SHA-256=`8faad41757d56a66b3553ba4265b3059c6ec26d3304c8efa6f9239541ea69d45`。

## 2026-09-24 H1 软复位和 IRQ 使能顺序

本地寄存器说明确认 `0x0000` 软复位 bit0 为写高脉冲、自动清零；候选读回轮询有文档依据。将 IRQ 使能从激活阶段移至冻结8笔轨迹的最后 START 写后，并在 START 前检查 IRQ 已登记，减少配置阶段把迟到事件认成本次完成的窗口。新目标构建与默认无启动预检通过；真实软复位/快速 IRQ 时序未测，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_SOFT_RESET_IRQ_ARM_ORDER_20260924.md`。

## 2026-09-24 H1 权重尾部哨兵和 AXI 字段核对

冻结 packet 的 `0x003C=0x0808` 仅声明最大突发长度/未完成数各8，不构成地址范围限制；本地 MPU_NPU/HPM 描述也不能证明 HardNPU 到 DDR 的隔离。将 H1 候选权重分配由12,288扩至16,384字节，追加4KiB `0xA5` 尾部、提交前检查和 DONE 后故障位。主机合同/状态机测试、目标构建、新 UAPI 程序的无启动预检及默认拒绝通过；没有真实 DMA 或尾部破坏板测，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_WEIGHT_GUARD_AXI_LIMIT_20260924.md`。

## 2026-09-24 H1 可选复位句柄实测及不碰 CRP 的实验候选

公开 HardNPU 驱动使用 optional reset，当前 TF/实时 NPU 节点无 `resets`；无启动模块在运行板端实测 `reset provider absent`。新增默认0的 `trust_boot_reset_release`：仅在显式声明且 reset 句柄缺失时，候选 RUN 路径可跳过已由 FPGA manager 持有的 CRP 窗口。新模块目标构建、仅开这一参数时的默认拒绝、原预检和卸载通过，TOP/CRP 未变；跳过 CRP 的真实路径未运行，释放态仍是基于私有源码的推断。IP/IRQ、AXI/超时等合同未闭合，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_OPTIONAL_RESET_ROUTE_20260924.md`。

## 2026-09-24 H1 一次性原始输出留存

首算验收程序后续修订要求执行前创建新的原始输出路径，只有完成并成功读取后才保存全部12,544字节，再比较冻结 CPU 金样。新板端构建、离线自比、无启动预检、两个模块参数默认关闭下的 RUN 拒绝与空文件清理均通过，TOP/CRP 未变；真实输出保存分支未运行。见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。HardNPU 首算仍 `NO-GO`。

## 2026-09-24 H1 当前 TF DTB 与 CRP 资源独占门禁

当前 TF `system.dtb` 的 NPU 节点与捕获的实时 FDT 所有属性逐字节相同，均为三段资源且无 `resets`；运行 `/proc/iomem` 确认 `0xF8801000-0xF8801FFF` 由 FPGA manager 持有。首算候选因此在 CRP 映射前新增独占资源申请，失败则拒绝启动。新板端构建、默认关闭模块的预检/卸载通过；实际申请失败分支与 NPU 启动均未运行。当前资源/复位归属仍未解决，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_BOOT_DTB_CRP_OWNER_GATE_20260924.md`。

## 2026-09-24 H1 冻结金样输出验收准备

沿用 Sol/Astra 冻结的输入、权重、CPU 金样和 130 字软件 packet，新增结果验收程序：默认预检只做冻结 CRC、暂存、8 笔地址轨迹、持有/释放及 COLD/零命令核验；独立 `--execute` 路径可在将来受控首算后读取12,544字节并与金样逐字节比较。本轮最终源码与板端副本哈希一致，目标 GCC 严格构建、默认禁用模块的预检、卸载均通过；纯离线金样自比及单字节破坏判别通过。未执行真实运行或硬件输出比较。HardNPU 首算仍 `NO-GO`，需要硬件合同闭合与用户新的明确许可。证据见 `docs/research/HARDNPU_H1_OUTPUT_VERIFIER_20260924.md`。

## 2026-09-24 H1 完成后完整性故障隔离

修正一次运行候选：精确完成 IRQ 后若 packet、输入/权重 CRC、输入/packet/输出尾部任一异常，立即从 DONE_PINNED 转为 FAULT_PINNED；后续状态/输出读取继续复核，禁止把被破坏的结果当成完成。主机/板端状态机测试、目标内核构建、默认拒绝和既有装载/轨迹回归通过；真实 IRQ/硬件执行未运行，仍 `NO-GO`。见 `docs/research/HARDNPU_H1_DONE_INTEGRITY_GUARD_20260924.md`。

## 2026-09-24 H1 默认禁止的一次运行候选

在现有装载模块中接入 `RUN_ONCE/RUN_STATUS/READ_OUTPUT`、TOP 激活、冻结 8 笔提交、threaded IRQ 与1秒超时状态路径；所有进入路径要求两个默认关闭的装载参数、持续模块引用、CRC/哨兵/计划与 `CAP_SYS_RAWIO`。目标内核构建及默认拒绝、既有载荷/轨迹回归、卸载通过，TOP/CRP 值未变；实际执行分支未运行，参数声明不构成硬件身份验证。当前 IP/bit2、复位绑定、AXI/超时、量化与无桩后端仍缺，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_GATED_FIRST_RUN_CANDIDATE_20260924.md`。

## 2026-09-24 H1 当前复位绑定冲突

实时 DTB 的 NPU 节点有第三段 CRP `0xF8801000/0x100`，却无 `resets`；板端私有内核 DTS 与公开 DTS 均为两段资源加 `resets=<&crp RST_NPU>`。第三段又落在当前 FPGA manager 的 `0xF8801000/0x1000` 资源中。板端只读 `CRP+0x74=0x73f0`，bit12=1；依私有源码仅可推断复位释放，TOP 时钟仍为0。当前启动 DTB 与私有源码不能当作同版，真实 START 的复位路径须先解决；首算仍 `NO-GO`。见 `docs/research/HARDNPU_H1_LIVE_RESET_BINDING_20260924.md`。

## 2026-09-24 H1 当前设备树资源及内核门禁

板端逐字节解出 HardNPU 三个设备树资源：主寄存器 `0x63F00000/0x100000`、TOP `0xF8800000/0x200`、第三段 `0xF8801000/0x100`，当前 IRQ 解析为 Linux 31。无启动模块新增 TOP 窗口/IRQ 探测门禁，目标构建、装载、原载荷/8 笔轨迹回归、卸载通过；没有映射或写寄存器、申请 IRQ、运行 NPU。首算仍 `NO-GO`，见 `docs/research/HARDNPU_H1_LIVE_RESOURCE_GATE_20260924.md`。

## 2026-09-24 H1 激活前缓冲锁定

沿用已有 H1 软件 packet 和目标端模块成果，把一次性提交包装扩展为“先锁定四缓冲，再调用硬件激活回调，再发送 8 笔命令”；激活失败零命令、故障固定且不可重试。主机及板端严格 C11 纯软件测试通过，源码哈希一致。尚未接 TOP 写、MMIO/IRQ 或运行 NPU；当前 IP/bit2、AXI 和超时合同仍待闭合，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_ACTIVATION_PIN_ORDER_20260924.md`。

## 2026-09-24 当前 NPU 顶层时钟实读

板端只读映射 TOP 配置页一次，`CFG_CTRL_NPU@0xF88001B8=0`；本地 UG1215 定义 bit0/bit1 为 NPU 功能/内部 RAM 时钟使能，故当前两者未使能。公开驱动在 probe 中写3，但本轮未执行该动作。`0xF8800030` 也实读为0，其 SRAM 掩码字段未由当前手册明确解释。无 HardNPU MMIO、驱动装载或作业；首算仍 `NO-GO`。见 `docs/research/HARDNPU_H1_LIVE_TOP_CLOCK_READ_20260924.md`。

## 2026-09-24 H1 持续模块引用进入板端模块

现有无启动 H1 模块已链接一次性状态机并新增 HOLD/RELEASE：仅在载荷 CRC、输出哨兵和实际 DMA 计划有效后持有真实内核模块引用，释放仅限 COLD。板端新 `/run` 构建及两轮装载验证通过；第二轮测试进程退出后模块仍被引用，普通卸载失败，另一进程在未启动状态释放后卸载成功。无 NPU MMIO/IRQ/作业；实际 START 接线、IP 身份与 AXI/超时合同仍缺，首算 `NO-GO`。见 `docs/research/HARDNPU_H1_PERSISTENT_OWNER_HOLD_20260924.md`。

## 2026-09-24 H1 模块卸载与缓冲生命周期

板端内核源码确认平台驱动 `remove()` 的非零返回会被忽略，因此不能用 `-EBUSY` 阻止在途 DMA 缓冲释放。现有无启动模块设置 `suppress_bind_attrs`，板端新 `/run` 构建/装载后 bind/unbind 文件确实缺失且原数据/轨迹测试通过；持有设备 FD 时普通 `rmmod` 被拒、关闭后可卸载。一次性状态机新增“模块引用已持有”前置条件，主机与板端纯软件测试通过。实际 START 路径尚未取得持续引用或执行设备操作，首算仍 `NO-GO`。见 `docs/research/HARDNPU_H1_MODULE_LIFETIME_GUARD_20260924.md`。

## 2026-09-24 H1 目标端实际 DMA 地址提交轨迹

在已有板端装载模块上新增无启动 PLAN_TRACE 接口，先从 coherent 目标区复核输入/权重 CRC 和输出哨兵，再以目标端真实分配地址运行 8 笔 packet-DMA 写值生成器；回调仅记录返回数据。新 `/run` 私有目录目标构建、一次加载/装载/轨迹测试/卸载均通过，测试报告 8 笔轨迹及四个非零对齐不同的地址，结束后设备节点和模块消失。内核未映射/写 NPU 寄存器或申请 IRQ；真实 AXI 和首算仍 `NO-GO`。证据见 `docs/research/HARDNPU_H1_BOARD_DMA_PLAN_TRACE_20260924.md`。

## 2026-09-24 H1 提交状态接线与中断使能冲突补证

沿用 Sol/Astra 冻结厂家软件包，核实第六项 `0x1020=7` 会写入本地 UG1215 标为保留的 bit2；同哈希厂家等待函数又检查 IRQ 状态 bit2，当前 IP 修订仍 `UNKNOWN`。将既有 DMA 发射器与一次性状态机接成 `h1_run_submit_once`，在首笔回调前锁定缓冲，任一 8 个写失败点进入不可释放故障状态；主机严格 C11 测试通过。回调仅为内存追踪，未接内核 MMIO/IRQ，未运行 NPU；首算 `NO-GO`。见 `docs/research/HARDNPU_H1_SUBMIT_STATE_AND_IRQ_MASK_20260924.md`。

## 2026-09-24 H1 一次性完成判据与当前 TF 身份

复核冻结厂家等待函数的结构体字段与分支：只有原始中断字恰为1且工作状态5才接受成功；bit1/bit2 错误位冲突可先通过“其余非零均故障隔离”保守处理，但当前硬件 IRQ 清除/迟到语义仍未知。新增一次性设备无关状态机，主机和板端 `/run` 严格构建/纯软件测试通过，开始后即禁止缓冲释放或重试，尚未接内核 MMIO。只读核对当前 TF 启动三文件哈希与 2026-09-14 同板备份一致，未能把其中 bit/IP 绑定到唯一源码或证明运行中无 JTAG 重配。详见 `docs/research/HARDNPU_H1_ONESHOT_IRQ_AND_BOOT_AUDIT_20260924.md`。硬件首算仍 `NO-GO`。

## 2026-09-24 HardNPU H1 中断位冲突

独立驱动准备中发现版本证据冲突：本地 UG1215 寄存器说明把 `0x1018` 地址错误状态列 bit1，冻结同哈希厂家运行库 `wait_for_hard_npu_irq` 反汇编却检查 bit2；两者都只把 bit0/工作状态5作为完成相关条件。当前 bit 身份未证，不得据任一单独来源实现最终错误/清除判据。详见 `docs/research/HARDNPU_H1_IRQ_BIT_CONFLICT_20260924.md`。本次未运行 NPU；首算继续 `NO-GO`。

## 2026-09-24 H1 目标端冻结数据装载

在前次四缓冲候选基础上新增限定原生 64 位 `/dev/h1_stage`：输入 37,632 字节和权重 12,288 字节各装载一次，内核从 coherent 目标区回算 CRC，并检查 16 KiB 输出 `0xA5` 哨兵。板端新 `/run` 私有目录构建返回 0；一次加载、测试、卸载均返回 0。目标端 CRC `49531080/9af5190b` 与电脑独立复算一致，错误 CRC/重复提交拒绝；卸载后模块表为空、HardNPU 平台设备未绑定。详见 `docs/research/HARDNPU_H1_TARGET_PAYLOAD_STAGING_20260924.md`。这是数据进入 coherent 缓冲的证据，尚无 NPU 主 AXI、MMIO、IRQ、结果或超时恢复；首算仍 `NO-GO`。

## 2026-09-24 H1 冻结数据与 packet 几何核对

新增只读交叉审计，将 Sol/Astra 冻结输入、权重、bias、CPU 金样与实际捕获的 13 项/130 字软件 packet 和分配容量连接：输入 37,632、权重 12,288、输出 12,544 字节声明一致，64 个 bias 字逐字相同。type-1 bias 是同一 `0x0044` RAM 端口连续写，不能当作地址递增；`0x004C=119` 与输出零点相同而 `0x0048` 使能为 0，实际量化语义仍待设备验证。见 `docs/research/HARDNPU_H1_PAYLOAD_PACKET_GEOMETRY_20260924.md`。这不证明线性数据布局或 AXI 范围；硬件首算仍 `NO-GO`。

## 2026-09-24 H1 四缓冲分配模块目标构建

更正上一节的构建树判断：板端标准 `/lib/modules/6.1.111-rt42/build` 不存在，但先前 SoftNPU 的私有 `/root/dr1_npu_module_build_20260914_r2/{source,output/kernel}` 仍在且 `kernel.release` 与运行内核相同。新增 HardNPU H1 四块 coherent 缓冲分配/校验候选，仅在板端新 `/run` 目录构建，返回 0；AArch64 模块 `vermagic=6.1.111-rt42 SMP preempt mod_unload aarch64`。一次加载走到四缓冲分配/校验成功分支，一次卸载后 `/proc/modules` 为空且平台设备未绑定。内核 `Module.symvers` 缺失和 clock-skew 警告仍在，精确源码同一性未知；外部模块加载留下 `tainted=4096`。详见 `docs/research/HARDNPU_H1_ALLOCATION_MODULE_TARGET_BUILD_20260924.md`。未映射/写 NPU 寄存器、未启动 DMA 或运行模型；HardNPU 首算仍 `NO-GO`。

## 2026-09-24 H1 packet-DMA 独立提交核心

沿用前人冻结 H1 软件 packet 与本日真实 `Execute` 分支捕获，新增固定首算夹具的纯 C DMA 计划校验和 8 次 packet-DMA 寄存器写序列回调。130/130 字与冻结捕获一致；主机及板端 `/run` 原生严格构建/纯软件测试均通过，覆盖精确写序列、8 个回调故障位置和 7 类非法计划。回调没有连接硬件，板端无 Hard/Soft/CMA 设备节点或加载模块；标准内核构建链接不存在，私有构建树见上一节。详情见 `docs/research/HARDNPU_H1_DMA_SUBMISSION_CORE_20260924.md`。这是驱动的可验证核心，不代表 DMA/Cache/IRQ/超时恢复、无桩后端、bit 身份或首算完成；HardNPU 硬件仍 `NO-GO`，视频保持后置。

## 2026-09-24 HardNPU H1真实Execute分派的软件截断实证

沿用Astra/Sol冻结的单层夹具和厂家packet，目标AArch64空设备隔离环境中一次执行到厂家`Execute`的提交调用入口并立即退出：**当前限定夹具实际选择packet-DMA提交**，`pkg_info+0x10=130`，包和输入/权重/输出字段与四种诊断哨兵对应。软件packet仍13项/130字且与2026-09-23实捕逐项相同；监督器PASS，独立审计14项通过。哨兵不是真实物理地址，未调用提交函数或硬件。详细原始日志、哈希和限制见`docs/research/HARDNPU_H1_PRE_SUBMIT_RUNTIME_CAPTURE_20260924.md`。这只关闭当前直接构造夹具的模式/字段来源缺口；无桩Alnpu归属、真实DMA范围/Cache、重排权重、独立驱动、bit身份及首算仍`OPEN/NO-GO`。公开寄存器说明的软复位不提供AXI排空保证，超时缓冲不得据此归还。

## 2026-09-24 HardNPU既有成果复核与有界CMA软件探针

重新对照Astra方向审查、Sol H1阶段交接、2026-09-23真实packet及目标端后端报告：H1真实模型派生单层路线已定，CPU金样与parser已具限定证据，厂家直接构造路径已捕获13项/130字软件packet；无桩Optimize/Alnpu归属、真实`pkg_info`及执行模式、独立Hard驱动的DMA/Cache/IRQ/超时停止合同和硬件首算仍未完成。新目标端有界主机CMA替身一次运行越过`Pool::Acquire`/`cma_mem_alloc`，在`Pool::GetPhyAddr`入口安全退出，监督器PASS；该哨兵不是物理地址，不能用于硬件。详情见`docs/research/HARDNPU_H1_POSTPACK_HOST_CMA_TARGET_20260924.md`。未使用的同哈希重复候选已删除；不再逐个函数机械增加探针。HardNPU硬件仍`NO-GO`，视频按用户优先级后置。

## 2026-09-24 HardNPU打包后Pool目标端实证（当时阶段）

在板端新`/run`私有目录严格构建并于空设备根中运行一次派生门禁；五项负探针及监督器通过。冻结厂家软件包再次得到13项/130字且与前次逐字相同，但packer返回后**首先触发`Pool::Acquire` tripwire**，未到`Pool::GetPhyAddr`；外层退出3、监督器报告FAIL（被拒系统调用0，失败退出3）。这是保护性中止，不能记为门禁PASS。原始日志哈希回传一致，见`docs/research/HARDNPU_H1_POSTPACK_POOL_TARGET_20260924.md`。静态复核SmallPool路径仍会调用CMA分配，下一步须设计有界主机内存替身；真实`pkg_info`、Execute模式、硬件首算继续`UNKNOWN/NO-GO`。U盘只读挂载后已卸载，未加载驱动或修改持久产物。

## 2026-09-24 HardNPU打包后Pool边界候选

从冻结软件捕获门禁派生仅用于设备遮蔽环境的候选：保留有界打包，返回后在`Pool::GetPhyAddr`入口记录并立即退出，不读取物理地址；其余23项设备/CMA/提交tripwire保留。冻结源码哈希一致，派生源码差异审查与主机C++17严格语法通过。目标AArch64构建、私有根运行与真实边界触发**均未做**，不能因此推进到`Execute`或首算。见`docs/research/HARDNPU_H1_POSTPACK_POOL_BOUNDARY_CANDIDATE_20260924.md`。

## 2026-09-24 HardNPU Execute截断位置静态补证（后续运行已见首节）

同哈希厂家ELF两处`Execute`模式分派及normal/packet-DMA提交调用已逐指令核对，提交函数均有动态JUMP_SLOT重定位，后接IRQ等待；离线断言通过，见`docs/research/HARDNPU_H1_EXECUTE_SUBMIT_BOUNDARY_20260924.md`。这只是截断点设计输入，实际符号抢占未运行。打包后、提交前仍可能触发Pool物理地址/指针、CMA同步与容量不足的Acquire分支，故现有软件包不能直接推进到`Execute`或硬件。真实模式与`pkg_info`仍`UNKNOWN`，首算`NO-GO`。

## 2026-09-24 HardNPU优先及首算离线门禁（当时阶段）

按用户最新顺序先完成HardNPU，再处理视频流；视频隔离复位候选保持未验收状态。新增`audit_first_run_gate.py`，只读交叉核对冻结13项/130字软件packet、独立校验、同哈希厂家静态字数桥接及两种条件提交分支。7项一致性检查通过，输出`docs/records/hardnpu_h1/2026-09-24-first-run-gate.json`，硬件判定仍为`NO-GO`。真实`Execute`点模式与`pkg_info`、DMA地址/范围和缓冲所有权、权重重排/scratch、独立Hard驱动中断/超时/停机、当前bit/DTB身份及无回退分区均未闭合。此工具不接触设备，不授权首算；本轮未运行HardNPU。下一步优先构建受隔离的软件截断探针，取得实际`Execute`点模式和`pkg_info`，在任何设备写入前退出并独立复核。 

## 2026-09-24 视频状态域复位同步器候选

新增PS复位/PLL失锁异步断言、`p2f_clk0`两拍释放的状态域复位模块和状态路径顶层，独立TD综合378 LUT/345寄存器/360 slice，74独立IO无约束及未驱动归零警告仍在。保存`uidbuf`同一复位输入还跨摄像头写与显示读时钟域，FIFO及在途FDMA写响应的复位次序未解决；当前同步器只覆盖UI/PS状态域。见`docs/research/VIDEO_RESET_SYNCHRONIZER_CANDIDATE_20260924.md`。无RTL仿真、GP0 SoC生成或板测，采帧仍`NO-GO`。

## 2026-09-24 帧状态同域条件与视频会话复位

保存视频`uidbuf`帧事件、FDMA AXI和隔离写响应保护器均处于`p2f_clk0`域；若隔离生成的GP0主口与AXI-Lite从端也接`p2f_clk0`，状态路径可同域实现。当前GP0未开启，该条件未获生成连线证明。候选桥新增独立`FRAME_RESETN`，使摄像头PLL失锁导致的帧会话复位与PS AXI总线复位分开；TD隔离独立综合377 LUT/343寄存器/359 slice，74独立IO无约束且仍有未驱动归零警告。复位同步释放、RTL仿真、SoC生成/时序/板测均未完成。DI手册还明确悬空时钟/复位与地址检查不阻止生成，故生成后必须审查实际连线。见`docs/research/VIDEO_STATUS_CLOCK_AND_RESET_AUDIT_20260924.md`。VID-001当前采帧仍`NO-GO`。

## 2026-09-24 视频SoC隔离源副本

新增受六文件SHA与68项源引用约束的准备工具，仅在`experiments/video_soc_source_stage_20260924_1/`复制视频工程`uisrc`和项目入口，并重绑旧项目/IP/catalog绝对路径。源/副本均306个`uisrc`文件，只有两份路径元数据不同；生成HDL逐字节相同。清单明确`generate_done=false`、`gp0_enabled=false`、`soc_build_done=false`。这是供后续Design Integrator探索的**隔离源阶段**，还不是GP可读、完整综合或可上板系统。见`docs/research/VIDEO_SOC_SOURCE_ISOLATION_20260924.md`；VID-001采帧仍`NO-GO`。

## 2026-09-24 视频参考SoC GP状态通路集成前审计

新增只读结构审计`tools/video/audit_video_gp_integration.py`并输出六文件哈希及连接证据：参考视频PS两层配置GP0/GP1与F2P IRQ关闭，活动实例仅PS和uiFDMA，控制总线连接与地址源均为0，生成HDL无GP0。参考工程的自定义IP、IP目录及项目入口仍有旧机器绝对路径。故候选AXI-Lite桥目前**仅独立综合**，CPU→PL状态路径未实现；隔离SoC生成前须重绑路径、设置非冲突地址、确认GP0与帧事件同接p2f_clk0并解决复位会话；若使用异域时钟才需原子跨域快照。见`docs/research/VIDEO_GP_STATUS_SOC_INTEGRATION_AUDIT_20260924.md`。本次未生成SoC、bit或板测；当前Linux采帧仍`NO-GO`。

## 2026-09-24 帧状态只读AXI-Lite桥独立综合

新增`fdma_frame_status_axi_lite.v`，同域提供14项帧状态寄存器的只读AXI-Lite访问，非法读/所有写以`SLVERR`拒绝。仅在`experiments/video_status_axi_synth_20260924_1/`做TD 6.2.168116独立展开及综合，导出门级DB；面积报告378 LUT、343寄存器、361 slice。日志含未驱动信号归零警告与73个独立顶层端口无管脚约束严重警告，故**不可bitgen，也不代表完整SoC综合或时序通过**。证据见`docs/research/VIDEO_STATUS_AXI_LITE_STANDALONE_SYNTH_20260924.md`。参考视频PS GP仍关闭，AXI桥未接顶层、未仿真、未上板；当前Linux采帧`NO-GO`。

## 2026-09-24 三槽帧状态生产者RTL草案与故障拒绝

新增设备无关`fdma_frame_status_regs.v`草案，按参考`uidbuf`的帧同步槽变化和完成IRQ上升沿生成三槽开始/完成代数、写中掩码、完成序号及故障位；寄存器读复用器与C候选布局14项静态匹配。软件读取器/防覆盖判定补上故障位拒绝，隔离主机回归分别12/12、13/13通过。见`docs/research/VIDEO_FRAME_STATUS_PRODUCER_RTL_CANDIDATE_20260924.md`。**RTL未接视频顶层/PS总线且未仿真，复位期间UI时钟停顿仍可能漏记epoch；当前板端无这些寄存器，VID-001仍NO-GO。**

## 2026-09-24 多字段帧状态软件读取合同与PS GP缺口

只读确认视频参考PS配置`Master_AXI_GP0/GP1`均关闭，生成系统没有CPU→PL控制主口；主工程另一套配置虽启用GP，不能直接移植其生成连线。新增候选状态寄存器布局和设备无关的有序32位读取器，经隔离主机严格编译与10项检查通过，可在错误ID/ABI、奇数或变化版本、总线读取失败时拒绝快照。证据见`docs/research/VIDEO_FRAME_STATUS_READER_CONTRACT_20260924.md`。**候选ID/地址偏移尚无PL寄存器、AXI从设备、Linux驱动或板端实读**；VID-001硬件状态通道仍`OPEN`，当前DDR门禁仍`NO-GO`。

## 2026-09-24 PS单比特GPIO故障输入候选

参考PS配置确有1位`pl_gpio_in`，但生成`system.v`把它固定接0。隔离候选`experiments/video_commit_candidate_20260924_2/`现把FDMA写响应保护器的粘性故障位接入该输入；源配置/端口/差异8项静态核查通过，见`docs/research/VIDEO_PS_GPIO_FAULT_PATH_AUDIT_20260924.md`。**只有故障位候选，没有帧序号、槽号、PS多字段状态接口或Linux读取验证**；RTL仿真至板测均未完成，当前Linux帧缓存仍`NO-GO`。

## 2026-09-24 参考FDMA写响应完成语义修正候选

只读源码确认保存`uiFDMA.v`在最后AXI W握手就撤销`O_fdma_wbusy`，B通道虽始终ready却未检查`BVALID/BRESP`；原`uidbuf`整帧IRQ因而不能单独证明DDR写响应成功。新增独立`fdma_write_commit_guard.v`，并从SHA固定的参考顶层与生成`system.v`派生隔离连线候选：每次FDMA请求等待全部B响应且为OKAY后才向`uidbuf`释放忙状态，错误锁定。10/10静态核查通过，证据见`docs/research/VIDEO_FDMA_AXI_B_COMPLETION_AUDIT_20260924.md`。**RTL仿真/综合/P&R/bit/板测未做，PS可读状态仍缺，当前Linux内存所有权仍NO-GO。**

## 2026-09-24 当前Linux设备树与FDMA帧槽保留区离线候选

COM4只读取回当前运行中的20,480字节设备树，PC/板端SHA-256同为`8454c5d088f038833ea1b49d79f053f8feeafff6758731f71251d05bda1bd56d`。实读`/reserved-memory`只有动态128 MiB CMA，无固定参考帧槽。新增隔离工具以源DTB哈希和冻结DDR审计为输入，在**离线候选**中添加`0x0A000000..0x0B7FFFFF`的`no-map`固定保留区；候选哈希`1dab07ac923b131808663aee3480b48d9895d921d1cf3f02d4c29ab41f48d8d7`，解析回读、树结构差异及错误输入拒绝通过。证据见`docs/research/VIDEO_FDMA_DTB_RESERVATION_CANDIDATE_20260924.md`。候选未加载，当前Linux依然无该保留区，且PS帧状态、Cache和产品bit身份未解决；VID-001板端采帧仍`NO-GO`。

## 2026-09-24 VID-001 帧交接防覆盖主机门禁

新增与设备总线解耦的三槽帧状态检查模块`implementation_video/include/frame_guard.h`、`src/frame_guard.c`。主机严格编译及11项检查通过，能在状态版本读取不一致/更新中、同槽重写、复位、非法槽和无完整帧时拒绝CPU拷贝结果；其他槽写入不会误拒绝。详见`docs/research/VIDEO_FRAME_GUARD_HOST_20260924.md`。**这只实现消费者判定，没有硬件状态生产者、PS可读通道、Linux驱动、DDR保留、Cache同步或真实帧采集。** COM4再次只读确认原Linux及设备树`reserved-memory`无`reg`子项输出；现有参考FDMA槽仍不得直接用于当前Linux。VID-001继续`NO-GO_CURRENT_LINUX_MEMORY_OWNERSHIP`。

## 2026-09-24 离线FDMA帧到空间模型的显式输入探针

新增只接受**离线文件**的`fdma_frame.py`和`probe_fdma_snapshot.py`：调用方明确声明像素字节序、宽高、行跨度、裁剪区域和可选完整槽大小，随后按新导出清单的预处理合同生成FP32张量并运行空间ONNX。从冻结公开测试PNG构造含行填充与裁剪偏移的合成BGRX帧，解码RGB、归一化输入和128维空间特征与直接PNG路径逐字节相同；完整槽尾填充不影响结果，截断一字节在输出前拒绝。证据见`docs/records/model_pipeline/2026-09-24/offline_fdma_frame_probe_audit.json`和`docs/research/OFFLINE_FDMA_FRAME_TO_MODEL_PROBE_20260924.md`。这是PC合成输入，不是IMX415真实帧或板端实时推理；实际字节序、ROI、缓存所有权、帧完成与时序均未验收。另只读核查参考demo生成`system/hdl/system.v`：只开放FDMA到PS HP0的内存通路，没有PS可读取的PL帧状态接口，VID-001隔离集成还需补状态/中断通道。

## 2026-09-24 IMX415参考帧槽与当前Linux内存所有权

COM4只读实读当前`6.1.111-rt42`的`/proc/iomem`、`/proc/cmdline`、视频节点和模块：`0x00000000..0x3FFFFFFF`是System RAM，未列有覆盖`0x0A000000..0x0B7FFFFF`的保留区；无`/dev/video*`和`/dev/media*`，`lsmod`为空。对保存参考demo有效顶层`system.v`及`uidbuf.v`复算：FDMA从`0x0A000000`使用3×8 MiB槽，写1920×1080×4字节帧，读左上1024×600、每行按1920像素步长；写完成IRQ/写缓冲编号在顶层未接给PS。**若在当前Linux内存布局下加载该demo写路径，PL帧写会指向Linux管理的RAM，不能直接接入或采帧。** 当前板卡是否运行该demo bit仍`UNKNOWN`，本次未加载任何bit。证据为`docs/records/video_demo/2026-09-24/board_linux_video_memory_probe.txt`、`ddr_overlap_audit.json`和`docs/research/IMX415_DDR_LINUX_MEMORY_AND_CAPTURE_AUDIT_20260924.md`。VID-001下一门槛是隔离集成设计中的DDR保留/分配、Cache所有权、完整帧事件/防覆盖，以及实际产物身份与原始帧对照。

## 2026-09-24 模型导出与回放预处理合同

新`export_onnx.py`从checkpoint内配置写出`sign-rgb-preprocess-1`合同（RGB、Pillow双线性、UINT8转FP32除255、224×224、mean/std），`continuous_replay_onnx.py`按合同预处理并与空间ONNX固定输入尺寸核对。冻结v2-finetune checkpoint在隔离目录重新导出，空间/时序ONNX哈希仍为`30e290aa1441a818178be38b1c9a27aba0f0d4a8f9edd27d54d34cfbe1c71fee`/`d452b0f297196a390cf4295c3db6842399a1f53168d249139e299d2e136de0dc`，新清单SHA-256=`fd1c99777115beba1fe4d3fcf34f58c2455d511f56c4eeacf5ecdc194577a970`。新清单完整PC回放376帧/12事件/弱标签相符9段，事件类别和帧位与前轮对齐回放12/12一致。旧冻结清单缺合同，只在显式提供对应配置时运行；该配置与checkpoint内配置本轮核对完全相等，但旧清单自身无法证明绑定。缺配置或故意将输入尺寸改为112×224均在生成输出前拒绝。证据：`docs/records/model_pipeline/2026-09-24/preprocess_manifest_binding_audit.json`、`docs/research/MODEL_PREPROCESS_MANIFEST_BINDING_20260924.md`。验收仅`PC_EXPORT_AND_REPLAY_CONTRACT_PASS_LIMITED`；不涉及新模型精度、板端视频/NPU/V4R。

## 2026-09-24 连续回放预处理对齐后完整复测与板端只读复核

附加核验：新字幕视频可重新解码为376帧、8fps、256×256。原工程F盘受保护V2清单17/17哈希匹配；当前工作树同清单仅14/17匹配，3个二进制路径不是原始基线字节，不能把工作树写成17/17。指定外部快照和其父目录不存在，状态`UNKNOWN`；原工程整树前后状态`UNKNOWN`。

在工作区`experiments/model_replay_20260924_1/`隔离复制已修改的回放程序及共享预处理，使用原冻结12段CSL-Clinic测试片段、同哈希空间/时序ONNX和既有隔离Python环境完整运行。产生376帧（288源帧、88测试黑场）及12个事件；与旧版逐事件比较，仅事件8由弱标签“发烧”对应的旧预测“发烧”变成“咳嗽”，发出帧275变为279；弱标签相符数从10/12降为9/12。全部288个源PNG经Pillow与OpenCV转RGB解码的像素完全一致，说明本次差异在此前已识别的缩放/归一化路径，而不是这批文件的解码差异。详见`docs/records/model_pipeline/2026-09-24/replay_rerun_comparison.json`及`docs/research/MODEL_REPLAY_PREPROCESS_RERUN_20260924.md`。这只是公开弱标签、显式黑场边界的PC回放，不能当产品准确率或DR1板端实时性能。

用户提供COM4登录口令后，只读登录原Linux `6.1.111-rt42`：`lsmod`为空，`/dev/hard_npu`、`/dev/soft_npu`、`/dev/cma`均不存在；`/dev/sda1`未挂载，`/run`为tmpfs，所查`dmesg`异常关键词无输出。没有运行NPU、装载模块、改写TF/U盘或触发硬件。硬件首算仍`NO-GO`。

## 2026-09-24 模型逐帧预处理对齐

本节保留首次16帧黄金核对的当时状态；其中“完整回放未运行”已由上节的后续复测更新。

训练数据集原用Pillow RGB双线性缩放，连续ONNX回放原用OpenCV线性缩放，插值接口不一致。现提取共享`normalized_rgb_chw`，让训练数据集与回放的逐帧输入使用同一Pillow路径；`sign_model`包顶层改为延迟导入，保证仅导入预处理时不强制加载PyTorch。用冻结CSL-Clinic真实视频的16个采样帧，与原`normalized_video_f32_le.bin`逐元素精确比较，16/16差异为0；审计JSON为`docs/records/model_pipeline/2026-09-24/replay_preprocess_golden_audit.json`。此结果只证明共享函数对该冻结输入的PC黄金一致和回放源码接线；当前环境缺OpenCV、ONNX Runtime、PyTorch，新回放完整推理、板端摄像头和产品精度均**未运行/未提升**。详见`docs/research/MODEL_REPLAY_PREPROCESS_ALIGNMENT_20260924.md`。

## 2026-09-24 IMX415→DSI参考demo只读身份清单

按端到端路线先盘点可显示demo的15个关键文件，当前工作树清单与原工程对应文件只读哈希15/15一致。保存工程声明`uisrc/01_rtl/system.v`为`system_top`源，布局布线bit与`best_result` bit同哈希；SDK平台bit却是另一份。demo根与`05_boot`下两个BOOT字节不同；根BOOT完整包含一次当前`fdma_en.bin`（偏移3,374,016，长度122,024），但`output.bif`引用外部旧工程绝对路径且本demo缺该FSBL。**不能由这些文件反推用户所见屏幕画面的实际BOOT/bit/ELF组合**。保存P&R报告setup/hold正裕量`+7.748/+0.039ns`，其STA coverage仅4.11%；准确屏幕型号仍`UNKNOWN`，旧ROM路径中的HX8279D名称不作型号证据。清单与边界见`docs/research/IMX415_DSI_DEMO_IDENTITY_AUDIT_20260924.md`。VID-001/DISP-001仍未进入产品集成验收。

## 2026-09-23 H1厂家模式变量目标端只加载实读

同日离线交叉核对同哈希ELF的`r_HardNPUDriver`：packer以编码参数0生成vector后，`0x3cc1c0/0x3cc1d0/0x3cc1e0/0x3cc1f0`依次取首尾指针、求字节差、右移2位、存入`pkg_info+0x10`。实捕13项packet为130字/520字节，若同一包继续到该静态路径，字数应为130。审计脚本`audit_pkg_word_count.py`对ELF指令和实捕JSON哈希逐项断言，结果`pkg_word_count_static_bridge.json`为`STATIC_COUNT_BRIDGE_PASS_LIMITED`。真正`pkg_info`和`Execute`未捕获，不能写成运行时提交长度。

板卡本次接入时先前易失`/run/h1_isolation_audit_20260923_1`不存在；同哈希厂家库仍在。于新`/run/h1_mode_load_20260923`重建只加载探针、精确pre-exec启动器和同源码哈希ptrace监督器。探针在私有根空`/dev`、无`/proc`/`/sys`、uid/gid65534、no-new-privileges、FD≥3关闭、外层15秒限时及load-only规则下，仅`dlopen`厂家库、`dlsym/dladdr`核对`run_npu_in_dma_mode`归属并读该4字节对象；结果`after_vendor=1`。监督器`PASS gate_execs=1 denied_entries=0 denied_exits=0 failed_exits=0`。同规则的五项负探针均得到`EPERM`，总8次拦截中另3次为探针自身loader搜索。原始stdout/stderr回传哈希一致，见`docs/records/hardnpu_h1/2026-09-23/dma_mode_load_stdout.txt`及研究报告。接受状态仅`TARGET_VENDOR_LOAD_MODE_1_DEVICE_BLIND_LIMITED`：证明**本次厂家库加载后的变量值**，不证明载荷、模型构造或`Execute`时值不变；`Execute`、提交函数、真实驱动、DMA和HardNPU均未运行。当前板端模块为空、真实Hard/Soft/CMA节点缺失，硬件首算保持`NO-GO`。本轮目标产物位于`/run`，但未显式设置编译器`TMPDIR`，而`/tmp`在根分区；编译临时根分区写入状态`UNKNOWN`，后续必须显式指向`/run`。

## 2026-09-23 H1厂商Execute静态默认packet-DMA分支复核

只读核验同哈希厂家ELF：`run_npu_in_dma_mode`为`.data`中的可写4字节导出对象，文件初始值1，`Execute`通过GOT重定位`0xd31908`读取并按零/非零分派normal/packet-DMA。**本次直接构造捕获没有调用Execute，运行时实际值仍UNKNOWN；packer mode 0不等于Execute normal-mode。** 对`run_npu_hard_dma_mode`128字节函数逐指令核对：若选packet-DMA，先写`0x0050/0x2000/0x2004/0x6000`，再写`0x003c=0x1010`、`0x100c=packet物理地址`、`0x1010=packet字数`，最后`0x1000=1`启动。静态审计工件`docs/records/hardnpu_h1/2026-09-23/dma_mode_static_audit.json`。该包尚无真实物理地址、DMA/IRQ/停止合同，未执行此分支或NPU；H1首算继续`NO-GO`。上一节104字normal-mode展开仅为零值条件分支，不能称作默认写序。

## 2026-09-23 H1 normal-mode重放偏移碰撞审计（离线）

以板端实捕13项packet和冻结厂家`run_npu_hard_normal_mode`反汇编为输入，独立离线展开其**推定调用参数**：104个payload字对应99个不同偏移；若真实`Execute`选择normal-mode，加`pkg_info`的4个前置写，共108次推定`hard_npu_write`调用。bias type-1块从`0x0044`连续64字，包含一次`0x0050`，与前置`0x0050`发生顺序重叠；包内`0x0048/0x004c/0x0054/0x0058/0x005c`各被两项触及。后续只读反汇编纠正了`0x0050`标签：`pkg_info+0x18`为Execute写入的控制选择值，**不是已证明的物理基址**；后三项`0x2000/0x2004/0x6000`才对应输入/权重/输出基址。直接构造捕获并未执行`Execute`，实际模式仍`UNKNOWN`。原“无独立前置entry”不表示`0x0050`不会在normal-mode重放时出现。审计工件为`docs/records/hardnpu_h1/2026-09-23/normal_replay_audit.json`，方法及边界见`docs/research/HARDNPU_H1_REAL_PACKET_CAPTURE_20260923.md`。本次没有运行厂家normal submit、设备写入或HardNPU；地址别名及副作用语义仍`UNKNOWN`，独立驱动白名单和首算维持`NO-GO`。

## 2026-09-23 H1冻结v2真实厂家软件packet捕获（设备遮蔽）

在板端`/run`的空设备私有根、uid/gid65534、继承FD关闭、stdin`/dev/null`、只读fixture和精确ptrace默认拒绝规则下，先由派生载荷完成**真实厂家`AlnpuALHardNPUWorkload`构造并返回**，再经冻结v2完整门禁单次调用其`r_HardNPUDriver`至厂家packer钩子。两级均零系统调用拒绝/零异常退出；对`hard_npu_driver_init`的独立合成负探针在构造/完整门禁各触发预期tripwire，五项限制调用在两种规则下均得`EPERM`。冻结厂家门禁和完整v2载荷目标哈希仍为`54efea766a4955e757806db71bf7c388e7dd2099331d9f4b04b0b9d9b249229d`/`87f0a67c847eab5c744014a9caf0555198d4ef2df5d02c35e1773c29525a379f`；最终监督器源码/二进制SHA-256=`b69b410cefcc771387a40ce335098acbae3da5a62a2fbcb5d1ca80126e575e26`/`fab9cfe935eae6b65ef0529b4c0998e4e1831fe8d4bf000f17bce959d1395d23`。

实捕mode 0为**13项、130字/520字节**，原始stdout/stderr SHA-256=`89345a41f717636f8ccad611143ef5530e3f87ee96ed9a0efbf0ac3f7ad25f7d`/`9d9e2cb739b52cda7210731d9a32bf8519a410d3b4726801b6500b332d39afb0`，已从板端回传至`docs/records/hardnpu_h1/2026-09-23/`且哈希一致。独立校验逐项复算packet header、地址编码与payload，64个bias字与冻结夹具一致。**2026-09-21静态12项/127字预测被证伪**：真实多type-0 `0x5040`一字`0x00611118`，其余12项完全一致；反汇编确认旧过滤范围多排除了`0x5040`。接受状态仅`VENDOR_PACKET_CAPTURED_DEVICE_BLIND_LIMITED`。该包含`0x1004=1`启动项，不能提交硬件；动态基址、DMA/IRQ、当前bit、独立驱动及无桩parser/Optimize ownership仍未闭合。板端模块列表为空、真实Hard/Soft/CMA节点缺失；**HardNPU首算继续`NO-GO`**。详见`docs/research/HARDNPU_H1_REAL_PACKET_CAPTURE_20260923.md`。

## 2026-09-23 H1冻结夹具的板端构造前预检

从只读冻结native-v2包取三份Conv张量输入，串口传至板端`/run/h1_isolation_audit_20260923_1/fixture`；板端回读SHA-256分别为输入`fbc6c29966252405dbef392a698b554b7e45b81ce3962d230e439dd7bff21a5e`、权重`66cbc396e77abe4c77b2e8fc514a5a9e1859cc0e433575b9e82b8e3d3750c623`、bias`710a3d9da29db0e9f94f8722d18e23829a605ace3563abb3ed1df596165a3f2f`，与冻结清单一致。派生预检源码逐字节保留冻结载荷从文件读取到厂商构造函数符号解析的前缀，并在实际构造函数调用前返回；派生源码SHA-256=`9958ae6e2c1cc5d35eb719d033d0fd28012b043c15c785ca623a86444156d767`，板端AArch64共享库SHA-256=`49c1566e3d2987a049a13fee2b4660526122a20be22fce8f7ffbcafea0feb7b7`。冻结v2源码和共享库保持不变。

在空`/dev`、无`/proc`/`/sys`、只读绑定、uid/gid65534、FD关闭和ptrace监督的私有根内，派生入口实读三份张量，完成`TensorInfo`/句柄准备、四个`vtable[15]`哨兵、`ALHardNPUQueueDescriptor::Validate`、保护页分配及厂商构造函数`dlsym`，然后返回`H1_PREFLIGHT_PASS`。首次探针因厂家库缺少`pthread_create`动态依赖失败；仅重链预检探针加入`DT_NEEDED libpthread.so.0`后通过。最终探针/启动器目标SHA-256=`adbeff35d73d048f76cf93e81386119ac88949c17a8e576d39ead5835f947b3c`/`71095916e3af40fce11bcfdafa034ccab467965a68287775e88a79650431ccfe`。

专用预检默认拒绝规则仅增加派生共享库精确只读路径和三份fixture的精确只读路径，监督器源码/目标SHA-256=`4794808d4fa8e516d2bec6f9bd54097f1429dc87160824d64b2a70280540b970`/`38c649455280872a3a103f563ec40e8c61724bd3eabc6329920e3871e139a274`。该规则下预检退出0，`gate_execs=1`、拒绝0、失败退出0，stdout/stderr SHA-256=`3179bbd5e615759e7013e11b08353d8dba264f704d28c4c811cd364b53beb413`/`121eeb7e165751c459e6862b25ff0854f8f08b6d6d82b568997d543f31a0e8a8`；既有五项负探针均获`EPERM`。接受为`TARGET_FIXTURE_AND_PRECONSTRUCTOR_PREFLIGHT_PASS_LIMITED`。**没有调用厂商workload构造函数或驱动入口，没有packet、DMA、IRQ或HardNPU计算**；原型仍非完整seccomp等效隔离，真实H1捕获和硬件继续`NO-GO`。板端`lsmod`仍为空，三个真实设备节点仍缺失。

## 2026-09-23 H1冻结v2载荷目标端只加载/入口解析

只读核查已编译载荷的`.init_array`，除编译器例程外含支持头`BACKEND_IDE`字符串初始化；随后在空`/dev`、无`/proc`/`/sys`、降权、关闭继承FD和ptrace监督的私有根中，仅`dlopen`同哈希厂家主库与冻结v2载荷，并用`dlsym/dladdr`核对`h1_capture_hard_packet`入口身份，**未调用入口**。专用探针/启动器源码SHA-256分别为`addaea017be56692a8510181e80de210037ddb6922b82518c13f03ee0406cd87`、`fb25683c3bdc611a257a7c633afb8ab750f87bf4cfdf03307eb8ea978a65c3bf`，目标二进制分别为`3e3c4d6767b2743f790aef57ee1e9587da8777eba6f29b98e79b2ec1638781fa`、`c63747b227fb173e8290cf655d02f7878333fdecc403c7f5c35d08f0c2e70e5e`。首轮得到`PAYLOAD_LOAD_ONLY_PASS`、零拒绝、零失败退出；实测123次系统调用、23种号、18个只读`openat`路径，比厂家load-only多载荷文件打开及`PR_GET_NO_NEW_PRIVS`等初始化调用。

为此增加独立的**载荷只加载**默认拒绝模式，监督器源码/目标二进制SHA-256=`4677821aca11e6aa5b1ea338c53a288fdf2b571b3922f69f46c5912eb49d8c4f`/`f5289cb781212b68f40403d4fdb05c21aa39c2b5daebcfaffd28df2a0ef35238`；仅额外允许精确载荷路径与`PR_GET_NO_NEW_PRIVS`。该模式复跑`PAYLOAD_LOAD_ONLY_PASS`、零拒绝/零失败退出，stdout SHA-256=`38372a26c5103924690dea065269c0c4c61901c76834fc43ca91c4126145122f`；五项受限负探针仍得`EPERM`，原厂家load-only模式复测仍PASS。接受为`TARGET_PAYLOAD_LOAD_AND_SYMBOL_PASS_LIMITED`，不代表载荷入口、厂家workload、entry/packet或硬件；真实H1捕获与首算继续`NO-GO`。

## 2026-09-23 H1 load-only最小系统调用面（仍非捕获门禁）

在同一板端私有根中记录成功的厂家load-only路径：目标进程114次系统调用入口、22种调用号，含17次`openat`；这17条均`AT_FDCWD`及只读`O_CLOEXEC`，路径仅为当次厂家/系统库搜索与`/etc/ld.so.cache`，未出现`ioctl`、共享映射或高号未知调用。基于此增加仅适用于**当前load-only二进制及库搜索**的默认拒绝模式，列出允许的调用及17个精确打开路径。首次模式漏列`geteuid/getegid`导致门禁身份检查失败；后续也删除两种未实测的`getuid/getgid`。最终源码SHA-256=`f6de18fad3e35434cb32319f456f5eee66858bafd3ddb0d5525c492801265425`、目标二进制SHA-256=`a26b30bea11324969f99937f6aa60a03851a20ab75caeef1c8560963d931bb78`；厂家load-only再次`PASS_DEVICE_BLIND`，监督器零拒绝/零异常退出，stdout SHA-256=`abb956c55c9136218a00a35a9ae950f97eff765d959819c6e9398d23a668a076`。独立负探针的五个意图受限操作均得`EPERM`；另有三次其自身loader路径搜索被拒绝。原19项负探针在默认模式重跑PASS；一次`openat2`合并测试因沙箱启动前失败不采信，单独重试得`EPERM`。此模式**未覆盖payload/workload**，完整隔离及真实捕获继续`NO-GO`。

## 2026-09-23 H1厂家门禁load-only目标复核（无载荷）

冻结门禁源码与外部包SHA-256一致（`c265b1af09bf41a8a91e5d6bc140d3fd374da05e3c9a3ffcc2225e8de89480e4`）。板端严格编译首次因g++预定义`_GNU_SOURCE`与源码重复定义而失败，改用`-U_GNU_SOURCE`后源码不变、编译通过。首次私有根`--load-only`在厂家`dlopen`处因库未声明但实际需要`pthread_create`而失败；仅重链门禁程序显式引入系统`libpthread.so.0`（目标门禁SHA-256=`54efea766a4955e757806db71bf7c388e7dd2099331d9f4b04b0b9d9b249229d`），`DT_NEEDED`核对后重试通过。受监督、空`/dev`、无`/proc`/`/sys`、降权和关闭继承FD的目标运行返回`PASS_DEVICE_BLIND`、厂家packer符号偏移`0x401b10`；监督器`PASS gate_execs=1 denied_entries=0 failed_exits=0`。成功stdout SHA-256=`b2e07f0c4fa9b811971e0bf0c1ac1eade58827ea6b96055e59273b40ea74ba14`，stderr为空。仅证明这一加载组合，未加载载荷共享库、未创建workload或packet；隔离仍`PARTIAL`，硬件`NO-GO`。

## 2026-09-23 H1隔离原型`openat2`缺口修复与负测试

独立无设备探针在旧监督器下用`openat2`成功打开私有根中**仅`/run`普通文件**占位的`/dev/hard_npu`，监督器记录零次拒绝，证明原系统调用覆盖有缺口；没有打开真实节点。修正版明确拒绝`openat2`，并在`openat`路径无法读取或超长时直接终止。修正版源码SHA-256=`6baf65deac70c7b452cbae8deb8a1a2a894e84d7dfea2c473f9099fdc085c4c9`、板端二进制SHA-256=`0a6081a86ac3219d570e3d89520e1527dbd3a0e9540fd0ae291634ad696fc391`；同一`openat2`探针现在得`EPERM`、监督器1次拒绝入口/出口且退出0。原19项负探针重跑PASS（7次拒绝入口/出口）；不可读`openat`路径探针使监督器退出125。仅接受为**两个已展示缺口的限定修复**，完整系统调用与竞态审计仍未闭合，真实载荷加载、workload、packet和硬件维持`NO-GO`。

## 2026-09-23 H1冻结native-v2载荷目标编译（仅构建）

板端原有冻结v2载荷源码与外部冻结源SHA-256一致（`048ea552bcd9f6f3f770ea01383e35a8ce7267b226ce308ac09601da068b5342`），只读复制到`/run`。补传冻结支持头`ProfilingGuid.hpp`并核对SHA-256=`a2dd95fa0be60e345b4ba5e2d979ef0417188e673d99fa8b86617ccdf0820edf`。使用板端厂家头/库严格`-Wall -Wextra -Werror`编译返回0；生成的`/run`共享库SHA-256=`87f0a67c847eab5c744014a9caf0555198d4ef2df5d02c35e1773c29525a379f`，ELF64/AArch64，导出`h1_capture_hard_packet`，依赖`libarmnn.so.32`且含BIND_NOW/GNU_RELRO。链接目标厂家主库再核哈希`5def7ba75e4b59644be6f58deaf8b2bb3791c62ed38b52b6aea08b11a8f728ce`。接受为`TARGET_BUILD_PASS_LIMITED`；未加载该共享库、未进入厂家构造/workload/packet，H1真实捕获与硬件仍`NO-GO`。

## 2026-09-23 H1目标AArch64句柄槽位自检与设备树复核

从冻结native-v2载荷抽出`ProbeTensorHandle`的构造、`GetPhyAddr() const`和四个独立哨兵，源文件SHA-256为`c057b003378affd9677bda6449a7c736c03a35c4678a0ef7bfe288fca7f28e4f`。板端在`/run`编译的AArch64程序SHA-256为`2a59da6e3e89a8a481a92a0a08e7b60314cb64dfb5ee64bcfa810609a89ccbd9`；在空`/dev`私有根和实验监督器内，四次`vtable[15]`（偏移`0x78`）均返回预期值，监督器`PASS gate_execs=1 denied_entries=0 failed_exits=0`。仅接受为`TARGET_VTABLE_SLOT_PASS_LIMITED`：没有运行冻结native-v2完整载荷或厂家workload，也没有验证厂家实际经该槽调用、物理地址或DMA。

板端当前**实时**设备树再次确认`anlogic,hard_npu`节点，三段资源为`0x63F00000/0x100000`、`0xF8800000/0x200`、`0xF8801000/0x100`，GIC SPI112/hwirq144；未见SoftNPU节点。只读解析旧80MHz临时DTB（SHA-256 `bd9125ad1fc31d8fb23aa5a8b9851376647601d836aae5d0d9ad2cb402ceb9f2`）则同时有相同Hard资源和`anlogic,soft_npu`的`0x80000000/0x4000`、SPI85/hwirq117。当前实际bit身份`UNKNOWN`，临时DTB没有加载。本轮真实Hard/Soft/CMA节点与模块仍缺失，H1真实workload、packet、独立驱动及硬件首算保持`NO-GO`。

## 2026-09-23 H1 runtime驱动入口定位（私有普通文件对照）

在板端私有根内新增受监督的设备路径`openat`审计，先由无设备探针校准。厂家库的既有runtime枚举在只读普通文件占位下实际执行`openat(/dev/hard_npu,O_RDWR)`并收到`-EROFS`，因此尚未到驱动ioctl；当占位换成**仅`/run` tmpfs中的可写普通文件**时，同一打开返回FD 3，紧接着请求`ioctl(fd=3,0x4801)`，被监督器在入口改写为`EPERM`，runtime报无法取得寄存器信息。公开头把`0x4801`定义为`GET_REGISTER_INFO`，返回两个64位地址/长度。没有给库伪造返回结构、没有允许共享寄存器映射或接触真实设备。占位文件结束仍为空，`lsmod`为0、真实Hard/Soft/CMA节点均缺失。原19项负探针在该监督器版本下重跑仍PASS。**H1真实runtime、workload、packet和硬件继续`NO-GO`。**

## 2026-09-23 H1目标端直接factory对照（仍为软件限定）

在板端`/run`构建受控pre-exec启动器及直接registry查询程序，并在bubblewrap私有根+ptrace监督器中执行。目标进程检查FD 3～4095均关闭，空`/dev`以及无`/proc`/`/sys`通过；仅加私有regular-file占位时，`/dev/hard_npu`是唯一条目，`ioctl`和共享`mmap`均被拒绝。修正监督器零受限调用的统计后，原19项负探针再次通过（7次入口/出口拦截）。

同一SHA-256 `5def7ba75e4b59644be6f58deaf8b2bb3791c62ed38b52b6aea08b11a8f728ce`的厂家主库直接factory查询：路径缺失时`alnpu_factory=no,size=3`；私有普通文件占位时`alnpu_factory=yes,size=4`，两次监督器均报告跟踪完整。既有runtime枚举探针在占位条件下仍报`Can't open hard_npu driver!`，因此只接受为**条件注册机制实证**，不提升为功能性backend、真实workload或硬件。板端随后实读`lsmod`为空，真实Hard/Soft/CMA节点均不存在；未运行模型、Optimize、packet、DMA、IRQ、驱动模块或NPU。原型尚非完整seccomp等效门禁，H1硬件继续`NO-GO`。详见`docs/research/HARDNPU_H1_BACKEND_FACTORY_AUDIT_20260923.md`。

## 2026-09-23 H1隔离负门禁原型（限无设备探针）

在板端`/run/h1_isolation_audit_20260923_1` tmpfs内编译、运行自写AArch64 ptrace探针与bubblewrap私有根负探针；没有写TF根分区或U盘。ptrace `NT_ARM_SYSTEM_CALL`改写无害`getpid`后，子进程收到`ENOSYS`。实验性监督器对原H1负探针的19项检查返回PASS，拦截七次受限调用；fork和pthread附加探针各有四项受限调用返回`EPERM`，共八次拦截；被监督的shell企图再次exec时监督器返回125并阻断。源码和边界见`tools/npu/hardnpu_h1_ptrace_gate_20260923/README.md`。

这些是有限负测试。继承FD、完整系统调用覆盖、挂载别名和异常/并发路径尚未完成独立审计，**ptrace原型不计为seccomp等效门禁通过**。本次未借原型启动厂家库、模型、workload或硬件；H1真实捕获和硬件仍`NO-GO`。

## 2026-09-23 HardNPU H1板端新鲜只读核验（用户确认上电、USB连接、U盘在板）

COM4本次由Windows识别为`USB-Enhanced-SERIAL-A CH342`，串口登录后实读目标为Ubuntu 20.04.1、`6.1.111-rt42 #17 SMP PREEMPT ... aarch64`，`lsmod`为空，`/dev/hard_npu`、`/dev/soft_npu`、`/dev/cma_mem`均不存在。根分区`/dev/mmcblk0p2`为`rw`；U盘为未挂载的`/dev/sda1`（vfat，57.7G）。本次未挂载、复制或运行U盘内容。板端时钟显示`2025-11-19 UTC`，与实际2026-09-23不一致，板端文件mtime不能作为本轮时间证据。

板端既有私有运行库`libarmnn.so.32.1`的SHA-256为`5def7ba75e4b59644be6f58deaf8b2bb3791c62ed38b52b6aea08b11a8f728ce`，parser库和protobuf分别为`dcb43bc092ec283364806e563fa6aa8d2404eb7c005db44081821da405c5ce99`、`5d69d988c4b8309bb5dc9318c010bac6a16904549ffd38ce11f65a918376e265`，三者与冻结输入一致。库目录未见独立Alnpu backend共享库；系统`ldconfig`可解析`libpthread`及主库所需系统DSO，glibc为2.31。仅能确认当前已见加载依赖，不能据此宣称真实backend和完整运行闭包已通过。

在读取源码确认只安装最小允许filter、没有设备访问后，该只读阶段运行既有`seccomp_probe`得到`SECCOMP_RC=-1 ERRNO=22 Invalid argument`，复现隔离阻塞。既有板端日志记录真实无桩registry探针只列`ALRef/CpuAcc/CpuRef`、`alnpu_registered=no`、Optimize报factory缺失；另一个typed-stub日志显示`ALHardNPU/Alnpu`，两者不得合并为真实backend通过。该阶段没有新运行厂家库；当日后续的限定registry对照见本文顶部。H1真实捕获和硬件继续`NO-GO`。串口已关闭，板卡仍按用户提供的上电状态，不假定关机或冷恢复。

## 2026-09-23 HardNPU H1只读接管与Alnpu注册门禁复核

本轮只读核验六个指定H1隔离包：各自`FINAL_SHA256SUMS.txt`所列148/148、265/265、251/251、182/182、149/149、10/10项均逐文件匹配，六份清单自身哈希亦与交接记录一致。但“列出项匹配”不等于“目录完整封存”：重定位包有85个未列入最终清单的`__pycache__`文件；stub包另有`SHA256SUMS.txt`、`TARGET_RUN_PLAN.md`和`scripts/build_stub_capture.sh`三个未列项。未修改这些冻结包；额外文件的来源时间和后续改动为`UNKNOWN`。

对冻结`libarmnn.so.32.1`（SHA-256 `5def7ba75e4b59644be6f58deaf8b2bb3791c62ed38b52b6aea08b11a8f728ce`）的既有ELF反汇编做独立控制流复核：`AlBackendStaticRegistryInitializer`位于`0x3b3e10`，先构造并`__lxstat`检查`/dev/hard_npu`；`ENOENT`或`ENOTDIR`进入不调用`BackendRegistry::Register`的返回分支（`0x3b3ff8..0x3b4024`），存在且类型通过的路径才到`Register`（`0x3b3f64`）。这为当前设备遮蔽下的`GetFactory`错误提供可证伪解释，也与私有regular-file占位的桩化分区观察相符。它**不证明**当前真实设备存在、真实backend可安全初始化或厂家workload/packet可用。详见`docs/research/HARDNPU_H1_BACKEND_FACTORY_AUDIT_20260923.md`。

当前板端seccomp最小filter返回`EINVAL`，尚无完整等效系统调用隔离；命名空间、设备遮蔽、降权、capability清零和FD关闭仍仅`PARTIAL_DEVICE_BLIND`，当日ptrace/FD负探针及直接factory对照见本文顶部。注册检查需要设备路径这一事实使“完全缺设备路径的板端进程中真实Optimize”与该库当前注册逻辑冲突。私有regular-file占位仅证明条件软件注册；在取得独立无设备直通的AArch64环境或同等可审计隔离前，不推进真实workload捕获。当前状态保持`GO_FOR_RUNTIME_BACKEND_RECOVERY / HARDWARE_NO_GO_PENDING_ALNPU_BACKEND_AND_ISOLATION`；H1-04～H1-06继续`NO-GO`。此前只读接管阶段未连接板卡或构建；当日后续实验见上方记录。没有运行Optimize或操作Git。

## 2026-09-22 追加：Alnpu桩化分区与捕获变体准备

在工程外新建隔离目录
`F:/My_proj/_isolated_builds/hardnpu_h1_stub_packet_capture_20260922_1/`。
它从冻结 native-capture 包复制目标 Conv 夹具、支持头和捕获源码，并增加
仅用于软件实验的 typed CMA/driver no-op stub gate。该变体保留 Pool、物理
地址、run、IRQ 等 fail-closed tripwire；命名空间中的设备名若出现，也只能
是私有 regular file，不能代表内核设备。

- stub gate 主机语法检查：`PASS`；payload 主机语法检查：`PASS`；
- 在板端私有设备命名空间中使用 typed stub 运行 parser/Optimize：
  `PASS_STUBBED_SOFTWARE_LIMITED`；输出显示唯一目标节点为 `ALHardNPU`，
  `BackendID=Alnpu`，形状和量化类型与冻结 Conv 一致；
- 厂家库仅在 typed-stub 对照中被加载；真实 target backend、真实 workload、
  packet、DMA、IRQ 和板端执行仍为 `NOT_RUN`（桩运行不计入真实 backend 或
  硬件执行）；
- 分类只能写 `STUBBED_SOFTWARE_PREPARATION`，不得写成 `Alnpu` 硬件或
  HardNPU packet 完成；
- 当前电脑未枚举 COM/UART，未向板端传输或运行该变体；
- 新包收据：`verification.json`，输入包哈希和源文件哈希见
  `F:/My_proj/_isolated_builds/hardnpu_h1_stub_packet_capture_20260922_1/SHA256SUMS.txt`。

该实验只为在后续恢复 AArch64 传输后验证“真实 workload 构造→厂家 packer”
的受控软件路径，不能替代 H1-02 的 seccomp/等效系统调用门禁，也不能替代
真实 target backend registration、packet 合同或 H1-06 首算。H1-03、H1-04、
H1-05 和 H1-06 仍保持硬件 `NO-GO`。

## 2026-09-22 HardNPU H1目标端门禁与parser/Optimize核验

本轮在板端原TF Linux的私有目录
`/root/h1_exec_20260922_1/`中完成了H1目标软件核验；没有加载原始Hard/Soft/CMA驱动，没有调用官方executor，没有启动DMA/NPU，也没有下载bit或修改DTB/TF卡。

### 已接受的限定证据

- AArch64目标编译：`h1_negative_probe`、原始隔离launcher、`h1_armnn_probe`、`h1_hard_capture_gate`均已生成；`SYS_close_range=436`是目标头文件缺失时采用的编译兼容定义，未修改源包。
- loader interpose自测：首次缺少`-rdynamic`的构建结果不采用；修正后观察值为41，结果`PASS`。
- 原始隔离launcher的命名空间、设备遮蔽、降权、capability清零和继承FD关闭路径已执行到seccomp安装点；当前内核对最小seccomp filter也返回`EINVAL`，因此完整负隔离门禁不能记为PASS。
- 降级设备遮蔽变体仅用于继续获取软件证据：进程为uid/gid 65534，`/dev/hard_npu`、`/dev/soft_npu`、`/dev/cma_mem`、`/sys/class`和`/proc/self`均不可见，no-new-privs和继承FD门禁保留；该变体标记为`PARTIAL`，不等同于seccomp通过。
- 厂家`libarmnn.so.32.1`在降级设备遮蔽环境下`--load-only`返回`PASS_DEVICE_BLIND`，`hardware_execution=NOT_RUN`。这只证明库可在设备不可见的环境加载，不证明后端注册、workload或硬件执行。
- ONNX parser成功识别冻结模型和目标节点；输入/输出绑定和三层常量已写出。目标Conv保持`QAsymmU8`输入/权重、`Signed32` bias、`QAsymmU8`输出及冻结形状。

### 阻塞和边界

- Arm NN在`Optimize(..., [Alnpu], ...)`处停止并报告：`Alnpu has no IBackend factory registered`。因此当前板端运行库目录中虽含Alnpu符号和HardNPU实现符号，但没有获得可用的Alnpu backend factory注册证据；优化后的分区、内部张量类型、真实workload、entry和packet均未取得。
- 当前运行库目录只发现`libarmnn.so.32.1`、`libarmnnOnnxParser.so.24.6`、`libprotobuf.so.23.0.0`等文件，没有独立的Alnpu backend共享库。该观察不能证明不存在其它未挂载介质中的配套库，但当前板端私有运行包不闭合。
- H1-03真实packet捕获、H1-04独立驱动、H1-05 GO/NO-GO和H1-06 HardNPU首算继续`NO-GO`。不能把parser成功、load-only成功或静态packet预测写成HardNPU完成。

当前总状态：
`GO_FOR_RUNTIME_BACKEND_RECOVERY / HARDWARE_NO_GO_PENDING_ALNPU_BACKEND_AND_ISOLATION`

下一步优先查明与该`libarmnn.so.32.1`匹配的Alnpu backend注册方式和完整运行库闭包；在完整隔离能力或可审计等效门禁恢复前，不运行真实workload，不加载原始驱动，不进行板端Hard首算。

## 2026-09-21/22 SoftNPU第二尺寸参数化Pool闭环完成

在工程外新增第二组固定夹具与单作业驱动：UINT8 NCHW `[1,1,4,6]`、MaxPool 2x2/stride2/zero-pad、输出 `[1,1,2,3]`，ABI `0x00010007`，设备 `/dev/softnpu_pool_v060`。源包位于 `F:/My_proj/_isolated_builds/softnpu_pool_param_v060_20260921_1/`，29/29清单通过，清单SHA-256=`c7b427c82e487812b102b9d1d8d87d32df9a7c26642ec6e7ab42a79bfddc21d2`。它只支持已恢复证据覆盖的Max/NCHW/UINT8/zero-pad/方形kernel/X-Y相同stride，不是通用Pool ABI。

板端匹配内核目标构建、80MHz候选bit/临时DTB身份、只读最小根、PREPARE-only和单次RUN门禁均通过。真实RUN仅执行一次且未重试：状态4、严格NN完成原因1、IRQ状态`0x4`、IRQ事件1、21条精确trace（4 common+15配置+1 start+1 IRQ clear）；输出`07 09 0b 13 15 17 00 00`与独立金样一致，packet/input/output三个4096字节dump差异均0，output偏移8～4095保护区未变。结论为 `BOARD_PASS_LIMITED(second-shape Pool normal DDR, single run)`，证明固定4x4以外的第二尺寸参数编码在该受控环境工作；不扩展到任意shape、padding、kernel/stride、量化、尾拍、全局AXI排空、packet-DMA、HardNPU或模型部署。

板端先显示软件 `Power down`，用户于2026-09-22确认关闭物理电源；保留缓冲由冷恢复终止，期间没有重试或再次上电。本次受限参数化子任务据此闭环。证据目录为 `F:/My_proj/_isolated_builds/softnpu_pool_param_v060_board_20260921_1/`，已生成35项最终清单，`FINAL_SHA256SUMS.txt` SHA-256=`f94a2eda6b75f1bd770821f396c1a661afd5851f62bd4dc90fa882b4bd2e276f`，逐项回读`bad=0`。HardNPU H1继续是后续主线，既有H1-01～H1-03状态不因本次Soft Pool结果提升。

## 2026-09-21 Sol H1-03：动态基址契约闭合，旧原生探针ABI被否决并形成v2

在工程外新增并封存两个隔离包：`F:/My_proj/_isolated_builds/hardnpu_h1_relocation_contract_20260921_1/` 最终清单182/182，清单SHA-256=`e5bc0c1b23e78ee04db700ca477b8ae4cd892d7aa8c5c316b2bdfbfbb89d296f`；`F:/My_proj/_isolated_builds/hardnpu_h1_native_capture_v2_20260921_1/` 输入114/114、最终149/149，清单SHA-256=`b1267e0f323239b9a7cb163b05ccb3f453d1897d8d2bc0d0e25048fd45156f20`。两包均未加载厂家共享库、未访问设备、未运行NPU/DMA/IRQ。

另建 `F:/My_proj/_isolated_builds/hardnpu_h1_native_gate_transfer_20260921_3/`，包含offline parser、重定位契约和native v2三个归档；源包清单148/148、182/182、149/149，三归档解包后再次逐文件通过，传输目录最终7/7，`FINAL_SHA256SUMS.txt` SHA-256=`1d05b4438090567d38dfb09d63a9c29ae0c2b0a54baf635c785920e7519bb9f4`。它不含内核模块、bit、DTB或硬件executor，仅供AArch64设备遮蔽软件门禁。

静态重定位契约为 `PASS_STATIC_RELOCATION_CONTRACT_LIMITED`：normal-mode在回放entry前把`pkg_info+0x18/+0x1c/+0x20/+0x24`分别写入Hard寄存器`0x0050/0x2000/0x2004/0x6000`；`r_HardNPUDriver`通过第二输入句柄vptr `+0x78`取得权重物理基址，厂家`AlnpuTensorHandle`虚表重定位把该槽识别为`GetPhyAddr()`。输入/输出还会叠加batch/tile偏移；冻结H1只有单split、单tile，静态条件偏移为0。此前12项/127-word预测packet不含`0x2000/0x2004/0x6000`三个动态基址，故packer-only捕获不能证明最终重定位值。

本轮否决旧v1 payload的“native-ready”假设：公共`ITensorHandle`虚表止于`Unimport()`，plain `PassthroughTensorHandle`没有已证明的vptr `+0x78 GetPhyAddr()`槽，真实driver可能在packer前即错误间接调用。v2改为派生`ProbeTensorHandle`、追加同签名virtual、为input/weight/bias/output返回四个不同的非设备哨兵，并在任何厂家构造/driver前自检`vtable[15]`。PC严格语法4/4、厂家静态契约14/14、静态安全39/39和x86-64对象槽精确addend检查通过；这些仅为 `PASS_HOST_ABI_LAYOUT_LIMITED`，AArch64目标构建、自检、loader/隔离/load-only和真实entry/packet捕获仍全部`NOT_RUN`。

H1-01保持`DONE_PC_LIMITED`；H1-02保持`CODED_HOST_SYNTAX_PASS_NOT_RUN`；H1-03新增“地址/重定位静态契约完成、v2安全捕获器PC门禁完成”，但真实parser/Optimize/partition、厂家entry/packet、常量原生布局、最终pkg_info、AXI/DMA范围、IRQ及停止/缓冲生命周期仍`UNKNOWN/NOT_RUN`。当前为`GO_FOR_TARGET_BUILD_AND_DEVICE_BLIND_GATES_ONLY / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。本机PATH及项目资料扫描未找到可用AArch64交叉编译器，未据此伪造目标构建结果；下一步是原生AArch64私有目录构建并依次跑loader自测、隔离负门禁、load-only、v2隐藏ABI自检和设备遮蔽捕获，同时独立执行H1-02 parser/Optimize/partition证据链。H1-04/H1-05继续NO-GO。

本阶段没有操作板卡、U盘、串口、JTAG或电源；没有加载Hard/Soft/CMA驱动、调用官方executor、启动DMA/NPU、修改模型/RTL/bit/DTB/工程配置或操作Git。

## 2026-09-21 Sol H1-03：冻结Conv的entry形状已静态收敛，原生捕获仍未运行

在工程外新增并封存 `F:/My_proj/_isolated_builds/hardnpu_h1_entry_contract_20260921_1/`。最终清单251/251通过，`FINAL_SHA256SUMS.txt` SHA-256为 `e90e48307f99a7169f850138bef75ccbfeac5bc4f3c84dc1c87ee09cb069f518`。分析只把冻结AArch64厂家库作为ELF数据读取，未加载共享库、未访问设备；两次分析结果完全一致，契约JSON SHA-256为 `e3ee45fb103c20f701e726b12ae0860762421a54532a1ac7662a725338fdc940`。

H1冻结形状的静态 `Split()` 算术已闭合：输出通道只有一组 `[0,63]`；初始及最终tile数均为1，计算工作集10752，小于恢复的186368预算。厂家normal-mode entry形状预测为12项、103个payload words、127个packed words（508字节），最后一项为`0x1004=1`。这些是 `PASS_STATIC_PREDICTION_LIMITED`，不是实际entry或packet捕获，更不是硬件写许可。

本轮纠正一项关键假设：冻结payload的输入/权重为 Arm NN `QAsymmU8=2`，不是`QSymmS8=6`。因此H1不会走type-6专用的`0x0040`逐通道量化尾项，`0x5000..0x5040`条件组也不进入预测；`m_HasAct=false`使`0x6028`激活LUT条目缺席；bias为type-1 `0x0044/64 words`。先前中间态的196-word假设已 `REJECTED`，不得继续引用。

H1-01保持 `DONE_PC_LIMITED`；H1-02仍为 `CODED_HOST_SYNTAX_PASS_NOT_RUN`；H1-03新增“冻结payload entry形状静态收敛”，但真实parser/Optimize/partition、workload、entry/packet、寄存器值、重排权重/bias、重定位、DMA范围及IRQ/停止契约仍为 `NOT_RUN/UNKNOWN`。当前仍为 `GO_FOR_DEVICE_BLIND_NATIVE_GATES / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。下一步不变：AArch64目标构建→loader自测→隔离负门禁→厂家load-only→parser/Optimize/partition→一次workload至packer hook；捕获结果必须独立对照127-word预测，出现任何差异即停止审查，不能强行套用静态结果。

为减少后续U盘往返，另建 `F:/My_proj/_isolated_builds/hardnpu_h1_native_gate_transfer_20260921_2/`，只含offline、packet-capture和entry-contract三个已封存包的归档及收据；三归档3/3哈希通过，传输目录6/6，`FINAL_SHA256SUMS.txt` SHA-256=`febeabb097d97637a131ee75cc54d9ee6d945f019446c580e184924a7c53ac1e`。它不含内核模块、bit、DTB或hardware executor，不能用于设备执行。

本阶段没有操作板卡、U盘、串口、JTAG或电源；没有加载Hard/Soft/CMA驱动、调用官方executor、启动DMA/NPU、修改模型/RTL/bit/DTB/工程配置或操作Git。H1-04/H1-05继续NO-GO。

## 2026-09-21 Sol H1-03：Hard packet静态ABI闭合，真实目标载荷仍待捕获

在工程外新增并封存 `F:/My_proj/_isolated_builds/hardnpu_h1_packet_abi_20260921_1/`。最终清单265/265通过，`FINAL_SHA256SUMS.txt` SHA-256为 `ff6ab241e172e876e8c1ba2a327ac05d520d3084e2afeaf96ede4e4830b90d47`。冻结厂家库SHA-256仍为 `5def7ba75e4b59644be6f58deaf8b2bb3791c62ed38b52b6aea08b11a8f728ce`；分析脚本仅将其作为ELF数据读取，没有加载共享库或访问设备。

为下一轮目标纯软件门禁新增 `F:/My_proj/_isolated_builds/hardnpu_h1_native_gate_transfer_20260921_1/`：两个源包在归档前分别复核148/148和133/133；归档SHA-256为 `33d4d5ad8d425753bd3841a0089f7d63b17e102e03606870a582a5f2253b5aba`、`b3620cfcbfd3b37541841e7fb1b1a044f2ca927d2c5e0d501758ff9b8bc7107c`，传输清单4/4，清单SHA-256=`d0aba4aa2178185793048f9a8c6abd13a646dd304ec787fb0a73dbb03d36fdf2`。该包没有内核模块、bit/DTB或硬件executor，仅允许设备遮蔽的AArch64用户态构建和门禁。

本阶段将H1-03的静态packet边界由“候选拦截点”推进为 `PASS_STATIC_LIMITED`：Capstone/ELF交叉分析通过29个精确指令断言，从只读常量恢复7组pre-special寄存器快照（`0x0000..0x005c`、`0x1000..0x1020`、`0x2000..0x200c`、`0x3000..0x3008`、`0x4000..0x4004`、`0x5000..0x5040`、`0x6000..0x6054`）。真实packer每项为长度/类型、地址头和payload：`type==0`使用`0xff000000+words`，非零type使用`0xff400000+words`；实际Hard driver以mode 0调用，地址头为`reg_offset|0x63f00000`。`0x63f00000`只是packet编码，不是已确认PS物理基址。独立有界codec通过4096组随机往返、5项固定向量断言和10个拒绝用例；特意用固定向量阻止编码器/解码器同时反向导致假通过。

公开Hard驱动14项静态门禁确认：probe会写top enable、SRAM控制并复位；ioctl允许无offset边界/对齐白名单的寄存器读写；mmap未把请求长度限制在资源内；IRQ在无作业generation归属前读/清状态；超时不证明停止、AXI排空或缓冲归还。因此结论为 `PUBLIC_DRIVER_NOT_REUSABLE_UNMODIFIED_FOR_H1_FIRST_RUN`。normal helper会将packet解码为逐寄存器写，packet-DMA则另写`0x100c/0x1010`并以`0x1000=1`启动；两条路径不能混用，本阶段均未执行。

H1-01保持 `DONE_PC_LIMITED`；H1-02仍为 `CODED_HOST_SYNTAX_PASS_NOT_RUN`；H1-03更新为“静态packet ABI完成、真实目标packet仍 `NOT_CAPTURED`”。七组快照不是硬件写白名单，entry builder仍会对多处偏移拆分/替换；最终entry、重排常量、地址重定位、DMA范围、padding/scratch和生命周期全部仍为 `UNKNOWN`。当前状态为 `GO_FOR_DEVICE_BLIND_NATIVE_GATES / HARDWARE_NO_GO_PENDING_H1_CONTRACT`；下一步仍是AArch64目标构建→loader抢占自测→隔离负门禁→厂家load-only→parser/Optimize/partition→一次真实workload至packer捕获。H1-04/H1-05继续NO-GO。

本阶段未操作板卡/U盘/串口/JTAG，未加载Hard/Soft/CMA驱动，未调用官方executor，未启动DMA/NPU，未修改模型、RTL、bit、DTB或工程配置，未操作Git。Windows结束检查未枚举到Win32 SerialPort或PnP COM设备，因此没有尝试板端连接。V2保护清单以纯文件哈希复核17/17；外部指定快照仍不存在、一致性 `UNKNOWN`，原工程整树无前置全量快照，不能声明整树无并发变化。

## 2026-09-21 Sol H1-03：真实Hard packet捕获器已封存，目标端软件门禁待跑

在工程外新增 `F:/My_proj/_isolated_builds/hardnpu_h1_packet_capture_20260921_1/`，未修改上一版148项H1离线包。新包冻结103项输入/依赖并逐项与来源SHA-256一致，最终133项清单逐项复核通过；`FINAL_SHA256SUMS.txt` SHA-256为 `9cf1eaa45918f2b6a2560e812242fd886b5065aa9b117aed2db5821242441d9a`。

H1-03安全真实对象路径已经 `CODED_PC_GATES_PASS / TARGET_NOT_RUN`。静态反汇编确认默认 `AlnpuWorkloadFactory` 构造会先进入 `cma_mem_init()`，因此明确排除factory/runtime路径；新payload改用公开host-backed `PassthroughTensorHandle`、真实三输入一输出 `ALHardNPUQueueDescriptor`、真实 `AlnpuALHardNPUWorkload` 构造和 `r_HardNPUDriver`。工厂原始指令中的 `mov x0,#0x2f0`把对象大小闭合为752字节，新payload以canary和后置不可访问页保护该边界。

冻结厂家库静态门禁14/14通过：normal-mode driver在 `0x3cc0d8` 通过PLT调用真实 `gen_dma_pkg_from_entry_list`，模式参数为0；首次 `Pool::GetPhyAddr` 位于其后的 `0x3cc224`；packer、CMA及物理地址函数存在动态重定位，库未设置 `SYMBOLIC`。新gate在隔离后导出packer hook及CMA、物理地址、Hard driver/run/IRQ fail-closed tripwire；hook直接调用运行时再次以 `dladdr` 校验的冻结packer偏移 `0x401b10`，输出真实entry/packet后 `fsync`并 `_exit`，不返回物理地址路径。另提供目标动态链接器符号抢占自测及厂家库 `--load-only` 门禁。PC C++17严格语法4/4、静态安全门禁34/34通过；这些都是软件准备证据，不是厂家packet或硬件执行结果。

当前仍未完成AArch64目标构建、目标loader自测、隔离负探针、厂家库load-only、真实workload/driver捕获、parser/Optimize/partition运行，也未取得真实Hard entry/packet。电脑端复查未枚举COM/UART，因此没有板端运行。状态更新为 `GO_FOR_NATIVE_DEVICE_BLIND_GATES / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。下一步依次是：目标构建；loader自测＋隔离负门禁＋load-only；随后才允许一次设备遮蔽的真实packet捕获并审查寄存器、重定位、DMA范围、padding和生命周期。H1-04/H1-05继续NO-GO。

本阶段未加载Hard/Soft/CMA驱动，未调用官方executor，未启动DMA/NPU，未进行硬件执行、综合、bit/DTB替换、U盘写入或Git操作。V2保护清单按纯文件哈希17/17，外部指定快照仍不存在、一致性 `UNKNOWN`；无全工程前置快照，不能声明整树无并发变化。

## 2026-09-21 Sol H1离线阶段历史快照：冻结与CPU语义完成，原生隔离门禁待跑

按Astra最新方向审查领取H1主线，在工程外新建 `F:/My_proj/_isolated_builds/hardnpu_h1_offline_20260921_1/`。原 `hardnpu_minconv_contract_20260920_1`、厂家AArch64库/头文件和方向审查只复制为输入，未修改来源。冻结输入清单123/123复算一致；`intake.json`、`INPUT_SHA256SUMS.txt`的SHA-256分别为 `426ba7e24b83fe8044a2cd46f9d8bb93e9bf14229c49e6f2d862ee91efe8a8f0`、`f94a5481d4fa4de34e34a1a9ebd078a67fa04ceabb2f419befdda0e0e0002c1f`。

H1-01A接受为 `DONE_PC_LIMITED / CPU_GOLDEN_PASS_LIMITED`：冻结模型前后SHA同为 `0379545c985615399b5e690e39e97242bc153434bd40e98bf134162ec6f43cf3`；节点序列为三层DequantizeLinear、目标Conv、QuantizeLinear；ORT和独立INT64累加/再量化路径均与12544字节冻结输出逐字节一致。权重和bias独立导出哈希分别为 `66cbc396e77abe4c77b2e8fc514a5a9e1859cc0e433575b9e82b8e3d3750c623`、`710a3d9da29db0e9f94f8722d18e23829a605ace3563abb3ed1df596165a3f2f`。该结果仍是诊断夹具CPU证据，预处理与训练不一致，不能证明产品模型精度。

库加载前设备隔离已 `CODED_NOT_TARGET_RUN`：独立launcher先建立私有mount/network namespace，以只读空tmpfs遮蔽 `/dev`、`/sys`、`/proc`，关闭stdin及3以上继承fd，清空环境，降至uid/gid 65534、清零capability、设置`no_new_privs`，再以seccomp拒绝ioctl、设备节点创建、挂载、模块、网络、ptrace、共享mmap等操作，最后才exec厂家链接探针。独立负探针验证上述条件；parser/Optimize探针不创建runtime、不LoadNetwork、不创建workload、不执行硬件，并记录绑定、优化前后层/张量、ALHardNPU描述符、图常量和DOT。静态门禁31/31通过；真实AArch64编译、负门禁、厂家parser和Optimize仍均 `NOT_RUN`。

冻结 `libarmnn.so.32.1` 为AArch64 ELF，含644个`.init_array`指针及 `/dev/hard_npu`、`/dev/soft_npu`、`/dev/cma_mem`、`/dev/mem` 字符串，因此“库能加载”不能代替隔离证明。静态反汇编接受 `DONE_STATIC_LIMITED`：`r_HardNPUDriver` 中 `get_quant_info`→reset→Fill→packet→`gen_dma_pkg_from_entry_list`，之后才出现 `Pool::GetPhyAddr/GetPointer`、CMA sync和Pool Acquire。该顺序只给出H1-03候选拦截边界；安全符号拦截、真实workload、entry、packet、重排常量、relocation、workspace均仍 `UNKNOWN/NOT_RUN`。

当前状态：`GO_FOR_DEVICE_BLIND_NATIVE_CPU_GATE / HARDWARE_NO_GO_PENDING_H1_CONTRACT`。下一步只允许在原生AArch64 Linux私有目录先构建launcher和负探针；负门禁全部通过后，才可在同一隔离器内运行单层parser/Optimize。H1-03必须另行证明真实对象路径在任何物理地址/CMA/Acquire前可审计终止；不能把H1-02图优化当作workload或packet。Arm NN探针已通过MinGW C++17严格主机语法检查，但这不替代AArch64目标构建。隔离包148项最终清单复核148/148，`FINAL_SHA256SUMS.txt` SHA-256为 `89dfdb8bb2630636cc68d542b344263b172f4d0d237a3cd123f4c4cd595f99f5`。

本阶段未连接或操作板卡/U盘/串口/JTAG，未加载Hard/Soft/CMA驱动，未调用官方executor，未启动DMA/NPU，未综合、下载bit或替换DTB，未修改模型/RTL/工程配置，未运行Git。V2保护清单以纯文件哈希复核17/17；外部指定快照路径仍不存在，一致性 `UNKNOWN`；原工程整树无本阶段前置全量快照，不能声明整树无并发变化。

## 2026-09-21 Astra方向审查：fixed Pool验收保留，下一主线H1

独立证据审查已完成，报告位于根目录 `SOFTNPU_ASTRA_DIRECTION_REVIEW_20260920.md`（按用户指定文件名，实际执行日期为2026-09-21）。v0.5.4板测清单15/15匹配，三块4096字节dump本轮重新逐字节比较均0差异，接受 `ACCEPTED / BOARD_PASS_LIMITED(fixed Pool normal DDR)`。准确追踪计数为 **4 common + 15 normal配置 + 1 NN start + 1 IRQ clear = 21**；normal计数16已经包含start，不能再把21条全算成提交。旧S0～S7未执行/等待首次RUN的描述仅为历史状态，不得重复执行。

下一主线明确选择 **H1：真实模型派生最小Hard Conv**，先做该单层受控parser/Optimize/真实Alnpu分配与host-only packet捕获，再实现Hard独立单作业驱动。S8 Soft packet-DMA不是Hard首算必要前置，保留P1；完整R1 runtime集成后移。当前为 `GO_FOR_OFFLINE_PREPARATION / HARDWARE_NO_GO_PENDING_H1_CONTRACT`，不是Hard板测放行。

现有1×1 UINT8 Conv候选的四项模型/输入/输出/来源哈希匹配，PC内存中ONNX full checker通过，ORT与保存输出12544字节差异0，新增INT64累加加理想比例再量化对照差异0。只接受 `CPU_GOLDEN_PASS_LIMITED`；厂家parser/Optimize/partition/packet/Hard执行仍未运行。生成脚本的独立NumPy路径实际上使用FP32反量化算术；其letterbox/除255预处理也与训练的直接缩放/ImageNet归一化记录不同，夹具不得当作产品精度验证。来源UINT8整图仍是此前拒绝部署的诊断模型。

公开Hard驱动probe的top/SRAM/reset副作用、无长度上界的RW mmap、任意offset、失败open清全局IRQ标志及无停止的超时路径均不允许原样沿用。报告已给Sol H1-01～05任务，每项含输入、实现、验收、失败分支、板卡及物理操作条件；推荐任务保持OPEN，NPU-001总任务继续DOING。本轮未连接板卡、未操作Git、未构建或修改模型/RTL/bit/DTB；V2清单17/17，外部指定快照不存在、一致性UNKNOWN。

## 2026-09-20 Sol→Astra方向复核交接已刷新

根目录 `SOFTNPU_ASTRA_HANDOFF_20260919.md` 已在最前面增加当前返交接入口：S0～S7已完成，其中v0.5.4 fixed-Pool normal DDR为 `BOARD_PASS_LIMITED`；S8 packet-DMA仍未运行；S9已建立真实模型派生的最小Hard Conv CPU金样和静态软件契约资料，但厂家parser/Optimize/packet及硬件执行均为 `NOT_RUN/UNKNOWN`。请求Astra判断下一主路线是优先Hard Conv、先补Soft packet-DMA，还是先做正式runtime的受控分区审查，再由Sol实现。该文档刷新不新增硬件结果，不改变NPU-001的`DOING`状态。

## 2026-09-20 SoftNPU v0.5.4：fixed-Pool normal DDR 限定板测通过

目标内核启用 `CONFIG_COMPAT`，而 v0.5.3 曾把 `.compat_ioctl` 直接指向 native handler。可用 MinGW 在默认和 `-m32` 下均通过15项结构尺寸/offset断言，但测试 ioctl 宏是桩，不能证明真实 Linux 编码或 AArch32 ABI；首轮板端探针本身为原生 AArch64。为避免暴露未验证入口，新建 `F:/My_proj/_isolated_builds/softnpu_ddr_traceable_v054_20260920_1/`，移除 `.compat_ioctl`，INFO 增加 `NATIVE_64BIT_ONLY` 能力标志，ABI 升至 `0x00010006`。这不是已观察到 compat 失败，而是有意 fail-closed。

v0.5.4 保持 v0.5.3 的 fixed normal 写序列、提交前 `EARLY_IRQ` 隔离、超时截止裁决、追踪和冷恢复资源策略不变。PC 状态机 `162/162`、追踪 `21/21`、静态门禁 `35/35`、native与主机 `-m32` 各15项编译期布局断言、native用户探针语法检查均通过；全部为软件证据。板端源码归档 12276 字节，SHA-256 `76591fc04e62c9563a59ecc77e945051616f6b0920fa048dfde3782127172a7c`；隔离包31/31，清单 SHA-256 `efe179ad17a90dfac2dd931aa8638e2955409976b349e0e87da8f99c81bf9e1f`。

用户明确确认物理冷断电后，在板端全新私有目录 `/root/softnpu_ddr_v054_target_20260920_1/` 完成 v0.5.4 原生 AArch64 目标构建。冻结源码归档在板端实读仍为 12276 字节、SHA-256 `76591fc04e62c9563a59ecc77e945051616f6b0920fa048dfde3782127172a7c`；U盘只读 SDK 实读 SHA-256 `521d0bd9d3fda583e4dd91d5a4694158844392bcd6e0d7ccfa01d7f4563e128f`，版本 6.1.111 + `-rt42`。m4/bison/flex/libsigsegv 只解包到实验私有目录，没有安装系统包。前两次 defconfig 分别暴露私有 bison 数据路径和编译时硬编码 `/usr/bin/m4` 问题；设置 `BISON_PKGDATADIR` 与 `M4` 后，defconfig、`prepare/modules_prepare`、模块和探针构建均返回0。

首次目标构建误用了 `anlogic_dr1m90_rt_defconfig`，产生 vermagic `6.1.111-rt42 SMP preempt_rt mod_unload aarch64`、SHA-256 `7d62ce6469628f5632697810ca27c5cf6032a7f229694d03050dee849cbda76a`；运行内核实际要求 `preempt`，首次 `insmod` 因 vermagic 不符而拒绝，平台未绑定。未使用强制装载。进一步确认普通 `anlogic_dr1m90_defconfig` 启用 `CONFIG_PREEMPT=y`；第一次增量切换又因板端时钟落后、未来时间戳导致旧生成物未更新。仅在板端私有 SDK 副本内执行干净重建后，新模块 vermagic 精确匹配 `6.1.111-rt42 SMP preempt mod_unload aarch64`，版本 `0.5.4-native64-only-not-hardware-approved`，SHA-256 `9ade02c508855b949dcba6708cc43d4f9867438638db3f5f8604612ee5c0f0a4`；探针 SHA-256 仍为 `2e09c7f8f13fb3192153ea8e1349de158f67e7f2fec2fe7ea2448816e374076c`。SDK 无 `Module.symvers`、modpost 未解析符号和1104字节栈帧警告仍保留，故仅为 `TARGET_BUILD_PASS_LIMITED`。

用户明确同意一次易失性 JTAG 下载后，TD 6.2.168116 返回 `Chip validation success: DR1M90` 和下载完成标志；没有写 Flash，OpenOCD/TD 进程已关闭。下载后 reset/divider 读回 `0x000001e1/0x07070904`，随后释放 reset 为 `0x000001f1`。原 TF 内核读取8131209字节，U盘临时 DTB 读取16915字节、CRC32 `0660312d`；仅在 RAM 设置 bootargs，Linux正常启动为 `6.1.111-rt42`。临时设备树实读为 `anlogic,soft_npu`、`0x80000000/0x4000`、80MHz、SPI85，平台初始未绑定且 IRQ/模块/设备节点均为空。

新模块先以默认 `permit_hardware_run=0` 成功装载；INFO 为 ABI `0x00010006`、flags `0x000003df`、Linux IRQ30/GIC hwirq117，IRQ计数0。唯一一次 `prepare-only` 分配三块独立、4KiB对齐、低4GiB的4KiB coherent缓冲（`0x2a11f000/0x02f37000/0x16ca7000`），packet 逐字节匹配冻结80字节夹具、SHA-256 `fd234aad45550f05dc2b0c21da35c0d9a17ec9a3d3f3c7ae201114c3ad59521f`；输入为`00..0f`，输出初值为八字节`a5`，未预填黄金值。探针明确 `hardware_start=NOT_RUN`，关闭后状态回到IDLE，IRQ前后仍为0；随后模块成功卸载，平台恢复未绑定。该阶段验收为 `DDR_PREPARE_PASS_LIMITED`。

用户随后明确授权唯一一次真实 RUN 并接受物理冷恢复。重新冷启动、易失下载同一80MHz bit后，以 `rootfstype=ext4 ro init=/bin/bash` 启动；根分区实读只读，`/run` 为tmpfs，模块/探针哈希、临时DT、无竞争驱动和零IRQ门禁全部匹配。模块以 `permit_hardware_run=1` 装载，INFO为ABI `0x00010006`、flags `0x000003ff`、state IDLE。唯一一次 `run-once` 返回0：`pre_status=0`、strict IRQ=`0x4`、IRQ事件1且GIC计数由0增至1、16次normal写+4次common AXI写+1次start、完整21项写追踪且无溢出；输出为 `05 07 0d 0f 00 00 00 00`，packet/input未变，逻辑输出、8字节实验可写容量、padding与全部guard均通过。两秒后状态仍DONE、IRQ仍为1，未观察到迟到中断。

三块4096字节缓冲已由板端tmpfs经串口回收，电脑端哈希分别为packet `b76edc2...48bd`、input `b037d089...6269`、output `018b8b9a...8603`，与板端一致；按冻结fixture及v0.5.4规则逐字节比较均为0差异。没有卸载、释放、重试或packet-DMA；证据回收后用户明确确认物理断电。结论提升为 `BOARD_PASS_LIMITED(fixed Pool normal DDR)`，不是通用SoftNPU、packet-DMA、其它算子/shape、官方runtime或模型通过。分配区外访问、IRQ后的全局AXI排空、超时/错误停机仍 `UNKNOWN`。证据入口：`F:/My_proj/_isolated_builds/softnpu_ddr_targetbuild_v054_20260920_1/evidence/board_run_v054_1/v054_real_run_evidence.md`。

## 2026-09-20 SoftNPU v0.5.3：超时截止后的完成竞态已封闭

继续审查 v0.5.2 发现：`wait_for_completion_interruptible_timeout()` 已返回 0 后，严格 NN IRQ 仍可能在 IRQ 完全停用前到达，把状态改成 `DONE_PENDING_VALIDATION`；旧 `sn_timeout()` 只处理 RUNNING，因而存在把软件截止时间后的完成继续做黄金值验证的窗口。该问题是源码可证的软件生命周期缺陷，不代表已在硬件触发。为保持 v0.5.2 封存不变，新建 `F:/My_proj/_isolated_builds/softnpu_ddr_traceable_v053_20260920_1/`，ABI 升至 `0x00010005`。

v0.5.3 在 wait 返回后先停用并同步 IRQ，再由 `sn_timeout_after_wait()` 做最终裁决：仍 RUNNING 记 `TIMEOUT`；竞态中已收到严格完成记 `TIMEOUT_LATE_IRQ` 并隔离；既有 `IRQ_ERROR` 隔离原因保持不变。超时路径均不能进入输出验证，所有已启动缓冲继续保留、模块继续自锁并要求物理冷恢复。该 late 计数只是软件时序分类，不是硬件 generation 标签，也不证明 AXI 已排空或设备已停止。

PC 状态机 `162/162`、追踪契约 `21/21`、静态门禁 `34/34`、15 项编译期 UAPI 布局断言和用户探针严格语法检查均通过；Windows 应用控制阻止了新 UAPI EXE 的运行，未尝试绕过，改用 C11 `_Static_assert -fsyntax-only`。板端源码归档 12281 字节，SHA-256 `a9a75f2590ed52b3a0d11304159fd3630d238cae42b42eb0d6a534c3e7d323aa`；隔离包 31/31，清单 SHA-256 `541a51cd296dde19e6901090a5b220624120a423ebec6c35e363825221dd3c89`。该候选现已由 v0.5.4 取代；其目标构建和硬件执行均保持 `NOT_RUN`。

又以独立主机发射器直接调用封存 v0.5.3 纯 writer，和冻结厂家拦截记录逐笔对照：17/17 通过。normal 路径为四笔 common AXI 加16笔厂家 normal 写，后16笔 offset/value 完全一致；休眠 packet helper 的六笔也与捕获一致，但只作软件等价性证据，packet-DMA 仍 `NO_GO`。固定20-word packet 字节及 SHA 仍一致。`0x0804/0x1004` 可由公开驱动直接支持，额外 `0x080c/0x100c=0` 只由候选33位 IP-XACT 和此前一次有限硬件执行支持，不扩展为通用厂家 ABI。审计包 20/20，清单 SHA-256 `1efa66183e6d50857190e03ce65173fd6269f6e77c3aac6bc7b3e858ccf41629`；硬件执行仍 `NOT_RUN`。

## 2026-09-20 SoftNPU v0.5.2：提交前早到 IRQ 隔离已补齐

继续静态审查 v0.5.1 时发现 IRQ 必须在第一笔设备写之前启用，因而存在“旧事件在 enable IRQ 与第一笔提交写之间到达”的窗口。旧实现会拒绝后续写入，但严格 NN 事件可留下 `DONE_PENDING_VALIDATION` 而非明确隔离终态。为不改动已封存 v0.5.1，新建 `F:/My_proj/_isolated_builds/softnpu_ddr_traceable_v052_20260920_1/`，ABI 升至 `0x00010004`；若第一笔提交写前状态已离开 RUNNING，严格 NN 事件转为 `SN_REASON_EARLY_IRQ` 隔离，错误 IRQ 保留 `SN_REASON_IRQ_ERROR`，两者均零提交写、保留缓冲、自锁模块并要求冷恢复。

v0.5.2 PC 状态机 `153/153`、追踪契约 `21/21`、静态门禁 `32/32`、64 位 UAPI 布局 `15/15` 均通过，用户探针语法检查通过；全部仅为软件证据。板端源码归档 SHA-256 `e63df86a3cb65f1e9b5bc6089c745be0ff52f2e2a1fa9435108b9a5c74492feb`；隔离包 27/27，清单 SHA-256 `3fb1c718373b7ebcc363c3ef4934cb22412eb884fe78030a5a9832cc80047bea`。v0.5.2 取代 v0.5.1 成为下一次目标构建候选，但仍为 `NOT_TARGET_BUILT/NOT_HARDWARE_RUN`；当前目标构建、PREPARE 和 RUN 均维持 `NO-GO NOW`，等待明确物理冷断电。

随后找到本地只读 Linux SDK 归档 `linux-SDK_2025.07-linux6.1.tar.gz`（221819301 字节，SHA-256 `521d0bd9d3fda583e4dd91d5a4694158844392bcd6e0d7ccfa01d7f4563e128f`）。归档 Makefile 为 6.1.111、`localversion-rt=-rt42`，与历史实读板端 release 完全一致；DR1 RT defconfig 启用 PREEMPT_RT、MODULES、MODULE_UNLOAD、CMA/DMA_CMA。选择性源码审计确认 v0.5.2 使用的 `ktime_get_ns`、`class_create(owner,name)`、int-returning platform remove、`IRQF_NO_AUTOEN`、`suppress_bind_attrs` 和 `try_module_get` 均存在，`ktime_get` 为 GPL 导出。结论为 `SOURCE_API_COMPATIBILITY_ACCEPTED_LIMITED`；归档没有生成 `.config`、`include/generated` 或 `Module.symvers`，本机也无可用 Linux/AArch64 构建环境，所以不能提升为目标编译通过。审计包 15/15，清单 SHA-256 `4b49b73ffff305cdcd19534a224a061b33463844ecb856416b0262386d20b638`。

## 2026-09-20 SoftNPU v0.5.1 可追溯单作业驱动（软件通过，尚未目标构建）

新建工程外隔离目录 `F:/My_proj/_isolated_builds/softnpu_ddr_traceable_20260920_1/`，未修改 v0.3/v0.4 或两个冻结输入包。v0.5.1 ABI `0x00010003` 在固定 normal-mode 单作业上为每次受控 MMIO 写记录顺序号、显式阶段、值以及单调时钟进入/返回时间；成功路径的 20 次提交写和严格 NN IRQ 后 `0x18bc=1` 清除写全部经过唯一适配器。驱动源码中已无旁路 `writel`。追踪容量为 24，可容纳四个已知状态位的清除写；固定成功契约要求恰好 21 条且无溢出。

生命周期进一步收紧：只要作业可能 start，无论最终数值成功或失败，close 都不释放三块 coherent 缓冲，模块自持有并要求物理冷恢复；仅从未 start 的 PREPARED 退出允许清理。probe 仍不分配缓冲、不写寄存器、不自动启动；不提供 mmap、任意 offset、用户地址/packet、重复提交或 packet-DMA。

PC 状态机 `143/143`、追踪契约反例 `21/21`、静态门禁 `31/31` 均通过，用户探针通过 MinGW 主机语法检查。该语法检查不替代 Linux 目标构建。未找到本地匹配 `6.1.111-rt42` 的完整 kernel output tree，WSL 未提供可用环境，所以 v0.5.1 真实目标模块/探针构建为 `NOT_RUN`，板端执行为 `NOT_RUN`。源码归档 SHA-256 `f133c583d9f4b2bff9c4c77f5767767e3979f4efebb37e3e56db0379accd10a4`；隔离目录 27 项清单复核 27/27，`FINAL_SHA256SUMS.txt` SHA-256 `c3198fc277b96a89073512c9d36346e385fe2650e602e0cb705f1699ff655590`。

等待冷恢复期间又在独立 `softnpu_ddr_traceable_api_audit_20260920_1` 做了 64 位主机 UAPI 布局检查：15/15 通过，result/dump 固定结构分别为 1096/4112 字节，并保存 v0.3→v0.5.1 驱动差异。相对已在目标板编译过的 v0.3 骨架，主要新增内核 API 是 `ktime_get_ns()`；这只能记 `PARTIAL`，AArch64 布局、ioctl 编码、符号解析、vermagic 和 PREEMPT_RT 编译诊断仍必须由真实目标构建确认。审计包 6/6，清单 SHA-256 `a950aa4d6710184fe0830475291a2f855a7619ce5dfe72935810a0cad280dd63`。

当时启动判断为目标构建、PREPARE 和新硬件单作业 `NO-GO NOW`；该候选现已由 v0.5.3 取代。上一真实作业的 v0.3 模块仍按最后证据处于自锁 `QUARANTINED` 上电周期，物理冷断电尚未获明确确认。确认冷断电后，下一步是在板端新私有目录重新读取内核/输出树/编译器/符号表并构建当前候选；构建成功也只先恢复 80MHz 候选组合并执行 run gate 关闭的 `info`/`prepare-only`。不得把软件通过写成 DMA、IRQ 或硬件完成。

## 2026-09-20 SoftNPU fixed-Pool 配置字段反汇编补证

在新工程外目录 `F:/My_proj/_isolated_builds/softnpu_pool_output_contract_20260920_1/` 对冻结 `libarmnn.so.32.1` 做只读 AArch64 反汇编和 PLT 符号恢复，没有运行厂家 executor、目标构建或板卡。`fill_soft_pool_driver_data()` 的指令级数据流确认：`0x1834=0x00101004` 编码固定输入 `C=1/H=4/W=4`，`0x1838=16` 来自输入张量 `GetNumElements()`；输出 TensorInfo 在该函数中只提供量化 offset/scale，其 shape 和 `GetNumElements()` 未被读取。捕获的 `0x1834..0x1860` 配置块中未观察到独立 output-byte-count 字段。纯静态解码脚本 4 项断言通过、退出 0。

结合实现数据库已接受的 8 字节 AXI beat，以及首次真实作业中 output 偏移 `0..7` 被改变、`8..4095` 保持 guard，本固定作业的 8 字节写回解释进一步加强；但运行时 `WSTRB/AWLEN/WLAST` 未采集，所以“单个全 strobe 尾拍”仍为 `INFERRED`，不能写成通用 SoftNPU ABI。v0.4 决策不变：目标构建 `GO_AFTER_CONFIRMED_COLD_RECOVERY`，一次 fixed normal-mode 复测 `CONDITIONAL_GO`；packet-DMA、其它 shape/算子、重复提交和完整 G4b 继续 NO-GO/`BLOCKED_BY_CONTRACT`。上一轮物理冷断电仍未获用户确认，因此没有进行任何板端动作。

## 2026-09-20 SoftNPU 80MHz 实现数据库补证与 v0.4 复测决策

在新工程外目录 `F:/My_proj/_isolated_builds/softnpu_axi_tail_static_20260920_1/` 只读导入已完成布局布线的 `soc_v2_softnpu_resetaligned_80mhz_board.db`；没有重新综合、布局布线或 bitgen。最终 TD 查询退出 0 且无 ERROR：PS HP1 的 `AWSIZE[1:0]` 两位均接常量 1，即固定 8 字节 AXI beat；`WSTRB[7:0]` 八位均为动态逻辑而非常量。由此接受 8 字节拍宽，但仍不能静态证明尾拍八个字节全有效，不能把 8 字节写回提升为通用 SoftNPU ABI。

v0.4 PC 状态机和静态门禁重新通过 `143/143`、`24/24`。结合第一次真实作业“0～3 字节为黄金值、4～7 字节为零”的现象，固定 Pool 单作业 8 字节写回解释升级为更强的 `INFERRED`，足以给出**目标构建 GO、单次硬件复测 CONDITIONAL_GO**：必须先确认物理冷断电，再重新目标构建并恢复匹配 80MHz bit/DTB、只读最小根、PREPARE-only、零旧 IRQ 和 `pre_status=0`。v0.4 仍为 `NOT_TARGET_BUILT/NOT_HARDWARE_RUN`；packet-DMA、重复提交、其它 shape/算子和通用 ABI 继续 NO-GO。

## 2026-09-20 SoftNPU output-granule v0.4 诊断版完成 PC 软件验收

在不修改 v0.3 板测证据的前提下，新建工程外隔离目录 `F:/My_proj/_isolated_builds/softnpu_ddr_outputgranule_20260920_1/`。v0.4 将逻辑输出 4 字节与实验可写容量 8 字节显式分离：偏移 0～3 必须匹配黄金值，4～7 必须为零，guard 从偏移 8 开始；padding 异常和 guard 异常使用不同隔离原因。ABI 升为 `0x00010001`，capability 和模块版本均明确标记 `OUTPUT_GRANULE_HYPOTHESIS/not-hardware-approved`，没有隐藏放宽原 guard，也没有加入 packet-DMA、任意寄存器、用户地址、mmap 或用户 packet。

PC 状态机严格编译和运行通过 `143/143`，静态门禁 `24/24`；板端源码包 SHA-256 `a62d344a37e9d5a23e033f9112ddaf172ad89049a2d8552081599ee20dd483f2`。当前等级仅 `CODED_PC_ONLY/NOT_TARGET_BUILT/NOT_HARDWARE_RUN`。板卡上一轮仍为 `QUARANTINED`，在用户确认物理冷断电前不得传包、构建或运行；即使未来固定 Pool v0.4 通过，也只能证明该 fixture 的 8 字节写回假设，不能推广为其它 shape/算子或完整 SoftNPU ABI。

## 2026-09-20 SoftNPU 系统 DDR 首次真实 fixed Pool 执行：数值正确但保护区失败

在工程外独立目录 `F:/My_proj/_isolated_builds/softnpu_ddr_oneshot_20260920_1/` 完成 S0～S7 第一轮实现与验证。冻结交接包 46/46、fixture 清单及候选 80MHz bit/DTB 哈希均复核通过；新驱动只提供固定单作业 ABI，probe 不启动 DMA，不提供 mmap、任意寄存器、用户物理地址或用户 packet。纯软件状态机 `139/139`、静态门禁 `21/21` 通过。目标内核 `6.1.111-rt42` 模块和探针构建返回 0，模块 SHA-256 `8d6575f5a2a2517e296658bdd7a1d418a0cbeee579cc6d18ab9a6fa7462c2b8b`，探针 SHA-256 `e47b8d050f7d0264d9f243d927e602cf915fb2b50029271e058ebcf15b4fac8c`；内核输出树缺少 `Module.symvers`，该构建缺口仍须保留，不能写成完整可发布驱动。

第一次在常规 Linux 下尝试把根文件系统在线改为只读时返回 busy，门禁正确中止，未产生 MMIO start 或 DMA 作业。随后重新易失下载已核验 80MHz 候选 bit，以原内核、临时 DTB、`rootfstype=ext4 ro init=/bin/bash` 启动；实读根分区为只读、`/run` 为 tmpfs、SoftNPU 平台为 `0x80000000+0x4000`、Linux IRQ 30/GIC hwirq 117、运行前 IRQ 计数为 0。PREPARE 使用三块由该 Soft 设备拥有的独立 4KiB coherent 缓冲，地址 `0x02326000/0x02328000/0x01e51000`，未预填黄金输出。

唯一一次 normal-mode `run-once` 发生真实硬件启动：`pre_status=0`，严格 NN IRQ 状态 `0x4`，`/proc/interrupts` 从 0 增至 1；寄存器写计数 16、公共 AXI 配置 4、start 1。输出前四字节为黄金值 `05 07 0d 0f`，packet 和 input 的 4096 字节均未变化。但 output 偏移 4～7 从保护值 `a5` 变为 `00`，其余输出保护区保持不变。驱动因此以 `SN_REASON_GUARD_MISMATCH` 进入 `QUARANTINED`、保留缓冲并返回失败；没有卸载、释放、重试或运行 packet-DMA。三块原始缓冲已通过串口完整回收并在电脑逐字节独立比较。

结论为 **PARTIAL / EXECUTED_ONCE_QUARANTINED**，不是 Pool BOARD_PASS。真实 NN IRQ和四字节数值输出可接受；候选 wrapper 与 IPUG166 均确认主 AXI 为 64-bit/8-byte，公开 CMA 参考驱动还会把逻辑请求页对齐到 4096 字节并把实际容量回传，因此本次额外四字节没有越过自有 4KiB 分配。但加密 IP 内部 WSTRB/尾拍规则和短输出 ABI 未公开，“硬件固定按 8 字节粒度写回”仍仅为 `INFERRED`。IRQ 后 AXI 是否完全排空、分配区外是否有访问、超时/错误作业的停止契约仍 `UNKNOWN`。S8 packet-DMA、额外输入和更广 runtime 继续 NO-GO；G4b 的单次 normal 首算阻塞已被实验取代，但完整 G4b 仍因输出写入边界与停止/排空契约保持阻塞。下一项 P0 是静态闭合 output write-size/valid-byte 语义，只有证据允许时才修订 guard/capacity 区分并进行新的冷启动单次复核。本轮结束保护检查为 V2 `17/17`；外部指定快照路径仍不存在，一致性保持 `UNKNOWN`。

## 2026-09-19 DDR固定fixture实现完成（PC-only）

在新工程外 `softnpu_ddr_fixture_20260919_1` 从真实80字节Pool packet生成可供Sol集成的C头文件、四组输入/金样、fixture manifest和独立FP32 MaxPool CPU oracle。配置数组分离启动前13项，完整packet仍20字且含start；无DMA地址或MMIO函数。1,284组CPU比较逐元素相等，640种单比特损坏全部拒绝；AArch64 C11严格语法检查通过，未编译Linux内核分支。仅PC_FIXTURE_ONLY，驱动/生命周期/IRQ/DDR首算仍未实现，G4b不提升。交接S2已加入确切输入及边界，本轮未连接板卡。

## 2026-09-19 交接补充：Sol执行任务包已细化

按用户要求扩展根 `SOFTNPU_ASTRA_HANDOFF_20260919.md` 的“Sol详细工作包”，S0～S9分别规定输入、操作、交付、验收及失败分支；增加固定单任务驱动接口/生命周期要求、11类软件测试、匹配启动/prepare、首算放行、normal及packet DMA对照、Hard Conv与产品衔接。第一轮交付目标明确为可审查源码、测试/构建证据和启动/首算决策，不以新研究报告代替实现。全部是待执行安排，未新增硬件验收或解除G4b门禁。本次仅文档修订，22:33封存收据仍对应前版，不回写旧清单。

## 2026-09-19 晚间最新：按用户要求恢复系统DDR主线，完成两种提交方式软件对照

用户已明确继续系统DDR路线并要求23:00前更新既有交接给Sol。私有PL RAM退为备选，下面“等待私有RAM构建范围确认”不再是当前主路线阻塞。尚未解除原工程/known-good保护及新硬件构建限制。

新隔离目录 `F:/My_proj/_isolated_builds/softnpu_ddr_handoff_20260919_1/` 中，板端设备遮蔽/降权CPU探针调用冻结厂家normal及DMA提交helper，GDB在soft_npu_write入口记录并跳过真实写入：普通模式16项、DMA模式6项与独立packet解码逐项一致，两进程正常退出，19份文件SHA回收通过。这里只是 `SOFTWARE_WRITE_TRACE_ONLY`，使用虚构地址哨兵，无真实MMIO/DMA/IRQ/算子。建议下一受控首算评估CPU配置、输入输出仍走DDR的normal模式，再验证任务包DMA；不能称无DMA或跳过恢复契约。

COM4当前实读原TF Linux6.1.111-rt42：无SoftNPU设备树/平台节点，只有未绑定HardNPU；modules空，三个NPU/CMA节点不存在，U盘未挂载。运行FDT SHA `8454c5d088f038833ea1b49d79f053f8feeafff6758731f71251d05bda1bd56d`。不能继承过去80MHz临时启动身份；当前bit身份UNKNOWN。未重启、未下bit，COM4已释放，板卡仍上电。下一硬件步骤首先恢复匹配候选环境及准备可审查的单次DDR驱动/冷恢复方案，G4b仍BLOCKED_BY_CONTRACT，不把软件轨迹通过写成设备执行。

根 `SOFTNPU_ASTRA_HANDOFF_20260919.md` 已直接更新为给Sol的最新交接；旧V5原稿完整保存在隔离备份，当前文档仅链接历史，不混入过时执行指令。本轮V2 17/17匹配，外部指定快照缺失；全工程无本轮前置快照，一致性UNKNOWN。详见 `2026-09-19-softnpu-z5-ddr-handoff.md`。

## 2026-09-19 独立RAM实验方案待范围确认

等待期间复核：V2 17/17、两阶段真实任务包封存清单46/46与34/34均匹配；无新构建或板端操作。构建范围问题仍未获回复，不能由自动续跑推定同意。

为避免继续依赖未公开DDR停止契约，形成SOFTNPU_PRIVATE_RAM_BRINGUP_PROPOSAL_20260919.md：NPU数据主口物理隔离至私有PL RAM，PS经有超时的mailbox/配置序列器访问，独立实验岛复位；先真Pool输出再验证DDR防护，最终目标不缩减。现有ERAM实例仅32bit/1KiB，不能直接复用。方案尚未实现/仿真/构建。用户既有禁止综合/P&R/bitgen/Generate仍有效，需要针对新隔离副本明确变更范围；旧G4b不放行。

## 2026-09-19 MPU候选收窄：默认放行，版本冲突未解

UG1214 v1.3第33章已完整提取并渲染核对：未匹配MPU区域默认放行，故仅配三个缓冲允许窗口不能实现白名单。说明书RASR bit10为UNCONFIGURED，UG1215/BSP却标为保留；区域数读取位置、SIZE与容量上限也不一致。FD25.1官方例程仅测试APU配置API，没有HP1越界流量验证。当前不放行MPU写入或NPU启动，G4b仍BLOCKED_BY_CONTRACT。报告SOFTNPU_MPU_DEFAULT_ALLOW_AND_VERSION_CONFLICT_20260919.md包含版本证据与六个待澄清问题；未向外发送。

## 2026-09-19 主口路径及MPU候选补证

只读脚本核验80MHz候选HDL的35根SoftNPU AXI信号均直连PS HP1，没有该段PL地址隔离。UG1215与现有BSP找到HPM MPU地址保护候选：HPM1基址0xf8413000、HP1 group0x80、4KiB区域、RW权限0/1/2/3分别为读写/只读/只写/禁止。硅片端口对应、未命中/重叠/跨界burst及动态在途处理仍UNKNOWN，未读写MPU，也不把MPU当作安全停止。新隔离证据softnpu_hp1_mpu_contract_20260919_1，研究报告SOFTNPU_HP1_MPU_CONTAINMENT_20260919.md。G4b不放行，下一研究扩展到已有HPM保护契约。

## 2026-09-19 完成中断归属反例已验证

工程外softnpu_irq_contract_20260919_1提取公开驱动原handler/ioctl函数，以内存桩在板端CPU降权运行：请求NN可被YOLO事件成功满足；超时后的迟到NN可被下一次等待成功消费。两个正常控制亦通过，运行0。冻结运行库静态仅检查0x0c任一位，不能补上严格Pool归属。此为软件反例，不是真实IRQ板测或驱动修复。下一最小执行驱动必须限定NN完成位、单任务生命周期、超时隔离并保留缓冲直到停止证据成立。G4b仍BLOCKED_BY_CONTRACT；详见SOFTNPU_IRQ_OWNERSHIP_COUNTEREXAMPLES_20260919.md。

## 2026-09-19 更晚：原始Pool配置路径任务包已捕获

新隔离目录softnpu_native_pool_path_20260919_1完成真实PostAllocationConfigure→r_SoftNPUPoolDriver的GDB捕获。在打包返回+0x3d37e8停止，从栈vector取80字节，SHA与前轮 `fd234aad45550f05dc2b0c21da35c0d9a17ec9a3d3f3c7ae201114c3ad59521f` 完全一致；Acquire调用点及入口断点命中均0，随后终止目标。14份文件逐SHA回收，V2 17/17，三设备节点不存在、modules为空、COM4释放。没有CMA或设备计算。此项为NATIVE_CONFIGURATION_PRE_ACQUIRE_PACKET_CAPTURE_LIMITED，不是配置完成、ONNX后端链或NPU执行。下一重点转为DMA/AXI、完成IRQ、停止恢复；G4b仍BLOCKED_BY_CONTRACT。详见SOFTNPU_NATIVE_POOL_PATH_CAPTURE_20260919.md。

## 2026-09-19 晚间：真实Pool对象任务包捕获，未提交设备

新隔离目录softnpu_real_pool_contract_20260919_1中，真实厂家Pool构造函数与公开类型host张量句柄通过设备遮蔽板端验证，厂家填充/打包得到3entry、20字，SHA `fd234aad45550f05dc2b0c21da35c0d9a17ec9a3d3f3c7ae201114c3ad59521f`，与条件化推导一致。13日志回收、94原头文件匹配、V2 17/17。此证据消除旧假对象字段来源限制，但不是ONNX→后端→配置全链；私有类精确sizeof/析构未测。成功构建补充Arm官方ProfilingGuid头，未修改厂家库。

PostAllocationConfigure静态确认会进入CMA Acquire，不能当成纯软件函数直接调用。本轮无CMA/驱动/MMIO/DMA/NPU运算，设备仍未绑定，COM4释放。G4b保持BLOCKED_BY_CONTRACT；下一步原始配置路径打包后且Acquire前的受控捕获及DMA/IRQ/停止契约。详见研究报告SOFTNPU_REAL_POOL_CONSTRUCTOR_CAPTURE_20260919.md。

## 2026-09-19 最新：V7 实际板端验证通过 BN 折叠及三种补声明混合精度图

用户要求直接上板推进后，在新隔离目录 `softnpu_astra_v7_board_20260919_1` 完成7次模型解析及2次无库gate。FP32 BN折叠图直接parse_return/0；三种混合图原版均139，PC/LR为parser `+0x41164/+0x41144`、addr0x24，反汇编为向目标TensorInfo字段写入。PC只补中间value_info（171→469/403/399），去声明protobuf一致，48帧逐元素误差0；三图再次板端验证全部parse_return/0，限定为 **PARSER_PASS_LIMITED**。27个独立日志逐项SHA回收，模型PC/板端哈希一致。未改变原图计算或新增终端Q/DQ。

本轮没有Optimize/runtime/backend、NPU/CMA驱动加载、MMIO、DMA、IRQ等待或NPU运算。原TF Linux仍上电空闲、modules为空、三个设备节点不存在，COM4已释放。量化精度仍约0.42223/0.63207/0.62963，均拒绝部署；主动G4b仍BLOCKED_BY_CONTRACT。详细故障、修复模型SHA、传输及验收边界见根 `SOFTNPU_ASTRA_BOARD_PROGRESS_20260919.md` 与 `2026-09-19-softnpu-v7-board-followup.md`。下面V6“折叠/混合图未板测”属于历史阶段状态，以本节为准。

## 2026-09-19 历史阶段：Astra V6 单变量解析修复、BN 折叠及 bias 审计完成

独立回收并核验V5的24个原始run日志；八图结果与交接一致。新隔离目录 `F:/My_proj/_isolated_builds/softnpu_astra_v6_20260919_1/` 中，V6仅增加两个终端Q/DQ中间张量的value_info，删除新增声明恢复原ModelProto，删除所有value_info后的protobuf逐字节一致；六个PC文件均通过full checker/shape inference，48帧修正前后6144个输出元素完全相等。inferred图与手工修正图同哈希。

已完成板端四图parser-only对照：UINT8/INT8控制均重现139、armnn `+0x730bd4`/parser LR `+0x2f740`/x0=0/addr0x30；仅补两声明的UINT8/INT8均parse_return/退出0。限定结论 **ACCEPTED / PARSER_PASS_LIMITED**；并不证明两条声明分别必要，亦不证明后端/算子/NPU执行。板端保持设备目录遮蔽、降权、独立进程/日志与40秒超时，未加载任何NPU/CMA驱动。15个V6日志已回收并核验。COM4已释放，原TF Linux仍上电空闲，三个设备节点不存在、lsmod为空。

实际W[1280,128]的MatMul+推理态BN按列折叠为MatMul+Add；48帧FP32最大误差 `1.1920928955e-6`，平均cosine `0.9999999999999849`，**DONE_PC_ONLY**。bias warning已独立复现为极小per-channel scale导致INT32越界的无保护强转：原INT8控制12层18通道，排除DW后仍6层9通道。无NaN/Inf或非法scale不代表bias安全。仅恢复越界bias不能恢复整体特征精度。

折叠通过后新增三组PC混合精度对照：只量化Conv平均cosine约0.42223；排除12个越界Conv约0.63207且cast warning消失；再保留完整早期block约0.62963。全部仍 **REJECTED_FOR_DEPLOYMENT**，未测试厂家parser或硬件。下一步为有限逐block敏感度/激活饱和审计、代表性校准与独立词级验证，必要时QAT；不应继续仅排除DW或单纯处理末端。真实packet、DMA/AXI、完成IRQ、超时停止及缓冲生命周期仍未闭合，主动G4b继续 **BLOCKED_BY_CONTRACT**。V4R接口未扩展。

V2基线17/17匹配；除四份授权文档外原工程22140个文件与本轮前置快照哈希一致。外部快照路径仍不存在，一致性UNKNOWN。完整模型哈希、数值、边界和下一步见根目录 [SOFTNPU_ASTRA_RESPONSE_20260919.md](../SOFTNPU_ASTRA_RESPONSE_20260919.md) 与当日 `2026-09-19-astra-v6-bn-bias.md`。以下各节为历史阶段快照，不覆盖本节最新结论。

## 2026-09-19 历史阶段：V5 八图 parser-only 板测完成，已形成 Astra 交接

V5 八图已在原 TF Linux、设备节点遮蔽、降权、独立进程和 60 秒超时条件下完成。UINT8/INT8 原控制图均重现 parser `NodeConnections +0x42954/+0x42948` 的终端消费者空指针；两种 `tail_bypass` 图均 `parse_return`/退出0，只能记为 `PARSER_PASS_LIMITED`。两种手工追加终端 Q/DQ 的图均在 `libarmnn +0x730bd4`、parser LR `+0x2f740` 以地址 `0x30`、`x0=0` 退出139；离线复核确认其两个新增中间张量没有 `graph.value_info`，与 V3 已证实的缺 `TensorInfo` 故障签名一致，因此该对照被第二故障截断，尚未直接证明“终端 DQ 可规避旧崩溃”。两种 legacy 完整 QDQ 图均由 parser 明确拒绝：BN 的 `projection.1.bias` 源自 INT32 QDQ，不在允许的 FLOAT/INT8/UINT8 类型集合内。

当前可接受的结论是：终端 `BatchNormalization→Relu` 尾部是旧消费者追踪崩溃的必要触发部分，但不能写成 BN/ReLU 普遍不支持；V6 应只为新增终端 Q/DQ 的两个中间张量补显式类型/shape，再做单变量 parser 对照。legacy 路线应先在 PC 上保持 BN 参数为 FLOAT，或把末端 BN 严格折叠到 MatMul 后验证数值，再重新量化。V5 板端原始日志仍只在 `/root/g4b_spatial_parser_v5_terminal_qdq_20260919_1`，尚未回收到 PC；板卡当前上电、Linux shell 空闲、U盘物理在板卡但已卸载，`lsmod` 为空且三个NPU/CMA设备节点均不存在；COM4 已正常关闭并释放。全程未进入 Optimize、runtime、backend、DMA、IRQ 或 NPU inference。

PC-only 量化敏感度对照把17个 depthwise Conv 排除出 INT8 QDQ 后，48帧特征平均 cosine 从 `0.4168428254` 提升到 `0.4945894880`，仍不合格；且生成时有 bias cast warning，候选只用于诊断。最新完整交接见根目录 `SOFTNPU_ASTRA_HANDOFF_20260919.md`。下一步为 V6 单变量 value_info 矩阵、末端 BN 折叠数值验证和量化 bias/混合精度审计；主动 G4b 继续 `BLOCKED_BY_CONTRACT`。

## 2026-09-19：真实空间模型 V4 板端解析完成，V5 终端 Q/DQ 对照已装入 U 盘

V3 四格板端结果已从 `/root/g4b_parser_matrix_v3_20260918_1` 回收到电脑并以冻结 AArch64 库符号化。A0/B0 两个失败图的 PC 均为 `libarmnn.so.32.1+0x730bd4`，对应 `armnn::TensorInfo::SetQuantizationScales` 内 `ldr x22,[x0,#48]`；调用点 LR 为 `libarmnnOnnxParser.so.24.6+0x2f740`，前一条调用从 `OnnxTensor` 首字段装入 `x0`。故障现场 `x0=0`、地址 `0x30`。A1/B1 仅补中间 `value_info` 后解析返回。当前可接受的限定结论是：冻结 parser 在 Q/DQ 量化信息设置路径中会对缺失 `TensorInfo` 的中间张量解引用空指针；这说明为什么 V3 两个缺声明图退出139，但不能推广为任意模型兼容，也不是 NPU 运算证据。

真实空间编码器已在工程外隔离目录固定为 batch=1 并做 ONNX shape inference，FP32控制模型 SHA-256=`41157e71c2204874f4beadaa778c04f011c4320485d5bb288da0c3e53f79573f`。采用48帧校准样本生成的 batch=1 UINT8/INT8 QDQ 候选均通过 ONNX checker、无未声明产出、无非有限 initializer；但对 FP32 特征的平均余弦相似度仅 `0.319099/0.416842`，两者均为 `REJECTED_FOR_DEPLOYMENT`，只能用于 parser 兼容诊断。官方检查器仍报告17个 depthwise Conv、GAP、MatMul、BN及 Q/DQ 警告，Add 需要 SoftNPU；35个普通Conv只是 HardNPU 静态候选，实际分区、执行与性能仍 `UNKNOWN`。

V4 parser-only 已在原 TF Linux（Ubuntu 20.04.1、kernel `6.1.111-rt42`、AArch64）完成板端限定测试。测试前后 `lsmod` 为空，`/dev/hard_npu`、`/dev/soft_npu`、`/dev/cma_mem` 均不存在；依赖库和94项头文件保持冻结哈希。严格 `-Wall -Wextra -Werror` 构建退出0，非root门禁正确拒绝，root `--gate-only` 返回0。FP32 batch1 控制模型解析返回/退出0，状态仅 `PARSER_PASS_LIMITED`；UINT8和INT8两图均在 `LoadGraphQuantORT()` 内以SIGSEGV/退出139失败，故障地址0，PC/LR固定为 parser load-bias `+0x42954/+0x42948`。该处是 `NodeConnections::operator[]` 返回对象内的vector数据指针为空后执行 `ldr w2,[x2]`，与V3的 `TensorInfo` 空指针故障不同。全程未调用Optimize/runtime/backend，未加载驱动或访问NPU/CMA设备。29文件结果已回收到 `F:/My_proj/_isolated_builds/softnpu_spatial_parser_v4_results_recovered_20260919_1`，源/目标29/29一致，内部清单28/28，清单SHA-256=`f224dada25103ec0df1bfe8e4654feddcd6880f189e992de699a7dba19aee81d`。V4包内量化环境字段勘误仍有效，以 `PYTHON_ENV_CHECK_PHASE.txt` 为准。

静态对照发现，本地冻结的8类安路公开量化样例（KWS、CRNN、手势、风机、叶片、YOLO检测/姿态/分割）的全部图输出都直接来自 `DequantizeLinear`；V4两个失败图则以 `DequantizeLinear→BatchNormalization→Relu→graph output` 结束。进一步反汇编重建确认，`NodeConnections` 对象偏移0是生产者索引vector，偏移24是消费者索引vector。解析器先确认起始节点有消费者，再沿一个明确包含`BatchNormalization`和`Relu`的可跳过算子集合追踪后继；循环在继续追踪时没有先检查当前游标节点的消费者vector是否为空。失败链中起始BN的消费者Relu属于该集合，随后程序直接读取终端Relu不存在的第一个消费者并在`0x42954`故障。逐图枚举显示，INT8失败图唯一零消费者节点是该终端Relu；UINT8失败图除70个未使用Constant外，唯一共同的非Constant零消费者节点也是同一终端Relu。当前最强结论仍为 `INFERRED`：冻结量化parser的可跳过算子消费者追踪未处理“链在图输出终止”，不是“BN/ReLU算子普遍不支持”的结论，须由V5单变量板端结果证实或证伪。为一次实验区分“尾部算子”“终端输出形式”和“量化生成差异”，工程外已生成UINT8/INT8各四图的V5矩阵：原失败控制、移除BN/ReLU尾部、保留尾部并补终端Q/DQ、早期完整QDQ图仅固定batch元数据。8图均通过完整ONNX检查和48帧CPU推理；补终端Q/DQ相对控制的余弦均值为 `0.9998027082/0.9999590508`，完整QDQ固定batch前后最大误差均为0。15文件包已写入U盘新目录 `DR1_SOFTNPU_SPATIAL_PARSER_V5_TERMINAL_QDQ_20260919_1`，源/回读15/15、内部清单14/14，清单SHA-256=`03f44a1a1fb7c8e0b9f0f0559f4060ed92bd1a20e804f89e83eaf82b320aab41`。当前状态仅 `USB_STAGED_ONLY/BOARD_NOT_RUN`，仍不授权Optimize或任何NPU执行。

U盘在写入前曾被Windows判定为FAT32脏卷；全部DR1目录已先备份235/235哈希一致，用户授权后又将可读个人/项目文件备份至 `F:/My_proj/DR1_USB_FULL_BACKUP_20260919_1`，632/634逐文件哈希一致，两个用户明确放弃的异常PPT目录项无法读取。`Repair-Volume -OfflineScanAndFix` 返回 `ErrorsFixed`；V5写入并回读后 `fsutil dirty query G:` 明确为 `NOT Dirty`，卷为Healthy/OK。用户当前确认U盘已插回板卡、板卡物理断电；电脑端COM4监听正在等待上电。下一步在同一设备遮蔽环境运行8图parser矩阵；任何返回都只能标记 `PARSER_PASS_LIMITED`，不得转入Optimize或NPU执行。

## 2026-09-18 晚间最新：V3 四格解析板测后依用户要求暂停

在原版板载 Linux 的**设备遮蔽、降权、独立进程、15 秒超时**条件下，仅运行 ONNX parser：FP32 控制图 `parse_return`；A0（原量化 Pool，缺中间 `value_info`）与 B0（官方风格拓扑，缺中间 `value_info`）均在 `parse_enter` 后 SIGSEGV/退出 139；只补中间 `value_info` 的 A1、B1 均 `parse_return`/退出 0。四图已在电脑通过 ONNX checker、shape inference 和 CPU 金样；该对照支持“中间声明影响冻结 parser”这一**限定结论**，尚未证明底层空指针根因、任意模型兼容或 NPU 运算。详情见 `docs/research/SOFTNPU_G4B_PARSER_MATRIX_V3_BOARD_20260918.md`。V3 探针首次严格 `-Werror` 构建因信号处理器忽略 `write()` 返回值失败；限定放宽该项后构建成功，不能称零警告构建。板端结果尚未从私有目录回收到电脑作独立复核。

本轮未加载 NPU bit、未运行 Optimize/后端、未启动 DMA 或 NPU 计算。主动 G4b 仍 `BLOCKED_BY_CONTRACT`（真实 packet、DMA/AXI、中断和失败恢复未闭合）。板载 Linux 已显示 `Power down`，电脑 COM4 已关闭；**物理电源关闭尚待用户确认**。用户要求现在暂停，旧 21:00 自动任务已删除；下一次须由用户明确恢复，先回收日志并定位故障 PC，再处理严格构建警告及下一轮解析差分，不得自动转入硬件运算。

## 2026-09-18 晚间恢复：Astra 建议落实到 parser 差分包

用户明确恢复 SoftNPU 工作并允许后续上板实践；先前 21:00 暂停已结束。独立审阅根目录 `SOFTNPU_ASTRA_RESPONSE_20260918.md`：接受“四格解析差分、故障位置采集与硬件数据面分开推进”的方向；不能把其假设写为段错误定因，也不能据此放行主动 G4b。当前板卡状态仅由用户确认“未上电”；U 盘位置待确认，尚未操作板卡。

在工程外新隔离目录 `F:/My_proj/_isolated_builds/softnpu_g4b_parser_matrix_20260918_1/`生成并校验 A0/A1/B0/B1：A0 为原317字节失败图，SHA-256 `599e8d0bfa59d1b7dba8da63c8ce8380ce1617caae1156dec368efd9140cde2d`；A1 仅补 `q_input/q_output` 的 value_info；B0/B1 是官方风格 `Q→DQ→FLOAT Pool→Q→DQ` 的无/有中间声明配对。A0/A1、B0/B1 清除 value_info 后模型序列化分别完全相同。四图 ONNX checker、shape inference 和 ONNX Runtime CPU 金样均通过，输出 `[1.25,1.75,3.25,3.75]`；这**不是**厂家 parser 或 NPU 通过。新 V3 探针保持 V2 设备遮蔽/降权门禁，仅增加共享库 load bias 与 SIGSEGV/SIGBUS 故障 PC/LR/SP 等采集，尚未目标 Linux 编译或运行。七项载荷和清单已复制/回读到工程外 `F:/My_proj/_isolated_builds/softnpu_g4b_parser_v3_pc_stage_20260918_1/`；原DR1 U盘 `G:` 的既有 V2 清单SHA匹配后，另在全新 `G:/DR1_SOFTNPU_G4B_PARSER_MATRIX_V3_20260918_1/` 复制八文件，源/USB回读8/8匹配且旧清单未变。状态仅 `USB_STAGED_ONLY/NOT_BOARD_BUILT/NOT_RUN`。下一步由用户安全弹出、物理断电下插回板卡，再做parser-only差分；设备 G4b 继续 `BLOCKED_BY_CONTRACT`。

## 2026-09-18 SoftNPU 故障恢复静态收窄

新P0解析假设：失败QDQ文件`graph.value_info=0`，Pool输入`q_input`没有显式中间类型/形状；官方CRNN目标Pool输入及上游有value_info，已通过FP32图只用graph端点。冻结`AddPoolingLayer`静态上从Pool输入名查`TensorInfo*`并直接构造TensorShape，局部未见空指针检查。缺中间声明是否导致退出139仍`UNKNOWN`，需未来只加value_info的隔离对照/崩溃栈证伪；本轮不运行。

官方9图IR均≤8，手写失败QDQ是IR9；然而已解析通过的FP32对照也是IR9，所以不能以IR9单独解释退出139。仅保留量化路径与IR版本交互的待检假设，未来隔离D/E配对验证；本轮不运行新图。

冻结parser的`SetTensorQuantInfoFromQuantNode`读取Q/DQ input(1/2)的scale/zero，并存在按raw_data存储取FLOAT scale及UINT8 zero后设置内部量化参数的静态路径；与15个官方Pool采用raw_data互相印证，但本次崩溃图是否进入该函数及后续TensorInfo正确性仍`UNKNOWN`。不能把raw_data本身定为失败原因。

ONNX内存形状推导补证：手写图Pool直接输入UINT8，穿过上游Q到FLOAT图输入；官方CRNN `/pool3/MaxPool` 在文件声明中直接输入为DQ输出FLOAT。冻结量化加载器只读指令已证明，在DQ输出资源指针非空时，其内部`OnnxTensor`类型会从DQ输入复制（`0x410fc/0x41150`）；因此不能由文件声明类型直接推定两图不同桥接分支。具体边实际内部类型、运行分支和退出139位置仍`UNKNOWN`。

`SetupInfo`会为官方DQ输出的`value_info`创建非空`TensorInfo`，却先把另一字段的资源指针置空；故文件含`value_info`不足以证明上述资源门槛成立。后续谁填充资源字段尚未追定，不把条件路径写成已执行事实。

门槛前目前只见预加载张量资源转移，CRNN该DQ输出不属于106个initializer；推断其资源指针可能仍为空、类型复制可能被跳过，尚非全链静态证明。后续解析/优化的真实量化Pool类型仍`UNKNOWN`。

冻结parser桥接方向已由只读指令和字符串交叉确认：当前边UINT8/INT8、追溯边FLOAT时选内部`ALQuant`；当前边FLOAT、追溯边UINT8/INT8时选`ALDequant`。这仅是静态条件，手写图实际分支及崩溃点未获运行轨迹，继续`UNKNOWN`。

官方示例参数存储补证：23个MaxPool上游DQ参数中，15个使用与手写故障图同类的标量 `raw_data`，8个使用类型专用字段；故 `raw_data` 单独不是充分段错误解释。官方CRNN `/pool3/MaxPool` 更接近手写图的opset14、2×2/stride2、raw_data条件，但其IR7、显式pads/ceil_mode及DQ→FLOAT Pool拓扑仍不同，且下游Q不复用上游DQ参数。静态参照已锁定，未裁剪/运行新图；崩溃根因继续`UNKNOWN`。

补充 parser 静态桥接缺口：冻结 `ParseALQuant/ParseALDequant` 对输入/输出均要求1/1，官方 KWS ONNX 的原生 Q/DQ 为3/1。只读反汇编已定位量化模式 `FindRealInputName` 跳过原生 Q/DQ，`LoadGraphQuantORT` 对原名与追溯后的真实输入名比较张量类型，仅不一致时合成 1/1 的 `ALQuant/ALDequant` 桥接节点；但具体 KWS 节点的参数绑定、桥接条件及调度全链未追完，也没有崩溃栈，不能把数量差异认定为QDQ图退出139的根因。后续先离线追完整桥接，再考虑任何新的有界解析试验。仍只做电脑静态分析，21:00暂停。

冻结 Arm NN 库的 `wait_for_soft_npu_irq` 以1000ms、NN/YOLO掩码`0x0c`等待内核中断；ioctl失败抛异常，已审函数内没有停止、复位或AXI排空。Pool workload 的 normal/dma 两条路径会在发命令后调用该等待。内核 `soft_npu.c` 超时仅返回`-ETIME`。库中名为`r_SoftNPU_reset`等函数只是软件寄存器镜像的内存清零，不能当硬件故障复位。以上是局部函数证据，完整异常链及动态packet未穷尽；超时后的设备停止和缓冲安全释放仍`UNKNOWN`，主动 G4b 保持`BLOCKED_BY_CONTRACT`。本轮仅电脑静态分析，21:00按用户要求暂停。

旧外部V2快照路径`F:/My_proj/_snapshots/fdma_imx415_20251008_v2_known_good_20260908`本次只读检查仍不存在；不得把仓库本地17/17清单通过写成外部完整备份可用。未来任何主动硬件实验仍须先核对回退条件。

原始产品空间ONNX的172节点计数还包含70个Constant（均为35个Clip提供阈值）、10个Add及GlobalAveragePool/MatMul/BatchNormalization等；公开检查脚本不提供逐层加速保证。`soft_npu_write`本身只执行“映射基址＋调用者偏移”的存储，normal-mode packet可提供动态偏移，故将来真实packet需逐字审计偏移/长度/副作用；不能直接用合成packet启动。简化/量化后的实际图、后端分配与硬件速度均`UNKNOWN`。

原图的35个普通Conv对`split_convFC.py`输入/滤波tile阈值静态全满足（最大16128/960，对应阈值186368/4736）；17个depthwise按脚本分支跳过，原图也无Gemm/ReduceMean/Slice，因此对原图的split分支预期为false。正式流程先运行onnxsim，本轮没有执行，实际简化图和是否split仍`UNKNOWN`；尤其需要核对no-split路径所保存的模型与之后内存中升级opset的预检对象是否一致。

产品空间模型训练预处理为RGB直接缩放224×224，再用`(pixel/255－ImageNet mean)/std`；厂家量化reader默认保比例letterbox并用`mean=0、scale=1/255`，不能直接用于本模型校准。按厂家`(raw－mean)×scale`公式，数值等价的候选参数为mean`[123.675,116.28,103.53]`、scale约`[0.01712475,0.01750700,0.01742919]`，但几何、色彩和插值仍需与训练/板端逐张核对。未执行转换或校准；量化可用性`UNKNOWN`。

冻结parser的`ParseConv`在ONNX `group`等于输入通道且大于1时走`AddConvLayerWithDepthwiseConv→AddDepthwiseConvolution2dLayer`，与普通Conv层分开。现有空间图17个depthwise满足该条件；Alnpu对通用depthwise的支持槽仍为默认拒绝。实际量化图解析、额外优化和最终CPU/Hard/Soft分配未执行，17层归属保持`UNKNOWN`。

源图35个Clip全是0..6的ReLU6形式，其中18个紧跟普通Conv、17个紧跟depthwise。冻结parser静态将Clip映射到`BoundedReLu`，Hard Conv转换器的局部`checkAct`允许此枚举；这只提供融合候选类型条件，不是18层已融合，也不改变depthwise限制。量化后图及逐层分配仍`UNKNOWN`。

官方KWS冻结ONNX（IR7/opset12）内有2×2/stride2/pad0的`DQ→FLOAT MaxPool→Q`局部，Q复用上游DQ的标量scale和UINT8 zero-point；比手工`Q→UINT8 MaxPool→DQ`更适合作下一轮受控裁剪来源。但该局部尚未裁剪/解析，不能报告parser或硬件通过。

真实模型10个Add不能按旧式`IsAdditionSupported`默认拒绝直接归类为CPU：冻结parser创建`ElementwiseBinaryLayer(Add)`，Alnpu新式`IsLayerSupported`对该类型有调用`soft_npu_op_supported(4)`的专门分支，并有Soft Add workload。真实能力位、量化/形状门槛及10层实际分配未验证，保持`UNKNOWN`；新旧支持入口须区分。

该新式Add分支局部要求8位量化类型`[2,6,7]`，并检查相同总元素数/类型；原始空间图的10个Add在形状推导下逐节点两输入与输出形状一致，但FP32源图不满足量化类型。能力bit4、量化边参数、完整支持结果和硬件执行继续`UNKNOWN`。

隔离候选IP配置有`NN_SHORTCUT=1`并生成对应宏，提供Soft Add候选的配置线索；未给出寄存器`0x20` bit4的实测或完整语义，不能据此提升支持状态。

厂家冻结`run_quant.py`有UINT8 QDQ（权重/激活QUInt8）与INT8 QDQ（权重/激活QInt8、per-channel、对称选项）两支。各局部Hard/Soft支持函数接受若干8位枚举，并不能保证任选一支可使整网通过；本轮未量化、未比较数值或分配。

候选IP-XACT的内部地址块从`0x91000000/0x91000800/0x91001000/0x91001800`排列；冻结normal-mode packet写分支把`0x6f000000`加至条目地址，32位模加后`0x91000000`恰变为映射偏移0。故normal软件模式下该常量是内部packet寄存器编码、不是PS物理窗口；DMA模式硬件如何解码及候选bit兼容性仍`UNKNOWN`。

冻结`AlnpuBackend::RegisterTensorHandleFactories`内直接连续调用Hard与Soft设备初始化，不能假设只研究Soft就不会打开Hard设备；此方法是否触发先前`dlopen`异常尚无栈证据。未来parser/Optimize/runtime探针必须分别隔离、审查双设备副作用。

公开等待结构虽有`work_status`字段，冻结Soft驱动等待分支未填充它；用户态等待只接受NN bit2或YOLO bit3标志。等待返回0不等于Pool数值/错误状态确认，真实完成IRQ、DMA覆盖范围与金样均待未来授权板测。

## 2026-09-18 Alnpu Pool 类型支持的静态边界

冻结 `libarmnn.so.32.1` 中 `AlnpuLayerSupport::IsPooling2dSupported` 首先检查 `soft_npu_op_supported(0)`，然后对输入、输出要求 8 位量化类型（`QAsymmS8`/`QSymmS8`/`QAsymmU8`），并检查两端类型相同；其它布局、维度等条件尚未完整判定。这是只读反汇编与冻结 `armnn/Types.hpp` 枚举的交叉核验，不是实际后端分配。板端 FP32 MaxPool **仅解析通过**，不能据此认定 Alnpu Pool 可用。官方示例 ONNX 的 `DQ→float MaxPool→Q` 在 parser/优化后能否变成符合上述条件的 Arm NN 量化 Pool 仍 `UNKNOWN`。当前只做电脑静态分析，主动 G4b 保持 `BLOCKED_BY_CONTRACT`。

冻结 parser 的 `LoadGraphQuantORT` 有设置量化 scale/offset 后将内部 `TensorInfo` 类型直接写成2或6（`QAsymmU8/QSymmS8`）的静态路径。这缩小了官方 QDQ 图可能被内部量化表示的疑问，但尚未定位具体 Pool 边，未运行优化或 Alnpu 分配；上述 `UNKNOWN` 不变。

另查冻结运行库，`soft_npu_op_supported(0)` 实际调用 `soft_npu_read(0x20)`，后者从 `/dev/soft_npu` 映射指针直接读寄存器；驱动初始化会读写打开设备并映射寄存器。因此后端 Pool 支持检查不是纯软件/无设备步骤。当前不运行 Optimize 或公开驱动，不把 parser-only 通过推广成后端安全可检查。

当前候选和 D20.3 官方示例的 IP-XACT `TOP` 寄存器表均未列相对 `0x20` 的能力位语义，尽管候选生成宏启用 `NN_POOLING`。该位是否实现、读值为何均 `UNKNOWN`；元数据缺项不能推断硬件不支持 Pool。

只读反汇编进一步确认冻结 Alnpu Pool 的部分必要条件：NCHW、输入4维且batch1、Max Pool、方形2/5/9/13核、X/Y相同的1或2 stride。当前2×2/stride2探针仅在该几何子集内；padding/输出形状、量化后的实际张量、能力位和分配均未通过。

9个公开示例的23个 MaxPool 中有2个CRNN节点使用stride(2,1)，不满足冻结 Alnpu Pool 的等stride必要条件；CRNN默认允许CpuAcc/CpuRef回退。不能把公开模型或运行输出当成逐节点NPU加速证明；该两节点的实际后端仍`UNKNOWN`。

同一Pool支持函数的输入维度局部上限为通道2047、高/宽1023，下限均为1；4×4诊断图和真实空间候选的3×224×224均在此范围内，但真实候选无MaxPool，该事实不提升产品模型的NPU完成等级。

真实空间候选的35个普通Conv按冻结`checkConv`已解出的形状/属性条件静态预筛为35/35（dilation1、方形1/3/5/7核、受限stride/中心padding、权重输入通道×核面积≤4736，实值最大960）。但源图为FP32，不满足该转换函数的量化8位类型门槛；转换产物、逐层后端分配与实际加速仍`UNKNOWN`。17个depthwise另行处理，不能计入35层预筛。

冻结`armnn::Optimize`静态上仅在偏好后端包含`ALRef`或`Alnpu`时调用Conv/FC专用层转换流程；因此转换路径确有条件入口。当前尚未执行项目量化图，转换层数与真实Alnpu分配仍`UNKNOWN`，也不能默认`ALRef`离线运行无设备副作用。

`ALRef` 后端上下文构造只返回空上下文，局部工厂/子图优化及Pool/ALHardNPU支持函数未见直接设备调用；全局优化、虚调用与动态库构造链尚未审完，故无设备安全性仍`UNKNOWN`，本轮不运行。

未来首个真实模型相关Hard Conv可考虑源ONNX的`/backbone/backbone.7/conv/conv.2/Conv`：batch1输入`[1,192,14,14]`、1×1权重`[64,192,1,1]`、输出`[1,64,14,14]`，三者共62464个8位元素的静态下界。此层尚未单独导出或量化，实际buffer/packet、后端分配和设备执行均`UNKNOWN`。

源图17个depthwise均在Conv拓扑次序中夹在普通Conv之间。仅普通Conv上NPU、depthwise留CPU且每个边界搬运完整8位特征的条件假设下，17层输入＋输出约6043072字节/帧；实际分区、零拷贝、缓存和延迟均未知，不能由普通Conv的MAC占比预测整网帧率。

全部23个官方 Pool 输入 DQ 输出再查消费者数：18个fanout=2、5个fanout=1；手势图中 DQ 输出同时供 Pool/Concat。冻结 parser 的“DQ 输出不应被其他节点使用”文本已反汇编定位至**DQ 输出名哈希查重**分支；另一个循环会统计输入使用次数，并非在第二消费者处抛这句异常。该文本不能视为普遍禁用多消费者；官方示例实际解析与设备执行仍未由此证明。

公开执行器源码在 ONNX 解析**之前**就创建 `IRuntime`，解析后又创建一次，因此标准 demo 不能作为 parser-only 无设备副作用对照。当前隔离解析探针并未创建 runtime；两者不可混用为同一证据。

公开 `soft_npu.c` 超时仅回 `-ETIME`、无独立 reset/abort ioctl；原始 `READ_REG/WRITE_REG` 和 `mmap` 路径未见完整偏移、长度校验。不可直接加载它作为当前候选的安全探针，更不能据超时返回释放 NPU 仍可能访问的缓冲。此结论只读源码，非目标硬件故障试验。

本地 IPUG166 v1.0 手册正文第6页要求配置侧 CLP 复位先于系统侧内部工作复位，分别至少10个时钟周期；两时钟同源同频。隔离候选生成 `system.v:1410-1418` 将 NPU 两复位端接**同一共享网**（亦接 AXI/temporal conv），与 `Design.xml:2164-2180` 的 master reset 连接记录相矛盾。安路三个公开示例也采用同网，不能仅凭此断言冷启动违规；IP 内部复位寄存器虽存在但忙时语义缺失。现有候选未证明 NPU-only 超时停止及 AXI 排空，主动 G4b 保持 `BLOCKED_BY_CONTRACT`，不推断普通 NPU 计算必失败。

IPUG166 标称 Soft MaxPool 支持2×2且stride1/2；当前诊断图2×2/stride2与候选配置 `NN_POOLING=1` 在静态范围内，但 QDQ 解析崩溃、后端与设备均未通过，不能把 IP 算子规格代替软件栈验收。

冻结 parser `LoadGraph` 静态扫描预加载张量类型码2/3并选择量化分支；QDQ极小图有UINT8 zero初始化值、FP32对照无初始化值，故量化分支触发是 `INFERRED` 优先线索而非崩溃栈。下一步仍需隔离解析对照和真实后端分配证据，当前不做板测。

## 2026-09-18 parser 崩溃的只读静态线索与 Astra 交接

真实模型范围校正：候选 manifest 指向的空间 ONNX SHA-256=`30e290aa1441a818178be38b1c9a27aba0f0d4a8f9edd27d54d34cfbe1c71fee` 已只读复核，为 IR8/opset17、`[N,3,224,224]→[N,128]`，52 Conv（35普通、17 depthwise）、10 Add、35 Clip、0 MaxPool。静态卷积 MAC 中普通/深度约93.1%/6.9%，非延迟测量。公开检查器标记 DWConv 不能由 ALNPU 加速；真实后端分配、融合与 CPU 回退仍 `UNKNOWN`。当前最小 Pool 图仅是 SoftNPU 通路诊断，不能视为当前 MobileNetV2 加速或模型部署证据。

普通 Conv 属性已复核：34个1×1/stride1/pad0及1个3×3/stride2/pad1均显式具备 `kernel_shape/strides/pads`，满足公开检查器列出的普通卷积尺寸条件；17个 depthwise 均3×3/pad1（13个stride1、4个stride2），仍触发其警告。静态条件通过不是 HardNPU 后端分配通过，也不能以约93.1%卷积 MAC 推算端到端帧率。

冻结 `libarmnn.so.32.1` 的 `AlnpuLayerSupport` vtable/重定位已只读确认：通用 Conv2d 与 Depthwise 支持槽均继承 `LayerSupportBase` 的默认拒绝路径；专用 `ALHardNPU` 层及 Pool 则有 Alnpu 自身支持函数。普通卷积若要加速，需另外证明优化后的专用层形成及实际分配；深度卷积、CPU回退和真实模型数值/速度继续 `UNKNOWN`。这不是设备执行证据。

同库导出 `ConvertConv2dIntoALHardNPUImpl::checkConv/Run/RunOptimization`，所以 Conv→专用层转换实现确实存在；实际候选图是否经过该变换仍 `UNKNOWN`。不可把符号存在写成35个普通 Conv 已由硬核执行。

`checkConv` 只读反汇编的张量类型门槛仅接受 Arm NN `QAsymmU8`(2) 或 `QSymmS8`(6)，不接受原始空间图的 `Float32`(1)。因此需要验证量化后的真实图及专用层形成；FP32 模型本身不能据几何尺寸合格就称 HardNPU 可分配。

追加全量只读对照：冻结 SDK `demo_inputs/` 的 9 个 ONNX 中，8 个模型共有 23 个 MaxPool，全部为 `DequantizeLinear→MaxPool→QuantizeLinear`，各节点显式含 `ceil_mode/kernel_shape/pads/strides`。手写 QDQ 小图让 UINT8 直接入池化且缺 `pads/ceil_mode`；但已成功解析的 FP32 对照同样缺这两属性，故“缺属性”不能单独解释段错误。静态优先假设仍是节点 dtype/拓扑差异，实际崩溃指令及修复效果 `UNKNOWN`。本轮没有新的厂家解析或板端调用。

公开转换入口的只读审查又确认：`AL_onnx_pass.py` 默认校准路径固定 RGB 三通道图像，不能不加适配地用本项目 1 通道极小 Pool 图；README 声明会在输入 ONNX 同目录生成中间/量化模型。无 split 分支在写 `*_sim.onnx` 后仅把内存模型升级到 opset19作检查，实际量化仍读取先前保存版本；这是待隔离产物核验的流程风险，不是当前解析崩溃根因。未执行任何转换或覆盖模型。

冻结 parser ELF（SHA-256=`dcb43bc092ec283364806e563fa6aa8d2404eb7c005db44081821da405c5ce99`）符号及 AArch64 反汇编表明存在 `LoadGraphQuantORT` 量化分支和多处 `SetTensorQuantInfoFromQuantNode` 调用，但本轮无崩溃栈，不能把退出 139 精确归因于该函数。冻结官方 KWS、手势、YOLOv8n 三个 QDQ 示例中检查到的 MaxPool 输入均来自 `DequantizeLinear`，即 ONNX 图层面为浮点池化；崩溃的手写极小图为 `QuantizeLinear→uint8 MaxPool→DequantizeLinear`，ONNX shape inference 确认池化输入/输出为 UINT8。进一步只读反汇编确认普通 `ParseMaxPool→AddPoolingLayer` 路径在 `ComputeOutputInfo` 调用处经重定位传入 `onnx::TensorProto::FLOAT`；这提高了结构差异的排查优先级，但无证据证明崩溃图实际走到该函数。仅在 PC 内存中构造未保存的官方风格 `Q→DQ→float MaxPool→Q→DQ` 极小图，checker/shape inference 通过，中间类型 `UINT8/FLOAT/FLOAT/UINT8`；没有让冻结 parser 读取。结构差异是优先排查假设，不是已证明根因。公开 `run_quant.py` 使用 ONNX Runtime `QuantFormat.QDQ`。已将现状、P0/P1/P2 阻塞及供 Astra 判断的问题汇总在工程根目录 `SOFTNPU_ASTRA_BRIEF_20260918.md`，当前用户限定只做静态分析，今晚 21:00 暂停目标。主动 G4b 仍 `BLOCKED_BY_CONTRACT`。

## 2026-09-18 G4b ONNX parser V2 板端差分定位（不涉及 NPU 执行）

原 TF Linux 6.1.111-rt42 启动；U 盘新包只读校验 3/3、板端私有旧包 7/7 和头文件 94/94 均通过。新板端私有目录严格编译退出 0；非 root 负门禁退出 2，root 无库隔离门禁退出 0。15 秒上限的 FP32 MaxPool 对照图经冻结 Arm NN ONNX parser 返回非空网络，退出 0，阶段标记走到 `parse_return`，状态仅 `FP32_ONNX_PARSE_PASS_LIMITED`。同条件下，原 QDQ/UINT8 MaxPool 图在 `parse_enter` 后、`parse_return` 前段错误，退出 139、stdout 0，状态 `QDQ_ONNX_PARSE_CRASH_REPRODUCED`；精确内部根因仍 `UNKNOWN`。两次都没有 Optimize、runtime、后端分配、模型推理或 NPU/DMA/IRQ 操作。后检模块为空、U 盘卸载、异常日志过滤无输出；Linux 已显示 `Power down`、COM4 已关闭，用户确认物理断电。主动 G4b 仍 `BLOCKED_BY_CONTRACT`；下一步先离线分析 QDQ parser 崩溃并选择可解析的模型表示，不能把 FP32 解析成功等同于 SoftNPU 可运行。详见 `docs/research/SOFTNPU_G4B_ONNX_PARSE_STAGE_V2_BOARD_20260918.md`。

## 2026-09-18 parser V2 已暂存原 DR1 U 盘（未板端运行）

以旧 V3 清单哈希识别用户的 `G:` U 盘，V2 新目录此前不存在。四文件源端/USB 回读 4/4 相同，包内三载荷清单 3/3，旧 V3 清单未变。状态仅 `USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`。用户已收到 Windows 安全弹出、保持板卡物理断电并插回的请求，尚待确认；当前不能上电。V1 退出 139 的崩溃阶段、QDQ 支持与 SoftNPU 硬件计算仍 `UNKNOWN`，主动 G4b `BLOCKED_BY_CONTRACT`。见 `docs/records/worklog/2026-09/2026-09-18-softnpu-v21-parser-usb-stage.md`。

## 2026-09-18 parser V2 电脑侧隔离包已备（未写 U 盘）

V2 分阶段源码、说明、三载荷清单和 FP32 对照图已复制到此前不存在的工程外独立目录 `F:/My_proj/_isolated_builds/softnpu_g4b_parser_v2_pc_stage_20260918_1/`；源/副本 4/4 哈希一致，包内 3/3。状态只到 `PC_STAGED_ONLY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。V1 段错误原因、QDQ 是否被厂商 parser 接受及 SoftNPU 硬件计算仍 `UNKNOWN`；主动 G4b `BLOCKED_BY_CONTRACT`。下一步等待用户方便时在物理断电条件下把 U 盘接电脑，一次传输并回读，随后才可上板做隔离解析。安路问答页本轮未能读取、未提交问题。见 `docs/records/worklog/2026-09/2026-09-18-softnpu-v20-parser-pc-stage.md`。

## 2026-09-18 ONNX parser 崩溃差分对照已离线备妥

V1 退出 139 的精确阶段仍 `UNKNOWN`。现有 317 字节 QDQ 图再次通过 ONNX checker；另在工程外新隔离目录生成 205 字节 FP32 MaxPool 对照图，ONNX checker/PC CPU 黄金输出通过，输入与输出均与原 QDQ 样例逐字节相同。上游 Arm NN 文档将通用 ONNX parser 支持限定为 FP32，但安路冻结 parser 含 QDQ 节点名称，不能据此断言本地图支持或不支持。V2 阶段标记源码、说明与 FP32 图的三载荷清单源端 3/3 匹配；状态仅 `SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。下一轮计划一次 U 盘传输，先 FP32 对照、通过后再考虑 QDQ，均不创建 runtime 或运行 NPU。主动 G4b 仍 `BLOCKED_BY_CONTRACT`。见 `docs/research/SOFTNPU_G4B_PARSER_CONTROL_PREP_20260918.md`。

## 2026-09-18 固定 ONNX parser-only V1 板端尝试失败（非 NPU 运算）

U 盘和板端私有副本分别通过七载荷 7/7 与头文件 94/94 哈希；目标严格编译、非 root 负门禁、root 无库隔离门禁均符合预期。唯一一次 15 秒上限解析调用发生段错误，退出 139，stdout 0 字节、stderr 43 字节；**没有 ONNX 解析成功证据**。V1 无阶段标记，崩溃点在库加载、parser 创建或读图中的哪一步仍 `UNKNOWN`。没有运行后端、NPU 或 DMA。板端后检 `lsmod` 空、异常日志过滤空，Linux `Power down`、COM4 关闭，用户确认物理断电，U 盘/TF 卡保持不动。保持门禁的 V2 阶段标记源码、说明及两载荷清单已离线准备并核对，状态 `SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`；下一轮尽量一次 U 盘往返定位。主动 G4b 仍 `BLOCKED_BY_CONTRACT`。见 `docs/research/SOFTNPU_G4B_ONNX_PARSE_ONLY_V1_BOARD_20260918.md`。

## 2026-09-18 固定ONNX解析包已暂存U盘（未板端运行）

用户在板卡断电时把原DR1 U盘转电脑；以旧V3包清单SHA-256=`4d6b1e27fad229232c624c5b1eaca0c08f1475fb537531b2892914f923535ad1`识别同一介质。新目录`G:/DR1_SOFTNPU_G4B_ONNX_PARSE_ONLY_V1_20260918_1/`原先不存在；八个顶层文件源端/回读一致、七载荷清单7/7、公开头文件94/94逐项回读一致，旧V3清单未变。仅`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`。尚需用户安全弹出并在物理断电板卡插回；本结果不代表ONNX parser接受图或任何NPU执行。见`docs/records/worklog/2026-09/2026-09-18-softnpu-v17-onnx-parse-usb-stage.md`。

## 2026-09-18 固定ONNX的Arm NN解析前置探针已备（未传输/运行）

针对V3仅验证伪workload的边界，已离线准备`tools/npu/g4b_onnx_parse_only_v1.cpp`：先遮蔽`/dev`/`/sys`/`/proc`、隔离网络/继承FD并降权，然后才加载冻结Arm NN、protobuf、ONNX parser，仅调用`CreateNetworkFromBinaryFile`。不调用`Optimize`、创建runtime、分配后端或执行模型。动态符号与SONAME/NEEDED已从冻结库核对，精确三库和317字节ONNX哈希已记录；公开头文件94/94哈希清单通过，七载荷清单源端核对。状态`SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`，解析是否接受此图仍`UNKNOWN`。板卡按用户确认物理断电、U盘仍在板卡；下次需用户断电转移U盘后再暂存，**当前不需要上电**。主动G4b仍`BLOCKED_BY_CONTRACT`。见`docs/research/SOFTNPU_G4B_ONNX_PARSE_ONLY_PREP_20260918.md`。

## 2026-09-18 G4b固定描述符厂家软件填充/打包V3通过（硬件仍未执行）

原TF Linux `6.1.111-rt42`与U盘`/dev/sda1` UUID`C568-76B8`正常；只读U盘及板端新私有目录清单各3/3、目标严格构建、非root拒绝和root无库隔离门禁通过。唯一一次15秒上限、无设备节点的软件调用退出0：三entry的14数据字均与修正候选一致，厂家软件打包得20字/80字节。237字节原始JSON在`tools/npu/evidence/g4b_v3_vendor_fixed_pool_fill_20260918.json`，板端与本地SHA-256同为`d75c7e4650782a893ce58ce3c255d9d790d5fa6fc4f57b118adb521e68305b9d`；离线独立解析无差异并标出末尾`NN_start`副作用候选。限定结论`VENDOR_FIXED_DESCRIPTOR_SOFTWARE_PACKET_PASS_LIMITED`：不是ONNX模型实际包、Alnpu后端分配、CLP接受、NPU主AXI/DMA、完成IRQ或Pool算子板测。前后模块空、dmesg异常筛查空；Linux到`Power down`、COM4关闭，用户确认物理断电。主动G4b继续`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_G4B_POOL_FILL_V3_BOARD_20260918.md`。

## 2026-09-18 G4b Pool填充V3已暂存U盘（尚未板端运行）

用户确认板卡物理断电并把原DR1 U盘接电脑；旧V2清单SHA-256=`ae6f7d3380f4cbf5518c5874f83cb927cdb3a9167ed00fd2924554`与记录一致。新建此前不存在的`G:/DR1_SOFTNPU_G4B_POOL_FILL_CAPTURE_V3_20260918_1/`，只复制V3源码、README、清单及冻结库；源端/U盘4/4 SHA一致、U盘清单3/3，旧V2清单未变。状态`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`。已请用户安全弹出并在物理断电时插回，完成回复待确认；不能把U盘暂存写成软件/硬件通过。主动G4b仍`BLOCKED_BY_CONTRACT`。见`docs/records/worklog/2026-09/2026-09-18-softnpu-v14-pool-fill-v3-usb-stage.md`。

## 2026-09-18 G4b Pool填充V3有界全字诊断源码已备

在不触板情况下，从冻结V2独立派生V3：修正已由厂家软件实测及反汇编支持的`0x1834`首字期望，最多报告14个entry数据字差异，任一差异仍退出2且不输出包。V2→V3 diff已审查，仅改这点、版本标记和有界继续比较；源码、README及冻结库清单3/3核对。状态`SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。用户已确认板卡物理断电；已请其在断电下将U盘转电脑供全新目录暂存，尚待回复。主动G4b仍`BLOCKED_BY_CONTRACT`，这不放行NPU硬件。见`tools/npu/G4B_VENDOR_POOL_FILL_CAPTURE_V3_README.md`。

## 2026-09-18 G4b Pool填充V2首字差异已定位（无设备计算）

用户确认U盘插回断电板卡后上电；原TF Linux `6.1.111-rt42`正常，U盘`/dev/sda1` UUID`C568-76B8`枚举。只读USB及新板端私有目录清单各3/3、目标严格编译、非root拒绝和root无库隔离门禁通过。唯一一次15秒上限的厂家**软件**填充调用退出2，首个不符字为entry1/`0x1834`/word0：实际`0x00101004`，旧静态预期`0x00401001`；JSON为0字节，未生成或提交包。离线复核冻结库反汇编表明旧候选把C/H/W打包位序写反；实际字可拆成C=1、H=4、W=4。已修正离线候选工具并通过自测，V2探针/USB包不改。其它13个字是否匹配仍`UNKNOWN`。板端后检无异常，Linux到`Power down`、COM4已关闭；用户确认物理断电。主动G4b仍`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_G4B_POOL_FILL_V2_BOARD_20260918.md`。

## 2026-09-18 G4b Pool填充差异V2已暂存U盘（未板端运行）

用户确认原DR1 U盘已插电脑；以旧V1包清单SHA-256=`a631f091d1e6c457c5d7991670e6adace2153e0ae277fbf8feef75addd805d8fc`识别介质。新建此前不存在的`G:/DR1_SOFTNPU_G4B_POOL_FILL_CAPTURE_V2_20260918_1/`，只复制V2源码、README、清单及冻结厂家库；源端与U盘回读4/4 SHA一致，清单载荷3/3通过，旧V1清单未变。状态仅`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`。已请用户在Windows安全弹出、保持板卡物理断电后插回U盘，尚未收到完成确认；不请求上电。主动G4b仍`BLOCKED_BY_CONTRACT`，不执行设备start/DMA。详见`docs/records/worklog/2026-09/2026-09-18-softnpu-v12-pool-fill-v2-usb-stage.md`。

## 2026-09-18 G4b Pool填充差异V2已备（尚未传输/运行）

针对V1已证实的“至少一个软件entry字与静态候选不同”，保留冻结V1及旧U盘包，新V2只增加首个差异的entry/偏移/字序号/期望/实际UINT32限界诊断，仍在校验失败时退出且不输出包。V1→V2逐行差异已审查，无设备访问新路径；新源码、README、冻结库清单3/3，清单SHA=`ae6f7d3380f4cbf5518c5874f83cb927cdb3760cdccdb3a9167ed00fd2924554`。状态`SOURCE_READY/NOT_USB_STAGED/NOT_TARGET_LINUX_BUILT/NOT_RUN`。用户确认板卡物理断电，下一步需将U盘转电脑，在全新目录暂存并回读。G4b主动设备仍`BLOCKED_BY_CONTRACT`，静态推导差异原因`UNKNOWN`。

## 2026-09-18 G4b固定Pool填充V1板端发现软件值不一致

首次启动U盘未枚举；用户物理断电重插后，同一U盘`/dev/sda1`/UUID`C568-76B8`出现。只读U盘和板端私有副本清单各4/4，目标G++严格构建、非root拒绝和root无库隔离门禁通过。一次限时厂商Pool**软件填充**调用退出2：entry中至少一字与静态候选不同，JSON 0字节，未进入软件打包输出，更没有设备start/DMA。具体差异尚`UNKNOWN`，不能改预期值求通过。运行后模块仍为空、dmesg筛查无异常，Linux到`Power down`，COM4关闭，用户确认物理断电。子阶段`VENDOR_POOL_FILL_SOFTWARE_MISMATCH/NO_PACKET`；V2拟仅报告首个不一致的entry/字/实际值，保持所有门禁。G4b设备仍`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_G4B_POOL_FILL_V1_BOARD_20260918.md`。

## 2026-09-18 固定Pool填充探针板端前置中止：U盘未枚举

用户称U盘已安全插回断电板卡后，COM4监听先启动再由用户上电。原TF Linux `6.1.111-rt42`正常进入root控制台，`lsmod`为空；但`lsblk`没有`/dev/sda`，`lsusb`仅见USB集线器、Wi-Fi及root hub，内核USB/SCSI日志未见存储设备枚举。故**未挂载U盘、未复制/编译/运行新探针**，不能把先前`USB_STAGED_ONLY`提升为板端通过。Linux执行`sync`、`poweroff`并显示`reboot: Power down`；原串口进程在回合中断后句柄已失，电脑端独立打开/关闭COM4确认端口空闲。物理断电及U盘重插待用户确认。G4b设备仍`BLOCKED_BY_CONTRACT`。详见`docs/records/worklog/2026-09/2026-09-18-softnpu-v9-usb-enumeration.md`。

## 2026-09-18 G4b固定Pool填充探针已暂存U盘（未板端运行）

用户确认板卡断电、U盘接电脑后，先用旧G4b包清单SHA核对`G:`为既有DR1 U盘，再在此前不存在的新目录`G:/DR1_SOFTNPU_G4B_POOL_FILL_CAPTURE_V1_20260918_1/`暂存固定Pool填充探针、ABI静态检查源、README、清单和冻结厂家库。源端/U盘回读5/5 SHA一致，U盘清单4/4匹配。状态仅`USB_STAGED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_RUN`；没有板端厂家填充调用、ONNX解析或NPU执行。下一步用户Windows安全弹出U盘、保持板卡物理断电插回；板端首先只读核包和私有目录目标构建/门禁。主动G4b仍`BLOCKED_BY_CONTRACT`。详见`docs/records/worklog/2026-09/2026-09-18-softnpu-v8-pool-fill-usb-stage.md`。

## 2026-09-18 G4b固定Pool厂商填充探针仅完成离线准备

针对现有固定QDQ+MaxPool样例，已从冻结库反汇编和公开头文件核对Pool填充函数读取的workload/handle字段及`TensorInfo`构造入口；新增只对这组参数有效的无设备探针，调用厂家填充后须逐字匹配三entry才输出软件JSON。AArch64头文件/ABI无输出语法检查通过，四文件SHA清单4/4通过；完整探针**未目标Linux构建、未暂存U盘、未板端运行**。探针不解析ONNX，所以未来软件结果也不能冒充真实模型包。下一步需用户在物理断电状态把U盘移到电脑供新目录暂存，随后按门禁决定是否板端运行。NPU-001保持`DOING/P0`、主动G4b仍`BLOCKED_BY_CONTRACT`。详见`docs/research/SOFTNPU_G4B_VENDOR_POOL_FILL_PROBE_PREP_20260918.md`。

## 2026-09-18 G4b厂家合成Pool软件raw包已捕获，头字段纠错

原TF Linux上，V1探针经只读U盘与板端私有目录两次清单3/3、目标G++构建、非root拒绝和root无库隔离门禁后，单次限时调用冻结厂家打包函数退出0。原始220字节JSON板端与工程内SHA-256均为`72f51e5f41943979fdf5f9513c58246fa554bedf7ce77891ce664c59956418bc`；对应3个type0 entry、20字/80字节。反汇编与真实软件输出共同纠正旧推断：类型0头是`0xff000000+字数`，不是`0x40000000+字数`。离线逐字核验为`STRUCTURE_ONLY`，末尾`0x1814 NN_start`为副作用候选。仅接受`VENDOR_SYNTHETIC_SOFTWARE_PACKET_CAPTURE_PASS_LIMITED`：它是reset镜像开Pool bit，不是ONNX模型包、CLP/NPU设备执行或DMA通过。设备G4b仍`BLOCKED_BY_CONTRACT`，下一步离线取得固定模型实际包并闭合NPU-only停机/主AXI排空及缓冲生命周期。板载Linux已到`Power down`，用户确认物理断电。详见`docs/research/SOFTNPU_G4B_VENDOR_SYNTHETIC_PACKET_CAPTURE_20260918.md`。

## 2026-09-18 G4b软件包探针已暂存U盘（板端未运行）

用户确认U盘插电脑后，电脑`G:`既有DR1目录及V3清单SHA与记录一致；新目标目录此前不存在。四文件已写入`G:/DR1_SOFTNPU_G4B_PACKET_CAPTURE_V1_20260918_1/`，源端/回读4/4 SHA一致、U盘清单3/3通过。状态仅`USB_STAGED_ONLY/BOARD_NOT_TARGET_BUILT/BOARD_NOT_RUN`，没有运行C++探针或厂家打包函数，更没有NPU设备操作。需用户Windows安全弹出U盘，在板卡物理断电时插回并保持断电；再建立COM4监听后由用户上电。见`docs/records/worklog/2026-09/2026-09-18-softnpu-v5-packet-usb-stage.md`。G4b设备执行仍`BLOCKED_BY_CONTRACT`。

## 2026-09-18 G4b厂家软件raw包捕获候选已备（仅离线）

对冻结厂家库反汇编与动态符号交叉核对，`gen_dma_pkg_from_entry_list`接收entry列表、真实`std::vector<uint32_t>&`及模式；V3实测三entry在局部编码规则下**预测**20字/80字节，仍未取得厂家raw输出。新增隔离C++探针、离线JSON逐字对照器、README及SHA清单；清单3/3通过，检查器正反自测与既有解析器自测通过，AArch64 bare-metal仅结构/向量大小静态语法检查通过。状态`CODED_ONLY/NOT_TARGET_LINUX_BUILT/NOT_USB_STAGED/NOT_RUN`；板卡按用户确认物理断电，U盘仍在板卡。下一步需要用户转移U盘至电脑，才可新目录暂存；本阶段不放行设备启动。详见`docs/research/SOFTNPU_G4B_PACKET_CAPTURE_PREP_20260918.md`。

## 2026-09-18 SoftNPU 厂家合成Pool软件entry首次实际捕获

原TF Linux上V3四文件经只读U盘及板端私有目录两次清单3/3核验。旧目标头文件缺`SYS_close_range`使首编译按门禁失败；核对运行内核`__arm64_sys_close_range`和Linux v6.1 AArch64通用编号436后，仅在板端私有构建加`-DSYS_close_range=436`，严格告警编译通过。非root负门禁退出2；root `--gate-only`输出指定标记、退出0且未加载厂家库。隔离条件复核后，一次限时厂家库**软件entry**调用退出0，捕获286字节JSON（SHA-256=`a43cf687544607e1a085441202a2ede1db9155d8df288d0c65b5b3265fb82e85`）：3组为`0x181c/1字`、`0x1834/12字`、`0x1814/1字`，与此前条件化分组推断相符。精确原始字节保存在`tools/npu/evidence/g4b_v3_vendor_synthetic_pool_entries_20260918.json`。这是**reset镜像仅开Pool bit、mode1的厂家软件输出**，不是固定ONNX模型、raw packet或NPU设备执行；G4b主动设备计算仍`BLOCKED_BY_CONTRACT`。U盘卸载，模块仍为空、dmesg过滤无异常，Linux软件关机到`Power down`，串口关闭；用户随后确认已关闭板卡物理电源。详见`docs/research/SOFTNPU_G4B_V3_VENDOR_ENTRY_CAPTURE_20260918.md`。

## 2026-09-17 SoftNPU V3包已暂存U盘（尚未板端运行）

用户确认U盘已插电脑后，核对`G:`上既有DR1实验目录及V2包，新建`G:/DR1_SOFTNPU_G4B_ENTRY_CAPTURE_V3_20260917_1/`，写入V3源码、说明、SHA清单和冻结厂家库。电脑Temp源与U盘回读四文件SHA-256逐一一致，清单所列三文件3/3匹配。状态仅为`USB_STAGED_ONLY/BOARD_NOT_LINUX_BUILT/BOARD_NOT_RUN`；未执行`--gate-only`、厂家`dlopen`、NPU设备启动或DMA。Linux软件关机先前已确认；物理断电没有由工具独立确认。下一步需用户安全弹出U盘，确认板卡物理断电后插回，再由用户确认才上电。G4b主动设备计算仍`BLOCKED_BY_CONTRACT`。

## 2026-09-17 SoftNPU V3离线隔离门禁待板端验证

本机只读盘点未发现可用WSL发行版、QEMU/容器/VM运行环境；当前G400候选与用户D20.3示例的TOP/AXI_READ/AXI_WRITE寄存器元数据相同，虽有复位、`AXI_master_transfer_limit`和中断状态，但没有可审计的忙时AXI排空/缓冲释放语义。V3探针新增关闭stdin/继承FD、stdout/stderr普通文件要求及`--gate-only`：后者在加载任何厂家库之前验证私有空`/dev`/`/sys`/`/proc`、降权和受保护路径不存在，然后退出。源码/说明/清单已备且3/3源哈希匹配，**未编译目标Linux、未写U盘**。用户报告板卡上电且U盘在板卡后，COM4一次回车确认Linux root提示符；只读检查发现`/dev/sda1`未挂载、NPU/CMA模块未加载，随后`sync; poweroff`到达`reboot: Power down`，串口已关闭。板卡物理供电是否关闭仍待用户确认；下一步由用户物理断电后转移U盘至电脑。见`docs/research/SOFTNPU_G4B_V3_ISOLATION_AND_AXIRECOVERY_20260917.md`；G4b主动设备计算仍`BLOCKED_BY_CONTRACT`。

## 2026-09-17 厂家Pool entry 软件ABI静态核验

对冻结`libarmnn.so.32.1`独立反汇编：entry列表头16字节（count@0、指针@8），entry24字节（类型@0、首偏移@4、数据字数@8、数据指针@16），与候选探针布局相符；厂家Pool镜像分配672字节，reset末端与之吻合。AArch64结构布局语法检查退出码0。合成Pool/mode1条件下，第三`param_t&`的已见读取分支被activation标志过滤；不推广到模型路径。V3源码加入布局断言和继承文件句柄关闭门禁，但仍`CODED_ONLY/NOT_LINUX_BUILT/NOT_RUN`，未审完库加载副作用，不允许移至当前板运行。见`docs/research/SOFTNPU_G4B_ENTRY_ABI_STATIC_AUDIT_20260917.md`；真实ONNX包、DMA和恢复仍`UNKNOWN`，G4b仍`BLOCKED_BY_CONTRACT`。

## 2026-09-17 SoftNPU 两个官方未答问题的本地推断

冻结驱动的中断等待超时只返回`-ETIME`，无主AXI停止/排空或缓冲释放流程；IPUG166给上电复位顺序但未给忙时恢复契约。因此超时必须先隔离作业、保留可能仍被设备引用的三缓冲并禁止重提，不能把软件超时或寄存器名当作设备已停。厂家库可静态推导固定Pool的条件化三entry/80字节结构，但这不是经ONNX/Alnpu生成的真实包；默认演示允许CPU回退，板端隔离`dlopen`尚未通过。新V3隔离源码只为`CODED_ONLY/NOT_RUN`，不批准当前板上加载。详细证据与推断见`docs/research/SOFTNPU_G4B_TWO_QUESTIONS_INFERENCE_20260917.md`。NPU-001仍`DOING`，主动G4b仍`BLOCKED_BY_CONTRACT`。

## 2026-09-17 D21.1 镜像单 Pool 证据盘点

只读内存解包 D21.1 rootfs，CPIO 有892个非 trailer 条目；`npu_demo/` 含9个演示程序、9个脚本及固定模型/输入，但未发现**独立文件形式**的单 Pool 真包或黄金输出。`run_gesture.sh` 用单张固定图，配置列8个静态手势类别，且未限定 Alnpu-only 执行；它不能证明连续手语或排除 CPU 回退。此盘点不排除程序内嵌/运行时生成数据。G4b仍 `BLOCKED_BY_CONTRACT`；详见 `docs/research/SOFTNPU_D21_1_ROOTFS_CONTENT_AUDIT_20260917.md`。

## 2026-09-17 Soft NPU 复位来源漂移（P0）

当前 G400 80MHz 候选的 `Design.xml` 将 NPU 主口复位接 PS GPIO 控制的 `_200` 网、配置口接普通共享网；同目录被历史综合日志引用的生成 HDL 却将**两端都接普通共享网**。新增只读检查器在该候选报 `MISMATCH`，原工程及下载的 D20.1/D20.3 示例各自报 `MATCH`。因此未来直接 Generate 可能改变候选复位拓扑；不得混合 XML、HDL 和旧 bit 证据，也不能称 `_200` 网是 NPU-only（它还接 FDMA/UI）。历史 bit 逐源绑定、真实板上边沿及超时安全停机仍 `UNKNOWN`，G4b设备计算继续 `BLOCKED_BY_CONTRACT`。见 `docs/research/SOFTNPU_RESET_METADATA_HDL_DRIFT_20260917.md`。

## 2026-09-17 D20.1 两份示例的 Pool 静态复核

用户新增的 TD 工程及 SD 镜像只构成 G484 的**配置配套线索**，不是已绑定的 BOOT/bit，也不适用于当前 G400。两库可装载机器码相同后，重新核对 Pool 数据类型与包头：固定 UINT8 输入的候选 `0x181c` 软件镜像字为0；类型0 entry 的局部头编码规则已知，三entry/80字节仍只是**条件化预测**，真实厂家包未捕获。设备DMA、完成IRQ及异常停机/缓冲释放仍 `UNKNOWN`，G4b设备计算 `BLOCKED_BY_CONTRACT`，本次无板端操作。见 `docs/research/SOFTNPU_D20_1_DEMO_POOL_REUSE_20260917.md`。

## 2026-09-17 D20.1 Arm NN 库差异已收窄

镜像内与冻结SDK中的`libarmnn.so.32.1`整体SHA不同，但从rootfs只读解码到电脑Temp并独立比较后，两个精确版本的**25个ELF可装载分节全部字节相同**，包括`.text`、`.rodata`、`.init_array`和动态链接数据；GNU Build ID也相同。差异在非装载元数据。因此既有Pool打包和构造函数的**静态**逆向可用于该镜像库，不必因整体SHA不同重做一次；但真实Pool packet、设备DMA、完成IRQ和故障恢复仍`UNKNOWN`，G4b设备计算`BLOCKED_BY_CONTRACT`。见`docs/research/SOFTNPU_VENDOR_RUNTIME_ALLOCATED_SECTION_EQUIVALENCE_20260917.md`。

## 2026-09-17 D20.1 2025.7 TD 与 SD 镜像补证

用户新放入的 D20.1 TD ZIP 与 D21.1 SD 镜像已只读解析：TD 为 G484/TD 6.2.175876，SoftNPU `0x80000000`/SPI82、YOLOV8；镜像 DTB 的 SoftNPU 地址、窗口及中断与 HPF 一致，内核/rootfs uImage 长度和 CRC 通过。rootfs 中有程序、静态手势模型及 `libarmnn.so.32.1`。虽然该库完整SHA与冻结公开库**不同**，后续25个可装载分节的独立比较证明其字节相同，故静态Pool/构造函数分析可转用；不能推导运行行为已通过。BOOT 内 bit 与 TD/HPF bit 尚未建立字节绑定，官方板测也未核；G484 镜像不能直接用于当前 G400 板。见`docs/research/SOFTNPU_D20_1_2025_7_SD_IMAGE_AUDIT_20260917.md`。G4b仍`BLOCKED_BY_CONTRACT`，暂不需新增下载或接线。

## 2026-09-17 本地 D20.3 示例补证

用户下载的 `demo/dr1_demo_prjs-2026.1/` 已只读核对：D20.3 TD/HPF为 G484、TD 6.2.190657、HPF 202601，NPU主机窗口 `0xA0000000`/SPI83、master 接HP1，Pool开启且YOLOV8配置；与当前G400候选的 `0x80000000`/SPI85、YOLOV5配置不同，示例bit/DTB不能直接上现板。两份IP-XACT的148项寄存器名称、命令基址、偏移及访问属性逐项相同，但不证明位值、实际译码或命令包兼容。D20.1/D20.2/D20.3厂家生成HDL均将NPU两路外部复位接同一信号，故此前“共享复位与手册文字冲突”收窄为**待官方解释的手册/示例差异**，不再断言共享线必然冷启动失败；运行期超时停机、主AXI排空和缓冲释放仍`UNKNOWN`。本地示例没有单Pool真包或板测证据，G4b仍`BLOCKED_BY_CONTRACT`。两项精确问题已拟好，但官方问答站页面读取超时、**尚未提交**；见`docs/research/SOFTNPU_D20_2026_1_LOCAL_DEMO_AUDIT_20260917.md`。

## 2026-09-17 最新离线进展（G4b）

新增只读真实包对照工具`tools/npu/g4b_pool_packet_compare.py`：已有包可逐项对照固定Pool的条件化三entry/80字节推断；合成正例与五种变异在隔离Temp副本自测通过，解析器仍将`NN_start`标为副作用。当前**没有厂家真实包**，比较器“匹配”也不等于硬件有效、DMA安全或Pool通过。详见`docs/research/SOFTNPU_G4B_CORE_IMPLEMENTATION_20260917.md`，G4b仍`BLOCKED_BY_CONTRACT`。

继续对冻结`libarmnn.so.32.1`只读反汇编：固定Pool调用点确实向`get_soft_driver_data_packet`传模式1、两个空指针，随后向打包函数传内部命令基址选择1；该路径跳过YOLO/CSC/Resize大块。它缩小了候选entry来源范围，但**仍未运行厂家函数或得到真包**。本机无现成AArch64模拟器/WSL发行版/运行中VM，板上不得放宽设备隔离。见`docs/research/SOFTNPU_G4B_CORE_IMPLEMENTATION_20260917.md`，G4b继续`BLOCKED_BY_CONTRACT`。

本机冻结公开 SDK 中找回**旧版** D20.3 `2025.1` HPF（非用户链接的`2026.1`文件）：其 `hpf.info` 指定 `DR1M90GEG484`，自带 DTS 将 Soft NPU 设在 `0x1F0000000/64KiB`、SPI97；同批通用 Linux DTS 却为同址1MiB。当前80/40MHz隔离候选为 `DR1M90GEG400`、`0x80000000/16KiB`、SPI85。故“公开参考窗口均为1MiB”须收窄为“通用DTS为1MiB”，旧HPF不能直接用于当前板。详见 `docs/research/SOFTNPU_D20_3_HPF_VERSION_COMPARISON_20260917.md`。该补查不提供真实Pool包或安全恢复，G4b仍`BLOCKED_BY_CONTRACT`。

用户新增 `数据手册资料/新建 文本文档.txt` 摘录安路 NPU Wiki、IPUG166 和接口说明。官方 `dr1_demo_prjs` 的 `2026.1` 分支目录已核对确有 D20.1/D20.2/D20.3 示例；D20.3 子文件、Wiki正文和 release README 本次未取到，故其复位/设备树/软件配套尚未验明。文本未提供真实单 Pool packet 或超时安全停机契约；YOLOv5s 27.3 FPS 数字缺可核验条件，不转用为现板指标。NPU-001 仍 `DOING`，G4b 设备计算仍 `BLOCKED_BY_CONTRACT`。见 `docs/research/NPU_USER_MATERIAL_REVIEW_20260917.md`。

同日继续只读核验：条件化三entry镜像若完全准确，厂家打包函数的逐项编码应为14数据字加6头字，即**推断20字/80字节**；离线工具只输出形状，不生成可执行包，真实包仍未捕获。候选IP-XACT另列`CLP_reset/AXI_rd_reset/AXI_we_reset/NN_reset`四个内部复位寄存器，但没有忙时AXI停机、事务排空或缓冲释放语义，不能据名称解除G4b启动门槛。隔离Temp副本自测通过；未访问板卡或运行NPU。详见`docs/research/SOFTNPU_G4B_CORE_IMPLEMENTATION_20260917.md`和`SOFTNPU_G4B_RESET_CONTRACT_20260917.md`。

进一步定位厂家库加载期异常：`.init_array`中的Alnpu静态登记路径会先对`/dev/hard_npu`做文件状态检查，非“文件不存在”类错误可抛出与板端一致的`filesystem_error`。该直接静态链不经过已知的`hard_npu_driver_init`调用点，因此**不能**由板端权限错误宣称驱动init或设备映射已经执行；其它构造函数副作用仍`UNKNOWN`。见`docs/research/SOFTNPU_G4B_DLOPEN_CONSTRUCTOR_20260917.md`。板端隔离抓包路线依旧停止，需真正无真实设备的独立运行环境。

8位MaxPool CPU参考与自测源码已完成；Windows/AArch64编译检查及AArch64静态分析通过，固定量化样例与既有ONNX CPU黄金字节一致，但Windows应用控制策略阻止执行新编译测试程序，故C运行测试为`NOT_RUN`。冻结公开库只读反汇编给出固定样例的六个**软件镜像候选字**，并条件化推断三个entry分组；它们不是真实packet或硬件实测。离线packet解析器副作用标记的合成自测通过。详见`docs/research/SOFTNPU_G4B_CORE_IMPLEMENTATION_20260917.md`。NPU-001维持`DOING`，主动G4b设备计算继续`BLOCKED_BY_CONTRACT`。用户此前告知板卡保持数据线连接和上电；本轮仅电脑端静态/离线工作，**不访问板卡、串口/JTAG或U盘，不下发命令**。板端运行状态未经本轮读取，为`UNKNOWN`。

同日CPU-only传输包已在电脑系统Temp独立新目录完成四文件复制和源端/副本SHA核对，清单3/3通过；**只到`PC_STAGED_ONLY`，尚未写U盘或上板**。用户确认在板卡旁且板卡上电；COM4登录确认当前运行Ubuntu 20.04.1/Linux 6.1.111-rt42，`lsblk`显示U盘为`sda/sda1`且无挂载点，`findmnt -S /dev/sda1`返回未挂载、`/proc/mounts`无`/dev/sda`条目。尚未移动U盘、构建或运行测试。该CPU-only测试即使将来通过，也不改变Soft NPU设备计算的`BLOCKED_BY_CONTRACT`。

随后用户将U盘插回电脑；识别为包含既有DR1实验目录的`G:`。四文件写入此前不存在的`G:/DR1_G4B_POOL_CPU_ONLY_20260917_1/`，源端/回读4/4哈希一致，U盘清单3/3通过。状态提升仅为`USB_STAGED_ONLY/BOARD_NOT_RUN`；尚未安全弹出、插回板卡或在板上编译运行。

最新板端限定结果：U盘回到板卡后以`ro,nosuid,nodev,noexec`挂载，载荷清单3/3通过；复制到新私有目录`/root/g4b_pool_cpu_only_20260917_1`再次3/3通过，随后卸载U盘。目标Ubuntu 20.04.1/Linux `6.1.111-rt42`、GCC 9.3.0以C11 `-O2 -Wall -Wextra -Werror -pedantic`编译退出码0；AArch64 Linux测试ELF SHA-256=`dd110fe251f7cbedeedcb367521fecf990ba4a4a20d0c912eb0b05f3dbbdcdc9`。一次`timeout 10s`运行输出精确`G4B_POOL_CPU_REFERENCE_PASS`、退出码0。状态仅`CPU_REFERENCE_BOARD_PASS_LIMITED`，不表示Soft NPU设备、DMA、IRQ、packet或模型执行；主动G4b继续`BLOCKED_BY_CONTRACT`。详见`docs/records/worklog/2026-09/2026-09-17-softnpu-zzzz-cpu-board.md`。

同日复核IPUG166和当前80/40MHz隔离候选生成HDL：NPU配置/系统时钟同接P2F_CLK0，但两侧复位同接共享`Processor_System_Reset_0.peripheral_aresetn`，并波及AXI Matrix、ERAM Controller、temporal_conv等。手册要求配置侧先于系统侧、各至少十周期；同网连线不能独立表达该先后关系，也不是NPU-only超时恢复。判定`PARTIAL/STATIC_CONTRACT_CONFLICT`，不会反推此前有限只读板测失败；设备启动门槛维持。详见`docs/research/SOFTNPU_G4B_RESET_CONTRACT_20260917.md`。

同日离线软件镜像工具已从六个固定寄存器字扩为**条件化**三entry/14数据字对照JSON，独立Temp副本哈希一致、脚本自测通过；它不输出raw packet，真实厂家entry仍未取得。难题已具体化为`docs/research/SOFTNPU_ASTRA_ASSIST_REQUEST_20260917.md`供并行审查：安全离线抓包与NPU-only复位/AXI停机。原工程没有运行SoC构建或设备测试。

网口传输候选：用户指出的外部`02_demo111/06_eth_udp_loop`是PL RGMII/UDP回环，固定`192.168.137.2:6002`到`192.168.137.1:6001`，不是当前Linux文件服务，也不能替换NPU候选bit来传文件。当前板载Linux的`eth0` carrier=1、1Gbps、地址`192.168.137.100/24`及`169.254.125.44/16`，`sshd`监听；电脑当前仅WLAN `10.15.77.56/16`，无已连接有线网卡，至`192.168.137.100`的一次ping超时。网口文件传输具备软件条件，但电脑—板卡可达性为`NOT_VERIFIED`；尚未改网络配置或进行SSH/SCP传输。

状态日期：2026-09-17。交接基线日期：2026-09-08。工程：`F:/My_proj/fdma_imx415_20251008`。Git：当前 branch 为 `codex/v4r-rtl`，当前 HEAD 为 `2685d5f4e21bb91b31a52dbde8527c59acd0964c`，工作树已有用户/既有未提交修改与未跟踪资产；V4R 实现历史提交为 `db9d30f6be3298c13fd0992331c69ed76d238396`，开发起点 `96af51bbe8d3ac5c65d6805cfb0fff2fc4a667fa`；V2 源码/验证提交 `7397b2cd9e2465edac37f2b4afcc4f0c6a161ced`，annotated tag `v2-board-20260907` 指向后者。作者身份仅在本仓库配置，全局配置未改。私有远端 `origin` 为 `https://github.com/aku666/fdma-imx415-dr1m90g.git`；按用户要求本任务不推送。

## 产品目标

项目目标明确为孤立动态中国手语词识别：IMX415采集完整动作的约16–32个采样帧，输出一个中文词语；不是静态姿态分类或连续句子翻译。DR1M90G处理链为：IMX415 采集视频，经空间特征提取和 TCN/V4R 时序建模后，由 PS 完成分类/解码、拒识和中文文本组织，最终叠加到目标屏幕。完整路线见 `docs/ROADMAP.md`。当前主工程 `soc_prj/` 仍是 MIPI CSI-2 摄像头输入和 HDMI TX 输出；新增参考工程 `demo/11_csi_dsi_imx415_7cun/` 则包含 IMX415→ISP→FDMA/DDR→1024×600 四通道 MIPI-DSI 的完整候选链，且用户确认已在7寸屏正常显示。该 demo 尚未与主工程、NPU、V4R或文字OSD集成，准确面板型号和已验证 BOOT/bit/ELF 组合仍需冻结，因此项目尚未达到端到端手语系统完成态。

## 当前 Known-Good

当前最可靠基线是 **V2-BOARD-20260907 的有限板测组合**，不是完整视觉系统验收：

| 项目 | 当前基线 |
|---|---|
| PL 版本 | V2 DUC2，基址 `0x90000000`，ID `0x44554332`，version `0x00020000` |
| bit | `implementation_v2/soc_v2/soc_v2.bit`，SHA-256 `f7a3de056633cd386602ab4617dc3ce9efe64acfc800095b9cf18f60549b3b33` |
| ELF | `soc_sdk/duration_v2/build/duration_v2.elf`，SHA-256 `2e1fa477a6bfac30e559f92d06d844e073532fd933e5e94054657458664f01a9` |
| 实际板测频率 | P2F_CLK0=100MHz，P2F_CLK1=50MHz；保存实读分频 `0x07070703` |
| 默认工程频率 | IP SDC 为 IO PLL 400MHz 的 /2、/3，约 200/133.32MHz；不是 known-good 板测频率 |
| 固件输入 | 32×4 INT8 合成样本、8×4 INT8 权重，产生 25 个 INT64 窗口结果和误差证书 |

指定 bit/ELF 的当前文件哈希与 `readback_verification.json` 记录一致；下载日志指向该 bit，GDB 脚本指向该 ELF。`BOARD_PASS` 只覆盖 `main.c` 的 3 类合成输入×3 模式及 1 个零预算回退用例，共 10 组；`REGRESSION_PASS` 只覆盖保存的 100 次 GDB 调用（2500 个窗口、0 failures）和复位后的 dense/lossless/budget-replay 三类结果。它不等于满带宽、长稳、真数据或端到端通过。

V4R-1 另有一个独立、限定范围的板测通过组合：manifest 指定 `soc_v4r.bit`（SHA-256 `560e540b...b7074cf`）和 `duration_v4r.elf`（SHA-256 `d1774821...12f8c7`），P2F_CLK0/1 为 100/50MHz，ABI ID/version 为 `0x56345231/0x00010000`。2026-09-10 完成 ELF 261 段/120474 字节 DDR 回读、8 个合成用例首轮和复位重跑，状态 `0x600d`、count 8；只能写 `V4R-1 BOARD_PASS（8 个指定合成用例）`，不取代 V2 known-good，也不代表完整系统。

## 版本状态

| 子系统/版本 | 状态 | 已确认边界 |
|---|---|---|
| V2 DUC2 RTL/AXI | VERIFYING | 代码、限定 RTL/AXI 仿真、独立综合、指定 SoC P&R/bit 和有限板测有证据；泛化、全 CDC/PVT、真数据未知 |
| 视频/FDMA | VERIFYING | 顶层及互连代码存在；`ENABLE_READBACK=0`、ISP 后处理 bypass；真实帧完整性和 V2 串接 `UNKNOWN` |
| IMX415/DSI demo | VERIFYING | demo 有效综合顶层含4-lane CSI、RAW10、ISP、DDR三帧缓存读写、1024×600 DSI配置及4-lane D-PHY TX；保存 bit 和正时序报告，用户确认7寸屏显示正常；产物绑定、长稳及主工程移植仍未验收 |
| PS V2 固件 | VERIFYING | 裸机 MMIO、CPU 参考、轮询和指定 ELF 板测有证据；无 DDR DMA，Cache 全契约 `UNKNOWN` |
| 普通 TCON | VERIFYING | 与 DUC2 同基址但 ID/version、寄存器和输出语义不同；指定仿真有证据，新板测 `UNKNOWN` |
| NPU | DOING | 用户已于2026-09-14授权Soft NPU适配实验。公开转换/量化、Arm NN与Linux hard/soft NPU/CMA资产已冻结；复位对齐80/40MHz候选重复通过最小只读门禁。G2为受限控制面板测，G3为64KiB CPU coherent分配/mmap限定通过，明确`device_dma=NOT_RUN`。2026-09-16 G4a唯一一次250ms空闲IRQ窗口前后状态0、事件0、IRQ计数0、卸载恢复，判定`IRQ_IDLE_WINDOW_PASS_LIMITED`。设备完成IRQ、NPU master/DMA、Soft/Hard算子、Arm NN Alnpu、CPU回退排除、自定义模型与历史SLVERR根因仍`UNKNOWN`；原驱动禁止直接加载 |
| V4 | RESEARCH | 设计稿与数学模型存在；RTL、ABI、综合、bit、固件和板测均 `UNKNOWN` |
| V4R-1 | VERIFYING | 固定块 RTL、独立 ABI、core/AXI 仿真、SoC 综合/P&R、100/50MHz 最终时序、指定 bit/ELF 及 8 个合成用例限定板测通过；DMA/Cache、视频/NPU、真实模型、长稳和满带宽仍为 `UNKNOWN` |
| PC手语模型 | VERIFYING | CSL-Clinic三类弱标签最佳模型在12段测试上Top-1/Macro-F1=`0.7500`；固定视频PyTorch/拆分ONNX逐段分类一致；公开数据连续回放已完成逐帧空间特征缓存、16帧TCN滑窗、稳定投票、事件和字幕视频输出；动作边界由测试夹具提供，自动切分、真实signer隔离、拒识、INT8/NPU、DR1性能和V4R映射仍为 `UNKNOWN` |

## 专利材料状态

V4R 板测后技术交底与 12 项权利要求讨论稿已形成，`MODEL-002` 进入 `VERIFYING`。当前可支撑的主线是 FPGA 本地“不可变分块摘要—窗口区间—精确块贡献替换—预算冻结”闭环：非零块细化在 RTL 仿真中有覆盖，但现有 8 个板测用例均为 `residual_products=0`，不能写成板上已覆盖非零残差结算。完整现有技术检索、权属/公开时间线、代理判断和性能型创造性证据仍为 `UNKNOWN`。

## 当前 P0

- 17 项 V2 清单于 2026-09-09 在当前工程中复算并全部匹配；外部快照/压缩备份不在本次 Git 建基线范围内，未读取、未哈希、未作为失败条件。
- `prepare_sdk.py` 会覆盖当前 `main.c` 及应用元数据/lds；`build_sdk.py` 会写构建输出和日志；bitgen 会覆盖 `soc_v2.bit`。
- 普通 TCON 与 DUC2 同基址但 ABI 不同；默认约 200/133.32MHz 与板测 100/50MHz 不同。
- Git 版本控制、工作流、guard、hook、两次初始提交、V2 tag 和精确 LFS 跟踪已完成；干净隔离环境可重建流程仍未证明。
- 远端已接收初始 `main` commit `b25cb5bb07ce0f070d6aec45cfaa62c67cd6078d`、annotated tag 和3个 LFS对象；随后独立 clone 因到 GitHub 443 连接连续失败而未完成。另因 `COM4.log` 为 Windows manifest-only 文件，即使网络恢复，Git-only clone 的17/17验收仍需单独解决。因此 SYS-005 为 `BLOCKED`，不能写远端恢复已验证。
- V4R-1 已在 `F:/My_proj/_isolated_builds/` 完成隔离实现和限定板测：100 个 core 用例及 AXI 仿真、完整 SoC P&R、100/50MHz setup/hold 正裕量、bit/ELF、DDR 回读和两轮 8 用例结果均有证据。实读分频 `0x07070703`，ID/version/capabilities 为 `0x56345231/0x00010000/0x01040820`。
- V4R-1 当前仅是 MMIO 装载的小规模固定块加速器。DDR DMA/Cache 所有权、视频/FDMA/NPU 串接、多输出通道、真实模型、长稳和满带宽均未完成；不得把 `BIT=GENERATED` 写成完整异构系统完成。
- V4R 最终时序使用一个唯一匹配的外部复位同步器入口例外。继承的 V2 例外仍写死 `reg[0]`，而当前 V4R 物理数据库的真实入口为 `reg[1]`；V4R 已独立修正，V2 历史约束未改且应另行审计。
- 当前主工程 `soc_prj/uisrc/01_rtl/system_top.v` 的摄像头输入链为 MIPI D-PHY/CSI/RAW10/ISP/FDMA，但 `ENABLE_READBACK=0`、`ISP_BYPASS_POSTPROC=1`，其输出仍为 HDMI；主工程的 DDR 读回显示和模型预处理均未闭环。
- `demo/11_csi_dsi_imx415_7cun/` 已提供另一条独立参考链。其有效综合源是 `soc_prj/uisrc/01_rtl/system.v`，不是同目录未参与该次 P&R 的 HDMI 版 `system_top.v`；有效源含 4-lane IMX415 CSI、FDMA写读、1024×600 DSI视频包、显示初始化和4-lane D-PHY TX，P&R 报告为 setup `+7.748ns`、hold `+0.039ns`，用户确认板上正常显示。
- demo 根目录 `BOOT.bin` 与保存的 2025-09-29 bit、2025-06-19 ELF 时间线不同，目录内另一个旧 `BOOT.bin` 也非同哈希；当前缺少把用户所见显示结果绑定到唯一 BOOT/bit/ELF 的 manifest 和日志。故可写“已有用户确认的可迁移视频/DSI demo”，不能写“当前主工程显示已完成”。
- 当前已有公开真实视频的三类弱标签训练候选和类别表，但不是已确认的产品数据/模型：数据卡许可证未声明、真实表演者身份未知、目标动作窗口为推定且测试样本仅12段。仓库仍无NPU runtime/转换结果或Linux系统集成资产；不得继续按旧专利计划假定这些已完成。
- PC模型GPU环境已在 `F:/My_proj/_isolated_builds/fdma_imx415_model_20260912/.venv` 配置并验证：Python 3.12.14、PyTorch 2.9.1+cu128、CUDA可用、设备为RTX 4070 Laptop；`SignTCN-MVP-v0` 的四项合成检查通过。该结果仅为随机权重前向冒烟，不是模型训练、准确率、ONNX/NPU或板端通过。
- 训练部署流水线已在隔离目录 `pipeline_selftest_20260912_6` 跑通：短视频提帧及源哈希、跨split重复视频拒绝、数据审计、CUDA训练、独立测试、固定时长ONNX和黄金向量全部贯通；微型合成数据Top-1/Macro-F1=1.0，空间/时序ONNX相对PyTorch最大误差约`1.79e-7/4.47e-8`。该结果不包含真实手语、医疗词表、INT8、NPU、V4R或板测。
- CSL-Clinic公开数据实验已在独立目录完成三轮训练。v0四类test Top-1=`0.4286`、Macro-F1=`0.3958`；v1冻结MobileNetV2的三类结果为`0.6667/0.6627`；v2低学习率全量微调后，咳嗽/过敏/发烧三类test Top-1/Macro-F1均为`0.7500`。v2空间/TCN ONNX相对PyTorch最大绝对误差约`8.82e-6/4.17e-7`并生成PC浮点黄金向量；产品验收、INT8、NPU、V4R和板测均未通过或未执行。

## 下一步三件事

1. **PROD-001 + MODEL-001**：三类演示词已暂定为咳嗽/过敏/发烧；下一步确认目标中国手语标准/地区和数据授权，采集至少4位不同手语者的IMX415孤立动作与非目标负样本，按人隔离重训并闭合拒识指标。
2. **VID-001 + DISP-001**：先固化 `demo/11_csi_dsi_imx415_7cun/` 的屏幕型号、连接、BOOT/bit/ELF和源码 manifest，再在新隔离副本把已验证 IMX415→ISP→DDR→1024×600 DSI 链迁入产品系统；不得在原工程或 demo 原目录直接生成、构建或覆盖。
3. **NPU-001 + IF-001**：诊断v2控制面、G3固定64KiB coherent缓冲和G4a 250ms空闲IRQ窗口均已分别完成受限板测。G4a状态仅为`IRQ_IDLE_WINDOW_PASS_LIMITED`，不证明设备完成中断或设备DMA。下一步先静态冻结G4b最小Soft算子的packet、DMA地址、黄金输出、缓存所有权及超时/停止/复位恢复；未闭合前不写`0x0804/0x1004`或运行Arm NN。

## 2026-09-13 NPU公开栈调查更新

详见 `docs/research/NPU_PUBLIC_STACK_INVESTIGATION_20260913.md`。公开SDK并非只有预转换模型：已有AL_onnx_pass、静态校准量化、Arm NN加载调用链。默认固定图示例是YOLOv8n，另有416×416、8类静态手势的YOLOv5风格QDQ模型。模型输入输出为float32，不能当作INT8应用接口。默认允许CPU回退。

参考Soft NPU设备树为0x1F0000000、SPI97，与当前BSP 0x80000000/IRQ117不同；不得复制写寄存器。当前主工程历史驱动目录仍缺失，但公开资产已冻结于 `F:/My_proj/_isolated_builds/npu_public_audit_20260913/`；这不表示已集成。推荐先测现有MobileNetV2＋CPU TCN固定视频，另按闸门验证NPU；IF-001可由CPU路径冻结，不再必须等待NPU。所有推荐实施任务保持OPEN/BLOCKED，未执行板写、转换或构建。

## 2026-09-13 固定视频CPU基准更新

在新隔离目录 `F:/My_proj/_isolated_builds/fdma_imx415_cpu_video_20260913_1/` 对冻结checkpoint及12段测试视频完成PyTorch CPU和拆分ONNX Runtime CPU基准。两条路径均复现Top-1/Macro-F1=`0.7500`，三段误分类；ONNX相对PyTorch的全测试最大空间特征绝对误差约`5.29e-4`、logits约`5.16e-5`，逐段分类完全一致。PyTorch 20线程PC CPU中位耗时：PNG解码/预处理`68.93ms`、16帧空间编码`105.65ms`、TCN`0.54ms`、估算流水线`174.92ms`。这些数据只说明固定弱标签视频的PC CPU基线；不是DR1、Linux、INT8、Arm NN、NPU、V4R、实时摄像头或产品精度结果。空间网络占模型时间绝大部分，当前仅卸载TCN不能据此宣称显著端到端加速。

## 2026-09-13 公开数据连续回放更新

在隔离目录 `F:/My_proj/_isolated_builds/fdma_imx415_stream_replay_20260913_1/` 将12段测试片段按三类轮换排列，并在片段间加入测试夹具提供的8帧黑场边界，按8fps回放为47秒、376帧连续输入。拆分ONNX Runtime CPU链以每帧一次MobileNetV2空间推理缓存128维特征，每4帧运行一次16帧TCN窗口，连续两票后发出事件；成功输出12个事件、逐帧时间线和带中文字幕视频，其中10个事件与当前片段弱标签一致。该结果仅验收软件数据流和状态传递；边界是显式提供的，阈值为演示值且无unknown/idle训练类别，不能写成自动动作切分、实时摄像头、产品准确率、Linux、NPU、V4R或DR1板测通过。

## 2026-09-14 DR1 Linux入口核验

用户本地资料 `F:/BaiduNetdiskDownload/DR1M90G/02_F3P_DR1M90GEG400_FPGA/03_demo/3-4_ex_soc_linux/` 存在Linux基础、驱动示例和两份电子书。基础包Chapter 3已含`BOOT.bin`、`boot.scr`、`system.dtb`、`uImage.lz4`和`uInitrd.lz4`，教程指向TF卡启动、拨码`ON-OFF-OFF`及PSUART `115200 8N1`。板卡接通后Windows枚举COM3至COM6；原始回车响应独立确认COM4为PS UART，登录提示为`bionic-arm64`，`root/root`实测登录成功。真实系统为DR1M90 FPSoC、AArch64双核、Ubuntu 20.04.1、Linux 6.1.111-rt42、glibc 2.31、Python 3.8.2、约989MB内存和29GB TF根分区；GCC/G++及SSH服务存在。NumPy、Pillow、OpenCV、ONNX Runtime、pip/ensurepip、Arm NN均未发现；`/dev/fb0`存在，`/dev/video*`和`/dev/dri*`不存在。eth0静态地址为`192.168.137.100/24`但无物理链路。

已在 `F:/My_proj/_isolated_builds/fdma_imx415_dr1_cpu_probe_20260914_1/package_output_v2/` 生成38,476,083字节AArch64离线CPU探测ZIP，SHA-256为`953c8f71c4751b97653e693857c1f6e2954d9b5889d2f3d96bae9ba89962bb24`。复制前发现并修正了板端Python 3.8.2不具备`Path.is_relative_to()`的兼容问题；修正版通过Python 3.8语法检查、ZIP完整性检查、2997项文件清单复算和24个AArch64 ELF machine 183检查。

2026-09-14 已经COM4在真实DR1 Linux完成固定张量执行，状态 `PASS_DR1_LINUX_CPU_FIXED_ONNX`。私有包成功导入NumPy 1.24.4和ONNX Runtime 1.16.2，只启用`CPUExecutionProvider`、2线程；16帧空间特征最大绝对误差`1.3116002082824707e-4`（限值`2e-3`），端到端logits误差`1.5497207641601562e-5`、TCN单独误差`9.5367431640625e-7`（限值均`1e-3`），期望/实际类别均为0。空间网络平均`458.49ms/帧`、16帧总计`7335.84ms`，TCN为`10.19–13.32ms`。结果JSON SHA-256为`985e8bff805603a52a96bc2d865e01e9342a808f28a5767f33543ff2daca5bc5`，保存在板端 `/root/dr1_cpu_onnx_probe_20260914/dr1_cpu_onnx_probe/results/dr1_cpu_probe.json`，并回写到U盘`board_results/`后安全卸载。该结论只允许写成**DR1 PS CPU固定预处理张量有限通过**：不是视频解码/预处理、实时摄像头、NPU、V4R、准确率或显示链通过。板端系统时钟仍错误显示2025-11-19，不能用结果文件时间戳作为实际执行日期。

同日启动NPU适配前置核验。当前TF卡为`mmcblk0`，根分区29GiB、BOOT分区99MiB。早先对`/proc/device-tree`使用未跟随符号链接的`find`，所得“无NPU节点”结论已撤回；对运行时明确路径及备份DTB独立复核后，确认存在`/soc/hard_npu@63F00000`，兼容串为`anlogic,hard_npu`，寄存器窗口为`0x63f00000/0x100000`、`0xf8800000/0x200`、`0xf8801000/0x100`，中断cells为`<0 112 4>`。当前仍没有Soft NPU节点，也没有`/dev/cma_mem`、`/dev/hard_npu`、`/dev/soft_npu`或对应已加载模块。因此当前系统提供Hard NPU设备树契约，但尚无驱动或推理通过证据。

BOOT分区只读复算：`BOOT.bin`=`60c2fff3...a1190`、`boot.scr`=`a414efb6...6656`、`system.dtb`=`e521c728...18b5`、`uImage.lz4`=`07fb0ebf...7892`；61个本地同名候选均无相同哈希。启动四件套、启动参数、I/O内存表和dmesg已通过U盘复制到隔离目录 `F:/My_proj/_isolated_builds/softnpu_takeover_20260914_1/board_current_boot/`，源端与隔离副本9/9哈希匹配；TF BOOT分区始终只读。内核解压后确认为`6.1.111-rt42`、Linaro GCC 7.5构建，镜像没有内嵌配置，板上也没有`/proc/config.gz`或匹配headers；公开`SDK_2025.07-linux6.1`同为6.1.111且含`localversion-rt=-rt42`，时间关系匹配但尚不能写成精确源码身份已证实。公开Kconfig进一步确认Hard NPU负责Conv/GEMM，Soft NPU负责其余算子，两者通过CMA交换数据，故不能把“只加载Soft NPU”当作空间卷积加速方案。

已把官方`SDK_2025.07-linux6.1`源码、Ubuntu 20.04 ARM64私有bison/flex/m4工具和构建脚本写入U盘新目录`DR1_NPU_BUILD_20260914/`，载荷5/5哈希匹配；没有覆盖原U盘备份。随后在板端私有目录完成CMA/Hard NPU/Soft NPU模块编译、ABI门禁和受控加载：`/dev/cma_mem`及`/dev/hard_npu`生成，Soft NPU模块本身可加载但因当前设备树/bit没有Soft NPU实例而不生成设备节点；Arm NN仅完成后端探测，未运行模型。

为闭合Soft NPU硬件侧，在 `F:/My_proj/_isolated_builds/softnpu_hw_v2_20260914_2/soc_v2/` 从原V2源码建立第二个隔离副本。只把NPU控制路径单独切到P2F_CLK0的首个实验因产生新的跨时钟路径而被拒绝，未生成bit。第二个实验将PS GP0/GP1、复位、AXI矩阵/协议转换、NPU控制口与NPU主数据口统一到P2F_CLK0；P&R从一开始按实际P2F_CLK0/1=100/50MHz约束运行。最终板级时序为setup `0.000ns`、hold `+0.020ns`，仅对经脚本强制唯一匹配的外部复位同步器首级入口使用false path。候选bit大小4,052,202字节，SHA-256=`f52383bbe72d6d0d07d9743fb050ac0d79a1be171884a9ecf7af4baf500b9bb7`；仍有厂商NPU内部ERAM由异步复位寄存器驱动的`TMR-5506`告警，因此状态是候选板测件，不是硬件通过。

当前启动DTB的PL节点只有`0x80100000` VDMA、`0x80200000` framebuffer和`0x80201000` dynclk。为避免运行中替换bit时旧驱动访问失效地址，已生成隔离临时DTB：只将这三个节点改为`disabled`，并新增Soft NPU `0x80000000/0x4000`、GIC SPI85、100MHz；与原DTB逐属性比较只存在这些预期差异。此前一次运行中解绑实验暴露板载`vdmafb_remove`缺陷：DMA解绑后再次解绑framebuffer触发内核Oops；因此后续已改为冷启动时由U-Boot临时加载DTB，不再运行中解绑。临时DTB、候选bit、说明和哈希清单已复制到Kingston U盘新目录`DR1_SOFTNPU_TEMP_20260914/`，三项载荷回读哈希匹配；TF启动文件和U盘既有目录未覆盖。

临时启动路线随后已实测：U-Boot从TF只读加载原内核、从U盘加载临时DTB，DTB CRC32=`4ee1ce77`且Soft NPU/禁用视频节点均与预期一致；未执行`saveenv`。因TD直连不兼容当前FTDI D2XX/VCP绑定，改用此前验证过的FD OpenOCD D2XX本地RBB桥后，候选bit两次均通过DR1M90芯片校验并下载到100%。第一次在Linux运行后下载时，当前TF的实际分频为`0x07070201`；读取`0x80000008`无响应并触发自动重启。第二次在U-Boot停止态先将P2F reset保持有效，把分频设置为`0x07070703`，再下载bit、释放reset和启动临时Linux；Linux复读确认分频仍为`0x07070703`，但同一只读事务仍无响应并再次自动重启。两次都没有加载Soft NPU驱动、没有执行驱动probe写操作，重启后FSBL从原TF重新装载原PL分区并回到登录提示。

因此“默认高频”与“Linux运行中热重配”均可能增加风险，但已被排除为唯一根因。离线连接图显示`Video_NPU_0.M_AXI_AResetn`另由PS `pl_gpio_out`控制；V2/V4R历史固件在访问PL前明确对GPIO bank2执行`0→1`，本次临时Linux没有执行该步骤。该复位未释放是当前`INFERRED`候选根因，尚未通过板测确认；不得继续加载公开Soft NPU驱动，因为其probe会立即写`0x804/0x1004`。另发现生成的`system.address.xml`仍写4KiB窗口，而实际AXI Matrix参数为14位即16KiB，必须先把地址源和生成数据库差异闭合。

继续回查`IPUG166_Video_NPU_IP用户手册`和官方AD101V20 Soft NPU demo后，已撤销“优先用PL GPIO bank2释放NPU主口复位”的假设：官方demo的`pl_gpio_out`未连接，NPU配置侧和系统侧均使用同一100MHz源，两个复位也来自同一个`Processor_System_Reset_0`；手册要求两侧同源同频、配置复位先于系统复位且释放后至少等待10个时钟再发AXI事务。新隔离副本`F:/My_proj/_isolated_builds/softnpu_hw_v2_20260914_3/`仅把`Video_NPU_0.M_AXI_AResetn`改接到同一复位模块。100/50MHz实现setup失败，未生成该频率bit；依据参考设计记录的Soft NPU典型80MHz，改为P2F_CLK0/1/2=`80/40/50MHz`，最终setup WNS=`+1.271ns`、hold WNS=`+0.020ns`、覆盖率96.02%，并生成候选bit `soc_v2_softnpu_resetaligned_80mhz.bit`，SHA-256=`edc2816d67c14968953b80d95a666ccee4204b977dd1074cd27e058e47021d07`。厂商`TMR-5506`告警仍存在，板测结果为`UNKNOWN`。

`tools/npu/fdt_patch_softnpu.py`现要求通过可审计参数选择NPU时钟（缺省仍为100MHz），已从只读启动备份生成80MHz临时DTB，解析复读确认Soft NPU为`0x80000000/0x4000`、SPI85、80MHz，三个冲突视频节点仍为`disabled`；DTB SHA-256=`bd9125ad1fc31d8fb23aa5a8b9851376647601d836aae5d0d9ad2cb402ceb9f2`。80/40MHz测试包已复制到U盘新增目录`DR1_SOFTNPU_TEMP_80MHZ_20260914/`，README、清单、bit和DTB共4项与隔离源逐文件SHA-256回读一致；未覆盖旧目录。板端随后经COM4执行`sync; poweroff`，日志到达`reboot: Power down`，再进入下述首次冷启动板测。

用户重新上电后，COM4自动抢占U-Boot成功。U-Boot从U盘读取80MHz DTB为16,915字节，CRC32=`0660312d`，与电脑端一致；初始reset/divider为`0x000001f1/0x07070201`。随后保持P2F reset为`0x000001e1`，写入并复读divider=`0x07070904`，通过FD25.1 OpenOCD D2XX RBB桥完成DR1M90链校验及新bit 100%易失下载，再释放并复读reset=`0x000001f1`。原TF内核加80MHz临时DTB正常启动；运行时确认Soft NPU节点为`anlogic,soft_npu`、`okay`、80MHz，平台设备存在、驱动未绑定，Linux从PS寄存器复读divider仍为`0x07070904`。在唯一一次受控访问中，官方驱动标为RO的顶层中断状态`0x80000008`正常返回`0x00000000`、退出码0，系统未重启。

随后完成第二次独立冷启动复测。U-Boot再次实读初始reset/divider=`0x000001f1/0x07070201`、同一DTB为16,915字节且CRC32仍为`0660312d`；相同顺序设置`0x000001e1/0x07070904`、下载同一SHA-256位流并释放为`0x000001f1`。Linux前置闸门再次确认DT compatible/status/clock、平台设备、driver-unbound、无NPU模块及PS分频均符合预期；本轮唯一一次`0x80000008`只读同样返回`0x00000000`、退出码0，持续监听15秒未发生挂死或重启。故冷启动重复性已在限定范围内确认，但仍只证明该候选组合的最小AXI-Lite可达性，不证明DMA、IRQ、driver probe、Hard/Soft协同或模型执行；由于复位连接和频率同时改变，不能把成功单独归因为其中一项。

公开`soft_npu.c`复核确认`0x08`是顶层设备中断状态，bit2..5对应NN/YOLO/CSC/Resize；空闲读0与源码语义一致。原驱动probe在建立字符设备和中断处理之前无条件向`0x804`和`0x1004`写1，源码仅将其命名为两个DMA start，未给出当前地址/缓冲区初始化前置条件，因此继续禁止直接加载原驱动。已在`F:/My_proj/_isolated_builds/softnpu_driver_diag_20260914_1/`从哈希冻结的公开源码派生诊断版：默认跳过DMA-start、IRQ注册/清中断和用户态寄存器IOCTL/mmap，只保留设备匹配、IRQ资源解析、ioremap及`/dev/soft_npu_diag`创建。传输包已新增到同一Kingston U盘的`DR1_SOFTNPU_DIAG_DRIVER_20260914/`，源端与U盘5/5文件哈希一致。

## 2026-09-15 Soft NPU诊断更新

诊断驱动已在板端私有内核树编译。初版因内部变量`enable_irq`与内核函数重名而失败，改为内部名`diag_enable_irq`后通过；最终版在请求IRQ时增加`IRQF_NO_AUTOEN`。源码SHA-256为`acb1d87f36166a9466a08692bed72886277805c9473f8e4a19cbb2de2fda7d1a`，板端模块SHA-256为`2763df4de905644b150e7fa57c5bd96fc9f1c106706591ca36f163d0d2c0d806`，vermagic与运行内核`6.1.111-rt42`匹配。缺少`Module.symvers`导致modpost未解析符号告警，但当前内核未启用`CONFIG_MODVERSIONS`，模块实际加载成功。

默认门禁加载成功创建`/dev/soft_npu_diag`并映射`0x80000000/0x4000`；`GET_REGISTER_INFO`返回正确资源，等待中断返回`EOPNOTSUPP`，寄存器读写和mmap均返回权限错误，卸载后驱动解绑和节点消失。随后以`enable_irq=1`加载最终版，Linux IRQ30映射到GIC hwirq117、Level High，处理器计数在10秒观察窗口内保持`0/0`；因为使用`IRQF_NO_AUTOEN`，这只证明资源登记，不证明中断线已实际使能或能被NPU触发。2026-09-15新上电后又按相同80MHz易失流程完成一次复核，bit下载100%、DTB CRC32仍为`0660312d`，诊断结果重复一致；结束时模块已卸载、U盘未挂载，Linux已正常`poweroff`。

对公开`libarmnn.so.32.1`符号和AArch64反汇编进一步确认：用户态`soft_npu_driver_init`仅打开字符设备、取得资源并mmap；Soft NN运行路径另行写`0x1804/0x1808/0x180c/0x1810/0x1820...`，而内核原驱动仍在probe阶段先写`0x804/0x1004`。现有手册、`npu.txt`和公开源码均没有给出两个全局DMA-start写操作的地址/缓冲区前置条件，因此它们不能解释为“解锁”并直接试写。当前U盘没有Arm NN运行库或固定模型，实际IRQ使能、DMA、CMA、Alnpu执行和模型数值验证均未执行。

## 2026-09-15 Soft NPU方向独立复核

只读复核认为逐级bring-up方向正确；详见 `docs/research/SOFTNPU_DIRECTION_REVIEW_20260915.md`。现有诊断门禁默认关闭有效，但不能直接开放allow_user_mmio（读写/mmap合并且缺边界检查）、allow_dma_start（仍在probe启动）或IRQ（handler会写清状态）。须先在新隔离版本补受控访问/作业状态/恢复边界，再做最小算子。未新增板测或修改驱动，NPU继续DOING，数据面与模型执行仍UNKNOWN。

## 2026-09-15 Soft NPU G0/G1更新

G0静态兼容矩阵已完成：公开 `SDK_2026.01` Arm NN 32.1运行库在Alnpu注册时连续初始化Hard NPU与Soft NPU，内存管理器还初始化CMA；两类NPU窗口都按RW共享映射。当前候选与本地官方Demo虽然同为Video_NPU 1.1、生成器`168007 2025/07/10`，但当前候选关闭`SOFT_CSC/SOFT_RESIZE/YOLOV3TINY`，加密RTL哈希也不同。故“纯MaxPool只需Soft”“同IP版本即同配置”和“诊断节点改名即可供运行库使用”均已拒绝。2026.01运行库与2025.07候选内核/实际板端配置的完整配套仍为`UNKNOWN`。报告：`docs/research/NPU_STACK_COMPATIBILITY_MATRIX_20260915.md`。

G1已在 `tools/npu/soft_npu_diag_v2/` 编码诊断v2，并逐文件复制到 `F:/My_proj/_isolated_builds/softnpu_diag_v2_20260915_1/`，6个源/说明文件哈希一致，另附哈希清单。它使用独立`/dev/soft_npu_diag_v2`和magic `D`，只允许资源查询、固定偏移`0x0008`只读及IRQ状态查询；无任意偏移接口、无MMIO写、无用户映射、无DMA-start、无IRQ使能。可选IRQ仅以`IRQF_NO_AUTOEN`登记，handler只读后隔离而不清设备寄存器。权威源和隔离副本的静态guard均通过；7文件载荷已复制到U盘`G:/DR1_SOFTNPU_DIAG_V2_20260915/`并逐项回读一致，清单内载荷6/6通过。当前状态仅为`CODED + STATIC_PASS + USB_STAGED`，尚未生成模块或上板，因此不得提升既有BOARD状态。

## 2026-09-15 Soft NPU G2板测更新

同一80/40MHz候选以U-Boot保持复位、设置`FCLK_CNT_DIV=0x07070904`、JTAG易失下载、释放复位，再从TF加载原内核并从只读U盘加载80MHz临时DTB。TD 6.2.1完成DR1M90芯片校验和100%下载；未执行`saveenv`或Flash写入。Linux设备树实读为`anlogic,soft_npu`、`okay`、`0x80000000/0x4000`、80MHz、SPI85，加载前无NPU模块且设备未绑定。

板端私有目录`/root/softnpu_diag_v2_20260915_1`以候选6.1.111-rt42源码/输出树构建成功；GCC为9.3.0，模块vermagic匹配运行内核。模块SHA-256=`62f00499b47e0620d3bd84d29411d3e6204bd3dd2058d80f40211c1793801462`，用户探针SHA-256=`82fa004bc3454ce81e642ded3cf64ff32125a0f83459cd8863f2d7c83a494839`。缺少`Module.symvers`产生modpost未解析符号告警，但目标内核未启用`CONFIG_MODVERSIONS`，实际加载成功；该源码树与运行内核的精确来源同一性仍`UNKNOWN`。

默认`register_irq=N`时，设备节点创建、平台绑定和固定状态读取通过：ABI=`0x00020000`、资源=`0x80000000/0x4000`、`top_status=0`、`linux_irq=-1`。稳定观察10秒无NPU中断项，卸载后节点删除且设备解绑。随后`register_irq=Y`只登记不使能，探针返回Linux虚拟IRQ30、状态`REGISTERED_DISABLED`、事件数0；`/proc/interrupts`显示GIC hwirq117，双核计数连续10秒均为0，之后卸载成功。不得把这些结果写成实际IRQ、DMA、CMA、Soft算子、Hard Conv或模型执行通过。Linux下另一次`devmem2`读取PS分频寄存器触发同步总线错误但系统保持运行；该值只采用启动前U-Boot实读，不再从Linux直接探测。

## 2026-09-15 Soft NPU G3连续内存契约更新

板端只读盘点确认内核启动时在`0x17c00000`保留128MiB CMA，运行时`CmaTotal=131072kB`、`CmaFree=130640kB`。Soft NPU设备树节点没有`dma-coherent`属性，`/soc/dma-ranges`存在但长度为0；这些信息只证明系统存在CMA保留区和当前设备树条件，不证明NPU主口可达、总线地址等同物理地址或缓存所有权已经闭合。

公开`cma_mem`驱动的同步ioctl不校验物理地址是否属于当前文件及是否越界，ABI会把内核逻辑地址复制给用户，并把`dma_alloc_coherent`缓冲区交给手工页属性和streaming sync路径，不能直接作为安全G3基线。公开Arm NN库则确实通过`/dev/cma_mem`分配、按返回物理地址mmap，并在CPU/设备切换时调用两个sync ioctl；这说明兼容运行库最终需要恢复该契约，但不等于公开实现可原样加载。

已在`tools/npu/soft_npu_cma_diag_v1/`形成独立CPU-only诊断，固定分配64KiB、32位DMA mask，只允许完整共享不可执行的`dma_mmap_coherent`映射和两向确定性CPU模式。它无NPU MMIO、IRQ、设备DMA、原始物理映射或公开vendor ABI，静态guard通过；最终载荷经隔离输入和U盘逐级哈希核验后，在板端新私有目录构建。模块SHA-256=`5478b2880227407bee1d3ba8c0fa6cc714e59da4a0d65d05b5ef3fe4e765b631`，探针SHA-256=`a2ee0ee5d5e40f7051e297d4bc31d977711c5a9ff7ca30659c8ff657f54b0fb4`，vermagic匹配`6.1.111-rt42`。

唯一一次板端探针返回ABI=`0x00010000`、flags=`0x0f`、size=65536、page=4096、DMA地址=`0x17c70000`；该地址完整位于启动日志记录的`0x17c00000`起128MiB CMA范围且不超过32位。内核填充→用户读取、用户填充→内核读取均为PASS，输出明确`device_dma=NOT_RUN`。加载后`CmaFree`从130640KiB降为130576KiB，卸载约2秒后恢复130640KiB；节点、模块和driver绑定均消失，10秒稳定观察无DMA API错误、Oops、BUG或重启。因此G3接受为`CMA_CPU_COHERENT_PASS_LIMITED`，不能扩大为NPU master、DMA、IRQ、Soft/Hard算子或模型通过。

## 2026-09-16 Soft NPU G4a传输包

在已识别为含既有DR1诊断目录的G盘，新建`DR1_SOFTNPU_IRQ_DIAG_V1_20260916/`并仅复制7个G4a源码/说明/清单文件。权威源与隔离输入7/7哈希一致，静态guard通过；隔离输入与U盘回读7/7一致，U盘内部清单6/6通过，且未覆盖既有目录。Windows弹出后该卷已不可访问。G4a状态为`CODED + STATIC_GUARD_PASS + USB_STAGED`，尚未在板端复制、构建或执行；实际IRQ使能、设备完成中断、DMA和模型仍未验证。下一步须由用户将U盘插回断电板卡，建立串口监听并按既有80/40MHz易失启动流程恢复环境；板端测试仍需独立前置核验。

## 2026-09-16 Soft NPU G4a限定板测

用户插回U盘后，从COM4截停U-Boot，实读初始reset/divider=`0x000001f1/0x07070201`；U盘临时80MHz DTB为16915字节、CRC32=`0660312d`。保持reset=`0x000001e1`期间设置并复读divider=`0x07070904`，用隔离候选bit（SHA-256=`edc2816d67c14968953b80d95a666ccee4204b977dd1074cd27e058e47021d07`）经FD OpenOCD RBB/TD完成DR1M90芯片校验和JTAG易失下载，再释放并复读reset=`0x000001f1`。原TF内核加临时DTB启动Linux `6.1.111-rt42`；设备树为`anlogic,soft_npu`、`0x80000000/0x4000`、80MHz、SPI85，测试前driver-unbound、无NPU/CMA模块，固定状态`0x80000008`只读为0。

U盘只读挂载，6/6清单通过；源码复制至新的板端私有目录`/root/softnpu_irq_diag_v1_20260916_1`后再次6/6通过并卸载U盘。板端模块/探针构建成功、`vermagic`匹配；缺少内核输出树`Module.symvers`和板端错误时钟仍产生与此前相同的modpost/clock-skew告警。模块SHA-256=`045eafb82af207e8fcf267928df6f7e6b3297023dadd13a5340a0e7d6087d98c`，探针SHA-256=`b94fdd75596f9933634e7534ee342ef7e42b74a17f21a33ac8f4b5a0674a41a2`。

模块加载后Linux IRQ30映射GIC hwirq117、双核计数0。唯一一次探针返回ABI=`0x00010000`、flags=`0x0f`、window=250ms、state=`NO_EVENT(2)`、pre/post status=0、event_count=0、退出码0；事后中断计数仍0，未见NPU相关内核异常。`rmmod`退出码0，节点消失、平台设备恢复未绑定、模块列表为空；Linux经`sync`正常`poweroff`，串口显示`reboot: Power down`。接受结论为`IRQ_IDLE_WINDOW_PASS_LIMITED`：仅证明空闲Linux IRQ短时使能没有异常事件，不证明设备能发出完成中断、能清中断或执行DMA/算子/模型。

## 2026-09-16 Soft NPU G4b启动前静态核验

复读IPUG166手册并对照冻结驱动和当前候选配置：NPU配置/系统时钟同为80MHz，候选参数含`NN_POOLING=1`；手册规定start后AXI master访问外存，完成IRQ保持有效直到清除。公开驱动在probe无条件写`0x0804/0x1004`，但完整Pool packet、设备DMA地址/缓存所有权、目标IRQ清除及超时恢复仍未闭合。故G4b状态为`BLOCKED_BY_CONTRACT`，未授权设备start、DMA或模型板测；当前不需开机/改线。逐项门槛见`docs/research/SOFTNPU_G4B_PREFLIGHT_20260916.md`。

同日继续只读反汇编冻结公开`libarmnn.so.32.1`：确认Pool packet生成函数把寄存器偏移与`0x91000000`组合写入packet。公开参考设备树的Soft NPU主机侧基址为`0x1F0000000`，当前候选为`0x80000000`，两者均不同于该packet常量；因此不能把三者简单当作同一地址空间，也不能据此判定当前候选不兼容。`0x91000000`为内部命令地址是`INFERRED`，准确解释及当前IP是否接受仍`UNKNOWN`。原G4b五项门槛不变；未上板、未启动DMA。

补充静态核验：公开参考Soft NPU窗口实际为1MiB，先前兼容矩阵的64KiB为笔误，已更正。当前候选生成的AXI Matrix参数指向`0x80000000`/16KiB；临时DTB亦为16KiB，但`system.address.xml`残留4KiB，真实板端高偏移响应和完整运行库访问范围仍`UNKNOWN`。公开Pool路径会把命令包复制到CMA并同步缓存，再启动局部DMA；`WAIT_INTERRUPT`超时仅返回错误，用户态抛异常，未见停DMA/复位/缓冲生命周期恢复。故G4b仍为`BLOCKED_BY_CONTRACT`，不能借已知写序直接上板执行。

新增纯离线`tools/npu/soft_npu_packet_inspector.py`并通过合成样本自测，只覆盖已恢复的局部packet结构；真实最小Pool包、设备执行和失败恢复未完成。用户确认U盘、COM4、FTDI/JTAG均已接好且板卡断电；当前保持断电，未提出上电或DMA试验。

G4b已在工程外隔离目录生成固定QDQ+MaxPool ONNX与输入/输出黄金向量，ONNX checker和PC CPU逐值结果通过；这是算术样本，不是Arm NN解析、Alnpu分配或NPU板测。冻结运行库的`.init_array`含644项，尚无法证明仅加载共享库没有硬件副作用，禁止以板上`dlopen`捕获packet。具体哈希和未闭合项见G4b报告。

后续静态追踪确认Soft NPU主AXI口直连PS HP1；公开Pool软件把输出/输入句柄值分别送`0x1820/0x1824`，包地址/字数送`0x1808/0x180c`，并单独在packet末尾构造`0x1814`项。公开等待函数把NN bit2与YOLO bit3都当成功候选，不能用于独立证明Pool完成。以上均为`PARTIAL`软件/连线证据，真实包、地址翻译、设备访问和失败恢复仍`UNKNOWN`，G4b启动门槛不变。

进一步只读解码公开库的Soft NN寄存器跳转表和寄存器枚举，确认软件镜像`r_SoftNPU+0x6c`按51个连续32位字对应`0x1800..0x18c8`。Pool配置写入的`r_SoftNPU+192/+196/+200/+204`分别映射到`0x1854/0x1858/0x185c/0x1860`；`0x1854`的bit0参与Pool entry筛选，后三者为Pool标记寄存器。此映射仅是公开软件静态证据，未证明真实packet、硬件位域或板上执行；G4b继续`BLOCKED_BY_CONTRACT`。

80MHz临时DTB的`/soc`含空`dma-ranges`地址映射声明，但Soft节点未声明`dma-coherent`。冻结CMA驱动的分配和同步绑定`cma_mem` misc device，并非Soft NPU平台设备；因此G3所得DMA地址不得直接移用为Soft NPU可达地址。后续必须由Soft设备自身分配/映射三缓冲并核对主口读写，不能把设备树声明视为DMA板测通过。

静态控制流已把单Pool mode 1普通配置entry候选偏移缩到`0x181c`和`0x1834..0x1860`的12个连续字，另有单独追加的`0x1814`；输入/输出句柄地址`0x1820/0x1824`由主机启动函数写入，不在普通配置entry中。此为`INFERRED`偏移/分组，未获得真实包的数据值与类型，也未证明CLP解释或上板安全。候选失败状态机已列出，但停机/复位仍未闭合。

已新增仅提取公开库entry列表的隔离探针C源码，设计上要求隐藏设备节点/系统接口、隔离网络并降权后才加载库；静态检查未见直接MMIO、DMA、ioctl或设备start，尚未在AArch64 Linux编译或运行，也未生成真实模型packet。本机无匹配AArch64 Linux sysroot且U盘目前在断电板卡上；下一步需用户在断电状态把U盘移至电脑，才能制作/校验离线传输包，之后另行审查是否上电做**非设备执行**的结构捕获。这不等于批准Pool硬件启动。

## 2026-09-17 G4b传输包暂缓

用户已将原DR1 U盘接回电脑；Windows识别为`G:`，盘根含历史DR1诊断包。只在`G:/DR1_SOFTNPU_G4B_ENTRY_CAPTURE_20260917/`新建空目录；安全审查拒绝把探针源码、说明/哈希清单和公开预编译库复制到可移动介质，理由是具体文件、目的地及介质归属需要明确授权。该目录复查为空，**没有USB_STAGED**，无板端编译/加载/运行。已在项目内准备说明和SHA-256清单，等待用户明确确认后才可再请求复制；不得绕过审查。V2保护清单17/17通过，G4b设备执行仍`BLOCKED_BY_CONTRACT`。

用户随后明确确认`G:`为自己的DR1 U盘并授权这四个具体文件复制到新目录。已按原目标路径复制探针源码、README、SHA-256清单和冻结公开库，U盘回读目录4文件、清单内3载荷哈希**3/3匹配**；阶段现为`USB_STAGED_ONLY`。没有目标Linux编译、库加载、entry捕获或NPU设备执行。下一步须由用户安全移除U盘并插回**断电**板卡，之后才可另行审查板端私有目录复制与隔离编译；此时不要上电。

## 2026-09-17 G4b板端离线捕获首试

用户将U盘插回断电板卡后，原TF默认启动进入AArch64 Linux `6.1.111-rt42`，未下载候选bit或替换DTB。`lsmod`为空，未见NPU/CMA设备节点。U盘`/dev/sda1`只读挂载，初版包清单3/3通过；四文件复制到新私有目录`/tmp/g4b_entry_capture_20260917_1`后复验3/3，U盘已卸载。板端GCC 9.3以`-Werror`构建用户态探针成功，二进制SHA-256=`9f0bdf75b082219f02dca3f5e42e76b004444cee90f7dc39e140eaa58f0d818f`。非root负门禁按预期在加载库前`CAPTURE_ABORT`/退出码2。唯一一次隔离捕获在`dlopen`厂家库时因`undefined symbol: pthread_create`退出码2，JSON为0字节；未调用entry函数、未访问NPU设备、未执行DMA/IRQ/算子/模型。符号表确认公开库引用该符号但`DT_NEEDED`不含`libpthread`，板端存在`libpthread.so.0`。之后`lsmod`仍为空、U盘未挂载，Linux经`sync; poweroff`到达`reboot: Power down`，COM4已关闭。板卡物理供电状态待用户确认。

工程内探针已修订为**完成隔离和降权后**先加载系统pthread，再加载厂家库，源码及清单哈希已变化；修订版未编译/板测，U盘旧目录不得当成新版本。离线结构捕获状态为`ABORTED_DEPENDENCY/NO_JSON`；G4b真实packet及设备执行继续`BLOCKED_BY_CONTRACT`。下一步先请用户确认物理断电，再把U盘移回电脑以独立新目录暂存修订包；不得覆盖旧包或直接重试设备。

同日用户要求继续，电脑识别同一`G:`可移动FAT32 U盘，旧包四文件及清单仍在，新目录原先不存在。修订版源码、README、SHA清单和冻结公开库已复制到新目录`G:/DR1_SOFTNPU_G4B_ENTRY_CAPTURE_V2_20260917/`，回读目录4文件、清单内载荷3/3哈希匹配；旧包清单哈希仍为`ed8133877bf7ddaf6a1a65f30f0b60bf38949e8d8478da099adc21abaa25e125`。状态为`V2_USB_STAGED_ONLY`，**修订版未上板编译/运行，无entry JSON**。板卡物理断电状态仍待用户确认；用户安全弹出并把U盘插回断电板卡后，才能进入新的前置检查。G4b设备执行继续`BLOCKED_BY_CONTRACT`。

用户随后确认U盘已插回且板卡断电；执行说明已修正为修订版路径和新的板端私有目录。按用户确认上电后，COM4只观察到FSBL在TF/SD初始化阶段报`Card SD Init error, err code 0xA6000103`、`Mmc Init Err: 0xA6000103`、`Boot device init failed`及`fsbl error: 2000007`，**没有进入U-Boot/Linux**。短暂观察无自动恢复，已关闭串口；用户确认再次物理断电。此次没有读取U盘包、板端编译、库加载或NPU操作。G4b非设备捕获新阻塞记为`BLOCKED_BOOT_MEDIA_INITIALIZATION`，原因仅知是本次SD启动初始化失败，接触/供电/卡/时序根因均`UNKNOWN`；不能由此推断修订包有问题，也不能提升G4b设备执行状态。下一步只在断电状态检查TF卡就位及启动拨码，不写卡或重刷固件。

用户在断电状态重新插牢TF卡并确认拨码`ON-OFF-OFF`后，一次仅观察启动的复测进入Linux `6.1.111-rt42`；FSBL仍曾有接收相位重试，启动介质长期可靠性**未证明**。Linux `dmesg`未见后续MMC I/O或ext4错误，NPU/CMA模块仍未加载。修订包在只读U盘和新私有目录`/tmp/g4b_entry_capture_v2_20260917_1`均清单3/3匹配，U盘已卸载；板端GCC 9.3 `-Werror`编译通过，二进制SHA-256=`bd1ccc8c1c8c9c03f869fcef9125880c885f5c32f79b85b212cb4cacd8b94161`，非root失败门禁退出码2。

**唯一一次隔离加载仍未捕获entry：**程序在私有namespace遮蔽`/dev`/`/sys`/`/proc`并降权后加载系统pthread，再`dlopen`厂家库；库初始化阶段抛`ghc::filesystem::filesystem_error: Permission denied: '/dev/hard_npu'`，进程退出码134、JSON 0字节，错误文件SHA-256=`afe594111bbcf887c2ef76d42088721515dba5383278e0eec6835f6977c1448b`。这证明该加载路径尝试访问Hard NPU设备节点，不能解除隔离去获取条目；没有调用目标entry函数、未运行模型或NPU设备。收尾`lsmod`仍为空、U盘未挂载、未见内核Oops/I/O错误；`sync; poweroff`到达`reboot: Power down`，COM4关闭，物理断电待用户确认。非设备捕获子阶段改为`BLOCKED_VENDOR_LIBRARY_INITIALIZATION`，G4b真实packet与设备执行仍`BLOCKED_BY_CONTRACT`。下一步转回只读静态分析/隔离主机替代方案，不在板上放宽设备遮蔽重试。

PC只读反汇编进一步确认冻结库含真实硬件初始化路径：`hard_npu_driver_init`以读写权限打开`/dev/hard_npu`，随后ioctl并申请读写映射；`soft_npu_driver_init`对`/dev/soft_npu`同样如此，库内调用点依次调用二者。本次板端异常的精确构造函数/调用栈尚未定位，不能把这两个函数写成已在本次执行；但`dlopen`不可当作无设备副作用的捕获手段。板端探针路线停止，仅继续PC静态或独立仿真研究；G4b设备执行门槛不变。

用户随后明确澄清板卡**已物理断电**；先前“一段点”是打字错误。U盘和TF卡保持原位。当前无需接线或上电，继续PC只读核验。

G4b主动Pool启动仍`BLOCKED_BY_CONTRACT`。新增一个**不启动设备**的前置板测源码`tools/npu/soft_npu_three_buffer_diag_v1/`：在Soft平台设备下同时申请三块各4KiB的coherent缓冲，检查32位范围、64字节对齐和互不重叠；不映射寄存器、不申请IRQ、不加载厂家库、不提交设备DMA。源码静态guard通过，清单4/4匹配；状态仅`SOURCE_READY/NOT_STAGED/NOT_BUILT/NOT_RUN`，不能写成上板通过。IPUG166手册复核证实启动后才会触发AXI master访问，未提供Pool packet及超时局部停止字段。前置实验计划见`docs/research/SOFTNPU_G4_PRESTART_THREE_BUFFER_PLAN_20260917.md`。U盘仍在断电板卡，下一步需要用户将其移至电脑以新目录传输，并在板端隔离构建前重新审查bit/DTB/内核身份。外部快照路径本次只读检查仍不存在。

用户将原DR1 U盘插回电脑后，已只在新目录`G:/DR1_SOFTNPU_G4_PRESTART_THREE_BUFFER_V1_20260917/`暂存三缓冲实验五文件，回读文件数5、清单内4/4哈希匹配；清单自身SHA-256=`4ecf48cc8a655c404086fa9b26c3394b82014c7ef646a9ca2324d8af96990e39`。旧G4b包清单及U盘80MHz bit/临时DTB哈希复算未变。子阶段现为`USB_STAGED_ONLY/NOT_BUILT/NOT_RUN`；此时板卡仍物理断电，下一步由用户安全弹出U盘并插回板卡，**不要上电**。G4b主动Pool门槛仍未放行。

## 2026-09-17 G4前置三缓冲限定板测

用户确认U盘插回断电板卡并按请求上电。先观察原TF完整进入Linux `6.1.111-rt42`；FSBL有一次SD接收相位失败后选择可用相位，长期介质可靠性仍`UNKNOWN`。软件重启后受控截停U-Boot，既有80/40MHz候选bit经DR1M90芯片校验和100%易失JTAG下载，P2F复位/分频读回为`0x000001e1`/`0x07070904`，释放复位后`0x000001f1`。原TF内核加U盘临时DTB启动，运行时Soft节点为`anlogic,soft_npu`、`0x80000000/0x4000`、SPI 85、80MHz，先前无绑定驱动。未改TF BOOT、Flash或持久环境。

U盘只读挂载、清单4/4通过；五文件复制到新板端私有目录`/root/soft_npu_three_buffer_diag_v1_20260917_1/`后复验4/4，U盘卸载。板端GCC 9.3.0构建退出码0，模块SHA-256=`1e1a0c8e8ac52758ec1b34ea9bbeb03a7ca10c697fee1c81f001d8b78d328d2b`，vermagic与运行内核一致。一次`insmod`记录packet/input/output三个4096字节coherent缓冲的DMA地址分别为`0x0496c000`、`0x0baf3000`、`0x0e635000`；三者在32位内、64字节对齐且不重叠。一次`rmmod`记录全部释放、设备重新未绑定，`lsmod`为空。`CmaFree`前中后均130640 KiB，不据此判定实际分配后端。Linux到达`reboot: Power down`，PC串口/JTAG关闭，用户确认物理断电。

此子阶段仅为`THREE_BUFFER_CPU_ALLOCATION_PASS_LIMITED`。没有NPU寄存器写、IRQ登记、设备主AXI传输、Pool算子、Arm NN、模型推理或延迟测试。构建树缺`Module.symvers`且有板端时钟偏差，精确内核源码同一性仍`UNKNOWN`。主动G4b仍`BLOCKED_BY_CONTRACT`；下一步回到离线packet结构、地址翻译/缓存所有权和超时停止恢复契约，不直接再次上板启动。

## 2026-09-17 G4b 寄存器元数据复核

隔离候选 IP 的寄存器元数据独立确认 `0x0804/0x1004` 为 AXI 读/写启动、`0x1804` 为读包启动、`0x1814` 为 NN 启动，`0x18b8` 为 Soft NN 只读中断状态；不是任意“解锁”寄存器。生成并由综合读取的互连 HDL 给 NPU 从端 `0x80000000/16KiB`，但矩阵 `Design.xml` 同时保留 `4KiB` 参数。板测前整体高偏移译码为 `UNKNOWN`，因此只批准下面这一字的只读核验，不写寄存器、不启动设备。主动 Pool 仍 `BLOCKED_BY_CONTRACT`。完整证据与停机条件见 `docs/research/SOFTNPU_G4B_REGISTER_MAP_RECONCILIATION_20260917.md`。

同日该限定只读板测已执行：复位对齐80/40MHz候选bit临时JTAG下载成功，复位/分频读回符合既有流程；U-Boot下`0x80000008`与`0x800018b8`各读一次均返回0，串口仍响应。判定仅`HIGH_OFFSET_RO_RESPONSE_PASS_LIMITED`，不能推广为完整16KiB寄存器窗口安全，更不能提升为DMA、IRQ完成或Pool通过。电脑端串口/JTAG关闭，用户确认板卡物理断电。主动G4b仍`BLOCKED_BY_CONTRACT`，下一步回到真实packet、主AXI与超时恢复的离线契约。

## 2026-09-18 Astra静态协助结论

用户要求的独立回复已保存根目录 `SOFTNPU_ASTRA_RESPONSE_20260918.md`。当前方向可继续，但下一步收敛为A0/A1/B0/B1（拓扑×value_info）差分规格、故障PC/栈与探针ABI核验、独立硬件恢复/AXI边界设计。未证明parser崩溃根因；未生成/运行新图或厂家库、未操作板卡。固定描述符包为20字/80字节，不是真实网络包；主动G4b仍BLOCKED_BY_CONTRACT。恢复建议区分一次性故障断电与在线局部恢复，不降低DMA边界要求。后续优先量化普通Conv和真实模型小链，不把Pool诊断等同MobileNet部署。






