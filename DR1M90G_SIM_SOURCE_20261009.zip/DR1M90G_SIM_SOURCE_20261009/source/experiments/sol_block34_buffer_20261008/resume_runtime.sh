#!/bin/sh
set -eu
base=/run/space16_cached1
target=/run/block34_span1/main
test -s "$base/runtime/run_hard_soft_clip.py"
for f in "$base"/runtime/*.py; do
 case "$f" in */space16_executor.py) continue;; esac
 cp "$f" "$target/runtime/"
done
for n in libblock34_cpu_gaps.so jobs.json combined_assets block3_dw_params.bin block4_dw_params.bin disable_dsi.py; do
 test -e "$base/$n"
 ln -s "$base/$n" "$target/$n"
done
python3 - <<'PY'
from pathlib import Path
base=Path('/run/space16_cached1')
target=Path('/run/block34_span1/main')
p=target/'runtime/run_hard_soft_clip.py'
s=p.read_text()
assert '0x42341610' in s
p.write_text(s.replace('0x42341610','0x42341910'))
s=(base/'run_saved_clip.sh').read_text()
assert 'root=/run/space16_cached1' in s
s=s.replace('root=/run/space16_cached1','root=/run/block34_span1/main')
s=s.replace('space16_fixed.ko','space16_span_fixed.ko').replace('rmmod space16_fixed','rmmod space16_span_fixed')
s=s.replace('SPACE16_SAVED_REAL_CLIP_COMPLETE','SPACE16_SPAN_REAL_CLIP_COMPLETE')
(target/'run_saved_clip.sh').write_text(s)
p=Path('/run/block34_span1/block/run_board_block.py')
s=p.read_text()
if 'import json\n' not in s:
 s='import json\n'+s
p.write_text(s)
PY
echo SPAN_RUNTIME_READY_NO_LOAD_NO_START
