"""Real CPU bridge for the next spatial depthwise hardware replacement."""
import json
from pathlib import Path
from time import perf_counter
import numpy as np
import onnxruntime as ort
from dw16_reference import requantize


class DepthwiseLayerReference:
    def __init__(self, folder):
        folder = Path(folder)
        self.q = json.loads((folder/'depthwise.json').read_text())
        channels = self.q['input_shape'][1]
        self.weight = np.fromfile(folder/'weight_u8.bin', np.uint8).reshape(channels,3,3).astype(np.int64)-128
        self.bias = np.fromfile(folder/'bias_i32.bin', '<i4').astype(np.int64)

    def __call__(self, activation):
        q = self.q
        if list(activation.shape)!=q['input_shape'] or activation.dtype!=np.uint8:
            raise ValueError('depthwise input shape/dtype differs')
        pt,pl,pb,pr = q['pads']
        sy,sx = q['strides']
        _,channels,height,width = q['output_shape']
        padded = np.pad(activation.astype(np.int64)-q['input_zero'],
                        ((0,0),(0,0),(pt,pb),(pl,pr)))
        acc = np.broadcast_to(self.bias[None,:,None,None],q['output_shape']).copy()
        for y in range(3):
            for x in range(3):
                acc += padded[:,:,y:y+sy*height:sy,x:x+sx*width:sx]*self.weight[:,y,x][None,:,None,None]
        multiplier = np.asarray(q['multiplier'],np.int64).reshape(1,channels,1,1)
        return requantize(acc,multiplier,q['shift'],q['output_zero'])


class DepthwisePrefix:
    def __init__(self, folder, options, executor=None, block3_assets=None, block3_executor=None, pointwise96_assets=None, block4_assets=None,block12_assets=None,batch16_models=None,session_factory=None):
        folder = Path(folder)
        session = session_factory or ort.InferenceSession
        self.reference = DepthwiseLayerReference(folder)
        self.executor = executor or self.reference
        self.fused=getattr(self.executor,'backend',None)=='PL_FRONT96'
        from tensor_codec_native import TensorCodec
        self.codec=TensorCodec()
        self.pointwise=None
        before_path=folder/'cpu_before_dw.onnx'
        if pointwise96_assets is not None:
            from pointwise96_reference import Pointwise96Reference
            self.pointwise=Pointwise96Reference(pointwise96_assets)
            self.pointwise_executor=self.pointwise
            if not self.fused:
                from pointwise96_native import Pointwise96Native,library_path
                if library_path().is_file():self.pointwise_executor=Pointwise96Native(pointwise96_assets,self.pointwise)
            pw=self.pointwise.q['output'];dw=self.reference.q
            if pw['scale']!=dw['input_scale'] or pw['zero']!=dw['input_zero']:
                raise ValueError('PW96 output domain does not feed DW96')
            before_path=Path(pointwise96_assets)/'cpu_before_pw96.onnx'
        if batch16_models is not None:before_path=Path(batch16_models)/'cpu_before_pw96_b16.onnx'
        self.before = session(str(before_path),options,providers=['CPUExecutionProvider'])
        if self.fused and self.pointwise is None:
            raise ValueError('Fused execution requires the PW96 input domain')
        if block3_assets is not None:
            from front_block3 import FrontBlock3After
            self.after=FrontBlock3After(block3_assets,options,block3_executor,block4_assets,block12_assets,batch16_models,session_factory=session)
        else:self.after = session(str(folder/'cpu_after_dw.onnx'),options,providers=['CPUExecutionProvider'])
        self.last_run = None

    def get_inputs(self):
        return self.before.get_inputs()

    def run(self, outputs, inputs):
        started = perf_counter()
        value = self.before.run(None,inputs)[0]
        q = self.reference.q
        pointwise_ms=0
        if self.pointwise is None:
            activation = self.codec.quantize(value,q['input_scale'],q['input_zero'])
        else:
            pwstarted=perf_counter()
            activation=self.pointwise.quantize(value)
            if not self.fused:activation=self.pointwise_executor(activation)
            pointwise_ms=(perf_counter()-pwstarted)*1000
        before_ms = (perf_counter()-started)*1000
        started = perf_counter()
        result = self.executor(activation)
        dw_ms = (perf_counter()-started)*1000
        value = self.codec.dequantize(result,q['output_scale'],q['output_zero'])
        started = perf_counter()
        output = self.after.run(outputs,{self.after.get_inputs()[0].name:value})
        self.last_run = dict(target=q['target'],backend=getattr(self.executor,'backend','CPU_FIXED_DEPTHWISE'),before_ms=before_ms,
                             depthwise_ms=dw_ms,after_ms=(perf_counter()-started)*1000)
        if hasattr(self.executor,'last_run'):self.last_run['device']=self.executor.last_run
        if hasattr(self.after,'last_run'):self.last_run['block3']=self.after.last_run
        self.last_run['tensor_conversion_backend']=self.codec.backend
        if self.pointwise is not None:
            self.last_run['pointwise96']=dict(backend='PL_FRONT96' if self.fused else self.pointwise_executor.backend,
                                            pointwise_ms=None if self.fused else pointwise_ms)
        return output
