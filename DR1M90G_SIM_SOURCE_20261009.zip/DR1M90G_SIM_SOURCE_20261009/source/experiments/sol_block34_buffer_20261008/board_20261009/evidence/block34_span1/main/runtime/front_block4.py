"""The real stride-two block immediately after the qualified block3."""
import json
from pathlib import Path
from time import perf_counter
import numpy as np
import onnxruntime as ort
from dw16_reference import requantize

class FrontBlock4Reference:
    backend='CPU_FIXED_BLOCK4'
    def __init__(self,folder):
        folder=Path(folder);self.q=json.loads((folder/'block4.json').read_text())
        if self.q['shape']!=[1,24,56,56] or self.q['output_shape']!=[1,32,28,28]:
            raise ValueError('Block4 fixed shape differs')
        self.weight=[];self.bias=[]
        for layer in self.q['layers']:
            self.weight.append(np.fromfile(folder/(layer['key']+'_weight_u8.bin'),np.uint8).reshape(layer['weight_shape']).astype(np.int64)-128)
            self.bias.append(np.fromfile(folder/(layer['key']+'_bias_i32.bin'),'<i4').astype(np.int64))

    def convolution(self,value,index):
        layer=self.q['layers'][index];weight=self.weight[index];bias=self.bias[index]
        pixels=value.astype(np.int64)-layer['input']['zero']
        _,channels,height,width=layer['output_shape']
        if layer['group']==1:
            acc=(weight.reshape(channels,-1)@pixels.reshape(pixels.shape[1],-1)+bias[:,None]).reshape(layer['output_shape'])
        else:
            pt,pl,pb,pr=layer['pads'];sy,sx=layer['strides']
            padded=np.pad(pixels,((0,0),(0,0),(pt,pb),(pl,pr)))
            acc=np.broadcast_to(bias[None,:,None,None],layer['output_shape']).copy()
            for y in range(3):
                for x in range(3):
                    acc+=padded[:,:,y:y+sy*height:sy,x:x+sx*width:sx]*weight[:,0,y,x][None,:,None,None]
        multiplier=np.asarray(layer['multiplier'],np.int64).reshape(1,channels,1,1)
        return requantize(acc,multiplier,layer['shift'],layer['output']['zero'])

    def __call__(self,value):
        if value.shape!=(1,24,56,56) or value.dtype!=np.uint8:raise ValueError('Block4 UINT8 input differs')
        for index in range(3):value=self.convolution(value,index)
        return value

class FrontBlock4After:
    def __init__(self,folder,options,block3_domain,executor=None,block12_assets=None,batch16_models=None,session_factory=None):
        folder=Path(folder);self.reference=FrontBlock4Reference(folder)
        session=session_factory or ort.InferenceSession
        if self.reference.q['layers'][0]['input']!=block3_domain:
            raise ValueError('Block3 output does not feed block4 directly')
        self.executor=executor
        if self.executor is None:
            from front_block4_native import FrontBlock4Native,library_path
            self.executor=FrontBlock4Native(folder,self.reference) if library_path().is_file() else self.reference
        from tensor_codec_native import TensorCodec
        self.codec=TensorCodec()
        if block12_assets is not None:
            from front_block12 import FrontBlock12After
            self.after=FrontBlock12After(block12_assets,options)
        else:
            after_path=folder/'cpu_after_block4.onnx' if batch16_models is None else Path(batch16_models)/'cpu_after_block4_b16.onnx'
            self.after=session(str(after_path),options,providers=['CPUExecutionProvider'])
        self.last_run=None

    def run_quantized(self,value):
        started=perf_counter();result=self.executor(value);block_ms=(perf_counter()-started)*1000
        if result.shape!=(1,32,28,28) or result.dtype!=np.uint8:raise ValueError('Block4 output differs')
        q=self.reference.q['layers'][-1]['output'];decoded=self.codec.dequantize(result,q['scale'],q['zero'])
        started=perf_counter();output=self.after.run(None,{self.after.get_inputs()[0].name:decoded})
        self.last_run=dict(backend=getattr(self.executor,'backend','CPU_FIXED_BLOCK4'),block_ms=block_ms,after_ms=(perf_counter()-started)*1000)
        if hasattr(self.after,'last_run'):self.last_run['block12']=self.after.last_run
        return output
