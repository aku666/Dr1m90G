"""Fixed two-mode access to the existing BLOCK34 DW engine and scratch DMA."""
import ctypes as C
import os
from pathlib import Path
from time import perf_counter
import numpy as np
from dw16_executor import Job

class DW144Executor:
    def __init__(self, parameters):
        import fcntl
        self.fcntl = fcntl
        self.parameters = {}
        for block in (3, 4):
            raw = (Path(parameters) / f'block{block}_dw_params.bin').read_bytes()
            if len(raw) != 4608:
                raise ValueError('Fixed DW144 parameters differ')
            self.parameters[block] = C.create_string_buffer(raw, len(raw))
        if C.sizeof(Job) != 56:
            raise ValueError('Fixed shared PL job ABI differs')
        self.output3 = np.empty((1, 144, 56, 56), np.uint8)
        self.output4 = np.empty((1, 144, 28, 32), np.uint8)
        self.fd = os.open('/dev/block34', os.O_RDWR | os.O_CLOEXEC)
        self.blocked = False
        self.last_run = None

    def __call__(self, value, block):
        if self.blocked:
            raise RuntimeError('Prior PL DW failure: preserve DMA until cold recovery')
        if block not in (3, 4) or value.shape != (1, 144, 56, 56) or value.dtype != np.uint8:
            raise ValueError('Fixed DW144 input differs')
        value = np.ascontiguousarray(value)
        output = self.output3 if block == 3 else self.output4
        job = Job(0x70001 if block == 3 else 0x80001, 451584, 4608, output.nbytes,
                  value.ctypes.data, C.addressof(self.parameters[block]), output.ctypes.data)
        raw = bytearray(bytes(job))
        cmd = (3 << 30) | (56 << 16) | (ord('G' if block == 3 else 'H') << 8) | 1
        self.blocked = True
        self.last_run = None
        start = perf_counter()
        try:
            self.fcntl.ioctl(self.fd, cmd, raw, True)
            result = Job.from_buffer_copy(raw)
            self.last_run = dict(block=block, status=result.status, device_cycles=result.cycles,
                                 device_ns=result.elapsed_ns, ioctl_ms=(perf_counter()-start)*1000)
            if result.abi != job.abi or result.status != 2:
                raise RuntimeError('PL DW144 final write response not acknowledged')
            if block == 4 and np.any(output[:, :, :, 28:]):
                raise ArithmeticError('PL DW144 stride2 physical row padding differs')
            actual = output.copy() if block == 3 else output[:, :, :, :28].copy()
            self.blocked = False
            return actual
        except Exception as error:
            if self.last_run is None:
                result = Job.from_buffer_copy(raw)
                self.last_run = dict(block=block, status=result.status,
                                     device_cycles=result.cycles, device_ns=result.elapsed_ns,
                                     ioctl_ms=(perf_counter()-start)*1000)
            self.last_run['error'] = str(error)
            raise

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1
