"""Single-image CPU prefix -> Hard H5 -> Soft H6 -> CPU 128D tail."""
import json
from pathlib import Path
from time import perf_counter
import numpy as np
import onnxruntime as ort
from soft_residual import fixed_h6_reference


def fixed_h5_reference(activation, folder):
    if activation.shape != (1,960,7,7) or activation.dtype != np.uint8:
        raise ValueError('H5 requires UINT8 1x960x7x7')
    folder = Path(folder)
    weight = np.fromfile(folder/'weight_u8.bin', np.uint8).reshape(160,960).astype(np.int64)-119
    bias = np.fromfile(folder/'bias.bin', '<i4').astype(np.int64)
    acc = weight @ activation.reshape(960,49).astype(np.int64) + bias[:,None]
    return np.clip(((acc*17640)>>23)+171,0,255).astype(np.uint8).reshape(1,160,7,7)


class HardSoftSpatial:
    def __init__(self, folder, hard_executor, soft_executor, dw16_assets=None, dw16_executor=None, expansion_assets=None, expansion_executor=None, front_dw_assets=None, front_dw_executor=None, front_block_assets=None, front_block_executor=None, front_pw96_assets=None, front_block4_assets=None,front_block12_assets=None,batch16_models=None,cpu_depthwise_library=None,cpu_sessions=None):
        folder = Path(folder)
        self.float_handoff = (folder/'float_handoff.json').exists()
        session = cpu_sessions or ort.InferenceSession
        if cpu_sessions is None:
            options = ort.SessionOptions()
            options.intra_op_num_threads = 2
            options.log_severity_level = 3
            options.add_session_config_entry('session.intra_op.allow_spinning','0')
        else:
            cpu_sessions.check_library(cpu_depthwise_library)
            options = cpu_sessions.options
        self.cpu_depthwise_counter=None
        if cpu_depthwise_library is not None:
            import ctypes
            if cpu_sessions is None:options.register_custom_ops_library(str(cpu_depthwise_library))
            self.cpu_depthwise_library=ctypes.CDLL(str(cpu_depthwise_library))
            self.cpu_depthwise_counter=self.cpu_depthwise_library.CpuDepthwiseLayersExecuted
            self.cpu_depthwise_counter.restype=ctypes.c_uint64
            self.cpu_depthwise_started=int(self.cpu_depthwise_counter())
        if (dw16_assets is None)!=(dw16_executor is None):
            raise ValueError('DW16 replacement requires both assets and executor')
        if (expansion_assets is None)!=(expansion_executor is None):
            raise ValueError('H4 replacement requires assets and executor')
        if expansion_assets is not None and not self.float_handoff:
            raise ValueError('H4 bridge requires qualified float prefix/tail')
        if expansion_assets is not None and dw16_assets is None:
            raise ValueError('H4 replacement feeds the existing DW16 handoff')
        self.expansion_executor=expansion_executor
        if front_block_assets is not None and front_dw_assets is None:
            raise ValueError('Block3 currently feeds the fixed front DW bridge')
        if front_pw96_assets is not None and front_dw_assets is None:
            raise ValueError('PW96 currently feeds the fixed front DW bridge')
        if front_block4_assets is not None and front_block_assets is None:
            raise ValueError('Block4 requires the real block3 UINT8 output')
        if front_block12_assets is not None and front_block4_assets is None:
            raise ValueError('Block12 bridge requires the current block4 CPU tail')
        self.expansion_contract=json.loads((Path(expansion_assets)/'expansion16.json').read_text()) if expansion_assets is not None else None
        prefix_path = Path(dw16_assets)/'cpu_before_dw16.onnx' if dw16_assets is not None else folder/'cpu_before_h5.onnx'
        if expansion_assets is not None:prefix_path=Path(expansion_assets)/'cpu_before_h4.onnx'
        if front_dw_assets is not None:
            if expansion_assets is None:raise ValueError('Front DW bridge feeds the H4 prefix')
            from depthwise_prefix import DepthwisePrefix
            self.prefix = DepthwisePrefix(front_dw_assets,options,front_dw_executor,front_block_assets,front_block_executor,front_pw96_assets,front_block4_assets,front_block12_assets,batch16_models,session_factory=session)
        else:self.prefix = session(str(prefix_path),options,providers=['CPUExecutionProvider'])
        self.tail = session(str(folder/'cpu_after_h6.onnx'),options,providers=['CPUExecutionProvider'])
        self.hard_executor = hard_executor
        self.soft_executor = soft_executor
        self.dw16_executor = dw16_executor
        self.last_tensors = None

    def run(self, tensor):
        if tensor.shape != (1,3,224,224) or tensor.dtype != np.float32:
            raise ValueError('requires float32 1x3x224x224')
        start = perf_counter()
        prefix_values=self.prefix.run(None,{self.prefix.get_inputs()[0].name:tensor})
        if self.expansion_executor is not None:
            skip=prefix_values[0]
            hard_input=np.clip(np.rint(skip/np.float32(self.expansion_contract['input_scale']))+133,0,255).astype(np.uint8)
        else:hard_input,skip=prefix_values
        if self.float_handoff:
            if self.expansion_executor is None:hard_input = np.clip(np.rint(hard_input/np.float32(0.0235294122248888)),0,255).astype(np.uint8)
            skip = np.clip(np.rint(skip/np.float32(0.18490247428417206))+133,0,255).astype(np.uint8)
        prefix_elapsed_ms=(perf_counter()-start)*1000
        prefix_ms=getattr(self.prefix,'prepared_prefix_ms',prefix_elapsed_ms)
        prepared_adjustment_ms=prefix_ms-prefix_elapsed_ms
        expansion_ms,expansion_backend=0.0,'CPU_ONNX'
        expansion_input=None
        if self.expansion_executor is not None:
            expansion_input=hard_input;t=perf_counter()
            hard_input,expansion_backend=self.expansion_executor(hard_input)
            expansion_ms=(perf_counter()-t)*1000
        dw16_ms, dw16_backend = 0.0, 'CPU_ONNX'
        if self.dw16_executor is not None:
            t = perf_counter()
            hard_input,dw16_backend = self.dw16_executor(hard_input)
            dw16_ms = (perf_counter()-t)*1000
        t = perf_counter()
        hard, hard_backend = self.hard_executor(hard_input)
        hard_ms = (perf_counter()-t)*1000
        if hard.shape != skip.shape or hard.dtype != np.uint8:
            raise ValueError('H5 output differs from residual shape/type')
        t = perf_counter()
        soft, soft_backend = self.soft_executor(skip,hard)
        soft_ms = (perf_counter()-t)*1000
        if soft.shape != (1,160,7,7) or soft.dtype != np.uint8:
            raise ValueError('Soft H6 output differs')
        t = perf_counter()
        tail_input = ((soft.astype(np.float32)-154)*np.float32(0.3371888995170593)
                      if self.float_handoff else soft)
        feature = self.tail.run(None,{self.tail.get_inputs()[0].name:tail_input})[0]
        if feature.shape != (1,128) or not np.isfinite(feature).all():
            raise ValueError('invalid 128D feature')
        self.last_tensors = dict(hard_input=hard_input,skip=skip,hard=hard,soft=soft)
        if expansion_input is not None:self.last_tensors['expansion_input']=expansion_input
        block_backend=(getattr(self.prefix,'last_run',None) or {}).get('block3',{}).get('backend')
        block3_pl=int(block_backend in ('PL_BLOCK3','PL_BLOCK34'))
        block4_pl=int(block_backend=='PL_BLOCK34')
        block34_hard=int(block_backend in ('HARD_PW_CPU_DW_ADD_BLOCK34_CANDIDATE','HARD_PW_PL_DW_CPU_ADD_BLOCK34_CANDIDATE'))
        block34_dw_pl=int(block_backend=='HARD_PW_PL_DW_CPU_ADD_BLOCK34_CANDIDATE')
        front_backend=(getattr(self.prefix,'last_run',None) or {}).get('backend')
        front_pw_pl=int(front_backend=='PL_FRONT96')
        front_dw_pl=int(front_backend in ('PL_DW96','PL_FRONT96'))
        return feature, dict(total_ms=(perf_counter()-start)*1000+prepared_adjustment_ms,prefix_ms=prefix_ms,
            hard_ms=hard_ms,soft_ms=soft_ms,tail_ms=(perf_counter()-t)*1000,
            expansion_ms=expansion_ms,expansion_backend=expansion_backend,
            dw16_ms=dw16_ms,dw16_backend=dw16_backend,
            hard_backend=hard_backend,soft_backend=soft_backend,
            actual_hardnpu_layers=int(hard_backend=='HARDNPU')+int(expansion_backend=='HARDNPU')+4*block34_hard,
            actual_softnpu_adds=int(soft_backend=='SOFTNPU'),
            actual_pl_pointwise_layers=2*block3_pl+2*block4_pl+front_pw_pl,actual_pl_residual_adds=block3_pl,
            cpu_ordinary_layers=35-2*block3_pl-2*block4_pl-4*block34_hard-front_pw_pl-int(hard_backend=='HARDNPU')-int(expansion_backend=='HARDNPU'),cpu_depthwise_layers=17-block3_pl-block4_pl-2*block34_dw_pl-int(dw16_backend=='PL_DW16')-front_dw_pl,
            actual_pl_depthwise_layers=block3_pl+block4_pl+2*block34_dw_pl+int(dw16_backend=='PL_DW16')+front_dw_pl,
            cpu_residual_adds=10-block3_pl-int(soft_backend=='SOFTNPU'),
            model_scope=('EXPERIMENTAL_H4_DW16_H5_H6_QUANTIZED_HANDOFF' if self.expansion_executor is not None else
                         'EXPERIMENTAL_DW16_H5_H6_QUANTIZED_HANDOFF' if self.dw16_executor is not None else
                         'TRAINED_FLOAT_CPU_WITH_H5_H6_QUANTIZED_HANDOFF' if self.float_handoff
                         else 'UINT8_QUANTIZED_SPATIAL_CANDIDATE'))


def run_cpu(folder, tensor):
    folder = Path(folder)
    chain = HardSoftSpatial(folder,
        lambda x:(fixed_h5_reference(x,folder),'CPU_FIXED_H5'),
        lambda a,b:(fixed_h6_reference(a,b),'CPU_FIXED_SOFT_ADD'))
    return chain, chain.run(tensor)
