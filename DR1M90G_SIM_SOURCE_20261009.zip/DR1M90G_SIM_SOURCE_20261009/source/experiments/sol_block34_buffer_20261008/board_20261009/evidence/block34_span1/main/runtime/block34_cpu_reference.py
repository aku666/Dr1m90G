"""Scalar Hard PW arithmetic, with the existing PL DW and residual rules."""
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'implementation_hardnpu/runtime'))
from front_block3 import FrontBlock3Reference
from front_block4 import FrontBlock4Reference


class HardPointwise:
    def convolution(self, value, index):
        layer = self.q['layers'][index]
        if layer['group'] != 1:
            return super().convolution(value, index)
        channels = layer['output_shape'][1]
        # Integer products and sums of these UINT8 fixed shapes are exact in
        # binary64. This avoids slow INT64 matrix multiply on the host only.
        pixels = value.reshape(value.shape[1], -1).astype(np.float64)
        pixels -= layer['input']['zero']
        acc = (self.weight[index].reshape(channels, -1).astype(np.float64)
               @ pixels).astype(np.int64) + self.bias[index][:, None]
        if acc.min() < -(1 << 31) or acc.max() >= (1 << 31):
            raise ArithmeticError('Hard pointwise accumulator outside signed32')
        multipliers = np.asarray(layer['multiplier'], np.int64)[:, None]
        output = ((acc * multipliers) >> layer['shift']) + layer['output']['zero']
        return np.clip(output, 0, 255).astype(np.uint8).reshape(layer['output_shape'])


class HardBlock3Reference(HardPointwise, FrontBlock3Reference):
    pass


class HardBlock4Reference(HardPointwise, FrontBlock4Reference):
    pass


class HardBlock34Reference:
    backend = 'CPU_HARD_SCALAR_BLOCK34_CANDIDATE'
    output_shape = (1, 32, 28, 28)

    def __init__(self, folder):
        folder = Path(folder)
        self.block3 = HardBlock3Reference(folder / 'block3')
        self.block4 = HardBlock4Reference(folder / 'block4')
        if self.block3.q['add']['output'] != self.block4.q['layers'][0]['input']:
            raise ValueError('Candidate block domains differ')

    def __call__(self, value):
        return self.block4(self.block3(value))
