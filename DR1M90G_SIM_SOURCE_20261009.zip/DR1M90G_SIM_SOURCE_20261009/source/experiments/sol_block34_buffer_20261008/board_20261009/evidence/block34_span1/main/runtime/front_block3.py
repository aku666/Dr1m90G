"""Fixed arithmetic and the real CPU bridge for spatial residual block 3."""
import json
from pathlib import Path
from time import perf_counter
import numpy as np
import onnxruntime as ort
from dw16_reference import requantize

class FrontBlock3Reference:
    backend='CPU_FIXED_BLOCK3'
    def __init__(self,folder):
        folder=Path(folder);self.q=json.loads((folder/'block3.json').read_text())
        self.weight=[];self.bias=[]
        for l in self.q['layers']:
            self.weight.append(np.fromfile(folder/(l['key']+'_weight_u8.bin'),np.uint8).reshape(l['weight_shape']).astype(np.int64)-128)
            self.bias.append(np.fromfile(folder/(l['key']+'_bias_i32.bin'),'<i4').astype(np.int64))

    def convolution(self,x,index):
        l,w,b=self.q['layers'][index],self.weight[index],self.bias[index]
        pixels=x.astype(np.int64)-l['input']['zero'];c=l['output_shape'][1]
        if l['group']==1:
            acc=(w.reshape(c,-1)@pixels.reshape(-1,3136)+b[:,None]).reshape(l['output_shape'])
        else:
            padded=np.pad(pixels,((0,0),(0,0),(1,1),(1,1)))
            acc=np.broadcast_to(b[None,:,None,None],l['output_shape']).copy()
            for y in range(3):
                for z in range(3):acc+=padded[:,:,y:y+56,z:z+56]*w[:,0,y,z][None,:,None,None]
        return requantize(acc,np.asarray(l['multiplier'],np.int64).reshape(1,c,1,1),l['shift'],l['output']['zero'])

    def __call__(self,x):
        if list(x.shape)!=self.q['shape'] or x.dtype!=np.uint8:raise ValueError('Block3 input differs')
        skip=x
        for index in range(3):x=self.convolution(x,index)
        q=self.q['add']
        acc=(skip.astype(np.int64)-q['inputs'][0]['zero'])*q['multiplier'][0]+(x.astype(np.int64)-q['inputs'][1]['zero'])*q['multiplier'][1]
        return requantize(acc,1,30,q['output']['zero'])

class FrontBlock3After:
    def __init__(self,folder,options,executor=None,block4_assets=None,block12_assets=None,batch16_models=None,session_factory=None):
        folder=Path(folder);self.reference=FrontBlock3Reference(folder)
        session=session_factory or ort.InferenceSession
        from tensor_codec_native import TensorCodec
        self.codec=TensorCodec()
        self.executor=executor or self.reference
        self.combined=getattr(self.executor,'output_shape',None)==(1,32,28,28)
        if self.combined and block4_assets is None:raise ValueError('BLOCK34 requires block4 CPU tail assets')
        if executor is None:
            from front_block3_native import FrontBlock3Native,library_path
            if library_path().is_file():self.executor=FrontBlock3Native(folder,self.reference)
        before_path=folder/'cpu_before_block3.onnx' if batch16_models is None else Path(batch16_models)/'cpu_before_block3_b16.onnx'
        self.before=session(str(before_path),options,providers=['CPUExecutionProvider'])
        self.block4=None
        if block4_assets is not None:
            from front_block4 import FrontBlock4After
            self.block4=FrontBlock4After(block4_assets,options,self.reference.q['add']['output'],block12_assets=block12_assets,batch16_models=batch16_models,session_factory=session)
            self.after=self.block4.after
        else:self.after=session(str(folder/'cpu_after_block3.onnx'),options,providers=['CPUExecutionProvider'])
        self.last_run=None

    def get_inputs(self):return self.before.get_inputs()

    def run(self,outputs,inputs):
        t=perf_counter();value=self.before.run(None,inputs)[0];q=self.reference.q
        d=q['layers'][0]['input']
        x=self.codec.quantize(value,d['scale'],d['zero'])
        before_ms=(perf_counter()-t)*1000;t=perf_counter();y=self.executor(x);block_ms=(perf_counter()-t)*1000
        if y.shape!=((1,32,28,28) if self.combined else x.shape) or y.dtype!=np.uint8:raise ValueError('Spatial block output differs')
        t=perf_counter()
        if self.combined:
            d=self.block4.reference.q['layers'][-1]['output'];value=self.codec.dequantize(y,d['scale'],d['zero'])
            result=self.after.run(outputs,{self.after.get_inputs()[0].name:value})
            self.block4.last_run=dict(backend=getattr(self.executor,'backend','UNKNOWN'),timing='INCLUDED_IN_BLOCK3_JOB')
            if hasattr(self.after,'last_run'):self.block4.last_run['block12']=self.after.last_run
        elif self.block4 is not None:result=self.block4.run_quantized(y)
        else:
            d=q['add']['output'];value=self.codec.dequantize(y,d['scale'],d['zero'])
            result=self.after.run(outputs,{self.after.get_inputs()[0].name:value})
        self.last_run=dict(backend=getattr(self.executor,'backend','CPU_FIXED_BLOCK3'),before_ms=before_ms,block_ms=block_ms,after_ms=(perf_counter()-t)*1000)
        if self.block4 is not None:self.last_run['block4']=self.block4.last_run
        if hasattr(self.executor,'last_run'):self.last_run['device']=self.executor.last_run
        self.last_run['tensor_conversion_backend']=self.codec.backend
        return result
