"""Fixed sixteen real frames -> Hard/Soft spatial features -> trained TCN."""
import argparse
import json
import sys
from pathlib import Path
from time import perf_counter
import numpy as np
from hard_soft_spatial import HardSoftSpatial,fixed_h5_reference
from soft_residual import CpuH6Executor
from temporal_sequence import TemporalSequence


def create_temporal(args,classes,exact_executor=None):
    """Reuse the existing trained TCN/V4R implementations."""
    if args.temporal_backend=='onnx':
        return TemporalSequence(args.temporal_model,classes)
    if args.temporal_backend=='pointwise-cpu':
        from pointwise_temporal import PointwiseTemporalSequence
        return PointwiseTemporalSequence(args.temporal_model,classes)
    if args.tcn_assets is None:
        raise ValueError('V4R requires the qualified --tcn-assets')
    from v4r_batched_temporal import BatchedV4RTemporalSequence
    executor=None
    if args.temporal_backend in ('v4r-pl','v4r-pl-hardnpu-prefix'):
        from v4r_c128_executor import V4RC128Executor
        executor=V4RC128Executor()
    return BatchedV4RTemporalSequence(args.temporal_model,args.tcn_assets,classes,
        args.v4r_budget_code,native_library=None if args.temporal_backend=='fixed-cpu' else args.v4r_native_library,
        settle_executor=executor,exact_executor=exact_executor,direct_cpu=args.temporal_backend=='fixed-cpu')


def main(argv=None,cpu_sessions=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--assets',type=Path,required=True)
    inputs = ap.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--frames',type=Path,help='normalized float32 NCHW raw or NPY')
    inputs.add_argument('--frames-dir',type=Path,help='exactly sixteen chronological images or saved raw frames')
    inputs.add_argument('--capture-fdma',action='store_true',help='capture sixteen IMX415 frames before NPU inference')
    ap.add_argument('--capture-pixel-bytes',choices=('BGRX','RGBX'))
    ap.add_argument('--capture-roi',nargs=4,type=int,metavar=('X','Y','W','H'))
    ap.add_argument('--capture-status-offset',type=lambda value:int(value,0),choices=(0,0x100),default=0,
                    help='FST1 bank offset; 0x100 for the shared PW32 camera candidate')
    ap.add_argument('--capture-copy-policy',choices=('freeze','continuous'),default='freeze',
                    help='freeze finishes active writes before each copy; continuous keeps recycling slots')
    ap.add_argument('--capture-full-snapshots',action='store_true',help='Preserve full-resolution evidence PNGs in product mode')
    ap.add_argument('--capture-mapped-resize',action='store_true',help='Resize each frozen camera slot into an owned tensor')
    ap.add_argument('--capture-no-snapshots',action='store_true',help='Headless capture: keep normalized model input and JSON only')
    ap.add_argument('--raw-layout',type=Path,help='explicit saved FDMA raw layout; requires --frames-dir')
    ap.add_argument('--temporal-model',type=Path,required=True)
    ap.add_argument('--temporal-backend',choices=('onnx','pointwise-cpu','fixed-cpu','v4r-batched-cpu','v4r-pl','v4r-pl-hardnpu-prefix'),default='onnx')
    ap.add_argument('--tcn-assets',type=Path)
    ap.add_argument('--tcn-driver',type=Path,help='qualified TCN module for serial H5-to-TCN switch')
    ap.add_argument('--v4r-budget-code',type=int,default=32)
    ap.add_argument('--v4r-native-library',type=Path)
    ap.add_argument('--classes',type=Path,required=True)
    ap.add_argument('--results',type=Path,required=True)
    ap.add_argument('--backend',choices=('cpu','hardware'),default='cpu')
    ap.add_argument('--soft-backend',choices=('cpu','hardware'),help='H6 residual placement; defaults to the main backend')
    ap.add_argument('--spatial-batch16-models',type=Path,help='unchanged fixed16 CPU prefix variants for FRONT96/BLOCK34')
    ap.add_argument('--cpu-depthwise-library',type=Path,
                    help='optional original-float CPU C576/H14 operator for the explicitly selected graph')
    ap.add_argument('--front-dw-assets',type=Path,help='Experimental CPU bridge for the next 96-channel DW replacement')
    ap.add_argument('--front-dw-backend',choices=('cpu','pl','fused'),default='cpu')
    ap.add_argument('--front-pw96-assets',type=Path,help='Experimental signed16 CPU pointwise arithmetic feeding DW96')
    ap.add_argument('--front-block-backend',choices=('cpu','pl','pl34','hardpl34'),default='cpu')
    ap.add_argument('--combined-hard-root',type=Path,help='Experimental 16-model owner; unchanged batch16 prefix required')
    ap.add_argument('--front-block-parameters',type=Path,help='Frozen expand/depthwise/project parameter records')
    ap.add_argument('--front-block-assets',type=Path,help='Fixed C24/C144 block3 assets')
    ap.add_argument('--front-block4-assets',type=Path,help='Experimental fixed CPU stride-two block4 after block3')
    ap.add_argument('--front-block12-assets',type=Path,help='Experimental real C96/C576 block12 CPU integer bridge')
    ap.add_argument('--execution-mode',choices=('validate','product'),default='product')
    ap.add_argument('--expansion-assets',type=Path,help='qualified H4 arithmetic with explicit candidate float-prefix bridge')
    ap.add_argument('--hard-block-assets',type=Path,help='ten qualified constant H4/H5 slots; requires hardware and expansion assets')
    ap.add_argument('--dw16-assets',type=Path,help='explicit experimental fixed-point DW16 handoff; CPU reference until PL qualification')
    ap.add_argument('--dw16-backend',choices=('cpu','pl'),default='cpu')
    ap.add_argument('--display-font',type=Path,help='render result.png with an explicit Chinese font')
    ap.add_argument('--display-latin-font',type=Path,help='ASCII font if the Chinese font lacks numbers')
    ap.add_argument('--display-dsi-frame',action='store_true',
                    help='write 1024x600 B,G,R,0 scanout bytes beside result.png')
    args = ap.parse_args(argv)
    soft_backend=args.soft_backend or args.backend
    if args.backend=='cpu' and soft_backend=='hardware':
        ap.error('hardware H6 requires the hardware main backend')
    if args.hard_block_assets is not None and (args.backend!='hardware' or args.expansion_assets is None):
        ap.error('fixed Hard block requires hardware and --expansion-assets')
    if args.display_dsi_frame and args.display_font is None:
        ap.error('--display-dsi-frame requires --display-font')
    if args.capture_no_snapshots and args.display_font is not None:
        ap.error('headless capture cannot also request a rendered result')
    if args.temporal_backend=='v4r-pl-hardnpu-prefix' and (args.tcn_driver is None or args.tcn_assets is None):
        ap.error('Hard TCN prefix requires --tcn-driver and --tcn-assets')
    if args.spatial_batch16_models is not None and (args.backend!='hardware' or
            args.front_dw_backend!='fused' or args.front_block_backend not in ('pl34','hardpl34') or
            args.front_block12_assets is not None):
        ap.error('fixed16 CPU prefix batching requires FRONT96/BLOCK34 and the unchanged block4 tail')
    if args.combined_hard_root is not None and (args.front_block_backend!='hardpl34' or
            args.hard_block_assets is None or args.spatial_batch16_models is None or
            args.temporal_backend!='fixed-cpu' or args.backend!='hardware'):
        ap.error('Combined candidate requires hardware, hardpl34, fixed16 CPU prefix, H4/H5 and exact CPU TCN')
    if args.front_block_backend=='hardpl34' and args.combined_hard_root is None:
        ap.error('hardpl34 requires the explicit combined candidate root')
    preprocessing_started = perf_counter()
    sources = []
    capture_report = None
    last_image = None
    if args.results.exists():
        raise ValueError('preserve previous results; choose a new directory')
    if args.capture_fdma:
        if args.capture_pixel_bytes is None or args.capture_roi is None:
            ap.error('--capture-fdma requires --capture-pixel-bytes and --capture-roi')
        if args.raw_layout is not None:
            ap.error('--raw-layout is for saved files, not live capture')
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
        from implementation_video.capture_model_clip import capture
        capture_folder = args.results/'capture'
        # Capture completes before opening either NPU device. The inference
        # tensors are private copies, never live/recycled FDMA slot views.
        capture_report = capture(capture_folder,args.capture_pixel_bytes,args.capture_roi,
                                 status_offset=args.capture_status_offset,
                                 freeze_copy=args.capture_copy_policy=='freeze',
                                 preview_snapshots=args.execution_mode=='product' and not args.capture_full_snapshots,
                                 mapped_resize=args.capture_mapped_resize,
                                 save_snapshots=not args.capture_no_snapshots)
        frames = np.load(capture_folder/'normalized_frames.npy',allow_pickle=False)
        sources = capture_report['frames']
        last_image = None if args.capture_no_snapshots else capture_folder/'latest_frame.png'
    elif args.frames_dir is not None:
        sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'model_pipeline/src'))
        from frame_input import prepare_frame
        layout = json.loads(args.raw_layout.read_text(encoding='utf-8')) if args.raw_layout else None
        suffixes = ('.raw',) if layout else ('.png','.jpg','.jpeg','.bmp')
        paths = sorted(p for p in args.frames_dir.iterdir() if p.is_file() and p.suffix.lower() in suffixes)
        if len(paths)!=16:
            raise ValueError('requires exactly sixteen chronological saved frames')
        tensors = []
        for path in paths:
            tensor,source = prepare_frame(path,layout)
            tensors.append(tensor[0])
            sources.append(source)
        frames = np.asarray(tensors,np.float32)
        if args.raw_layout is None:
            last_image = paths[-1]
    else:
        if args.raw_layout:
            ap.error('--raw-layout requires --frames-dir')
        frames = (np.load(args.frames,allow_pickle=False) if args.frames.suffix=='.npy' else
                  np.fromfile(args.frames,dtype='<f4').reshape(16,3,224,224))
    input_preparation_ms = (perf_counter()-preprocessing_started)*1000
    if frames.shape!=(16,3,224,224) or frames.dtype!=np.float32 or not np.isfinite(frames).all():
        raise ValueError('requires sixteen normalized finite float32 3x224x224 frames')
    args.results.mkdir(parents=True,exist_ok=capture_report is not None)
    classes = json.loads(args.classes.read_text(encoding='utf-8'))
    if isinstance(classes,dict):
        classes = classes['classes']
    init = perf_counter()
    session_before = cpu_sessions.report() if cpu_sessions is not None else None
    hard = soft = dw16 = front_dw = front_block = temporal = tcn = None
    tcn_loaded = False
    temporal_initialization_ms = 0
    frame_index = [0]
    try:
        dw16 = None
        expansion=None
        if args.combined_hard_root is not None:
            from space16_executor import Space16Executor
            hard=Space16Executor(args.combined_hard_root,args.results/'hard',args.execution_mode)
        if args.front_block_backend in ('pl','pl34','hardpl34'):
            if args.front_block_assets is None or args.front_block_parameters is None or args.backend!='hardware':
                raise ValueError('PL block3 requires assets, parameter records and hardware main chain')
            if args.front_block_backend=='hardpl34':
                if args.front_block4_assets is None:raise ValueError('Combined candidate requires block4 assets')
                from block34_hard_executor import Block34HardExecutor
                from dw144_executor import DW144Executor
                front_block=Block34HardExecutor(args.combined_hard_root,args.results/'front_hard',
                    args.execution_mode,pl_dw=DW144Executor(args.combined_hard_root),transport=hard)
            elif args.front_block_backend=='pl34':
                if args.front_block4_assets is None:raise ValueError('BLOCK34 requires block4 assets')
                from block34_executor import Block34Executor
                front_block=Block34Executor(args.front_block_assets,args.front_block_parameters,args.front_block4_assets,args.execution_mode)
            else:
                from block3_executor import Block3Executor
                front_block=Block3Executor(args.front_block_assets,args.front_block_parameters,args.execution_mode)
        if args.front_dw_backend in ('pl','fused'):
            if args.front_dw_assets is None or args.backend!='hardware':
                raise ValueError('PL front DW requires assets and the hardware main chain')
            if args.front_dw_backend=='fused':
                if args.front_pw96_assets is None:raise ValueError('Fused front requires signed16 PW96 assets')
                from front96_executor import Front96Executor
                front_dw=Front96Executor(args.front_pw96_assets,args.front_dw_assets,args.execution_mode)
            else:
                from dw96_executor import Depthwise96Executor
                front_dw=Depthwise96Executor(args.front_dw_assets,args.execution_mode)
        if args.expansion_assets is not None:
            if args.dw16_assets is None:raise ValueError('H4 candidate requires DW16 handoff')
            from expansion16_reference import Expansion16Reference
            expansion=Expansion16Reference(args.expansion_assets)
        if args.dw16_backend=='pl' and args.dw16_assets is None:
            raise ValueError('PL DW16 needs --dw16-assets')
        if args.dw16_assets is not None:
            if args.dw16_backend=='pl':
                from dw16_executor import Depthwise16Executor
                dw16 = Depthwise16Executor(args.dw16_assets,args.execution_mode)
            else:
                from dw16_reference import Depthwise16Reference
                dw16 = Depthwise16Reference(args.dw16_assets)
        if args.backend=='hardware':
            from h5_serial_executor import H5SerialExecutor
            from h6_serial_executor import H6SerialExecutor
            if args.combined_hard_root is not None:
                expansion=hard.expansion
            elif args.hard_block_assets is not None:
                from h4_h5_fixed_executor import H4H5FixedExecutor
                hard=H4H5FixedExecutor(args.hard_block_assets,args.results/'hard',args.execution_mode)
                expansion=hard.expansion
            else:
                hard = H5SerialExecutor(args.assets,args.results/'hard',args.execution_mode)
            if soft_backend=='hardware':
                soft = H6SerialExecutor(args.results/'soft',args.execution_mode)
            soft_executor=soft if soft is not None else CpuH6Executor()
            chain = HardSoftSpatial(args.assets,hard,soft_executor,args.dw16_assets,dw16,args.expansion_assets,expansion,args.front_dw_assets,front_dw,args.front_block_assets,front_block,args.front_pw96_assets,args.front_block4_assets,args.front_block12_assets,args.spatial_batch16_models,args.cpu_depthwise_library,cpu_sessions=cpu_sessions)
        else:
            soft_executor=CpuH6Executor()
            chain = HardSoftSpatial(args.assets,
                lambda x:(fixed_h5_reference(x,args.assets),'CPU_FIXED_H5'),
                soft_executor,args.dw16_assets,dw16,args.expansion_assets,expansion,args.front_dw_assets,front_block_assets=args.front_block_assets,front_pw96_assets=args.front_pw96_assets,front_block4_assets=args.front_block4_assets,front_block12_assets=args.front_block12_assets,cpu_depthwise_library=args.cpu_depthwise_library,cpu_sessions=cpu_sessions)
        if args.spatial_batch16_models is not None:
            from spatial_batch16 import Fixed16BatchPrefix
            chain.prefix=Fixed16BatchPrefix(chain.prefix,args.spatial_batch16_models)
        if args.temporal_backend!='v4r-pl-hardnpu-prefix':
            temporal = create_temporal(args,classes)
        initialization_ms = (perf_counter()-init)*1000
        started = perf_counter()
        if args.spatial_batch16_models is not None:
            chain.prefix.prepare(frames,frame_index)
        if args.combined_hard_root is not None:
            hard.select_group(6)  # All sixteen BLOCK34 calls have completed/released.
        features,timings = [],[]
        for index in range(16):
            frame_index[0] = index
            feature,timing = chain.run(frames[index:index+1])
            if args.front_dw_assets is not None:
                timing['front_depthwise_execution'] = chain.prefix.last_run
            if args.backend=='hardware':
                timing['hard_execution'] = hard.last_run
                timing['soft_execution'] = soft_executor.last_run
            if args.dw16_backend=='pl':
                timing['dw16_execution'] = dw16.last_run
            if args.execution_mode=='validate':
                folder = args.results/f'frame_{index:02d}'
                folder.mkdir(exist_ok=False)
                np.save(folder/'feature.npy',feature)
                for name,value in chain.last_tensors.items():
                    (folder/f'{name}.bin').write_bytes(value.tobytes())
                (folder/'timing.json').write_text(json.dumps(timing,indent=2)+'\n')
            features.append(feature[0])
            timings.append(timing)
            if args.execution_mode=='validate':
                print('FRAME_COMPLETE',index,round(timing['total_ms'],3),flush=True)
        features = np.asarray(features,np.float32)[None]
        mask = np.ones((1,16),np.bool_)
        np.save(args.results/'features.npy',features)
        np.save(args.results/'valid_mask.npy',mask)
        if args.temporal_backend=='v4r-pl-hardnpu-prefix':
            import subprocess
            from tcn_fixed_model_executor import TcnFixedModelExecutor
            begin=perf_counter()
            # H5 and TCN own the same HardNPU registers/IRQ; all H5 shards
            # have already completed and released before this serial switch.
            if hard is not None:
                if hard.blocked or hard.count!=16:
                    raise RuntimeError('H5 not released; preserve device state')
                hard.close()
                subprocess.run(['rmmod','h4_h5_fixed' if args.hard_block_assets is not None else 'h5_segment'],check=True)
            subprocess.run(['insmod',str(args.tcn_driver),'allow_h10_start=1'],check=True)
            tcn_loaded=True
            tcn=TcnFixedModelExecutor(args.tcn_assets,args.results/'temporal_hard')
            temporal=create_temporal(args,classes,exact_executor=tcn)
            temporal_initialization_ms=(perf_counter()-begin)*1000
        prediction = temporal.classify(features,mask)
        if tcn is not None:
            # This fixed window used layers0/1; each actual output was RELEASED.
            tcn.close()
            subprocess.run(['rmmod','tcn_grid7_fixed'],check=True)
            tcn_loaded=False
        report = dict(scope=('LIVE_IMX415_FIXED_WINDOW' if capture_report is not None else
            'FIXED_SAVED_REAL_FRAMES_NOT_CAMERA'),backend=args.backend,
            input_kind='IMX415 FDMA' if capture_report is not None else 'SAVED_FRAMES',
            temporal_backend=args.temporal_backend,execution_mode=args.execution_mode,
            temporal_initialization_ms=temporal_initialization_ms,
            input_sources=sources,input_preparation_ms=input_preparation_ms,
            feature_shape=list(features.shape),initialization_ms=initialization_ms,
            total_ms=(perf_counter()-started)*1000,spatial_ms=sum(x['total_ms'] for x in timings),
            actual_hard_starts=hard.starts if args.combined_hard_root is not None else
                (160 if args.hard_block_assets is not None else 64) if args.backend=='hardware' else 0,
            actual_soft_starts=sum(x['actual_softnpu_adds'] for x in timings),
            prediction=prediction,frames=timings,
            display_artifacts_requested=args.display_font is not None,
            recovery=('SOFT_DMA_PINNED_COLD_REQUIRED' if soft is not None else
                      'DW16_COMPLETED_DMA_REUSABLE' if args.dw16_backend=='pl' else
                      'HARD_COMPLETED_DMA_RELEASED' if args.backend=='hardware' else 'NO_DEVICE_ACCESS'))
        report['soft_backend']=soft_backend
        if args.spatial_batch16_models is not None:
            report['spatial_batch16']=chain.prefix.report
        if cpu_sessions is not None:
            session_after=cpu_sessions.report()
            report['cpu_session_reuse']=dict(created=session_after['created']-session_before['created'],
                reused=session_after['reused']-session_before['reused'],
                construction_ms=session_after['creation_ms']-session_before['creation_ms'],
                scope=session_after['scope'])
        if chain.cpu_depthwise_counter is not None:
            report['cpu_depthwise_library']=str(args.cpu_depthwise_library)
            report['actual_cpu_float_depthwise_layers']=int(chain.cpu_depthwise_counter())-chain.cpu_depthwise_started
            report['cpu_float_depthwise_precision']='ORIGINAL_FLOAT32_NO_NEW_QUANTIZATION'
        report['actual_cpu_h6_calls']=sum(x['soft_backend'].startswith('CPU_') for x in timings)
        report['cpu_h6_is_model_computation']=soft_backend=='cpu'
        report['expansion_handoff'] = str(args.expansion_assets) if args.expansion_assets is not None else None
        report['actual_hard_expansion_starts'] = 96 if args.hard_block_assets is not None else 0
        report['actual_temporal_hard_starts'] = prediction.get('actual_hardnpu_layers',0)
        report['actual_total_hard_starts'] = report['actual_hard_starts']+report['actual_temporal_hard_starts']
        report['actual_pl_v4r_starts'] = sum(x.get('mode')=='PL_V4R_C128' for x in prediction.get('layers',[]))
        report['cpu_spatial_ms'] = sum(x['prefix_ms']+x['tail_ms']+
            (-x['front_depthwise_execution']['depthwise_ms'] if args.front_dw_backend in ('pl','fused') else 0)+
            (-x['front_depthwise_execution']['block3']['block_ms'] if args.front_block_backend in ('pl','pl34','hardpl34') else 0)+
            (x['front_depthwise_execution']['block3']['device']['cpu_add_ms'] if args.combined_hard_root is not None else 0)+
            (x['expansion_ms'] if x['expansion_backend'].startswith('CPU_') else 0)+
            (x['dw16_ms'] if x['dw16_backend'].startswith('CPU_') else 0)+
            (x['hard_ms'] if x['hard_backend'].startswith('CPU_') else 0)+
            (x['soft_ms'] if x['soft_backend'].startswith('CPU_') else 0) for x in timings)
        report['dw16_handoff'] = str(args.dw16_assets) if args.dw16_assets is not None else None
        report['actual_pl_dw16_starts'] = 16 if args.dw16_backend=='pl' else 0
        report['front_depthwise_handoff'] = str(args.front_dw_assets) if args.front_dw_assets is not None else None
        report['front_block3_handoff'] = str(args.front_block_assets) if args.front_block_assets is not None else None
        report['front_block4_handoff'] = str(args.front_block4_assets) if args.front_block4_assets is not None else None
        report['front_block12_handoff'] = str(args.front_block12_assets) if args.front_block12_assets is not None else None
        report['front_pw96_handoff'] = str(args.front_pw96_assets) if args.front_pw96_assets is not None else None
        report['actual_pl_block3_starts'] = front_block.count if front_block is not None and args.front_block_backend=='pl' else 0
        report['actual_pl_block34_starts'] = front_block.count if front_block is not None and args.front_block_backend=='pl34' else 0
        if args.combined_hard_root is not None:
            report['actual_hard_block34_starts']=sum(len(row['block34_device']['jobs']) for row in chain.prefix.records)
            report['actual_pl_dw144_starts']=sum(row['block34_device']['pl_dw_layers'] for row in chain.prefix.records)
            report['combined_candidate']=dict(abi='0x42341910',quality='NOT_ADOPTED_NOT_CALIBRATED',
                run_attempts=hard.attempts,model_slots=16,original_h4_h5_assets_unchanged=True)
        report['actual_pl_dw96_starts'] = front_dw.count if front_dw is not None and args.front_dw_backend=='pl' else 0
        report['actual_pl_front96_starts'] = front_dw.count if front_dw is not None and args.front_dw_backend=='fused' else 0
        report['hard_path_ms'] = sum(x['hard_ms'] for x in timings)
        report['soft_path_ms'] = sum(x['soft_ms'] for x in timings)
        report['hard_run_ioctl_ms'] = sum(x.get('hard_execution',{}).get('run_ioctl_ms',0) for x in timings)
        report['cpu_oracle_calls'] = sum(x.get('hard_execution',{}).get('cpu_oracle_calls',0) for x in timings)
        report['static_asset_load_ms'] = hard.asset_load_ms if hard is not None else 0
        report['soft_golden_compared'] = soft is not None and args.execution_mode=='validate'
        report['cpu_only_fixed_ops_are_model_computation'] = args.backend=='cpu' and args.dw16_backend=='cpu'
        if capture_report is not None:
            report['capture'] = capture_report
            report['capture_through_classification_ms'] = (
                input_preparation_ms+initialization_ms+report['total_ms'])
            if soft is None:
                report['recovery'] = 'CAPTURE_DISABLED_RESERVED_DDR_PERSISTS_NO_DRAIN_CLAIM'
        (args.results/'clip_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        if args.display_font is not None:
            from sign_result_display import render_result,pack_dsi_rgbx
            image=render_result(report,args.display_font,frame_path=last_image,
                latin_font_path=args.display_latin_font)
            image.save(args.results/'result.png')
            if args.display_dsi_frame:
                (args.results/'result.rgbx').write_bytes(pack_dsi_rgbx(image))
        print(json.dumps({k:v for k,v in report.items() if k!='frames'},ensure_ascii=False,indent=2))
    except Exception as error:
        if front_block is not None and getattr(front_block,'last_output',None) is not None:
            np.save(args.results/'block3_failure_output.npy',front_block.last_output)
        if front_dw is not None and getattr(front_dw,'last_output',None) is not None:
            np.save(args.results/'dw96_failure_output.npy',front_dw.last_output)
        if dw16 is not None and getattr(dw16,'last_output',None) is not None:
            np.save(args.results/'dw16_failure_output.npy',dw16.last_output)
        (args.results/'failure.json').write_text(json.dumps(dict(error=str(error),
            execution_mode=args.execution_mode,frame_index=frame_index[0],hard=hard.last_run if hard else None,
            dw16=getattr(dw16,'last_run',None),
            dw96=getattr(front_dw,'last_run',None),
            block3=getattr(front_block,'last_run',None),
            actual_pl_block3_starts=getattr(front_block,'count',0),
            tcn_loaded=tcn_loaded,tcn_halted=getattr(tcn,'halted',None),
            soft=soft.last_run if soft else None,recovery='PRESERVE_DEVICE_STATE_NO_AUTOMATIC_RETRY'),indent=2)+'\n')
        raise
    finally:
        if front_block is not None:front_block.close()
        if front_dw is not None:front_dw.close()
        if tcn is not None:tcn.close()
        if temporal is not None and getattr(temporal,'settle_executor',None) is not None:
            temporal.settle_executor.close()
        if dw16 is not None and args.dw16_backend=='pl':
            dw16.close()
        if soft is not None:
            soft.close()
        if hard is not None:
            hard.close()


if __name__=='__main__':
    main()
