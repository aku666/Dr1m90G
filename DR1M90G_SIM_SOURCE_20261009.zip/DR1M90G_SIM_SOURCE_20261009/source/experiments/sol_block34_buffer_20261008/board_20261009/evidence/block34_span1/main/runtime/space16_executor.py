"""Six BLOCK34 plus unchanged ten H4/H5 jobs, one fixed HardNPU owner."""
import ctypes as C
import json
import os
from pathlib import Path
from time import perf_counter
import zlib
import numpy as np
from h10_fixed_model_executor import Status, Model, Input, Output, Release, command

ABI = 0x42341910

class Group(C.Structure):
    _fields_ = [('abi', C.c_uint32), ('first', C.c_uint32)]

class Space16Executor:
    def ioctl(self, direction, number, value):
        raw = bytearray(bytes(value))
        self.fcntl.ioctl(self.fd, command(direction, number, type(value)), raw, True)
        return type(value).from_buffer_copy(raw)

    def __init__(self, root, results, mode='product'):
        import fcntl
        self.fcntl = fcntl
        self.root, self.results, self.mode = Path(root), Path(results), mode
        self.results.mkdir(parents=True, exist_ok=False)
        self.jobs = json.loads((self.root / 'combined_jobs.json').read_text())['jobs']
        if len(self.jobs) != 16:
            raise ValueError('Combined fixed model count differs')
        self.slot, self.count, self.starts, self.attempts = 0, 0, 0, 0
        self.blocked, self.last_run, self.fd = False, None, -1
        packets, weights = [], []
        started = perf_counter()
        for i, job in enumerate(self.jobs):
            packet = (self.root / 'combined_assets' / f'packet_{i}.bin').read_bytes()
            weight = (self.root / 'combined_assets' / f'weight_{i}.bin').read_bytes()
            if (len(packet), len(weight)) != (job['packet_bytes'], job['weight_bytes']):
                raise ValueError('Combined fixed asset lengths differ')
            packets.append(packet.ljust(904, b'\xa5'))
            weights.append(weight.ljust(46080, b'\xa5'))
        self.fd = os.open('/dev/space16_span_fixed', os.O_RDWR | os.O_CLOEXEC)
        try:
            state = self.ioctl(2, 0x21, Status(abi=ABI))
            if (state.abi, state.phase, state.writes, state.irq, state.work, state.reserved[3]) != (ABI,0,0,0,0,0):
                raise RuntimeError('Combined fixed owner requires fresh model instance')
            pb, wb = b''.join(packets), b''.join(weights)
            p, w = C.create_string_buffer(pb, len(pb)), C.create_string_buffer(wb, len(wb))
            self.ioctl(1, 0x28, Model(ABI,len(pb),len(wb),0,C.addressof(p),C.addressof(w)))
        except Exception:
            self.close()
            raise
        self.asset_load_ms = (perf_counter()-started)*1000

    def select_group(self, first):
        if self.blocked or self.slot not in (0,6) or first not in (0,6):
            raise RuntimeError('Fixed group switch requires a released boundary')
        self.ioctl(1, 0x29, Group(ABI,first))
        state = self.ioctl(2, 0x21, Status(abi=ABI))
        if (state.abi,state.phase,state.writes,state.irq,state.work,state.reserved[3]) != (ABI,0,0,0,0,1 | (first << 8)):
            self.blocked = True
            raise RuntimeError('Fixed group switch state differs; preserve DMA')
        self.slot = first

    def run_one(self, index, activation=None):
        if self.blocked or self.slot != index:
            raise RuntimeError('Fixed job order differs or previous device failure')
        job = self.jobs[index]
        needs_input = index <= 6 or index == 12
        if needs_input != (activation is not None):
            raise ValueError('Fixed input reuse boundary differs')
        self.blocked = True
        if activation is not None:
            if activation.dtype != np.uint8 or activation.nbytes != job['input_bytes']:
                raise ValueError('Fixed input size/type differs')
            raw = np.ascontiguousarray(activation).tobytes()
            source = C.create_string_buffer(raw,len(raw))
            self.ioctl(1,0x25,Input(ABI,len(raw),C.addressof(source),0,0,0))
        start = perf_counter()
        self.attempts += 1
        try:
            state = self.ioctl(3,0x20,Status(abi=ABI))
        except OSError:
            # Read the same driver's saved status; never resubmit a failed job.
            state = self.ioctl(2,0x21,Status(abi=ABI))
            self.last_run = dict(slot=index,phase=state.phase,writes=state.writes,
                                 reason=state.reason,run_ms=(perf_counter()-start)*1000)
            self.starts += int(state.writes == 8)
            raise
        record = dict(slot=index,phase=state.phase,writes=state.writes,irq=state.irq,
                      work=state.work,guard=state.guard,reason=state.reason,
                      run_ms=(perf_counter()-start)*1000)
        self.last_run = record
        self.starts += int(state.writes == 8)
        if (state.abi,state.phase,state.writes,state.irq,state.work,state.guard,state.reason) != (ABI,3,8,1,5,0,0):
            raise RuntimeError('Combined completion failed: keep module/DMA until physical recovery')
        output = C.create_string_buffer(job['output_bytes'])
        self.ioctl(1,0x22,Output(ABI,job['output_bytes'],C.addressof(output)))
        crc = zlib.crc32(output.raw)
        if crc != state.crc:
            raise RuntimeError('Combined export CRC differs: preserve DMA')
        self.ioctl(1,0x23,Release(ABI,crc))
        cold = self.ioctl(2,0x21,Status(abi=ABI))
        nxt = 0 if index == 5 else 6 if index == 15 else index+1
        has_input = nxt not in (0,1,2,3,4,5,6,12)
        flags = 1 | (2 if has_input else 0) | (nxt << 8)
        if (cold.abi,cold.phase,cold.writes,cold.irq,cold.work,cold.reserved[3]) != (ABI,0,0,0,0,flags):
            raise RuntimeError('Combined release state differs: preserve DMA')
        self.slot, self.blocked = nxt, False
        record['released'] = True
        return output.raw, record

    def expansion(self, activation):
        return self.run_group(activation,6,6,160,960)

    def __call__(self, activation):
        return self.run_group(activation,12,4,960,160)

    def run_group(self, activation, first, count, channels, output_channels):
        if activation.shape != (1,channels,7,7) or activation.dtype != np.uint8:
            raise ValueError('Unchanged H4/H5 group tensor differs')
        started, outputs, records = perf_counter(), [], []
        try:
            for index in range(first,first+count):
                output, record = self.run_one(index,activation if index == first else None)
                outputs.append(output)
                records.append(record)
        finally:
            last = self.last_run
            if self.blocked and last and last.get('slot') not in [r['slot'] for r in records]:
                records.append(last)
            self.last_run = dict(jobs=records,cpu_oracle_calls=0,
                                 run_ioctl_ms=sum(r['run_ms'] for r in records),
                                 client_ms=(perf_counter()-started)*1000)
            if self.mode == 'validate' or self.blocked:
                folder = self.results / f'frame_{self.count:02d}_group_{first}'
                folder.mkdir()
                (folder / 'jobs.json').write_text(json.dumps(self.last_run,indent=2)+'\n')
                for index, raw in enumerate(outputs):
                    (folder / f'output_{first+index}.bin').write_bytes(raw)
        if first == 12:
            self.count += 1
        return np.frombuffer(b''.join(outputs),np.uint8).reshape(1,output_channels,7,7).copy(), 'HARDNPU'

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1
