"""Fixed16 CPU prefix batching with the existing serial FRONT96/BLOCK34 calls."""
import copy
from pathlib import Path
from time import perf_counter
import numpy as np


class Fixed16BatchPrefix:
    def __init__(self,prefix,models):
        if not prefix.fused or not prefix.after.combined:
            raise ValueError('Fixed16 batching requires FRONT96 plus BLOCK34')
        self.prefix=prefix;self.index=0;self.prepared_prefix_ms=0;self.last_run=None
        for session in (prefix.before,prefix.after.before,prefix.after.after):
            if session.get_inputs()[0].shape[0]!=16:
                raise ValueError('Select fixed16 CPU sessions before constructing the prefix')

    def get_inputs(self):return self.prefix.get_inputs()

    def prepare(self,frames,frame_index):
        if frames.shape!=(16,3,224,224) or frames.dtype!=np.float32:
            raise ValueError('Fixed16 batching preserves all sixteen normalized images')
        self.frames=frames;self.index=0
        prefix=self.prefix;block=prefix.after
        begin=perf_counter();cpu_times={};records=[{} for _ in range(16)]
        start=perf_counter()
        value=prefix.before.run(None,{prefix.before.get_inputs()[0].name:frames})[0]
        cpu_times['before_pw96_ms']=(perf_counter()-start)*1000
        if value.shape!=(16,16,112,112) or value.dtype!=np.float32:
            raise ValueError('Fixed16 PW96 CPU input shape differs')
        encoded=[]
        for i in range(16):
            frame_index[0]=i
            start=perf_counter();activation=prefix.pointwise.quantize(value[i:i+1])
            records[i]['pw96_quantize_ms']=(perf_counter()-start)*1000
            start=perf_counter();result=prefix.executor(activation)
            records[i]['front96_ms']=(perf_counter()-start)*1000
            records[i]['front96_device']=copy.deepcopy(prefix.executor.last_run)
            encoded.append(result.copy())
        q=prefix.reference.q
        value=prefix.codec.dequantize(np.concatenate(encoded,axis=0),q['output_scale'],q['output_zero'])
        start=perf_counter();value=block.before.run(None,{block.before.get_inputs()[0].name:value})[0]
        cpu_times['before_block3_ms']=(perf_counter()-start)*1000
        if value.shape!=(16,24,56,56) or value.dtype!=np.float32:
            raise ValueError('Fixed16 BLOCK34 input shape differs')
        domain=block.reference.q['layers'][0]['input'];encoded=[]
        for i in range(16):
            frame_index[0]=i
            start=perf_counter();activation=block.codec.quantize(value[i:i+1],domain['scale'],domain['zero'])
            records[i]['block3_quantize_ms']=(perf_counter()-start)*1000
            start=perf_counter();result=block.executor(activation)
            records[i]['block34_ms']=(perf_counter()-start)*1000
            records[i]['block34_device']=copy.deepcopy(block.executor.last_run)
            encoded.append(result.copy())
        domain=block.block4.reference.q['layers'][-1]['output']
        value=block.codec.dequantize(np.concatenate(encoded,axis=0),domain['scale'],domain['zero'])
        start=perf_counter();self.values=block.after.run(None,{block.after.get_inputs()[0].name:value})
        cpu_times['after_block4_ms']=(perf_counter()-start)*1000
        if len(self.values)!=1 or self.values[0].shape!=(16,160,7,7) or self.values[0].dtype!=np.float32:
            raise ValueError('Fixed16 CPU prefix output shape differs')
        elapsed=(perf_counter()-begin)*1000
        hardware_ms=sum(r['front96_ms']+r['block34_ms'] for r in records)
        self.cpu_mean_ms=(elapsed-hardware_ms)/16
        self.records=records;self.cpu_times=cpu_times
        combined_hard=getattr(block.executor,'backend','').startswith('HARD_PW_')
        self.report=dict(mode='FIXED16_CPU_BATCH_SERIAL_HARD_PW_PL_DW' if combined_hard else 'FIXED16_CPU_BATCH_SERIAL_EXISTING_PL',frames=16,
                         prefix_ms=elapsed,cpu_prefix_ms=elapsed-hardware_ms,
                         cpu_batches=cpu_times,actual_front96_starts=16,actual_block34_starts=0 if combined_hard else 16,
                         frame_timing_scope='CPU batch preparation allocated by frame; PL call timings measured individually')

    def run(self,outputs,inputs):
        i=self.index
        if i>=16:raise ValueError('Fixed16 cached prefix exhausted')
        tensor=inputs[self.get_inputs()[0].name]
        if tensor.shape!=(1,3,224,224) or tensor.ctypes.data!=self.frames[i:i+1].ctypes.data:
            raise ValueError('Fixed16 cached prefix frame order differs')
        row=self.records[i];cpu=self.cpu_times
        self.prepared_prefix_ms=self.cpu_mean_ms+row['front96_ms']+row['block34_ms']
        front_before=cpu['before_pw96_ms']/16+row['pw96_quantize_ms']
        block_before=cpu['before_block3_ms']/16+row['block3_quantize_ms']
        self.last_run=dict(backend='PL_FRONT96',target=self.prefix.reference.q['target'],
            before_ms=front_before,depthwise_ms=row['front96_ms'],
            after_ms=self.prepared_prefix_ms-front_before-row['front96_ms'],
            device=row['front96_device'],tensor_conversion_backend=self.prefix.codec.backend,
            pointwise96=dict(backend='PL_FRONT96',pointwise_ms=None),
            timing_scope='CPU_BATCH16_STAGE_TIME_ALLOCATED_NOT_FRAME_LATENCY',
            block3=dict(backend=getattr(self.prefix.after.executor,'backend','UNKNOWN'),before_ms=block_before,block_ms=row['block34_ms'],
                after_ms=cpu['after_block4_ms']/16,
                device=row['block34_device'],tensor_conversion_backend=self.prefix.after.codec.backend,
                block4=dict(backend=getattr(self.prefix.after.executor,'backend','UNKNOWN'),timing='INCLUDED_IN_BLOCK3_JOB')))
        self.index+=1
        return [v[i:i+1] for v in self.values]
