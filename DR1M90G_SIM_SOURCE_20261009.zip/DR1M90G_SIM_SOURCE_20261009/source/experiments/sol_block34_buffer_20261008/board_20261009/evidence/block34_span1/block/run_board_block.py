"""Run one real saved BLOCK34 boundary; compare only after hardware release."""
import json
import argparse
from pathlib import Path
import numpy as np
from block34_hard_executor import Block34HardExecutor

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pl-dw', action='store_true', help='Requires isolated control ABI0x60002 bit and matching PL driver')
parser.add_argument('--execution-mode', choices=('product', 'validate'), default='validate')
parser.add_argument('--repeat', type=int, choices=(1,3), default=1)
parser.add_argument('--result-dir', default='board_block1')
args = parser.parse_args()
results = root / args.result_dir
pl_dw = None
if args.pl_dw:
    from dw144_executor import DW144Executor
    pl_dw = DW144Executor(root)
executor = Block34HardExecutor(root, results, args.execution_mode, pl_dw=pl_dw)
try:
    activation = np.load(root / 'fixture/input.npy', allow_pickle=False)
    outputs, runs = [], []
    for _ in range(args.repeat):
        outputs.append(executor(activation))
        runs.append(executor.last_run)
    output = outputs[-1]
    np.save(results / 'output.npy', output)
    golden = np.load(root / 'fixture/expected.npy', allow_pickle=False)
    difference = np.stack(outputs).astype(np.int16)-golden.astype(np.int16)
    report = dict(output_shape=list(output.shape), differing=int(np.count_nonzero(difference)),
                  max_abs=int(np.max(np.abs(difference))), timing=executor.last_run,
                  asset_load_ms=executor.asset_load_ms, adopted=False,
                  execution_mode=args.execution_mode, runs=runs,
                  scope='ONE_REAL_BLOCK_BOUNDARY_NOT_FULL_MODEL_QUALITY_OR_SUSTAINED_FPS')
    (results / 'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2), flush=True)
    if report['differing']:
        raise ArithmeticError('BLOCK34 output differs from actual vendor fixed reference')
    print('BLOCK34_HARD_CPU_GAPS_COMPLETE', flush=True)
finally:
    executor.close()
