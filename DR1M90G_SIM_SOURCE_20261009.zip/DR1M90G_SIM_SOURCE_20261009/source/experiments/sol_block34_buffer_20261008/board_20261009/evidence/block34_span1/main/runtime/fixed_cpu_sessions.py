"""Reuse CPU model sessions for one fixed, serial three-window process."""
from pathlib import Path
from time import perf_counter
import onnxruntime as ort


class FixedCpuSessions:
    def __init__(self, cpu_depthwise_library=None):
        self.library = str(Path(cpu_depthwise_library).resolve()) if cpu_depthwise_library else None
        self.options = ort.SessionOptions()
        self.options.intra_op_num_threads = 2
        self.options.log_severity_level = 3
        self.options.add_session_config_entry('session.intra_op.allow_spinning', '0')
        if self.library:
            self.options.register_custom_ops_library(self.library)
        self.sessions = {}
        self.created = self.reused = 0
        self.creation_ms = 0.0

    def check_library(self, library):
        selected = str(Path(library).resolve()) if library else None
        if selected != self.library:
            raise ValueError('three-window CPU reuse requires the same fixed operator library')

    def __call__(self, model, options, providers):
        # Models remain frozen throughout this single process. Nothing is
        # shared across processes and no device executor or DMA buffer is cached.
        if options is not self.options or providers != ['CPUExecutionProvider']:
            raise ValueError('CPU reuse requires its unchanged session options and provider')
        key = str(Path(model).resolve())
        if key in self.sessions:
            self.reused += 1
            return self.sessions[key]
        started = perf_counter()
        session = ort.InferenceSession(key, options, providers=providers)
        self.creation_ms += (perf_counter() - started) * 1000
        self.sessions[key] = session
        self.created += 1
        return session

    def report(self):
        return dict(created=self.created, reused=self.reused, creation_ms=self.creation_ms,
                    scope='FIXED_CPU_ONLY_SESSIONS; NO_DEVICE_OR_FRAME_CACHE')
