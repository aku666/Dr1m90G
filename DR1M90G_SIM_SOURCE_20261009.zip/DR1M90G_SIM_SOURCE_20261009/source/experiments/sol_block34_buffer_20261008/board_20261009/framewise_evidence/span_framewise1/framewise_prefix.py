import copy
from time import perf_counter

class FramewisePrefix:
    def __init__(self,prefix,owner):
        self.prefix=prefix;self.owner=owner;self.records=[];self.last_run=None
        for session in (prefix.before,prefix.after.before,prefix.after.after):
            if session.get_inputs()[0].shape[0]!=1:
                raise ValueError('Framewise execution requires fixed batch1 CPU graphs')
        self.report=dict(mode='FIXED_BATCH1_SERIAL_WHOLE_SPATIAL',frames=0,prefix_ms=0.,actual_front96_starts=0,actual_block34_starts=0)
    def get_inputs(self):return self.prefix.get_inputs()
    def run(self,outputs,inputs):
        self.owner.select_group(0)
        started=perf_counter()
        value=self.prefix.run(outputs,inputs)
        elapsed=(perf_counter()-started)*1000
        self.owner.select_group(6)
        self.last_run=copy.deepcopy(self.prefix.last_run)
        self.records.append(dict(block34_device=copy.deepcopy(self.prefix.after.executor.last_run)))
        self.report['frames']+=1
        self.report['prefix_ms']+=elapsed
        self.report['actual_front96_starts']+=1
        return value
