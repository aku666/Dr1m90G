import base64,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
base=Path('/run/sol_float_dw9_graph1/models')
models=root/'models';models.mkdir(exist_ok=False)
for name,spec in json.loads((root/'batch1_delta.json').read_text()).items():
 raw=(base/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==spec['base_sha256'],name
 value=b''.join(raw[o['copy'][0]:sum(o['copy'])] if 'copy' in o else base64.b64decode(o['literal']) for o in spec['ops'])
 assert hashlib.sha256(value).hexdigest()==spec['sha256']
 (models/name).write_bytes(value)
target=root/'runtime';target.mkdir(exist_ok=False)
source=Path('/run/block34_span1/main/runtime')
for p in source.glob('*.py'):(target/p.name).write_bytes(p.read_bytes())
(target/'framewise_prefix.py').write_bytes((root/'framewise_prefix.py').read_bytes())
p=target/'run_hard_soft_clip.py';s=p.read_text()
a='''        if args.spatial_batch16_models is not None:
            from spatial_batch16 import Fixed16BatchPrefix
            chain.prefix=Fixed16BatchPrefix(chain.prefix,args.spatial_batch16_models)'''
b='''        from framewise_prefix import FramewisePrefix
        chain.prefix=FramewisePrefix(chain.prefix,hard)'''
assert s.count(a)==1;s=s.replace(a,b)
a='''        if args.spatial_batch16_models is not None:
            chain.prefix.prepare(frames,frame_index)
        if args.combined_hard_root is not None:
            hard.select_group(6)  # All sixteen BLOCK34 calls have completed/released.'''
assert s.count(a)==1;s=s.replace(a,'        # Prefix and H4/H5 groups alternate at released boundaries per real frame.')
s=s.replace("report['spatial_batch16']=chain.prefix.report","report['spatial_framewise']=chain.prefix.report")
p.write_bytes(s.encode())
s=Path('/run/block34_span1/main/run_saved_clip.sh').read_text()
s=s.replace('export PYTHONPATH="$root/runtime:', 'export PYTHONPATH="/run/span_framewise1/runtime:$root/runtime:')
s=s.replace('python3 "$root/runtime/run_hard_soft_clip.py"','python3 /run/span_framewise1/runtime/run_hard_soft_clip.py')
s=s.replace('--spatial-batch16-models "$neon/models"','--spatial-batch16-models /run/span_framewise1/models')
s=s.replace('SPACE16_SPAN_REAL_CLIP_COMPLETE','SPACE16_SPAN_FRAMEWISE_COMPLETE')
(root/'run_main.sh').write_bytes(s.encode())
print('FRAMEWISE_RUNTIME_READY_NO_LOAD_NO_START')
