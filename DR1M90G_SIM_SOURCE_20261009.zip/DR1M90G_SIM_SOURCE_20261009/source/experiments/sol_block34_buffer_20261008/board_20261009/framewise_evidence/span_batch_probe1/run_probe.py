import json
from pathlib import Path
from time import perf_counter
import numpy as np
import onnxruntime as ort
root=Path(__file__).resolve().parent
frames=np.load('/run/space16_cached1/normalized_frames.npy',allow_pickle=False)
assert frames.shape==(16,3,224,224) and frames.dtype==np.float32
options=ort.SessionOptions()
options.intra_op_num_threads=2
options.log_severity_level=3
options.add_session_config_entry('session.intra_op.allow_spinning','0')
sessions={n:ort.InferenceSession(str(root/f'before_pw96_b{n}.onnx'),options,providers=['CPUExecutionProvider']) for n in (1,2,4,16)}
reference=sessions[16].run(None,{sessions[16].get_inputs()[0].name:frames})[0]
reports=[]
for batch in (1,2,4,16):
 session=sessions[batch]
 times=[]
 for repeat in range(3):
  started=perf_counter()
  outputs=[session.run(None,{session.get_inputs()[0].name:frames[i:i+batch]})[0] for i in range(0,16,batch)]
  elapsed=(perf_counter()-started)*1000
  times.append(elapsed)
 output=np.concatenate(outputs,axis=0)
 assert output.shape==reference.shape==(16,16,112,112)
 error=float(np.abs(output-reference).max())
 reports.append(dict(batch=batch,whole16_ms=times,median_per_frame_ms=float(np.median(times))/16,max_abs=error,differing=int(np.count_nonzero(output!=reference)),calls_per_window=16//batch))
report=dict(scope='UNCHANGED_FIRST_CPU_STAGE_SAME_REAL16; NOT_FULL_MODEL_FPS_OR_FRAME_LATENCY',weights_nodes_unchanged=True,results=reports)
p=root/'batch_probe.json'
assert not p.exists()
p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
