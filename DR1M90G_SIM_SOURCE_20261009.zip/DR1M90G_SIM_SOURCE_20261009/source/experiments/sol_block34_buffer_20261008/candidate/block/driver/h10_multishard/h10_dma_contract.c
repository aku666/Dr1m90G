/* SPDX-License-Identifier: GPL-2.0 */
#include "h10_dma_contract.h"

static int h10_region_valid(const struct h10_region *region, h10_u32 size)
{
	return region->address != 0 &&
	       !(region->address & (H10_ALIGNMENT - 1u)) &&
	       region->allocated_bytes == size &&
	       region->address <= 0xffffffffULL &&
	       (h10_u64)size - 1u <= 0xffffffffULL - region->address;
}

static int h10_overlap(const struct h10_region *a, const struct h10_region *b)
{
	return a->address < b->address + b->allocated_bytes &&
	       b->address < a->address + a->allocated_bytes;
}

int h10_validate_plan(const struct h10_plan *plan)
{
	const struct h10_region *regions[4];
	h10_u32 i, j;

	if (!plan ||
	    !h10_region_valid(&plan->packet, H10_PACKET_ALLOC_BYTES) ||
	    !h10_region_valid(&plan->input, H10_INPUT_ALLOC_BYTES) ||
	    !h10_region_valid(&plan->weight, H10_WEIGHT_ALLOC_BYTES) ||
	    (!h10_region_valid(&plan->output, H10_OUTPUT_ALLOC_BYTES) &&
     !h10_region_valid(&plan->output, H10_SMALL_OUTPUT_ALLOC_BYTES)))
		return H10_CONTRACT_INVALID;
	regions[0] = &plan->packet;
	regions[1] = &plan->input;
	regions[2] = &plan->weight;
	regions[3] = &plan->output;
	for (i = 0; i < 4u; ++i)
		for (j = i + 1u; j < 4u; ++j)
			if (h10_overlap(regions[i], regions[j]))
				return H10_CONTRACT_INVALID;
	return H10_CONTRACT_OK;
}

int h10_tile_plan(const struct h10_plan *plan, h10_u32 tile,
		 struct h10_tile_addresses *addresses)
{
	h10_u64 packet, weight, output;

	if (!addresses || tile >= H10_TILE_COUNT ||
	    h10_validate_plan(plan) != H10_CONTRACT_OK)
		return H10_CONTRACT_INVALID;
	packet = plan->packet.address + (h10_u64)tile * H10_PACKET_BYTES;
	weight = plan->weight.address + (h10_u64)tile * H10_WEIGHT_TILE_BYTES;
	output = plan->output.address + (h10_u64)tile * H10_OUTPUT_TILE_BYTES;
	if (packet + H10_PACKET_BYTES > plan->packet.address + H10_PACKET_ALLOC_BYTES ||
	    weight + H10_WEIGHT_TILE_BYTES > plan->weight.address + H10_WEIGHT_ALLOC_BYTES ||
	    output + H10_OUTPUT_TILE_BYTES > plan->output.address + H10_OUTPUT_ALLOC_BYTES ||
	    packet > 0xffffffffULL || weight > 0xffffffffULL || output > 0xffffffffULL)
		return H10_CONTRACT_INVALID;
	addresses->packet = (h10_u32)packet;
	addresses->input = (h10_u32)plan->input.address;
	addresses->weight = (h10_u32)weight;
	addresses->output = (h10_u32)output;
	return H10_CONTRACT_OK;
}
