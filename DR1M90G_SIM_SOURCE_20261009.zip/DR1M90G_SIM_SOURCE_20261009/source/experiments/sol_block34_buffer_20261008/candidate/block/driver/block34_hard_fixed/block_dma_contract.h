/* SPDX-License-Identifier: GPL-2.0 */
#ifndef H10_DMA_CONTRACT_H
#define H10_DMA_CONTRACT_H

#ifdef __KERNEL__
#include <linux/types.h>
typedef u32 h10_u32;
typedef u64 h10_u64;
#else
#include <stdint.h>
typedef uint32_t h10_u32;
typedef uint64_t h10_u64;
#endif

#define H10_TILE_COUNT 1u
#define H10_PACKET_WORDS 210u
#define H10_PACKET_BYTES 840u
#define H10_PACKET_ALLOC_BYTES 4096u
#define H10_INPUT_BYTES 153216u
#define H10_INPUT_ALLOC_BYTES 155648u
#define H10_WEIGHT_BYTES 4608u
#define H10_WEIGHT_ALLOC_BYTES 8192u
#define H10_OUTPUT_BYTES 451584u
#define H10_OUTPUT_ALLOC_BYTES 454656u
#define H10_WEIGHT_TILE_BYTES 4608u
#define H10_OUTPUT_TILE_BYTES 451584u
#define H10_ALIGNMENT 4096u
#define H10_SMALL_OUTPUT_ALLOC_BYTES 28672u

enum h10_contract_result {
	H10_CONTRACT_OK = 0,
	H10_CONTRACT_INVALID = -1
};

struct h10_region {
	h10_u64 address;
	h10_u32 allocated_bytes;
};

struct h10_plan {
	struct h10_region packet;
	struct h10_region input;
	struct h10_region weight;
	struct h10_region output;
};

struct h10_tile_addresses {
	h10_u32 packet;
	h10_u32 input;
	h10_u32 weight;
	h10_u32 output;
};

int h10_validate_plan(const struct h10_plan *plan);
int h10_tile_plan(const struct h10_plan *plan, h10_u32 tile,
		 struct h10_tile_addresses *addresses);

#endif
