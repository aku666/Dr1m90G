/* SPDX-License-Identifier: GPL-2.0 */
/* Diagnostic only: eight frozen H10 shards across two frames, one module. */
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "h10_run_uapi.h"
#include "h10_dma_contract.h"
#include "h10_multishard_config.h"

static uint64_t fnv64(const unsigned char *p, size_t n)
{
	uint64_t v = UINT64_C(0xcbf29ce484222325);
	size_t i;
	for (i = 0; i < n; ++i) {
		v ^= p[i];
		v *= UINT64_C(0x100000001b3);
	}
	return v;
}

static uint32_t crc32_bytes(const unsigned char *p, size_t n)
{
	uint32_t crc = ~UINT32_C(0);
	size_t i;
	unsigned int bit;
	for (i = 0; i < n; ++i) {
		crc ^= p[i];
		for (bit = 0; bit < 8; ++bit)
			crc = (crc >> 1) ^ ((crc & 1) ? UINT32_C(0xedb88320) : 0);
	}
	return ~crc;
}

static int read_exact_file(const char *path, unsigned char *p, size_t n)
{
	int fd = open(path, O_RDONLY | O_CLOEXEC);
	size_t at = 0;
	unsigned char extra;
	ssize_t got;
	if (fd < 0) { perror(path); return -1; }
	while (at < n) {
		got = read(fd, p + at, n - at);
		if (got <= 0) { fprintf(stderr, "short read %s\n", path); close(fd); return -1; }
		at += (size_t)got;
	}
	got = read(fd, &extra, 1);
	close(fd);
	if (got != 0) { fprintf(stderr, "bad file size %s\n", path); return -1; }
	return 0;
}

static int save_unique(const char *path, const unsigned char *p, size_t n)
{
	int fd = open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
	size_t at = 0;
	ssize_t written;
	if (fd < 0) { perror(path); return -1; }
	while (at < n) {
		written = write(fd, p + at, n - at);
		if (written <= 0) { perror("write output"); close(fd); return -1; }
		at += (size_t)written;
	}
	if (fsync(fd)) { perror("fsync output"); close(fd); return -1; }
	close(fd);
	return 0;
}

static void print_status(const char *label, const struct h10_run_status *s)
{
	printf("%s phase=%u writes=%u irq=%08x work=%08x crc=%08x guard=%08x reason=%u prework=%08x preirq=%08x polls=%u idle=%08x\n",
		label, s->phase, s->writes_attempted, s->irq_status,
		s->work_status, s->output_crc32, s->integrity_fail_mask,
		s->failure_reason, s->reserved[0], s->reserved[1],
		s->reserved[2], s->reserved[3]);
	fflush(stdout);
}

static int one_job(int fd, unsigned int frame, unsigned int shard)
{
	unsigned char packet[H10_PACKET_BYTES];
	unsigned char weight[H10_WEIGHT_BYTES];
	unsigned char input[H10_INPUT_BYTES];
	unsigned char oracle[H10_RUN_OUTPUT_BYTES];
	unsigned char output[H10_RUN_OUTPUT_BYTES];
	struct h10_run_status status = { .abi_version = H10_RUN_ABI_VERSION };
	struct h10_run_job set = { .abi_version = H10_RUN_ABI_VERSION,
		.packet_bytes = H10_PACKET_BYTES,
		.weight_bytes = H10_WEIGHT_BYTES,
		.input_bytes = H10_INPUT_BYTES };
	struct h10_run_output get = { .abi_version = H10_RUN_ABI_VERSION,
		.bytes = H10_RUN_OUTPUT_BYTES };
	struct h10_run_release release = { .abi_version = H10_RUN_ABI_VERSION };
	char label[96];
	char packet_path[128], weight_path[128], input_path[128];
	char oracle_path[128], output_path[128];
	int good;
	snprintf(label, sizeof(label), "F%u_S%u", frame, shard);
	snprintf(packet_path, sizeof(packet_path), H10_BOARD_DIR "/packet_%u.bin", shard);
	snprintf(weight_path, sizeof(weight_path), H10_BOARD_DIR "/weight_%u.bin", shard);
	snprintf(input_path, sizeof(input_path), H10_BOARD_DIR "/input_f%u.bin", frame);
	snprintf(oracle_path, sizeof(oracle_path), H10_BOARD_DIR "/expected_f%u_s%u.bin", frame, shard);
	snprintf(output_path, sizeof(output_path), H10_BOARD_DIR "/output_f%u_s%u.bin", frame, shard);
	if (read_exact_file(packet_path, packet, sizeof(packet)) ||
	    read_exact_file(weight_path, weight, sizeof(weight)) ||
	    read_exact_file(input_path, input, sizeof(input)) ||
	    read_exact_file(oracle_path, oracle, sizeof(oracle)))
		return -1;
	if (ioctl(fd, H10_IOCTL_STATUS, &status) || status.phase != H10_RUN_COLD ||
	    status.writes_attempted || status.irq_status || status.work_status) {
		fprintf(stderr, "%s not cold before SET_JOB\n", label);
		return -1;
	}
	set.shard_index = shard;
	set.packet_ptr = (uintptr_t)packet;
	set.weight_ptr = (uintptr_t)weight;
	set.input_ptr = (uintptr_t)input;
	set.packet_fnv64 = fnv64(packet, sizeof(packet));
	set.weight_fnv64 = fnv64(weight, sizeof(weight));
	set.input_fnv64 = fnv64(input, sizeof(input));
	set.expected_crc32 = crc32_bytes(oracle, sizeof(oracle));
	if (ioctl(fd, H10_IOCTL_SET_JOB, &set)) { perror("SET_JOB"); return -1; }
	memset(&status, 0, sizeof(status));
	status.abi_version = H10_RUN_ABI_VERSION;
	if (ioctl(fd, H10_IOCTL_RUN, &status)) { perror("RUN"); return -1; }
	snprintf(label, sizeof(label), "F%u_S%u_RUN", frame, shard);
	print_status(label, &status);
	good = status.phase == H10_RUN_DONE_PINNED && status.writes_attempted == 8 &&
	       status.irq_status == 1 && status.work_status == 5 &&
	       !status.integrity_fail_mask && !status.failure_reason &&
	       status.output_crc32 == set.expected_crc32;
	get.user_ptr = (uintptr_t)output;
	if (status.irq_status == 1 && status.work_status == 5) {
		if (ioctl(fd, H10_IOCTL_OUTPUT, &get)) { perror("OUTPUT"); return -1; }
	} else {
		if (ioctl(fd, H10_IOCTL_DIAG_OUTPUT, &get)) {
			perror("DIAG_OUTPUT");
			return -1;
		}
	}
	if (save_unique(output_path, output, sizeof(output))) return -1;
	printf("%s_OUTPUT path=%s expected_crc=%08x actual_crc=%08x equal=%d\n",
		label, output_path, set.expected_crc32,
		crc32_bytes(output, sizeof(output)),
		memcmp(output, oracle, sizeof(output)) == 0);
	fflush(stdout);
	if (!good || memcmp(output, oracle, sizeof(output)))
		return -1; /* Keep module and DMA pinned for diagnosis. */
	release.expected_crc32 = set.expected_crc32;
	if (ioctl(fd, H10_IOCTL_RELEASE, &release)) { perror("RELEASE"); return -1; }
	memset(&status, 0, sizeof(status));
	status.abi_version = H10_RUN_ABI_VERSION;
	if (ioctl(fd, H10_IOCTL_STATUS, &status)) { perror("STATUS after release"); return -1; }
	snprintf(label, sizeof(label), "F%u_S%u_RELEASED", frame, shard);
	print_status(label, &status);
	return status.phase == H10_RUN_COLD && !status.writes_attempted &&
	       !status.irq_status && !status.work_status ? 0 : -1;
}

int main(int argc, char **argv)
{
	int fd, ret = 0;
	unsigned int frame, shard;
	int one = argc == 4 && !strcmp(argv[1], "--confirm-one-start");
	if ((!one && (argc != 2 || strcmp(argv[1], "--confirm-sixteen-starts"))) ||
	    (one && (strlen(argv[2]) != 1 || argv[2][0] < '0' || argv[2][0] > '1' ||
	             strlen(argv[3]) != 1 || argv[3][0] < '0' || argv[3][0] > '7'))) {
		fprintf(stderr, "requires --confirm-sixteen-starts or --confirm-one-start <frame 0..1> <shard 0..7>\n");
		return 2;
	}
	fd = open("/dev/h10_multishard", O_RDWR | O_CLOEXEC);
	if (fd < 0) { perror("open /dev/h10_multishard"); return 1; }
	if (one) {
		ret = one_job(fd, (unsigned int)(argv[2][0] - '0'), (unsigned int)(argv[3][0] - '0'));
	} else {
		for (frame = 0; frame < 2 && !ret; ++frame)
			for (shard = 0; shard < 8 && !ret; ++shard)
				ret = one_job(fd, frame, shard);
	}
	close(fd);
	return ret ? 1 : 0;
}
