/* Six fixed PW jobs, compact rows, unchanged Hard driver lifecycle. */
#define H10_FIXED_MODEL 1
#define H10_FIXED_MODEL_COUNT 6u
#define H10_FIXED_INPUT_PER_JOB 1
#define H10_FIXED_PACKET_BYTES(i) ((i)==0u ? 840u : ((i)==1u ? 360u : ((i)==2u ? 360u : ((i)==3u ? 360u : ((i)==4u ? 840u : 392u)))))
#define H10_FIXED_WEIGHT_BYTES(i) ((i)==0u ? 4608u : ((i)==1u ? 3456u : ((i)==2u ? 3456u : ((i)==3u ? 3456u : ((i)==4u ? 4608u : 4608u)))))
#define H10_FIXED_INPUT_BYTES(i) ((i)==0u ? 100352u : ((i)==1u ? 153216u : ((i)==2u ? 153216u : ((i)==3u ? 145152u : ((i)==4u ? 100352u : 112896u)))))
#define H10_FIXED_OUTPUT_BYTES(i) ((i)==0u ? 451584u : ((i)==1u ? 25536u : ((i)==2u ? 25536u : ((i)==3u ? 24192u : ((i)==4u ? 451584u : 25088u)))))
#include "block_dma_contract.h"
#include "block_run_uapi.h"
#include "block_frozen_config.h"
#define H10_DEVICE_NAME "block34_span_fixed"
#include "../h10_multishard/h10_multishard_main.c"
