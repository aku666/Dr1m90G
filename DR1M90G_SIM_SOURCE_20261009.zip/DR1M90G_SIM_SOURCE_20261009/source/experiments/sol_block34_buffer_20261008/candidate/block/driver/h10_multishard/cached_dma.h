/* Matched Linux 6.1 dma_alloc_noncoherent API; fixed serial ownership. */
static void *fixed_cached_alloc(struct device *dev, size_t bytes,
                               dma_addr_t *address, gfp_t flags)
{
 void *p = dma_alloc_noncoherent(dev, bytes, address, DMA_BIDIRECTIONAL, flags);
 if (p) dma_sync_single_for_cpu(dev, *address, bytes, DMA_BIDIRECTIONAL);
 return p;
}
static void fixed_cached_free(struct device *dev, size_t bytes, void *p,
                              dma_addr_t address)
{
 dma_free_noncoherent(dev, bytes, p, address, DMA_BIDIRECTIONAL);
}
