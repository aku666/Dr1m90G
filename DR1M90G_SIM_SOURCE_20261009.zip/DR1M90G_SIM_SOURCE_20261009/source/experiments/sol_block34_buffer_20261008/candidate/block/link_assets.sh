#!/bin/sh
set -eu
cd /run/block34_span1/block
for n in jobs.json hard_assets fixture libblock34_cpu_gaps.so dw144_executor.py dw16_executor.py dw16_reference.py h10_fixed_model_executor.py block3_dw_params.bin block4_dw_params.bin; do ln -s /run/block34_cached_board1/$n $n; done
