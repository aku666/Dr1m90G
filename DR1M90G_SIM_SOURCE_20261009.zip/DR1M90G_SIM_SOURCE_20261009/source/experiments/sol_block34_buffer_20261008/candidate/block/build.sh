#!/bin/sh
set -eu
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
cd /run/block34_span1/block
make -C /root/softnpu_ddr_v054_target_20260920_1/kernel M="$PWD/driver/block34_hard_fixed" ARCH=arm64 KBUILD_MODPOST_WARN=1 modules > build.log 2>&1
sha256sum driver/block34_hard_fixed/block34_span_fixed.ko
echo SPAN_BLOCK_BUILD_NO_START
