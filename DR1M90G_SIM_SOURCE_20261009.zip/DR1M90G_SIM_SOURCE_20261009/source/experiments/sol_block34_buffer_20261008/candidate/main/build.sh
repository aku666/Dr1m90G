#!/bin/sh
set -eu
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
cd /run/block34_span1/main
make -C /root/softnpu_ddr_v054_target_20260920_1/kernel M="$PWD/driver/space16_fixed" ARCH=arm64 KBUILD_MODPOST_WARN=1 modules > build.log 2>&1
sha256sum driver/space16_fixed/space16_span_fixed.ko
echo SPAN_MAIN_BUILD_NO_START
