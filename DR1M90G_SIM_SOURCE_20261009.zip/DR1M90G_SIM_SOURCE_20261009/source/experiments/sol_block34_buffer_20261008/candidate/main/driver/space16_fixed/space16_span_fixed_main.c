/* Fixed order, one existing HardNPU driver and buffer owner. */
#define H10_FIXED_MODEL 1
#define H10_FIXED_MODEL_COUNT 16u
/* Clear each compact BLOCK34 input and at the two H4/H5 boundaries. */
#define H10_FIXED_INPUT_GROUP_END(i) ((i)<=6u || (i)==12u)
#define H10_FIXED_PACKET_BYTES(i) ((i)==0u ? 840u : ((i)==1u ? 360u : ((i)==2u ? 360u : ((i)==3u ? 360u : ((i)==4u ? 840u : ((i)==5u ? 392u : ((i)==6u ? 904u : ((i)==7u ? 904u : ((i)==8u ? 904u : ((i)==9u ? 904u : ((i)==10u ? 904u : ((i)==11u ? 904u : ((i)==12u ? 456u : ((i)==13u ? 456u : ((i)==14u ? 456u : 328u)))))))))))))))
#define H10_FIXED_WEIGHT_BYTES(i) ((i)==0u ? 4608u : ((i)==1u ? 3456u : ((i)==2u ? 3456u : ((i)==3u ? 3456u : ((i)==4u ? 4608u : ((i)==5u ? 4608u : ((i)==6u ? 25600u : ((i)==7u ? 25600u : ((i)==8u ? 25600u : ((i)==9u ? 25600u : ((i)==10u ? 25600u : ((i)==11u ? 25600u : ((i)==12u ? 46080u : ((i)==13u ? 46080u : ((i)==14u ? 46080u : 15360u)))))))))))))))
#define H10_FIXED_INPUT_BYTES(i) ((i)==0u ? 100352u : ((i)==1u ? 153216u : ((i)==2u ? 153216u : ((i)==3u ? 145152u : ((i)==4u ? 100352u : ((i)==5u ? 112896u : ((i)==6u ? 7840u : ((i)==7u ? 7840u : ((i)==8u ? 7840u : ((i)==9u ? 7840u : ((i)==10u ? 7840u : ((i)==11u ? 7840u : ((i)==12u ? 47040u : ((i)==13u ? 47040u : ((i)==14u ? 47040u : 47040u)))))))))))))))
#define H10_FIXED_OUTPUT_BYTES(i) ((i)==0u ? 451584u : ((i)==1u ? 25536u : ((i)==2u ? 25536u : ((i)==3u ? 24192u : ((i)==4u ? 451584u : ((i)==5u ? 25088u : ((i)==6u ? 7840u : ((i)==7u ? 7840u : ((i)==8u ? 7840u : ((i)==9u ? 7840u : ((i)==10u ? 7840u : ((i)==11u ? 7840u : ((i)==12u ? 2352u : ((i)==13u ? 2352u : ((i)==14u ? 2352u : 784u)))))))))))))))
#include "block_dma_contract.h"
#include "block_run_uapi.h"
#include "block_frozen_config.h"
#define H10_DEVICE_NAME "space16_span_fixed"
#include "../h10_multishard/h10_multishard_main.c"
