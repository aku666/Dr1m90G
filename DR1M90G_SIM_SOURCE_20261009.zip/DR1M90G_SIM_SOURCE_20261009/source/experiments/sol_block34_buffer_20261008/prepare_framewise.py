"""One initialized owner; each real frame goes directly through the full spatial chain."""
from pathlib import Path
import base64,hashlib,io,json,tarfile
import onnx

stage=Path(__file__).resolve().parent
root=stage.parents[1]
specs=json.loads((root/'experiments/sol_cpu_batch16_fix_20261006/batch_model_delta.json').read_text())
sources={}
for name,path in [('cpu_before_pw96_b16.onnx','sol_front_pw96_int16_20261001/assets/cpu_before_pw96.onnx'),('cpu_before_block3_b16.onnx','network_front_block3_20260930/assets/cpu_before_block3.onnx')]:
    spec=specs[name];base=(root/'experiments'/path).read_bytes()
    assert hashlib.sha256(base).hexdigest()==spec['base_sha256']
    raw=b''.join(base[o['copy'][0]:sum(o['copy'])] if 'copy' in o else base64.b64decode(o['literal']) for o in spec['ops'])
    assert hashlib.sha256(raw).hexdigest()==spec['sha256']
    sources[name]=raw
sources['cpu_after_block4_b16.onnx']=(root/'experiments/sol_float_dw9_cpu_20261007/cpu_after_block4_dw9_b16.onnx').read_bytes()

def varint(n):
    data=bytearray()
    while n>127:data.append((n&127)|128);n>>=7
    data.append(n);return bytes(data)

delta={}
for name,raw in sources.items():
    model=onnx.load_from_string(raw)
    frozen_nodes=[n.SerializeToString() for n in model.graph.node]
    frozen_parameters=[p.SerializeToString() for p in model.graph.initializer]
    for v in [*model.graph.input,*model.graph.output,*model.graph.value_info]:
        d=v.type.tensor_type.shape.dim
        if len(d)==4 and d[0].dim_value==16:d[0].dim_value=1
    assert frozen_nodes==[n.SerializeToString() for n in model.graph.node]
    assert frozen_parameters==[p.SerializeToString() for p in model.graph.initializer]
    onnx.checker.check_model(model)
    target=model.SerializeToString()
    weights=b''.join(b'\x2a'+varint(len(p))+p for p in frozen_parameters)
    a=raw.find(weights);b=target.find(weights)
    assert weights and a>=0 and b>=0
    ops=[dict(literal=base64.b64encode(target[:b]).decode()),dict(copy=[a,len(weights)]),dict(literal=base64.b64encode(target[b+len(weights):]).decode())]
    assert b''.join(raw[o['copy'][0]:sum(o['copy'])] if 'copy' in o else base64.b64decode(o['literal']) for o in ops)==target
    delta[name]=dict(base_sha256=hashlib.sha256(raw).hexdigest(),sha256=hashlib.sha256(target).hexdigest(),ops=ops)

runtime=r'''import copy
from time import perf_counter

class FramewisePrefix:
    def __init__(self,prefix,owner):
        self.prefix=prefix;self.owner=owner;self.records=[];self.last_run=None
        for session in (prefix.before,prefix.after.before,prefix.after.after):
            if session.get_inputs()[0].shape[0]!=1:
                raise ValueError('Framewise execution requires fixed batch1 CPU graphs')
        self.report=dict(mode='FIXED_BATCH1_SERIAL_WHOLE_SPATIAL',frames=0,prefix_ms=0.,actual_front96_starts=0,actual_block34_starts=0)
    def get_inputs(self):return self.prefix.get_inputs()
    def run(self,outputs,inputs):
        self.owner.select_group(0)
        started=perf_counter()
        value=self.prefix.run(outputs,inputs)
        elapsed=(perf_counter()-started)*1000
        self.owner.select_group(6)
        self.last_run=copy.deepcopy(self.prefix.last_run)
        self.records.append(dict(block34_device=copy.deepcopy(self.prefix.after.executor.last_run)))
        self.report['frames']+=1
        self.report['prefix_ms']+=elapsed
        self.report['actual_front96_starts']+=1
        return value
'''
restore=r"""import base64,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
base=Path('/run/sol_float_dw9_graph1/models')
models=root/'models';models.mkdir(exist_ok=False)
for name,spec in json.loads((root/'batch1_delta.json').read_text()).items():
 raw=(base/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==spec['base_sha256'],name
 value=b''.join(raw[o['copy'][0]:sum(o['copy'])] if 'copy' in o else base64.b64decode(o['literal']) for o in spec['ops'])
 assert hashlib.sha256(value).hexdigest()==spec['sha256']
 (models/name).write_bytes(value)
target=root/'runtime';target.mkdir(exist_ok=False)
source=Path('/run/block34_span1/main/runtime')
for p in source.glob('*.py'):(target/p.name).write_bytes(p.read_bytes())
(target/'framewise_prefix.py').write_bytes((root/'framewise_prefix.py').read_bytes())
p=target/'run_hard_soft_clip.py';s=p.read_text()
a='''        if args.spatial_batch16_models is not None:
            from spatial_batch16 import Fixed16BatchPrefix
            chain.prefix=Fixed16BatchPrefix(chain.prefix,args.spatial_batch16_models)'''
b='''        from framewise_prefix import FramewisePrefix
        chain.prefix=FramewisePrefix(chain.prefix,hard)'''
assert s.count(a)==1;s=s.replace(a,b)
a='''        if args.spatial_batch16_models is not None:
            chain.prefix.prepare(frames,frame_index)
        if args.combined_hard_root is not None:
            hard.select_group(6)  # All sixteen BLOCK34 calls have completed/released.'''
assert s.count(a)==1;s=s.replace(a,'        # Prefix and H4/H5 groups alternate at released boundaries per real frame.')
s=s.replace("report['spatial_batch16']=chain.prefix.report","report['spatial_framewise']=chain.prefix.report")
p.write_bytes(s.encode())
s=Path('/run/block34_span1/main/run_saved_clip.sh').read_text()
s=s.replace('export PYTHONPATH="$root/runtime:', 'export PYTHONPATH="/run/span_framewise1/runtime:$root/runtime:')
s=s.replace('python3 "$root/runtime/run_hard_soft_clip.py"','python3 /run/span_framewise1/runtime/run_hard_soft_clip.py')
s=s.replace('--spatial-batch16-models "$neon/models"','--spatial-batch16-models /run/span_framewise1/models')
s=s.replace('SPACE16_SPAN_REAL_CLIP_COMPLETE','SPACE16_SPAN_FRAMEWISE_COMPLETE')
(root/'run_main.sh').write_bytes(s.encode())
print('FRAMEWISE_RUNTIME_READY_NO_LOAD_NO_START')
"""
files={'batch1_delta.json':json.dumps(delta).encode(),'framewise_prefix.py':runtime.encode(),'restore.py':restore.encode()}
for name,data in files.items():
    if name.endswith('.py'):compile(data,name,'exec')
with tarfile.open(stage/'framewise1.tgz','w:gz') as archive:
    for name,data in files.items():
        m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;archive.addfile(m,io.BytesIO(data))
p=stage/'framewise1.tgz'
print(p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
