"""Measure unchanged first CPU stage at fixed batch1/2/4, using real16."""
import base64
import hashlib
import io
import json
from pathlib import Path
import tarfile
import onnx

stage=Path(__file__).resolve().parent
root=stage.parents[1]
spec=json.loads((root/'experiments/sol_cpu_batch16_fix_20261006/batch_model_delta.json').read_text())['cpu_before_pw96_b16.onnx']
base=(root/'experiments/sol_front_pw96_int16_20261001/assets/cpu_before_pw96.onnx').read_bytes()
assert hashlib.sha256(base).hexdigest()==spec['base_sha256']
raw=b''.join(base[o['copy'][0]:sum(o['copy'])] if 'copy' in o else base64.b64decode(o['literal']) for o in spec['ops'])
assert hashlib.sha256(raw).hexdigest()==spec['sha256']
source=onnx.load_from_string(raw)
files={}
for batch in (1,2,4,16):
    model=onnx.load_from_string(raw)
    for value in [*model.graph.input,*model.graph.output,*model.graph.value_info]:
        dims=value.type.tensor_type.shape.dim
        if len(dims)==4 and dims[0].dim_value==16:
            dims[0].dim_value=batch
    assert [n.SerializeToString() for n in model.graph.node]==[n.SerializeToString() for n in source.graph.node]
    assert [v.SerializeToString() for v in model.graph.initializer]==[v.SerializeToString() for v in source.graph.initializer]
    onnx.checker.check_model(model)
    files[f'before_pw96_b{batch}.onnx']=model.SerializeToString()
files['run_probe.py']=b'''import json
from pathlib import Path
from time import perf_counter
import numpy as np
import onnxruntime as ort
root=Path(__file__).resolve().parent
frames=np.load('/run/space16_cached1/normalized_frames.npy',allow_pickle=False)
assert frames.shape==(16,3,224,224) and frames.dtype==np.float32
options=ort.SessionOptions()
options.intra_op_num_threads=2
options.log_severity_level=3
options.add_session_config_entry('session.intra_op.allow_spinning','0')
sessions={n:ort.InferenceSession(str(root/f'before_pw96_b{n}.onnx'),options,providers=['CPUExecutionProvider']) for n in (1,2,4,16)}
reference=sessions[16].run(None,{sessions[16].get_inputs()[0].name:frames})[0]
reports=[]
for batch in (1,2,4,16):
 session=sessions[batch]
 times=[]
 for repeat in range(3):
  started=perf_counter()
  outputs=[session.run(None,{session.get_inputs()[0].name:frames[i:i+batch]})[0] for i in range(0,16,batch)]
  elapsed=(perf_counter()-started)*1000
  times.append(elapsed)
 output=np.concatenate(outputs,axis=0)
 assert output.shape==reference.shape==(16,16,112,112)
 error=float(np.abs(output-reference).max())
 reports.append(dict(batch=batch,whole16_ms=times,median_per_frame_ms=float(np.median(times))/16,max_abs=error,differing=int(np.count_nonzero(output!=reference)),calls_per_window=16//batch))
report=dict(scope='UNCHANGED_FIRST_CPU_STAGE_SAME_REAL16; NOT_FULL_MODEL_FPS_OR_FRAME_LATENCY',weights_nodes_unchanged=True,results=reports)
p=root/'batch_probe.json'
assert not p.exists()
p.write_text(json.dumps(report,indent=2)+'\\n')
print(json.dumps(report,indent=2),flush=True)
'''
compile(files['run_probe.py'],'run_probe.py','exec')
with tarfile.open(stage/'batch_probe1.tgz','w:gz') as archive:
    for name,data in files.items():
        info=tarfile.TarInfo(name)
        info.size=len(data)
        info.mode=0o644
        archive.addfile(info,io.BytesIO(data))
p=stage/'batch_probe1.tgz'
print(p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
