#!/bin/sh
# After qualified volatile bit/DTB/80MHz startup; invoke in a child shell.
# Restores files only: no insmod, START, flash, or persistent root changes.
set -eu
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
usb=${1:-/run/camera_usb}
saved=$usb/BLOCK34_SPAN_20261009_1
test -z "$(cat /proc/modules)"
test ! -e /run/block34_span1
for n in block34_span_input1.tgz span_resume1.tgz span_compiled1.tgz span_framewise1.tgz; do
 test -s "$saved/$n"
done
if test ! -d /run/camera_pw32_20261006_1; then
 sh "$usb/SOL_CAMERA_PW32_20261006_1/setup_linux.sh"
fi
if test ! -d /run/sol_float_dw9_graph1; then
 sh "$usb/CAMERA_SPEED_DSI_20261007_1/float_dw9_cpu_stage/restore_cpu_dw9.sh"
fi
if test ! -d /run/space16_cached1; then
 mkdir /run/space16_cached1
 for n in candidate1.tgz compiled1.tgz runtime_fix2.tgz; do
  tar --warning=no-timestamp -xzf "$usb/SPACE16_CACHED_20261008_1/$n" -C /run/space16_cached1
 done
 tar xzOf "$usb/CAMERA_SPEED_DSI_20261007_1/headless_stage/board_evidence_1.tgz" headless_copy16_1/capture/normalized_frames.npy > /run/space16_cached1/normalized_frames.npy
fi
if test ! -d /run/block34_cached_board1; then
 mkdir /run/block34_cached_board1
 for n in block34_cached_candidate1.tgz cached_dma_compiled1.tgz; do
  tar --warning=no-timestamp -xzf "$usb/BLOCK34_CACHED_20261008_1/$n" -C /run/block34_cached_board1
 done
 cp /run/space16_cached1/libblock34_cpu_gaps.so /run/block34_cached_board1/
fi
mkdir /run/block34_span1
tar xzf "$saved/block34_span_input1.tgz" -C /run/block34_span1
tar --warning=no-timestamp -xzf "$saved/span_compiled1.tgz" -C /run/block34_span1
tar xzf "$saved/span_resume1.tgz" -C /run
sh /run/block34_span1/block/link_assets.sh
sh /run/resume_runtime.sh
mkdir /run/span_framewise1
tar xzf "$saved/span_framewise1.tgz" -C /run/span_framewise1
python3 /run/span_framewise1/restore.py
python3 /run/space16_cached1/disable_dsi.py
echo SPAN_FILES_RESTORED_NO_LOAD_NO_START
