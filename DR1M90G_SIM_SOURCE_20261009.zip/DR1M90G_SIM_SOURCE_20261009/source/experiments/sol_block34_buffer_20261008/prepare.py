"""Fixed input maximum and two genuine output allocations, same DMA checks."""
from pathlib import Path
import hashlib,io,json,shutil,tarfile
stage=Path(__file__).resolve().parent;root=stage.parents[1];out=stage/'candidate';out.mkdir(exist_ok=False)
block=root/'experiments/sol_block34_cached_20261008/board_candidate'
main=root/'experiments/sol_block34_cached_main_20261008'
def prepare_driver(source,target,folder,oldname,newname,oldabi,newabi,jobs):
 assert max(j['input_bytes'] for j in jobs)==153216
 assert max(j['output_bytes'] for j in jobs)==451584
 assert max(j['output_bytes'] for j in jobs if j['output_bytes']<451584)==25536
 shutil.copytree(source/'driver',target/'driver')
 d=target/'driver'/folder
 p=d/'block_dma_contract.h';s=p.read_text().replace('H10_INPUT_BYTES 451584u','H10_INPUT_BYTES 153216u').replace('H10_INPUT_ALLOC_BYTES 454656u','H10_INPUT_ALLOC_BYTES 155648u')
 s=s.replace('#define H10_ALIGNMENT 4096u','#define H10_ALIGNMENT 4096u\n#define H10_SMALL_OUTPUT_ALLOC_BYTES 28672u')
 p.write_bytes(s.encode())
 p=d/'block_run_uapi.h';s=p.read_text();assert oldabi in s;p.write_bytes(s.replace(oldabi,newabi).encode())
 p=d/(oldname+'_main.c');s=p.read_text().replace('"'+oldname+'"','"'+newname+'"');p.unlink();(d/(newname+'_main.c')).write_bytes(s.encode())
 p=d/'Makefile';s=p.read_text().replace(oldname,newname);p.write_bytes(s.encode())
 p=target/'driver/h10_multishard/h10_multishard_main.c';s=p.read_text()
 s=s.replace('struct h10_buffer buffer[H10_BUFFER_COUNT];','struct h10_buffer buffer[H10_BUFFER_COUNT];\n struct h10_buffer small_output;')
 at=s.index('static u64 h10_fnv64(')
 s=s[:at]+'''/* All jobs and payload lengths are frozen by this module, not user addresses. */
static struct h10_buffer *h10_output_buffer(struct h10_diag_state *s)
{
 if (H10_FIXED_OUTPUT_BYTES(s->shard_index) <= H10_SMALL_OUTPUT_ALLOC_BYTES && s->small_output.cpu)
  return &s->small_output;
 return &s->buffer[H10_BUFFER_OUTPUT];
}

'''+s[at:]
 # Change only active output accesses, not the base buffer ownership/free loop.
 s=s.replace('state->buffer[H10_BUFFER_OUTPUT].cpu','h10_output_buffer(state)->cpu')
 s=s.replace('state->buffer[H10_BUFFER_OUTPUT].dma','h10_output_buffer(state)->dma')
 s=s.replace('state->buffer[H10_BUFFER_OUTPUT].size','h10_output_buffer(state)->size')
 s=s.replace('plan->output.allocated_bytes = H10_OUTPUT_ALLOC_BYTES;', 'plan->output.allocated_bytes = h10_output_buffer(state)->size;')
 s=s.replace('plan.output.allocated_bytes = H10_OUTPUT_ALLOC_BYTES;', 'plan.output.allocated_bytes = h10_output_buffer(state)->size;')
 # Every active output byte, including all its guard, remains maintained.
 s=s.replace('H10_OUTPUT_ALLOC_BYTES -','h10_output_buffer(state)->size -')
 s=s.replace('0xa5, H10_OUTPUT_ALLOC_BYTES);','0xa5, h10_output_buffer(state)->size);')
 s=s.replace('       H10_OUTPUT_ALLOC_BYTES);','       h10_output_buffer(state)->size);')
 a='''  if (device) dma_sync_single_for_device(dev, s->buffer[i].dma, s->buffer[i].size, DMA_BIDIRECTIONAL);
  else dma_sync_single_for_cpu(dev, s->buffer[i].dma, s->buffer[i].size, DMA_BIDIRECTIONAL);'''
 b='''  struct h10_buffer *b = i == H10_BUFFER_OUTPUT ? h10_output_buffer(s) : &s->buffer[i];
  if (device) dma_sync_single_for_device(dev, b->dma, b->size, DMA_BIDIRECTIONAL);
  else dma_sync_single_for_cpu(dev, b->dma, b->size, DMA_BIDIRECTIONAL);'''
 assert a in s;s=s.replace(a,b)
 at=s.index('\tfor (i = H10_BUFFER_COUNT - 1; i >= 0; --i)')
 s=s[:at]+''' if (state->small_output.cpu) {
  fixed_cached_free(dev,state->small_output.size,state->small_output.cpu,state->small_output.dma);
  state->small_output.cpu = NULL;
 }
'''+s[at:]
 at=s.index('\tplan.packet.address =',s.index('static int h10_probe_impl('))
 s=s[:at]+''' state->small_output.size = H10_SMALL_OUTPUT_ALLOC_BYTES;
 state->small_output.cpu = fixed_cached_alloc(&pdev->dev,state->small_output.size,&state->small_output.dma,GFP_KERNEL);
 if (!state->small_output.cpu) {ret=-ENOMEM;goto err_release;}
 memset(state->small_output.cpu,0xa5,state->small_output.size);
'''+s[at:]
 p.write_bytes(s.encode())
 p=target/'driver/h10_multishard/h10_fixed_model.inc';s=p.read_text().replace('s->buffer[H10_BUFFER_OUTPUT].cpu','h10_output_buffer(s)->cpu').replace('H10_OUTPUT_ALLOC_BYTES-','h10_output_buffer(s)->size-')
 a='''  h10_fill_plan(s,&plan);''';assert a in s
 s=s.replace(a,'  s->shard_index = i;\n'+a)
 p.write_bytes(s.encode())
 p=target/'driver/h10_multishard/h10_dma_contract.c';s=p.read_text()
 a='!h10_region_valid(&plan->output, H10_OUTPUT_ALLOC_BYTES)'
 b='(!h10_region_valid(&plan->output, H10_OUTPUT_ALLOC_BYTES) &&\n     !h10_region_valid(&plan->output, H10_SMALL_OUTPUT_ALLOC_BYTES))'
 assert s.count(a)==1;s=s.replace(a,b);p.write_bytes(s.encode())
 # Only tile0 is used by these unchanged captured packets; this helper is not called.
 return dict(abi=newabi,input_max=153216,input_alloc=155648,large_output_alloc=454656,small_output_alloc=28672,
  output_slots={str(i):454656 if j['output_bytes']>28672 else 28672 for i,j in enumerate(jobs)},driver=newname)

reports={}
for label,src,folder,oldname,newname,oldabi,newabi in [
 ('block',block,'block34_hard_fixed','block34_hard_fixed','block34_span_fixed','0x42343300','0x42343410'),
 ('main',main,'space16_fixed','space16_fixed','space16_span_fixed','0x42341610','0x42341910')]:
 target=out/label;target.mkdir();jobs=json.loads((src/('jobs.json' if label=='block' else 'combined_jobs.json')).read_text())['jobs']
 reports[label]=prepare_driver(src,target,folder,oldname,newname,oldabi,newabi,jobs)
 if label=='block':
  for n in ['block34_hard_executor.py','run_board_block.py']:
   s=(src/n).read_text().replace(oldabi,newabi).replace('/dev/'+oldname,'/dev/'+newname)
   (target/n).write_bytes(s.encode())
  # Dependencies and frozen assets are reused from the actual passed board package.
  (target/'link_assets.sh').write_bytes(b'''#!/bin/sh
set -eu
cd /run/block34_span1/block
for n in jobs.json hard_assets fixture libblock34_cpu_gaps.so dw144_executor.py dw16_executor.py dw16_reference.py h10_fixed_model_executor.py block3_dw_params.bin block4_dw_params.bin; do ln -s /run/block34_cached_board1/$n $n; done
''')
 else:
  runtime=target/'runtime';runtime.mkdir()
  s=(src/'runtime/space16_executor.py').read_text().replace(oldabi,newabi).replace('/dev/'+oldname,'/dev/'+newname)
  (runtime/'space16_executor.py').write_bytes(s.encode())
  shutil.copyfile(src/'combined_jobs.json',target/'combined_jobs.json')
  spec=json.loads((target/'combined_jobs.json').read_text());spec['abi']=newabi
  (target/'combined_jobs.json').write_bytes((json.dumps(spec,indent=2)+'\n').encode())
 # Build in this isolated package, using the already matched board kernel.
 (target/'build.sh').write_bytes(f'''#!/bin/sh
set -eu
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
cd /run/block34_span1/{label}
make -C /root/softnpu_ddr_v054_target_20260920_1/kernel M="$PWD/driver/{folder}" ARCH=arm64 KBUILD_MODPOST_WARN=1 modules > build.log 2>&1
sha256sum driver/{folder}/{newname}.ko
echo SPAN_{label.upper()}_BUILD_NO_START
'''.encode())
(out/'preparation.json').write_bytes((json.dumps(reports,indent=2)+'\n').encode())
files={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for n,v in files.items():
 if n.endswith('.py'):compile(v,n,'exec')
files['inputs.sha256']=''.join(hashlib.sha256(v).hexdigest()+'  '+n+'\n' for n,v in sorted(files.items())).encode()
with tarfile.open(stage/'input1.tgz','w:gz') as a:
 for n,v in files.items():
  m=tarfile.TarInfo(n);m.size=len(v);m.mode=0o644;a.addfile(m,io.BytesIO(v))
p=stage/'input1.tgz';report=dict(scope='FIXED_BLOCK34_BUFFER_CODED',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),config=reports,board='NOT_RUN',model_math_changed=False,bit_changed=False)
(stage/'preparation.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report,indent=2))
