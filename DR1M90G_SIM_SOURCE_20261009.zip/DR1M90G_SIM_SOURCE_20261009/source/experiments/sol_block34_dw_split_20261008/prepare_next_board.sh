#!/bin/sh
# Restore files only, after physical recovery and qualified temporary setup.
set -eu
usb=${1:?supply mounted read-only USB path}
previous=4528d917-6db5-4411-99ee-0a8d3fba5a29
test "$(cat /proc/sys/kernel/random/boot_id)" != "$previous"
test -z "$(cat /proc/modules)"
grep -q 'init=/bin/bash' /proc/cmdline
package=$usb/BLOCK34_HARD_20261008_1
patch=/run/block34_runtime_fix2
test ! -e "$patch"
mkdir "$patch"
tar xzf "$package/runtime_fix2.tgz" -C "$patch"
sh "$patch/restore_after_cold.sh" "$usb" "$patch"
root=/run/block34_hard_board2
sh "$patch/overlay.sh" "$root"
mkdir "$root/pl_driver" "$root/gap_fixture"
tar xzf "$package/dw_driver_compiled1.tgz" -C "$root/pl_driver"
test "$(sha256sum "$root/pl_driver/net_pl.ko" | cut -d ' ' -f 1)" = f25f240e8e3c039013901115dc4e4a27cc0b75cbd35cb8f2d60b9fe51001dc59
tar xzf "$package/cpu_gap_check.tgz" -C "$root/gap_fixture"
cp "$package/run_board_dw.py" "$root/"
echo DW_SPLIT_NEXT_BOARD_FILES_READY_NO_LOAD_NO_START
