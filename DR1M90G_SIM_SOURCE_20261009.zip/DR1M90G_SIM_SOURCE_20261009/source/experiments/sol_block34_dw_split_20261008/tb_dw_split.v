`timescale 1ns/1ps
module tb_dw_split;
 reg clk=0; always #5 clk=~clk;
 reg resetn=0,start=0;
 reg [1:0] mode=1;
 wire busy,done,fault;
 wire [31:0] araddr,awaddr;
 wire [7:0] arlen,awlen,wstrb;
 wire [2:0] arsize,awsize;
 wire [1:0] arburst,awburst;
 wire arvalid,arready,rready,awvalid,awready,wvalid,wready,wlast,bready;
 wire [63:0] wdata;
 reg [63:0] rdata;
 reg rvalid=0,rlast=0,bvalid=0;
 reg [7:0] memory[0:2097151],gold3[0:451583],gold4[0:129023];
 reg reading=0,writing=0;
 integer ra,wa,read_left,write_left,delay=0,cycles=0,responses=0,reads=0,writes=0,i,j,index;
 integer copied=0,expected_bytes,begin_cycles,begin_responses,begin_writes;
 assign arready=!reading && !rvalid && cycles%5!=0;
 assign awready=!writing && !bvalid && delay==0 && cycles%3!=0;
 assign wready=writing && cycles%4!=0;
 block34_axi_chain dut(.clk(clk),.resetn(resetn),.start(start),.dw_only_mode(mode),
  .input_base(32'h1000),.expand_parameters(32'h80000),.depthwise_parameters(32'h80000),.project_parameters(32'h80000),
  .scratch_expand(32'h1000),.scratch_depthwise(32'h90000),.output_base(32'h90000),
  .busy(busy),.done(done),.fault(fault),
  .araddr(araddr),.arlen(arlen),.arsize(arsize),.arburst(arburst),.arvalid(arvalid),.arready(arready),
  .rdata(rdata),.rresp(2'b00),.rlast(rlast),.rvalid(rvalid),.rready(rready),
  .awaddr(awaddr),.awlen(awlen),.awsize(awsize),.awburst(awburst),.awvalid(awvalid),.awready(awready),
  .wdata(wdata),.wstrb(wstrb),.wlast(wlast),.wvalid(wvalid),.wready(wready),.bresp(2'b00),.bvalid(bvalid),.bready(bready));
 function read_allowed;
 input integer at,count;
 begin read_allowed=(at>='h1000 && at+count<='h6f400) || (at>='h80000 && at+count<='h81200); end
 endfunction
 always @(posedge clk) begin
  cycles<=cycles+1;
  if(dut.pw_arvalid || dut.pw_awvalid || dut.pw_wvalid)$fatal(1,"DW-only launched PW traffic");
  if(arvalid && arready)begin
   if(arsize!=3 || arburst!=1 || arlen>15 || araddr[2:0]!=0 || ({1'b0,araddr[11:0]}+(arlen+1)*8)>4096 || !read_allowed(araddr,(arlen+1)*8))$fatal(1,"DW split read range");
   ra<=araddr;read_left<=arlen+1;reading<=1;reads<=reads+1;
  end
  if(reading && !rvalid)begin
   for(j=0;j<8;j=j+1)rdata[j*8+:8]<=memory[ra+j];
   rlast<=read_left==1;rvalid<=1;
  end
  if(rvalid && rready)begin rvalid<=0;ra<=ra+8;read_left<=read_left-1;if(rlast)reading<=0;end
  if(awvalid && awready)begin
   if(awsize!=3 || awburst!=1 || awlen>15 || awaddr[2:0]!=0 || ({1'b0,awaddr[11:0]}+(awlen+1)*8)>4096 || awaddr<'h90000 || awaddr+(awlen+1)*8>'h90000+expected_bytes)$fatal(1,"DW split write range");
   wa<=awaddr;write_left<=awlen+1;writing<=1;writes<=writes+1;
  end
  if(wvalid && wready)begin
   if(wstrb!=8'hff)$fatal(1,"DW split WSTRB");
   for(j=0;j<8;j=j+1)begin
    index=wa+j-'h90000;
    if(wdata[j*8+:8] !== (mode==1?gold3[index]:gold4[index]))$fatal(1,"DW split mismatch mode=%0d index=%0d",mode,index);
    memory[wa+j]<=wdata[j*8+:8];
   end
   copied<=copied+8;
   if(wlast!=(write_left==1))$fatal(1,"DW split WLAST");
   wa<=wa+8;write_left<=write_left-1;
   if(wlast)begin writing<=0;delay<=4;end
  end
  if(delay>0)begin delay<=delay-1;if(delay==1)bvalid<=1;end
  if(bvalid && bready)begin bvalid<=0;responses<=responses+1;end
  if(done && (reading || rvalid || writing || bvalid || delay!=0 || responses!=writes))$fatal(1,"DW split done before drain/final B");
  if(fault)$fatal(1,"DW split fault");
 end
 initial begin
  for(i=0;i<2097152;i=i+1)memory[i]=8'ha5;
  $readmemh("fixture/gold3.hex",gold3);$readmemh("fixture/gold4.hex",gold4);
  repeat(3)@(negedge clk);resetn=1;
  for(mode=1;mode<=2;mode=mode+1'b1)begin
   if(mode==1)begin
    $readmemh("fixture/input3.hex",memory,'h1000,'h6f3ff);
    $readmemh("fixture/parameters3.hex",memory,'h80000,'h811ff);
    expected_bytes=451584;
   end else begin
    $readmemh("fixture/input4.hex",memory,'h1000,'h6f3ff);
    $readmemh("fixture/parameters4.hex",memory,'h80000,'h811ff);
    expected_bytes=129024;
   end
   copied=0;begin_cycles=cycles;begin_responses=responses;begin_writes=writes;
   @(negedge clk);start=1;@(negedge clk);start=0;
   wait(busy);wait(done);@(negedge clk);
   if(copied!=expected_bytes || responses-begin_responses!=writes-begin_writes)$fatal(1,"DW split final bytes/responses");
   $display("DW_SPLIT_REAL_PASS mode=%0d bytes=%0d cycles=%0d writes=%0d final_b=%0d",mode,copied,cycles-begin_cycles,writes-begin_writes,responses-begin_responses);
   repeat(3)@(negedge clk);
  end
  $display("DW_SPLIT_SHARED_CORE_SERIAL_PASS_NO_NEW_ENGINE");$finish;
 end
 initial begin #200000000;$fatal(1,"DW split timeout");end
endmodule
