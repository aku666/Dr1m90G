SWNS: 0.108ns, STNS: 0.000ns.
HWNS: -0.790ns, HTNS: -0.790ns.
