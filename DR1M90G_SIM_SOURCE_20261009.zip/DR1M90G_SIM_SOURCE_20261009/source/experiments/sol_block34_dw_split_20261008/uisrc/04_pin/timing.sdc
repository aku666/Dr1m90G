create_clock -name sysclk -period 10 -waveform {0 5} [get_ports {I_sysclk}]
 
derive_pll_clocks
 
rename_clock -name {clk_24m} -source [get_ports {I_sysclk}] -master_clock {sysclk} [get_pins {camera/U_pll/dr1_phy_pll_bb3f286c4695_Inst/u_DR1_PHY_PLL.clkc[5]}]
rename_clock -name {clk_70m} -source [get_ports {I_sysclk}] -master_clock {sysclk} [get_pins {camera/U_pll/dr1_phy_pll_bb3f286c4695_Inst/u_DR1_PHY_PLL.clkc[6]}]
