# The Command Lines that defined the parameter attributes.

set_param -param_id {M_AXI_B2B_SET} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {M_AXI_ID_WIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {M_AXI_ID} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {M_AXI_ADDR_WIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {M_AXI_DATA_WIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {M_AXI_MAX_BURST_LEN} -data_type {Integer} -min {-2147483648} -max {2147483647}
# The Tcl Procs that used in parameter dependency.

proc updateRelValue { value } {
 set tmp $value
 return $tmp
}