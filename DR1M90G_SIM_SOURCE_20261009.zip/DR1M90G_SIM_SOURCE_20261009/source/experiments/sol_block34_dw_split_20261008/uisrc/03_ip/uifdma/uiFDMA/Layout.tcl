# The Command Lines that defined the layout and widget properties.

set Tab_Tab_0 [add_tab -name {Tab_0} -col_count {1}]

set Spin_Box_M_AXI_B2B_SET [add_param -parent {Tab_0} -name {M_AXI_B2B_SET} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_M_AXI_B2B_SET -prop {Display Name} -value {M_AXI_B2B_SET}

set Spin_Box_M_AXI_ID_WIDTH [add_param -parent {Tab_0} -name {M_AXI_ID_WIDTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_M_AXI_ID_WIDTH -prop {Display Name} -value {M_AXI_ID_WIDTH}

set Spin_Box_M_AXI_ID [add_param -parent {Tab_0} -name {M_AXI_ID} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_M_AXI_ID -prop {Display Name} -value {M_AXI_ID}

set Spin_Box_M_AXI_ADDR_WIDTH [add_param -parent {Tab_0} -name {M_AXI_ADDR_WIDTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_M_AXI_ADDR_WIDTH -prop {Display Name} -value {M_AXI_ADDR_WIDTH}

set Spin_Box_M_AXI_DATA_WIDTH [add_param -parent {Tab_0} -name {M_AXI_DATA_WIDTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_M_AXI_DATA_WIDTH -prop {Display Name} -value {M_AXI_DATA_WIDTH}

set Spin_Box_M_AXI_MAX_BURST_LEN [add_param -parent {Tab_0} -name {M_AXI_MAX_BURST_LEN} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_M_AXI_MAX_BURST_LEN -prop {Display Name} -value {M_AXI_MAX_BURST_LEN}