/*****************************************************************
Company : MiLianKe Electronic Technology Co., Ltd.
WebSite:https://www.milianke.com
TechWeb:https://www.uisrc.com
tmall-shop:https://milianke.tmall.com
jd-shop:https://milianke.jd.com
taobao-shop: https://milianke.taobao.com
Description: 
The reference demo provided by Milianke is only used for learning. 
We cannot ensure that the demo itself is free of bugs, so users 
should be responsible for the technical problems and consequences
caused by the use of their own products.
@Author      :   XiaoQingquan 
@Time        :   2024/08/23 
version:     :   1.0
@Description :   ISP  gamma(٤������)
*****************************************************************/
`timescale 1ns / 1ps
module gamma #(
    parameter [4:0] GAMMA_10x = 22 // ٤��ֵ��ʮ����Ĭ��ֵΪ22����٤��ֵΪ2.2
)
(
    input                   I_clk  ,    // ʱ���ź�
    input                   I_rst_n,    // ��λ�źţ��͵�ƽ��Ч

    input                   I_tlast     , // ��������ͨ�������һ����Ч�ź�
    input                   I_tuser     , // ��������ͨ���ĵ�һ����Ч�ź�
    input [95:0]            I_tdata     , // �������ݣ��ܹ�96λ��ÿ24λ��ʾһ�����ص�RGB����
    input                   I_tvalid    , // ����������Ч�ź�
    output                  I_tready    , // ��������׼�����ź�

    output                  O_tlast     , // �������ͨ�������һ����Ч�ź�
    output                  O_tuser     , // �������ͨ���ĵ�һ����Ч�ź�
    output [95:0]           O_tdata     , // ������ݣ��ܹ�96λ��ÿ24λ��ʾһ�����ص�RGB����
    output                  O_tvalid    , // ���������Ч�ź�
    input                   O_tready      // �������׼�����ź�
);

/*****************************************************************
                        �������96λ���ݷֽ�Ϊ4�����ص�RGB888��ʽ                                        
*****************************************************************/

    wire [23:0] I_tdata_r1 = I_tdata[23:0] ;     // ��1�����ص�����
    wire [23:0] I_tdata_r2 = I_tdata[47:24];     // ��2�����ص�����
    wire [23:0] I_tdata_r3 = I_tdata[71:48];     // ��3�����ص�����
    wire [23:0] I_tdata_r4 = I_tdata[95:72];     // ��4�����ص�����

    wire [7:0]  rgb888_r[3:0];                   // �������飬�洢4�����ص�R����
    wire [7:0]  rgb888_g[3:0];                   // �������飬�洢4�����ص�G����
    wire [7:0]  rgb888_b[3:0];                   // �������飬�洢4�����ص�B����

    // ��ȡ��1�����ص�RGB����
    assign   rgb888_r[0] = I_tdata_r1[16+:8];    // R��������8λ
    assign   rgb888_g[0] = I_tdata_r1[8+:8] ;    // G��������8λ
    assign   rgb888_b[0] = I_tdata_r1[0+:8] ;    // B��������8λ

    // ��ȡ��2�����ص�RGB����
    assign   rgb888_r[1] = I_tdata_r2[16+:8];
    assign   rgb888_g[1] = I_tdata_r2[8+:8] ;
    assign   rgb888_b[1] = I_tdata_r2[0+:8] ;

    // ��ȡ��3�����ص�RGB����
    assign   rgb888_r[2] = I_tdata_r3[16+:8];
    assign   rgb888_g[2] = I_tdata_r3[8+:8] ;
    assign   rgb888_b[2] = I_tdata_r3[0+:8] ;

    // ��ȡ��4�����ص�RGB����
    assign   rgb888_r[3] = I_tdata_r4[16+:8];
    assign   rgb888_g[3] = I_tdata_r4[8+:8] ;
    assign   rgb888_b[3] = I_tdata_r4[0+:8] ;

/*****************************************************************
                        �����м��ź�                     
*****************************************************************/

    // �������ڴ洢���ұ�(LUT)������źţ���Բ�ͬ��٤��ֵ
    wire [11:0] O_LUT_2_6_data_r[3:0];
    wire [11:0] O_LUT_2_6_data_g[3:0];
    wire [11:0] O_LUT_2_6_data_b[3:0];
    
    wire [11:0] O_LUT_2_4_data_r[3:0];
    wire [11:0] O_LUT_2_4_data_g[3:0];
    wire [11:0] O_LUT_2_4_data_b[3:0];

    wire [11:0] O_LUT_2_2_data_r[3:0];
    wire [11:0] O_LUT_2_2_data_g[3:0];
    wire [11:0] O_LUT_2_2_data_b[3:0];

    wire [11:0] O_LUT_2_0_data_r[3:0];
    wire [11:0] O_LUT_2_0_data_g[3:0];
    wire [11:0] O_LUT_2_0_data_b[3:0];

    wire [11:0] O_LUT_1_8_data_r[3:0];
    wire [11:0] O_LUT_1_8_data_g[3:0];
    wire [11:0] O_LUT_1_8_data_b[3:0];

    wire [11:0] O_LUT_1_6_data_r[3:0];
    wire [11:0] O_LUT_1_6_data_g[3:0];
    wire [11:0] O_LUT_1_6_data_b[3:0];
    
    wire [11:0] O_LUT_1_4_data_r[3:0];
    wire [11:0] O_LUT_1_4_data_g[3:0];
    wire [11:0] O_LUT_1_4_data_b[3:0];
    
    wire [11:0] O_LUT_1_2_data_r[3:0];
    wire [11:0] O_LUT_1_2_data_g[3:0];
    wire [11:0] O_LUT_1_2_data_b[3:0];

    wire [11:0] O_LUT_0_8_data_r[3:0];
    wire [11:0] O_LUT_0_8_data_g[3:0];
    wire [11:0] O_LUT_0_8_data_b[3:0];

    // �����µ�RGBֵ
    wire  [7:0]  R_new [3:0];
    wire  [7:0]  G_new [3:0];
    wire  [7:0]  B_new [3:0];

/*****************************************************************
                        ����Ĵ����ź�                     
*****************************************************************/

    // ���ڴ洢ѡ����LUT�������
    reg   [11:0]  acc_rgb888_r[3:0];
    reg   [11:0]  acc_rgb888_g[3:0];
    reg   [11:0]  acc_rgb888_b[3:0];

    // ����ͬ�������tlast��tuser��tvalid�ź�
    reg   [3:0]   I_tlast_r ;
    reg   [3:0]   I_tuser_r ;
    reg   [3:0]   I_tvalid_r;

    // ���ڷ���һ�����м����
    reg   [20:0] acc_rgb888_r_x0[3:0];
    reg   [20:0] acc_rgb888_g_x0[3:0];
    reg   [20:0] acc_rgb888_b_x0[3:0];

    reg   [20:0] acc_rgb888_r_x1[3:0];
    reg   [20:0] acc_rgb888_g_x1[3:0];
    reg   [20:0] acc_rgb888_b_x1[3:0];

    reg   [7:0]  acc_rgb888_r_x2[3:0];
    reg   [7:0]  acc_rgb888_g_x2[3:0];
    reg   [7:0]  acc_rgb888_b_x2[3:0];

/*****************************************************************
                           ٤����ұ�ģ��ʵ����                                        
*****************************************************************/
    genvar i;
    generate
        for(i = 0; i < 4; i = i + 1)
        begin: LUT
            // ��Բ�ͬ��٤��ֵ��ʵ������Ӧ��LUTģ��

            // ٤��ֵΪ2.6��LUT
            lut_2_6 lut_2_6_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_6_data(rgb888_r[i]),
                .O_LUT_2_6_data(O_LUT_2_6_data_r[i])
            );

            lut_2_6 lut_2_6_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_6_data(rgb888_g[i]),
                .O_LUT_2_6_data(O_LUT_2_6_data_g[i])
            );

            lut_2_6 lut_2_6_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_6_data(rgb888_b[i]),
                .O_LUT_2_6_data(O_LUT_2_6_data_b[i])
            );

            // ٤��ֵΪ2.4��LUT
            lut_2_4 lut_2_4_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_4_data(rgb888_r[i]),
                .O_LUT_2_4_data(O_LUT_2_4_data_r[i])
            );

            lut_2_4 lut_2_4_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_4_data(rgb888_g[i]),
                .O_LUT_2_4_data(O_LUT_2_4_data_g[i])
            );

            lut_2_4 lut_2_4_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_4_data(rgb888_b[i]),
                .O_LUT_2_4_data(O_LUT_2_4_data_b[i])
            );

            // ٤��ֵΪ2.2��LUT
            lut_2_2 lut_2_2_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_2_data(rgb888_r[i]),
                .O_LUT_2_2_data(O_LUT_2_2_data_r[i])
            );

            lut_2_2 lut_2_2_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_2_data(rgb888_g[i]),
                .O_LUT_2_2_data(O_LUT_2_2_data_g[i])
            );

            lut_2_2 lut_2_2_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_2_data(rgb888_b[i]),
                .O_LUT_2_2_data(O_LUT_2_2_data_b[i])
            );

            // ٤��ֵΪ2.0��LUT
            lut_2_0 lut_2_0_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_0_data(rgb888_r[i]),
                .O_LUT_2_0_data(O_LUT_2_0_data_r[i])
            );

            lut_2_0 lut_2_0_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_0_data(rgb888_g[i]),
                .O_LUT_2_0_data(O_LUT_2_0_data_g[i])
            );

            lut_2_0 lut_2_0_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_2_0_data(rgb888_b[i]),
                .O_LUT_2_0_data(O_LUT_2_0_data_b[i])
            );

            // ٤��ֵΪ1.8��LUT
            lut_1_8 lut_1_8_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_8_data(rgb888_r[i]),
                .O_LUT_1_8_data(O_LUT_1_8_data_r[i])
            );

            lut_1_8 lut_1_8_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_8_data(rgb888_g[i]),
                .O_LUT_1_8_data(O_LUT_1_8_data_g[i])
            );

            lut_1_8 lut_1_8_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_8_data(rgb888_b[i]),
                .O_LUT_1_8_data(O_LUT_1_8_data_b[i])
            );

            // ٤��ֵΪ1.6��LUT
            lut_1_6 lut_1_6_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_6_data(rgb888_r[i]),
                .O_LUT_1_6_data(O_LUT_1_6_data_r[i])
            );

            lut_1_6 lut_1_6_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_6_data(rgb888_g[i]),
                .O_LUT_1_6_data(O_LUT_1_6_data_g[i])
            );

            lut_1_6 lut_1_6_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_6_data(rgb888_b[i]),
                .O_LUT_1_6_data(O_LUT_1_6_data_b[i])
            );

            // ٤��ֵΪ1.4��LUT
            lut_1_4 lut_1_4_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_4_data(rgb888_r[i]),
                .O_LUT_1_4_data(O_LUT_1_4_data_r[i])
            );

            lut_1_4 lut_1_4_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_4_data(rgb888_g[i]),
                .O_LUT_1_4_data(O_LUT_1_4_data_g[i])
            );

            lut_1_4 lut_1_4_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_4_data(rgb888_b[i]),
                .O_LUT_1_4_data(O_LUT_1_4_data_b[i])
            );

            // ٤��ֵΪ1.2��LUT
            lut_1_2 lut_1_2_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_2_data(rgb888_r[i]),
                .O_LUT_1_2_data(O_LUT_1_2_data_r[i])
            );

            lut_1_2 lut_1_2_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_2_data(rgb888_g[i]),
                .O_LUT_1_2_data(O_LUT_1_2_data_g[i])
            );

            lut_1_2 lut_1_2_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_1_2_data(rgb888_b[i]),
                .O_LUT_1_2_data(O_LUT_1_2_data_b[i])
            );

            // ٤��ֵΪ0.8��LUT
            lut_0_8 lut_0_8_R(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_0_8_data(rgb888_r[i]),
                .O_LUT_0_8_data(O_LUT_0_8_data_r[i])
            );

            lut_0_8 lut_0_8_G(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_0_8_data(rgb888_g[i]),
                .O_LUT_0_8_data(O_LUT_0_8_data_g[i])
            );

            lut_0_8 lut_0_8_B(
                .I_clk         (I_clk     ),
                .I_rst_n       (I_rst_n   ),
                .I_LUT_0_8_data(rgb888_b[i]),
                .O_LUT_0_8_data(O_LUT_0_8_data_b[i])
            );

/*****************************************************************
                           ѡ���Ӧ��٤��У��ֵ                                      
*****************************************************************/

            // ���ݲ���GAMMA_10xѡ���Ӧ��٤��LUT���
            always @(posedge I_clk or negedge I_rst_n)begin 
                if(!I_rst_n)begin
                    acc_rgb888_r[i] <= 12'd0;
                    acc_rgb888_g[i] <= 12'd0;
                    acc_rgb888_b[i] <= 12'd0;
                end
                else begin
                    case (GAMMA_10x)
                        5'd26:begin 
                           acc_rgb888_r[i] <= O_LUT_2_6_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_2_6_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_2_6_data_b[i];
                        end
                        5'd24:begin 
                           acc_rgb888_r[i] <= O_LUT_2_4_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_2_4_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_2_4_data_b[i];
                        end
                        5'd22:begin 
                           acc_rgb888_r[i] <= O_LUT_2_2_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_2_2_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_2_2_data_b[i];
                        end
                        5'd20:begin
                           acc_rgb888_r[i] <= O_LUT_2_0_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_2_0_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_2_0_data_b[i];
                        end
                        5'd18:begin
                           acc_rgb888_r[i] <= O_LUT_1_8_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_1_8_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_1_8_data_b[i];
                        end
                        5'd16:begin
                           acc_rgb888_r[i] <= O_LUT_1_6_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_1_6_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_1_6_data_b[i];
                        end
                        5'd14:begin
                           acc_rgb888_r[i] <= O_LUT_1_4_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_1_4_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_1_4_data_b[i];
                        end
                        5'd12:begin
                           acc_rgb888_r[i] <= O_LUT_1_2_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_1_2_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_1_2_data_b[i];
                        end
                        5'd8 :begin
                           acc_rgb888_r[i] <= O_LUT_0_8_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_0_8_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_0_8_data_b[i];
                        end
                        default:begin 
                           acc_rgb888_r[i] <= O_LUT_2_2_data_r[i];
                           acc_rgb888_g[i] <= O_LUT_2_2_data_g[i];
                           acc_rgb888_b[i] <= O_LUT_2_2_data_b[i];
                        end
                    endcase
                end
            end

/*****************************************************************
                           ����һ������                                      
*****************************************************************/

            // ��һ����ˮ�ߣ�����������8λ
            always @(posedge I_clk or negedge I_rst_n)begin 
                if(!I_rst_n)begin
                    acc_rgb888_r_x0[i] <= 0;
                    acc_rgb888_g_x0[i] <= 0;
                    acc_rgb888_b_x0[i] <= 0;
                end
                else if(I_tvalid_r[0])begin
                    acc_rgb888_r_x0[i] <= acc_rgb888_r[i] << 8;
                    acc_rgb888_g_x0[i] <= acc_rgb888_g[i] << 8;
                    acc_rgb888_b_x0[i] <= acc_rgb888_b[i] << 8;
                end
                else begin
                    acc_rgb888_r_x0[i] <= acc_rgb888_r_x0[i] ;
                    acc_rgb888_g_x0[i] <= acc_rgb888_g_x0[i] ;
                    acc_rgb888_b_x0[i] <= acc_rgb888_b_x0[i] ;
                end
            end
        
            // �ڶ�����ˮ�ߣ���ȥ2048��ʵ�ַ���һ��
            always @(posedge I_clk or negedge I_rst_n)begin 
                if(!I_rst_n)begin
                    acc_rgb888_r_x1[i] <= 0;
                    acc_rgb888_g_x1[i] <= 0;
                    acc_rgb888_b_x1[i] <= 0;
                end
                else if(I_tvalid_r[1])begin
                    acc_rgb888_r_x1[i] <= acc_rgb888_r_x0[i] - 2048;
                    acc_rgb888_g_x1[i] <= acc_rgb888_g_x0[i] - 2048;
                    acc_rgb888_b_x1[i] <= acc_rgb888_b_x0[i] - 2048;
                end
                else begin
                    acc_rgb888_r_x1[i] <= acc_rgb888_r_x1[i];
                    acc_rgb888_g_x1[i] <= acc_rgb888_g_x1[i];
                    acc_rgb888_b_x1[i] <= acc_rgb888_b_x1[i];
                end
            end
    
            // ��������ˮ�ߣ�����RGBֵ�ķ�Χ����ֹ���
            always @(posedge I_clk or negedge I_rst_n)begin 
                if(!I_rst_n)begin
                    acc_rgb888_r_x2[i] <= 0;
                    acc_rgb888_g_x2[i] <= 0;
                    acc_rgb888_b_x2[i] <= 0;
                end
                else if(I_tvalid_r[2])begin
                    acc_rgb888_r_x2[i] <= (acc_rgb888_r_x1[i][20]) ? 8'd255 : (acc_rgb888_r_x1[i][19:12]);
                    acc_rgb888_g_x2[i] <= (acc_rgb888_g_x1[i][20]) ? 8'd255 : (acc_rgb888_g_x1[i][19:12]);
                    acc_rgb888_b_x2[i] <= (acc_rgb888_b_x1[i][20]) ? 8'd255 : (acc_rgb888_b_x1[i][19:12]);
                end
                else begin
                    acc_rgb888_r_x2[i] <= acc_rgb888_r_x2[i];
                    acc_rgb888_g_x2[i] <= acc_rgb888_g_x2[i];
                    acc_rgb888_b_x2[i] <= acc_rgb888_b_x2[i];
                end
            end

/*****************************************************************
                            ��ȡ�µ�RGBֵ                                      
*****************************************************************/

            // ������һ�������ƺ��ֵ�����µ�RGBֵ
            assign R_new[i] = acc_rgb888_r_x2[i];
            assign G_new[i] = acc_rgb888_g_x2[i];
            assign B_new[i] = acc_rgb888_b_x2[i];

        end
    endgenerate

/*****************************************************************
                            ͬ���źŴ���                                      
*****************************************************************/

    // ������Ŀ����źŽ���ͬ�����ӳ�4��ʱ�����ڣ������ݶ���
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n)
            {I_tlast_r,I_tuser_r,I_tvalid_r} <= 0;
        else begin
            I_tlast_r <= {I_tlast_r[2:0],I_tlast};
            I_tuser_r <= {I_tuser_r[2:0],I_tuser};
            I_tvalid_r <= {I_tvalid_r[2:0],I_tvalid};
        end
    end

    // ��ͬ����Ŀ����źŸ������
    assign  O_tlast  = I_tlast_r[3];   
    assign  O_tuser  = I_tuser_r[3];   
    assign  O_tvalid = I_tvalid_r[3];

    // ���µ�RGBֵ��ϳ��������
    assign O_tdata = {R_new[3],G_new[3],B_new[3],
                      R_new[2],G_new[2],B_new[2],
                      R_new[1],G_new[1],B_new[1],
                      R_new[0],G_new[0],B_new[0]};

    // �������׼�����ź�ֱ�����ӵ������׼�����ź�
    assign  I_tready = O_tready;

endmodule
