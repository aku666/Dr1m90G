`define DP_RAM_36adcf8112f5
`define OUTREG_DISA_36adcf8112f5
`define ASYNC_RELEASE_A_36adcf8112f5
`define OUTREG_DISB_36adcf8112f5
`define ASYNC_RELEASE_B_36adcf8112f5
`define FAST_36adcf8112f5
`define WEA_EN_36adcf8112f5
