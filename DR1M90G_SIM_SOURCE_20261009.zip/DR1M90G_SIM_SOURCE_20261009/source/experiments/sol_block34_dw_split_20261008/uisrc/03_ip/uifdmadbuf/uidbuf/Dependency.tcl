# The Command Lines that defined the parameter attributes.

set_param -param_id {AXI_DATA_WIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {AXI_ADDR_WIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_SYNC} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_BUFDEPTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_DATAWIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_BASEADDR} -data_type {Integer}
set_param -param_id {W_DSIZEBITS} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_XSIZE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_XSTRIDE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_YSIZE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_XDIV} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {W_BUFSIZE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_SYNC} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_BUFDEPTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_DATAWIDTH} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_BASEADDR} -data_type {Integer}
set_param -param_id {R_DSIZEBITS} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_XSIZE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_XSTRIDE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_YSIZE} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_XDIV} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {R_BUFSIZE} -data_type {Integer} -min {-2147483648} -max {2147483647}
# The Tcl Procs that used in parameter dependency.

proc updateRelValue { value } {
 set tmp $value
 return $tmp
}