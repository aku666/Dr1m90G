# The Command Lines that defined the layout and widget properties.

set Tab_Tab_0 [add_tab -name {Tab_0} -col_count {1}]

set Spin_Box_num [add_param -parent {Tab_0} -name {num} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_num -prop {Display Name} -value {num}