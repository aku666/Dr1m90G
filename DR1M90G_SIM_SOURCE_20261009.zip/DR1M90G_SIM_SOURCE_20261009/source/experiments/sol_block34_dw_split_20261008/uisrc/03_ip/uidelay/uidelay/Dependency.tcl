# The Command Lines that defined the parameter attributes.

set_param -param_id {num} -data_type {Integer} -min {-2147483648} -max {2147483647}
# The Tcl Procs that used in parameter dependency.

proc updateRelValue { value } {
 set tmp $value
 return $tmp
}