`define SP_ROM_ed264d956bc8
`define OUTREG_DISA_ed264d956bc8
`define OUTREG_DISB_ed264d956bc8
