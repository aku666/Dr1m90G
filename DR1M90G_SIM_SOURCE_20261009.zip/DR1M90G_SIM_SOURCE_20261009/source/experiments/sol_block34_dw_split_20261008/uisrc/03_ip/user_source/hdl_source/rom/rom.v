/************************************************************\
**	Copyright (c) 2012-2025 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Jun 11 2025 13:31:15
**	TD version	:	5.9.151508
************************************************************/
`timescale 1 ns / 1 ps
module rom
(
  input   [9:0]                 addra,
  input                         clka,
  output  [7:0]                 doa
);

  rom_ed264d956bc8
  #(
      .DATA_WIDTH_A(8),
      .ADDR_WIDTH_A(10),
      .DATA_DEPTH_A(1024),
      .INIT_FILE("../../display_config/config_data_nes.mif.dat"),
      .FILL_ALL("NONE")
  )rom_ed264d956bc8_Inst
  (
      .doa(doa),
      .addra(addra),
      .clka(clka)
  );
endmodule
