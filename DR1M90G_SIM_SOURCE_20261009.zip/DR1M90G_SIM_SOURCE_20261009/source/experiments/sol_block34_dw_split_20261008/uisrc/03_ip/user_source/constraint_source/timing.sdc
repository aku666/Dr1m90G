create_clock -name I_clk -period 10 -waveform {0 5} [get_ports {I_clk}]

derive_pll_clocks

rename_clock -name {clk_130m} -source [get_ports {I_clk}] -master_clock {I_clk_50m} [get_pins {u_pll/dr1_phy_pll_7c68db14e1dc_Inst/u_DR1_PHY_PLL.clkc[0]}]
rename_clock -name {clk_260m} -source [get_ports {I_clk}] -master_clock {I_clk_50m} [get_pins {u_pll/dr1_phy_pll_7c68db14e1dc_Inst/u_DR1_PHY_PLL.clkc[1]}]
rename_clock -name {clk_500m} -source [get_ports {I_clk}] -master_clock {I_clk_50m} [get_pins {u_pll/dr1_phy_pll_7c68db14e1dc_Inst/u_DR1_PHY_PLL.clkc[2]}]
rename_clock -name {clk_500m_90d} -source [get_ports {I_clk}] -master_clock {I_clk_50m} [get_pins {u_pll/dr1_phy_pll_7c68db14e1dc_Inst/u_DR1_PHY_PLL.clkc[3]}]
rename_clock -name {clk_10m} -source [get_ports {I_clk}] -master_clock {I_clk_50m} [get_pins {u_pll/dr1_phy_pll_7c68db14e1dc_Inst/u_DR1_PHY_PLL.clkc[4]}]
set_clock_groups -exclusive -group [get_clocks {clk_10m clk_130m clk_260m clk_500m clk_500m_90d I_clk}]