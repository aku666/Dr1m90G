//============================================================================
// feature_bram.v — On-chip feature buffer (dual-port BRAM).
//
// Capacity: NUM_FRAMES (max 32) * FEAT_DIM (max 256) bytes = 8 KB
// Word width: 8-bit (one INT8 sample per address).
//
// Port A: AXI-Lite write from ARM (load input feature map).
//   Each AXI-Lite write to FEAT_WR (offset 0x40) writes ONE byte at the
//   current `feat_wr_ptr`, which auto-increments. ARM uses FEAT_WR_ADDR
//   (offset 0x44) to reset the pointer before a new transfer.
//
// Port B: streaming read by ctrl_fsm at compute time.
//============================================================================
module feature_bram #(
    parameter ADDR_WIDTH = 13,    // 2^13 = 8192 bytes
    parameter DATA_WIDTH = 8
)(
    input  wire                    clk,
    // Port A: write
    input  wire                    wr_en_a,
    input  wire [ADDR_WIDTH-1:0]   addr_a,
    input  wire [DATA_WIDTH-1:0]   din_a,
    // Port B: read (1-cycle latency)
    input  wire [ADDR_WIDTH-1:0]   addr_b,
    output reg  [DATA_WIDTH-1:0]   dout_b
);

    (* ram_style = "block" *)
    reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

    always @(posedge clk) begin
        if (wr_en_a) mem[addr_a] <= din_a;
    end

    always @(posedge clk) begin
        dout_b <= mem[addr_b];
    end

endmodule
