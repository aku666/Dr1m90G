//============================================================================
// output_bram.v — On-chip output buffer (dual-port BRAM).
//
// Capacity: NUM_FILTERS (max 64) * 4 bytes (INT32 per filter) = 256 bytes
// Word width: 32-bit (one INT32 result per filter index).
//
// Port A: written by ctrl_fsm at the end of each filter's pooling stage.
// Port B: read by AXI-Lite (ARM reads via OUTPUT_RD register at offset 0x48
//         using auto-incrementing pointer OUTPUT_RD_ADDR at offset 0x4C).
//============================================================================
module output_bram #(
    parameter ADDR_WIDTH = 6,     // 2^6 = 64 entries
    parameter DATA_WIDTH = 32
)(
    input  wire                    clk,
    // Port A: write
    input  wire                    wr_en_a,
    input  wire [ADDR_WIDTH-1:0]   addr_a,
    input  wire [DATA_WIDTH-1:0]   din_a,
    // Port B: read
    input  wire [ADDR_WIDTH-1:0]   addr_b,
    output reg  [DATA_WIDTH-1:0]   dout_b
);

    (* ram_style = "block" *)
    reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

    always @(posedge clk) begin
        if (wr_en_a) mem[addr_a] <= din_a;
    end

    always @(posedge clk) begin
        dout_b <= mem[addr_b];
    end

endmodule
