//============================================================================
// mac_unit.v — Single signed INT8 × INT8 -> INT32 multiply-accumulate.
//
// Pipeline:
//   stage 1 : multiply (a * b -> 16-bit signed)
//   stage 2 : accumulate (acc += multiply, sign-extended to 32-bit)
//
// Behavior:
//   - clear (sync, level): zero accumulator next cycle
//   - valid_i pulse train: each beat contributes one a*b to acc
//   - When valid_i goes low after a run, valid_o pulses one cycle to mark
//     "result settled" (caller can latch acc).
//============================================================================
module mac_unit (
    input  wire              clk,
    input  wire              rst_n,
    input  wire              clear,
    input  wire              valid_i,
    input  wire signed [7:0] a,
    input  wire signed [7:0] b,
    output reg  signed [31:0] acc,
    output reg               valid_o
);

    reg signed [15:0] mult_r;
    reg               mult_valid;
    reg               valid_i_d;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mult_r     <= 16'sd0;
            mult_valid <= 1'b0;
            valid_i_d  <= 1'b0;
        end else begin
            mult_r     <= a * b;
            mult_valid <= valid_i;
            valid_i_d  <= valid_i;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            acc     <= 32'sd0;
            valid_o <= 1'b0;
        end else if (clear) begin
            acc     <= 32'sd0;
            valid_o <= 1'b0;
        end else begin
            if (mult_valid)
                acc <= acc + {{16{mult_r[15]}}, mult_r};
            // pulse valid_o on the falling edge of mult_valid (run finished)
            valid_o <= mult_valid & ~valid_i;
        end
    end

endmodule
