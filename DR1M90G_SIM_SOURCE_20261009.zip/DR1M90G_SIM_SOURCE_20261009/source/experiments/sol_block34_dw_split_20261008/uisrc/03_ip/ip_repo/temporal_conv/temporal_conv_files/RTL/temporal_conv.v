`timescale 1 ns / 1 ps

//============================================================================
// temporal_conv.v — TD-packaged AXI-Lite temporal convolution accelerator.
//
// Top-level wrapper. AXI-Lite slave is implemented inline (matches Anlogic
// official axi_lite_reg style: explicit Idle/Waddr/Wdata write FSM,
// Idle/Raddr/Rdata read FSM). Compute engine is fully on-chip BRAM-only:
//
//   ARM writes feature bytes via FEAT_WR  (offset 0x40, byte-wise).
//   ARM writes weight  bytes via WEIGHT_WR (offset 0x20, byte-wise).
//   ARM kicks  CTRL[start] (offset 0x00).
//   ARM polls  CTRL[done] / IRQ_STATUS for completion.
//   ARM reads  output INT32 results via OUTPUT_RD (offset 0x48).
//
// Register map (byte offsets, 32-bit registers, addr[6:2] = word index):
//   0x00 CTRL          [0]=start (W1S, self-clearing)
//                      [1]=done  (RO)
//                      [2]=busy  (RO)
//   0x0C NUM_FRAMES    RW   N           [7:0]   (default 0x10 = 16)
//   0x10 FEAT_DIM      RW   D           [8:0]   (default 0x100 = 256)
//   0x14 KERNEL_SIZE   RW   K           [3:0]   (default 0x05 = 5)
//   0x18 NUM_FILTERS   RW   F           [7:0]   (default 0x04 = 4 — clamped to NUM_PE)
//   0x1C POOL_SHIFT    RW   S           [3:0]
//   0x20 WEIGHT_WR     WO   write-only — pushes one byte at WEIGHT_PTR
//   0x24 WEIGHT_ADDR   RW   resets WEIGHT_PTR (LSB byte address inside the
//                                              concatenated weight stream)
//   0x28 IRQ_STATUS    RO   [0]=done latched
//   0x2C IRQ_CLEAR     WO   write 1 to bit0 to clear IRQ_STATUS
//   0x30 IRQ_ENABLE    RW   [0]=enable
//   0x34 IP_ID         RO   "TCON" = 0x54434F4E
//   0x38 VERSION       RO   0x00010000
//   0x3C CAPABILITY    RO   reserved
//   0x40 FEAT_WR       WO   write-only — pushes one byte at FEAT_PTR
//   0x44 FEAT_WR_ADDR  RW   resets FEAT_PTR
//   0x48 OUTPUT_RD     RO   reads a 32-bit result and auto-advances OUT_PTR
//   0x4C OUTPUT_RD_ADDR RW  resets OUT_PTR (filter index)
//
// Storage:
//   FEAT_BRAM    : 8 KB,  8-bit wide   (NUM_FRAMES_MAX * FEAT_DIM_MAX = 32*256)
//   WEIGHT_BRAM  : NUM_PE separate BRAMs, each KERNEL_MAX * FEAT_DIM_MAX bytes
//                  per filter (8*256 = 2 KB per BRAM; 4 BRAMs total = 8 KB)
//   OUTPUT_BRAM  : 64 entries × 32-bit
//
// Compute strategy: see ctrl_fsm.v header.
//============================================================================

module temporal_conv (
    input  wire        aclk,
    input  wire        rst_n,

    input  wire [6:0]  S_AXI_AWADDR,
    input  wire [2:0]  S_AXI_AWPROT,
    input  wire        S_AXI_AWVALID,
    output wire        S_AXI_AWREADY,
    input  wire [31:0] S_AXI_WDATA,
    input  wire [3:0]  S_AXI_WSTRB,
    input  wire        S_AXI_WVALID,
    output wire        S_AXI_WREADY,
    output wire [1:0]  S_AXI_BRESP,
    output wire        S_AXI_BVALID,
    input  wire        S_AXI_BREADY,
    input  wire [6:0]  S_AXI_ARADDR,
    input  wire [2:0]  S_AXI_ARPROT,
    input  wire        S_AXI_ARVALID,
    output wire        S_AXI_ARREADY,
    output wire [31:0] S_AXI_RDATA,
    output wire [1:0]  S_AXI_RRESP,
    output wire        S_AXI_RVALID,
    input  wire        S_AXI_RREADY
);

    // -----------------------------------------------------------------------
    // Sizing parameters — kept consistent across all sub-modules.
    // -----------------------------------------------------------------------
    localparam NUM_PE         = 4;
    localparam FEAT_ADDR_W    = 13;     // 8 KB feature buffer
    localparam WEIGHT_ADDR_W  = 11;     // 2 KB per-filter weight buffer
    localparam OUT_ADDR_W     = 6;      // 64 INT32 entries
    localparam FEAT_DIM_MAX   = 256;
    localparam KERNEL_MAX     = 8;
    localparam NUM_FRAMES_MAX = 32;

    // -----------------------------------------------------------------------
    // AXI-Lite slave write FSM (Idle/Waddr/Wdata — Anlogic official style)
    // -----------------------------------------------------------------------
    localparam W_IDLE  = 2'b00;
    localparam W_WADDR = 2'b10;
    localparam W_WDATA = 2'b11;
    localparam R_IDLE  = 2'b00;
    localparam R_RADDR = 2'b10;
    localparam R_RDATA = 2'b11;

    reg [1:0]  state_w, state_r;
    reg [6:0]  axi_awaddr_q, axi_araddr_q;
    reg        axi_awready, axi_wready;
    reg        axi_bvalid;
    reg [1:0]  axi_bresp;
    reg        axi_arready;
    reg        axi_rvalid;
    reg [1:0]  axi_rresp;
    reg [31:0] read_data_mux;
    reg [31:0] rdata_q;
    wire sts_busy;
    wire start_rejected;

    assign S_AXI_AWREADY = axi_awready;
    assign S_AXI_WREADY  = axi_wready;
    assign S_AXI_BVALID  = axi_bvalid;
    assign S_AXI_BRESP   = axi_bresp;
    assign S_AXI_ARREADY = axi_arready;
    assign S_AXI_RVALID  = axi_rvalid;
    assign S_AXI_RRESP   = axi_rresp;
    assign S_AXI_RDATA   = rdata_q;

    // One buffered AW and W independently; one response outstanding.
    reg aw_pending, w_pending;
    reg [31:0] wdata_q;
    reg [3:0] wstrb_q;
    wire any_write = aw_pending && w_pending && !axi_bvalid;
    wire [6:0] wr_addr = axi_awaddr_q;
    wire [31:0] wr_data = wdata_q;
    wire [3:0] wr_strb = wstrb_q;
    always @(*) begin
        axi_awready = !aw_pending && !axi_bvalid;
        axi_wready = !w_pending && !axi_bvalid;
        axi_arready = (state_r == R_RADDR) && !axi_rvalid;
    end
    always @(posedge aclk or negedge rst_n) begin
        if (!rst_n) begin
            aw_pending <= 0; w_pending <= 0; axi_bvalid <= 0;
            axi_bresp <= 0; axi_awaddr_q <= 0; wdata_q <= 0; wstrb_q <= 0;
            state_w <= W_IDLE;
        end else begin
            if (S_AXI_AWVALID && axi_awready) begin
                axi_awaddr_q <= S_AXI_AWADDR; aw_pending <= 1;
            end
            if (S_AXI_WVALID && axi_wready) begin
                wdata_q <= S_AXI_WDATA; wstrb_q <= S_AXI_WSTRB; w_pending <= 1;
            end
            if (axi_bvalid && S_AXI_BREADY) axi_bvalid <= 0;
            if (any_write) begin
                aw_pending <= 0; w_pending <= 0; axi_bvalid <= 1;
                axi_bresp <= (sts_busy || start_rejected) ? 2'b10 : 2'b00;
            end
        end
    end
    // Capture address, allow a complete cycle for RAM/mux, then hold RDATA.
    always @(posedge aclk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= R_RADDR; axi_rvalid <= 0; axi_rresp <= 0;
            axi_araddr_q <= 0; rdata_q <= 0;
        end else case(state_r)
            R_RADDR: if (S_AXI_ARVALID && axi_arready) begin
                axi_araddr_q <= S_AXI_ARADDR; state_r <= R_IDLE;
            end
            R_IDLE: begin
                rdata_q <= read_data_mux; axi_rvalid <= 1; state_r <= R_RDATA;
            end
            R_RDATA: if (axi_rvalid && S_AXI_RREADY) begin
                axi_rvalid <= 0; state_r <= R_RADDR;
            end
            default: state_r <= R_RADDR;
        endcase
    end

    // -----------------------------------------------------------------------
    // Memory-mapped registers (config + IRQ + RO)
    // -----------------------------------------------------------------------
    reg        cfg_start_pulse;
    reg [7:0]  cfg_num_frames;
    reg [8:0]  cfg_feat_dim;
    reg [3:0]  cfg_kernel_size;
    reg [7:0]  cfg_num_filters;
    reg [3:0]  cfg_pool_shift;

    reg        irq_status;
    reg        irq_enable;

    // Pointers into BRAMs (auto-incrementing on each WO write)
    reg [WEIGHT_ADDR_W+1:0] weight_ptr;     // byte address spanning all PEs
    reg [FEAT_ADDR_W-1:0]   feat_ptr;
    reg [OUT_ADDR_W-1:0]    out_rd_ptr;

    // Side-band signals from FSM
    wire        sts_done;
    wire [31:0] out_rd_data;

    // The done event latching is gated by sts_done
    reg done_prev;
    assign start_rejected = (wr_addr[6:2] == 0) && wr_strb[0] && wr_data[0] &&
                            ((cfg_num_frames < cfg_kernel_size) ||
                             (cfg_feat_dim == 0) || (cfg_feat_dim > FEAT_DIM_MAX));

    always @(posedge aclk or negedge rst_n) begin
        if (!rst_n) begin
            cfg_start_pulse <= 1'b0;
            cfg_num_frames  <= 8'd16;
            cfg_feat_dim    <= 9'd256;
            cfg_kernel_size <= 4'd5;
            cfg_num_filters <= 8'd4;
            cfg_pool_shift  <= 4'd0;
            irq_status      <= 1'b0;
            irq_enable      <= 1'b0;
            weight_ptr      <= {(WEIGHT_ADDR_W+2){1'b0}};
            feat_ptr        <= {FEAT_ADDR_W{1'b0}};
            out_rd_ptr      <= {OUT_ADDR_W{1'b0}};
            done_prev       <= 1'b0;
        end else begin
            cfg_start_pulse <= 1'b0;

            // Latch done -> irq_status
            done_prev <= sts_done;
            if (sts_done && !done_prev) irq_status <= 1'b1;

            if (any_write && !sts_busy && !start_rejected) begin
                case (wr_addr[6:2])
                5'h00: if (wr_strb[0] && wr_data[0]) cfg_start_pulse <= 1'b1;

                5'h03: if (wr_strb[0]) cfg_num_frames <= (wr_data[7:0] < 1) ? 1 : ((wr_data[7:0] > NUM_FRAMES_MAX) ? NUM_FRAMES_MAX : wr_data[7:0]);

                5'h04: begin
                    if (wr_strb[0]) cfg_feat_dim[7:0] <= wr_data[7:0];
                    if (wr_strb[1]) cfg_feat_dim[8]   <= wr_data[8];
                end

                5'h05: if (wr_strb[0]) cfg_kernel_size <= (wr_data[3:0] < 1) ? 1 : ((wr_data[3:0] > KERNEL_MAX) ? KERNEL_MAX : wr_data[3:0]);
                5'h06: if (wr_strb[0]) cfg_num_filters <= (wr_data[7:0] < 1) ? 1 : ((wr_data[7:0] > NUM_PE) ? NUM_PE : wr_data[7:0]);
                5'h07: if (wr_strb[0]) cfg_pool_shift  <= wr_data[3:0];

                5'h08: begin     // WEIGHT_WR — write byte at weight_ptr, auto-inc
                    if (wr_strb[0])
                        weight_ptr <= weight_ptr + 1'b1;
                end

                5'h09: begin     // WEIGHT_WR_ADDR — reset pointer
                    if (wr_strb[0]) weight_ptr[7:0] <= wr_data[7:0];
                    if (wr_strb[1]) weight_ptr[(WEIGHT_ADDR_W+1):8]
                                       <= wr_data[(WEIGHT_ADDR_W+1):8];
                end

                5'h0B: if (wr_strb[0] && wr_data[0]) irq_status <= 1'b0; // IRQ_CLEAR
                5'h0C: if (wr_strb[0]) irq_enable <= wr_data[0];

                5'h10: begin    // FEAT_WR — auto-inc feat_ptr
                    if (wr_strb[0])
                        feat_ptr <= feat_ptr + 1'b1;
                end

                5'h11: begin    // FEAT_WR_ADDR — reset pointer
                    if (wr_strb[0]) feat_ptr[ 7:0] <= wr_data[ 7:0];
                    if (wr_strb[1]) feat_ptr[(FEAT_ADDR_W-1):8]
                                      <= wr_data[(FEAT_ADDR_W-1):8];
                end

                5'h13: begin    // OUTPUT_RD_ADDR — reset out_rd_ptr
                    if (wr_strb[0]) out_rd_ptr <= wr_data[OUT_ADDR_W-1:0];
                end

                default: ;
                endcase
            end

            // OUTPUT_RD auto-increment on RDATA handshake (on R_RDATA -> R_RADDR)
            if (state_r == R_RDATA && S_AXI_RREADY && axi_rvalid &&
                axi_araddr_q[6:2] == 5'h12) begin
                out_rd_ptr <= out_rd_ptr + 1'b1;
            end
        end
    end

    // Read mux (synchronous: latched into read_data_mux on R_RADDR transition)
    always @(*) begin
        case (axi_araddr_q[6:2])
            5'h00: read_data_mux = {29'd0, sts_busy, irq_status, 1'b0};
            5'h03: read_data_mux = {24'd0, cfg_num_frames};
            5'h04: read_data_mux = {23'd0, cfg_feat_dim};
            5'h05: read_data_mux = {28'd0, cfg_kernel_size};
            5'h06: read_data_mux = {24'd0, cfg_num_filters};
            5'h07: read_data_mux = {28'd0, cfg_pool_shift};
            5'h09: read_data_mux = {{(32-WEIGHT_ADDR_W-2){1'b0}}, weight_ptr};
            5'h0A: read_data_mux = {31'd0, irq_status};
            5'h0C: read_data_mux = {31'd0, irq_enable};
            5'h0D: read_data_mux = 32'h5443_4F4E;        // "TCON"
            5'h0E: read_data_mux = 32'h0001_0001;        // VERSION
            5'h0F: read_data_mux = 32'h0000_0001;        // CAPABILITY
            5'h11: read_data_mux = {{(32-FEAT_ADDR_W){1'b0}}, feat_ptr};
            5'h12: read_data_mux = out_rd_data;
            5'h13: read_data_mux = {{(32-OUT_ADDR_W){1'b0}}, out_rd_ptr};
            default: read_data_mux = 32'd0;
        endcase
    end

    // -----------------------------------------------------------------------
    // Feature BRAM
    // -----------------------------------------------------------------------
    wire                    feat_wr_en   = any_write && !sts_busy && (wr_addr[6:2] == 5'h10)
                                                     && wr_strb[0];
    wire [7:0]              feat_wr_data = wr_data[7:0];
    wire [FEAT_ADDR_W-1:0]  feat_rd_addr;
    wire [7:0]              feat_rd_data;

    feature_bram #(
        .ADDR_WIDTH (FEAT_ADDR_W),
        .DATA_WIDTH (8)
    ) u_feat_bram (
        .clk     (aclk),
        .wr_en_a (feat_wr_en),
        .addr_a  (feat_ptr),
        .din_a   (feat_wr_data),
        .addr_b  (feat_rd_addr),
        .dout_b  (feat_rd_data)
    );

    // -----------------------------------------------------------------------
    // Weight BRAMs (NUM_PE instances, one per filter)
    //
    // weight_ptr layout:
    //   weight_ptr[ WEIGHT_ADDR_W+1 : WEIGHT_ADDR_W ]  = filter index (PE select)
    //   weight_ptr[ WEIGHT_ADDR_W-1 : 0              ] = byte addr inside that filter
    // -----------------------------------------------------------------------
    wire [1:0]                wr_pe_sel  = weight_ptr[WEIGHT_ADDR_W+1:WEIGHT_ADDR_W];
    wire [WEIGHT_ADDR_W-1:0]  wr_pe_addr = weight_ptr[WEIGHT_ADDR_W-1:0];
    wire                      weight_wr_en = any_write && !sts_busy && (wr_addr[6:2] == 5'h08)
                                                       && wr_strb[0];
    wire [7:0]                weight_wr_data = wr_data[7:0];

    wire [WEIGHT_ADDR_W-1:0]  weight_rd_addr;     // broadcast to all PEs
    wire [7:0]                weight_rd_data [0:NUM_PE-1];
    wire [NUM_PE*8-1:0]       weight_rd_packed;

    genvar i;
    generate
        for (i = 0; i < NUM_PE; i = i + 1) begin : WBRAM_GEN
            weight_bram #(
                .ADDR_WIDTH (WEIGHT_ADDR_W),
                .DATA_WIDTH (8)
            ) u_wbram (
                .clk     (aclk),
                .wr_en_a (weight_wr_en && (wr_pe_sel == i[1:0])),
                .addr_a  (wr_pe_addr),
                .din_a   (weight_wr_data),
                .addr_b  (weight_rd_addr),
                .dout_b  (weight_rd_data[i])
            );
            assign weight_rd_packed[i*8 +: 8] = weight_rd_data[i];
        end
    endgenerate

    // -----------------------------------------------------------------------
    // PE array
    // -----------------------------------------------------------------------
    wire                       pe_clear;
    wire                       pe_valid;
    wire signed [7:0]          pe_feat;
    wire signed [NUM_PE*32-1:0] pe_acc;
    wire        [NUM_PE-1:0]   pe_done;

    pe_array #(
        .NUM_PE (NUM_PE)
    ) u_pe_array (
        .clk      (aclk),
        .rst_n    (rst_n),
        .clear    (pe_clear),
        .valid_i  (pe_valid),
        .feat_i   (pe_feat),
        .weight_i (weight_rd_packed),
        .acc_o    (pe_acc),
        .valid_o  (pe_done)
    );

    // -----------------------------------------------------------------------
    // Output BRAM
    // -----------------------------------------------------------------------
    wire                    out_wr_en;
    wire [OUT_ADDR_W-1:0]   out_wr_addr;
    wire [31:0]             out_wr_data;

    output_bram #(
        .ADDR_WIDTH (OUT_ADDR_W),
        .DATA_WIDTH (32)
    ) u_out_bram (
        .clk     (aclk),
        .wr_en_a (out_wr_en),
        .addr_a  (out_wr_addr),
        .din_a   (out_wr_data),
        .addr_b  (out_rd_ptr),
        .dout_b  (out_rd_data)
    );

    // -----------------------------------------------------------------------
    // Compute controller
    // -----------------------------------------------------------------------
    ctrl_fsm #(
        .NUM_PE         (NUM_PE),
        .FEAT_ADDR_W    (FEAT_ADDR_W),
        .WEIGHT_ADDR_W  (WEIGHT_ADDR_W),
        .OUT_ADDR_W     (OUT_ADDR_W),
        .FEAT_DIM_MAX   (FEAT_DIM_MAX),
        .KERNEL_MAX     (KERNEL_MAX),
        .NUM_FRAMES_MAX (NUM_FRAMES_MAX)
    ) u_ctrl (
        .clk                (aclk),
        .rst_n              (rst_n),

        .cfg_start          (cfg_start_pulse),
        .cfg_num_frames     (cfg_num_frames),
        .cfg_feat_dim       (cfg_feat_dim),
        .cfg_kernel_size    (cfg_kernel_size),
        .cfg_num_filters    (cfg_num_filters),
        .cfg_pool_shift     (cfg_pool_shift),

        .sts_busy           (sts_busy),
        .sts_done           (sts_done),

        .feat_addr          (feat_rd_addr),
        .feat_data          (feat_rd_data),

        .weight_addr_per_pe (weight_rd_addr),

        .pe_clear           (pe_clear),
        .pe_valid           (pe_valid),
        .pe_feat            (pe_feat),
        .pe_acc             (pe_acc),

        .out_wr_en          (out_wr_en),
        .out_wr_addr        (out_wr_addr),
        .out_wr_data        (out_wr_data)
    );

    // -----------------------------------------------------------------------
    // Tie-offs to silence "unused" warnings during initial bring-up
    // -----------------------------------------------------------------------
    wire _unused = |{
        S_AXI_AWPROT, S_AXI_ARPROT, S_AXI_WSTRB[3:1],
        pe_done
    };

endmodule
