//============================================================================
// pe_array.v — Parallel Processing Element array of NUM_PE MAC units.
//
// All PEs share the same feature input. Each PE has its own 8-bit weight
// drawn from the packed weight bus. PE k computes:
//
//     acc_k = sum_t (feat_t * weight_k_t)
//
// where the (t) iteration is driven externally by the controller pulsing
// valid_i. Once valid_i goes low, each PE pulses its valid_o and exposes
// its 32-bit accumulator on acc_o.
//
// Storage layout for weight_i (when NUM_PE = 4):
//   weight_i[ 7: 0] -> PE0
//   weight_i[15: 8] -> PE1
//   weight_i[23:16] -> PE2
//   weight_i[31:24] -> PE3
//============================================================================
module pe_array #(
    parameter NUM_PE = 4
)(
    input  wire                       clk,
    input  wire                       rst_n,
    input  wire                       clear,
    input  wire                       valid_i,
    input  wire signed [7:0]          feat_i,
    input  wire        [NUM_PE*8-1:0] weight_i,
    output wire signed [NUM_PE*32-1:0] acc_o,
    output wire        [NUM_PE-1:0]   valid_o
);

    genvar g;
    generate
        for (g = 0; g < NUM_PE; g = g + 1) begin : PE_GEN
            wire signed [7:0]  pe_b = weight_i[g*8 +: 8];
            wire signed [31:0] pe_acc;

            mac_unit u_mac (
                .clk     (clk),
                .rst_n   (rst_n),
                .clear   (clear),
                .valid_i (valid_i),
                .a       (feat_i),
                .b       (pe_b),
                .acc     (pe_acc),
                .valid_o (valid_o[g])
            );

            assign acc_o[g*32 +: 32] = pe_acc;
        end
    endgenerate

endmodule
