# The Command Lines that defined the parameter attributes.

set_param -param_id {REF_CLK_FREQ} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {FPS} -data_type {Integer} -min {-2147483648} -max {2147483647}
set_param -param_id {H_FRONT_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {H_ACTIVE_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {H_SYNC_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {H_BACK_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {V_FRONT_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {V_ACTIVE_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {V_SYNC_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {V_BACK_Display} -data_type {String} -validator {[-0-9]*('[BbOoDdHh])?(-)?[0-9a-fA-F_]+}
set_param -param_id {H_FRONT} -data_type {Integer} -value {updateRelValue $H_FRONT_Display}
set_param -param_id {H_ACTIVE} -data_type {Integer} -value {updateRelValue $H_ACTIVE_Display}
set_param -param_id {H_SYNC} -data_type {Integer} -value {updateRelValue $H_SYNC_Display}
set_param -param_id {H_BACK} -data_type {Integer} -value {updateRelValue $H_BACK_Display}
set_param -param_id {V_FRONT} -data_type {Integer} -value {updateRelValue $V_FRONT_Display}
set_param -param_id {V_ACTIVE} -data_type {Integer} -value {updateRelValue $V_ACTIVE_Display}
set_param -param_id {V_SYNC} -data_type {Integer} -value {updateRelValue $V_SYNC_Display}
set_param -param_id {V_BACK} -data_type {Integer} -value {updateRelValue $V_BACK_Display}
# The Tcl Procs that used in parameter dependency.

proc updateRelValue { value } {
 set tmp $value
 return $tmp
}