# The Command Lines that defined the layout and widget properties.

set Tab_Tab_0 [add_tab -name {Tab_0} -col_count {1}]

set Spin_Box_REF_CLK_FREQ [add_param -parent {Tab_0} -name {REF_CLK_FREQ} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_REF_CLK_FREQ -prop {Display Name} -value {REF_CLK_FREQ}

set Spin_Box_FPS [add_param -parent {Tab_0} -name {FPS} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_FPS -prop {Display Name} -value {FPS}

set Line_Edit_H_FRONT_Display [add_param -parent {Tab_0} -name {H_FRONT_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_H_FRONT_Display -prop {Display Name} -value {H_FRONT}

set Line_Edit_H_ACTIVE_Display [add_param -parent {Tab_0} -name {H_ACTIVE_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_H_ACTIVE_Display -prop {Display Name} -value {H_ACTIVE}

set Line_Edit_H_SYNC_Display [add_param -parent {Tab_0} -name {H_SYNC_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_H_SYNC_Display -prop {Display Name} -value {H_SYNC}

set Line_Edit_H_BACK_Display [add_param -parent {Tab_0} -name {H_BACK_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_H_BACK_Display -prop {Display Name} -value {H_BACK}

set Line_Edit_V_FRONT_Display [add_param -parent {Tab_0} -name {V_FRONT_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_V_FRONT_Display -prop {Display Name} -value {V_FRONT}

set Line_Edit_V_ACTIVE_Display [add_param -parent {Tab_0} -name {V_ACTIVE_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_V_ACTIVE_Display -prop {Display Name} -value {V_ACTIVE}

set Line_Edit_V_SYNC_Display [add_param -parent {Tab_0} -name {V_SYNC_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_V_SYNC_Display -prop {Display Name} -value {V_SYNC}

set Line_Edit_V_BACK_Display [add_param -parent {Tab_0} -name {V_BACK_Display} -widget {Line Edit}]
set_widget_prop -widget_id $Line_Edit_V_BACK_Display -prop {Display Name} -value {V_BACK}

set Line_Edit_V_FRONT [add_param -parent {} -name {V_FRONT} -widget {Line Edit}]

set Line_Edit_H_SYNC [add_param -parent {} -name {H_SYNC} -widget {Line Edit}]

set Line_Edit_H_ACTIVE [add_param -parent {} -name {H_ACTIVE} -widget {Line Edit}]

set Line_Edit_H_FRONT [add_param -parent {} -name {H_FRONT} -widget {Line Edit}]

set Line_Edit_V_BACK [add_param -parent {} -name {V_BACK} -widget {Line Edit}]

set Line_Edit_V_ACTIVE [add_param -parent {} -name {V_ACTIVE} -widget {Line Edit}]

set Line_Edit_H_BACK [add_param -parent {} -name {H_BACK} -widget {Line Edit}]

set Line_Edit_V_SYNC [add_param -parent {} -name {V_SYNC} -widget {Line Edit}]