
module dr1_phy_pll_bb3f286c4695 #(
  parameter FBKCLK            = "CLKC0_EXT",     

  parameter FBKCLK_INT        = "VCO_PHASE0",    

  parameter REFCLK_DIV        = 1,               
  parameter FBCLK_DIV         = 1,               

  parameter CLKC0_FPHASE      = 0,               
  parameter CLKC1_FPHASE      = 0,               
  parameter CLKC2_FPHASE      = 0,               
  parameter CLKC3_FPHASE      = 0,               
  parameter CLKC4_FPHASE      = 0,               
  parameter CLKC5_FPHASE      = 0,               
  parameter CLKC6_FPHASE      = 0,               

  parameter CLKC0_DIV2_ENABLE = "DISABLE",       
  parameter CLKC1_DIV2_ENABLE = "DISABLE",       
  parameter CLKC2_DIV2_ENABLE = "DISABLE",       
  parameter CLKC3_DIV2_ENABLE = "DISABLE",       
  parameter CLKC4_DIV2_ENABLE = "DISABLE",       
  parameter CLKC5_DIV2_ENABLE = "DISABLE",       
  parameter CLKC6_DIV2_ENABLE = "DISABLE",       

  parameter PREDIV_MUXC0      = "VCO",           
  parameter PREDIV_MUXC1      = "VCO",           
  parameter PREDIV_MUXC2      = "VCO",           
  parameter PREDIV_MUXC3      = "VCO",           
  parameter PREDIV_MUXC4      = "VCO",           
  parameter PREDIV_MUXC5      = "VCO",           
  parameter PREDIV_MUXC6      = "VCO",           

  parameter CLKC0_CPHASE      = 0,               
  parameter CLKC1_CPHASE      = 0,               
  parameter CLKC2_CPHASE      = 0,               
  parameter CLKC3_CPHASE      = 0,               
  parameter CLKC4_CPHASE      = 0,               
  parameter CLKC5_CPHASE      = 0,               
  parameter CLKC6_CPHASE      = 0,               

// output divider
  parameter CLKC0_DIV         = 1,               
  parameter CLKC1_DIV         = 1,               
  parameter CLKC2_DIV         = 1,               
  parameter CLKC3_DIV         = 1,               
  parameter CLKC4_DIV         = 1,               
  parameter CLKC5_DIV         = 1,               
  parameter CLKC6_DIV         = 1,               

// duty
  parameter CLKC0_DUTY_INT    = 1,               
  parameter CLKC1_DUTY_INT    = 1,               
  parameter CLKC2_DUTY_INT    = 1,               
  parameter CLKC3_DUTY_INT    = 1,               
  parameter CLKC4_DUTY_INT    = 1,               
  parameter CLKC5_DUTY_INT    = 1,               
  parameter CLKC6_DUTY_INT    = 1,               

//ssc
  parameter FREQ_OFFSET       = 0,               

// clk output
  parameter DIVOUT_MUXC0      = "DIV",           
  parameter DIVOUT_MUXC1      = "DIV",           
  parameter DIVOUT_MUXC2      = "DIV",           
  parameter DIVOUT_MUXC3      = "DIV",           
  parameter DIVOUT_MUXC4      = "DIV",           
  parameter DIVOUT_MUXC5      = "DIV",           
  parameter DIVOUT_MUXC6      = "DIV",           
  parameter MAIN_MUXC         = "MAIN",          

  parameter CLKC0_ENABLE      = "DISABLE",       
  parameter CLKC1_ENABLE      = "DISABLE",       
  parameter CLKC2_ENABLE      = "DISABLE",       
  parameter CLKC3_ENABLE      = "DISABLE",       
  parameter CLKC4_ENABLE      = "DISABLE",       
  parameter CLKC5_ENABLE      = "DISABLE",       
  parameter CLKC6_ENABLE      = "DISABLE",       
  parameter CLK_MAIN_ENABLE   = "DISABLE",       

  parameter WORK_MODE         = "USER",          

  parameter FIN               = "100.0000",      

  parameter FEEDBK_MODE       = "NORMAL",        

  parameter PD_DIG            = "DISABLE",       
  parameter REFCLK_USR_RST    = "DISABLE",       
  parameter PLL_USR_RST       = "DISABLE",       
  parameter PLL_FEED_TYPE     = "INTERNAL",      

// loop   parameter
  parameter LPF_RES           = 2,               
  parameter LPF_CAP           = 2,               
  parameter ICP_CUR           = 12,              
  parameter GMC_GAIN          = 2,               

//frac-N
  parameter FRAC_ENABLE       = "DISABLE",       
  parameter DITHER_ENABLE     = "DISABLE",       
  parameter SDM_FRAC          = 0,               

  parameter SSC_AMP           = 0.0,             
                                               
//fine phase shift
  parameter MPHASE_ENABLE     = "DISABLE",       
  parameter PHASE_PATH_SEL    = 0,               
  parameter DYN_PHASE_PATH_SEL= "DISABLE",       
  parameter DYN_FPHASE_EN     = "DISABLE",       

  parameter CLKC0_FPHASE_RSTSEL        = 0,               
  parameter CLKC1_FPHASE_RSTSEL        = 0,               
  parameter CLKC2_FPHASE_RSTSEL        = 0,               
  parameter CLKC3_FPHASE_RSTSEL        = 0,               
  parameter CLKC4_FPHASE_RSTSEL        = 0,               
  parameter CLKC5_FPHASE_RSTSEL        = 0,               
  parameter CLKC6_FPHASE_RSTSEL        = 0,               

//coarse phase shift
  parameter DYN_CPHASE_CLKC0_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC1_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC2_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC3_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC4_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC5_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC6_DIV2_EN   = "DISABLE",       
  parameter DYN_CPHASE_CLKC0_DIV_EN    = "DISABLE",       
  parameter DYN_CPHASE_CLKC1_DIV_EN    = "DISABLE",       
  parameter DYN_CPHASE_CLKC2_DIV_EN    = "DISABLE",       
  parameter DYN_CPHASE_CLKC3_DIV_EN    = "DISABLE",       
  parameter DYN_CPHASE_CLKC4_DIV_EN    = "DISABLE",       
  parameter DYN_CPHASE_CLKC5_DIV_EN    = "DISABLE",       
  parameter DYN_CPHASE_CLKC6_DIV_EN    = "DISABLE",       

  parameter CLKC0_CPHASE_DIV2 = 0,               
  parameter CLKC1_CPHASE_DIV2 = 0,               
  parameter CLKC2_CPHASE_DIV2 = 0,               
  parameter CLKC3_CPHASE_DIV2 = 0,               
  parameter CLKC4_CPHASE_DIV2 = 0,               
  parameter CLKC5_CPHASE_DIV2 = 0,               
  parameter CLKC6_CPHASE_DIV2 = 0,               

  parameter CLKC0_DUTY50      = "ENABLE",        
  parameter CLKC1_DUTY50      = "ENABLE",        
  parameter CLKC2_DUTY50      = "ENABLE",        
  parameter CLKC3_DUTY50      = "ENABLE",        
  parameter CLKC4_DUTY50      = "ENABLE",        
  parameter CLKC5_DUTY50      = "ENABLE",        
  parameter CLKC6_DUTY50      = "ENABLE",        

  parameter CLKC0_USR_RST     = "ENABLE",        
  parameter CLKC1_USR_RST     = "ENABLE",        

//ssc
  parameter INTPI             = 0,               
  parameter SSC_ENABLE        = "DISABLE",       
  parameter SSC_MODE          = "CENTER",        
  parameter EXT_USR_FREQ_EN   = "DISABLE",       
  parameter SSC_FREQ_DIV      = 0,               
  parameter SSC_RNGE          = 242,             
  parameter HIGH_SPEED_EN     = "DISABLE",       

  parameter REFCLK_OUT_ENABLE = "DISABLE",       

  parameter REFCLK_DET_BYP    = "DISABLE",       

  parameter DERIVE_PLL_CLOCKS = "DISABLE",       
  parameter GEN_BASIC_CLOCK   = "DISABLE"  
) (
  input            refclk,           
  input            fbclk,            
  output		   clk0_out,
  output		   clk1_out,
  output		   clk2_out,
  output		   clk3_out,
  output		   clk4_out,
  output		   clk5_out,
  output		   clk6_out,
  output	       clkb0_out,
  output	       clkb1_out,
  output	       clkb2_out,
  output	       clkb3_out,
  output	       clkb4_out,
  output	       clkb5_out,
  output	       clkb6_out,
  input            clk0_en,
  input            clk1_en,
  input            clk2_en,
  input            clk3_en,
  input            clk4_en,
  input            clk5_en,
  input            clk6_en,  
  input			   wakeup,           
  output           lock,             
  input            reset,         
  input  [1:0]     clkc_rst,         
  input            refclk_rst,       
  input  [1:0]     cps_step,         
  input            pllpd,            
  input            drp_clk,          
  input            drp_rstn,         
  input            drp_sel,          
  input            drp_rd,           
  input            drp_wr,           
  input  [7:0]     drp_addr,         
  input  [7:0]     drp_wdata,        
  output           drp_err,          
  output           drp_rdy,          
  output [7:0]     drp_rdata,        
  input            psclk,            
  input  [2:0]     psclksel,         
  input            psstep,           
  input            psdown,           
  output           psdone,           
  input            ssc_en,           
  input            ext_freq_mod_clk, 
  input            ext_freq_mod_en,  
  input  [16:0]    ext_freq_mod_val 	
);

wire clk_no_use;
wire clkb_no_use;

DR1_PHY_PLL #(
   .FBKCLK            (FBKCLK ),     

   .FBKCLK_INT        (FBKCLK_INT ),     

   .REFCLK_DIV        (REFCLK_DIV ),     
   .FBCLK_DIV         (FBCLK_DIV ),     

   .CLKC0_FPHASE      (CLKC0_FPHASE ),     
   .CLKC1_FPHASE      (CLKC1_FPHASE ),     
   .CLKC2_FPHASE      (CLKC2_FPHASE ),     
   .CLKC3_FPHASE      (CLKC3_FPHASE ),     
   .CLKC4_FPHASE      (CLKC4_FPHASE ),     
   .CLKC5_FPHASE      (CLKC5_FPHASE ),     
   .CLKC6_FPHASE      (CLKC6_FPHASE ),     

   .CLKC0_DIV2_ENABLE (CLKC0_DIV2_ENABLE ),     
   .CLKC1_DIV2_ENABLE (CLKC1_DIV2_ENABLE ),     
   .CLKC2_DIV2_ENABLE (CLKC2_DIV2_ENABLE ),     
   .CLKC3_DIV2_ENABLE (CLKC3_DIV2_ENABLE ),     
   .CLKC4_DIV2_ENABLE (CLKC4_DIV2_ENABLE ),     
   .CLKC5_DIV2_ENABLE (CLKC5_DIV2_ENABLE ),     
   .CLKC6_DIV2_ENABLE (CLKC6_DIV2_ENABLE ),     

   .PREDIV_MUXC0      (PREDIV_MUXC0 ),     
   .PREDIV_MUXC1      (PREDIV_MUXC1 ),     
   .PREDIV_MUXC2      (PREDIV_MUXC2 ),     
   .PREDIV_MUXC3      (PREDIV_MUXC3 ),     
   .PREDIV_MUXC4      (PREDIV_MUXC4 ),     
   .PREDIV_MUXC5      (PREDIV_MUXC5 ),     
   .PREDIV_MUXC6      (PREDIV_MUXC6 ),     

   .CLKC0_CPHASE      (CLKC0_CPHASE ),                
   .CLKC1_CPHASE      (CLKC1_CPHASE ),                
   .CLKC2_CPHASE      (CLKC2_CPHASE ),                
   .CLKC3_CPHASE      (CLKC3_CPHASE ),                
   .CLKC4_CPHASE      (CLKC4_CPHASE ),                
   .CLKC5_CPHASE      (CLKC5_CPHASE ),                
   .CLKC6_CPHASE      (CLKC6_CPHASE ),                

// output divider
   .CLKC0_DIV         (CLKC0_DIV ),                
   .CLKC1_DIV         (CLKC1_DIV ),                
   .CLKC2_DIV         (CLKC2_DIV ),                
   .CLKC3_DIV         (CLKC3_DIV ),                
   .CLKC4_DIV         (CLKC4_DIV ),                
   .CLKC5_DIV         (CLKC5_DIV ),                
   .CLKC6_DIV         (CLKC6_DIV ),                

// duty
   .CLKC0_DUTY_INT    (CLKC0_DUTY_INT ),                
   .CLKC1_DUTY_INT    (CLKC1_DUTY_INT ),                
   .CLKC2_DUTY_INT    (CLKC2_DUTY_INT ),                
   .CLKC3_DUTY_INT    (CLKC3_DUTY_INT ),                
   .CLKC4_DUTY_INT    (CLKC4_DUTY_INT ),                
   .CLKC5_DUTY_INT    (CLKC5_DUTY_INT ),                
   .CLKC6_DUTY_INT    (CLKC6_DUTY_INT ),                

//ssc
   .FREQ_OFFSET       (FREQ_OFFSET ),                

// clk output
   .DIVOUT_MUXC0      (DIVOUT_MUXC0 ),           
   .DIVOUT_MUXC1      (DIVOUT_MUXC1 ),           
   .DIVOUT_MUXC2      (DIVOUT_MUXC2 ),           
   .DIVOUT_MUXC3      (DIVOUT_MUXC3 ),           
   .DIVOUT_MUXC4      (DIVOUT_MUXC4 ),           
   .DIVOUT_MUXC5      (DIVOUT_MUXC5 ),           
   .DIVOUT_MUXC6      (DIVOUT_MUXC6 ),           
   .MAIN_MUXC         (MAIN_MUXC ),           

   .CLKC0_ENABLE      (CLKC0_ENABLE ),        
   .CLKC1_ENABLE      (CLKC1_ENABLE ),        
   .CLKC2_ENABLE      (CLKC2_ENABLE ),        
   .CLKC3_ENABLE      (CLKC3_ENABLE ),        
   .CLKC4_ENABLE      (CLKC4_ENABLE ),        
   .CLKC5_ENABLE      (CLKC5_ENABLE ),        
   .CLKC6_ENABLE      (CLKC6_ENABLE ),        
   .CLK_MAIN_ENABLE   (CLK_MAIN_ENABLE ),        

   .WORK_MODE         (WORK_MODE ),           

   .FIN               (FIN ),       

   .FEEDBK_MODE       (FEEDBK_MODE ),         

   .PD_DIG            (PD_DIG ),        
   .REFCLK_USR_RST    (REFCLK_USR_RST ),        
   .PLL_USR_RST       (PLL_USR_RST ),        
   .PLL_FEED_TYPE     (PLL_FEED_TYPE ),       

// loop parameter
   .LPF_RES           (LPF_RES ),                
   .LPF_CAP           (LPF_CAP ),                
   .ICP_CUR           (ICP_CUR ),               
   .GMC_GAIN          (GMC_GAIN ),                

//frac-N
   .FRAC_ENABLE       (FRAC_ENABLE ),        
   .DITHER_ENABLE     (DITHER_ENABLE ),        
   .SDM_FRAC          (SDM_FRAC ),                

   .SSC_AMP           (SSC_AMP ),              
                                               
//fine phase shift
   .MPHASE_ENABLE     (MPHASE_ENABLE ),        
   .PHASE_PATH_SEL    (PHASE_PATH_SEL ),                
   .DYN_PHASE_PATH_SEL(DYN_PHASE_PATH_SEL ),        
   .DYN_FPHASE_EN     (DYN_FPHASE_EN ),        

   .CLKC0_FPHASE_RSTSEL        (CLKC0_FPHASE_RSTSEL ),                
   .CLKC1_FPHASE_RSTSEL        (CLKC1_FPHASE_RSTSEL ),                
   .CLKC2_FPHASE_RSTSEL        (CLKC2_FPHASE_RSTSEL ),                
   .CLKC3_FPHASE_RSTSEL        (CLKC3_FPHASE_RSTSEL ),                
   .CLKC4_FPHASE_RSTSEL        (CLKC4_FPHASE_RSTSEL ),                
   .CLKC5_FPHASE_RSTSEL        (CLKC5_FPHASE_RSTSEL ),                
   .CLKC6_FPHASE_RSTSEL        (CLKC6_FPHASE_RSTSEL ),                

//coarse phase shift
   .DYN_CPHASE_CLKC0_DIV2_EN   (DYN_CPHASE_CLKC0_DIV2_EN ),        
   .DYN_CPHASE_CLKC1_DIV2_EN   (DYN_CPHASE_CLKC1_DIV2_EN ),        
   .DYN_CPHASE_CLKC2_DIV2_EN   (DYN_CPHASE_CLKC2_DIV2_EN ),        
   .DYN_CPHASE_CLKC3_DIV2_EN   (DYN_CPHASE_CLKC3_DIV2_EN ),        
   .DYN_CPHASE_CLKC4_DIV2_EN   (DYN_CPHASE_CLKC4_DIV2_EN ),        
   .DYN_CPHASE_CLKC5_DIV2_EN   (DYN_CPHASE_CLKC5_DIV2_EN ),        
   .DYN_CPHASE_CLKC6_DIV2_EN   (DYN_CPHASE_CLKC6_DIV2_EN ),        
   .DYN_CPHASE_CLKC0_DIV_EN    (DYN_CPHASE_CLKC0_DIV_EN ),        
   .DYN_CPHASE_CLKC1_DIV_EN    (DYN_CPHASE_CLKC1_DIV_EN ),        
   .DYN_CPHASE_CLKC2_DIV_EN    (DYN_CPHASE_CLKC2_DIV_EN ),        
   .DYN_CPHASE_CLKC3_DIV_EN    (DYN_CPHASE_CLKC3_DIV_EN ),        
   .DYN_CPHASE_CLKC4_DIV_EN    (DYN_CPHASE_CLKC4_DIV_EN ),        
   .DYN_CPHASE_CLKC5_DIV_EN    (DYN_CPHASE_CLKC5_DIV_EN ),        
   .DYN_CPHASE_CLKC6_DIV_EN    (DYN_CPHASE_CLKC6_DIV_EN ),        

   .CLKC0_CPHASE_DIV2 (CLKC0_CPHASE_DIV2 ),                
   .CLKC1_CPHASE_DIV2 (CLKC1_CPHASE_DIV2 ),                
   .CLKC2_CPHASE_DIV2 (CLKC2_CPHASE_DIV2 ),                
   .CLKC3_CPHASE_DIV2 (CLKC3_CPHASE_DIV2 ),                
   .CLKC4_CPHASE_DIV2 (CLKC4_CPHASE_DIV2 ),                
   .CLKC5_CPHASE_DIV2 (CLKC5_CPHASE_DIV2 ),                
   .CLKC6_CPHASE_DIV2 (CLKC6_CPHASE_DIV2 ),                

   .CLKC0_DUTY50      (CLKC0_DUTY50 ),         
   .CLKC1_DUTY50      (CLKC1_DUTY50 ),         
   .CLKC2_DUTY50      (CLKC2_DUTY50 ),         
   .CLKC3_DUTY50      (CLKC3_DUTY50 ),         
   .CLKC4_DUTY50      (CLKC4_DUTY50 ),         
   .CLKC5_DUTY50      (CLKC5_DUTY50 ),         
   .CLKC6_DUTY50      (CLKC6_DUTY50 ),         

   .CLKC0_USR_RST     (CLKC0_USR_RST ),         
   .CLKC1_USR_RST     (CLKC1_USR_RST ),         

//ssc
   .INTPI             (INTPI ),                
   .SSC_ENABLE        (SSC_ENABLE ),        
   .SSC_MODE          (SSC_MODE ),         
   .EXT_USR_FREQ_EN   (EXT_USR_FREQ_EN ),        
   .SSC_FREQ_DIV      (SSC_FREQ_DIV ),                
   .SSC_RNGE          (SSC_RNGE ),              
   .HIGH_SPEED_EN     (HIGH_SPEED_EN ),        

   .REFCLK_OUT_ENABLE (REFCLK_OUT_ENABLE ),        

   .REFCLK_DET_BYP    (REFCLK_DET_BYP ),        

   .DERIVE_PLL_CLOCKS (DERIVE_PLL_CLOCKS ),        
   .GEN_BASIC_CLOCK   (GEN_BASIC_CLOCK )       
) u_DR1_PHY_PLL (
		.refclk				( refclk			),
		.refclk_rst			( refclk_rst		),
		.fbclk				( fbclk				),
		.clkc				({clk_no_use,clk6_out,clk5_out,clk4_out,clk3_out,clk2_out,clk1_out,clk0_out}),
		.clkcb				({clkb_no_use,clkb6_out,clkb5_out,clkb4_out,clkb3_out,clkb2_out,clkb1_out,clkb0_out}),
		.lock				( lock				),
		.pllreset			( reset			),
		.clkc_rst			( clkc_rst			),
		.clkc_en			({1'b0,clk6_en,clk5_en,clk4_en,clk3_en,clk2_en,clk1_en,clk0_en}),
		.wakeup				( wakeup			),
		.cps_step			( cps_step			),
		.pllpd				( pllpd				),
		.drp_clk			( drp_clk			),
		.drp_rstn			( drp_rstn			),
		.drp_sel			( drp_sel			),
		.drp_rd				( drp_rd			),
		.drp_wr				( drp_wr			),
		.drp_addr			( drp_addr			),
		.drp_wdata			( drp_wdata			),
		.drp_err			( drp_err			),
		.drp_rdy			( drp_rdy			),
		.drp_rdata			( drp_rdata			),
		.psdone				( psdone			),
		.psclk				( psclk				),
		.psdown				( psdown			),
		.psstep				( psstep			),
		.psclksel			( psclksel			),
		.ssc_en				( ssc_en			),
		.ext_freq_mod_clk	( ext_freq_mod_clk	),
		.ext_freq_mod_en	( ext_freq_mod_en	),
		.ext_freq_mod_val	( ext_freq_mod_val	)
	);

endmodule
