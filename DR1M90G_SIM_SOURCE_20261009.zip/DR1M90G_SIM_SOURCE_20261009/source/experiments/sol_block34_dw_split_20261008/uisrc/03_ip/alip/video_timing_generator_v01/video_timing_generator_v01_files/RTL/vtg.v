//==============================================================================
// 视频时序生成器模块 (Video Timing Generator - VTG)
// 功能：生成标准视频时序信号，支持可配置的分辨率和时序参数
// 作者：anlogic
// 日期：2025年9月14日
//==============================================================================

module vtg_v01
#(
    parameter COUNTER_WIDTH = 12                // 计数器位宽，支持最大4095像素/行
)(
    // 时钟和复位接口
    input  wire                     clk,        // 像素时钟输入
    input  wire                     rst_n,      // 异步复位信号，低电平有效
    input  wire                     vtg_ce,     // 时序生成使能信号，高电平有效
    
    // 水平时序参数配置接口
    input  wire [COUNTER_WIDTH-1:0] h_active,   // 水平有效像素数
    input  wire [COUNTER_WIDTH-1:0] h_front,    // 水平前肩时间
    input  wire [COUNTER_WIDTH-1:0] h_sync,     // 水平同步脉冲宽度
    input  wire [COUNTER_WIDTH-1:0] h_back,     // 水平后肩时间
    
    // 垂直时序参数配置接口  
    input  wire [COUNTER_WIDTH-1:0] v_active,   // 垂直有效行数
    input  wire [COUNTER_WIDTH-1:0] v_front,    // 垂直前肩时间
    input  wire [COUNTER_WIDTH-1:0] v_sync,     // 垂直同步脉冲宽度
    input  wire [COUNTER_WIDTH-1:0] v_back,     // 垂直后肩时间
    
    // 时序信号输出接口
    output reg                      vtg_hsync,   // 水平同步信号
    output reg                      vtg_vsync,   // 垂直同步信号
    output reg                      vtg_hblank,  // 水平消隐信号
    output reg                      vtg_vblank,  // 垂直消隐信号
    output reg                      vtg_de,      // 数据使能信号
    
    // 位置信息输出接口
    output wire [COUNTER_WIDTH-1:0] vtg_h_count, // 当前水平位置计数
    output wire [COUNTER_WIDTH-1:0] vtg_v_count, // 当前垂直位置计数
    
    // 状态指示输出接口
    output reg                      vtg_frame_start, // 帧起始脉冲
    output reg                      vtg_line_start,  // 行起始脉冲
    output wire                     vtg_active_video // 有效视频区域标志
);

/* 
时序图说明：

水平时序 (一行):
|<----------------------- H_TOTAL ------------------------->|
|<-Sync->|<-Back->|<-----Active Video---->|<-Front->|
|        |        |                       |         |
|________|________|_______________________|_________|
0      H_SYNC  H_SYNC+   H_SYNC+H_BACK+    H_TOTAL
              H_BACK    H_BACK+H_ACTIVE

垂直时序 (一帧):
|<----------------------- V_TOTAL ------------------------->|
|<-Sync->|<-Back->|<-----Active Video---->|<-Front->|
|        |        |                       |         |
|________|________|_______________________|_________|
0      V_SYNC  V_SYNC+   V_SYNC+V_BACK+    V_TOTAL
              V_BACK    V_BACK+V_ACTIVE

信号含义：
- Sync: 同步脉冲期间，HSYNC/VSYNC为低电平
- Back: 同步脉冲后的后肩时间
- Active Video: 有效视频数据传输期间
- Front: 前肩时间，准备下一个同步脉冲
*/

//==============================================================================
// 内部信号定义
//==============================================================================
reg  [COUNTER_WIDTH-1:0] h_counter;            // 水平扫描计数器
reg  [COUNTER_WIDTH-1:0] v_counter;            // 垂直扫描计数器

wire [COUNTER_WIDTH-1:0] h_total;              // 水平总周期
wire [COUNTER_WIDTH-1:0] v_total;              // 垂直总周期

wire [COUNTER_WIDTH-1:0] h_sync_end;           // 水平同步结束位置
wire [COUNTER_WIDTH-1:0] h_back_end;           // 水平后肩结束位置  
wire [COUNTER_WIDTH-1:0] h_active_end;         // 水平有效区结束位置

wire [COUNTER_WIDTH-1:0] v_sync_end;           // 垂直同步结束位置
wire [COUNTER_WIDTH-1:0] v_back_end;           // 垂直后肩结束位置
wire [COUNTER_WIDTH-1:0] v_active_end;         // 垂直有效区结束位置

wire h_counter_max;                            // 水平计数器到达最大值
wire v_counter_max;                            // 垂直计数器到达最大值

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Cadence Design Systems.", key_keyname = "CDS_RSA_KEY_VER_1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
IchK7TZy1UjTldFBQKvtrir9TXyWj4Sk9C9ZgnqdV300vhcrvDTgo3ciVaINYLI9
W/UniFwsfxbhQAOmLWMoHdCGvE/D0v/rU154gx2FL9vjaSQPv3BkPDx2JLIvlfi7
GxpY9uX9VRgGJBUUp3wYOypgwKDKT7b/xX1SiP54SUuS7t3OQT1i5FyIG8jA9KtJ
+mPmDVfejg+QEpEIjJOMbNwM0tjyR5PQnKnlDWazguDH+Y4ToP7VPtSyUt2dqEGk
j+KLvMtZ4nqJwN9r/MhWmUyoeI1upxfFL9aouql8TjypFmbb7K/NW4pGCY6XQaNH
uX3BP0uR8pL7Gtj3RbZ05w==
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
aICOjhzaYHpDJU2i1ac0NQ9OxMMSD1YYgYpEM6lIcsXxGcKC1TYJkmlyWo19Iq5J
8nNO9/Ycq0Mv/K0/DREGGmhFLq3VFkjwUhWzuWeFYgKJ4oGUy+aHiCGzoPkPVAPD
Rs2Xl7jzI5WJIWk1fWCkUDEH4x0GFnPpC1REYUgyhrA=
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
CUwscRdWkmJLT2yKUFEE3waGju2vcQd3yiM3ohkhJqHIR3bXr8BSS67ymOk111QH
d8QN/I37KpnR3I9ox98ARYQwg5NvdOCOrZqP6la2RM5v70AT9aJdeRPOF6iMJzkk
vMlAZ+yKoTjtsm93biaBE3IqYIGSoYBKCgfaEYlPHZSLHGidb1jvno26QZiTjlI5
t0tV9+6WCfs8QMkuNX6heMDeABmfbgejYDysONOGsH5tuW0Ngnj3KKw1COPGLull
s2VO8E3T652uNnyoFZ/BSRUISbVy9zZmrOQxSZHDAt6Vgq5hQqJa6qUlkmKNk02t
S2Z3FuljoK40ez8eXesZpw==
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
D67oQysrLD4ZiT7jIjzZVLNK5dgfKT3jn7INYZ8SZHnnlfT8TNyNwPyy9dwE6OP/
nKXIWDs1uTdQyJE6TAS0oekZcowuPfEkzPtu0a1EsdpfTFr18ubkfwDCiVvOv4qS
ANPjcIbLkvRRpNWPcOeTFWa4yJE9O5+t95U9VNtmP8s=
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
qVMwMX8/Vu2ifCNiHNwRCeIOQXZtYP1/spJjbIIltMrWotykg9Gn7ck2uApTlwGg
9jNL58n9Vj5KFHU9Kpv8yOzNwvCqZG7uD++roJwRj0w7l6SchLS3OmpulTmQWamG
yue1SQeHBquzeFDGb5JMvApqOe+MDYw1rP93C0lwNrY=
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-009"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
ldeLS7PWezQy4zk4TW9KnXMqnoYSQo9U1P0nDeuzG675jof15drVswyLTbmSCvc8
S+Vjomezsw9ifDu2Xekk8DgeIWL9TU5/z6VadNeDyAPYvmoBZEQ+QgQIt7+GEx7k
gCgHBJP79F0GzJHZNA5GmrVXBaOPcO9/MYvHMrkwEOA=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 5440)
`pragma protect data_block
87iqAttXDfHW7dA/sEQgFL3eDTl9WZYnAGs89KR4tywqAzNAoWI/e7Qo+I1clarr
DkT+3mQ0FK6ujJdu3k2QMveg69SLwAs2On4KsWePtRmaFvIVvw9ESmkqQMfF2emc
8Wf41i7EQp3eX8KNzlZWYJXxZRTsJZyFrnmCajvWaOHvcV2s3gURrKRl3PCoCjnw
Phue6I1zN9Wvn+TqXx5p1ZO0Pr4aCzK2/loZnLxEiuCpCocPU/WGaQQYn+P2DaW4
wISDIdpagkl/Xqm3LcD8TgoCuDujClPCNAc1D6vWmIdDXesqaJlvsp1cUx7nUw9m
yzsPJ5GbowvSyEblo7Ewm8F746kgOoLjeYpJvGcwvZuFWw0Qs794SwNHhraXo9z2
QdLB0i1NStSO7S29U6NYnuxR+FHVJvXYEfCXfp4aNUEiLKquuCRCkJTPYu36INw/
qCv/FVA01tFIJdMOXEjhlBQnVOJEeFtU7XUS9MVft/mQ4G2Hk9wNh71etb8uxH4q
qlGAuoTtajTOyKxZjfrXm2V2h1obLu3Bh8GK3SbjMvP4k1jAS3blCCochWevlG8e
uq/ZHqm8rlPcow1j7kSk/nhnzMl00r1CANJk6BKMhqqnOQxVzrFVLwU1psTAs57O
LMOzRFbfBTXwPuUTjKGUeX3d/riOLP6pRBrRTz47gESSWLACv5nBrQOg3dJTGGEm
jiqNfTxH7dkxxafWY6QHLruOocMwjh+NpKFXWx0FSLCvASq2F0wInlOKwrOEayjP
1gmf6ZZ5V6CgiP4pEpKCDh1ECenMVYUi2Y/B+y5GCIamV19o1J5Kbc/SC+YSWOMc
IHlDdP1+IOWvpgN7PjXSMqY7+CMsYWS0ebXGelo1Ghe5dDcY7ttPcHPiPEbxHJpp
fCNolEFh81rcTMoM3Y4kLn1orlHwxBQfLALXBVLk4bJOUSNRXQ1gVS2+cP4wtHMa
xKqm4WXnu2aVYNvyqzrAMEhohfxq+uvHYqgQF4SwUW2dfE1yccUm/b3niB3MLDqv
KDORfnIC2toAJxqcENDeFmqOPKPZmm3V2PK/fma/6DhFCZDZ8LMQDsZvTMSqJwuE
jWvDxRhZ86NoBFl6aujRFoNs4hytFja1lJh6GK2HLp1RNJ2m8TykXwYOzvxnXq7H
dPh0tE+A47d00oXEQnwKKlH2CQoIdpNKkxEikPqA2VFfbYYHLaTfTsnf5ZGgqapj
uoR4iV3YlLJzq5+CtCW58wAYe2cPNSit10hA1gTqOPutjoNoYeyDNQxoWxK1ukb8
W94mYoGdwPaYm5jHaUKAFFyGV92/MVk+ZubmTq916Upl5xbWoje5ZF3Z5KE+pIoK
VD3NBIRJmTyxKll17rL1A92ZIscJQrxx1iameL6XMGJadux7C5nt2wnpvgOmxWwX
k8DUyvMkKWdEuZLibzYuawejrfJg5FNbERqQ8vu1wqoKv+pUDcPUMevquyJ8LESa
QRbu7IoYqiMmevQ3+u/DWRviuWfc41Opw21tilIbjJuvXsmPJW/+rFcWLviN3xW3
21jhXcDWUccr3RW31PwOYN9nGh71DIYY1ReuFW4ECmNo/Eg/AmWQMhEqopZgmMZQ
ZqE+JVZMbMsVaxlP278oyWhmJpb9UFic+MHAuwwU8/2KFsj882GoreX802mPlO0T
Zn34mAnjfuED0ahOCE8oZDUZ2X0VMM/6hdSzVGtuPX/TRCGLVCRLdkL1KvFHnHjH
kzHvlL2puKIpZ37QNCRVsR6vPDsQdmhL+fNt0+gSHMJkh2Uc5mmYzaPlOpGzTtgV
FVEhpPMNmsr32YixZYTGJcwl4FQeknMZ4yzLDyquYj6JG6Z8f1PoVdtzsR5lNYHu
Avw7SOn0bRsj8Vo1A2fHQwMjClOMHBkacmfaHqjhvRsTwp+926Mx1eQWwgGBD1em
U/wtUDKQ3wNTslOc8cKwO4HOTKbDILSqdCpSbrGc+Setisk3n2sr5AS7oixjI+2J
XI+EIuAHwrdvyjsFoVK193a0tw129Z7JtY8SCgJOtutaSmXNpo6064CcqC8aSfEq
B1Ue95I4O3UE3UqYugpxZEvQrrdufI1OFV9wS7e3Rna5Dbb1Dr2APS/N7kaGv2Qu
evVhvQn5WWUG2GEzId5WlguspS7bCfySJGwlRP7q1u3yrKtbNNnK6dL0VWC987QL
+22/uQF5qeQgB0Z/hc2kMw4rciOuUmXrFF2zoJLeAQhASPYZRO1FjNsUZX3vm4Pt
uM6HEvZcfmS9fJ6C8sY1DF+FcfwNMoEMy9sT69rrwKckvvEhC0mej6/EtoYd4WYQ
SF77h8KAsjtj/1r+j3fUZw9pHtSU29GccFfqQ3H6X640IhMQCO2/Z97QXZbASrg9
pFVJZ1f8cu96eZERce58fzhqNw/FNuHSDWRkZRak8wLD2QDSVg8qymur0FU0sd2N
rQ22Vqzc27Zp0DXeyOR9RP1ec7p8jIYRG+bpntMhSOkBV/x6IdwGnZ8o1wNZpJTX
8UMe0gl73wtQLmsULzVpBS26S6wLl2nOeug5dndCnwNpALOwn/Yql7IBjl+fX0d/
T1NBFNc1il+Ff/jQ6M9kkcW6DOjEpV0vXmxkFKzWlwPmHKJO3Wwf1+69CJ+Xy/kZ
FWpyyaK813QxsHMpjtp38yDBAz3FO3wqWyGAAUNeDHPqpxwk51a7qXJbD8q3IZOo
SWnB4ZrxoY0GjHSQIB3AsF/zjhhX9eOYCWOwk3tR+dWoBFkE2gUysT1g837qRe2P
SBQTCQa9yKEQqqySa0ii2QVejm56zsBPKIQuD+Y33Rh6IzEljva2vqPv08LDvpJG
kommZBP6sK6ke8lD2b00aUgqM6NUBRVxHSKLhnOj6ux6JP3GbCkfTPuNDcd+b2tx
RkRKR/lKkXfRriPQJPW85qpWaEG5CUxMFmU3cK9fUE6gOYA2XaivAr0Hl037lsMZ
CnMdTiPcnbBr5Pt+kKKTzOWyifW3jZiPuzKtPjxka+SjRFV61mMTEAu4OgHJeaNb
OdleO97EtzCepX/qCcbwvdS80hgBTnXRFaenHW2CS0y4HA1HTVkdBgP8us0bQgrP
TCczxxNbJ9G5PyQlP8HO4XmbK0IgewN4E1eblPYqJ8TjWsBeyfFitMg/7RusG/7b
uL7tLaWxk/ocTPPRLaXePZJPMr19ifDHOLd6EdFRJPaWciVQbAZW1jUN4bJJb4vU
eBxe7I9srg7KUmsSQ8mDVv3y98zvG/EJNm0UIwa0OHM9i9ocYth/UBUw+orGUMj+
KboFNkDgShCYUWarWgD4+JZn+9D3xWSoIWlJ7LFuoUiMUj5T5SEHNerdwz9BnLK4
GLd4zLYUNZOFz9Yxrqkrc8NSm+tKE8wUrznCPm+J1JhWBc0PjEdsOKrKFDO0w2bg
PmyjTvnKa/dbhS5eQJWC/nsjyb+eGHX/vVT3loIdKNEevHy9KKW462U561w3ysbX
MOARxealh65eacDDAhOKtF64y/pEPjiTioAyrsdjJ5QT9h/esXCK/OGZSPN7kS6L
pUx3vxsYCdI684o6XDQuH4TfEZqQAdgK9fIIns1V4+w7zlUowBXVlmEoFXUOJhLY
gjhzsymOS4FE/NIDbzFM+bF6VyPEAY+nAqXgUtmZor/Vu/O+sB5lgLJWwzwmKAbD
lu4eMzjE4PFD9xZ8uv/xd/j6ab0HoTpqnXVkvAERDyGkqTXDpu6UUdIjOvIbq6IC
BDcg4//Q0xg62JhD6+obFFrheUky/Cs77tZLjVRYxyZi00HczYmkgiEYymZKSGtd
1pvHdczZeNXpjR36A6rBGm20ZUFcMOyZ6MB1XPTU13zuzu3EiaZFKjhlY01Zjc3D
eHX7QBmIqeoPKCvftfunHAnGpS4di9vTmCpeOJYii1rjXTeW16Xhvtd3wjcTee5p
dzl1TBwFzFia9vGWvxrTgHoxNhaJh8yET4qySaEJEaCNa3zFjBrV/M9D0HlGbMQC
yP3Dnm7Gw3yDrBlNcDiLeanyTeS5bsE7OWYjHr3+gbwZuNlX2HEwuwpzX3l6skCn
fN9tgaW8KGGplbQqY0AC0PD7QfrkMdxe4alkdLl94K7FAPhCGP0F3BQ/hm3ek8cW
62AT4ewlGbxzb8BdJn1+Oc+JV/YHDO/UcAcp/IeeQLip0xWf/ayXP/BegRX6Ejde
k1shy/LfKp6CW8DTOC1zirQGK4m+GHW1jF/54mwt/tyud8xm9EYFRY+Eaijwcq0U
cpveQhRLWhCpT6OIYVn1L6pMHeuhRnK2/dVf50OGeosyVan1YXgyehsU1LCt6x4v
FgVOSN7bph8qlSMR0LlrmT/mOj7Q3rsEYKxAHKXEC0togPwetXCJI/v9+0Afnr5S
6zmuuSZF7fsWwAR7uASWeFmU3+ZZ+6Oi5CBuhmAKBn0CWGvxwUoODR6FXJ1rTw2r
eRAcVePf+qJ+IHfFJoZo+8jyI/Xz4r3jAyKuNWJAXqbPlu3nF1IsKOwPIq8VcN9V
ATyl1ywmWMqMeRCiYvjGsEJ5yQFYLPOXTbC3ldT7GyLf3zuSeEUJv0SuHIwzo3rR
FZaIzCQLcfrdiOEV842a4tNAPaRTZscl2it3Uv0A2Tl/KYaQhBbb6MzIJthIa3Un
9+23wv3vLh4XllwnfTZMlAyhsMCuro8HdafdeQi/DJ3OFGGXlLCczFW1nRZ+fI7j
v+4xsxsLD1F4OPCZ5lVGyRuo+xD2+NgiZDGQVbLMs5hOu+BWdqeUra91Yj8SoRPY
3h9i7ldtSrncBmLTB5MiBFdXKMS0LM2S+lNH3hqNElBRI24Y5/muO0x/fgdIfclf
zMuKL/qE6923QTfb+trMl/C99XBBdTKgT4hXfxVR2Hz0XE+/WvhOZSf+22mJ0fyr
1W+UrpGq4TOd09268wc3VJI63KH3FkEjxFnzgii2lY0uMV0plMIoNsuFeTNskJbz
mnuHZ7c1ziVcxxxHYiPUCg+odz+kwTvReuRaXX5aeN1jyhmTQjmJN9YWhz6OU/cX
XE5Ll82ScVPXShO4krMpBZWdWjF5ZbfmceWgxSafOXimakUT0dy/zhc61PRjJxTf
VSHaZp3hWxjmzvyT4lFES9Lzwx87q/ERlOZP13lNwISdmgAuvcznSHJ8EsgMZf/Y
kI4Kl0lh2fO5hNMwHIGN/RtyyZczsNZ5ccPP3dW0OY306N90ccNzT0n2Q8ksVF2Y
MX3GFSyUiRw7KPQZP6Yy8ckd3Top1BxRUsHQQZW51FUoE32x32kOJw225YcvUodO
6D1hq6XLb5HBfeEPlbzNEQDDMwe5/NxtstPw+kW1B/R1xVSDkkALKY3h6iIrfUnC
YqxUaq4wzWdvbsFej6bxDCnAS6lMfIsP02s982K5ssAD3Mz770Oi4av1Fz3WLMhC
y6Ho0rus3cDdRj8ujR8HLadZMopeMG5vlzjYxy+HULRhipw7rxN0yDRqriV+OAdi
gc+ZmTWWtV4UTVXTmZJPCSH9XDqpR9jTrjst2ICNr0QbjwCZuUrdepcL33Dm9g82
UTpPP/L8ZKg1heAd/eF1/6Vt/sM+kvLnKD2QAHH9CwzC8TtEOydgHWbeqR0CYqLb
H7CoyK5Wduu0REOxnfee9xoFepQ9x7h6AsBTulelZ0zc8DRwbZ4wL9ZbGdarHvK4
VoZu5/mN0JfvGqPow5w8p9yLTcArjb4YVFenWwh9jYYHkgtzL9bzzvlwbPIMhOEU
2h5jewugXb+vGo7yQSya8JuzMzZF+RFu0JAQ7k50RCGnbHXZk7Wse2rMrAgpIdzZ
bF6RfmdmA6LXf3zICpn0UVsH97bGwYjKX2C4BH8q3uJGU0o9H4QHJ+fMyYKg4Sx8
K8bZl3kYloKIHpVZeUnkP8kySpSSy4/mu/GBuwoZnUCeIS1KAhTpxUPBF6sPCP4L
fD9//ev/dD5jc8Pz3hxSDXoxsFyQNxU3z5DJw7WRic0+QOaCDWGz4KDL8HZ51PH9
O4F4YFBYrK6mf5/zxIAKal7oz8UBfmtUpGvLVfckGVcENzktE9IkCwGt2nj7CFxb
WsLslj9gjAs2cUIB3YPHcr0NJRBrEJ24t0VsIuZk9FFgQ7GcYDTAIHn7BVQketm1
hi2QBCbk7uZed1v500YOXpXdPK/cZDgIX1qvPM/dZxmmjlvECFtLA8TXmEC5aDho
zusF9n6zsLALejb/YCj/WApQofpgQUt7kTkKg3Zb9kPZ+luSmhTQoWqvpwLNhex5
LlomY5picC4aIg1PjeByg6BwsnxBbw4BBBG8tvkAxXQcrwslYHANapNm0WfNR9iI
oG2ymRl97lF9GYecG/jdINvRvaUzvgjZoNCWCPLPLidzeI5oS4X0gLu0+KdimwJw
/NdHc1yuxSGsS1jr7MPxUg9QfJlNYflJgssjP5lgwiL3uSnHIy+bb2q+DBnB9BHI
tlYR7snpKeVgRe2eEh1MgsoS27jS6v5PgcoZeQu7l3Bu4kRBlQELQa3q/CcVKtSt
QoMRK8NLGK9LbJWWDQozjYoo+adgg73vdp/8E4cazaYkac2tD3iEePAirEYn37zj
t+kf20EYzObcuUHj8Mx7GA/+88DlmSDwtBl3cNLamCim51NLY3GYPHX2hOh0avyO
HkLU+KotwSy5o/Pn7RsJ5oZL6mEJrVhsg++NoyfZ+ulUiQwgkcBB5VDt4YBTTUj3
3LFVDbJAaJCgvLfnsuBRY1V1MAV27sCMnWeFFkqnACHDPGLNAHMc7jgish9mBEi/
VL35/8Vdtees6+FLysjOPgCHbGoub2radQxG7qYEIjWB7mQgWVdPrO40wxLqar/g
CtkAkm5ZLkvU6+eJ2bZJNf/AZUrMgkjOIG/GN/MDxRMCFOeYG4cy8FkEAm4DIdY8
VKmKMifpxabH3SEPeQkI3rmjfp4G0kJ1YmF10o0CSo40ND2cLJCMg96sLxHHNDYp
8Q65Ng44RruUBGVp/n6nZQbfqJ0QhWnYfB88/sD5ZSmn6wa3ay3HDz1p00FelubK
zZXgR6q4GaVEPsKYqsJ+FgPnZUkoApDEv8KfcAVXi8OO0mfia8sSqg7Seo9jK4SU
6ujDlculSaI5GQT1HchSKoPlBMa3gsJDbvslIgiD3DtdQ8urC86i9EG6YZ+X07RG
K3aMgx+RyyaZpD4IEPdBMUtYDmGS6qaDrEk8HgsPV6CftFh6x02Vq4ZIMYliJQxd
RC6VTwdle00qIvMC7H16hjMtAipzVsVZ5tCKha0fstS/fm9knXJrrOt1e4y+jwBU
SQF5VpaBcIRD7IaZi7Ydjw==
`pragma protect end_protected
//==============================================================================
// 时序参数有效性检查 (仿真用)
//==============================================================================
`ifdef SIMULATION
initial begin
    // 检查时序参数是否合理
    if (h_active == 0 || h_sync == 0) begin
        $error("VTG: Invalid horizontal timing parameters!");
    end
    if (v_active == 0 || v_sync == 0) begin
        $error("VTG: Invalid vertical timing parameters!");
    end
    
    // 显示配置信息
    $display("VTG Configuration:");
    $display("  H: Active=%0d, Front=%0d, Sync=%0d, Back=%0d, Total=%0d", 
             h_active, h_front, h_sync, h_back, h_total);
    $display("  V: Active=%0d, Front=%0d, Sync=%0d, Back=%0d, Total=%0d",
             v_active, v_front, v_sync, v_back, v_total);
end
`endif

endmodule
