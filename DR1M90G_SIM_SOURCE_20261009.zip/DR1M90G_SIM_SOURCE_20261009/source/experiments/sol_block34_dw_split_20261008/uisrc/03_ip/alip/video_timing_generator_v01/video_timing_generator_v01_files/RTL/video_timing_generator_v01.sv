

// 使用axi lite接口配置显示时序参数，生成hs、vs等信号，一般用于对接vdma和axi stream to video out实现显示器显示
// 20250810 初始版本
// 20250910 增加axi lite接口，实现动态配置视频时序参数和像素时钟
// 20250919 支持通过参数设置视频时序、帧率，以支持非动态调整的模式
// 20250919 新增vtg_ce信号，以和axis to video out ip 配合使用
// 20250919 更改ip名称为video 提名 generator，暂不支持vtc的视频时序检测功能

/* 寄存器分布
index addr    purpose
0     0x00    h_front      (reg0[15:0])
1     0x04    h_action     (reg1[15:0])
2     0x08    h_sync       (reg2[15:0])
3     0x0c    h_back       (reg3[15:0])
4     0x10    v_front      (reg4[15:0])
5     0x14    v_action     (reg5[15:0])
6     0x18    v_sync       (reg6[15:0])
7     0x1c    v_back       (reg7[15:0])
8     0x20    [0] : rstn   (reg8[15:0])

...

16    0x1000  pll drp [7:0] write data, [15:8] write addr
17    0x1004  pll drp [7:0] read  data, [15:8] read addr
18    0x1008  pll lock  [0] pll lock status
*/


`timescale 1 ns / 1 ps
module video_timing_generator_v01 #(
    // 时钟参数
    parameter REF_CLK_FREQ = 50,      // ref clock时钟频率,用于计算pll的分频系数, 仅支持50和100两个频率，且输入必须为整数
    parameter integer FPS  = 60,      // 帧率(Frames Per Second)
    // 默认时序参数 - 1920x1080@60Hz
    parameter H_FRONT  = 16'd88,     // 水平前肩
    parameter H_ACTIVE = 16'd1920,   // 水平有效区
    parameter H_SYNC   = 16'd44,     // 水平同步
    parameter H_BACK   = 16'd148,    // 水平后肩
    parameter V_FRONT  = 16'd4,      // 垂直前肩
    parameter V_ACTIVE = 16'd1080,   // 垂直有效区
    parameter V_SYNC   = 16'd5,      // 垂直同步
    parameter V_BACK   = 16'd36      // 垂直后肩
   
)(
    input  wire                 aclk,            // 时钟信号
    input  wire                 arst_n,          // 异步复位，低有效

    // AXI Lite 接口信号
    input  wire [12:0]           s_axi_awaddr  ,  // 写地址
    input  wire                  s_axi_awvalid ,  // 写地址有效
    output wire                  s_axi_awready ,  // 写地址准备好  
    input  wire [31:0]           s_axi_wdata   ,  // 写数据
    input  wire [3:0]            s_axi_wstrb   ,  // 写字节使能
    input  wire                  s_axi_wvalid  ,  // 写数据有效
    output wire                  s_axi_wready  ,  // 写数据准备好 
    output wire [1:0]            s_axi_bresp   ,  // 写响应
    output wire                  s_axi_bvalid  ,  // 写响应有效
    input  wire                  s_axi_bready  ,  // 写响应准备好 
    input  wire [12:0]           s_axi_araddr  ,  // 读地址
    input  wire                  s_axi_arvalid ,  // 读地址有效
    output wire                  s_axi_arready ,  // 读地址准备好 
    output wire [31:0]           s_axi_rdata   ,  // 读数据
    output wire [1:0]            s_axi_rresp   ,  // 读响应
    output wire                  s_axi_rvalid  ,  // 读数据有效
    input  wire                  s_axi_rready  ,  // 读数据准备好 
    // 这里添加用户端口
    // ....
    input  wire                  ref_clk       ,  // 输入到PLL的参考时钟，需要与驱动中保持一致 
    input  wire                  vtg_ce        ,
     // 时序信号输出接口
    output wire                      vtg_pclk_locked,      // 像素时钟锁定状态
    output wire                      vtg_pclk,
    output wire                      vtg_hsync,            // 水平同步信号
    output wire                      vtg_vsync,            // 垂直同步信号
    output wire                      vtg_hblank,           // 水平消隐信号
    output wire                      vtg_vblank,           // 垂直消隐信号
    output wire                      vtg_active_video      // 数据使能信号
    
    // 用户端口添加结束
);
 
    
localparam REG_NUM    = 32;                   // 寄存器数量
localparam DATA_WIDTH = 32;                   // 数据宽度
localparam ADDR_WIDTH = 13;                   // 地址宽度

//==============================================================================
// PLL配置参数自动计算
//==============================================================================

localparam real REF_CLK_REAL = REF_CLK_FREQ;
localparam FIN = (REF_CLK_FREQ == 50)? "50":(REF_CLK_FREQ == 100)? "100":"50" ;

// 根据时序参数和FPS计算像素时钟 (MHz)
// Pixel Clock = (H_TOTAL * V_TOTAL * FPS) / 1_000_000
localparam integer H_TOTAL = H_FRONT + H_ACTIVE + H_SYNC + H_BACK;
localparam integer V_TOTAL = V_FRONT + V_ACTIVE + V_SYNC + V_BACK;
localparam integer TOTAL_PIXELS_PER_FRAME = H_TOTAL * V_TOTAL; // 可能较大, 对1080p约 2200*1125=2,475,000
localparam real PIXEL_CLK_REAL = (TOTAL_PIXELS_PER_FRAME * 1.0 * FPS) / 1_000_000.0; // MHz

// PLL VCO频率范围约束 (MHz)
localparam real VCO_MIN = 800.0;
localparam real VCO_MAX = 2000.0;

// 计算最优PLL参数的函数
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Cadence Design Systems.", key_keyname = "CDS_RSA_KEY_VER_1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
LUWbzpcSfeLSNKNJsKJGQ+t3sSAJPaMw8bBslAQXBsvGWnA/IfX47d2KQcRM886a
YqsZLnCv7W+dXdEkS32o2o3DkWVUB1+mnaqKIBWWJenGXAq5x1GC18N9Tvp2UzCH
TeI7PxEf3FPl+lSEnABn32JwJnguXsOVfaIsZoNpUFpArJLUGuzCSV5icT9ny4z/
FfVJ5qrI/VnEHdWKFKdjcTIv3mkQaahnW6Y2vVIvoY8l87J+hoQePSnaKlefTP+n
Nk0OLymPVtOSQDddbz1LNDi8XiAlp/MjHcsimgxczIMp5j08IXc2Y0CZF15Oma0a
iEHx+325H9eqfblr+7u1qw==
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
eZglypsMcbGVMxlNNrlilAmTHr6qHhPf2ulJoC0e6YV2RbqefmQZUZA3ka2m8kg1
52eFICxITOIXvXanP+Yj7vbHbnR5IpdfV9G9RLg9PL9lD9DXC2fGcpTbWW/P7P2q
SqRdCSx0yDCuJCL6ZTwEJW3CesTWG/WFOCD+IA6fZ2c=
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
quMAoYz3F/g47rJpe4/u8XwbMeIq1GCBFyoNONFs64k7A67AjqmXGO2bgQo296Nh
P8BnqRyINwYkdNdiVnxL+RI+e7s8Ke6UyP3XMUkstzR3yV1sq2CMsj39Q36TUqGn
aLEL9xC+s2f+qkrroA626F9zFrCygMh3aQe1vvJ62oXH/Ntzk6XOvP+zGLy+qApB
ignQ7VBkEi1YqR4b7KHx/fIEpES2tXd+2+ckhSvFvjLxhlyT943yIObAMoSQXckk
I2VShso5Ab8Ps+x7OJg3r4AoN32TkQr6CG08vB+VyJ8ztg1wSM1vrnstDcR8Z4Ow
7HMDVSac6KKVay3llehD/g==
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
HbScWG+mkXugSVBtsDS+qQ2pQTgZQTIe7qaQxDmeqRAwRtVXlkKgpbSaJTrkYOcQ
t4JJBRcNjwy8kNpL8TwHeNeXnumksGWd2pkOhx0HZkTceuxlo4lU2EDjx+qODRn5
+NoeQ9ln4fwuEaJdy+eiidnyXBB3CyxqZ0y5xuwnwa8=
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
rCe8fnjZJ+ewU7c4wFy6WUhJuXnGUQaTTEbCDDFJPcu7LA0/aRVuFLp0MMUp0Zt6
eqcIl8G0jW0QMjeEeuy6CGQh6gKB4j0UKENMeuGLRCUTbAFNt+SXy7PLkOq5qPZM
AIT4qGJjHwNU5GORwkpq9okNG971hUI0NRyFWGdP7qw=
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-009"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
Z01DptRjWhyTBX8o2koWLnWqx0nr4Cp4pw+beuzncIm29FKYwPcVUrjxXe5CiuR7
2JQL8S2fU/AcspbGhFboiu0MlIi7ly6VhsL9BBP65U9PQtZ8umb6/yjsU+SzpWW0
Y0bJfGichctnapxhzMQzZH0V/M0VKsRLaVjE/ZkD1q4=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1840)
`pragma protect data_block
6gH0AM64svJifxiVIyor4LLIp70u9Vz7l6k66mn9h0XznP5GpTjYBzdLVWZIhVw3
gdqnvl76OZbnsTvL9ZeMf8I5z3uNUsCCPCGaBTA3HU+hfvRPAv+9NPfBRGbE7hNl
PtBEd07VaklvgV1PhXH+Cwps0PbDNTeRAbpjVhRuPMfPYIWzjz0Q0JcfTe8mteA3
mRt+4NI1fBxec9z/lBu81Nxon3wuljuDhcAIi15xpuPzcXtyLojdKJxAhroC2DTu
InBXn0YhL2jnSNMYxjGaz4yFYZOjHizxODSvYjip1u4iWdSgD3NDs4TsysTaUwkH
+DMi6WWry5PzZnz/FkSHnA7tfMxGdgsQM44EagkVBPT01MJSDPVrnWoWgR0EACzL
NIvAspLvc15j4Z1EfcB89MC6aWi+ccP8IEHcbiRMbN4AwK5aMu95HXcMYjkX4LHH
A8XnoSAzjt5gx8SxdhyHzpx9POAB6JLfvDo65Ia7FGkmLus/s2SGoF8E26fBdFx6
GZGIzxr7rwkkLhMsyuS8FIySZXnJYJ9J9CdaaRUgYb0hDP+qC4D5Fyzr2oiDyDSf
TC9XJlFMBwa87OAoraUhp+1WKj6hzCSzcFf5fZUoa4JkjOQu6YnXiYFg2F0rAaaZ
9oJnbB/DBtUZojrvaXZMStaWpvLmssOVlt5nr+oEm+XlyZ/1+sAtgGmDKG+C4k2m
jCIlY+qihX67Nrk6/UVERx4YTzGhchP7jV1gpGx9C0McSUsI1mRL39JDdWNyGGia
vCtJUZEfMt4tWlO+MDX/kOoMkWV8lbepoocvopoDq5McyAufy88UzX6YoxSCuV1B
cuYCjLYzNJ/AjzVZeyXtu+ItozYOjpS+lf+rTJqaLlhtAJ9qQ/aYkypb0DGFxj4b
nYlarMj31qFtnhrEmm4nJgXb/lHcr4u5t8QEB2jYqR0BBMlc6LUlQSP9TwBOrpN2
zqFEk8TQMCOFMnbMcpvis/YPovDglFHDc6EKKOWkyP124ALQ0Y6Nl9IM1FX4vfTp
ruGzgK/W7wuVZmZHSdB7V3Y56bEyYhaIV3qPpNu+XWKbWBNICssHBgyu+sb/QYMW
8yDllN6zdAafxXq20gNPnu0mmfVTYsawELTUbJt5yxvNRm9En61fAK4Mx2fcB5+R
GalEJ/UrA1LqGD07opTkbx8PAlfm4c7ztcua15kBbyDOhRC4qMmlXcnYzJ/gjBB4
439p11cAkr9raZnU1PTMRuo5PdZtUcgI6XhT1BzBjttWueRd5BLI06YygcdA0Yow
UszW4ASgi2NV0PWW89GY7w3wWjbc7Qg1V09foSGgxe1NqDMjiCEQWL4BuV4kxuuW
z2BHG/NkefPTRuKoxDxuAz6rcSEVtonxvsMU1RnytiLkPDsCKYdiSwnsWIq+tl3m
TsaY8WSPjM6DNIfXgI6qrHmFrSbUZl3moghEKaF5wxkEmIrQeWsF3/iTEiWD/4gp
VddivGIlaqpcaUU6/bA7mayuvR9t/Zp7UC5ezWSZ/RDGzy8/WKoNqel+VWl9aNf3
RPbAVrBCkhzZh2seFVSY/cq1NkiJ8vkIcXOhDVw1iwdnWlCPmxPIWpZWYgRVyWHA
DZa6aausRFK4/cQcOLSWYGTW/jtblCcgWRsGBVW7R/5yQ2Q+FEEQhlrtCa7hdagu
KqkdwkbGPObpqKbwRT5BbNLwoKcawoIdL8gnf08LEHqAOwqK/ysYviraFEF1LD4H
3okT/UJ6qkUYWQqUQH6oBzyzEnkWrgAkxOOXLDzv2VYmPLQUaQ85WeoLonAdezJG
XFclXimmwgShvkSwhfOc46ShSihCfPDtaOwn8cZ6tF7iv6hPD4RXbBAWxZ8Qap6J
yDvH4lTN+EckM4wPs4w6JA4woyuJ+hxvU+XYQjbf5sPABHqSJmjj/ZlZzq/pLrJn
8UYwhdknBSY4iAzMue4kQgL2bNNgJ4H6seUmVn7exgGlG0eJXpmZHkWNeHHObqvp
8kSqlkGPbZ/OUZcqxQp0mWJMD5dz++7gAWW7vhHx0B8MlbvPkaY3rT9breuKXrbi
xR3kXBjd/ozWFc3UgGF4gpONu7jhrhNmsxH4/n6oD5M2soZRIpUVTMktPsdQcVY9
5wZ6uxoCzs5E1l4Fx7FFJi5Bpu2EMHtkibdAIjkUcOzQmXcV/48PwSJuVz0uHdhI
/1Cx0oZm2Y7su66JAEcAVXt9/ilISDb4Q1FzrrP2anDCGUS3NlcPFsAknkH4bVce
lB34NXG8Ae6Cbh2PeCFGfLv6Wg3by7G0HL/4f9Ky4bsom0vxMGdfDzU1XYs7VL8E
ux19vtlMsmFsn/QVQRLud899kJY3Q5kFDblPJuYJQpVNb76R0mkoYWo2utQ90dCB
/a2tI+GD5EOW0uKi9Rld+p4NXsjf0G+dDu8eeVzLbZFyRucLQJSrgXu5HFWRJVKb
a7nhucg2+bdWBSgEZ5qwUg==
`pragma protect end_protected

// 计算PLL参数
localparam [20:0] PLL_PARAMS = calculate_pll_params(REF_CLK_REAL, PIXEL_CLK_REAL);
localparam  FBCLK_DIV  = int'(PLL_PARAMS[20:14]);    // m值 (3~126)
localparam  REFCLK_DIV = int'(PLL_PARAMS[13:7]);     // n值 (1~127)
localparam  CLKC0_DIV  = int'(PLL_PARAMS[6:0]);      // c值 (1~127)
localparam  CLKC0_DUTY_INT = (CLKC0_DIV > 1) ? ((CLKC0_DIV+1)/2) : 1; // 简单偶数/奇数占空比近似

// axi lite bus  start 
// 时钟和复位信号
wire clk   = aclk;
wire rst_n = arst_n;
// 写通道状态机
localparam [1:0] WRITE_IDLE = 2'b00,
                 WRITE_ADDR = 2'b01,
                 WRITE_DATA = 2'b10,
                 WRITE_RESP = 2'b11;

reg [1:0] write_state;

// 参数化的寄存器数组
reg [DATA_WIDTH-1:0] reg0;
reg [DATA_WIDTH-1:0] reg1;
reg [DATA_WIDTH-1:0] reg2;
reg [DATA_WIDTH-1:0] reg3;
reg [DATA_WIDTH-1:0] reg4;
reg [DATA_WIDTH-1:0] reg5;
reg [DATA_WIDTH-1:0] reg6;
reg [DATA_WIDTH-1:0] reg7;
reg [DATA_WIDTH-1:0] reg8;

reg [DATA_WIDTH-1:0] reg400;
reg [DATA_WIDTH-1:0] reg401;
reg [DATA_WIDTH-1:0] reg402;

// 写通道寄存器 , 确保数据缓存
reg [ADDR_WIDTH-1:0] write_addr;
reg [DATA_WIDTH-1:0] write_data;     // 缓存写数据
reg [3:0]            write_strb;     // 缓存写字节使能
reg                  bvalid;

// 读通道状态寄存器
reg [DATA_WIDTH-1:0] rdata;
reg rvalid;

// 声明变量
integer j;

// 输出信号连接
assign s_axi_awready = (write_state == WRITE_IDLE) || (write_state == WRITE_ADDR);
assign s_axi_wready  = (write_state == WRITE_IDLE) || (write_state == WRITE_DATA);

assign s_axi_bvalid  = bvalid;
assign s_axi_bresp   = 2'b00;

// 优化的读通道信号连接 
assign s_axi_arready = (!rvalid || s_axi_rready);
assign s_axi_rdata   = rdata;
assign s_axi_rvalid  = rvalid;
assign s_axi_rresp   = 2'b00;

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Cadence Design Systems.", key_keyname = "CDS_RSA_KEY_VER_1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
depQTqH1GhjcDNarQsjl6em6bdTMlGzdxWyj3WHMvFFYw7L7lMR/oCFQ4NNRLC8J
oAkkbPQUDEizvOeQ81wTzjZAt07RQdUSKZKOw/FQ8wvam5ytaTcZ8R66nAahJdb4
0v6P/eWhGZpEptPqMB6WsOVOFS/zytmvrVaCVCiHLTnyHHGLBQo30VMJ98e/Yyax
YnG6i6ifvJTpig27+L7xU2Vd6TNIpvKw3bt0wZDgmrmamFV20We6LDhp69U6Auhk
Am5Q4NdieWEDU25VbSc4GMluez+9NBi6YuWH4Ef5jJmc1qUJv2NVEB5rQygXIWQo
FcTbwxRse8ItjlfauQIuXg==
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
E08kJp38MqMOOuLlEANEob2ASWeDa7RzDQ83Yh61YTNHT2jw4CdNiM21YZuh9RXV
HHja1jSeWHpoaoL2TacFzj4SI2C2dbISrEDyfX+ivaryEWI1ImRhMhmh2ssOTg4K
HPKWLU2F4CASpTApTYbPS4snQ4hn+nUBxAIFkVQeOX0=
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
oTs2wYW1iNkUBfJG2mQt87Oz9SUu6yQDdDp2zOFqzapQinRNcekk21FDFUzpfzFe
QXSpEZRNnCx0I6gyzicifr+nndak6CqkRPQ/g3APnQPwOk5DdK0rZwmasLX0Pvxt
pgm2lIfH/OBXsfsKQg297pYxBX4SE0ZiaEa30rj60OKex0BVldpZ0t9ZGgliTkQ9
+JSKdmXNlpPWvipRuKlUyiiHAsaOkLg+lBgJzYvZaDLkP2cG7CF6GObpTAxS12JC
kccdSDwjBJvU+JRNahrfHFmL/mUW8/O1KdBu3tIpvpHJQwcbBJwENinRaWG7J9/e
ihnv7OcnN8KaXFoukkX7VA==
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
3CcN9cIHkV8XWX9lc/muJg2ThGS/mbJOYfBzTRVmXqP3IUc6FNRKZUEanZTqx9Pr
9OAh28fULkXxUeJk7QEzzEvMSFjCUF/eDm+Z2HSw93HaCxTtqvxVq+TQLc+nBakE
onIGWBPR2igjNTK+ZhQVD0So4q6NXY0LNceeL7Ia8tE=
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
pE+J4YGriFPE3ZeOSW3xDzVWHHG+IQc97j6cGVleTZ6/t9/JSYZm6PSjpvKz1fYv
ygtyehy3n8c53sufv/j893aC00tY9zbNzSWa3efQrpWi9zet6dgEeSwCtdlJ0vvB
Pu5gccb5rDb0/FiE3cHzKj2ZdTJxmc3RqMRgMMWtons=
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-009"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
ryiZp0f/ZyPEsT/Hxl8RDQ5FHoa+1Gmtlj3oDzWBXdACDyhs/TmCPPfowJ10/fcV
USOmRKwcpgUKfCZGEiqCPU/HDyK5IcyvsKZJpBShUXFN3z65CctrarRgW4U5y98y
Em9gD1/sKlxyya0BSgns0FPVarxDvKmkeSLelmMK6ME=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 688)
`pragma protect data_block
d/yfSDKpAjrthU0Buy4CkpWsKINGP0u1YIZE2JSV3yiDA+h/RQ6dulMD/nzV3aza
x6DmVbf68PlA5Im3Bhf+xkNpbP6ZiQ8G7zL8STGacvgXZSNHF8mFQZ08F2ve/xVR
CdPKvAiw9jcEcySFUF8eGdlANznlV5oXcw0QkFFDuepWLnmcZAkEL8D5zm1omRf7
zYH/hjcQU8BY2OS6qd/tpFD6SC0NNabwSdXDhwUv8goIpwmcE+IrS8RNlGjpGfyS
jjFeWhqISijRXHF7ZC3FW9uU9dBfnMTXgQE1c1rnwb1jXDPBOPYjbfILNLbNvTi2
g8jmlef85xX6yc7R6VP3ExIh+OWQnCOoUv8ISvCXHvawCQenKdro3WDZ5lsJVD3n
1Ldcnl5Cj1H8c+Fy0tId7j/+7iw6zK0NqPJZ/YOqfCO+TRR/0HfsQbw76Hp1a1wb
5dukaaoQozsKvbouQgUjkx/PvGAA6Wnu5vgeoGsVs/jtuRUq5hpNvo3fWxJxk5p/
3l66Cr0PUpGCSyq1UA2l92BEDbX8wsSMKa5n9GawOXrTfzI11w7TMkDvRcFVs0rT
6eJktGX/H2FAsGtZeOkjWAPOPBcBmUm5n0PJdqk1zDn+rBItB1pRFCZNne3ubIhu
5UENejMbTR5zpjwAXTM9JE8uY6xUQ/MAqSdyfXPdCzLsYsrLgX7tGUUVc1mUB82q
lurTQCNnWyTsb3o/ODsFf/10IlU+VK7Bvz72b6gHC3fdAjQ9MP3u7U9v4l+FGNUC
au5zPZimDn61uiRNQ96HDh1+F0o8+3Shn5G6Kn75KvWoXuy34Q9d0bVth3aJ3bAS
Lk9rKygMgeHFVCYeiALNMEAC7OZfvg303tB6/yffkCTbK8WVUCCBFGWG9wiUlupz
SzEXXbVAttjgPaYynJ1/KA==
`pragma protect end_protected

// 写通道状态机
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        write_state <= WRITE_IDLE;
        write_addr  <= {ADDR_WIDTH{1'b0}};
        write_data  <= {DATA_WIDTH{1'b0}};
        write_strb  <= 4'b0000;
        bvalid      <= 1'b0;
        // 初始化寄存器数组 - 使用默认时序参数
        reg0  <= {16'd0, H_FRONT};   // h_front
        reg1  <= {16'd0, H_ACTIVE};  // h_action  
        reg2  <= {16'd0, H_SYNC};    // h_sync
        reg3  <= {16'd0, H_BACK};    // h_back
        reg4  <= {16'd0, V_FRONT};   // v_front
        reg5  <= {16'd0, V_ACTIVE};  // v_action
        reg6  <= {16'd0, V_SYNC};    // v_sync
        reg7  <= {16'd0, V_BACK};    // v_back
        reg8  <= {32'd1};            // 默认使能视频时序输出
        
        reg400  <= {DATA_WIDTH{1'b0}};
        reg401  <= {DATA_WIDTH{1'b0}};
        reg402  <= {DATA_WIDTH{1'b0}};
        
        
    end else begin
        case (write_state)
            WRITE_IDLE: begin
                if (s_axi_awvalid && s_axi_wvalid) begin
                    // 地址和数据同时到达，直接执行写操作
                    execute_write_operation(s_axi_awaddr, s_axi_wdata, s_axi_wstrb);
                    write_state <= WRITE_RESP;
                    bvalid <= 1'b1;
                end else if (s_axi_awvalid) begin
                    // 只有地址到达，缓存地址
                    write_addr <= s_axi_awaddr;
                    write_state <= WRITE_DATA;
                end else if (s_axi_wvalid) begin
                    // 只有数据到达，缓存数据
                    write_data <= s_axi_wdata;
                    write_strb <= s_axi_wstrb;
                    write_state <= WRITE_ADDR;
                end
            end
            
            WRITE_ADDR: begin
                // 等待地址，数据已缓存
                if (s_axi_awvalid) begin
                    // 使用缓存的数据和当前地址执行写操作
                    execute_write_operation(s_axi_awaddr, write_data, write_strb);
                    write_state <= WRITE_RESP;
                    bvalid <= 1'b1;
                end
            end
            
            WRITE_DATA: begin
                // 等待数据，地址已缓存
                if (s_axi_wvalid) begin
                    // 使用缓存的地址和当前数据执行写操作
                    execute_write_operation(write_addr, s_axi_wdata, s_axi_wstrb);
                    write_state <= WRITE_RESP;
                    bvalid <= 1'b1;
                end
            end
            
            WRITE_RESP: begin
                // 等待响应被接收
                if (s_axi_bready) begin
                    bvalid <= 1'b0;
                    write_state <= WRITE_IDLE;
                end
                // 关键：在RESP状态下，bvalid必须保持为1直到被接收
            end
            
            default: begin
                write_state <= WRITE_IDLE;
                bvalid <= 1'b0;
            end
        endcase
    end
end

// 优化的读操作处理
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rvalid <= 1'b0;
        rdata  <= {DATA_WIDTH{1'b0}};
    end else begin
        if (s_axi_arvalid && (!rvalid || s_axi_rready)) begin
            // 可以在以下情况接收新的读地址：
            // 1. rvalid为0（没有待处理的读数据）
            // 2. rvalid为1但master准备好接收数据
    
            case (s_axi_araddr[ADDR_WIDTH-1:2]) 
                11'h0  : rdata    <= reg0;
                11'h1  : rdata    <= reg1;
                11'h2  : rdata    <= reg2;
                11'h3  : rdata    <= reg3;
                11'h4  : rdata    <= reg4;
                11'h5  : rdata    <= reg5;
                11'h6  : rdata    <= reg6;
                11'h7  : rdata    <= reg7;
                11'h8  : rdata    <= reg8;
                
                11'h400: rdata    <= reg400;
                11'h401: rdata    <= {24'd0,drp_rdata};
                11'h402: rdata    <= {30'd0,drp_status[1], vtg_pclk_locked }; 
                default: rdata    <= {DATA_WIDTH{1'b0}};      
            endcase
        
            rvalid <= 1'b1;                   // 标记读数据有效
        end else if (rvalid && s_axi_rready) begin
            // 当前读数据被接收，但没有新的读请求
            rvalid <= 1'b0;
        end
    end
end

// axi lite bus end 

// 添加用户逻辑
// ...
// axi pll 数据处理,实现通过总线动态配置axi pll
wire    [7:0]     drp_addr;
wire    [7:0]     drp_wdata;
wire    [7:0]     drp_rdata;
wire              drp_w_enable;

// drp_rst_n must be 1
wire              drp_rst_n = 1'b1;
assign drp_w_enable = drp_w_t;
wire   [31:0]     drp_status;  

reg [15:0] drp_w_temp1;
reg [15:0] drp_w_temp2;
reg  drp_w_t;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        drp_w_t <= 1'b0;
        drp_w_temp1  <= {16{1'b0}};
    
    end else begin
        drp_w_temp1 <= reg400[15:0];
        drp_w_temp2 <= drp_w_temp1;
        if ( reg400[15:0] != drp_w_temp2)
           drp_w_t <= 1;
         else 
           drp_w_t <= 0;  
    end
end

assign drp_addr     = drp_w_enable ? reg400[15:8]:reg401[15:8];
assign drp_wdata    = drp_w_enable ? reg400[7:0]: 8'd0;

dr1_phy_pll_vtc
  #(
      .FBKCLK("VCO_PHASE0"),
      .FBKCLK_INT("VCO_PHASE0"),
      .REFCLK_DIV(REFCLK_DIV),          // 使用计算得到的n值
      .FBCLK_DIV(FBCLK_DIV),            // 使用计算得到的m值
      .CLKC0_FPHASE(0),
      .CLKC0_CPHASE(29),             
      .CLKC0_DIV(CLKC0_DIV),            // 使用计算得到的c值
      .CLKC0_DUTY_INT(CLKC0_DUTY_INT),  // 使用计算得到的占空比
      .CLKC0_ENABLE("ENABLE"),
      .FIN(FIN),                        // 使用参数化的输入频率
      .FEEDBK_MODE("NOCOMP"),
      .PLL_USR_RST("DISABLE"),
      .PLL_FEED_TYPE("INTERNAL"),
      .LPF_RES(2),
      .LPF_CAP(2),
      .ICP_CUR(12),
      .GMC_GAIN(2),
      .FRAC_ENABLE("DISABLE"),
      .DITHER_ENABLE("DISABLE"),
      .SDM_FRAC(0),
      .SSC_AMP(0.0000),
      .MPHASE_ENABLE("DISABLE"),
      .DYN_PHASE_PATH_SEL("DISABLE"),
      .DYN_FPHASE_EN("DISABLE"),
      .CLKC0_FPHASE_RSTSEL(0),
      .CLKC0_DUTY50("ENABLE"),
      .INTPI(0),
      .SSC_ENABLE("DISABLE"),
      .SSC_MODE("DOWN"),
      .SSC_FREQ_DIV(0),
      .SSC_RNGE(0),
      .HIGH_SPEED_EN("DISABLE")
  )dr1_pll_vtc_Inst
  (
      .clk1_en(1'b1),
      .clk1_out(),
      .clkb1_out(),
      .clk2_en(1'b0),
      .clk2_out(),
      .clkb2_out(),
      .clk3_en(1'b0),
      .clk3_out(),
      .clkb3_out(),
      .clk4_en(1'b0),
      .clk4_out(),
      .clkb4_out(),
      .clk5_en(1'b0),
      .clk5_out(),
      .clkb5_out(),
      .clk6_en(1'b0),
      .clk6_out(),
      .clkb6_out(),
      .refclk(ref_clk),
      .ssc_en(1'b0),
      .ext_freq_mod_val(17'b00000000000000000),
      .ext_freq_mod_en(1'b0),
      .ext_freq_mod_clk(1'b0),
	  .clkc_rst(2'b00),
      .fbclk(1'b0),
      .cps_step(2'b00),
      .psclksel(3'b000),
      .psdone(),
      .psstep(1'b0),
      .psdown(1'b0),
      .psclk(1'b0),
      .pllpd(1'b0),
      .lock(vtg_pclk_locked),
      .reset(1'b0),
      .wakeup(1'b0),
      .refclk_rst(1'b0),
      .clk0_en(1'b1),
      .clkb0_out(), 
      .clk0_out(pixel_clk), 
      .drp_clk(clk),
      .drp_rstn(drp_rst_n),
      .drp_sel(1'b1),
      .drp_rd(drp_r_enable),
      .drp_wr(drp_w_enable),
      .drp_addr(drp_addr),
      .drp_wdata(drp_wdata),
      .drp_err(),
      .drp_rdy(drp_status[0]),
      .drp_rdata(drp_rdata)
  );
  
    
    
assign vtg_pclk = pixel_clk;
wire  pixel_rst_n = rst_n & reg8[0];
    
 // 实例化修改后的VTG模块
vtg_v01 #(
    .COUNTER_WIDTH(12)
) vtg_v01_inst (
    .clk(pixel_clk),
    .rst_n(pixel_rst_n),
    .vtg_ce(vtg_ce),         // vtg使能信号
    
    // 时序参数配置
    .h_active(reg1[15:0]), 
    .h_front(reg0[15:0]), 
    .h_sync(reg2[15:0]), 
    .h_back(reg3[15:0]),
    .v_active(reg5[15:0]), 
    .v_front(reg4[15:0]),  
    .v_sync(reg6[15:0]),  
    .v_back(reg7[15:0]),
    
    // 修改后的时序输出信号
    .vtg_hsync(vtg_hsync), 
    .vtg_vsync(vtg_vsync),
    .vtg_hblank(vtg_hblank), 
    .vtg_vblank(vtg_vblank),
    .vtg_de(vtg_active_video),
    .vtg_h_count(), 
    .vtg_v_count(),
    .vtg_frame_start(), 
    .vtg_line_start()
);

 // 用户逻辑添加结束
endmodule



