# The Command Lines that defined the layout and widget properties.

set Tab_Tab_0 [add_tab -name {Tab_0} -col_count {1}]

set Spin_Box_AXI_DATA_WIDTH [add_param -parent {Tab_0} -name {AXI_DATA_WIDTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_AXI_DATA_WIDTH -prop {Display Name} -value {AXI_DATA_WIDTH}

set Spin_Box_W_BUFDEPTH [add_param -parent {Tab_0} -name {W_BUFDEPTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_W_BUFDEPTH -prop {Display Name} -value {W_BUFDEPTH}

set Spin_Box_W_DATAWIDTH [add_param -parent {Tab_0} -name {W_DATAWIDTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_W_DATAWIDTH -prop {Display Name} -value {W_DATAWIDTH}

set Spin_Box_W_XSIZE [add_param -parent {Tab_0} -name {W_XSIZE} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_W_XSIZE -prop {Display Name} -value {W_XSIZE}

set Spin_Box_W_YSIZE [add_param -parent {Tab_0} -name {W_YSIZE} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_W_YSIZE -prop {Display Name} -value {W_YSIZE}

set Spin_Box_W_XDIV [add_param -parent {Tab_0} -name {W_XDIV} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_W_XDIV -prop {Display Name} -value {W_XDIV}

set Spin_Box_R_BUFDEPTH [add_param -parent {Tab_0} -name {R_BUFDEPTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_R_BUFDEPTH -prop {Display Name} -value {R_BUFDEPTH}

set Spin_Box_R_DATAWIDTH [add_param -parent {Tab_0} -name {R_DATAWIDTH} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_R_DATAWIDTH -prop {Display Name} -value {R_DATAWIDTH}

set Spin_Box_R_XSIZE [add_param -parent {Tab_0} -name {R_XSIZE} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_R_XSIZE -prop {Display Name} -value {R_XSIZE}

set Spin_Box_R_YSIZE [add_param -parent {Tab_0} -name {R_YSIZE} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_R_YSIZE -prop {Display Name} -value {R_YSIZE}

set Spin_Box_R_XDIV [add_param -parent {Tab_0} -name {R_XDIV} -widget {Spin Box}]
set_widget_prop -widget_id $Spin_Box_R_XDIV -prop {Display Name} -value {R_XDIV}