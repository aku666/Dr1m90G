/************************************************************\
**	Copyright (c) 2012-2025 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: May 18 2026 21:26:28
**	TD version	:	6.2.168116
************************************************************/
`timescale 1 ns / 1 ps
module system_temporal_conv_0
(
  input                         aclk,
  input                         rst_n,
  input   [6:0]                 S_AXI_AWADDR,
  input   [2:0]                 S_AXI_AWPROT,
  input                         S_AXI_AWVALID,
  output                        S_AXI_AWREADY,
  input   [31:0]                S_AXI_WDATA,
  input   [3:0]                 S_AXI_WSTRB,
  input                         S_AXI_WVALID,
  output                        S_AXI_WREADY,
  output  [1:0]                 S_AXI_BRESP,
  output                        S_AXI_BVALID,
  input                         S_AXI_BREADY,
  input   [6:0]                 S_AXI_ARADDR,
  input   [2:0]                 S_AXI_ARPROT,
  input                         S_AXI_ARVALID,
  output                        S_AXI_ARREADY,
  output  [31:0]                S_AXI_RDATA,
  output  [1:0]                 S_AXI_RRESP,
  output                        S_AXI_RVALID,
  input                         S_AXI_RREADY
);

  temporal_conv_c4d33bc5d477  temporal_conv_c4d33bc5d477_Inst
  (
      .aclk(aclk),
      .rst_n(rst_n),
      .S_AXI_AWADDR(S_AXI_AWADDR),
      .S_AXI_AWPROT(S_AXI_AWPROT),
      .S_AXI_AWVALID(S_AXI_AWVALID),
      .S_AXI_AWREADY(S_AXI_AWREADY),
      .S_AXI_WDATA(S_AXI_WDATA),
      .S_AXI_WSTRB(S_AXI_WSTRB),
      .S_AXI_WVALID(S_AXI_WVALID),
      .S_AXI_WREADY(S_AXI_WREADY),
      .S_AXI_BRESP(S_AXI_BRESP),
      .S_AXI_BVALID(S_AXI_BVALID),
      .S_AXI_BREADY(S_AXI_BREADY),
      .S_AXI_ARADDR(S_AXI_ARADDR),
      .S_AXI_ARPROT(S_AXI_ARPROT),
      .S_AXI_ARVALID(S_AXI_ARVALID),
      .S_AXI_ARREADY(S_AXI_ARREADY),
      .S_AXI_RDATA(S_AXI_RDATA),
      .S_AXI_RRESP(S_AXI_RRESP),
      .S_AXI_RVALID(S_AXI_RVALID),
      .S_AXI_RREADY(S_AXI_RREADY)
  );
endmodule
