// Isolated CPU Add profile. Soft arithmetic runs in the CPU model entry.
// This disabled GP endpoint returns DECERR; it never submits HP1 traffic.
module system_Video_NPU_0
(
  input                         M_AXI_ACLK,
  input                         M_AXI_AResetn,
  input                         S_AXILite_ACLK,
  input                         S_AXILite_AResetn,
  input   [32:0]                s_axilite_awaddr_i,
  input   [2:0]                 s_axilite_awprot_i,
  input                         s_axilite_awvalid_i,
  output                        s_axilite_awready_o,
  input   [31:0]                s_axilite_wdata_i,
  input   [3:0]                 s_axilite_wstrb_i,
  input                         s_axilite_wvalid_i,
  output                        s_axilite_wready_o,
  output                        reg s_axilite_bvalid_o,
  output  [1:0]                 s_axilite_bresp_o,
  input                         s_axilite_bready_i,
  input   [32:0]                s_axilite_araddr_i,
  input   [2:0]                 s_axilite_arprot_i,
  input                         s_axilite_arvalid_i,
  output                        s_axilite_arready_o,
  output  [31:0]                s_axilite_rdata_o,
  output  [1:0]                 s_axilite_rresp_o,
  output                        reg s_axilite_rvalid_o,
  input                         s_axilite_rready_i,
  input                         m_axi_awready_soft_i,
  output  [5:0]                 m_axi_awid_soft_o,
  output  [32:0]                m_axi_awaddr_soft_o,
  output  [3:0]                 m_axi_awlen_soft_o,
  output  [1:0]                 m_axi_awsize_soft_o,
  output  [1:0]                 m_axi_awburst_soft_o,
  output  [2:0]                 m_axi_awprot_soft_o,
  output                        m_axi_awvalid_soft_o,
  output                        m_axi_awlock_soft_o,
  output  [3:0]                 m_axi_awcache_soft_o,
  output  [63:0]                m_axi_wdata_soft_o,
  output  [7:0]                 m_axi_wstrb_soft_o,
  input                         m_axi_wready_soft_i,
  output                        m_axi_wlast_soft_o,
  output                        m_axi_wvalid_soft_o,
  input   [5:0]                 m_axi_bid_soft_i,
  input   [1:0]                 m_axi_bresp_soft_i,
  input                         m_axi_bvalid_soft_i,
  output                        m_axi_bready_soft_o,
  input                         m_axi_arready_soft_i,
  output  [5:0]                 m_axi_arid_soft_o,
  output  [32:0]                m_axi_araddr_soft_o,
  output  [3:0]                 m_axi_arlen_soft_o,
  output  [1:0]                 m_axi_arsize_soft_o,
  output  [1:0]                 m_axi_arburst_soft_o,
  output  [2:0]                 m_axi_arprot_soft_o,
  output                        m_axi_arvalid_soft_o,
  output                        m_axi_arlock_soft_o,
  output  [3:0]                 m_axi_arcache_soft_o,
  input   [5:0]                 m_axi_rid_soft_i,
  input   [63:0]                m_axi_rdata_soft_i,
  input   [1:0]                 m_axi_rresp_soft_i,
  input                         m_axi_rlast_soft_i,
  input                         m_axi_rvalid_soft_i,
  output                        m_axi_rready_soft_o,
  output                        npu_soft_intr
);
reg aw_seen, w_seen;
assign s_axilite_awready_o = !aw_seen && !s_axilite_bvalid_o;
assign s_axilite_wready_o = !w_seen && !s_axilite_bvalid_o;
assign s_axilite_bresp_o = 2'b11;
assign s_axilite_arready_o = !s_axilite_rvalid_o;
assign s_axilite_rdata_o = 32'h43504144;
assign s_axilite_rresp_o = 2'b11;
assign m_axi_awid_soft_o = 'b0;
assign m_axi_awaddr_soft_o = 'b0;
assign m_axi_awlen_soft_o = 'b0;
assign m_axi_awsize_soft_o = 'b0;
assign m_axi_awburst_soft_o = 'b0;
assign m_axi_awprot_soft_o = 'b0;
assign m_axi_awvalid_soft_o = 'b0;
assign m_axi_awlock_soft_o = 'b0;
assign m_axi_awcache_soft_o = 'b0;
assign m_axi_wdata_soft_o = 'b0;
assign m_axi_wstrb_soft_o = 'b0;
assign m_axi_wlast_soft_o = 'b0;
assign m_axi_wvalid_soft_o = 'b0;
assign m_axi_bready_soft_o = 1'b1;
assign m_axi_arid_soft_o = 'b0;
assign m_axi_araddr_soft_o = 'b0;
assign m_axi_arlen_soft_o = 'b0;
assign m_axi_arsize_soft_o = 'b0;
assign m_axi_arburst_soft_o = 'b0;
assign m_axi_arprot_soft_o = 'b0;
assign m_axi_arvalid_soft_o = 'b0;
assign m_axi_arlock_soft_o = 'b0;
assign m_axi_arcache_soft_o = 'b0;
assign m_axi_rready_soft_o = 1'b1;
assign npu_soft_intr = 'b0;

wire aw_take = s_axilite_awvalid_i && s_axilite_awready_o;
wire w_take = s_axilite_wvalid_i && s_axilite_wready_o;
always @(posedge S_AXILite_ACLK) begin
    if (!S_AXILite_AResetn) begin
        aw_seen <= 0; w_seen <= 0;
        s_axilite_bvalid_o <= 0; s_axilite_rvalid_o <= 0;
    end else begin
        if (s_axilite_bvalid_o && s_axilite_bready_i) s_axilite_bvalid_o <= 0;
        if (aw_take) aw_seen <= 1;
        if (w_take) w_seen <= 1;
        if (!s_axilite_bvalid_o && (aw_seen || aw_take) && (w_seen || w_take)) begin
            s_axilite_bvalid_o <= 1; aw_seen <= 0; w_seen <= 0;
        end
        if (s_axilite_rvalid_o && s_axilite_rready_i) s_axilite_rvalid_o <= 0;
        if (s_axilite_arvalid_i && s_axilite_arready_o) s_axilite_rvalid_o <= 1;
    end
end
endmodule
