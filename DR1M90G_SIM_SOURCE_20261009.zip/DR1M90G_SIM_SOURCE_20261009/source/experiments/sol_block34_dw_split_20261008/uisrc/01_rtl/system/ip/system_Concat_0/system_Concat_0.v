/************************************************************\
**	Copyright (c) 2012-2025 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Mar 03 2026 15:56:49
**	TD version	:	6.2.168116
************************************************************/
module system_Concat_0
(
  input   [0:0]                 In0,
  input   [0:0]                 In1,
  input   [0:0]                 In2,
  input   [0:0]                 In3,
  output  [3:0]                 Dout
);

  Concat_fe5c73756bec
  #(
      .PORT_NUM(4),
      .IN_WIDTH_0(1),
      .IN_WIDTH_1(1),
      .IN_WIDTH_2(1),
      .IN_WIDTH_3(1),
      .OUT_WIDTH(4)
  )Concat_fe5c73756bec_Inst
  (
      .In0(In0),
      .In1(In1),
      .In2(In2),
      .In3(In3),
      .Dout(Dout)
  );
endmodule
