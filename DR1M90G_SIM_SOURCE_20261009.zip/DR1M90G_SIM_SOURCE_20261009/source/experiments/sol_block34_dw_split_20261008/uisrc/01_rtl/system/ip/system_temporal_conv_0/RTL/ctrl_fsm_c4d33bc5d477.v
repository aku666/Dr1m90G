//============================================================================
// ctrl_fsm_c4d33bc5d477.v — Compute controller for the temporal-convolution accelerator.
//
// Strategy:
//   We unroll over the FILTER dimension (one PE per filter, NUM_PE = 4).
//   Each PE accumulates the same multi-dimensional sum:
//
//       acc_f = sum over (t_out=0..N-K, k=0..K-1, d=0..D-1)
//                  feat[t_out+k][d] * w[f][k][d]
//
//   That sum is identical to the "global temporal-average conv + sum-pool"
//   recipe, modulo a final right-shift by POOL_SHIFT (averaging).
//
// FSM phases:
//   IDLE   -> wait for cfg_start.
//   PREP   -> 1 cycle to clear all PE accumulators.
//   COMP   -> iterate (t_out, k, d). Each iteration uses 3 cycles:
//             phase 0: drive feat_addr / weight_addr to BRAMs
//             phase 1: latch BRAM dout into pe_feat, pulse pe_valid;
//                      advance loop counters
//   DRAIN  -> wait 4 cycles for mac_unit_c4d33bc5d477's mult+acc pipeline to flush.
//   WRITE  -> 1 cycle per filter: read PE accumulator, shift, write to
//             output BRAM.
//   DONE   -> pulse sts_done; back to IDLE.
//
// BRAM read latency : 1 cycle.
// MAC pipeline depth: 2 cycles.
// COMP throughput   : 1 useful MAC per 3 clk cycles (could be 1/clk with
//                     more aggressive pipelining; left as future work).
//============================================================================
module ctrl_fsm_c4d33bc5d477 #(
    parameter NUM_PE         = 4,
    parameter FEAT_ADDR_W    = 13,
    parameter WEIGHT_ADDR_W  = 17,
    parameter OUT_ADDR_W     = 6,
    parameter FEAT_DIM_MAX   = 256,
    parameter KERNEL_MAX     = 8,
    parameter NUM_FRAMES_MAX = 32
)(
    input  wire                       clk,
    input  wire                       rst_n,

    // Configuration (latched at start time)
    input  wire                       cfg_start,
    input  wire [7:0]                 cfg_num_frames,    // N (1..NUM_FRAMES_MAX)
    input  wire [8:0]                 cfg_feat_dim,      // D (1..FEAT_DIM_MAX)
    input  wire [3:0]                 cfg_kernel_size,   // K (1..KERNEL_MAX)
    input  wire [7:0]                 cfg_num_filters,   // F (1..NUM_PE)
    input  wire [3:0]                 cfg_pool_shift,    // S (0..15)

    // Status
    output reg                        sts_busy,
    output reg                        sts_done,

    // Feature BRAM port B (read)
    output reg  [FEAT_ADDR_W-1:0]     feat_addr,
    input  wire [7:0]                 feat_data,

    // Weight BRAM port B (read) — broadcast same address to NUM_PE BRAMs,
    // each BRAM stores ONE filter's full weight tensor.
    output reg  [WEIGHT_ADDR_W-1:0]   weight_addr_per_pe,

    // PE array control
    output reg                        pe_clear,
    output reg                        pe_valid,
    output reg  signed [7:0]          pe_feat,
    input  wire signed [NUM_PE*32-1:0] pe_acc,

    // Output BRAM port A (write)
    output reg                        out_wr_en,
    output reg  [OUT_ADDR_W-1:0]      out_wr_addr,
    output reg  [31:0]                out_wr_data
);

    // -----------------------------------------------------------------------
    // FSM states
    // -----------------------------------------------------------------------
    localparam [2:0] S_IDLE  = 3'd0;
    localparam [2:0] S_PREP  = 3'd1;
    localparam [2:0] S_COMP  = 3'd2;
    localparam [2:0] S_DRAIN = 3'd3;
    localparam [2:0] S_WRITE = 3'd4;
    localparam [2:0] S_DONE  = 3'd5;

    reg [2:0] state, state_n;

    // Latched config
    reg [7:0] N_q;
    reg [8:0] D_q;
    reg [3:0] K_q;
    reg [7:0] F_q;
    reg [3:0] S_q;

    // Loop counters
    reg [7:0] tout_q;
    reg [3:0] k_q;
    reg [8:0] d_q;
    reg [1:0] phase_q;       // 0 = issue addr, 1 = wait BRAM, 2 = latch+valid

    reg [3:0] drain_cnt;
    reg [7:0] write_idx;

    // Loop terminal indicators
    wire last_d    = (d_q    == D_q - 9'd1);
    wire last_k    = (k_q    == K_q - 4'd1);
    wire last_tout = (tout_q == N_q - K_q);

    // Address arithmetic (combinational from current loop counters)
    // weight_addr_kd = k * FEAT_DIM_MAX + d
    wire [WEIGHT_ADDR_W-1:0] w_addr_kd =
        ($unsigned({{(WEIGHT_ADDR_W-4){1'b0}}, k_q}) * FEAT_DIM_MAX) +
        $unsigned({{(WEIGHT_ADDR_W-9){1'b0}}, d_q});

    // feat_addr_kd = (tout + k) * FEAT_DIM_MAX + d
    wire [9:0] tout_plus_k = {2'd0, tout_q} + {6'd0, k_q};
    wire [FEAT_ADDR_W-1:0] f_addr =
        ($unsigned({{(FEAT_ADDR_W-10){1'b0}}, tout_plus_k}) * FEAT_DIM_MAX) +
        $unsigned({{(FEAT_ADDR_W-9){1'b0}}, d_q});

    // -----------------------------------------------------------------------
    // FSM next-state
    // -----------------------------------------------------------------------
    always @(*) begin
        case (state)
            S_IDLE:  state_n = cfg_start ? S_PREP : S_IDLE;
            S_PREP:  state_n = S_COMP;
            S_COMP:  state_n = (last_tout && last_k && last_d && phase_q == 2'd2)
                               ? S_DRAIN : S_COMP;
            S_DRAIN: state_n = (drain_cnt == 4'd4) ? S_WRITE : S_DRAIN;
            S_WRITE: state_n = (write_idx + 8'd1 == F_q) ? S_DONE : S_WRITE;
            S_DONE:  state_n = S_IDLE;
            default: state_n = S_IDLE;
        endcase
    end

    // -----------------------------------------------------------------------
    // Sequential
    // -----------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state              <= S_IDLE;
            N_q                <= 8'd0;
            D_q                <= 9'd0;
            K_q                <= 4'd0;
            F_q                <= 8'd0;
            S_q                <= 4'd0;
            tout_q             <= 8'd0;
            k_q                <= 4'd0;
            d_q                <= 9'd0;
            phase_q            <= 2'd0;
            drain_cnt          <= 4'd0;
            write_idx          <= 8'd0;

            sts_busy           <= 1'b0;
            sts_done           <= 1'b0;

            feat_addr          <= {FEAT_ADDR_W{1'b0}};
            weight_addr_per_pe <= {WEIGHT_ADDR_W{1'b0}};
            pe_clear           <= 1'b1;
            pe_valid           <= 1'b0;
            pe_feat            <= 8'sd0;
            out_wr_en          <= 1'b0;
            out_wr_addr        <= {OUT_ADDR_W{1'b0}};
            out_wr_data        <= 32'd0;
        end else begin
            // Single-cycle defaults
            sts_done  <= 1'b0;
            pe_valid  <= 1'b0;
            pe_clear  <= 1'b0;
            out_wr_en <= 1'b0;

            state <= state_n;

            case (state)
            // ----------------------------------------------------------------
            S_IDLE: begin
                sts_busy <= 1'b0;
                if (cfg_start) begin
                    N_q       <= cfg_num_frames;
                    D_q       <= (cfg_feat_dim < 1) ? 1 : ((cfg_feat_dim > FEAT_DIM_MAX) ? FEAT_DIM_MAX : cfg_feat_dim);
                    K_q       <= cfg_kernel_size;
                    F_q       <= cfg_num_filters;
                    S_q       <= cfg_pool_shift;
                    tout_q    <= 8'd0;
                    k_q       <= 4'd0;
                    d_q       <= 9'd0;
                    phase_q   <= 2'd0;
                    drain_cnt <= 4'd0;
                    write_idx <= 8'd0;
                    sts_busy  <= 1'b1;
                end
            end

            // ----------------------------------------------------------------
            S_PREP: begin
                pe_clear <= 1'b1;
                phase_q  <= 2'd0;
            end

            // ----------------------------------------------------------------
            S_COMP: begin
                case (phase_q)
                2'd0: begin
                    // Issue read addresses for current (tout, k, d)
                    feat_addr          <= f_addr;
                    weight_addr_per_pe <= w_addr_kd;
                    phase_q            <= 2'd1;
                end
                2'd1: begin
                    // Wait one cycle for BRAM read latency.
                    phase_q <= 2'd2;
                end
                2'd2: begin
                    // BRAM dout has settled this cycle — drive PE inputs.
                    pe_feat  <= $signed(feat_data);
                    pe_valid <= 1'b1;
                    phase_q  <= 2'd0;

                    // Advance loop counters
                    if (!(last_tout && last_k && last_d)) begin
                        if (last_d) begin
                            d_q <= 9'd0;
                            if (last_k) begin
                                k_q    <= 4'd0;
                                tout_q <= tout_q + 8'd1;
                            end else begin
                                k_q <= k_q + 4'd1;
                            end
                        end else begin
                            d_q <= d_q + 9'd1;
                        end
                    end
                end
                default: phase_q <= 2'd0;
                endcase
            end

            // ----------------------------------------------------------------
            S_DRAIN: begin
                drain_cnt <= drain_cnt + 4'd1;
            end

            // ----------------------------------------------------------------
            S_WRITE: begin
                out_wr_en   <= 1'b1;
                out_wr_addr <= write_idx[OUT_ADDR_W-1:0];
                // Mux per-PE accumulator using a generate-friendly compare.
                // We support up to NUM_PE filters; SDK already clamps F<=NUM_PE.
                case (write_idx[1:0])    // NUM_PE = 4 today
                    2'd0: out_wr_data <= $signed(pe_acc[0*32 +: 32]) >>> S_q;
                    2'd1: out_wr_data <= $signed(pe_acc[1*32 +: 32]) >>> S_q;
                    2'd2: out_wr_data <= $signed(pe_acc[2*32 +: 32]) >>> S_q;
                    2'd3: out_wr_data <= $signed(pe_acc[3*32 +: 32]) >>> S_q;
                    default: out_wr_data <= 32'd0;
                endcase
                write_idx <= write_idx + 8'd1;
            end

            // ----------------------------------------------------------------
            S_DONE: begin
                sts_done <= 1'b1;
                sts_busy <= 1'b0;
            end

            default: ;
            endcase
        end
    end

endmodule
