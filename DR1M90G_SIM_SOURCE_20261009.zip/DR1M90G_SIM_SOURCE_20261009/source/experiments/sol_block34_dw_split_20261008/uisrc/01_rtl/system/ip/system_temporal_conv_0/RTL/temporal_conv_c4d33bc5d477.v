`timescale 1ns/1ps
// V2 executable embodiment: one filter, stride=1, dilation=1, VALID output.
// Preload all T*C raw bytes and K*C weight bytes before start. Memories persist
// across reset; contents are not valid until loaded. No host writes while busy.
// P (signed prefix) and Q (absolute prefix) share each physical 32-bit RAM word.
// Supported parameters: 1<=CHANNELS<=16, 1<=MAX_T<=255, 1<=MAX_K<=128,
// 1<=MAX_SEG<=MAX_T. Output is a signed, unquantized 64-bit sum per window.
module duration_accel_core #(
 parameter CHANNELS=4, MAX_T=32, MAX_K=8, MAX_SEG=16
)(
 input wire clk, rst_n, start,
 input wire [7:0] cfg_t, cfg_k, cfg_max_length,
 input wire [1:0] cfg_mode, // 0=dense, 1=lossless (theta forced 0), 2=bounded
 input wire [CHANNELS*8-1:0] cfg_thresholds,
 input wire [63:0] cfg_budget,
 input wire raw_we, weight_we,
 input wire [15:0] load_addr,
 input wire signed [7:0] load_data,
 output reg busy, done, config_error, segment_overflow,
 output reg out_valid,
 input wire out_ready,
 output reg [7:0] out_index,
 output reg signed [63:0] out_data,
 output reg [63:0] out_error_bound,
 output reg out_replayed,
 output reg [7:0] segment_count,
 output reg [31:0] active_cycles, replay_count, overlap_products, dense_products
);
 localparam IDLE=0, FIRST_REQ=1, FIRST_WAIT=2, FIRST_USE=3,
 SCAN_REQ=4, SCAN_WAIT=5, SCAN_USE=6, DECIDE=7, COMMIT=8,
 PREFIX_ZERO=9, WEIGHT_REQ=10, WEIGHT_WAIT=11, PREFIX_WRITE=12,
 WINDOW=13, INTERSECT=14, LO_REQ=15, LO_WAIT=16, LO_USE=17,
 HI_REQ=18, HI_WAIT=19, PAIR_USE=20, CHECK=21,
 DENSE_REQ=22, DENSE_WAIT=23, DENSE_USE=24, EMIT=25;
 reg [5:0] state;
 reg [7:0] n_q,k_q,maxlen_q;
 reg [1:0] mode_q;
 reg [CHANNELS*8-1:0] theta_q;
 reg [63:0] budget_q;
 reg [15:0] t,c,k,s,cur_seg,m,u,v;
 reg split_q,new_segment,replay_q;
 reg signed [63:0] sum_q;
 reg [63:0] error_q;
 reg [7:0] seg_start[0:MAX_SEG-1],seg_end[0:MAX_SEG-1];
 reg signed [7:0] representatives[0:MAX_SEG*CHANNELS-1];
 reg [7:0] deviations[0:MAX_SEG*CHANNELS-1];
 reg signed [7:0] frame_tmp[0:CHANNELS-1];
 reg [7:0] diff_tmp[0:CHANNELS-1];
 reg signed [7:0] raw_mem[0:MAX_T*CHANNELS-1];
 reg signed [7:0] weight_mem[0:MAX_K*CHANNELS-1];
 reg [31:0] prefix_mem[0:CHANNELS*(MAX_K+1)-1];
 reg [15:0] raw_addr,weight_addr,prefix_addr;
 reg signed [7:0] raw_r,weight_r;
 reg [31:0] prefix_r,lo_q;
 reg signed [15:0] p_acc;
 reg [15:0] q_acc;
 wire signed [8:0] sample_diff=$signed({raw_r[7],raw_r})-
                      $signed({representatives[cur_seg*CHANNELS+c][7],representatives[cur_seg*CHANNELS+c]});
 wire [8:0] abs_diff=sample_diff[8] ? -sample_diff : sample_diff;
 wire [7:0] abs_weight=weight_r[7] ? -weight_r : weight_r;
 wire signed [16:0] p_delta=$signed({prefix_r[31],prefix_r[31:16]})-
                                    $signed({lo_q[31],lo_q[31:16]});
 wire [16:0] q_delta={1'b0,prefix_r[15:0]}-{1'b0,lo_q[15:0]};
 wire signed [24:0] overlap_product=$signed(representatives[s*CHANNELS+c])*p_delta;
 wire [24:0] certificate_product=deviations[s*CHANNELS+c]*q_delta;
 wire signed [15:0] dense_product=raw_r*weight_r;
 wire signed [15:0] p_next=p_acc+{{8{weight_r[7]}},weight_r};
 wire [15:0] q_next=q_acc+{8'd0,abs_weight};
 // Synchronous read ports. Metadata uses small registers; bulk data has no reset.
 always @(posedge clk) begin
  if(raw_we && !busy && load_addr<MAX_T*CHANNELS) raw_mem[load_addr]<=load_data;
  if(weight_we && !busy && load_addr<MAX_K*CHANNELS) weight_mem[load_addr]<=load_data;
  raw_r<=raw_mem[raw_addr]; weight_r<=weight_mem[weight_addr];
  prefix_r<=prefix_mem[prefix_addr];
  if(state==PREFIX_ZERO) prefix_mem[c*(MAX_K+1)]<=0;
  if(state==PREFIX_WRITE) prefix_mem[c*(MAX_K+1)+k+1]<={p_next,q_next};
 end
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=IDLE;busy<=0;done<=0;config_error<=0;segment_overflow<=0;
   out_valid<=0;out_index<=0;out_data<=0;out_error_bound<=0;out_replayed<=0;
   segment_count<=0;active_cycles<=0;replay_count<=0;overlap_products<=0;dense_products<=0;
   n_q<=0;k_q<=0;maxlen_q<=1;mode_q<=0;theta_q<=0;budget_q<=0;
   t<=0;c<=0;k<=0;s<=0;cur_seg<=0;m<=0;u<=0;v<=0;
   split_q<=0;new_segment<=0;replay_q<=0;sum_q<=0;error_q<=0;
   raw_addr<=0;weight_addr<=0;prefix_addr<=0;lo_q<=0;p_acc<=0;q_acc<=0;
  end else begin
   done<=0;
   if(busy && state!=EMIT) active_cycles<=active_cycles+1;
   case(state)
    IDLE: if(start) begin
     out_valid<=0;config_error<=0;segment_overflow<=0;segment_count<=0;
     active_cycles<=0;replay_count<=0;overlap_products<=0;dense_products<=0;
     n_q<=cfg_t;k_q<=cfg_k;mode_q<=cfg_mode;theta_q<=cfg_mode==1 ? 0 : cfg_thresholds;
     budget_q<=cfg_budget;maxlen_q<=cfg_max_length==0 ? 1 : cfg_max_length;
     t<=0;c<=0;k<=0;s<=0;m<=0;cur_seg<=0;sum_q<=0;error_q<=0;replay_q<=0;
     if(cfg_t==0 || cfg_t>MAX_T || cfg_k==0 || cfg_k>MAX_K || cfg_k>cfg_t || cfg_mode>2) begin
      config_error<=1;done<=1;
     end else begin
      busy<=1;
      if(cfg_mode==0) state<=WINDOW;
      else begin segment_count<=1;seg_start[0]<=0;seg_end[0]<=1;state<=FIRST_REQ;end
     end
    end
    FIRST_REQ: begin raw_addr<=c;state<=FIRST_WAIT;end
    FIRST_WAIT: state<=FIRST_USE;
    FIRST_USE: begin
     representatives[c]<=raw_r;deviations[c]<=0;
     if(c==CHANNELS-1) begin
      c<=0;t<=1;split_q<=0;
      if(n_q==1) state<=PREFIX_ZERO;else state<=SCAN_REQ;
     end else begin c<=c+1;state<=FIRST_REQ;end
    end
    SCAN_REQ: begin raw_addr<=t*CHANNELS+c;state<=SCAN_WAIT;end
    SCAN_WAIT: state<=SCAN_USE;
    SCAN_USE: begin
     frame_tmp[c]<=raw_r;diff_tmp[c]<=abs_diff[7:0];
     if(abs_diff>{1'b0,theta_q[c*8+:8]} || (t-seg_start[cur_seg])>=maxlen_q) split_q<=1;
     if(c==CHANNELS-1) begin c<=0;state<=DECIDE;end
     else begin c<=c+1;state<=SCAN_REQ;end
    end
    DECIDE: begin
     if(split_q && segment_count==MAX_SEG) begin
      // Entire raw sequence is retained: never silently discard a frame.
      segment_overflow<=1;state<=WINDOW;m<=0;
     end else begin
      new_segment<=split_q;
      if(split_q) begin
       cur_seg<=segment_count;segment_count<=segment_count+1;
       seg_start[segment_count]<=t;seg_end[segment_count]<=t+1;
      end else seg_end[cur_seg]<=t+1;
      state<=COMMIT;
     end
    end
    COMMIT: begin
     if(new_segment) begin representatives[cur_seg*CHANNELS+c]<=frame_tmp[c];deviations[cur_seg*CHANNELS+c]<=0;end
     else if(diff_tmp[c]>deviations[cur_seg*CHANNELS+c]) deviations[cur_seg*CHANNELS+c]<=diff_tmp[c];
     if(c==CHANNELS-1) begin
      c<=0;split_q<=0;t<=t+1;
      if(t+1==n_q) state<=PREFIX_ZERO;else state<=SCAN_REQ;
     end else c<=c+1;
    end
    PREFIX_ZERO: begin p_acc<=0;q_acc<=0;k<=0;state<=WEIGHT_REQ;end
    WEIGHT_REQ: begin weight_addr<=k*CHANNELS+c;state<=WEIGHT_WAIT;end
    WEIGHT_WAIT: state<=PREFIX_WRITE;
    PREFIX_WRITE: begin
     p_acc<=p_next;q_acc<=q_next;
     if(k+1==k_q) begin
      if(c==CHANNELS-1) begin c<=0;m<=0;state<=WINDOW;end
      else begin c<=c+1;state<=PREFIX_ZERO;end
     end else begin k<=k+1;state<=WEIGHT_REQ;end
    end
    WINDOW: begin
     sum_q<=0;error_q<=0;s<=0;c<=0;k<=0;replay_q<=segment_overflow;
     if(mode_q==0 || segment_overflow) begin
      if(segment_overflow) replay_count<=replay_count+1;
      state<=DENSE_REQ;
     end else state<=INTERSECT;
    end
    INTERSECT: begin
     if(s==segment_count) state<=CHECK;
     else if(seg_end[s]<=m || seg_start[s]>=m+k_q) s<=s+1;
     else begin
      u<=seg_start[s]>m ? seg_start[s]-m : 0;
      v<=seg_end[s]<m+k_q ? seg_end[s]-m : k_q;
      c<=0;state<=LO_REQ;
     end
    end
    LO_REQ: begin prefix_addr<=c*(MAX_K+1)+u;state<=LO_WAIT;end
    LO_WAIT: state<=LO_USE;
    LO_USE: begin lo_q<=prefix_r;state<=HI_REQ;end
    HI_REQ: begin prefix_addr<=c*(MAX_K+1)+v;state<=HI_WAIT;end
    HI_WAIT: state<=PAIR_USE;
    PAIR_USE: begin
     overlap_products<=overlap_products+1;
     // Nonnegative partial certificate is monotone. Stop work immediately when
     // it exceeds the snapshotted budget; never emit the rejected candidate.
     if(mode_q==2 && error_q+certificate_product>budget_q) begin
      sum_q<=0;error_q<=0;c<=0;k<=0;replay_q<=1;replay_count<=replay_count+1;state<=DENSE_REQ;
     end else begin
      sum_q<=sum_q+overlap_product;error_q<=error_q+certificate_product;
      if(c==CHANNELS-1) begin c<=0;s<=s+1;state<=INTERSECT;end
      else begin c<=c+1;state<=LO_REQ;end
     end
    end
    CHECK: begin
     out_index<=m;out_data<=sum_q;out_error_bound<=error_q;out_replayed<=replay_q;
     out_valid<=1;state<=EMIT;
    end
    DENSE_REQ: begin raw_addr<=(m+k)*CHANNELS+c;weight_addr<=k*CHANNELS+c;state<=DENSE_WAIT;end
    DENSE_WAIT: state<=DENSE_USE;
    DENSE_USE: begin
     sum_q<=sum_q+dense_product;dense_products<=dense_products+1;
     if(c==CHANNELS-1) begin
      c<=0;
      if(k+1==k_q) state<=CHECK;else begin k<=k+1;state<=DENSE_REQ;end
     end else begin c<=c+1;state<=DENSE_REQ;end
    end
    EMIT: if(out_valid && out_ready) begin
     out_valid<=0;
     if(m+k_q==n_q) begin busy<=0;done<=1;state<=IDLE;end
     else begin m<=m+1;state<=WINDOW;end
    end
    default: begin state<=IDLE;busy<=0;out_valid<=0;config_error<=1;done<=1;end
   endcase
  end
 end
endmodule

`timescale 1ns/1ps
// Standalone AXI-Lite peripheral for the V2 core. This is a different ABI from
// TCON. Identify DUC2 at +0x34 before using it. See implementation_v2/README.md.
module temporal_conv_c4d33bc5d477 (
 input wire aclk,rst_n,
 input wire [6:0] S_AXI_AWADDR,input wire [2:0] S_AXI_AWPROT,
 input wire S_AXI_AWVALID,output wire S_AXI_AWREADY,
 input wire [31:0] S_AXI_WDATA,input wire [3:0] S_AXI_WSTRB,
 input wire S_AXI_WVALID,output wire S_AXI_WREADY,
 output reg [1:0] S_AXI_BRESP,output reg S_AXI_BVALID,input wire S_AXI_BREADY,
 input wire [6:0] S_AXI_ARADDR,input wire [2:0] S_AXI_ARPROT,
 input wire S_AXI_ARVALID,output wire S_AXI_ARREADY,
 output reg [31:0] S_AXI_RDATA,output reg [1:0] S_AXI_RRESP,
 output reg S_AXI_RVALID,input wire S_AXI_RREADY
);
 reg aw_pending,w_pending;
 reg [6:0] aw_q;
 reg [31:0] wd_q;
 reg [3:0] ws_q;
 reg [7:0] cfg_t,cfg_k,cfg_max_length;
 reg [1:0] cfg_mode;
 reg [31:0] cfg_thresholds;
 reg [63:0] cfg_budget;
 reg [15:0] raw_ptr,weight_ptr;
 reg [4:0] out_ptr;
 reg start,done_latched;
 wire busy,done,config_error,segment_overflow,out_valid,out_replayed;
 wire [7:0] out_index,segment_count;
 wire signed [63:0] out_data;
 wire [63:0] out_error_bound;
 wire [31:0] active_cycles,replay_count,overlap_products,dense_products;
 reg [7:0] output_count;
 reg [128:0] results[0:31]; // {replayed, certificate64, signed result64}
 wire running=busy || start;
 wire write_fire=aw_pending && w_pending && !S_AXI_BVALID;
 wire aligned=aw_q[1:0]==0;
 wire [4:0] word_addr=aw_q[6:2];
 wire writable=word_addr==0 || (word_addr>=2 && word_addr<=12) || word_addr==16;
 wire bad_pointer=(word_addr==10 && raw_ptr>=128) || (word_addr==12 && weight_ptr>=32);
 wire write_ok=write_fire && !running && aligned && writable && !bad_pointer;
 wire raw_we=write_ok && word_addr==10 && ws_q[0];
 wire weight_we=write_ok && word_addr==12 && ws_q[0];
 wire [15:0] load_addr=raw_we ? raw_ptr : weight_ptr;
 wire signed [7:0] load_data=wd_q[7:0];
 reg [31:0] read_mux;
 reg read_error;
 integer b;
 function [31:0] merge_bytes;
 input [31:0] old_value,new_value;input [3:0] strobes;integer j;
 begin
  merge_bytes=old_value;
  for(j=0;j<4;j=j+1) if(strobes[j]) merge_bytes[j*8+:8]=new_value[j*8+:8];
 end endfunction
 assign S_AXI_AWREADY=!aw_pending && !S_AXI_BVALID;
 assign S_AXI_WREADY=!w_pending && !S_AXI_BVALID;
 assign S_AXI_ARREADY=!S_AXI_RVALID;
 duration_accel_core core(
 .clk(aclk),.rst_n(rst_n),.start(start),.cfg_t(cfg_t),.cfg_k(cfg_k),
 .cfg_max_length(cfg_max_length),.cfg_mode(cfg_mode),.cfg_thresholds(cfg_thresholds),.cfg_budget(cfg_budget),
 .raw_we(raw_we),.weight_we(weight_we),.load_addr(load_addr),.load_data(load_data),
 .busy(busy),.done(done),.config_error(config_error),.segment_overflow(segment_overflow),
 .out_valid(out_valid),.out_ready(1'b1),.out_index(out_index),.out_data(out_data),
 .out_error_bound(out_error_bound),.out_replayed(out_replayed),.segment_count(segment_count),
 .active_cycles(active_cycles),.replay_count(replay_count),.overlap_products(overlap_products),.dense_products(dense_products));
 always @(posedge aclk) if(out_valid) results[out_index[4:0]]<={out_replayed,out_error_bound,out_data};
 always @(*) begin
  read_mux=0;read_error=0;
  case(S_AXI_ARADDR[6:2])
   0: read_mux=0;
   1: read_mux={28'd0,segment_overflow,config_error,done_latched,running};
   2: read_mux={24'd0,cfg_t};3:read_mux={24'd0,cfg_k};4:read_mux={30'd0,cfg_mode};
   5:read_mux={24'd0,cfg_max_length};6:read_mux=cfg_thresholds;
   7:read_mux=cfg_budget[31:0];8:read_mux=cfg_budget[63:32];
   9:read_mux={16'd0,raw_ptr};11:read_mux={16'd0,weight_ptr};
   13:read_mux=32'h44554332;14:read_mux=32'h00020000;15:read_mux=32'h10040820;
   16:read_mux={27'd0,out_ptr};
   17:read_mux=results[out_ptr][31:0];18:read_mux=results[out_ptr][63:32];
   19:read_mux=results[out_ptr][95:64];20:read_mux=results[out_ptr][127:96];
   21:read_mux={31'd0,results[out_ptr][128]};
   22:read_mux=active_cycles;23:read_mux=replay_count;24:read_mux=overlap_products;
   25:read_mux=dense_products;26:read_mux={24'd0,segment_count};27:read_mux={24'd0,output_count};
   default:read_error=1;
  endcase
  if(S_AXI_ARADDR[1:0]!=0) read_error=1;
  // A complete run forms one immutable result epoch, preventing torn 64-bit reads.
  if(S_AXI_ARADDR[6:2]>=17 && S_AXI_ARADDR[6:2]<=21 &&
     (running || !done_latched || config_error || out_ptr>=output_count)) begin read_error=1;read_mux=0;end
 end
 always @(posedge aclk or negedge rst_n) begin
  if(!rst_n) begin
   aw_pending<=0;w_pending<=0;aw_q<=0;wd_q<=0;ws_q<=0;
   S_AXI_BRESP<=0;S_AXI_BVALID<=0;S_AXI_RDATA<=0;S_AXI_RRESP<=0;S_AXI_RVALID<=0;
   cfg_t<=32;cfg_k<=8;cfg_mode<=0;cfg_max_length<=32;cfg_thresholds<=0;cfg_budget<=0;
   raw_ptr<=0;weight_ptr<=0;out_ptr<=0;start<=0;done_latched<=0;output_count<=0;
  end else begin
   start<=0;
   if(done) done_latched<=1;
   if(out_valid) output_count<=output_count+1;
   if(S_AXI_AWVALID && S_AXI_AWREADY) begin aw_q<=S_AXI_AWADDR;aw_pending<=1;end
   if(S_AXI_WVALID && S_AXI_WREADY) begin wd_q<=S_AXI_WDATA;ws_q<=S_AXI_WSTRB;w_pending<=1;end
   if(S_AXI_BVALID && S_AXI_BREADY) S_AXI_BVALID<=0;
   if(write_fire) begin
    aw_pending<=0;w_pending<=0;S_AXI_BVALID<=1;S_AXI_BRESP<=write_ok ? 2'b00 : 2'b10;
    if(write_ok) case(word_addr)
     0: if(ws_q[0]) begin
      if(wd_q[1]) done_latched<=0;
      if(wd_q[0]) begin start<=1;done_latched<=0;output_count<=0;out_ptr<=0;end
     end
     2:if(ws_q[0]) cfg_t<=wd_q[7:0];
     3:if(ws_q[0]) cfg_k<=wd_q[7:0];
     4:if(ws_q[0]) cfg_mode<=wd_q[1:0];
     5:if(ws_q[0]) cfg_max_length<=wd_q[7:0];
     6:cfg_thresholds<=merge_bytes(cfg_thresholds,wd_q,ws_q);
     7:cfg_budget[31:0]<=merge_bytes(cfg_budget[31:0],wd_q,ws_q);
     8:cfg_budget[63:32]<=merge_bytes(cfg_budget[63:32],wd_q,ws_q);
     9:begin if(ws_q[0])raw_ptr[7:0]<=wd_q[7:0];if(ws_q[1])raw_ptr[15:8]<=wd_q[15:8];end
     10:if(ws_q[0])raw_ptr<=raw_ptr+1;
     11:begin if(ws_q[0])weight_ptr[7:0]<=wd_q[7:0];if(ws_q[1])weight_ptr[15:8]<=wd_q[15:8];end
     12:if(ws_q[0])weight_ptr<=weight_ptr+1;
     16:if(ws_q[0])out_ptr<=wd_q[4:0];
    endcase
   end
   if(S_AXI_RVALID && S_AXI_RREADY) S_AXI_RVALID<=0;
   if(S_AXI_ARVALID && S_AXI_ARREADY) begin
    S_AXI_RDATA<=read_mux;S_AXI_RRESP<=read_error ? 2'b10 : 2'b00;S_AXI_RVALID<=1;
   end
  end
 end
endmodule
