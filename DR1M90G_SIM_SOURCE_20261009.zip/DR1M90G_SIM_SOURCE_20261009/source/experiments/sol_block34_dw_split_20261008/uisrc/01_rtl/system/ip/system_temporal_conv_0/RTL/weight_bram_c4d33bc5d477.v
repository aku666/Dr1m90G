//============================================================================
// weight_bram_c4d33bc5d477.v — On-chip weight buffer (dual-port BRAM).
//
// Capacity: NUM_FILTERS (max 64) * KERNEL (max 8) * FEAT_DIM (max 256)
//         = 64 * 8 * 256 = 131072 bytes = 128 KB
// Word width: 8-bit (one INT8 weight per address).
//
// Port A: AXI-Lite byte-wise write (one byte per WEIGHT_WR transaction).
// Port B: streaming read by ctrl_fsm_c4d33bc5d477 at compute time (1-cycle latency).
//
// Address layout:
//   addr = (filter_idx * KERNEL_MAX + k) * FEAT_DIM_MAX + d
//   ARM writes weights in {filter, k, d} order, ctrl_fsm_c4d33bc5d477 reads in matching
//   order during compute.
//============================================================================
module weight_bram_c4d33bc5d477 #(
    parameter ADDR_WIDTH = 17,    // 2^17 = 131072 bytes
    parameter DATA_WIDTH = 8
)(
    input  wire                    clk,
    // Port A: write
    input  wire                    wr_en_a,
    input  wire [ADDR_WIDTH-1:0]   addr_a,
    input  wire [DATA_WIDTH-1:0]   din_a,
    // Port B: read
    input  wire [ADDR_WIDTH-1:0]   addr_b,
    output reg  [DATA_WIDTH-1:0]   dout_b
);

    (* ram_style = "block" *)
    reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

    always @(posedge clk) begin
        if (wr_en_a) mem[addr_a] <= din_a;
    end

    always @(posedge clk) begin
        dout_b <= mem[addr_b];
    end

endmodule
