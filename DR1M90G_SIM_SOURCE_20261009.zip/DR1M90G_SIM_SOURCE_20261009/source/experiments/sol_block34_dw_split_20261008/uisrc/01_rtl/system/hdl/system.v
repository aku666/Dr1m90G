module system (
 input wire [31:0] I_disp_addr,input wire I_disp_req,input wire [15:0] I_disp_size,input wire I_disp_ready,
 output wire O_disp_busy,O_disp_valid,output wire [63:0] O_disp_data,output wire O_disp_enable,
 input wire I_cap_resetn,I_cap_done,I_cap_fault,I_cap_req,I_cap_ready,
 input wire [7:0] I_cap_slot,I_cap_done_slot,input wire [31:0] I_cap_addr,
 input wire [15:0] I_cap_size,input wire [63:0] I_cap_data,
 input wire [31:0] I_cap_flags,I_cap_csi,I_cap_isp,I_cap_aw,I_cap_b,I_cap_rx,I_cap_valid,
 output wire O_cap_busy,O_cap_valid,O_cap_enable,O_cap_awvalid,O_cap_awready,O_cap_bvalid,O_cap_bready,
 output wire [1:0] O_cap_bresp,
    input     wire       [31:0] I_fdma_waddr ,
    input     wire              I_fdma_wareq ,
    input     wire       [15:0] I_fdma_wsize ,
    input     wire       [63:0] I_fdma_wdata ,
    input     wire              I_fdma_wready ,
    input     wire       [31:0] I_fdma_raddr ,
    input     wire              I_fdma_rareq ,
    input     wire       [15:0] I_fdma_rsize ,
    input     wire              I_fdma_rready ,
    input     wire       [31:0] I_mwdata ,
    input     wire              I_irq2 ,
    input     wire       [23:0] I_video_in_data ,
    input     wire              I_video_in_de ,
    input     wire              I_video_in_vs ,
    input     wire              I_video_in_hs ,
    output    wire              O_ui_clk ,
    output    wire              O_ui_rstn ,
    output    wire              O_fdma_wbusy ,
    output    wire              O_fdma_wvalid ,
    output    wire              O_fdma_rbusy ,
    output    wire       [63:0] O_fdma_rdata ,
    output    wire              O_fdma_rvalid ,
    output    wire              O_mrstn ,
    output    wire        [7:0] O_maddr ,
    output    wire        [3:0] O_mweb ,
    output    wire              O_mcsb ,
    output    wire       [31:0] O_mrdata ,
    output    wire              O_mclk ,
    output    wire              O_hdmi_clk_p ,
    output    wire        [2:0] O_hdmi_tx_p ,
    output    wire              O_refclk
); 
    wire [32:0]       w_port__ARM_Processor_System_0__master_gp0_axi_araddr ;
    wire [32:0]       w_port__AXI_Protocol_Converter_0__us_axi_araddr ;
    wire [32:0]       w_net__ARM_Processor_System_0__master_gp0_axi_araddr ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp0_axi_arburst ;
    wire [1:0]        w_port__AXI_Protocol_Converter_0__us_axi_arburst ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp0_axi_arburst ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp0_axi_arcache ;
    wire [3:0]        w_port__AXI_Protocol_Converter_0__us_axi_arcache ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp0_axi_arcache ; 

    wire [11:0]       w_port__ARM_Processor_System_0__master_gp0_axi_arid ;
    wire [11:0]       w_port__AXI_Protocol_Converter_0__us_axi_arid ;
    wire [11:0]       w_net__ARM_Processor_System_0__master_gp0_axi_arid ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp0_axi_arlen ;
    wire [7:0]        w_port__AXI_Protocol_Converter_0__us_axi_arlen ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp0_axi_arlen ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_arlock ;
    wire [0:0]        w_port__AXI_Protocol_Converter_0__us_axi_arlock ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_arlock ; 

    wire [2:0]        w_port__ARM_Processor_System_0__master_gp0_axi_arprot ;
    wire [2:0]        w_port__AXI_Protocol_Converter_0__us_axi_arprot ;
    wire [2:0]        w_net__ARM_Processor_System_0__master_gp0_axi_arprot ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp0_axi_arsize ;
    wire [2:0]        w_port__AXI_Protocol_Converter_0__us_axi_arsize ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp0_axi_arsize ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_arvalid ;
    wire              w_port__AXI_Protocol_Converter_0__us_axi_arvalid ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_arvalid ; 

    wire [32:0]       w_port__ARM_Processor_System_0__master_gp0_axi_awaddr ;
    wire [32:0]       w_port__AXI_Protocol_Converter_0__us_axi_awaddr ;
    wire [32:0]       w_net__ARM_Processor_System_0__master_gp0_axi_awaddr ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp0_axi_awburst ;
    wire [1:0]        w_port__AXI_Protocol_Converter_0__us_axi_awburst ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp0_axi_awburst ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp0_axi_awcache ;
    wire [3:0]        w_port__AXI_Protocol_Converter_0__us_axi_awcache ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp0_axi_awcache ; 

    wire [11:0]       w_port__ARM_Processor_System_0__master_gp0_axi_awid ;
    wire [11:0]       w_port__AXI_Protocol_Converter_0__us_axi_awid ;
    wire [11:0]       w_net__ARM_Processor_System_0__master_gp0_axi_awid ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp0_axi_awlen ;
    wire [7:0]        w_port__AXI_Protocol_Converter_0__us_axi_awlen ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp0_axi_awlen ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_awlock ;
    wire [0:0]        w_port__AXI_Protocol_Converter_0__us_axi_awlock ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_awlock ; 

    wire [2:0]        w_port__ARM_Processor_System_0__master_gp0_axi_awprot ;
    wire [2:0]        w_port__AXI_Protocol_Converter_0__us_axi_awprot ;
    wire [2:0]        w_net__ARM_Processor_System_0__master_gp0_axi_awprot ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp0_axi_awsize ;
    wire [2:0]        w_port__AXI_Protocol_Converter_0__us_axi_awsize ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp0_axi_awsize ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_awvalid ;
    wire              w_port__AXI_Protocol_Converter_0__us_axi_awvalid ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_awvalid ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_bready ;
    wire              w_port__AXI_Protocol_Converter_0__us_axi_bready ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_bready ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_rready ;
    wire              w_port__AXI_Protocol_Converter_0__us_axi_rready ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_rready ; 

    wire [31:0]       w_port__ARM_Processor_System_0__master_gp0_axi_wdata ;
    wire [31:0]       w_port__AXI_Protocol_Converter_0__us_axi_wdata ;
    wire [31:0]       w_net__ARM_Processor_System_0__master_gp0_axi_wdata ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_wlast ;
    wire              w_port__AXI_Protocol_Converter_0__us_axi_wlast ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_wlast ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp0_axi_wstrb ;
    wire [3:0]        w_port__AXI_Protocol_Converter_0__us_axi_wstrb ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp0_axi_wstrb ; 

    wire              w_port__ARM_Processor_System_0__master_gp0_axi_wvalid ;
    wire              w_port__AXI_Protocol_Converter_0__us_axi_wvalid ;
    wire              w_net__ARM_Processor_System_0__master_gp0_axi_wvalid ; 

    wire [32:0]       w_port__ARM_Processor_System_0__master_gp1_axi_araddr ;
    wire [9:0]        w_port__AXI_ERAM_Controller_0__araddr ;
    wire [32:0]       w_net__ARM_Processor_System_0__master_gp1_axi_araddr ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp1_axi_arburst ;
    wire [1:0]        w_port__AXI_ERAM_Controller_0__arburst ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp1_axi_arburst ; 

    wire [11:0]       w_port__ARM_Processor_System_0__master_gp1_axi_arid ;
    wire [11:0]       w_port__AXI_ERAM_Controller_0__arid ;
    wire [11:0]       w_net__ARM_Processor_System_0__master_gp1_axi_arid ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp1_axi_arlen ;
    wire [7:0]        w_port__AXI_ERAM_Controller_0__arlen ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp1_axi_arlen ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_arlock ;
    wire              w_port__AXI_ERAM_Controller_0__arlock ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_arlock ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp1_axi_arsize ;
    wire [2:0]        w_port__AXI_ERAM_Controller_0__arsize ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp1_axi_arsize ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_arvalid ;
    wire              w_port__AXI_ERAM_Controller_0__arvalid ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_arvalid ; 

    wire [32:0]       w_port__ARM_Processor_System_0__master_gp1_axi_awaddr ;
    wire [9:0]        w_port__AXI_ERAM_Controller_0__awaddr ;
    wire [32:0]       w_net__ARM_Processor_System_0__master_gp1_axi_awaddr ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp1_axi_awburst ;
    wire [1:0]        w_port__AXI_ERAM_Controller_0__awburst ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp1_axi_awburst ; 

    wire [11:0]       w_port__ARM_Processor_System_0__master_gp1_axi_awid ;
    wire [11:0]       w_port__AXI_ERAM_Controller_0__awid ;
    wire [11:0]       w_net__ARM_Processor_System_0__master_gp1_axi_awid ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp1_axi_awlen ;
    wire [7:0]        w_port__AXI_ERAM_Controller_0__awlen ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp1_axi_awlen ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_awlock ;
    wire              w_port__AXI_ERAM_Controller_0__awlock ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_awlock ; 

    wire [1:0]        w_port__ARM_Processor_System_0__master_gp1_axi_awsize ;
    wire [2:0]        w_port__AXI_ERAM_Controller_0__awsize ;
    wire [1:0]        w_net__ARM_Processor_System_0__master_gp1_axi_awsize ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_awvalid ;
    wire              w_port__AXI_ERAM_Controller_0__awvalid ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_awvalid ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_bready ;
    wire              w_port__AXI_ERAM_Controller_0__bready ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_bready ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_rready ;
    wire              w_port__AXI_ERAM_Controller_0__rready ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_rready ; 

    wire [31:0]       w_port__ARM_Processor_System_0__master_gp1_axi_wdata ;
    wire [31:0]       w_port__AXI_ERAM_Controller_0__wdata ;
    wire [31:0]       w_net__ARM_Processor_System_0__master_gp1_axi_wdata ; 

    wire [3:0]        w_port__ARM_Processor_System_0__master_gp1_axi_wstrb ;
    wire [3:0]        w_port__AXI_ERAM_Controller_0__wstrb ;
    wire [3:0]        w_net__ARM_Processor_System_0__master_gp1_axi_wstrb ; 

    wire              w_port__ARM_Processor_System_0__master_gp1_axi_wvalid ;
    wire              w_port__AXI_ERAM_Controller_0__wvalid ;
    wire              w_net__ARM_Processor_System_0__master_gp1_axi_wvalid ; 

    wire              w_port__ARM_Processor_System_0__p2f_clk0 ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_aclk ;
    wire              w_port__Processor_System_Reset_0_200__clk ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_aclk ;
    wire              w_port__uiFDMA_0__M_AXI_ACLK ;
    wire              w_port__Video_NPU_0__M_AXI_ACLK ;
    wire              w_net__ARM_Processor_System_0__p2f_clk0 ; 

    wire              w_port__ARM_Processor_System_0__p2f_clk1 ;
    wire              w_port__Processor_System_Reset_0__clk ;
    wire              w_port__AXI_ERAM_Controller_0__aclk ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_aclk ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_aclk ;
    wire              w_port__Video_NPU_0__S_AXILite_ACLK ;
    wire              w_port__AXI_Protocol_Converter_0__aclk ;
    wire              w_port__AXI_Matrix_0__aclk ;
    wire              w_port__temporal_conv_0__aclk ;
    wire              w_net__ARM_Processor_System_0__p2f_clk1 ; 

    wire              w_port__ARM_Processor_System_0__p2f_clk2 ;
    wire              w_net__ARM_Processor_System_0__p2f_clk2 ; 

    wire              w_port__ARM_Processor_System_0__p2f_rst0_n ;
    wire              w_port__Processor_System_Reset_0__external_reset ;
    wire              w_net__ARM_Processor_System_0__p2f_rst0_n ; 

    wire [0:0]        w_port__ARM_Processor_System_0__pl_gpio_out ;
    wire              w_port__Processor_System_Reset_0_200__external_reset ;
    wire [0:0]        w_net__ARM_Processor_System_0__pl_gpio_out ; 

    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_arready ;
    wire              w_port__uiFDMA_0__M_AXI_ARREADY ;
    wire              w_net__ARM_Processor_System_0__slave_hp0_axi_arready ; 

    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_awready ;
    wire              w_port__uiFDMA_0__M_AXI_AWREADY ;
    wire              w_net__ARM_Processor_System_0__slave_hp0_axi_awready ; 

    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_bid ;
    wire [5:0]        w_port__uiFDMA_0__M_AXI_BID ;
    wire [5:0]        w_net__ARM_Processor_System_0__slave_hp0_axi_bid ; 

    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_bresp ;
    wire [1:0]        w_port__uiFDMA_0__M_AXI_BRESP ;
    wire [1:0]        w_net__ARM_Processor_System_0__slave_hp0_axi_bresp ; 

    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_bvalid ;
    wire              w_port__uiFDMA_0__M_AXI_BVALID ;
    wire              w_net__ARM_Processor_System_0__slave_hp0_axi_bvalid ; 

    wire [63:0]       w_port__ARM_Processor_System_0__slave_hp0_axi_rdata ;
    wire [63:0]       w_port__uiFDMA_0__M_AXI_RDATA ;
    wire [63:0]       w_net__ARM_Processor_System_0__slave_hp0_axi_rdata ; 

    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_rid ;
    wire [5:0]        w_port__uiFDMA_0__M_AXI_RID ;
    wire [5:0]        w_net__ARM_Processor_System_0__slave_hp0_axi_rid ; 

    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_rlast ;
    wire              w_port__uiFDMA_0__M_AXI_RLAST ;
    wire              w_net__ARM_Processor_System_0__slave_hp0_axi_rlast ; 

    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_rresp ;
    wire [1:0]        w_port__uiFDMA_0__M_AXI_RRESP ;
    wire [1:0]        w_net__ARM_Processor_System_0__slave_hp0_axi_rresp ; 

    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_rvalid ;
    wire              w_port__uiFDMA_0__M_AXI_RVALID ;
    wire              w_net__ARM_Processor_System_0__slave_hp0_axi_rvalid ; 

    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_wready ;
    wire              w_port__uiFDMA_0__M_AXI_WREADY ;
    wire              w_net__ARM_Processor_System_0__slave_hp0_axi_wready ; 

    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_arready ;
    wire              w_port__Video_NPU_0__m_axi_arready_soft_i ;
    wire              w_net__ARM_Processor_System_0__slave_hp1_axi_arready ; 

    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_awready ;
    wire              w_port__Video_NPU_0__m_axi_awready_soft_i ;
    wire              w_net__ARM_Processor_System_0__slave_hp1_axi_awready ; 

    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_bid ;
    wire [5:0]        w_port__Video_NPU_0__m_axi_bid_soft_i ;
    wire [5:0]        w_net__ARM_Processor_System_0__slave_hp1_axi_bid ; 

    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_bresp ;
    wire [1:0]        w_port__Video_NPU_0__m_axi_bresp_soft_i ;
    wire [1:0]        w_net__ARM_Processor_System_0__slave_hp1_axi_bresp ; 

    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_bvalid ;
    wire              w_port__Video_NPU_0__m_axi_bvalid_soft_i ;
    wire              w_net__ARM_Processor_System_0__slave_hp1_axi_bvalid ; 

    wire [63:0]       w_port__ARM_Processor_System_0__slave_hp1_axi_rdata ;
    wire [63:0]       w_port__Video_NPU_0__m_axi_rdata_soft_i ;
    wire [63:0]       w_net__ARM_Processor_System_0__slave_hp1_axi_rdata ; 

    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_rid ;
    wire [5:0]        w_port__Video_NPU_0__m_axi_rid_soft_i ;
    wire [5:0]        w_net__ARM_Processor_System_0__slave_hp1_axi_rid ; 

    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_rlast ;
    wire              w_port__Video_NPU_0__m_axi_rlast_soft_i ;
    wire              w_net__ARM_Processor_System_0__slave_hp1_axi_rlast ; 

    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_rresp ;
    wire [1:0]        w_port__Video_NPU_0__m_axi_rresp_soft_i ;
    wire [1:0]        w_net__ARM_Processor_System_0__slave_hp1_axi_rresp ; 

    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_rvalid ;
    wire              w_port__Video_NPU_0__m_axi_rvalid_soft_i ;
    wire              w_net__ARM_Processor_System_0__slave_hp1_axi_rvalid ; 

    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_wready ;
    wire              w_port__Video_NPU_0__m_axi_wready_soft_i ;
    wire              w_net__ARM_Processor_System_0__slave_hp1_axi_wready ; 

    wire              w_port__AXI_ERAM_Controller_0__arready ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_arready ;
    wire              w_net__AXI_ERAM_Controller_0__arready ; 

    wire              w_port__AXI_ERAM_Controller_0__awready ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_awready ;
    wire              w_net__AXI_ERAM_Controller_0__awready ; 

    wire [11:0]       w_port__AXI_ERAM_Controller_0__bid ;
    wire [11:0]       w_port__ARM_Processor_System_0__master_gp1_axi_bid ;
    wire [11:0]       w_net__AXI_ERAM_Controller_0__bid ; 

    wire [1:0]        w_port__AXI_ERAM_Controller_0__bresp ;
    wire [1:0]        w_port__ARM_Processor_System_0__master_gp1_axi_bresp ;
    wire [1:0]        w_net__AXI_ERAM_Controller_0__bresp ; 

    wire              w_port__AXI_ERAM_Controller_0__bvalid ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_bvalid ;
    wire              w_net__AXI_ERAM_Controller_0__bvalid ; 

    wire [7:0]        w_port__AXI_ERAM_Controller_0__mem_addr ;
    wire [7:0]        w_net__AXI_ERAM_Controller_0__mem_addr ; 

    wire              w_port__AXI_ERAM_Controller_0__mem_csb ;
    wire              w_net__AXI_ERAM_Controller_0__mem_csb ; 

    wire [31:0]       w_port__AXI_ERAM_Controller_0__mem_din ;
    wire [31:0]       w_net__AXI_ERAM_Controller_0__mem_din ; 

    wire [3:0]        w_port__AXI_ERAM_Controller_0__mem_web ;
    wire [3:0]        w_net__AXI_ERAM_Controller_0__mem_web ; 

    wire [31:0]       w_port__AXI_ERAM_Controller_0__rdata ;
    wire [31:0]       w_port__ARM_Processor_System_0__master_gp1_axi_rdata ;
    wire [31:0]       w_net__AXI_ERAM_Controller_0__rdata ; 

    wire [11:0]       w_port__AXI_ERAM_Controller_0__rid ;
    wire [11:0]       w_port__ARM_Processor_System_0__master_gp1_axi_rid ;
    wire [11:0]       w_net__AXI_ERAM_Controller_0__rid ; 

    wire              w_port__AXI_ERAM_Controller_0__rlast ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_rlast ;
    wire              w_net__AXI_ERAM_Controller_0__rlast ; 

    wire [1:0]        w_port__AXI_ERAM_Controller_0__rresp ;
    wire [1:0]        w_port__ARM_Processor_System_0__master_gp1_axi_rresp ;
    wire [1:0]        w_net__AXI_ERAM_Controller_0__rresp ; 

    wire              w_port__AXI_ERAM_Controller_0__rvalid ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_rvalid ;
    wire              w_net__AXI_ERAM_Controller_0__rvalid ; 

    wire              w_port__AXI_ERAM_Controller_0__wready ;
    wire              w_port__ARM_Processor_System_0__master_gp1_axi_wready ;
    wire              w_net__AXI_ERAM_Controller_0__wready ; 

    wire [32:0]       w_port__AXI_Matrix_0__ds1_araddr ;
    wire [32:0]       w_port__Video_NPU_0__s_axilite_araddr_i ;
    wire [32:0]       w_net__AXI_Matrix_0__ds1_araddr ; 

    wire [2:0]        w_port__AXI_Matrix_0__ds1_arprot ;
    wire [2:0]        w_port__Video_NPU_0__s_axilite_arprot_i ;
    wire [2:0]        w_net__AXI_Matrix_0__ds1_arprot ; 

    wire              w_port__AXI_Matrix_0__ds1_arvalid ;
    wire              w_port__Video_NPU_0__s_axilite_arvalid_i ;
    wire              w_net__AXI_Matrix_0__ds1_arvalid ; 

    wire [32:0]       w_port__AXI_Matrix_0__ds1_awaddr ;
    wire [32:0]       w_port__Video_NPU_0__s_axilite_awaddr_i ;
    wire [32:0]       w_net__AXI_Matrix_0__ds1_awaddr ; 

    wire [2:0]        w_port__AXI_Matrix_0__ds1_awprot ;
    wire [2:0]        w_port__Video_NPU_0__s_axilite_awprot_i ;
    wire [2:0]        w_net__AXI_Matrix_0__ds1_awprot ; 

    wire              w_port__AXI_Matrix_0__ds1_awvalid ;
    wire              w_port__Video_NPU_0__s_axilite_awvalid_i ;
    wire              w_net__AXI_Matrix_0__ds1_awvalid ; 

    wire              w_port__AXI_Matrix_0__ds1_bready ;
    wire              w_port__Video_NPU_0__s_axilite_bready_i ;
    wire              w_net__AXI_Matrix_0__ds1_bready ; 

    wire              w_port__AXI_Matrix_0__ds1_rready ;
    wire              w_port__Video_NPU_0__s_axilite_rready_i ;
    wire              w_net__AXI_Matrix_0__ds1_rready ; 

    wire [31:0]       w_port__AXI_Matrix_0__ds1_wdata ;
    wire [31:0]       w_port__Video_NPU_0__s_axilite_wdata_i ;
    wire [31:0]       w_net__AXI_Matrix_0__ds1_wdata ; 

    wire [3:0]        w_port__AXI_Matrix_0__ds1_wstrb ;
    wire [3:0]        w_port__Video_NPU_0__s_axilite_wstrb_i ;
    wire [3:0]        w_net__AXI_Matrix_0__ds1_wstrb ; 

    wire              w_port__AXI_Matrix_0__ds1_wvalid ;
    wire              w_port__Video_NPU_0__s_axilite_wvalid_i ;
    wire              w_net__AXI_Matrix_0__ds1_wvalid ; 

    wire              w_port__AXI_Matrix_0__us0_arready ;
    wire              w_port__AXI_Protocol_Converter_0__ds_axi_arready ;
    wire              w_net__AXI_Matrix_0__us0_arready ; 

    wire              w_port__AXI_Matrix_0__us0_awready ;
    wire              w_port__AXI_Protocol_Converter_0__ds_axi_awready ;
    wire              w_net__AXI_Matrix_0__us0_awready ; 

    wire [1:0]        w_port__AXI_Matrix_0__us0_bresp ;
    wire [1:0]        w_port__AXI_Protocol_Converter_0__ds_axi_bresp ;
    wire [1:0]        w_net__AXI_Matrix_0__us0_bresp ; 

    wire              w_port__AXI_Matrix_0__us0_bvalid ;
    wire              w_port__AXI_Protocol_Converter_0__ds_axi_bvalid ;
    wire              w_net__AXI_Matrix_0__us0_bvalid ; 

    wire [31:0]       w_port__AXI_Matrix_0__us0_rdata ;
    wire [31:0]       w_port__AXI_Protocol_Converter_0__ds_axi_rdata ;
    wire [31:0]       w_net__AXI_Matrix_0__us0_rdata ; 

    wire [1:0]        w_port__AXI_Matrix_0__us0_rresp ;
    wire [1:0]        w_port__AXI_Protocol_Converter_0__ds_axi_rresp ;
    wire [1:0]        w_net__AXI_Matrix_0__us0_rresp ; 

    wire              w_port__AXI_Matrix_0__us0_rvalid ;
    wire              w_port__AXI_Protocol_Converter_0__ds_axi_rvalid ;
    wire              w_net__AXI_Matrix_0__us0_rvalid ; 

    wire              w_port__AXI_Matrix_0__us0_wready ;
    wire              w_port__AXI_Protocol_Converter_0__ds_axi_wready ;
    wire              w_net__AXI_Matrix_0__us0_wready ; 

    wire [32:0]       w_port__AXI_Protocol_Converter_0__ds_axi_araddr ;
    wire [32:0]       w_port__AXI_Matrix_0__us0_araddr ;
    wire [32:0]       w_net__AXI_Protocol_Converter_0__ds_axi_araddr ; 

    wire [2:0]        w_port__AXI_Protocol_Converter_0__ds_axi_arprot ;
    wire [2:0]        w_port__AXI_Matrix_0__us0_arprot ;
    wire [2:0]        w_net__AXI_Protocol_Converter_0__ds_axi_arprot ; 

    wire              w_port__AXI_Protocol_Converter_0__ds_axi_arvalid ;
    wire              w_port__AXI_Matrix_0__us0_arvalid ;
    wire              w_net__AXI_Protocol_Converter_0__ds_axi_arvalid ; 

    wire [32:0]       w_port__AXI_Protocol_Converter_0__ds_axi_awaddr ;
    wire [32:0]       w_port__AXI_Matrix_0__us0_awaddr ;
    wire [32:0]       w_net__AXI_Protocol_Converter_0__ds_axi_awaddr ; 

    wire [2:0]        w_port__AXI_Protocol_Converter_0__ds_axi_awprot ;
    wire [2:0]        w_port__AXI_Matrix_0__us0_awprot ;
    wire [2:0]        w_net__AXI_Protocol_Converter_0__ds_axi_awprot ; 

    wire              w_port__AXI_Protocol_Converter_0__ds_axi_awvalid ;
    wire              w_port__AXI_Matrix_0__us0_awvalid ;
    wire              w_net__AXI_Protocol_Converter_0__ds_axi_awvalid ; 

    wire              w_port__AXI_Protocol_Converter_0__ds_axi_bready ;
    wire              w_port__AXI_Matrix_0__us0_bready ;
    wire              w_net__AXI_Protocol_Converter_0__ds_axi_bready ; 

    wire              w_port__AXI_Protocol_Converter_0__ds_axi_rready ;
    wire              w_port__AXI_Matrix_0__us0_rready ;
    wire              w_net__AXI_Protocol_Converter_0__ds_axi_rready ; 

    wire [31:0]       w_port__AXI_Protocol_Converter_0__ds_axi_wdata ;
    wire [31:0]       w_port__AXI_Matrix_0__us0_wdata ;
    wire [31:0]       w_net__AXI_Protocol_Converter_0__ds_axi_wdata ; 

    wire [3:0]        w_port__AXI_Protocol_Converter_0__ds_axi_wstrb ;
    wire [3:0]        w_port__AXI_Matrix_0__us0_wstrb ;
    wire [3:0]        w_net__AXI_Protocol_Converter_0__ds_axi_wstrb ; 

    wire              w_port__AXI_Protocol_Converter_0__ds_axi_wvalid ;
    wire              w_port__AXI_Matrix_0__us0_wvalid ;
    wire              w_net__AXI_Protocol_Converter_0__ds_axi_wvalid ; 

    wire              w_port__AXI_Protocol_Converter_0__us_axi_arready ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_arready ;
    wire              w_net__AXI_Protocol_Converter_0__us_axi_arready ; 

    wire              w_port__AXI_Protocol_Converter_0__us_axi_awready ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_awready ;
    wire              w_net__AXI_Protocol_Converter_0__us_axi_awready ; 

    wire [11:0]       w_port__AXI_Protocol_Converter_0__us_axi_bid ;
    wire [11:0]       w_port__ARM_Processor_System_0__master_gp0_axi_bid ;
    wire [11:0]       w_net__AXI_Protocol_Converter_0__us_axi_bid ; 

    wire [1:0]        w_port__AXI_Protocol_Converter_0__us_axi_bresp ;
    wire [1:0]        w_port__ARM_Processor_System_0__master_gp0_axi_bresp ;
    wire [1:0]        w_net__AXI_Protocol_Converter_0__us_axi_bresp ; 

    wire              w_port__AXI_Protocol_Converter_0__us_axi_bvalid ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_bvalid ;
    wire              w_net__AXI_Protocol_Converter_0__us_axi_bvalid ; 

    wire [31:0]       w_port__AXI_Protocol_Converter_0__us_axi_rdata ;
    wire [31:0]       w_port__ARM_Processor_System_0__master_gp0_axi_rdata ;
    wire [31:0]       w_net__AXI_Protocol_Converter_0__us_axi_rdata ; 

    wire [11:0]       w_port__AXI_Protocol_Converter_0__us_axi_rid ;
    wire [11:0]       w_port__ARM_Processor_System_0__master_gp0_axi_rid ;
    wire [11:0]       w_net__AXI_Protocol_Converter_0__us_axi_rid ; 

    wire              w_port__AXI_Protocol_Converter_0__us_axi_rlast ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_rlast ;
    wire              w_net__AXI_Protocol_Converter_0__us_axi_rlast ; 

    wire [1:0]        w_port__AXI_Protocol_Converter_0__us_axi_rresp ;
    wire [1:0]        w_port__ARM_Processor_System_0__master_gp0_axi_rresp ;
    wire [1:0]        w_net__AXI_Protocol_Converter_0__us_axi_rresp ; 

    wire              w_port__AXI_Protocol_Converter_0__us_axi_rvalid ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_rvalid ;
    wire              w_net__AXI_Protocol_Converter_0__us_axi_rvalid ; 

    wire              w_port__AXI_Protocol_Converter_0__us_axi_wready ;
    wire              w_port__ARM_Processor_System_0__master_gp0_axi_wready ;
    wire              w_net__AXI_Protocol_Converter_0__us_axi_wready ; 

    wire [3:0]        w_port__Concat_0__Dout ;
    wire [15:0]       w_port__ARM_Processor_System_0__f2p_irq ;
    wire [3:0]        w_net__Concat_0__Dout ; 

    wire [0:0]        w_port__Constant_0__dout ;
    wire              w_port__Processor_System_Reset_0__pll_locked ;
    wire              w_port__Processor_System_Reset_0_200__pll_locked ;
    wire [0:0]        w_net__Constant_0__dout ; 

    wire [0:0]        w_port__Constant_3__dout ;
    wire              w_port__Processor_System_Reset_0__system_rst ;
    wire              w_port__Processor_System_Reset_0_200__system_rst ;
    wire              w_port__Processor_System_Reset_0_200__aux_rst ;
    wire              w_port__Processor_System_Reset_0__aux_rst ;
    wire [0:0]        w_net__Constant_3__dout ; 

    wire [31:0]       w_port__uiFDMA_0__I_fdma_raddr ;
    wire [31:0]       w_net__I_fdma_raddr ; 

    wire              w_port__uiFDMA_0__I_fdma_rareq ;
    wire              w_net__I_fdma_rareq ; 

    wire              w_port__uiFDMA_0__I_fdma_rready ;
    wire              w_net__I_fdma_rready ; 

    wire [15:0]       w_port__uiFDMA_0__I_fdma_rsize ;
    wire [15:0]       w_net__I_fdma_rsize ; 

    wire [31:0]       w_port__uiFDMA_0__I_fdma_waddr ;
    wire [31:0]       w_net__I_fdma_waddr ; 

    wire              w_port__uiFDMA_0__I_fdma_wareq ;
    wire              w_net__I_fdma_wareq ; 

    wire [63:0]       w_port__uiFDMA_0__I_fdma_wdata ;
    wire [63:0]       w_net__I_fdma_wdata ; 

    wire              w_port__uiFDMA_0__I_fdma_wready ;
    wire              w_net__I_fdma_wready ; 

    wire [15:0]       w_port__uiFDMA_0__I_fdma_wsize ;
    wire [15:0]       w_net__I_fdma_wsize ; 

    wire [0:0]        w_port__Concat_0__In2 ;
    wire [0:0]        w_net__I_irq2 ; 

    wire [31:0]       w_port__AXI_ERAM_Controller_0__mem_dout ;
    wire [31:0]       w_net__I_mwdata ; 

    wire [23:0]       w_port__uihdmi_tx_0__I_video_in_data ;
    wire [23:0]       w_net__I_video_in_data ; 

    wire              w_port__uihdmi_tx_0__I_video_in_de ;
    wire              w_net__I_video_in_de ; 

    wire              w_port__uihdmi_tx_0__I_video_in_hs ;
    wire              w_net__I_video_in_hs ; 

    wire              w_port__uihdmi_tx_0__I_video_in_vs ;
    wire              w_net__I_video_in_vs ; 

    wire [0:0]        w_port__Processor_System_Reset_0_200__peripheral_aresetn ;
    wire              w_port__uiFDMA_0__M_AXI_ARESETN ;
    wire              w_port__Video_NPU_0__M_AXI_AResetn ;
    wire [0:0]        w_net__Processor_System_Reset_0_200__peripheral_aresetn ; 

    wire [0:0]        w_port__Processor_System_Reset_0__peripheral_aresetn ;
    wire              w_port__AXI_ERAM_Controller_0__aresetn ;
    wire              w_port__Video_NPU_0__S_AXILite_AResetn ;
    wire              w_port__AXI_Protocol_Converter_0__aresetn ;
    wire              w_port__AXI_Matrix_0__aresetn ;
    wire              w_port__temporal_conv_0__rst_n ;
    wire [0:0]        w_net__Processor_System_Reset_0__peripheral_aresetn ; 

    wire [32:0]       w_port__Video_NPU_0__m_axi_araddr_soft_o ;
    wire [32:0]       w_port__ARM_Processor_System_0__slave_hp1_axi_araddr ;
    wire [32:0]       w_net__Video_NPU_0__m_axi_araddr_soft_o ; 

    wire [1:0]        w_port__Video_NPU_0__m_axi_arburst_soft_o ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_arburst ;
    wire [1:0]        w_net__Video_NPU_0__m_axi_arburst_soft_o ; 

    wire [3:0]        w_port__Video_NPU_0__m_axi_arcache_soft_o ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_arcache ;
    wire [3:0]        w_net__Video_NPU_0__m_axi_arcache_soft_o ; 

    wire [5:0]        w_port__Video_NPU_0__m_axi_arid_soft_o ;
    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_arid ;
    wire [5:0]        w_net__Video_NPU_0__m_axi_arid_soft_o ; 

    wire [3:0]        w_port__Video_NPU_0__m_axi_arlen_soft_o ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_arlen ;
    wire [3:0]        w_net__Video_NPU_0__m_axi_arlen_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_arlock_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_arlock ;
    wire              w_net__Video_NPU_0__m_axi_arlock_soft_o ; 

    wire [2:0]        w_port__Video_NPU_0__m_axi_arprot_soft_o ;
    wire [2:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_arprot ;
    wire [2:0]        w_net__Video_NPU_0__m_axi_arprot_soft_o ; 

    wire [1:0]        w_port__Video_NPU_0__m_axi_arsize_soft_o ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_arsize ;
    wire [1:0]        w_net__Video_NPU_0__m_axi_arsize_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_arvalid_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_arvalid ;
    wire              w_net__Video_NPU_0__m_axi_arvalid_soft_o ; 

    wire [32:0]       w_port__Video_NPU_0__m_axi_awaddr_soft_o ;
    wire [32:0]       w_port__ARM_Processor_System_0__slave_hp1_axi_awaddr ;
    wire [32:0]       w_net__Video_NPU_0__m_axi_awaddr_soft_o ; 

    wire [1:0]        w_port__Video_NPU_0__m_axi_awburst_soft_o ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_awburst ;
    wire [1:0]        w_net__Video_NPU_0__m_axi_awburst_soft_o ; 

    wire [3:0]        w_port__Video_NPU_0__m_axi_awcache_soft_o ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_awcache ;
    wire [3:0]        w_net__Video_NPU_0__m_axi_awcache_soft_o ; 

    wire [5:0]        w_port__Video_NPU_0__m_axi_awid_soft_o ;
    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_awid ;
    wire [5:0]        w_net__Video_NPU_0__m_axi_awid_soft_o ; 

    wire [3:0]        w_port__Video_NPU_0__m_axi_awlen_soft_o ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_awlen ;
    wire [3:0]        w_net__Video_NPU_0__m_axi_awlen_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_awlock_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_awlock ;
    wire              w_net__Video_NPU_0__m_axi_awlock_soft_o ; 

    wire [2:0]        w_port__Video_NPU_0__m_axi_awprot_soft_o ;
    wire [2:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_awprot ;
    wire [2:0]        w_net__Video_NPU_0__m_axi_awprot_soft_o ; 

    wire [1:0]        w_port__Video_NPU_0__m_axi_awsize_soft_o ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_awsize ;
    wire [1:0]        w_net__Video_NPU_0__m_axi_awsize_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_awvalid_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_awvalid ;
    wire              w_net__Video_NPU_0__m_axi_awvalid_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_bready_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_bready ;
    wire              w_net__Video_NPU_0__m_axi_bready_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_rready_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_rready ;
    wire              w_net__Video_NPU_0__m_axi_rready_soft_o ; 

    wire [63:0]       w_port__Video_NPU_0__m_axi_wdata_soft_o ;
    wire [63:0]       w_port__ARM_Processor_System_0__slave_hp1_axi_wdata ;
    wire [63:0]       w_net__Video_NPU_0__m_axi_wdata_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_wlast_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_wlast ;
    wire              w_net__Video_NPU_0__m_axi_wlast_soft_o ; 

    wire [7:0]        w_port__Video_NPU_0__m_axi_wstrb_soft_o ;
    wire [7:0]        w_port__ARM_Processor_System_0__slave_hp1_axi_wstrb ;
    wire [7:0]        w_net__Video_NPU_0__m_axi_wstrb_soft_o ; 

    wire              w_port__Video_NPU_0__m_axi_wvalid_soft_o ;
    wire              w_port__ARM_Processor_System_0__slave_hp1_axi_wvalid ;
    wire              w_net__Video_NPU_0__m_axi_wvalid_soft_o ; 

    wire              w_port__Video_NPU_0__npu_soft_intr ;
    wire [0:0]        w_port__Concat_0__In3 ;
    wire              w_net__Video_NPU_0__npu_soft_intr ; 

    wire              w_port__Video_NPU_0__s_axilite_arready_o ;
    wire              w_port__AXI_Matrix_0__ds1_arready ;
    wire              w_net__Video_NPU_0__s_axilite_arready_o ; 

    wire              w_port__Video_NPU_0__s_axilite_awready_o ;
    wire              w_port__AXI_Matrix_0__ds1_awready ;
    wire              w_net__Video_NPU_0__s_axilite_awready_o ; 

    wire [1:0]        w_port__Video_NPU_0__s_axilite_bresp_o ;
    wire [1:0]        w_port__AXI_Matrix_0__ds1_bresp ;
    wire [1:0]        w_net__Video_NPU_0__s_axilite_bresp_o ; 

    wire              w_port__Video_NPU_0__s_axilite_bvalid_o ;
    wire              w_port__AXI_Matrix_0__ds1_bvalid ;
    wire              w_net__Video_NPU_0__s_axilite_bvalid_o ; 

    wire [31:0]       w_port__Video_NPU_0__s_axilite_rdata_o ;
    wire [31:0]       w_port__AXI_Matrix_0__ds1_rdata ;
    wire [31:0]       w_net__Video_NPU_0__s_axilite_rdata_o ; 

    wire [1:0]        w_port__Video_NPU_0__s_axilite_rresp_o ;
    wire [1:0]        w_port__AXI_Matrix_0__ds1_rresp ;
    wire [1:0]        w_net__Video_NPU_0__s_axilite_rresp_o ; 

    wire              w_port__Video_NPU_0__s_axilite_rvalid_o ;
    wire              w_port__AXI_Matrix_0__ds1_rvalid ;
    wire              w_net__Video_NPU_0__s_axilite_rvalid_o ; 

    wire              w_port__Video_NPU_0__s_axilite_wready_o ;
    wire              w_port__AXI_Matrix_0__ds1_wready ;
    wire              w_net__Video_NPU_0__s_axilite_wready_o ; 

    wire [31:0]       w_port__uiFDMA_0__M_AXI_ARADDR ;
    wire [32:0]       w_port__ARM_Processor_System_0__slave_hp0_axi_araddr ;
    wire [31:0]       w_net__uiFDMA_0__M_AXI_ARADDR ; 

    wire [1:0]        w_port__uiFDMA_0__M_AXI_ARBURST ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arburst ;
    wire [1:0]        w_net__uiFDMA_0__M_AXI_ARBURST ; 

    wire [3:0]        w_port__uiFDMA_0__M_AXI_ARCACHE ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arcache ;
    wire [3:0]        w_net__uiFDMA_0__M_AXI_ARCACHE ; 

    wire [5:0]        w_port__uiFDMA_0__M_AXI_ARID ;
    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arid ;
    wire [5:0]        w_net__uiFDMA_0__M_AXI_ARID ; 

    wire [7:0]        w_port__uiFDMA_0__M_AXI_ARLEN ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arlen ;
    wire [7:0]        w_net__uiFDMA_0__M_AXI_ARLEN ; 

    wire              w_port__uiFDMA_0__M_AXI_ARLOCK ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_arlock ;
    wire              w_net__uiFDMA_0__M_AXI_ARLOCK ; 

    wire [2:0]        w_port__uiFDMA_0__M_AXI_ARPROT ;
    wire [2:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arprot ;
    wire [2:0]        w_net__uiFDMA_0__M_AXI_ARPROT ; 

    wire [3:0]        w_port__uiFDMA_0__M_AXI_ARQOS ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arqos ;
    wire [3:0]        w_net__uiFDMA_0__M_AXI_ARQOS ; 

    wire [2:0]        w_port__uiFDMA_0__M_AXI_ARSIZE ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_arsize ;
    wire [2:0]        w_net__uiFDMA_0__M_AXI_ARSIZE ; 

    wire              w_port__uiFDMA_0__M_AXI_ARVALID ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_arvalid ;
    wire              w_net__uiFDMA_0__M_AXI_ARVALID ; 

    wire [31:0]       w_port__uiFDMA_0__M_AXI_AWADDR ;
    wire [32:0]       w_port__ARM_Processor_System_0__slave_hp0_axi_awaddr ;
    wire [31:0]       w_net__uiFDMA_0__M_AXI_AWADDR ; 

    wire [1:0]        w_port__uiFDMA_0__M_AXI_AWBURST ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awburst ;
    wire [1:0]        w_net__uiFDMA_0__M_AXI_AWBURST ; 

    wire [3:0]        w_port__uiFDMA_0__M_AXI_AWCACHE ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awcache ;
    wire [3:0]        w_net__uiFDMA_0__M_AXI_AWCACHE ; 

    wire [5:0]        w_port__uiFDMA_0__M_AXI_AWID ;
    wire [5:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awid ;
    wire [5:0]        w_net__uiFDMA_0__M_AXI_AWID ; 

    wire [7:0]        w_port__uiFDMA_0__M_AXI_AWLEN ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awlen ;
    wire [7:0]        w_net__uiFDMA_0__M_AXI_AWLEN ; 

    wire              w_port__uiFDMA_0__M_AXI_AWLOCK ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_awlock ;
    wire              w_net__uiFDMA_0__M_AXI_AWLOCK ; 

    wire [2:0]        w_port__uiFDMA_0__M_AXI_AWPROT ;
    wire [2:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awprot ;
    wire [2:0]        w_net__uiFDMA_0__M_AXI_AWPROT ; 

    wire [3:0]        w_port__uiFDMA_0__M_AXI_AWQOS ;
    wire [3:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awqos ;
    wire [3:0]        w_net__uiFDMA_0__M_AXI_AWQOS ; 

    wire [2:0]        w_port__uiFDMA_0__M_AXI_AWSIZE ;
    wire [1:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_awsize ;
    wire [2:0]        w_net__uiFDMA_0__M_AXI_AWSIZE ; 

    wire              w_port__uiFDMA_0__M_AXI_AWVALID ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_awvalid ;
    wire              w_net__uiFDMA_0__M_AXI_AWVALID ; 

    wire              w_port__uiFDMA_0__M_AXI_BREADY ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_bready ;
    wire              w_net__uiFDMA_0__M_AXI_BREADY ; 

    wire              w_port__uiFDMA_0__M_AXI_RREADY ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_rready ;
    wire              w_net__uiFDMA_0__M_AXI_RREADY ; 

    wire [63:0]       w_port__uiFDMA_0__M_AXI_WDATA ;
    wire [63:0]       w_port__ARM_Processor_System_0__slave_hp0_axi_wdata ;
    wire [63:0]       w_net__uiFDMA_0__M_AXI_WDATA ; 

    wire              w_port__uiFDMA_0__M_AXI_WLAST ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_wlast ;
    wire              w_net__uiFDMA_0__M_AXI_WLAST ; 

    wire [7:0]        w_port__uiFDMA_0__M_AXI_WSTRB ;
    wire [7:0]        w_port__ARM_Processor_System_0__slave_hp0_axi_wstrb ;
    wire [7:0]        w_net__uiFDMA_0__M_AXI_WSTRB ; 

    wire              w_port__uiFDMA_0__M_AXI_WVALID ;
    wire              w_port__ARM_Processor_System_0__slave_hp0_axi_wvalid ;
    wire              w_net__uiFDMA_0__M_AXI_WVALID ; 

    wire              w_port__uiFDMA_0__O_fdma_rbusy ;
    wire              w_net__uiFDMA_0__O_fdma_rbusy ; 

    wire [63:0]       w_port__uiFDMA_0__O_fdma_rdata ;
    wire [63:0]       w_net__uiFDMA_0__O_fdma_rdata ; 

    wire              w_port__uiFDMA_0__O_fdma_rvalid ;
    wire              w_net__uiFDMA_0__O_fdma_rvalid ; 

    wire              w_port__uiFDMA_0__O_fdma_wbusy ;
    wire              w_net__uiFDMA_0__O_fdma_wbusy ; 

    wire              w_port__uiFDMA_0__O_fdma_wvalid ;
    wire              w_net__uiFDMA_0__O_fdma_wvalid ; 

    wire              w_port__uihdmi_tx_0__O_hdmi_clk_p ;
    wire              w_net__uihdmi_tx_0__O_hdmi_clk_p ; 

    wire [2:0]        w_port__uihdmi_tx_0__O_hdmi_tx_p ;
    wire [2:0]        w_net__uihdmi_tx_0__O_hdmi_tx_p ; 








    wire [32:0]       w_port__AXI_Matrix_0__ds0_araddr ;
    wire [11:0]       w_port__temporal_conv_0__S_AXI_ARADDR ;
    wire [32:0]       w_net__AXI_Matrix_0__ds0_araddr ; 

    wire [2:0]        w_port__AXI_Matrix_0__ds0_arprot ;
    wire [2:0]        w_port__temporal_conv_0__S_AXI_ARPROT ;
    wire [2:0]        w_net__AXI_Matrix_0__ds0_arprot ; 

    wire              w_port__temporal_conv_0__S_AXI_ARREADY ;
    wire              w_port__AXI_Matrix_0__ds0_arready ;
    wire              w_net__temporal_conv_0__S_AXI_ARREADY ; 

    wire              w_port__AXI_Matrix_0__ds0_arvalid ;
    wire              w_port__temporal_conv_0__S_AXI_ARVALID ;
    wire              w_net__AXI_Matrix_0__ds0_arvalid ; 

    wire [32:0]       w_port__AXI_Matrix_0__ds0_awaddr ;
    wire [11:0]       w_port__temporal_conv_0__S_AXI_AWADDR ;
    wire [32:0]       w_net__AXI_Matrix_0__ds0_awaddr ; 

    wire [2:0]        w_port__AXI_Matrix_0__ds0_awprot ;
    wire [2:0]        w_port__temporal_conv_0__S_AXI_AWPROT ;
    wire [2:0]        w_net__AXI_Matrix_0__ds0_awprot ; 

    wire              w_port__temporal_conv_0__S_AXI_AWREADY ;
    wire              w_port__AXI_Matrix_0__ds0_awready ;
    wire              w_net__temporal_conv_0__S_AXI_AWREADY ; 

    wire              w_port__AXI_Matrix_0__ds0_awvalid ;
    wire              w_port__temporal_conv_0__S_AXI_AWVALID ;
    wire              w_net__AXI_Matrix_0__ds0_awvalid ; 

    wire              w_port__AXI_Matrix_0__ds0_bready ;
    wire              w_port__temporal_conv_0__S_AXI_BREADY ;
    wire              w_net__AXI_Matrix_0__ds0_bready ; 

    wire [1:0]        w_port__temporal_conv_0__S_AXI_BRESP ;
    wire [1:0]        w_port__AXI_Matrix_0__ds0_bresp ;
    wire [1:0]        w_net__temporal_conv_0__S_AXI_BRESP ; 

    wire              w_port__temporal_conv_0__S_AXI_BVALID ;
    wire              w_port__AXI_Matrix_0__ds0_bvalid ;
    wire              w_net__temporal_conv_0__S_AXI_BVALID ; 

    wire [31:0]       w_port__temporal_conv_0__S_AXI_RDATA ;
    wire [31:0]       w_port__AXI_Matrix_0__ds0_rdata ;
    wire [31:0]       w_net__temporal_conv_0__S_AXI_RDATA ; 

    wire              w_port__AXI_Matrix_0__ds0_rready ;
    wire              w_port__temporal_conv_0__S_AXI_RREADY ;
    wire              w_net__AXI_Matrix_0__ds0_rready ; 

    wire [1:0]        w_port__temporal_conv_0__S_AXI_RRESP ;
    wire [1:0]        w_port__AXI_Matrix_0__ds0_rresp ;
    wire [1:0]        w_net__temporal_conv_0__S_AXI_RRESP ; 

    wire              w_port__temporal_conv_0__S_AXI_RVALID ;
    wire              w_port__AXI_Matrix_0__ds0_rvalid ;
    wire              w_net__temporal_conv_0__S_AXI_RVALID ; 

    wire [31:0]       w_port__AXI_Matrix_0__ds0_wdata ;
    wire [31:0]       w_port__temporal_conv_0__S_AXI_WDATA ;
    wire [31:0]       w_net__AXI_Matrix_0__ds0_wdata ; 

    wire              w_port__temporal_conv_0__S_AXI_WREADY ;
    wire              w_port__AXI_Matrix_0__ds0_wready ;
    wire              w_net__temporal_conv_0__S_AXI_WREADY ; 

    wire [3:0]        w_port__AXI_Matrix_0__ds0_wstrb ;
    wire [3:0]        w_port__temporal_conv_0__S_AXI_WSTRB ;
    wire [3:0]        w_net__AXI_Matrix_0__ds0_wstrb ; 

    wire              w_port__AXI_Matrix_0__ds0_wvalid ;
    wire              w_port__temporal_conv_0__S_AXI_WVALID ;
    wire              w_net__AXI_Matrix_0__ds0_wvalid ; 

    assign w_net__ARM_Processor_System_0__master_gp0_axi_araddr = w_port__ARM_Processor_System_0__master_gp0_axi_araddr ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_araddr = w_net__ARM_Processor_System_0__master_gp0_axi_araddr ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arburst = w_port__ARM_Processor_System_0__master_gp0_axi_arburst ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arburst = w_net__ARM_Processor_System_0__master_gp0_axi_arburst ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arcache = w_port__ARM_Processor_System_0__master_gp0_axi_arcache ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arcache = w_net__ARM_Processor_System_0__master_gp0_axi_arcache ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arid = w_port__ARM_Processor_System_0__master_gp0_axi_arid ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arid = w_net__ARM_Processor_System_0__master_gp0_axi_arid ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arlen = w_port__ARM_Processor_System_0__master_gp0_axi_arlen ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arlen = {4'b0,w_net__ARM_Processor_System_0__master_gp0_axi_arlen} ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arlock = w_port__ARM_Processor_System_0__master_gp0_axi_arlock ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arlock = w_net__ARM_Processor_System_0__master_gp0_axi_arlock ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arprot = w_port__ARM_Processor_System_0__master_gp0_axi_arprot ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arprot = w_net__ARM_Processor_System_0__master_gp0_axi_arprot ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arsize = w_port__ARM_Processor_System_0__master_gp0_axi_arsize ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arsize = {1'b0,w_net__ARM_Processor_System_0__master_gp0_axi_arsize} ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_arvalid = w_port__ARM_Processor_System_0__master_gp0_axi_arvalid ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_arvalid = w_net__ARM_Processor_System_0__master_gp0_axi_arvalid ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awaddr = w_port__ARM_Processor_System_0__master_gp0_axi_awaddr ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awaddr = w_net__ARM_Processor_System_0__master_gp0_axi_awaddr ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awburst = w_port__ARM_Processor_System_0__master_gp0_axi_awburst ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awburst = w_net__ARM_Processor_System_0__master_gp0_axi_awburst ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awcache = w_port__ARM_Processor_System_0__master_gp0_axi_awcache ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awcache = w_net__ARM_Processor_System_0__master_gp0_axi_awcache ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awid = w_port__ARM_Processor_System_0__master_gp0_axi_awid ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awid = w_net__ARM_Processor_System_0__master_gp0_axi_awid ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awlen = w_port__ARM_Processor_System_0__master_gp0_axi_awlen ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awlen = {4'b0,w_net__ARM_Processor_System_0__master_gp0_axi_awlen} ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awlock = w_port__ARM_Processor_System_0__master_gp0_axi_awlock ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awlock = w_net__ARM_Processor_System_0__master_gp0_axi_awlock ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awprot = w_port__ARM_Processor_System_0__master_gp0_axi_awprot ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awprot = w_net__ARM_Processor_System_0__master_gp0_axi_awprot ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awsize = w_port__ARM_Processor_System_0__master_gp0_axi_awsize ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awsize = {1'b0,w_net__ARM_Processor_System_0__master_gp0_axi_awsize} ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_awvalid = w_port__ARM_Processor_System_0__master_gp0_axi_awvalid ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_awvalid = w_net__ARM_Processor_System_0__master_gp0_axi_awvalid ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_bready = w_port__ARM_Processor_System_0__master_gp0_axi_bready ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_bready = w_net__ARM_Processor_System_0__master_gp0_axi_bready ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_rready = w_port__ARM_Processor_System_0__master_gp0_axi_rready ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_rready = w_net__ARM_Processor_System_0__master_gp0_axi_rready ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_wdata = w_port__ARM_Processor_System_0__master_gp0_axi_wdata ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_wdata = w_net__ARM_Processor_System_0__master_gp0_axi_wdata ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_wlast = w_port__ARM_Processor_System_0__master_gp0_axi_wlast ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_wlast = w_net__ARM_Processor_System_0__master_gp0_axi_wlast ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_wstrb = w_port__ARM_Processor_System_0__master_gp0_axi_wstrb ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_wstrb = w_net__ARM_Processor_System_0__master_gp0_axi_wstrb ;

    assign w_net__ARM_Processor_System_0__master_gp0_axi_wvalid = w_port__ARM_Processor_System_0__master_gp0_axi_wvalid ;
    assign w_port__AXI_Protocol_Converter_0__us_axi_wvalid = w_net__ARM_Processor_System_0__master_gp0_axi_wvalid ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_araddr = w_port__ARM_Processor_System_0__master_gp1_axi_araddr ;
    assign w_port__AXI_ERAM_Controller_0__araddr = w_net__ARM_Processor_System_0__master_gp1_axi_araddr ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_arburst = w_port__ARM_Processor_System_0__master_gp1_axi_arburst ;
    assign w_port__AXI_ERAM_Controller_0__arburst = w_net__ARM_Processor_System_0__master_gp1_axi_arburst ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_arid = w_port__ARM_Processor_System_0__master_gp1_axi_arid ;
    assign w_port__AXI_ERAM_Controller_0__arid = w_net__ARM_Processor_System_0__master_gp1_axi_arid ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_arlen = w_port__ARM_Processor_System_0__master_gp1_axi_arlen ;
    assign w_port__AXI_ERAM_Controller_0__arlen = {4'b0,w_net__ARM_Processor_System_0__master_gp1_axi_arlen} ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_arlock = w_port__ARM_Processor_System_0__master_gp1_axi_arlock ;
    assign w_port__AXI_ERAM_Controller_0__arlock = w_net__ARM_Processor_System_0__master_gp1_axi_arlock ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_arsize = w_port__ARM_Processor_System_0__master_gp1_axi_arsize ;
    assign w_port__AXI_ERAM_Controller_0__arsize = {1'b0,w_net__ARM_Processor_System_0__master_gp1_axi_arsize} ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_arvalid = w_port__ARM_Processor_System_0__master_gp1_axi_arvalid ;
    assign w_port__AXI_ERAM_Controller_0__arvalid = w_net__ARM_Processor_System_0__master_gp1_axi_arvalid ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awaddr = w_port__ARM_Processor_System_0__master_gp1_axi_awaddr ;
    assign w_port__AXI_ERAM_Controller_0__awaddr = w_net__ARM_Processor_System_0__master_gp1_axi_awaddr ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awburst = w_port__ARM_Processor_System_0__master_gp1_axi_awburst ;
    assign w_port__AXI_ERAM_Controller_0__awburst = w_net__ARM_Processor_System_0__master_gp1_axi_awburst ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awid = w_port__ARM_Processor_System_0__master_gp1_axi_awid ;
    assign w_port__AXI_ERAM_Controller_0__awid = w_net__ARM_Processor_System_0__master_gp1_axi_awid ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awlen = w_port__ARM_Processor_System_0__master_gp1_axi_awlen ;
    assign w_port__AXI_ERAM_Controller_0__awlen = {4'b0,w_net__ARM_Processor_System_0__master_gp1_axi_awlen} ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awlock = w_port__ARM_Processor_System_0__master_gp1_axi_awlock ;
    assign w_port__AXI_ERAM_Controller_0__awlock = w_net__ARM_Processor_System_0__master_gp1_axi_awlock ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awsize = w_port__ARM_Processor_System_0__master_gp1_axi_awsize ;
    assign w_port__AXI_ERAM_Controller_0__awsize = {1'b0,w_net__ARM_Processor_System_0__master_gp1_axi_awsize} ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_awvalid = w_port__ARM_Processor_System_0__master_gp1_axi_awvalid ;
    assign w_port__AXI_ERAM_Controller_0__awvalid = w_net__ARM_Processor_System_0__master_gp1_axi_awvalid ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_bready = w_port__ARM_Processor_System_0__master_gp1_axi_bready ;
    assign w_port__AXI_ERAM_Controller_0__bready = w_net__ARM_Processor_System_0__master_gp1_axi_bready ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_rready = w_port__ARM_Processor_System_0__master_gp1_axi_rready ;
    assign w_port__AXI_ERAM_Controller_0__rready = w_net__ARM_Processor_System_0__master_gp1_axi_rready ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_wdata = w_port__ARM_Processor_System_0__master_gp1_axi_wdata ;
    assign w_port__AXI_ERAM_Controller_0__wdata = w_net__ARM_Processor_System_0__master_gp1_axi_wdata ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_wstrb = w_port__ARM_Processor_System_0__master_gp1_axi_wstrb ;
    assign w_port__AXI_ERAM_Controller_0__wstrb = w_net__ARM_Processor_System_0__master_gp1_axi_wstrb ;

    assign w_net__ARM_Processor_System_0__master_gp1_axi_wvalid = w_port__ARM_Processor_System_0__master_gp1_axi_wvalid ;
    assign w_port__AXI_ERAM_Controller_0__wvalid = w_net__ARM_Processor_System_0__master_gp1_axi_wvalid ;

    assign w_net__ARM_Processor_System_0__p2f_clk0 = w_port__ARM_Processor_System_0__p2f_clk0 ;
    assign O_ui_clk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__Processor_System_Reset_0_200__clk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__uiFDMA_0__M_AXI_ACLK = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__Video_NPU_0__M_AXI_ACLK = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__Processor_System_Reset_0__clk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__AXI_ERAM_Controller_0__aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__Video_NPU_0__S_AXILite_ACLK = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__AXI_Protocol_Converter_0__aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__AXI_Matrix_0__aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;
    assign w_port__temporal_conv_0__aclk = w_net__ARM_Processor_System_0__p2f_clk0 ;

    assign w_net__ARM_Processor_System_0__p2f_clk1 = w_port__ARM_Processor_System_0__p2f_clk1 ;
    assign O_mclk = w_net__ARM_Processor_System_0__p2f_clk1 ;

    assign w_net__ARM_Processor_System_0__p2f_clk2 = w_port__ARM_Processor_System_0__p2f_clk2 ;
    assign O_refclk = w_net__ARM_Processor_System_0__p2f_clk2 ;

    assign w_net__ARM_Processor_System_0__p2f_rst0_n = w_port__ARM_Processor_System_0__p2f_rst0_n ;
    assign w_port__Processor_System_Reset_0__external_reset = w_net__ARM_Processor_System_0__p2f_rst0_n ;

    assign w_net__ARM_Processor_System_0__pl_gpio_out = w_port__ARM_Processor_System_0__pl_gpio_out ;
    assign w_port__Processor_System_Reset_0_200__external_reset = w_net__ARM_Processor_System_0__pl_gpio_out ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_arready = w_port__ARM_Processor_System_0__slave_hp0_axi_arready ;
    assign w_port__uiFDMA_0__M_AXI_ARREADY = w_net__ARM_Processor_System_0__slave_hp0_axi_arready ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_awready = w_port__ARM_Processor_System_0__slave_hp0_axi_awready ;
    assign w_port__uiFDMA_0__M_AXI_AWREADY = w_net__ARM_Processor_System_0__slave_hp0_axi_awready ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_bid = w_port__ARM_Processor_System_0__slave_hp0_axi_bid ;
    assign w_port__uiFDMA_0__M_AXI_BID = w_net__ARM_Processor_System_0__slave_hp0_axi_bid ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_bresp = w_port__ARM_Processor_System_0__slave_hp0_axi_bresp ;
    assign w_port__uiFDMA_0__M_AXI_BRESP = w_net__ARM_Processor_System_0__slave_hp0_axi_bresp ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_bvalid = w_port__ARM_Processor_System_0__slave_hp0_axi_bvalid ;
    assign w_port__uiFDMA_0__M_AXI_BVALID = w_net__ARM_Processor_System_0__slave_hp0_axi_bvalid ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_rdata = w_port__ARM_Processor_System_0__slave_hp0_axi_rdata ;
    assign w_port__uiFDMA_0__M_AXI_RDATA = w_net__ARM_Processor_System_0__slave_hp0_axi_rdata ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_rid = w_port__ARM_Processor_System_0__slave_hp0_axi_rid ;
    assign w_port__uiFDMA_0__M_AXI_RID = w_net__ARM_Processor_System_0__slave_hp0_axi_rid ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_rlast = w_port__ARM_Processor_System_0__slave_hp0_axi_rlast ;
    assign w_port__uiFDMA_0__M_AXI_RLAST = w_net__ARM_Processor_System_0__slave_hp0_axi_rlast ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_rresp = w_port__ARM_Processor_System_0__slave_hp0_axi_rresp ;
    assign w_port__uiFDMA_0__M_AXI_RRESP = w_net__ARM_Processor_System_0__slave_hp0_axi_rresp ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_rvalid = w_port__ARM_Processor_System_0__slave_hp0_axi_rvalid ;
    assign w_port__uiFDMA_0__M_AXI_RVALID = w_net__ARM_Processor_System_0__slave_hp0_axi_rvalid ;

    assign w_net__ARM_Processor_System_0__slave_hp0_axi_wready = w_port__ARM_Processor_System_0__slave_hp0_axi_wready ;
    assign w_port__uiFDMA_0__M_AXI_WREADY = w_net__ARM_Processor_System_0__slave_hp0_axi_wready ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_arready = w_port__ARM_Processor_System_0__slave_hp1_axi_arready ;
    assign w_port__Video_NPU_0__m_axi_arready_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_arready ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_awready = w_port__ARM_Processor_System_0__slave_hp1_axi_awready ;
    assign w_port__Video_NPU_0__m_axi_awready_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_awready ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_bid = w_port__ARM_Processor_System_0__slave_hp1_axi_bid ;
    assign w_port__Video_NPU_0__m_axi_bid_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_bid ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_bresp = w_port__ARM_Processor_System_0__slave_hp1_axi_bresp ;
    assign w_port__Video_NPU_0__m_axi_bresp_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_bresp ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_bvalid = w_port__ARM_Processor_System_0__slave_hp1_axi_bvalid ;
    assign w_port__Video_NPU_0__m_axi_bvalid_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_bvalid ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_rdata = w_port__ARM_Processor_System_0__slave_hp1_axi_rdata ;
    assign w_port__Video_NPU_0__m_axi_rdata_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_rdata ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_rid = w_port__ARM_Processor_System_0__slave_hp1_axi_rid ;
    assign w_port__Video_NPU_0__m_axi_rid_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_rid ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_rlast = w_port__ARM_Processor_System_0__slave_hp1_axi_rlast ;
    assign w_port__Video_NPU_0__m_axi_rlast_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_rlast ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_rresp = w_port__ARM_Processor_System_0__slave_hp1_axi_rresp ;
    assign w_port__Video_NPU_0__m_axi_rresp_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_rresp ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_rvalid = w_port__ARM_Processor_System_0__slave_hp1_axi_rvalid ;
    assign w_port__Video_NPU_0__m_axi_rvalid_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_rvalid ;

    assign w_net__ARM_Processor_System_0__slave_hp1_axi_wready = w_port__ARM_Processor_System_0__slave_hp1_axi_wready ;
    assign w_port__Video_NPU_0__m_axi_wready_soft_i = w_net__ARM_Processor_System_0__slave_hp1_axi_wready ;

    assign w_net__AXI_ERAM_Controller_0__arready = w_port__AXI_ERAM_Controller_0__arready ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_arready = w_net__AXI_ERAM_Controller_0__arready ;

    assign w_net__AXI_ERAM_Controller_0__awready = w_port__AXI_ERAM_Controller_0__awready ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_awready = w_net__AXI_ERAM_Controller_0__awready ;

    assign w_net__AXI_ERAM_Controller_0__bid = w_port__AXI_ERAM_Controller_0__bid ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_bid = w_net__AXI_ERAM_Controller_0__bid ;

    assign w_net__AXI_ERAM_Controller_0__bresp = w_port__AXI_ERAM_Controller_0__bresp ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_bresp = w_net__AXI_ERAM_Controller_0__bresp ;

    assign w_net__AXI_ERAM_Controller_0__bvalid = w_port__AXI_ERAM_Controller_0__bvalid ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_bvalid = w_net__AXI_ERAM_Controller_0__bvalid ;

    assign w_net__AXI_ERAM_Controller_0__mem_addr = w_port__AXI_ERAM_Controller_0__mem_addr ;
    assign O_maddr = w_net__AXI_ERAM_Controller_0__mem_addr ;

    assign w_net__AXI_ERAM_Controller_0__mem_csb = w_port__AXI_ERAM_Controller_0__mem_csb ;
    assign O_mcsb = w_net__AXI_ERAM_Controller_0__mem_csb ;

    assign w_net__AXI_ERAM_Controller_0__mem_din = w_port__AXI_ERAM_Controller_0__mem_din ;
    assign O_mrdata = w_net__AXI_ERAM_Controller_0__mem_din ;

    assign w_net__AXI_ERAM_Controller_0__mem_web = w_port__AXI_ERAM_Controller_0__mem_web ;
    assign O_mweb = w_net__AXI_ERAM_Controller_0__mem_web ;

    assign w_net__AXI_ERAM_Controller_0__rdata = w_port__AXI_ERAM_Controller_0__rdata ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_rdata = w_net__AXI_ERAM_Controller_0__rdata ;

    assign w_net__AXI_ERAM_Controller_0__rid = w_port__AXI_ERAM_Controller_0__rid ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_rid = w_net__AXI_ERAM_Controller_0__rid ;

    assign w_net__AXI_ERAM_Controller_0__rlast = w_port__AXI_ERAM_Controller_0__rlast ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_rlast = w_net__AXI_ERAM_Controller_0__rlast ;

    assign w_net__AXI_ERAM_Controller_0__rresp = w_port__AXI_ERAM_Controller_0__rresp ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_rresp = w_net__AXI_ERAM_Controller_0__rresp ;

    assign w_net__AXI_ERAM_Controller_0__rvalid = w_port__AXI_ERAM_Controller_0__rvalid ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_rvalid = w_net__AXI_ERAM_Controller_0__rvalid ;

    assign w_net__AXI_ERAM_Controller_0__wready = w_port__AXI_ERAM_Controller_0__wready ;
    assign w_port__ARM_Processor_System_0__master_gp1_axi_wready = w_net__AXI_ERAM_Controller_0__wready ;

    assign w_net__AXI_Matrix_0__ds1_araddr = w_port__AXI_Matrix_0__ds1_araddr ;
    assign w_port__Video_NPU_0__s_axilite_araddr_i = w_net__AXI_Matrix_0__ds1_araddr ;

    assign w_net__AXI_Matrix_0__ds1_arprot = w_port__AXI_Matrix_0__ds1_arprot ;
    assign w_port__Video_NPU_0__s_axilite_arprot_i = w_net__AXI_Matrix_0__ds1_arprot ;

    assign w_net__AXI_Matrix_0__ds1_arvalid = w_port__AXI_Matrix_0__ds1_arvalid ;
    assign w_port__Video_NPU_0__s_axilite_arvalid_i = w_net__AXI_Matrix_0__ds1_arvalid ;

    assign w_net__AXI_Matrix_0__ds1_awaddr = w_port__AXI_Matrix_0__ds1_awaddr ;
    assign w_port__Video_NPU_0__s_axilite_awaddr_i = w_net__AXI_Matrix_0__ds1_awaddr ;

    assign w_net__AXI_Matrix_0__ds1_awprot = w_port__AXI_Matrix_0__ds1_awprot ;
    assign w_port__Video_NPU_0__s_axilite_awprot_i = w_net__AXI_Matrix_0__ds1_awprot ;

    assign w_net__AXI_Matrix_0__ds1_awvalid = w_port__AXI_Matrix_0__ds1_awvalid ;
    assign w_port__Video_NPU_0__s_axilite_awvalid_i = w_net__AXI_Matrix_0__ds1_awvalid ;

    assign w_net__AXI_Matrix_0__ds1_bready = w_port__AXI_Matrix_0__ds1_bready ;
    assign w_port__Video_NPU_0__s_axilite_bready_i = w_net__AXI_Matrix_0__ds1_bready ;

    assign w_net__AXI_Matrix_0__ds1_rready = w_port__AXI_Matrix_0__ds1_rready ;
    assign w_port__Video_NPU_0__s_axilite_rready_i = w_net__AXI_Matrix_0__ds1_rready ;

    assign w_net__AXI_Matrix_0__ds1_wdata = w_port__AXI_Matrix_0__ds1_wdata ;
    assign w_port__Video_NPU_0__s_axilite_wdata_i = w_net__AXI_Matrix_0__ds1_wdata ;

    assign w_net__AXI_Matrix_0__ds1_wstrb = w_port__AXI_Matrix_0__ds1_wstrb ;
    assign w_port__Video_NPU_0__s_axilite_wstrb_i = w_net__AXI_Matrix_0__ds1_wstrb ;

    assign w_net__AXI_Matrix_0__ds1_wvalid = w_port__AXI_Matrix_0__ds1_wvalid ;
    assign w_port__Video_NPU_0__s_axilite_wvalid_i = w_net__AXI_Matrix_0__ds1_wvalid ;

    assign w_net__AXI_Matrix_0__us0_arready = w_port__AXI_Matrix_0__us0_arready ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_arready = w_net__AXI_Matrix_0__us0_arready ;

    assign w_net__AXI_Matrix_0__us0_awready = w_port__AXI_Matrix_0__us0_awready ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_awready = w_net__AXI_Matrix_0__us0_awready ;

    assign w_net__AXI_Matrix_0__us0_bresp = w_port__AXI_Matrix_0__us0_bresp ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_bresp = w_net__AXI_Matrix_0__us0_bresp ;

    assign w_net__AXI_Matrix_0__us0_bvalid = w_port__AXI_Matrix_0__us0_bvalid ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_bvalid = w_net__AXI_Matrix_0__us0_bvalid ;

    assign w_net__AXI_Matrix_0__us0_rdata = w_port__AXI_Matrix_0__us0_rdata ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_rdata = w_net__AXI_Matrix_0__us0_rdata ;

    assign w_net__AXI_Matrix_0__us0_rresp = w_port__AXI_Matrix_0__us0_rresp ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_rresp = w_net__AXI_Matrix_0__us0_rresp ;

    assign w_net__AXI_Matrix_0__us0_rvalid = w_port__AXI_Matrix_0__us0_rvalid ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_rvalid = w_net__AXI_Matrix_0__us0_rvalid ;

    assign w_net__AXI_Matrix_0__us0_wready = w_port__AXI_Matrix_0__us0_wready ;
    assign w_port__AXI_Protocol_Converter_0__ds_axi_wready = w_net__AXI_Matrix_0__us0_wready ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_araddr = w_port__AXI_Protocol_Converter_0__ds_axi_araddr ;
    assign w_port__AXI_Matrix_0__us0_araddr = w_net__AXI_Protocol_Converter_0__ds_axi_araddr ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_arprot = w_port__AXI_Protocol_Converter_0__ds_axi_arprot ;
    assign w_port__AXI_Matrix_0__us0_arprot = w_net__AXI_Protocol_Converter_0__ds_axi_arprot ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_arvalid = w_port__AXI_Protocol_Converter_0__ds_axi_arvalid ;
    assign w_port__AXI_Matrix_0__us0_arvalid = w_net__AXI_Protocol_Converter_0__ds_axi_arvalid ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_awaddr = w_port__AXI_Protocol_Converter_0__ds_axi_awaddr ;
    assign w_port__AXI_Matrix_0__us0_awaddr = w_net__AXI_Protocol_Converter_0__ds_axi_awaddr ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_awprot = w_port__AXI_Protocol_Converter_0__ds_axi_awprot ;
    assign w_port__AXI_Matrix_0__us0_awprot = w_net__AXI_Protocol_Converter_0__ds_axi_awprot ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_awvalid = w_port__AXI_Protocol_Converter_0__ds_axi_awvalid ;
    assign w_port__AXI_Matrix_0__us0_awvalid = w_net__AXI_Protocol_Converter_0__ds_axi_awvalid ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_bready = w_port__AXI_Protocol_Converter_0__ds_axi_bready ;
    assign w_port__AXI_Matrix_0__us0_bready = w_net__AXI_Protocol_Converter_0__ds_axi_bready ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_rready = w_port__AXI_Protocol_Converter_0__ds_axi_rready ;
    assign w_port__AXI_Matrix_0__us0_rready = w_net__AXI_Protocol_Converter_0__ds_axi_rready ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_wdata = w_port__AXI_Protocol_Converter_0__ds_axi_wdata ;
    assign w_port__AXI_Matrix_0__us0_wdata = w_net__AXI_Protocol_Converter_0__ds_axi_wdata ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_wstrb = w_port__AXI_Protocol_Converter_0__ds_axi_wstrb ;
    assign w_port__AXI_Matrix_0__us0_wstrb = w_net__AXI_Protocol_Converter_0__ds_axi_wstrb ;

    assign w_net__AXI_Protocol_Converter_0__ds_axi_wvalid = w_port__AXI_Protocol_Converter_0__ds_axi_wvalid ;
    assign w_port__AXI_Matrix_0__us0_wvalid = w_net__AXI_Protocol_Converter_0__ds_axi_wvalid ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_arready = w_port__AXI_Protocol_Converter_0__us_axi_arready ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_arready = w_net__AXI_Protocol_Converter_0__us_axi_arready ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_awready = w_port__AXI_Protocol_Converter_0__us_axi_awready ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_awready = w_net__AXI_Protocol_Converter_0__us_axi_awready ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_bid = w_port__AXI_Protocol_Converter_0__us_axi_bid ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_bid = w_net__AXI_Protocol_Converter_0__us_axi_bid ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_bresp = w_port__AXI_Protocol_Converter_0__us_axi_bresp ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_bresp = w_net__AXI_Protocol_Converter_0__us_axi_bresp ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_bvalid = w_port__AXI_Protocol_Converter_0__us_axi_bvalid ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_bvalid = w_net__AXI_Protocol_Converter_0__us_axi_bvalid ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_rdata = w_port__AXI_Protocol_Converter_0__us_axi_rdata ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_rdata = w_net__AXI_Protocol_Converter_0__us_axi_rdata ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_rid = w_port__AXI_Protocol_Converter_0__us_axi_rid ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_rid = w_net__AXI_Protocol_Converter_0__us_axi_rid ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_rlast = w_port__AXI_Protocol_Converter_0__us_axi_rlast ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_rlast = w_net__AXI_Protocol_Converter_0__us_axi_rlast ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_rresp = w_port__AXI_Protocol_Converter_0__us_axi_rresp ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_rresp = w_net__AXI_Protocol_Converter_0__us_axi_rresp ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_rvalid = w_port__AXI_Protocol_Converter_0__us_axi_rvalid ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_rvalid = w_net__AXI_Protocol_Converter_0__us_axi_rvalid ;

    assign w_net__AXI_Protocol_Converter_0__us_axi_wready = w_port__AXI_Protocol_Converter_0__us_axi_wready ;
    assign w_port__ARM_Processor_System_0__master_gp0_axi_wready = w_net__AXI_Protocol_Converter_0__us_axi_wready ;

    assign w_net__Concat_0__Dout = w_port__Concat_0__Dout ;
    assign w_port__ARM_Processor_System_0__f2p_irq = {12'b0,w_net__Concat_0__Dout} ;

    assign w_net__Constant_0__dout = w_port__Constant_0__dout ;
    assign w_port__Processor_System_Reset_0__pll_locked = w_net__Constant_0__dout ;
    assign w_port__Processor_System_Reset_0_200__pll_locked = w_net__Constant_0__dout ;

    assign w_net__Constant_3__dout = w_port__Constant_3__dout ;
    assign w_port__Processor_System_Reset_0__system_rst = w_net__Constant_3__dout ;
    assign w_port__Processor_System_Reset_0_200__system_rst = w_net__Constant_3__dout ;
    assign w_port__Processor_System_Reset_0_200__aux_rst = w_net__Constant_3__dout ;
    assign w_port__Processor_System_Reset_0__aux_rst = w_net__Constant_3__dout ;

    assign w_net__I_fdma_raddr = I_fdma_raddr ;
    assign w_port__uiFDMA_0__I_fdma_raddr = w_net__I_fdma_raddr ;

    assign w_net__I_fdma_rareq = I_fdma_rareq ;
    assign w_port__uiFDMA_0__I_fdma_rareq = w_net__I_fdma_rareq ;

    assign w_net__I_fdma_rready = I_fdma_rready ;
    assign w_port__uiFDMA_0__I_fdma_rready = w_net__I_fdma_rready ;

    assign w_net__I_fdma_rsize = I_fdma_rsize ;
    assign w_port__uiFDMA_0__I_fdma_rsize = w_net__I_fdma_rsize ;

    assign w_net__I_fdma_waddr = I_fdma_waddr ;
    assign w_port__uiFDMA_0__I_fdma_waddr = w_net__I_fdma_waddr ;

    assign w_net__I_fdma_wareq = I_fdma_wareq ;
    assign w_port__uiFDMA_0__I_fdma_wareq = w_net__I_fdma_wareq ;

    assign w_net__I_fdma_wdata = I_fdma_wdata ;
    assign w_port__uiFDMA_0__I_fdma_wdata = w_net__I_fdma_wdata ;

    assign w_net__I_fdma_wready = I_fdma_wready ;
    assign w_port__uiFDMA_0__I_fdma_wready = w_net__I_fdma_wready ;

    assign w_net__I_fdma_wsize = I_fdma_wsize ;
    assign w_port__uiFDMA_0__I_fdma_wsize = w_net__I_fdma_wsize ;

    assign w_net__I_irq2 = I_irq2 ;
    assign w_port__Concat_0__In2 = w_net__I_irq2 ;

    assign w_net__I_mwdata = I_mwdata ;
    assign w_port__AXI_ERAM_Controller_0__mem_dout = w_net__I_mwdata ;

    assign w_net__I_video_in_data = I_video_in_data ;
    assign w_port__uihdmi_tx_0__I_video_in_data = w_net__I_video_in_data ;

    assign w_net__I_video_in_de = I_video_in_de ;
    assign w_port__uihdmi_tx_0__I_video_in_de = w_net__I_video_in_de ;

    assign w_net__I_video_in_hs = I_video_in_hs ;
    assign w_port__uihdmi_tx_0__I_video_in_hs = w_net__I_video_in_hs ;

    assign w_net__I_video_in_vs = I_video_in_vs ;
    assign w_port__uihdmi_tx_0__I_video_in_vs = w_net__I_video_in_vs ;

    assign w_net__Processor_System_Reset_0_200__peripheral_aresetn = w_port__Processor_System_Reset_0_200__peripheral_aresetn ;
    assign O_ui_rstn = w_net__Processor_System_Reset_0_200__peripheral_aresetn ;
    assign w_port__uiFDMA_0__M_AXI_ARESETN = w_net__Processor_System_Reset_0_200__peripheral_aresetn ;
    assign w_port__Video_NPU_0__M_AXI_AResetn = w_net__Processor_System_Reset_0__peripheral_aresetn ;

    assign w_net__Processor_System_Reset_0__peripheral_aresetn = w_port__Processor_System_Reset_0__peripheral_aresetn ;
    assign w_port__AXI_ERAM_Controller_0__aresetn = w_net__Processor_System_Reset_0__peripheral_aresetn ;
    assign O_mrstn = w_net__Processor_System_Reset_0__peripheral_aresetn ;
    assign w_port__Video_NPU_0__S_AXILite_AResetn = w_net__Processor_System_Reset_0__peripheral_aresetn ;
    assign w_port__AXI_Protocol_Converter_0__aresetn = w_net__Processor_System_Reset_0__peripheral_aresetn ;
    assign w_port__AXI_Matrix_0__aresetn = w_net__Processor_System_Reset_0__peripheral_aresetn ;
    assign w_port__temporal_conv_0__rst_n = w_net__Processor_System_Reset_0__peripheral_aresetn ;

    assign w_net__Video_NPU_0__m_axi_araddr_soft_o = w_port__Video_NPU_0__m_axi_araddr_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_araddr = w_net__Video_NPU_0__m_axi_araddr_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arburst_soft_o = w_port__Video_NPU_0__m_axi_arburst_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arburst = w_net__Video_NPU_0__m_axi_arburst_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arcache_soft_o = w_port__Video_NPU_0__m_axi_arcache_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arcache = w_net__Video_NPU_0__m_axi_arcache_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arid_soft_o = w_port__Video_NPU_0__m_axi_arid_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arid = w_net__Video_NPU_0__m_axi_arid_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arlen_soft_o = w_port__Video_NPU_0__m_axi_arlen_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arlen = w_net__Video_NPU_0__m_axi_arlen_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arlock_soft_o = w_port__Video_NPU_0__m_axi_arlock_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arlock = w_net__Video_NPU_0__m_axi_arlock_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arprot_soft_o = w_port__Video_NPU_0__m_axi_arprot_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arprot = w_net__Video_NPU_0__m_axi_arprot_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arsize_soft_o = w_port__Video_NPU_0__m_axi_arsize_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arsize = w_net__Video_NPU_0__m_axi_arsize_soft_o ;

    assign w_net__Video_NPU_0__m_axi_arvalid_soft_o = w_port__Video_NPU_0__m_axi_arvalid_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_arvalid = w_net__Video_NPU_0__m_axi_arvalid_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awaddr_soft_o = w_port__Video_NPU_0__m_axi_awaddr_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awaddr = w_net__Video_NPU_0__m_axi_awaddr_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awburst_soft_o = w_port__Video_NPU_0__m_axi_awburst_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awburst = w_net__Video_NPU_0__m_axi_awburst_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awcache_soft_o = w_port__Video_NPU_0__m_axi_awcache_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awcache = w_net__Video_NPU_0__m_axi_awcache_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awid_soft_o = w_port__Video_NPU_0__m_axi_awid_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awid = w_net__Video_NPU_0__m_axi_awid_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awlen_soft_o = w_port__Video_NPU_0__m_axi_awlen_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awlen = w_net__Video_NPU_0__m_axi_awlen_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awlock_soft_o = w_port__Video_NPU_0__m_axi_awlock_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awlock = w_net__Video_NPU_0__m_axi_awlock_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awprot_soft_o = w_port__Video_NPU_0__m_axi_awprot_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awprot = w_net__Video_NPU_0__m_axi_awprot_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awsize_soft_o = w_port__Video_NPU_0__m_axi_awsize_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awsize = w_net__Video_NPU_0__m_axi_awsize_soft_o ;

    assign w_net__Video_NPU_0__m_axi_awvalid_soft_o = w_port__Video_NPU_0__m_axi_awvalid_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_awvalid = w_net__Video_NPU_0__m_axi_awvalid_soft_o ;

    assign w_net__Video_NPU_0__m_axi_bready_soft_o = w_port__Video_NPU_0__m_axi_bready_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_bready = w_net__Video_NPU_0__m_axi_bready_soft_o ;

    assign w_net__Video_NPU_0__m_axi_rready_soft_o = w_port__Video_NPU_0__m_axi_rready_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_rready = w_net__Video_NPU_0__m_axi_rready_soft_o ;

    assign w_net__Video_NPU_0__m_axi_wdata_soft_o = w_port__Video_NPU_0__m_axi_wdata_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_wdata = w_net__Video_NPU_0__m_axi_wdata_soft_o ;

    assign w_net__Video_NPU_0__m_axi_wlast_soft_o = w_port__Video_NPU_0__m_axi_wlast_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_wlast = w_net__Video_NPU_0__m_axi_wlast_soft_o ;

    assign w_net__Video_NPU_0__m_axi_wstrb_soft_o = w_port__Video_NPU_0__m_axi_wstrb_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_wstrb = w_net__Video_NPU_0__m_axi_wstrb_soft_o ;

    assign w_net__Video_NPU_0__m_axi_wvalid_soft_o = w_port__Video_NPU_0__m_axi_wvalid_soft_o ;
    assign w_port__ARM_Processor_System_0__slave_hp1_axi_wvalid = w_net__Video_NPU_0__m_axi_wvalid_soft_o ;

    assign w_net__Video_NPU_0__npu_soft_intr = w_port__Video_NPU_0__npu_soft_intr ;
    assign w_port__Concat_0__In3 = w_net__Video_NPU_0__npu_soft_intr ;

    assign w_net__Video_NPU_0__s_axilite_arready_o = w_port__Video_NPU_0__s_axilite_arready_o ;
    assign w_port__AXI_Matrix_0__ds1_arready = w_net__Video_NPU_0__s_axilite_arready_o ;

    assign w_net__Video_NPU_0__s_axilite_awready_o = w_port__Video_NPU_0__s_axilite_awready_o ;
    assign w_port__AXI_Matrix_0__ds1_awready = w_net__Video_NPU_0__s_axilite_awready_o ;

    assign w_net__Video_NPU_0__s_axilite_bresp_o = w_port__Video_NPU_0__s_axilite_bresp_o ;
    assign w_port__AXI_Matrix_0__ds1_bresp = w_net__Video_NPU_0__s_axilite_bresp_o ;

    assign w_net__Video_NPU_0__s_axilite_bvalid_o = w_port__Video_NPU_0__s_axilite_bvalid_o ;
    assign w_port__AXI_Matrix_0__ds1_bvalid = w_net__Video_NPU_0__s_axilite_bvalid_o ;

    assign w_net__Video_NPU_0__s_axilite_rdata_o = w_port__Video_NPU_0__s_axilite_rdata_o ;
    assign w_port__AXI_Matrix_0__ds1_rdata = w_net__Video_NPU_0__s_axilite_rdata_o ;

    assign w_net__Video_NPU_0__s_axilite_rresp_o = w_port__Video_NPU_0__s_axilite_rresp_o ;
    assign w_port__AXI_Matrix_0__ds1_rresp = w_net__Video_NPU_0__s_axilite_rresp_o ;

    assign w_net__Video_NPU_0__s_axilite_rvalid_o = w_port__Video_NPU_0__s_axilite_rvalid_o ;
    assign w_port__AXI_Matrix_0__ds1_rvalid = w_net__Video_NPU_0__s_axilite_rvalid_o ;

    assign w_net__Video_NPU_0__s_axilite_wready_o = w_port__Video_NPU_0__s_axilite_wready_o ;
    assign w_port__AXI_Matrix_0__ds1_wready = w_net__Video_NPU_0__s_axilite_wready_o ;

    assign w_net__uiFDMA_0__M_AXI_ARADDR = w_port__uiFDMA_0__M_AXI_ARADDR ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_araddr = {1'b0,w_net__uiFDMA_0__M_AXI_ARADDR} ;

    assign w_net__uiFDMA_0__M_AXI_ARBURST = w_port__uiFDMA_0__M_AXI_ARBURST ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arburst = w_net__uiFDMA_0__M_AXI_ARBURST ;

    assign w_net__uiFDMA_0__M_AXI_ARCACHE = w_port__uiFDMA_0__M_AXI_ARCACHE ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arcache = w_net__uiFDMA_0__M_AXI_ARCACHE ;

    assign w_net__uiFDMA_0__M_AXI_ARID = w_port__uiFDMA_0__M_AXI_ARID ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arid = w_net__uiFDMA_0__M_AXI_ARID ;

    assign w_net__uiFDMA_0__M_AXI_ARLEN = w_port__uiFDMA_0__M_AXI_ARLEN ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arlen = w_net__uiFDMA_0__M_AXI_ARLEN ;

    assign w_net__uiFDMA_0__M_AXI_ARLOCK = w_port__uiFDMA_0__M_AXI_ARLOCK ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arlock = w_net__uiFDMA_0__M_AXI_ARLOCK ;

    assign w_net__uiFDMA_0__M_AXI_ARPROT = w_port__uiFDMA_0__M_AXI_ARPROT ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arprot = w_net__uiFDMA_0__M_AXI_ARPROT ;

    assign w_net__uiFDMA_0__M_AXI_ARQOS = w_port__uiFDMA_0__M_AXI_ARQOS ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arqos = w_net__uiFDMA_0__M_AXI_ARQOS ;

    assign w_net__uiFDMA_0__M_AXI_ARSIZE = w_port__uiFDMA_0__M_AXI_ARSIZE ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arsize = w_net__uiFDMA_0__M_AXI_ARSIZE ;

    assign w_net__uiFDMA_0__M_AXI_ARVALID = w_port__uiFDMA_0__M_AXI_ARVALID ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_arvalid = w_net__uiFDMA_0__M_AXI_ARVALID ;

    assign w_net__uiFDMA_0__M_AXI_AWADDR = w_port__uiFDMA_0__M_AXI_AWADDR ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awaddr = {1'b0,w_net__uiFDMA_0__M_AXI_AWADDR} ;

    assign w_net__uiFDMA_0__M_AXI_AWBURST = w_port__uiFDMA_0__M_AXI_AWBURST ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awburst = w_net__uiFDMA_0__M_AXI_AWBURST ;

    assign w_net__uiFDMA_0__M_AXI_AWCACHE = w_port__uiFDMA_0__M_AXI_AWCACHE ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awcache = w_net__uiFDMA_0__M_AXI_AWCACHE ;

    assign w_net__uiFDMA_0__M_AXI_AWID = w_port__uiFDMA_0__M_AXI_AWID ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awid = w_net__uiFDMA_0__M_AXI_AWID ;

    assign w_net__uiFDMA_0__M_AXI_AWLEN = w_port__uiFDMA_0__M_AXI_AWLEN ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awlen = w_net__uiFDMA_0__M_AXI_AWLEN ;

    assign w_net__uiFDMA_0__M_AXI_AWLOCK = w_port__uiFDMA_0__M_AXI_AWLOCK ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awlock = w_net__uiFDMA_0__M_AXI_AWLOCK ;

    assign w_net__uiFDMA_0__M_AXI_AWPROT = w_port__uiFDMA_0__M_AXI_AWPROT ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awprot = w_net__uiFDMA_0__M_AXI_AWPROT ;

    assign w_net__uiFDMA_0__M_AXI_AWQOS = w_port__uiFDMA_0__M_AXI_AWQOS ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awqos = w_net__uiFDMA_0__M_AXI_AWQOS ;

    assign w_net__uiFDMA_0__M_AXI_AWSIZE = w_port__uiFDMA_0__M_AXI_AWSIZE ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awsize = w_net__uiFDMA_0__M_AXI_AWSIZE ;

    assign w_net__uiFDMA_0__M_AXI_AWVALID = w_port__uiFDMA_0__M_AXI_AWVALID ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_awvalid = w_net__uiFDMA_0__M_AXI_AWVALID ;

    assign w_net__uiFDMA_0__M_AXI_BREADY = w_port__uiFDMA_0__M_AXI_BREADY ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_bready = w_net__uiFDMA_0__M_AXI_BREADY ;

    assign w_net__uiFDMA_0__M_AXI_RREADY = w_port__uiFDMA_0__M_AXI_RREADY ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_rready = w_net__uiFDMA_0__M_AXI_RREADY ;

    assign w_net__uiFDMA_0__M_AXI_WDATA = w_port__uiFDMA_0__M_AXI_WDATA ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_wdata = w_net__uiFDMA_0__M_AXI_WDATA ;

    assign w_net__uiFDMA_0__M_AXI_WLAST = w_port__uiFDMA_0__M_AXI_WLAST ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_wlast = w_net__uiFDMA_0__M_AXI_WLAST ;

    assign w_net__uiFDMA_0__M_AXI_WSTRB = w_port__uiFDMA_0__M_AXI_WSTRB ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_wstrb = w_net__uiFDMA_0__M_AXI_WSTRB ;

    assign w_net__uiFDMA_0__M_AXI_WVALID = w_port__uiFDMA_0__M_AXI_WVALID ;
    assign w_port__ARM_Processor_System_0__slave_hp0_axi_wvalid = w_net__uiFDMA_0__M_AXI_WVALID ;

    assign w_net__uiFDMA_0__O_fdma_rbusy = w_port__uiFDMA_0__O_fdma_rbusy ;
    assign O_fdma_rbusy = w_net__uiFDMA_0__O_fdma_rbusy ;

    assign w_net__uiFDMA_0__O_fdma_rdata = w_port__uiFDMA_0__O_fdma_rdata ;
    assign O_fdma_rdata = w_net__uiFDMA_0__O_fdma_rdata ;

    assign w_net__uiFDMA_0__O_fdma_rvalid = w_port__uiFDMA_0__O_fdma_rvalid ;
    assign O_fdma_rvalid = w_net__uiFDMA_0__O_fdma_rvalid ;

    assign w_net__uiFDMA_0__O_fdma_wbusy = w_port__uiFDMA_0__O_fdma_wbusy ;
    assign O_fdma_wbusy = w_net__uiFDMA_0__O_fdma_wbusy ;

    assign w_net__uiFDMA_0__O_fdma_wvalid = w_port__uiFDMA_0__O_fdma_wvalid ;
    assign O_fdma_wvalid = w_net__uiFDMA_0__O_fdma_wvalid ;

    assign w_net__uihdmi_tx_0__O_hdmi_clk_p = w_port__uihdmi_tx_0__O_hdmi_clk_p ;
    assign O_hdmi_clk_p = w_net__uihdmi_tx_0__O_hdmi_clk_p ;

    assign w_net__uihdmi_tx_0__O_hdmi_tx_p = w_port__uihdmi_tx_0__O_hdmi_tx_p ;
    assign O_hdmi_tx_p = w_net__uihdmi_tx_0__O_hdmi_tx_p ;








    assign w_net__AXI_Matrix_0__ds0_araddr = w_port__AXI_Matrix_0__ds0_araddr ;
    assign w_port__temporal_conv_0__S_AXI_ARADDR = w_net__AXI_Matrix_0__ds0_araddr ;

    assign w_net__AXI_Matrix_0__ds0_arprot = w_port__AXI_Matrix_0__ds0_arprot ;
    assign w_port__temporal_conv_0__S_AXI_ARPROT = w_net__AXI_Matrix_0__ds0_arprot ;

    assign w_net__temporal_conv_0__S_AXI_ARREADY = w_port__temporal_conv_0__S_AXI_ARREADY ;
    assign w_port__AXI_Matrix_0__ds0_arready = w_net__temporal_conv_0__S_AXI_ARREADY ;

    assign w_net__AXI_Matrix_0__ds0_arvalid = w_port__AXI_Matrix_0__ds0_arvalid ;
    assign w_port__temporal_conv_0__S_AXI_ARVALID = w_net__AXI_Matrix_0__ds0_arvalid ;

    assign w_net__AXI_Matrix_0__ds0_awaddr = w_port__AXI_Matrix_0__ds0_awaddr ;
    assign w_port__temporal_conv_0__S_AXI_AWADDR = w_net__AXI_Matrix_0__ds0_awaddr ;

    assign w_net__AXI_Matrix_0__ds0_awprot = w_port__AXI_Matrix_0__ds0_awprot ;
    assign w_port__temporal_conv_0__S_AXI_AWPROT = w_net__AXI_Matrix_0__ds0_awprot ;

    assign w_net__temporal_conv_0__S_AXI_AWREADY = w_port__temporal_conv_0__S_AXI_AWREADY ;
    assign w_port__AXI_Matrix_0__ds0_awready = w_net__temporal_conv_0__S_AXI_AWREADY ;

    assign w_net__AXI_Matrix_0__ds0_awvalid = w_port__AXI_Matrix_0__ds0_awvalid ;
    assign w_port__temporal_conv_0__S_AXI_AWVALID = w_net__AXI_Matrix_0__ds0_awvalid ;

    assign w_net__AXI_Matrix_0__ds0_bready = w_port__AXI_Matrix_0__ds0_bready ;
    assign w_port__temporal_conv_0__S_AXI_BREADY = w_net__AXI_Matrix_0__ds0_bready ;

    assign w_net__temporal_conv_0__S_AXI_BRESP = w_port__temporal_conv_0__S_AXI_BRESP ;
    assign w_port__AXI_Matrix_0__ds0_bresp = w_net__temporal_conv_0__S_AXI_BRESP ;

    assign w_net__temporal_conv_0__S_AXI_BVALID = w_port__temporal_conv_0__S_AXI_BVALID ;
    assign w_port__AXI_Matrix_0__ds0_bvalid = w_net__temporal_conv_0__S_AXI_BVALID ;

    assign w_net__temporal_conv_0__S_AXI_RDATA = w_port__temporal_conv_0__S_AXI_RDATA ;
    assign w_port__AXI_Matrix_0__ds0_rdata = w_net__temporal_conv_0__S_AXI_RDATA ;

    assign w_net__AXI_Matrix_0__ds0_rready = w_port__AXI_Matrix_0__ds0_rready ;
    assign w_port__temporal_conv_0__S_AXI_RREADY = w_net__AXI_Matrix_0__ds0_rready ;

    assign w_net__temporal_conv_0__S_AXI_RRESP = w_port__temporal_conv_0__S_AXI_RRESP ;
    assign w_port__AXI_Matrix_0__ds0_rresp = w_net__temporal_conv_0__S_AXI_RRESP ;

    assign w_net__temporal_conv_0__S_AXI_RVALID = w_port__temporal_conv_0__S_AXI_RVALID ;
    assign w_port__AXI_Matrix_0__ds0_rvalid = w_net__temporal_conv_0__S_AXI_RVALID ;

    assign w_net__AXI_Matrix_0__ds0_wdata = w_port__AXI_Matrix_0__ds0_wdata ;
    assign w_port__temporal_conv_0__S_AXI_WDATA = w_net__AXI_Matrix_0__ds0_wdata ;

    assign w_net__temporal_conv_0__S_AXI_WREADY = w_port__temporal_conv_0__S_AXI_WREADY ;
    assign w_port__AXI_Matrix_0__ds0_wready = w_net__temporal_conv_0__S_AXI_WREADY ;

    assign w_net__AXI_Matrix_0__ds0_wstrb = w_port__AXI_Matrix_0__ds0_wstrb ;
    assign w_port__temporal_conv_0__S_AXI_WSTRB = w_net__AXI_Matrix_0__ds0_wstrb ;

    assign w_net__AXI_Matrix_0__ds0_wvalid = w_port__AXI_Matrix_0__ds0_wvalid ;
    assign w_port__temporal_conv_0__S_AXI_WVALID = w_net__AXI_Matrix_0__ds0_wvalid ;

    system_ARM_Processor_System_0 ARM_Processor_System_0 ( 
                                                            .slave_hp0_axi_araddr(w_port__ARM_Processor_System_0__slave_hp0_axi_araddr)
                                                          , .slave_hp0_axi_arburst(w_port__ARM_Processor_System_0__slave_hp0_axi_arburst)
                                                          , .slave_hp0_axi_arcache(w_port__ARM_Processor_System_0__slave_hp0_axi_arcache)
                                                          , .slave_hp0_axi_arid(w_port__ARM_Processor_System_0__slave_hp0_axi_arid)
                                                          , .slave_hp0_axi_arlen(w_port__ARM_Processor_System_0__slave_hp0_axi_arlen)
                                                          , .slave_hp0_axi_arlock(w_port__ARM_Processor_System_0__slave_hp0_axi_arlock)
                                                          , .slave_hp0_axi_arprot(w_port__ARM_Processor_System_0__slave_hp0_axi_arprot)
                                                          , .slave_hp0_axi_arqos(w_port__ARM_Processor_System_0__slave_hp0_axi_arqos)
                                                          , .slave_hp0_axi_arready(w_port__ARM_Processor_System_0__slave_hp0_axi_arready)
                                                          , .slave_hp0_axi_arsize(w_port__ARM_Processor_System_0__slave_hp0_axi_arsize)
                                                          , .slave_hp0_axi_arvalid(w_port__ARM_Processor_System_0__slave_hp0_axi_arvalid)
                                                          , .slave_hp0_axi_awaddr(w_port__ARM_Processor_System_0__slave_hp0_axi_awaddr)
                                                          , .slave_hp0_axi_awburst(w_port__ARM_Processor_System_0__slave_hp0_axi_awburst)
                                                          , .slave_hp0_axi_awcache(w_port__ARM_Processor_System_0__slave_hp0_axi_awcache)
                                                          , .slave_hp0_axi_awid(w_port__ARM_Processor_System_0__slave_hp0_axi_awid)
                                                          , .slave_hp0_axi_awlen(w_port__ARM_Processor_System_0__slave_hp0_axi_awlen)
                                                          , .slave_hp0_axi_awlock(w_port__ARM_Processor_System_0__slave_hp0_axi_awlock)
                                                          , .slave_hp0_axi_awprot(w_port__ARM_Processor_System_0__slave_hp0_axi_awprot)
                                                          , .slave_hp0_axi_awqos(w_port__ARM_Processor_System_0__slave_hp0_axi_awqos)
                                                          , .slave_hp0_axi_awready(w_port__ARM_Processor_System_0__slave_hp0_axi_awready)
                                                          , .slave_hp0_axi_awsize(w_port__ARM_Processor_System_0__slave_hp0_axi_awsize)
                                                          , .slave_hp0_axi_awvalid(w_port__ARM_Processor_System_0__slave_hp0_axi_awvalid)
                                                          , .slave_hp0_axi_bid(w_port__ARM_Processor_System_0__slave_hp0_axi_bid)
                                                          , .slave_hp0_axi_bready(w_port__ARM_Processor_System_0__slave_hp0_axi_bready)
                                                          , .slave_hp0_axi_bresp(w_port__ARM_Processor_System_0__slave_hp0_axi_bresp)
                                                          , .slave_hp0_axi_bvalid(w_port__ARM_Processor_System_0__slave_hp0_axi_bvalid)
                                                          , .slave_hp0_axi_rdata(w_port__ARM_Processor_System_0__slave_hp0_axi_rdata)
                                                          , .slave_hp0_axi_rid(w_port__ARM_Processor_System_0__slave_hp0_axi_rid)
                                                          , .slave_hp0_axi_rlast(w_port__ARM_Processor_System_0__slave_hp0_axi_rlast)
                                                          , .slave_hp0_axi_rready(w_port__ARM_Processor_System_0__slave_hp0_axi_rready)
                                                          , .slave_hp0_axi_rresp(w_port__ARM_Processor_System_0__slave_hp0_axi_rresp)
                                                          , .slave_hp0_axi_rvalid(w_port__ARM_Processor_System_0__slave_hp0_axi_rvalid)
                                                          , .slave_hp0_axi_wdata(w_port__ARM_Processor_System_0__slave_hp0_axi_wdata)
                                                          , .slave_hp0_axi_wlast(w_port__ARM_Processor_System_0__slave_hp0_axi_wlast)
                                                          , .slave_hp0_axi_wready(w_port__ARM_Processor_System_0__slave_hp0_axi_wready)
                                                          , .slave_hp0_axi_wstrb(w_port__ARM_Processor_System_0__slave_hp0_axi_wstrb)
                                                          , .slave_hp0_axi_wvalid(w_port__ARM_Processor_System_0__slave_hp0_axi_wvalid)
                                                          , .slave_hp1_axi_araddr(w_port__ARM_Processor_System_0__slave_hp1_axi_araddr)
                                                          , .slave_hp1_axi_arburst(w_port__ARM_Processor_System_0__slave_hp1_axi_arburst)
                                                          , .slave_hp1_axi_arcache(w_port__ARM_Processor_System_0__slave_hp1_axi_arcache)
                                                          , .slave_hp1_axi_arid(w_port__ARM_Processor_System_0__slave_hp1_axi_arid)
                                                          , .slave_hp1_axi_arlen(w_port__ARM_Processor_System_0__slave_hp1_axi_arlen)
                                                          , .slave_hp1_axi_arlock(w_port__ARM_Processor_System_0__slave_hp1_axi_arlock)
                                                          , .slave_hp1_axi_arprot(w_port__ARM_Processor_System_0__slave_hp1_axi_arprot)
                                                          , .slave_hp1_axi_arqos(4'b0)
                                                          , .slave_hp1_axi_arready(w_port__ARM_Processor_System_0__slave_hp1_axi_arready)
                                                          , .slave_hp1_axi_arsize(w_port__ARM_Processor_System_0__slave_hp1_axi_arsize)
                                                          , .slave_hp1_axi_arvalid(w_port__ARM_Processor_System_0__slave_hp1_axi_arvalid)
                                                          , .slave_hp1_axi_awaddr(w_port__ARM_Processor_System_0__slave_hp1_axi_awaddr)
                                                          , .slave_hp1_axi_awburst(w_port__ARM_Processor_System_0__slave_hp1_axi_awburst)
                                                          , .slave_hp1_axi_awcache(w_port__ARM_Processor_System_0__slave_hp1_axi_awcache)
                                                          , .slave_hp1_axi_awid(w_port__ARM_Processor_System_0__slave_hp1_axi_awid)
                                                          , .slave_hp1_axi_awlen(w_port__ARM_Processor_System_0__slave_hp1_axi_awlen)
                                                          , .slave_hp1_axi_awlock(w_port__ARM_Processor_System_0__slave_hp1_axi_awlock)
                                                          , .slave_hp1_axi_awprot(w_port__ARM_Processor_System_0__slave_hp1_axi_awprot)
                                                          , .slave_hp1_axi_awqos(4'b0)
                                                          , .slave_hp1_axi_awready(w_port__ARM_Processor_System_0__slave_hp1_axi_awready)
                                                          , .slave_hp1_axi_awsize(w_port__ARM_Processor_System_0__slave_hp1_axi_awsize)
                                                          , .slave_hp1_axi_awvalid(w_port__ARM_Processor_System_0__slave_hp1_axi_awvalid)
                                                          , .slave_hp1_axi_bid(w_port__ARM_Processor_System_0__slave_hp1_axi_bid)
                                                          , .slave_hp1_axi_bready(w_port__ARM_Processor_System_0__slave_hp1_axi_bready)
                                                          , .slave_hp1_axi_bresp(w_port__ARM_Processor_System_0__slave_hp1_axi_bresp)
                                                          , .slave_hp1_axi_bvalid(w_port__ARM_Processor_System_0__slave_hp1_axi_bvalid)
                                                          , .slave_hp1_axi_rdata(w_port__ARM_Processor_System_0__slave_hp1_axi_rdata)
                                                          , .slave_hp1_axi_rid(w_port__ARM_Processor_System_0__slave_hp1_axi_rid)
                                                          , .slave_hp1_axi_rlast(w_port__ARM_Processor_System_0__slave_hp1_axi_rlast)
                                                          , .slave_hp1_axi_rready(w_port__ARM_Processor_System_0__slave_hp1_axi_rready)
                                                          , .slave_hp1_axi_rresp(w_port__ARM_Processor_System_0__slave_hp1_axi_rresp)
                                                          , .slave_hp1_axi_rvalid(w_port__ARM_Processor_System_0__slave_hp1_axi_rvalid)
                                                          , .slave_hp1_axi_wdata(w_port__ARM_Processor_System_0__slave_hp1_axi_wdata)
                                                          , .slave_hp1_axi_wlast(w_port__ARM_Processor_System_0__slave_hp1_axi_wlast)
                                                          , .slave_hp1_axi_wready(w_port__ARM_Processor_System_0__slave_hp1_axi_wready)
                                                          , .slave_hp1_axi_wstrb(w_port__ARM_Processor_System_0__slave_hp1_axi_wstrb)
                                                          , .slave_hp1_axi_wvalid(w_port__ARM_Processor_System_0__slave_hp1_axi_wvalid)
                                                          , .slave_hp0_axi_aclk(w_port__ARM_Processor_System_0__slave_hp0_axi_aclk)
                                                          , .slave_hp1_axi_aclk(w_port__ARM_Processor_System_0__slave_hp1_axi_aclk)
                                                          , .master_gp0_axi_aclk(w_port__ARM_Processor_System_0__master_gp0_axi_aclk)
                                                          , .master_gp1_axi_aclk(w_port__ARM_Processor_System_0__master_gp1_axi_aclk)
                                                          , .f2p_irq(w_port__ARM_Processor_System_0__f2p_irq)
                                                          , .master_gp0_axi_araddr(w_port__ARM_Processor_System_0__master_gp0_axi_araddr)
                                                          , .master_gp0_axi_arburst(w_port__ARM_Processor_System_0__master_gp0_axi_arburst)
                                                          , .master_gp0_axi_arcache(w_port__ARM_Processor_System_0__master_gp0_axi_arcache)
                                                          , .master_gp0_axi_arid(w_port__ARM_Processor_System_0__master_gp0_axi_arid)
                                                          , .master_gp0_axi_arlen(w_port__ARM_Processor_System_0__master_gp0_axi_arlen)
                                                          , .master_gp0_axi_arlock(w_port__ARM_Processor_System_0__master_gp0_axi_arlock)
                                                          , .master_gp0_axi_arprot(w_port__ARM_Processor_System_0__master_gp0_axi_arprot)
                                                          , .master_gp0_axi_arready(w_port__ARM_Processor_System_0__master_gp0_axi_arready)
                                                          , .master_gp0_axi_arsize(w_port__ARM_Processor_System_0__master_gp0_axi_arsize)
                                                          , .master_gp0_axi_arvalid(w_port__ARM_Processor_System_0__master_gp0_axi_arvalid)
                                                          , .master_gp0_axi_awaddr(w_port__ARM_Processor_System_0__master_gp0_axi_awaddr)
                                                          , .master_gp0_axi_awburst(w_port__ARM_Processor_System_0__master_gp0_axi_awburst)
                                                          , .master_gp0_axi_awcache(w_port__ARM_Processor_System_0__master_gp0_axi_awcache)
                                                          , .master_gp0_axi_awid(w_port__ARM_Processor_System_0__master_gp0_axi_awid)
                                                          , .master_gp0_axi_awlen(w_port__ARM_Processor_System_0__master_gp0_axi_awlen)
                                                          , .master_gp0_axi_awlock(w_port__ARM_Processor_System_0__master_gp0_axi_awlock)
                                                          , .master_gp0_axi_awprot(w_port__ARM_Processor_System_0__master_gp0_axi_awprot)
                                                          , .master_gp0_axi_awready(w_port__ARM_Processor_System_0__master_gp0_axi_awready)
                                                          , .master_gp0_axi_awsize(w_port__ARM_Processor_System_0__master_gp0_axi_awsize)
                                                          , .master_gp0_axi_awvalid(w_port__ARM_Processor_System_0__master_gp0_axi_awvalid)
                                                          , .master_gp0_axi_bid(w_port__ARM_Processor_System_0__master_gp0_axi_bid)
                                                          , .master_gp0_axi_bready(w_port__ARM_Processor_System_0__master_gp0_axi_bready)
                                                          , .master_gp0_axi_bresp(w_port__ARM_Processor_System_0__master_gp0_axi_bresp)
                                                          , .master_gp0_axi_bvalid(w_port__ARM_Processor_System_0__master_gp0_axi_bvalid)
                                                          , .master_gp0_axi_rdata(w_port__ARM_Processor_System_0__master_gp0_axi_rdata)
                                                          , .master_gp0_axi_rid(w_port__ARM_Processor_System_0__master_gp0_axi_rid)
                                                          , .master_gp0_axi_rlast(w_port__ARM_Processor_System_0__master_gp0_axi_rlast)
                                                          , .master_gp0_axi_rready(w_port__ARM_Processor_System_0__master_gp0_axi_rready)
                                                          , .master_gp0_axi_rresp(w_port__ARM_Processor_System_0__master_gp0_axi_rresp)
                                                          , .master_gp0_axi_rvalid(w_port__ARM_Processor_System_0__master_gp0_axi_rvalid)
                                                          , .master_gp0_axi_wdata(w_port__ARM_Processor_System_0__master_gp0_axi_wdata)
                                                          , .master_gp0_axi_wlast(w_port__ARM_Processor_System_0__master_gp0_axi_wlast)
                                                          , .master_gp0_axi_wready(w_port__ARM_Processor_System_0__master_gp0_axi_wready)
                                                          , .master_gp0_axi_wstrb(w_port__ARM_Processor_System_0__master_gp0_axi_wstrb)
                                                          , .master_gp0_axi_wvalid(w_port__ARM_Processor_System_0__master_gp0_axi_wvalid)
                                                          , .master_gp1_axi_araddr(w_port__ARM_Processor_System_0__master_gp1_axi_araddr)
                                                          , .master_gp1_axi_arburst(w_port__ARM_Processor_System_0__master_gp1_axi_arburst)
                                                          , .master_gp1_axi_arcache()
                                                          , .master_gp1_axi_arid(w_port__ARM_Processor_System_0__master_gp1_axi_arid)
                                                          , .master_gp1_axi_arlen(w_port__ARM_Processor_System_0__master_gp1_axi_arlen)
                                                          , .master_gp1_axi_arlock(w_port__ARM_Processor_System_0__master_gp1_axi_arlock)
                                                          , .master_gp1_axi_arprot()
                                                          , .master_gp1_axi_arready(w_port__ARM_Processor_System_0__master_gp1_axi_arready)
                                                          , .master_gp1_axi_arsize(w_port__ARM_Processor_System_0__master_gp1_axi_arsize)
                                                          , .master_gp1_axi_arvalid(w_port__ARM_Processor_System_0__master_gp1_axi_arvalid)
                                                          , .master_gp1_axi_awaddr(w_port__ARM_Processor_System_0__master_gp1_axi_awaddr)
                                                          , .master_gp1_axi_awburst(w_port__ARM_Processor_System_0__master_gp1_axi_awburst)
                                                          , .master_gp1_axi_awcache()
                                                          , .master_gp1_axi_awid(w_port__ARM_Processor_System_0__master_gp1_axi_awid)
                                                          , .master_gp1_axi_awlen(w_port__ARM_Processor_System_0__master_gp1_axi_awlen)
                                                          , .master_gp1_axi_awlock(w_port__ARM_Processor_System_0__master_gp1_axi_awlock)
                                                          , .master_gp1_axi_awprot()
                                                          , .master_gp1_axi_awready(w_port__ARM_Processor_System_0__master_gp1_axi_awready)
                                                          , .master_gp1_axi_awsize(w_port__ARM_Processor_System_0__master_gp1_axi_awsize)
                                                          , .master_gp1_axi_awvalid(w_port__ARM_Processor_System_0__master_gp1_axi_awvalid)
                                                          , .master_gp1_axi_bid(w_port__ARM_Processor_System_0__master_gp1_axi_bid)
                                                          , .master_gp1_axi_bready(w_port__ARM_Processor_System_0__master_gp1_axi_bready)
                                                          , .master_gp1_axi_bresp(w_port__ARM_Processor_System_0__master_gp1_axi_bresp)
                                                          , .master_gp1_axi_bvalid(w_port__ARM_Processor_System_0__master_gp1_axi_bvalid)
                                                          , .master_gp1_axi_rdata(w_port__ARM_Processor_System_0__master_gp1_axi_rdata)
                                                          , .master_gp1_axi_rid(w_port__ARM_Processor_System_0__master_gp1_axi_rid)
                                                          , .master_gp1_axi_rlast(w_port__ARM_Processor_System_0__master_gp1_axi_rlast)
                                                          , .master_gp1_axi_rready(w_port__ARM_Processor_System_0__master_gp1_axi_rready)
                                                          , .master_gp1_axi_rresp(w_port__ARM_Processor_System_0__master_gp1_axi_rresp)
                                                          , .master_gp1_axi_rvalid(w_port__ARM_Processor_System_0__master_gp1_axi_rvalid)
                                                          , .master_gp1_axi_wdata(w_port__ARM_Processor_System_0__master_gp1_axi_wdata)
                                                          , .master_gp1_axi_wlast()
                                                          , .master_gp1_axi_wready(w_port__ARM_Processor_System_0__master_gp1_axi_wready)
                                                          , .master_gp1_axi_wstrb(w_port__ARM_Processor_System_0__master_gp1_axi_wstrb)
                                                          , .master_gp1_axi_wvalid(w_port__ARM_Processor_System_0__master_gp1_axi_wvalid)
                                                          , .pl_gpio_in(1'b0)
                                                          , .pl_gpio_oe()
                                                          , .pl_gpio_out(w_port__ARM_Processor_System_0__pl_gpio_out)
                                                          , .p2f_rst0_n(w_port__ARM_Processor_System_0__p2f_rst0_n)
                                                          , .p2f_clk2(w_port__ARM_Processor_System_0__p2f_clk2)
                                                          , .p2f_clk1(w_port__ARM_Processor_System_0__p2f_clk1)
                                                          , .p2f_clk0(w_port__ARM_Processor_System_0__p2f_clk0) );

    system_Processor_System_Reset_0 Processor_System_Reset_0 ( 
                                                                .clk(w_port__Processor_System_Reset_0__clk)
                                                              , .external_reset(w_port__Processor_System_Reset_0__external_reset)
                                                              , .aux_rst(w_port__Processor_System_Reset_0__aux_rst)
                                                              , .system_rst(w_port__Processor_System_Reset_0__system_rst)
                                                              , .pll_locked(w_port__Processor_System_Reset_0__pll_locked)
                                                              , .soc_reset()
                                                              , .bus_reset()
                                                              , .peripheral_reset()
                                                              , .interconnect_aresetn()
                                                              , .peripheral_aresetn(w_port__Processor_System_Reset_0__peripheral_aresetn) );

    system_Constant_0 Constant_0 ( 
                                    .dout(w_port__Constant_0__dout) );

    system_Processor_System_Reset_0_0 Processor_System_Reset_0_200 ( 
                                                                      .clk(w_port__Processor_System_Reset_0_200__clk)
                                                                    , .external_reset(w_port__Processor_System_Reset_0_200__external_reset)
                                                                    , .aux_rst(w_port__Processor_System_Reset_0_200__aux_rst)
                                                                    , .system_rst(w_port__Processor_System_Reset_0_200__system_rst)
                                                                    , .pll_locked(w_port__Processor_System_Reset_0_200__pll_locked)
                                                                    , .soc_reset()
                                                                    , .bus_reset()
                                                                    , .peripheral_reset()
                                                                    , .interconnect_aresetn()
                                                                    , .peripheral_aresetn(w_port__Processor_System_Reset_0_200__peripheral_aresetn) );

    system_AXI_ERAM_Controller_0 AXI_ERAM_Controller_0 ( 
                                                          .awid(w_port__AXI_ERAM_Controller_0__awid)
                                                        , .awaddr(w_port__AXI_ERAM_Controller_0__awaddr)
                                                        , .awlen(w_port__AXI_ERAM_Controller_0__awlen)
                                                        , .awsize(w_port__AXI_ERAM_Controller_0__awsize)
                                                        , .awburst(w_port__AXI_ERAM_Controller_0__awburst)
                                                        , .awlock(w_port__AXI_ERAM_Controller_0__awlock)
                                                        , .awvalid(w_port__AXI_ERAM_Controller_0__awvalid)
                                                        , .awready(w_port__AXI_ERAM_Controller_0__awready)
                                                        , .wdata(w_port__AXI_ERAM_Controller_0__wdata)
                                                        , .wstrb(w_port__AXI_ERAM_Controller_0__wstrb)
                                                        , .wvalid(w_port__AXI_ERAM_Controller_0__wvalid)
                                                        , .wready(w_port__AXI_ERAM_Controller_0__wready)
                                                        , .bid(w_port__AXI_ERAM_Controller_0__bid)
                                                        , .bresp(w_port__AXI_ERAM_Controller_0__bresp)
                                                        , .bvalid(w_port__AXI_ERAM_Controller_0__bvalid)
                                                        , .bready(w_port__AXI_ERAM_Controller_0__bready)
                                                        , .arid(w_port__AXI_ERAM_Controller_0__arid)
                                                        , .araddr(w_port__AXI_ERAM_Controller_0__araddr)
                                                        , .arlen(w_port__AXI_ERAM_Controller_0__arlen)
                                                        , .arsize(w_port__AXI_ERAM_Controller_0__arsize)
                                                        , .arburst(w_port__AXI_ERAM_Controller_0__arburst)
                                                        , .arlock(w_port__AXI_ERAM_Controller_0__arlock)
                                                        , .arvalid(w_port__AXI_ERAM_Controller_0__arvalid)
                                                        , .arready(w_port__AXI_ERAM_Controller_0__arready)
                                                        , .rid(w_port__AXI_ERAM_Controller_0__rid)
                                                        , .rdata(w_port__AXI_ERAM_Controller_0__rdata)
                                                        , .rresp(w_port__AXI_ERAM_Controller_0__rresp)
                                                        , .rlast(w_port__AXI_ERAM_Controller_0__rlast)
                                                        , .rvalid(w_port__AXI_ERAM_Controller_0__rvalid)
                                                        , .rready(w_port__AXI_ERAM_Controller_0__rready)
                                                        , .mem_dout(w_port__AXI_ERAM_Controller_0__mem_dout)
                                                        , .aclk(w_port__AXI_ERAM_Controller_0__aclk)
                                                        , .aresetn(w_port__AXI_ERAM_Controller_0__aresetn)
                                                        , .mem_addr(w_port__AXI_ERAM_Controller_0__mem_addr)
                                                        , .mem_web(w_port__AXI_ERAM_Controller_0__mem_web)
                                                        , .mem_csb(w_port__AXI_ERAM_Controller_0__mem_csb)
                                                        , .mem_din(w_port__AXI_ERAM_Controller_0__mem_din) );

    system_Concat_0 Concat_0 ( 
                                .In0(1'b0)
                              , .In1(1'b0)
                              , .In2(w_port__Concat_0__In2)
                              , .In3(w_port__Concat_0__In3)
                              , .Dout(w_port__Concat_0__Dout) );

wire dw16_resetn=w_port__uiFDMA_0__M_AXI_ARESETN && w_port__temporal_conv_0__rst_n;
wire [1:0] c_dw_mode;
wire c_start,c_busy,c_done,c_fault;
wire [31:0] c_input,c_expand,c_depthwise,c_project,c_scratch_expand,c_scratch_depthwise,c_output;
wire [1:0] net_owner; wire v_start,v_busy,v_done,v_fault;
wire f_start,f_busy,f_done,f_fault; wire [31:0] f_input,f_parameter,f_output;
wire [31:0] v_input,v_parameter,v_output,v_core_cycles,v_base_products,v_interval_products,v_residual_products,v_skipped_products,v_residual_reads;
wire [63:0] v_budget;
wire dw16_start,dw16_busy,dw16_done,dw16_fault;
wire [31:0] dw16_input,dw16_parameter,dw16_output;
net_pl_datapath #(.FRONT96(1),.BLOCK34(1),.V4R_OUTPUT_GROUP(16)) dw16_dma (
.clk(w_port__uiFDMA_0__M_AXI_ACLK),
.resetn(dw16_resetn),
.start(dw16_start),
.input_base(dw16_input),
.parameter_base(dw16_parameter),
.output_base(dw16_output),
.busy(dw16_busy),
.done(dw16_done),
.fault(dw16_fault),.owner(net_owner),
       .v_start(v_start),.v_input(v_input),.v_parameter(v_parameter),.v_output(v_output),.v_budget(v_budget),
       .v_busy(v_busy),.v_done(v_done),.v_fault(v_fault),.v_core_cycles(v_core_cycles),
       .v_base_products(v_base_products),.v_interval_products(v_interval_products),
       .v_residual_products(v_residual_products),.v_skipped_products(v_skipped_products),.v_residual_reads(v_residual_reads),.f_start(f_start),.f_input(f_input),.f_parameter(f_parameter),.f_output(f_output),.f_busy(f_busy),.f_done(f_done),.f_fault(f_fault),.c_dw_mode(c_dw_mode),.c_start(c_start),.c_busy(c_busy),.c_done(c_done),.c_fault(c_fault),.c_input(c_input),.c_expand(c_expand),.c_depthwise(c_depthwise),.c_project(c_project),.c_scratch_expand(c_scratch_expand),.c_scratch_depthwise(c_scratch_depthwise),.c_output(c_output),
.araddr(w_port__uiFDMA_0__M_AXI_ARADDR),
.arlen(w_port__uiFDMA_0__M_AXI_ARLEN),
.arsize(w_port__uiFDMA_0__M_AXI_ARSIZE),
.arburst(w_port__uiFDMA_0__M_AXI_ARBURST),
.arvalid(w_port__uiFDMA_0__M_AXI_ARVALID),
.arready(w_port__uiFDMA_0__M_AXI_ARREADY),
.rdata(w_port__uiFDMA_0__M_AXI_RDATA),
.rresp(w_port__uiFDMA_0__M_AXI_RRESP),
.rlast(w_port__uiFDMA_0__M_AXI_RLAST),
.rvalid(w_port__uiFDMA_0__M_AXI_RVALID),
.rready(w_port__uiFDMA_0__M_AXI_RREADY),
.awaddr(w_port__uiFDMA_0__M_AXI_AWADDR),
.awlen(w_port__uiFDMA_0__M_AXI_AWLEN),
.awsize(w_port__uiFDMA_0__M_AXI_AWSIZE),
.awburst(w_port__uiFDMA_0__M_AXI_AWBURST),
.awvalid(w_port__uiFDMA_0__M_AXI_AWVALID),
.awready(w_port__uiFDMA_0__M_AXI_AWREADY),
.wdata(w_port__uiFDMA_0__M_AXI_WDATA),
.wstrb(w_port__uiFDMA_0__M_AXI_WSTRB),
.wlast(w_port__uiFDMA_0__M_AXI_WLAST),
.wvalid(w_port__uiFDMA_0__M_AXI_WVALID),
.wready(w_port__uiFDMA_0__M_AXI_WREADY),
.bresp(w_port__uiFDMA_0__M_AXI_BRESP),
.bvalid(w_port__uiFDMA_0__M_AXI_BVALID),
.bready(w_port__uiFDMA_0__M_AXI_BREADY)
);
assign w_port__uiFDMA_0__M_AXI_AWID=6'd0;
assign w_port__uiFDMA_0__M_AXI_AWLOCK=1'b0;
assign w_port__uiFDMA_0__M_AXI_AWCACHE=4'b0010;
assign w_port__uiFDMA_0__M_AXI_AWPROT=3'b000;
assign w_port__uiFDMA_0__M_AXI_AWQOS=4'b0000;
assign w_port__uiFDMA_0__M_AXI_ARID=6'd0;
assign w_port__uiFDMA_0__M_AXI_ARLOCK=1'b0;
assign w_port__uiFDMA_0__M_AXI_ARCACHE=4'b0010;
assign w_port__uiFDMA_0__M_AXI_ARPROT=3'b000;
assign w_port__uiFDMA_0__M_AXI_ARQOS=4'b0000;
assign w_port__uiFDMA_0__O_fdma_wbusy=1'b0;
assign w_port__uiFDMA_0__O_fdma_wvalid=1'b0;
assign w_port__uiFDMA_0__O_fdma_rbusy=1'b0;
assign w_port__uiFDMA_0__O_fdma_rdata=64'b0;
assign w_port__uiFDMA_0__O_fdma_rvalid=1'b0;


    system_Constant_3 Constant_3 ( 
                                    .dout(w_port__Constant_3__dout) );

    system_uihdmi_tx_0 uihdmi_tx_0 ( 
                                      .I_video_in_data(w_port__uihdmi_tx_0__I_video_in_data)
                                    , .I_video_in_de(w_port__uihdmi_tx_0__I_video_in_de)
                                    , .I_video_in_vs(w_port__uihdmi_tx_0__I_video_in_vs)
                                    , .I_video_in_hs(w_port__uihdmi_tx_0__I_video_in_hs)
                                    , .O_hdmi_clk_p(w_port__uihdmi_tx_0__O_hdmi_clk_p)
                                    , .O_hdmi_tx_p(w_port__uihdmi_tx_0__O_hdmi_tx_p) );

    system_Video_NPU_0 Video_NPU_0 ( 
                                      .s_axilite_awaddr_i(w_port__Video_NPU_0__s_axilite_awaddr_i)
                                    , .s_axilite_awprot_i(w_port__Video_NPU_0__s_axilite_awprot_i)
                                    , .s_axilite_awvalid_i(w_port__Video_NPU_0__s_axilite_awvalid_i)
                                    , .s_axilite_awready_o(w_port__Video_NPU_0__s_axilite_awready_o)
                                    , .s_axilite_wdata_i(w_port__Video_NPU_0__s_axilite_wdata_i)
                                    , .s_axilite_wstrb_i(w_port__Video_NPU_0__s_axilite_wstrb_i)
                                    , .s_axilite_wvalid_i(w_port__Video_NPU_0__s_axilite_wvalid_i)
                                    , .s_axilite_wready_o(w_port__Video_NPU_0__s_axilite_wready_o)
                                    , .s_axilite_bvalid_o(w_port__Video_NPU_0__s_axilite_bvalid_o)
                                    , .s_axilite_bresp_o(w_port__Video_NPU_0__s_axilite_bresp_o)
                                    , .s_axilite_bready_i(w_port__Video_NPU_0__s_axilite_bready_i)
                                    , .s_axilite_araddr_i(w_port__Video_NPU_0__s_axilite_araddr_i)
                                    , .s_axilite_arprot_i(w_port__Video_NPU_0__s_axilite_arprot_i)
                                    , .s_axilite_arvalid_i(w_port__Video_NPU_0__s_axilite_arvalid_i)
                                    , .s_axilite_arready_o(w_port__Video_NPU_0__s_axilite_arready_o)
                                    , .s_axilite_rdata_o(w_port__Video_NPU_0__s_axilite_rdata_o)
                                    , .s_axilite_rresp_o(w_port__Video_NPU_0__s_axilite_rresp_o)
                                    , .s_axilite_rvalid_o(w_port__Video_NPU_0__s_axilite_rvalid_o)
                                    , .s_axilite_rready_i(w_port__Video_NPU_0__s_axilite_rready_i)
                                    , .M_AXI_ACLK(w_port__Video_NPU_0__M_AXI_ACLK)
                                    , .M_AXI_AResetn(w_port__Video_NPU_0__M_AXI_AResetn)
                                    , .S_AXILite_ACLK(w_port__Video_NPU_0__S_AXILite_ACLK)
                                    , .S_AXILite_AResetn(w_port__Video_NPU_0__S_AXILite_AResetn)
                                    , .npu_soft_intr(w_port__Video_NPU_0__npu_soft_intr) );

    system_AXI_Protocol_Converter_0 AXI_Protocol_Converter_0 ( 
                                                                .us_axi_awid(w_port__AXI_Protocol_Converter_0__us_axi_awid)
                                                              , .us_axi_awaddr(w_port__AXI_Protocol_Converter_0__us_axi_awaddr)
                                                              , .us_axi_awlen(w_port__AXI_Protocol_Converter_0__us_axi_awlen)
                                                              , .us_axi_awsize(w_port__AXI_Protocol_Converter_0__us_axi_awsize)
                                                              , .us_axi_awburst(w_port__AXI_Protocol_Converter_0__us_axi_awburst)
                                                              , .us_axi_awlock(w_port__AXI_Protocol_Converter_0__us_axi_awlock)
                                                              , .us_axi_awcache(w_port__AXI_Protocol_Converter_0__us_axi_awcache)
                                                              , .us_axi_awprot(w_port__AXI_Protocol_Converter_0__us_axi_awprot)
                                                              , .us_axi_awqos(4'b0)
                                                              , .us_axi_awvalid(w_port__AXI_Protocol_Converter_0__us_axi_awvalid)
                                                              , .us_axi_awready(w_port__AXI_Protocol_Converter_0__us_axi_awready)
                                                              , .us_axi_wdata(w_port__AXI_Protocol_Converter_0__us_axi_wdata)
                                                              , .us_axi_wstrb(w_port__AXI_Protocol_Converter_0__us_axi_wstrb)
                                                              , .us_axi_wlast(w_port__AXI_Protocol_Converter_0__us_axi_wlast)
                                                              , .us_axi_wvalid(w_port__AXI_Protocol_Converter_0__us_axi_wvalid)
                                                              , .us_axi_wready(w_port__AXI_Protocol_Converter_0__us_axi_wready)
                                                              , .us_axi_bid(w_port__AXI_Protocol_Converter_0__us_axi_bid)
                                                              , .us_axi_bresp(w_port__AXI_Protocol_Converter_0__us_axi_bresp)
                                                              , .us_axi_bvalid(w_port__AXI_Protocol_Converter_0__us_axi_bvalid)
                                                              , .us_axi_bready(w_port__AXI_Protocol_Converter_0__us_axi_bready)
                                                              , .us_axi_arid(w_port__AXI_Protocol_Converter_0__us_axi_arid)
                                                              , .us_axi_araddr(w_port__AXI_Protocol_Converter_0__us_axi_araddr)
                                                              , .us_axi_arlen(w_port__AXI_Protocol_Converter_0__us_axi_arlen)
                                                              , .us_axi_arsize(w_port__AXI_Protocol_Converter_0__us_axi_arsize)
                                                              , .us_axi_arburst(w_port__AXI_Protocol_Converter_0__us_axi_arburst)
                                                              , .us_axi_arlock(w_port__AXI_Protocol_Converter_0__us_axi_arlock)
                                                              , .us_axi_arcache(w_port__AXI_Protocol_Converter_0__us_axi_arcache)
                                                              , .us_axi_arprot(w_port__AXI_Protocol_Converter_0__us_axi_arprot)
                                                              , .us_axi_arqos(4'b0)
                                                              , .us_axi_arvalid(w_port__AXI_Protocol_Converter_0__us_axi_arvalid)
                                                              , .us_axi_arready(w_port__AXI_Protocol_Converter_0__us_axi_arready)
                                                              , .us_axi_rid(w_port__AXI_Protocol_Converter_0__us_axi_rid)
                                                              , .us_axi_rdata(w_port__AXI_Protocol_Converter_0__us_axi_rdata)
                                                              , .us_axi_rresp(w_port__AXI_Protocol_Converter_0__us_axi_rresp)
                                                              , .us_axi_rlast(w_port__AXI_Protocol_Converter_0__us_axi_rlast)
                                                              , .us_axi_rvalid(w_port__AXI_Protocol_Converter_0__us_axi_rvalid)
                                                              , .us_axi_rready(w_port__AXI_Protocol_Converter_0__us_axi_rready)
                                                              , .aclk(w_port__AXI_Protocol_Converter_0__aclk)
                                                              , .aresetn(w_port__AXI_Protocol_Converter_0__aresetn)
                                                              , .ds_axi_awaddr(w_port__AXI_Protocol_Converter_0__ds_axi_awaddr)
                                                              , .ds_axi_awprot(w_port__AXI_Protocol_Converter_0__ds_axi_awprot)
                                                              , .ds_axi_awvalid(w_port__AXI_Protocol_Converter_0__ds_axi_awvalid)
                                                              , .ds_axi_awready(w_port__AXI_Protocol_Converter_0__ds_axi_awready)
                                                              , .ds_axi_wdata(w_port__AXI_Protocol_Converter_0__ds_axi_wdata)
                                                              , .ds_axi_wstrb(w_port__AXI_Protocol_Converter_0__ds_axi_wstrb)
                                                              , .ds_axi_wvalid(w_port__AXI_Protocol_Converter_0__ds_axi_wvalid)
                                                              , .ds_axi_wready(w_port__AXI_Protocol_Converter_0__ds_axi_wready)
                                                              , .ds_axi_bresp(w_port__AXI_Protocol_Converter_0__ds_axi_bresp)
                                                              , .ds_axi_bvalid(w_port__AXI_Protocol_Converter_0__ds_axi_bvalid)
                                                              , .ds_axi_bready(w_port__AXI_Protocol_Converter_0__ds_axi_bready)
                                                              , .ds_axi_araddr(w_port__AXI_Protocol_Converter_0__ds_axi_araddr)
                                                              , .ds_axi_arprot(w_port__AXI_Protocol_Converter_0__ds_axi_arprot)
                                                              , .ds_axi_arvalid(w_port__AXI_Protocol_Converter_0__ds_axi_arvalid)
                                                              , .ds_axi_arready(w_port__AXI_Protocol_Converter_0__ds_axi_arready)
                                                              , .ds_axi_rdata(w_port__AXI_Protocol_Converter_0__ds_axi_rdata)
                                                              , .ds_axi_rresp(w_port__AXI_Protocol_Converter_0__ds_axi_rresp)
                                                              , .ds_axi_rvalid(w_port__AXI_Protocol_Converter_0__ds_axi_rvalid)
                                                              , .ds_axi_rready(w_port__AXI_Protocol_Converter_0__ds_axi_rready) );

    system_AXI_Matrix_0 AXI_Matrix_0 ( 
                                        .us0_araddr(w_port__AXI_Matrix_0__us0_araddr)
                                      , .us0_arprot(w_port__AXI_Matrix_0__us0_arprot)
                                      , .us0_arready(w_port__AXI_Matrix_0__us0_arready)
                                      , .us0_arvalid(w_port__AXI_Matrix_0__us0_arvalid)
                                      , .us0_awaddr(w_port__AXI_Matrix_0__us0_awaddr)
                                      , .us0_awprot(w_port__AXI_Matrix_0__us0_awprot)
                                      , .us0_awready(w_port__AXI_Matrix_0__us0_awready)
                                      , .us0_awvalid(w_port__AXI_Matrix_0__us0_awvalid)
                                      , .us0_bready(w_port__AXI_Matrix_0__us0_bready)
                                      , .us0_bresp(w_port__AXI_Matrix_0__us0_bresp)
                                      , .us0_bvalid(w_port__AXI_Matrix_0__us0_bvalid)
                                      , .us0_rdata(w_port__AXI_Matrix_0__us0_rdata)
                                      , .us0_rready(w_port__AXI_Matrix_0__us0_rready)
                                      , .us0_rresp(w_port__AXI_Matrix_0__us0_rresp)
                                      , .us0_rvalid(w_port__AXI_Matrix_0__us0_rvalid)
                                      , .us0_wdata(w_port__AXI_Matrix_0__us0_wdata)
                                      , .us0_wready(w_port__AXI_Matrix_0__us0_wready)
                                      , .us0_wstrb(w_port__AXI_Matrix_0__us0_wstrb)
                                      , .us0_wvalid(w_port__AXI_Matrix_0__us0_wvalid)
                                      , .aclk(w_port__AXI_Matrix_0__aclk)
                                      , .aresetn(w_port__AXI_Matrix_0__aresetn)
                                      , .ds0_araddr(w_port__AXI_Matrix_0__ds0_araddr)
                                      , .ds0_arprot(w_port__AXI_Matrix_0__ds0_arprot)
                                      , .ds0_arready(w_port__AXI_Matrix_0__ds0_arready)
                                      , .ds0_arvalid(w_port__AXI_Matrix_0__ds0_arvalid)
                                      , .ds0_awaddr(w_port__AXI_Matrix_0__ds0_awaddr)
                                      , .ds0_awprot(w_port__AXI_Matrix_0__ds0_awprot)
                                      , .ds0_awready(w_port__AXI_Matrix_0__ds0_awready)
                                      , .ds0_awvalid(w_port__AXI_Matrix_0__ds0_awvalid)
                                      , .ds0_bready(w_port__AXI_Matrix_0__ds0_bready)
                                      , .ds0_bresp(w_port__AXI_Matrix_0__ds0_bresp)
                                      , .ds0_bvalid(w_port__AXI_Matrix_0__ds0_bvalid)
                                      , .ds0_rdata(w_port__AXI_Matrix_0__ds0_rdata)
                                      , .ds0_rready(w_port__AXI_Matrix_0__ds0_rready)
                                      , .ds0_rresp(w_port__AXI_Matrix_0__ds0_rresp)
                                      , .ds0_rvalid(w_port__AXI_Matrix_0__ds0_rvalid)
                                      , .ds0_wdata(w_port__AXI_Matrix_0__ds0_wdata)
                                      , .ds0_wready(w_port__AXI_Matrix_0__ds0_wready)
                                      , .ds0_wstrb(w_port__AXI_Matrix_0__ds0_wstrb)
                                      , .ds0_wvalid(w_port__AXI_Matrix_0__ds0_wvalid)
                                      , .ds1_araddr(w_port__AXI_Matrix_0__ds1_araddr)
                                      , .ds1_arprot(w_port__AXI_Matrix_0__ds1_arprot)
                                      , .ds1_arready(w_port__AXI_Matrix_0__ds1_arready)
                                      , .ds1_arvalid(w_port__AXI_Matrix_0__ds1_arvalid)
                                      , .ds1_awaddr(w_port__AXI_Matrix_0__ds1_awaddr)
                                      , .ds1_awprot(w_port__AXI_Matrix_0__ds1_awprot)
                                      , .ds1_awready(w_port__AXI_Matrix_0__ds1_awready)
                                      , .ds1_awvalid(w_port__AXI_Matrix_0__ds1_awvalid)
                                      , .ds1_bready(w_port__AXI_Matrix_0__ds1_bready)
                                      , .ds1_bresp(w_port__AXI_Matrix_0__ds1_bresp)
                                      , .ds1_bvalid(w_port__AXI_Matrix_0__ds1_bvalid)
                                      , .ds1_rdata(w_port__AXI_Matrix_0__ds1_rdata)
                                      , .ds1_rready(w_port__AXI_Matrix_0__ds1_rready)
                                      , .ds1_rresp(w_port__AXI_Matrix_0__ds1_rresp)
                                      , .ds1_rvalid(w_port__AXI_Matrix_0__ds1_rvalid)
                                      , .ds1_wdata(w_port__AXI_Matrix_0__ds1_wdata)
                                      , .ds1_wready(w_port__AXI_Matrix_0__ds1_wready)
                                      , .ds1_wstrb(w_port__AXI_Matrix_0__ds1_wstrb)
                                      , .ds1_wvalid(w_port__AXI_Matrix_0__ds1_wvalid) );


uiFDMA #(.M_AXI_MAX_BURST_LEN(16)) capture_fdma(
 .M_AXI_ACLK(w_net__ARM_Processor_System_0__p2f_clk0),.M_AXI_ARESETN(I_cap_resetn),
 .I_fdma_waddr(I_cap_addr),.I_fdma_wareq(I_cap_req),.I_fdma_wsize(I_cap_size),.I_fdma_wdata(I_cap_data),
 .I_fdma_wready(I_cap_ready),.O_fdma_wbusy(O_cap_busy),.O_fdma_wvalid(O_cap_valid),
 .I_fdma_raddr(I_disp_addr),.I_fdma_rareq(I_disp_req),.I_fdma_rsize(I_disp_size),.I_fdma_rready(I_disp_ready),
 .O_fdma_rbusy(O_disp_busy),.O_fdma_rvalid(O_disp_valid),.O_fdma_rdata(O_disp_data),
.M_AXI_AWID(w_port__Video_NPU_0__m_axi_awid_soft_o),
.M_AXI_AWADDR(w_port__Video_NPU_0__m_axi_awaddr_soft_o),
.M_AXI_AWLEN(w_port__Video_NPU_0__m_axi_awlen_soft_o),
.M_AXI_AWSIZE(w_port__Video_NPU_0__m_axi_awsize_soft_o),
.M_AXI_AWBURST(w_port__Video_NPU_0__m_axi_awburst_soft_o),
.M_AXI_AWLOCK(w_port__Video_NPU_0__m_axi_awlock_soft_o),
.M_AXI_AWCACHE(w_port__Video_NPU_0__m_axi_awcache_soft_o),
.M_AXI_AWPROT(w_port__Video_NPU_0__m_axi_awprot_soft_o),
.M_AXI_AWVALID(w_port__Video_NPU_0__m_axi_awvalid_soft_o),
.M_AXI_AWREADY(w_port__Video_NPU_0__m_axi_awready_soft_i),
.M_AXI_WDATA(w_port__Video_NPU_0__m_axi_wdata_soft_o),
.M_AXI_WSTRB(w_port__Video_NPU_0__m_axi_wstrb_soft_o),
.M_AXI_WLAST(w_port__Video_NPU_0__m_axi_wlast_soft_o),
.M_AXI_WVALID(w_port__Video_NPU_0__m_axi_wvalid_soft_o),
.M_AXI_WREADY(w_port__Video_NPU_0__m_axi_wready_soft_i),
.M_AXI_BID(w_port__Video_NPU_0__m_axi_bid_soft_i),
.M_AXI_BRESP(w_port__Video_NPU_0__m_axi_bresp_soft_i),
.M_AXI_BVALID(w_port__Video_NPU_0__m_axi_bvalid_soft_i),
.M_AXI_BREADY(w_port__Video_NPU_0__m_axi_bready_soft_o),
.M_AXI_ARID(w_port__Video_NPU_0__m_axi_arid_soft_o),
.M_AXI_ARADDR(w_port__Video_NPU_0__m_axi_araddr_soft_o),
.M_AXI_ARLEN(w_port__Video_NPU_0__m_axi_arlen_soft_o),
.M_AXI_ARSIZE(w_port__Video_NPU_0__m_axi_arsize_soft_o),
.M_AXI_ARBURST(w_port__Video_NPU_0__m_axi_arburst_soft_o),
.M_AXI_ARLOCK(w_port__Video_NPU_0__m_axi_arlock_soft_o),
.M_AXI_ARCACHE(w_port__Video_NPU_0__m_axi_arcache_soft_o),
.M_AXI_ARPROT(w_port__Video_NPU_0__m_axi_arprot_soft_o),
.M_AXI_ARVALID(w_port__Video_NPU_0__m_axi_arvalid_soft_o),
.M_AXI_ARREADY(w_port__Video_NPU_0__m_axi_arready_soft_i),
.M_AXI_RID(w_port__Video_NPU_0__m_axi_rid_soft_i),
.M_AXI_RDATA(w_port__Video_NPU_0__m_axi_rdata_soft_i),
.M_AXI_RRESP(w_port__Video_NPU_0__m_axi_rresp_soft_i),
.M_AXI_RLAST(w_port__Video_NPU_0__m_axi_rlast_soft_i),
.M_AXI_RVALID(w_port__Video_NPU_0__m_axi_rvalid_soft_i),
.M_AXI_RREADY(w_port__Video_NPU_0__m_axi_rready_soft_o));
assign O_cap_awvalid=w_port__Video_NPU_0__m_axi_awvalid_soft_o;
assign O_cap_awready=w_port__Video_NPU_0__m_axi_awready_soft_i;
assign O_cap_bvalid=w_port__Video_NPU_0__m_axi_bvalid_soft_i;
assign O_cap_bready=w_port__Video_NPU_0__m_axi_bready_soft_o;
assign O_cap_bresp=w_port__Video_NPU_0__m_axi_bresp_soft_i;

    net_pl_control #(.FRONT96(1),.BLOCK34(1)) dw16_cfg ( 
                                              .S_AXI_AWADDR({20'b0,w_port__temporal_conv_0__S_AXI_AWADDR})
                                            , .S_AXI_AWPROT(w_port__temporal_conv_0__S_AXI_AWPROT)
                                            , .S_AXI_AWVALID(w_port__temporal_conv_0__S_AXI_AWVALID)
                                            , .S_AXI_AWREADY(w_port__temporal_conv_0__S_AXI_AWREADY)
                                            , .S_AXI_WDATA(w_port__temporal_conv_0__S_AXI_WDATA)
                                            , .S_AXI_WSTRB(w_port__temporal_conv_0__S_AXI_WSTRB)
                                            , .S_AXI_WVALID(w_port__temporal_conv_0__S_AXI_WVALID)
                                            , .S_AXI_WREADY(w_port__temporal_conv_0__S_AXI_WREADY)
                                            , .S_AXI_BRESP(w_port__temporal_conv_0__S_AXI_BRESP)
                                            , .S_AXI_BVALID(w_port__temporal_conv_0__S_AXI_BVALID)
                                            , .S_AXI_BREADY(w_port__temporal_conv_0__S_AXI_BREADY)
                                            , .S_AXI_ARADDR({20'b0,w_port__temporal_conv_0__S_AXI_ARADDR})
                                            , .S_AXI_ARPROT(w_port__temporal_conv_0__S_AXI_ARPROT)
                                            , .S_AXI_ARVALID(w_port__temporal_conv_0__S_AXI_ARVALID)
                                            , .S_AXI_ARREADY(w_port__temporal_conv_0__S_AXI_ARREADY)
                                            , .S_AXI_RDATA(w_port__temporal_conv_0__S_AXI_RDATA)
                                            , .S_AXI_RRESP(w_port__temporal_conv_0__S_AXI_RRESP)
                                            , .S_AXI_RVALID(w_port__temporal_conv_0__S_AXI_RVALID)
                                            , .S_AXI_RREADY(w_port__temporal_conv_0__S_AXI_RREADY)
                                            , .cap_resetn(I_cap_resetn),.cap_slot(I_cap_slot),.cap_done(I_cap_done),.cap_done_slot(I_cap_done_slot),
 .cap_fault(I_cap_fault),.cap_enable(O_cap_enable),.disp_enable(O_disp_enable),.cap_flags(I_cap_flags),.cap_csi(I_cap_csi),.cap_isp(I_cap_isp),
 .cap_aw(I_cap_aw),.cap_b(I_cap_b),.cap_rx(I_cap_rx),.cap_valid(I_cap_valid),
 .aclk(w_port__temporal_conv_0__aclk)
                                            , .rst_n(dw16_resetn) , .dma_start(dw16_start), .dma_input(dw16_input), .dma_parameter(dw16_parameter),
.dma_output(dw16_output), .dma_busy(dw16_busy), .dma_done(dw16_done), .dma_fault(dw16_fault),.owner(net_owner),
       .v_start(v_start),.v_input(v_input),.v_parameter(v_parameter),.v_output(v_output),.v_budget(v_budget),
       .v_busy(v_busy),.v_done(v_done),.v_fault(v_fault),.v_core_cycles(v_core_cycles),
       .v_base_products(v_base_products),.v_interval_products(v_interval_products),
       .v_residual_products(v_residual_products),.v_skipped_products(v_skipped_products),.v_residual_reads(v_residual_reads),.f_start(f_start),.f_input(f_input),.f_parameter(f_parameter),.f_output(f_output),.f_busy(f_busy),.f_done(f_done),.f_fault(f_fault),.c_dw_mode(c_dw_mode),.c_start(c_start),.c_busy(c_busy),.c_done(c_done),.c_fault(c_fault),.c_input(c_input),.c_expand(c_expand),.c_depthwise(c_depthwise),.c_project(c_project),.c_scratch_expand(c_scratch_expand),.c_scratch_depthwise(c_scratch_depthwise),.c_output(c_output) );

endmodule
