//============================================================================
// ctrl_fsm.v — Main Control FSM for Temporal Convolution Accelerator
//
// Orchestrates the 1D convolution computation:
//   1. Read feature data from DDR (via AXI master read)
//   2. Read weights from BRAM
//   3. Feed feature×weight pairs to PE array
//   4. Accumulate across kernel_size × feat_dim
//   5. Repeat for all filter groups (if NUM_FILTERS > NUM_PE)
//   6. Pool results
//   7. Write output to DDR (via AXI master write)
//   8. Assert done
//
// States: IDLE → LOAD_FEAT → COMPUTE → POOL → WRITE_OUT → DONE
//============================================================================
module ctrl_fsm #(
    parameter NUM_PE      = 16,
    parameter MAX_FRAMES  = 16,
    parameter MAX_FEAT_DIM = 256,
    parameter MAX_KERNEL  = 8
)(
    input  wire        clk,
    input  wire        rst_n,

    // Control registers (from AXI-Lite)
    input  wire        start,           // pulse to begin
    input  wire [31:0] feat_addr,       // DDR base address of feature buffer
    input  wire [31:0] out_addr,        // DDR base address for output
    input  wire [7:0]  num_frames,      // number of frames in temporal window
    input  wire [8:0]  feat_dim,        // feature dimension per frame (max 256)
    input  wire [3:0]  kernel_size,     // convolution kernel size (max 8)
    input  wire [7:0]  num_filters,     // total output channels
    input  wire [3:0]  pool_shift,      // right-shift for average pooling

    // Status
    output reg         busy,
    output reg         done,

    // PE array control
    output reg         pe_clear,
    output reg         pe_valid,
    output reg  signed [7:0] pe_feat,
    output reg  [12:0] weight_addr,     // BRAM read address
    input  wire [127:0] weight_data,    // BRAM read data (16 × INT8)

    // Pool control
    output reg         pool_clear,
    output reg         pool_acc_valid,

    // AXI master read interface (simplified)
    output reg         axi_rd_req,
    output reg  [31:0] axi_rd_addr,
    output reg  [7:0]  axi_rd_len,      // burst length - 1
    input  wire        axi_rd_valid,
    input  wire [63:0] axi_rd_data,
    input  wire        axi_rd_last,

    // AXI master write interface (simplified)
    output reg         axi_wr_req,
    output reg  [31:0] axi_wr_addr,
    output reg  [7:0]  axi_wr_len,
    output reg         axi_wr_valid,
    output reg  [63:0] axi_wr_data,
    input  wire        axi_wr_ready,
    input  wire        axi_wr_done
);

    // FSM states
    localparam S_IDLE      = 3'd0;
    localparam S_LOAD_FEAT = 3'd1;
    localparam S_COMPUTE   = 3'd2;
    localparam S_POOL      = 3'd3;
    localparam S_WRITE_OUT = 3'd4;
    localparam S_DONE      = 3'd5;

    reg [2:0] state, next_state;

    // Internal counters
    reg [7:0]  frame_cnt;      // current frame index within kernel window
    reg [8:0]  dim_cnt;        // current dimension index
    reg [7:0]  filter_pass;    // current filter group (for NUM_FILTERS > NUM_PE)
    reg [3:0]  k_cnt;          // kernel position counter

    // Feature buffer (small local SRAM for current kernel window)
    // For simplicity, features are streamed from DDR on-the-fly
    // In a production design, you'd double-buffer

    // State register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= S_IDLE;
        else
            state <= next_state;
    end

    // Next state logic
    always @(*) begin
        next_state = state;
        case (state)
            S_IDLE:
                if (start) next_state = S_LOAD_FEAT;
            S_LOAD_FEAT:
                if (axi_rd_last) next_state = S_COMPUTE;
            S_COMPUTE:
                if (k_cnt == kernel_size - 1 && dim_cnt == feat_dim - 1)
                    next_state = S_POOL;
            S_POOL:
                next_state = S_WRITE_OUT;
            S_WRITE_OUT:
                if (axi_wr_done) next_state = S_DONE;
            S_DONE:
                next_state = S_IDLE;
            default:
                next_state = S_IDLE;
        endcase
    end

    // Output logic (simplified — production version needs full datapath)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy           <= 1'b0;
            done           <= 1'b0;
            pe_clear       <= 1'b0;
            pe_valid       <= 1'b0;
            pe_feat        <= 8'd0;
            weight_addr    <= 13'd0;
            pool_clear     <= 1'b0;
            pool_acc_valid <= 1'b0;
            axi_rd_req     <= 1'b0;
            axi_rd_addr    <= 32'd0;
            axi_rd_len     <= 8'd0;
            axi_wr_req     <= 1'b0;
            axi_wr_addr    <= 32'd0;
            axi_wr_len     <= 8'd0;
            axi_wr_valid   <= 1'b0;
            axi_wr_data    <= 64'd0;
            frame_cnt      <= 8'd0;
            dim_cnt        <= 9'd0;
            filter_pass    <= 8'd0;
            k_cnt          <= 4'd0;
        end else begin
            // Default de-assertions
            pe_valid       <= 1'b0;
            pe_clear       <= 1'b0;
            pool_clear     <= 1'b0;
            pool_acc_valid <= 1'b0;
            axi_rd_req     <= 1'b0;
            axi_wr_req     <= 1'b0;
            axi_wr_valid   <= 1'b0;
            done           <= 1'b0;

            case (state)
                S_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy       <= 1'b1;
                        pe_clear   <= 1'b1;
                        pool_clear <= 1'b1;
                        frame_cnt  <= 8'd0;
                        dim_cnt    <= 9'd0;
                        k_cnt      <= 4'd0;
                        filter_pass <= 8'd0;
                    end
                end

                S_LOAD_FEAT: begin
                    // Issue AXI read burst for feature data
                    // Address: feat_addr + frame_offset
                    axi_rd_req  <= 1'b1;
                    axi_rd_addr <= feat_addr + {frame_cnt, 8'd0}; // frame * 256 bytes
                    axi_rd_len  <= (feat_dim >> 3) - 1; // 256/8 - 1 = 31 beats of 64-bit
                end

                S_COMPUTE: begin
                    // Stream feature×weight pairs to PE array
                    // This is a simplified placeholder — full implementation
                    // would iterate over kernel positions and dimensions
                    pe_valid    <= 1'b1;
                    pe_feat     <= axi_rd_data[7:0]; // simplified: take first byte
                    weight_addr <= {filter_pass[3:0], k_cnt, dim_cnt[7:0]};

                    dim_cnt <= dim_cnt + 1'b1;
                    if (dim_cnt == feat_dim - 1) begin
                        dim_cnt <= 9'd0;
                        k_cnt   <= k_cnt + 1'b1;
                    end
                end

                S_POOL: begin
                    pool_acc_valid <= 1'b1;
                end

                S_WRITE_OUT: begin
                    // Write pooled results to DDR
                    axi_wr_req   <= 1'b1;
                    axi_wr_addr  <= out_addr;
                    axi_wr_len   <= (NUM_PE * 4 / 8) - 1; // 16*4=64 bytes = 8 beats
                    axi_wr_valid <= 1'b1;
                    // axi_wr_data driven from pool_out (connected at top level)
                end

                S_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                end
            endcase
        end
    end

endmodule
