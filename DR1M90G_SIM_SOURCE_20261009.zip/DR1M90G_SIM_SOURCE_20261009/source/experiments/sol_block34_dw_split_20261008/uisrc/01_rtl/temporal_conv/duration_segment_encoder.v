`timescale 1ns/1ps

// Duration segment encoder: fixed-representative, per-channel bounded merge.
// A frame is accepted on frame_valid. frame_last publishes the segment list.
module duration_segment_encoder #(
    parameter CHANNELS = 4,
    parameter MAX_FRAMES = 16,
    parameter MAX_SEGMENTS = MAX_FRAMES,
    parameter MAX_SEGMENT_LENGTH = MAX_FRAMES,
    parameter FRAME_W = (MAX_FRAMES <= 2) ? 1 : $clog2(MAX_FRAMES),
    parameter LEN_W = (MAX_SEGMENT_LENGTH <= 1) ? 1 : $clog2(MAX_SEGMENT_LENGTH + 1),
    parameter COUNT_W = $clog2(MAX_FRAMES + 1)
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         clear,
    input  wire                         frame_valid,
    input  wire                         frame_last,
    input  wire [CHANNELS*8-1:0]        frame_data,
    input  wire [CHANNELS*8-1:0]        thresholds,
    output reg  [COUNT_W-1:0]           frame_count,
    output reg  [COUNT_W-1:0]           segment_count,
    output reg  [FRAME_W*MAX_SEGMENTS-1:0] segment_start_flat,
    output reg  [LEN_W*MAX_SEGMENTS-1:0] segment_len_flat,
    output reg  [CHANNELS*8*MAX_SEGMENTS-1:0] segment_value_flat,
    output reg  [CHANNELS*8*MAX_SEGMENTS-1:0] segment_dev_flat,
    output reg  [CHANNELS*8*MAX_FRAMES-1:0] feature_flat,
    output reg                          busy,
    output reg                          done
);
    integer c;
    integer current_seg;
    integer merge_ok;
    integer difference;
    integer threshold_value;
    integer representative_value;
    integer sample_value;
    integer current_len;
    integer frame_index;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_count       <= 0;
            segment_count     <= 0;
            segment_start_flat<= 0;
            segment_len_flat  <= 0;
            segment_value_flat<= 0;
            segment_dev_flat  <= 0;
            feature_flat      <= 0;
            busy              <= 1'b0;
            done              <= 1'b0;
        end else if (clear) begin
            frame_count       <= 0;
            segment_count     <= 0;
            segment_start_flat<= 0;
            segment_len_flat  <= 0;
            segment_value_flat<= 0;
            segment_dev_flat  <= 0;
            feature_flat      <= 0;
            busy              <= 1'b1;
            done              <= 1'b0;
        end else begin
            done <= 1'b0;
            if (frame_valid && frame_count < MAX_FRAMES) begin
                busy <= 1'b1;
                frame_index = frame_count;
                for (c = 0; c < CHANNELS; c = c + 1)
                    feature_flat[(frame_index*CHANNELS+c)*8 +: 8] <= frame_data[c*8 +: 8];

                if (frame_count == 0) begin
                    segment_count <= 1;
                    segment_start_flat[0 +: FRAME_W] <= 0;
                    segment_len_flat[0 +: LEN_W] <= 1;
                    for (c = 0; c < CHANNELS; c = c + 1) begin
                        segment_value_flat[c*8 +: 8] <= frame_data[c*8 +: 8];
                        segment_dev_flat[c*8 +: 8] <= 0;
                    end
                end else begin
                    current_seg = segment_count - 1;
                    current_len = segment_len_flat[current_seg*LEN_W +: LEN_W];
                    merge_ok = (current_len < MAX_SEGMENT_LENGTH);
                    for (c = 0; c < CHANNELS; c = c + 1) begin
                        sample_value = $signed(frame_data[c*8 +: 8]);
                        representative_value = $signed(segment_value_flat[(current_seg*CHANNELS+c)*8 +: 8]);
                        difference = sample_value - representative_value;
                        if (difference < 0) difference = -difference;
                        threshold_value = thresholds[c*8 +: 8];
                        if (difference > threshold_value) merge_ok = 0;
                    end
                    if (merge_ok) begin
                    segment_len_flat[current_seg*LEN_W +: LEN_W] <= current_len + 1;
                        for (c = 0; c < CHANNELS; c = c + 1) begin
                            sample_value = $signed(frame_data[c*8 +: 8]);
                            representative_value = $signed(segment_value_flat[(current_seg*CHANNELS+c)*8 +: 8]);
                            difference = sample_value - representative_value;
                            if (difference < 0) difference = -difference;
                            if (difference > segment_dev_flat[(current_seg*CHANNELS+c)*8 +: 8])
                                segment_dev_flat[(current_seg*CHANNELS+c)*8 +: 8] <= difference[7:0];
                        end
                    end else if (segment_count < MAX_SEGMENTS) begin
                        segment_start_flat[segment_count*FRAME_W +: FRAME_W] <= frame_count;
                        segment_len_flat[segment_count*LEN_W +: LEN_W] <= 1;
                        for (c = 0; c < CHANNELS; c = c + 1) begin
                            segment_value_flat[(segment_count*CHANNELS+c)*8 +: 8] <= frame_data[c*8 +: 8];
                            segment_dev_flat[(segment_count*CHANNELS+c)*8 +: 8] <= 0;
                        end
                        segment_count <= segment_count + 1;
                    end
                end

                frame_count <= frame_count + 1;
                if (frame_last) begin
                    busy <= 1'b0;
                    done <= 1'b1;
                end
            end
        end
    end
endmodule
