//============================================================================
// temporal_conv_top.v — Top-level Wrapper for 1D Temporal Convolution Accelerator
//
// Interfaces:
//   - S_AXI_LITE: ARM configuration (register read/write, weight loading)
//   - M_AXI: DDR access (read features, write results) via HP port
//   - IRQ: done interrupt to ARM
//
// Architecture:
//   axi_lite_cfg ←→ ctrl_fsm ←→ pe_array ←→ pool_unit
//                                    ↕
//                              weight_bram
//                                    ↕
//                         AXI Master (DDR read/write)
//
// Parameters (configurable at synthesis time):
//   NUM_PE      = 16   (parallel MAC units)
//   MAX_FRAMES  = 16   (temporal window depth)
//   MAX_FEAT_DIM = 256 (feature vector length)
//   MAX_KERNEL  = 8    (max kernel size)
//============================================================================
module temporal_conv_top #(
    parameter NUM_PE       = 16,
    parameter MAX_FRAMES   = 16,
    parameter MAX_FEAT_DIM = 256,
    parameter MAX_KERNEL   = 8,
    parameter AXI_ADDR_W   = 32,
    parameter AXI_DATA_W   = 64,
    parameter AXI_ID_W     = 6,
    parameter AXIL_ADDR_W  = 6
)(
    // Clock and reset
    input  wire        aclk,          // system clock (200MHz recommended)
    input  wire        aresetn,       // active-low reset

    // ========== AXI4-Lite Slave (ARM config) ==========
    input  wire [AXIL_ADDR_W-1:0] s_axil_awaddr,
    input  wire        s_axil_awvalid,
    output wire        s_axil_awready,
    input  wire [31:0] s_axil_wdata,
    input  wire [3:0]  s_axil_wstrb,
    input  wire        s_axil_wvalid,
    output wire        s_axil_wready,
    output wire [1:0]  s_axil_bresp,
    output wire        s_axil_bvalid,
    input  wire        s_axil_bready,
    input  wire [AXIL_ADDR_W-1:0] s_axil_araddr,
    input  wire        s_axil_arvalid,
    output wire        s_axil_arready,
    output wire [31:0] s_axil_rdata,
    output wire [1:0]  s_axil_rresp,
    output wire        s_axil_rvalid,
    input  wire        s_axil_rready,

    // ========== AXI4 Master (DDR access) ==========
    // AR channel
    output wire [AXI_ID_W-1:0]   m_axi_arid,
    output wire [AXI_ADDR_W-1:0] m_axi_araddr,
    output wire [7:0]            m_axi_arlen,
    output wire [2:0]            m_axi_arsize,
    output wire [1:0]            m_axi_arburst,
    output wire                  m_axi_arvalid,
    input  wire                  m_axi_arready,
    // R channel
    input  wire [AXI_ID_W-1:0]   m_axi_rid,
    input  wire [AXI_DATA_W-1:0] m_axi_rdata,
    input  wire [1:0]            m_axi_rresp,
    input  wire                  m_axi_rlast,
    input  wire                  m_axi_rvalid,
    output wire                  m_axi_rready,
    // AW channel
    output wire [AXI_ID_W-1:0]   m_axi_awid,
    output wire [AXI_ADDR_W-1:0] m_axi_awaddr,
    output wire [7:0]            m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    // W channel
    output wire [AXI_DATA_W-1:0] m_axi_wdata,
    output wire [AXI_DATA_W/8-1:0] m_axi_wstrb,
    output wire                  m_axi_wlast,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    // B channel
    input  wire [AXI_ID_W-1:0]   m_axi_bid,
    input  wire [1:0]            m_axi_bresp,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,

    // ========== Interrupt ==========
    output wire        irq_done
);

    // ---- Internal wires ----
    // AXI-Lite config ↔ ctrl_fsm
    wire        cfg_start;
    wire [31:0] cfg_feat_addr;
    wire [31:0] cfg_out_addr;
    wire [7:0]  cfg_num_frames;
    wire [8:0]  cfg_feat_dim;
    wire [3:0]  cfg_kernel_size;
    wire [7:0]  cfg_num_filters;
    wire [3:0]  cfg_pool_shift;
    wire        sts_busy;
    wire        sts_done;

    // Weight BRAM
    wire        weight_wr_en;
    wire [12:0] weight_wr_addr;
    wire [31:0] weight_wr_data;
    wire [12:0] weight_rd_addr;
    wire [127:0] weight_rd_data;

    // PE array
    wire        pe_clear;
    wire        pe_valid;
    wire signed [7:0] pe_feat;
    wire signed [NUM_PE*32-1:0] pe_acc;
    wire [NUM_PE-1:0] pe_done;

    // Pool
    wire        pool_clear;
    wire        pool_acc_valid;
    wire signed [NUM_PE*32-1:0] pool_out;
    wire        pool_valid;

    // AXI master simplified signals (ctrl_fsm ↔ external AXI)
    wire        axi_rd_req;
    wire [31:0] axi_rd_addr_w;
    wire [7:0]  axi_rd_len_w;
    wire        axi_rd_valid_w;
    wire [63:0] axi_rd_data_w;
    wire        axi_rd_last_w;
    wire        axi_wr_req;
    wire [31:0] axi_wr_addr_w;
    wire [7:0]  axi_wr_len_w;
    wire        axi_wr_valid_w;
    wire [63:0] axi_wr_data_w;
    wire        axi_wr_ready_w;
    wire        axi_wr_done_w;

    // ---- Instantiations ----

    axi_lite_cfg #(.ADDR_WIDTH(AXIL_ADDR_W)) u_cfg (
        .aclk           (aclk),
        .aresetn        (aresetn),
        .s_awaddr       (s_axil_awaddr),
        .s_awvalid      (s_axil_awvalid),
        .s_awready      (s_axil_awready),
        .s_wdata        (s_axil_wdata),
        .s_wstrb        (s_axil_wstrb),
        .s_wvalid       (s_axil_wvalid),
        .s_wready       (s_axil_wready),
        .s_bresp        (s_axil_bresp),
        .s_bvalid       (s_axil_bvalid),
        .s_bready       (s_axil_bready),
        .s_araddr       (s_axil_araddr),
        .s_arvalid      (s_axil_arvalid),
        .s_arready      (s_axil_arready),
        .s_rdata        (s_axil_rdata),
        .s_rresp        (s_axil_rresp),
        .s_rvalid       (s_axil_rvalid),
        .s_rready       (s_axil_rready),
        .cfg_start      (cfg_start),
        .cfg_feat_addr  (cfg_feat_addr),
        .cfg_out_addr   (cfg_out_addr),
        .cfg_num_frames (cfg_num_frames),
        .cfg_feat_dim   (cfg_feat_dim),
        .cfg_kernel_size(cfg_kernel_size),
        .cfg_num_filters(cfg_num_filters),
        .cfg_pool_shift (cfg_pool_shift),
        .sts_busy       (sts_busy),
        .sts_done       (sts_done),
        .weight_wr_en   (weight_wr_en),
        .weight_wr_addr (weight_wr_addr),
        .weight_wr_data (weight_wr_data),
        .irq_out        (irq_done)
    );

    ctrl_fsm #(
        .NUM_PE      (NUM_PE),
        .MAX_FRAMES  (MAX_FRAMES),
        .MAX_FEAT_DIM(MAX_FEAT_DIM),
        .MAX_KERNEL  (MAX_KERNEL)
    ) u_ctrl (
        .clk          (aclk),
        .rst_n        (aresetn),
        .start        (cfg_start),
        .feat_addr    (cfg_feat_addr),
        .out_addr     (cfg_out_addr),
        .num_frames   (cfg_num_frames),
        .feat_dim     (cfg_feat_dim),
        .kernel_size  (cfg_kernel_size),
        .num_filters  (cfg_num_filters),
        .pool_shift   (cfg_pool_shift),
        .busy         (sts_busy),
        .done         (sts_done),
        .pe_clear     (pe_clear),
        .pe_valid     (pe_valid),
        .pe_feat      (pe_feat),
        .weight_addr  (weight_rd_addr),
        .weight_data  (weight_rd_data),
        .pool_clear   (pool_clear),
        .pool_acc_valid(pool_acc_valid),
        .axi_rd_req   (axi_rd_req),
        .axi_rd_addr  (axi_rd_addr_w),
        .axi_rd_len   (axi_rd_len_w),
        .axi_rd_valid (axi_rd_valid_w),
        .axi_rd_data  (axi_rd_data_w),
        .axi_rd_last  (axi_rd_last_w),
        .axi_wr_req   (axi_wr_req),
        .axi_wr_addr  (axi_wr_addr_w),
        .axi_wr_len   (axi_wr_len_w),
        .axi_wr_valid (axi_wr_valid_w),
        .axi_wr_data  (axi_wr_data_w),
        .axi_wr_ready (axi_wr_ready_w),
        .axi_wr_done  (axi_wr_done_w)
    );

    pe_array #(
        .NUM_PE     (NUM_PE),
        .KERNEL_SIZE(MAX_KERNEL),
        .FEAT_DIM   (MAX_FEAT_DIM)
    ) u_pe (
        .clk       (aclk),
        .rst_n     (aresetn),
        .clear_all (pe_clear),
        .valid_i   (pe_valid),
        .feat_i    (pe_feat),
        .weight_i  (weight_rd_data[NUM_PE*8-1:0]),
        .acc_o     (pe_acc),
        .valid_o   (pe_done)
    );

    pool_unit #(.NUM_PE(NUM_PE)) u_pool (
        .clk        (aclk),
        .rst_n      (aresetn),
        .clear      (pool_clear),
        .acc_valid  (pool_acc_valid),
        .acc_in     (pe_acc),
        .shift_amt  (cfg_pool_shift),
        .pool_out   (pool_out),
        .pool_valid (pool_valid)
    );

    weight_bram #(
        .ADDR_WIDTH (13),
        .DATA_WIDTH (128)
    ) u_wbram (
        .clk    (aclk),
        .wr_en_a(weight_wr_en),
        .addr_a (weight_wr_addr),
        .din_a  ({{96{1'b0}}, weight_wr_data}),  // zero-pad to 128-bit
        .addr_b (weight_rd_addr),
        .dout_b (weight_rd_data)
    );

    // ---- AXI Master (simplified direct connection) ----
    // In production, replace with a proper AXI master state machine.
    // For now, directly map ctrl_fsm signals to AXI ports.
    assign m_axi_arid    = {AXI_ID_W{1'b0}};
    assign m_axi_araddr  = axi_rd_addr_w;
    assign m_axi_arlen   = axi_rd_len_w;
    assign m_axi_arsize  = 3'b011;  // 8 bytes per beat
    assign m_axi_arburst = 2'b01;   // INCR
    assign m_axi_arvalid = axi_rd_req;
    assign axi_rd_valid_w = m_axi_rvalid;
    assign axi_rd_data_w  = m_axi_rdata;
    assign axi_rd_last_w  = m_axi_rlast;
    assign m_axi_rready   = 1'b1;   // always ready to accept read data

    assign m_axi_awid    = {AXI_ID_W{1'b0}};
    assign m_axi_awaddr  = axi_wr_addr_w;
    assign m_axi_awlen   = axi_wr_len_w;
    assign m_axi_awsize  = 3'b011;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awvalid = axi_wr_req;
    assign m_axi_wdata   = axi_wr_data_w;
    assign m_axi_wstrb   = {(AXI_DATA_W/8){1'b1}};
    assign m_axi_wlast   = 1'b1;    // single-beat for now
    assign m_axi_wvalid  = axi_wr_valid_w;
    assign axi_wr_ready_w = m_axi_wready;
    assign axi_wr_done_w  = m_axi_bvalid;
    assign m_axi_bready   = 1'b1;

endmodule
