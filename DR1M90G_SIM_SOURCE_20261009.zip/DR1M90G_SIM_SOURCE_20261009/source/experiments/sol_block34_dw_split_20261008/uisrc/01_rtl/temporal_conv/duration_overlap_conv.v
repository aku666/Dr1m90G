`timescale 1ns/1ps

// Segment-domain temporal convolution.
// MODE 0: ordinary frame-by-frame convolution.
// MODE 1: lossless segment-domain direct convolution.
// MODE 2: bounded-error segment-domain direct convolution with certificate.
module duration_overlap_conv #(
    parameter CHANNELS = 4,
    parameter MAX_FRAMES = 16,
    parameter MAX_KERNEL = 8,
    parameter MAX_SEGMENTS = MAX_FRAMES,
    parameter FRAME_W = (MAX_FRAMES <= 2) ? 1 : $clog2(MAX_FRAMES),
    parameter LEN_W = (MAX_FRAMES <= 1) ? 1 : $clog2(MAX_FRAMES + 1),
    parameter COUNT_W = $clog2(MAX_FRAMES + 1),
    parameter PREFIX_W = 16
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         start,
    input  wire [1:0]                   mode,
    input  wire [COUNT_W-1:0]           frame_count,
    input  wire [COUNT_W-1:0]           segment_count,
    input  wire [FRAME_W*MAX_SEGMENTS-1:0] segment_start_flat,
    input  wire [LEN_W*MAX_SEGMENTS-1:0] segment_len_flat,
    input  wire [CHANNELS*8*MAX_SEGMENTS-1:0] segment_value_flat,
    input  wire [CHANNELS*8*MAX_SEGMENTS-1:0] segment_dev_flat,
    input  wire [CHANNELS*8*MAX_FRAMES-1:0] feature_flat,
    input  wire [CHANNELS*MAX_KERNEL*8-1:0] weight_flat,
    input  wire signed [CHANNELS*(MAX_KERNEL+1)*PREFIX_W-1:0] prefix_flat,
    input  wire [3:0]                   kernel_size,
    output reg                          busy,
    output reg                          done,
    output reg                          out_valid,
    output reg  [FRAME_W-1:0]           out_index,
    output reg  signed [63:0]           out_data,
    output reg  [63:0]                  out_error_bound
);
    localparam S_IDLE = 1'b0;
    localparam S_RUN  = 1'b1;
    reg state;
    integer win_index;
    integer frame_total;
    integer kernel_total;
    integer s;
    integer c;
    integer k;
    integer seg_start;
    integer seg_end;
    integer left;
    integer right;
    integer rel_left;
    integer rel_right;
    integer rep;
    integer dev;
    integer sample;
    integer weight;
    integer p_hi;
    integer p_lo;
    integer sum_tmp;
    integer bound_tmp;
    integer abs_weight;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE;
            win_index <= 0;
            busy <= 1'b0;
            done <= 1'b0;
            out_valid <= 1'b0;
            out_index <= 0;
            out_data <= 0;
            out_error_bound <= 0;
        end else begin
            done <= 1'b0;
            out_valid <= 1'b0;
            if (state == S_IDLE) begin
                if (start) begin
                    state <= S_RUN;
                    busy <= 1'b1;
                    win_index <= 0;
                end
            end else begin
                frame_total = frame_count;
                kernel_total = kernel_size;
                sum_tmp = 0;
                bound_tmp = 0;
                if (frame_total >= kernel_total && win_index <= frame_total-kernel_total) begin
                    if (mode == 0) begin
                        for (k = 0; k < MAX_KERNEL; k = k + 1) begin
                            if (k < kernel_total) begin
                                for (c = 0; c < CHANNELS; c = c + 1) begin
                                    sample = $signed(feature_flat[((win_index+k)*CHANNELS+c)*8 +: 8]);
                                    weight = $signed(weight_flat[(k*CHANNELS+c)*8 +: 8]);
                                    sum_tmp = sum_tmp + sample * weight;
                                end
                            end
                        end
                    end else begin
                        for (s = 0; s < MAX_SEGMENTS; s = s + 1) begin
                            if (s < segment_count) begin
                                seg_start = segment_start_flat[s*FRAME_W +: FRAME_W];
                                seg_end = seg_start + segment_len_flat[s*LEN_W +: LEN_W];
                                left = (seg_start > win_index) ? seg_start : win_index;
                                right = (seg_end < win_index+kernel_total) ? seg_end : win_index+kernel_total;
                                if (left < right) begin
                                    rel_left = left - win_index;
                                    rel_right = right - win_index;
                                    for (c = 0; c < CHANNELS; c = c + 1) begin
                                        p_lo = $signed(prefix_flat[(rel_left*CHANNELS+c)*PREFIX_W +: PREFIX_W]);
                                        p_hi = $signed(prefix_flat[(rel_right*CHANNELS+c)*PREFIX_W +: PREFIX_W]);
                                        rep = $signed(segment_value_flat[(s*CHANNELS+c)*8 +: 8]);
                                        sum_tmp = sum_tmp + rep * (p_hi - p_lo);
                                        if (mode == 2) begin
                                            dev = segment_dev_flat[(s*CHANNELS+c)*8 +: 8];
                                            for (k = rel_left; k < rel_right; k = k + 1) begin
                                                weight = $signed(weight_flat[(k*CHANNELS+c)*8 +: 8]);
                                                abs_weight = (weight < 0) ? -weight : weight;
                                                bound_tmp = bound_tmp + dev * abs_weight;
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                    out_index <= win_index;
                    out_data <= sum_tmp;
                    out_error_bound <= bound_tmp;
                    out_valid <= 1'b1;
                    if (win_index == frame_total-kernel_total) begin
                        state <= S_IDLE;
                        busy <= 1'b0;
                        done <= 1'b1;
                    end else begin
                        win_index <= win_index + 1;
                    end
                end else begin
                    state <= S_IDLE;
                    busy <= 1'b0;
                    done <= 1'b1;
                end
            end
        end
    end
endmodule
