//============================================================================
// mac_unit.v — Single Multiply-Accumulate Unit for Temporal Convolution
//
// Performs: acc += a * b (signed 8-bit inputs, 32-bit accumulator)
// Pipeline: 2 stages (multiply → accumulate)
// Reset clears accumulator.
//============================================================================
module mac_unit (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        clear,      // synchronous clear accumulator
    input  wire        valid_i,    // input data valid
    input  wire signed [7:0] a,    // feature value (INT8)
    input  wire signed [7:0] b,    // weight value (INT8)
    output reg  signed [31:0] acc, // accumulated result
    output reg         valid_o     // result valid (1 cycle after last valid_i)
);

    // Stage 1: multiply
    reg signed [15:0] mult_r;
    reg               mult_valid;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mult_r     <= 16'd0;
            mult_valid <= 1'b0;
        end else begin
            mult_r     <= a * b;
            mult_valid <= valid_i;
        end
    end

    // Stage 2: accumulate
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            acc     <= 32'd0;
            valid_o <= 1'b0;
        end else if (clear) begin
            acc     <= 32'd0;
            valid_o <= 1'b0;
        end else begin
            if (mult_valid)
                acc <= acc + {{16{mult_r[15]}}, mult_r};  // sign-extend and add
            valid_o <= mult_valid & ~valid_i;  // pulse when stream ends
        end
    end

endmodule
