`timescale 1ns/1ps

// Innovation-kernel integration top.
// This simple control surface is intended for RTL simulation and AXI-Lite wrapping.
// Existing temporal_conv_top remains unchanged for backward compatibility.
module duration_conv_top #(
    parameter CHANNELS = 4,
    parameter MAX_FRAMES = 16,
    parameter MAX_KERNEL = 8,
    parameter MAX_SEGMENTS = MAX_FRAMES,
    parameter MAX_SEGMENT_LENGTH = MAX_FRAMES,
    parameter PREFIX_W = 16,
    parameter FRAME_W = (MAX_FRAMES <= 2) ? 1 : $clog2(MAX_FRAMES),
    parameter LEN_W = (MAX_SEGMENT_LENGTH <= 1) ? 1 : $clog2(MAX_SEGMENT_LENGTH + 1),
    parameter COUNT_W = $clog2(MAX_FRAMES + 1),
    parameter WEIGHT_ADDR_W = $clog2(CHANNELS*MAX_KERNEL)
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         start,
    input  wire [1:0]                   mode,
    input  wire [3:0]                   kernel_size,
    input  wire [CHANNELS*8-1:0]        thresholds,
    input  wire                         frame_valid,
    input  wire                         frame_last,
    input  wire [CHANNELS*8-1:0]        frame_data,
    input  wire                         weight_we,
    input  wire [WEIGHT_ADDR_W-1:0]     weight_index,
    input  wire signed [7:0]            weight_data,
    output wire                         busy,
    output wire                         done,
    output wire                         out_valid,
    output wire [FRAME_W-1:0]           out_index,
    output wire signed [63:0]           out_data,
    output wire [63:0]                  out_error_bound
);
    reg [CHANNELS*MAX_KERNEL*8-1:0] weight_flat;
    wire [COUNT_W-1:0] frame_count;
    wire [COUNT_W-1:0] segment_count;
    wire [FRAME_W*MAX_SEGMENTS-1:0] segment_start_flat;
    wire [LEN_W*MAX_SEGMENTS-1:0] segment_len_flat;
    wire [CHANNELS*8*MAX_SEGMENTS-1:0] segment_value_flat;
    wire [CHANNELS*8*MAX_SEGMENTS-1:0] segment_dev_flat;
    wire [CHANNELS*8*MAX_FRAMES-1:0] feature_flat;
    wire encoder_busy;
    wire encoder_done;
    reg frame_done_d;
    wire conv_busy;
    wire conv_done;
    wire signed [CHANNELS*(MAX_KERNEL+1)*PREFIX_W-1:0] prefix_flat;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            weight_flat <= 0;
            frame_done_d <= 1'b0;
        end else begin
            frame_done_d <= encoder_done;
            if (weight_we)
                weight_flat[weight_index*8 +: 8] <= weight_data;
        end
    end

    duration_segment_encoder #(
        .CHANNELS(CHANNELS), .MAX_FRAMES(MAX_FRAMES), .MAX_SEGMENTS(MAX_SEGMENTS),
        .MAX_SEGMENT_LENGTH(MAX_SEGMENT_LENGTH), .FRAME_W(FRAME_W), .LEN_W(LEN_W), .COUNT_W(COUNT_W)
    ) u_segment_encoder (
        .clk(clk), .rst_n(rst_n), .clear(start), .frame_valid(frame_valid), .frame_last(frame_last),
        .frame_data(frame_data), .thresholds(thresholds), .frame_count(frame_count), .segment_count(segment_count),
        .segment_start_flat(segment_start_flat), .segment_len_flat(segment_len_flat),
        .segment_value_flat(segment_value_flat), .segment_dev_flat(segment_dev_flat),
        .feature_flat(feature_flat), .busy(encoder_busy), .done(encoder_done)
    );

    duration_prefix_weights #(.CHANNELS(CHANNELS), .MAX_KERNEL(MAX_KERNEL), .PREFIX_W(PREFIX_W)) u_prefix (
        .weight_flat(weight_flat), .prefix_flat(prefix_flat)
    );

    duration_overlap_conv #(
        .CHANNELS(CHANNELS), .MAX_FRAMES(MAX_FRAMES), .MAX_KERNEL(MAX_KERNEL),
        .MAX_SEGMENTS(MAX_SEGMENTS), .FRAME_W(FRAME_W), .LEN_W(LEN_W), .COUNT_W(COUNT_W), .PREFIX_W(PREFIX_W)
    ) u_overlap_conv (
        .clk(clk), .rst_n(rst_n), .start(frame_done_d), .mode(mode), .frame_count(frame_count),
        .segment_count(segment_count), .segment_start_flat(segment_start_flat), .segment_len_flat(segment_len_flat),
        .segment_value_flat(segment_value_flat), .segment_dev_flat(segment_dev_flat), .feature_flat(feature_flat),
        .weight_flat(weight_flat), .prefix_flat(prefix_flat), .kernel_size(kernel_size), .busy(conv_busy),
        .done(conv_done), .out_valid(out_valid), .out_index(out_index), .out_data(out_data),
        .out_error_bound(out_error_bound)
    );

    assign busy = encoder_busy | conv_busy;
    assign done = conv_done;
endmodule
