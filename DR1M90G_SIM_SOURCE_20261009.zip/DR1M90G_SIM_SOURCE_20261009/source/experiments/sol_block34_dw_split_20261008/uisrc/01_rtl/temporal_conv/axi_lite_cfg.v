//============================================================================
// axi_lite_cfg.v — Based on Anlogic official axi_lite_reg (verbatim state machine)
// with our custom register map for temporal convolution accelerator.
//============================================================================
`timescale 1 ns / 1 ps

module axi_lite_cfg #(
    parameter ADDR_WIDTH = 6
)(
    input wire  aclk,
    input wire  aresetn,
    input wire [ADDR_WIDTH-1 : 0] s_awaddr,
    input wire  s_awvalid,
    output wire  s_awready,
    input wire [31 : 0] s_wdata,
    input wire [3 : 0] s_wstrb,
    input wire  s_wvalid,
    output wire  s_wready,
    output wire [1 : 0] s_bresp,
    output wire  s_bvalid,
    input wire  s_bready,
    input wire [ADDR_WIDTH-1 : 0] s_araddr,
    input wire  s_arvalid,
    output wire  s_arready,
    output wire [31 : 0] s_rdata,
    output wire [1 : 0] s_rresp,
    output wire  s_rvalid,
    input wire  s_rready,

    // Config outputs
    output reg         cfg_start,
    output reg  [31:0] cfg_feat_addr,
    output reg  [31:0] cfg_out_addr,
    output reg  [7:0]  cfg_num_frames,
    output reg  [8:0]  cfg_feat_dim,
    output reg  [3:0]  cfg_kernel_size,
    output reg  [7:0]  cfg_num_filters,
    output reg  [3:0]  cfg_pool_shift,

    // Status inputs
    input  wire        sts_busy,
    input  wire        sts_done,

    // Weight BRAM write
    output reg         weight_wr_en,
    output reg  [12:0] weight_wr_addr,
    output reg  [31:0] weight_wr_data,

    // Interrupt
    output wire        irq_out
);

    // AXI4LITE signals
    reg [ADDR_WIDTH-1 : 0] axi_awaddr;
    reg        axi_awready;
    reg        axi_wready;
    reg [1:0]  axi_bresp;
    reg        axi_bvalid;
    reg [ADDR_WIDTH-1 : 0] axi_araddr;
    reg        axi_arready;
    reg [31:0] axi_rdata;
    reg [1:0]  axi_rresp;
    reg        axi_rvalid;

    // IRQ
    reg        irq_status;
    reg        irq_enable;
    reg        done_prev;

    assign s_awready = axi_awready;
    assign s_wready  = axi_wready;
    assign s_bresp   = axi_bresp;
    assign s_bvalid  = axi_bvalid;
    assign s_arready = axi_arready;
    assign s_rresp   = axi_rresp;
    assign s_rvalid  = axi_rvalid;
    assign irq_out   = irq_status & irq_enable;

    // State machine (verbatim from Anlogic axi_lite_reg)
    reg [1:0] state_write;
    reg [1:0] state_read;
    localparam Idle = 2'b00, Raddr = 2'b10, Rdata = 2'b11, Waddr = 2'b10, Wdata = 2'b11;

    // ================================================================
    // Write state machine (exact copy of official pattern)
    // ================================================================
    always @(posedge aclk) begin
        if (aresetn == 1'b0) begin
            axi_awready <= 0;
            axi_wready <= 0;
            axi_bvalid <= 0;
            axi_bresp <= 0;
            axi_awaddr <= 0;
            state_write <= Idle;
        end else begin
            case(state_write)
                Idle: begin
                    if(aresetn == 1'b1) begin
                        axi_awready <= 1'b1;
                        axi_wready <= 1'b1;
                        state_write <= Waddr;
                    end else
                        state_write <= state_write;
                end
                Waddr: begin
                    if (s_awvalid && axi_awready) begin
                        axi_awaddr <= s_awaddr;
                        if(s_wvalid) begin
                            axi_awready <= 1'b1;
                            state_write <= Waddr;
                            axi_bvalid <= 1'b1;
                        end else begin
                            axi_awready <= 1'b0;
                            state_write <= Wdata;
                            if (s_bready && axi_bvalid) axi_bvalid <= 1'b0;
                        end
                    end else begin
                        state_write <= state_write;
                        if (s_bready && axi_bvalid) axi_bvalid <= 1'b0;
                    end
                end
                Wdata: begin
                    if (s_wvalid) begin
                        state_write <= Waddr;
                        axi_bvalid <= 1'b1;
                        axi_awready <= 1'b1;
                    end else begin
                        state_write <= state_write;
                        if (s_bready && axi_bvalid) axi_bvalid <= 1'b0;
                    end
                end
            endcase
        end
    end

    // ================================================================
    // Register write logic (triggered on s_wvalid, same as official)
    // ================================================================
    localparam ADDR_LSB = 2;

    always @(posedge aclk) begin
        if (aresetn == 1'b0) begin
            cfg_start       <= 1'b0;
            cfg_feat_addr   <= 32'd0;
            cfg_out_addr    <= 32'd0;
            cfg_num_frames  <= 8'd16;
            cfg_feat_dim    <= 9'd256;
            cfg_kernel_size <= 4'd5;
            cfg_num_filters <= 8'd64;
            cfg_pool_shift  <= 4'd0;
            weight_wr_en    <= 1'b0;
            weight_wr_addr  <= 13'd0;
            weight_wr_data  <= 32'd0;
            irq_enable      <= 1'b0;
            irq_status      <= 1'b0;
            done_prev       <= 1'b0;
        end else begin
            // Defaults
            cfg_start    <= 1'b0;
            weight_wr_en <= 1'b0;

            // IRQ edge detect
            done_prev <= sts_done;
            if (sts_done && !done_prev)
                irq_status <= 1'b1;

            // Write data capture (same pattern as official: use awaddr if awvalid, else latched)
            if (s_wvalid) begin
                case ((s_awvalid) ? s_awaddr[ADDR_WIDTH-1:ADDR_LSB] : axi_awaddr[ADDR_WIDTH-1:ADDR_LSB])
                    4'h0: begin // CTRL (offset 0x00)
                        if (s_wstrb[0] && s_wdata[0]) cfg_start <= 1'b1;
                    end
                    4'h1: begin // FEAT_ADDR (offset 0x04)
                        cfg_feat_addr <= s_wdata;
                    end
                    4'h2: begin // OUT_ADDR (offset 0x08)
                        cfg_out_addr <= s_wdata;
                    end
                    4'h3: begin // NUM_FRAMES (offset 0x0C)
                        cfg_num_frames <= s_wdata[7:0];
                    end
                    4'h4: begin // FEAT_DIM (offset 0x10)
                        cfg_feat_dim <= s_wdata[8:0];
                    end
                    4'h5: begin // KERNEL_SIZE (offset 0x14)
                        cfg_kernel_size <= s_wdata[3:0];
                    end
                    4'h6: begin // NUM_FILTERS (offset 0x18)
                        cfg_num_filters <= s_wdata[7:0];
                    end
                    4'h7: begin // POOL_SHIFT (offset 0x1C)
                        cfg_pool_shift <= s_wdata[3:0];
                    end
                    4'h8: begin // WEIGHT_WR (offset 0x20)
                        weight_wr_en   <= 1'b1;
                        weight_wr_data <= s_wdata;
                        weight_wr_addr <= weight_wr_addr + 1'b1;
                    end
                    4'h9: begin // WEIGHT_ADDR (offset 0x24)
                        weight_wr_addr <= s_wdata[12:0];
                    end
                    4'hB: begin // IRQ_CLEAR (offset 0x2C)
                        if (s_wstrb[0] && s_wdata[0]) irq_status <= 1'b0;
                    end
                    4'hC: begin // IRQ_ENABLE (offset 0x30)
                        irq_enable <= s_wdata[0];
                    end
                    default: ;
                endcase
            end
        end
    end

    // ================================================================
    // Read state machine (exact copy of official pattern)
    // ================================================================
    always @(posedge aclk) begin
        if (aresetn == 1'b0) begin
            axi_arready <= 1'b0;
            axi_rvalid <= 1'b0;
            axi_rresp <= 2'b0;
            state_read <= Idle;
        end else begin
            case(state_read)
                Idle: begin
                    if (aresetn == 1'b1) begin
                        state_read <= Raddr;
                        axi_arready <= 1'b1;
                    end else
                        state_read <= state_read;
                end
                Raddr: begin
                    if (s_arvalid && axi_arready) begin
                        state_read <= Rdata;
                        axi_araddr <= s_araddr;
                        axi_rvalid <= 1'b1;
                        axi_arready <= 1'b0;
                    end else
                        state_read <= state_read;
                end
                Rdata: begin
                    if (s_rvalid && s_rready) begin
                        axi_rvalid <= 1'b0;
                        axi_arready <= 1'b1;
                        state_read <= Raddr;
                    end else
                        state_read <= state_read;
                end
            endcase
        end
    end

    // Read data mux (combinational, same as official)
    assign s_rdata =
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h0) ? {29'd0, sts_busy, sts_done, 1'b0} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h1) ? cfg_feat_addr :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h2) ? cfg_out_addr :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h3) ? {24'd0, cfg_num_frames} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h4) ? {23'd0, cfg_feat_dim} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h5) ? {28'd0, cfg_kernel_size} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h6) ? {24'd0, cfg_num_filters} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'h7) ? {28'd0, cfg_pool_shift} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'hA) ? {31'd0, irq_status} :
        (axi_araddr[ADDR_WIDTH-1:ADDR_LSB] == 4'hC) ? {31'd0, irq_enable} :
        32'hDEAD_BEEF;

endmodule
