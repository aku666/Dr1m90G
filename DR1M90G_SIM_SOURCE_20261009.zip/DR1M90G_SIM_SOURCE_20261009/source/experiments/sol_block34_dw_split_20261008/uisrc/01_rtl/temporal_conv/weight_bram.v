//============================================================================
// weight_bram.v — Dual-port BRAM for Convolution Kernel Weights
//
// Port A: AXI-Lite write (ARM loads weights)
// Port B: Read by ctrl_fsm during convolution
//
// Storage layout:
//   addr = filter_idx * KERNEL_SIZE * FEAT_DIM + k * FEAT_DIM + d
//   Each entry is 8-bit signed (INT8)
//   Packed as NUM_PE bytes per word (128-bit = 16 × 8-bit)
//
// Total capacity: NUM_FILTERS * KERNEL_SIZE * FEAT_DIM bytes
//   Default: 64 * 5 * 256 = 81920 bytes = 80 KB
//   Stored as 16-byte words: 5120 entries → needs ~5K × 128-bit BRAM
//============================================================================
module weight_bram #(
    parameter ADDR_WIDTH = 13,   // 2^13 = 8192 entries (enough for 80KB/16)
    parameter DATA_WIDTH = 128   // 16 bytes packed (NUM_PE=16 weights)
)(
    input  wire                    clk,
    // Port A — write (from AXI-Lite config)
    input  wire                    wr_en_a,
    input  wire [ADDR_WIDTH-1:0]   addr_a,
    input  wire [DATA_WIDTH-1:0]   din_a,
    // Port B — read (by compute engine)
    input  wire [ADDR_WIDTH-1:0]   addr_b,
    output reg  [DATA_WIDTH-1:0]   dout_b
);

    (* ram_style = "block" *)
    reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

    // Port A: write-only
    always @(posedge clk) begin
        if (wr_en_a)
            mem[addr_a] <= din_a;
    end

    // Port B: read-only, 1-cycle latency
    always @(posedge clk) begin
        dout_b <= mem[addr_b];
    end

endmodule
