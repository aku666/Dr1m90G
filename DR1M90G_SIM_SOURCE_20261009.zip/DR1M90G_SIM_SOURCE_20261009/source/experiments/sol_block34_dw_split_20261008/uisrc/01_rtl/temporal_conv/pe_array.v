//============================================================================
// pe_array.v — Parallel Processing Element Array (NUM_PE MAC units)
//
// Each PE computes one output channel of the 1D temporal convolution.
// All PEs share the same feature input stream but use different weights.
//
// Parameters:
//   NUM_PE       — number of parallel PEs (output channels per pass)
//   KERNEL_SIZE  — temporal convolution kernel size (max)
//   FEAT_DIM     — input feature dimension per frame (max)
//============================================================================
module pe_array #(
    parameter NUM_PE      = 16,
    parameter KERNEL_SIZE = 8,
    parameter FEAT_DIM    = 256
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        clear_all,          // clear all accumulators
    input  wire        valid_i,            // feature×weight pair valid
    input  wire signed [7:0] feat_i,       // shared feature input
    input  wire signed [NUM_PE*8-1:0] weight_i, // packed weights for all PEs
    output wire signed [NUM_PE*32-1:0] acc_o,   // packed accumulators
    output wire [NUM_PE-1:0] valid_o       // per-PE done flags
);

    genvar g;
    generate
        for (g = 0; g < NUM_PE; g = g + 1) begin : PE_GEN
            mac_unit u_mac (
                .clk     (clk),
                .rst_n   (rst_n),
                .clear   (clear_all),
                .valid_i (valid_i),
                .a       (feat_i),
                .b       (weight_i[g*8 +: 8]),
                .acc     (acc_o[g*32 +: 32]),
                .valid_o (valid_o[g])
            );
        end
    endgenerate

endmodule
