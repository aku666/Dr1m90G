//============================================================================
// pool_unit.v — Global Average Pooling over temporal dimension
//
// Accumulates NUM_FILTERS × 32-bit values over KERNEL_GROUPS passes,
// then divides by the number of passes to produce the final output.
//
// For simplicity, division is implemented as right-shift (assumes
// power-of-2 number of accumulation passes, or accept truncation).
//============================================================================
module pool_unit #(
    parameter NUM_PE = 16
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        clear,
    input  wire        acc_valid,                    // pulse: new PE results ready
    input  wire signed [NUM_PE*32-1:0] acc_in,      // from pe_array
    input  wire [3:0]  shift_amt,                   // right-shift for averaging (log2 of count)
    output reg  signed [NUM_PE*32-1:0] pool_out,    // pooled results
    output reg         pool_valid                   // pulse when pooling done
);

    reg signed [NUM_PE*32-1:0] sum_r;
    reg [7:0] count;
    reg        pool_done;

    integer i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sum_r      <= {(NUM_PE*32){1'b0}};
            count      <= 8'd0;
            pool_out   <= {(NUM_PE*32){1'b0}};
            pool_valid <= 1'b0;
            pool_done  <= 1'b0;
        end else if (clear) begin
            sum_r      <= {(NUM_PE*32){1'b0}};
            count      <= 8'd0;
            pool_out   <= {(NUM_PE*32){1'b0}};
            pool_valid <= 1'b0;
            pool_done  <= 1'b0;
        end else begin
            pool_valid <= 1'b0;
            if (acc_valid) begin
                for (i = 0; i < NUM_PE; i = i + 1) begin
                    sum_r[i*32 +: 32] <= sum_r[i*32 +: 32] + acc_in[i*32 +: 32];
                end
                count <= count + 1'b1;
                pool_done <= 1'b0;
            end else if (!pool_done && count > 0) begin
                // Apply shift and output once accumulation stops
                for (i = 0; i < NUM_PE; i = i + 1) begin
                    pool_out[i*32 +: 32] <= sum_r[i*32 +: 32] >>> shift_amt;
                end
                pool_valid <= 1'b1;
                pool_done  <= 1'b1;
            end
        end
    end

endmodule
