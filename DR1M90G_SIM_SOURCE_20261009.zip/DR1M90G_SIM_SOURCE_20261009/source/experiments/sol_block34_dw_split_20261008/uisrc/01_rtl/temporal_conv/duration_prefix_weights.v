`timescale 1ns/1ps

// Combinational prefix-weight generator.
// prefix[(q*CHANNELS+c)] = sum(weight[0:q][c]).
module duration_prefix_weights #(
    parameter CHANNELS = 4,
    parameter MAX_KERNEL = 8,
    parameter PREFIX_W = 16
) (
    input  wire [CHANNELS*MAX_KERNEL*8-1:0] weight_flat,
    output reg  signed [CHANNELS*(MAX_KERNEL+1)*PREFIX_W-1:0] prefix_flat
);
    integer c;
    integer k;
    integer acc;
    always @(*) begin
        prefix_flat = 0;
        for (c = 0; c < CHANNELS; c = c + 1) begin
            acc = 0;
            prefix_flat[(c)*PREFIX_W +: PREFIX_W] = 0;
            for (k = 0; k < MAX_KERNEL; k = k + 1) begin
                acc = acc + $signed(weight_flat[(k*CHANNELS+c)*8 +: 8]);
                prefix_flat[((k+1)*CHANNELS+c)*PREFIX_W +: PREFIX_W] = acc;
            end
        end
    end
endmodule
