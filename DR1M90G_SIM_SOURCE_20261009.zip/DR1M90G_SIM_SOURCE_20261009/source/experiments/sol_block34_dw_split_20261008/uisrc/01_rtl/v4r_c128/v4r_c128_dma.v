// Fixed C128 job: input2048, parameter49664 (weight49152+bias512), output49152.
// HP0 uses AXI3 4-bit ARLEN: at most16 read beats.
// All bases64-aligned. Bursts split at4KiB. Final B precedes job completion.
module v4r_c128_dma #(parameter OUTPUT_GROUP=128)(
 input wire clk,resetn,start,input wire [63:0] budget,
 input wire [31:0] input_base,parameter_base,output_base,
 output wire busy,output reg done,fault,
 output wire [31:0] araddr,output wire [7:0] arlen,
 output wire [2:0] arsize,output wire [1:0] arburst,
 output wire arvalid,input wire arready,
 input wire [63:0] rdata,input wire [1:0] rresp,
 input wire rlast,rvalid,output wire rready,
 output wire [31:0] awaddr,output wire [7:0] awlen,
 output wire [2:0] awsize,output wire [1:0] awburst,
 output wire awvalid,input wire awready,
 output wire [63:0] wdata,output wire [7:0] wstrb,
 output wire wlast,wvalid,input wire wready,
 input wire [1:0] bresp,input wire bvalid,output wire bready,
 output wire [31:0] core_cycles,base_products,interval_products,
 output wire [31:0] residual_products,skipped_products,residual_reads
);
 localparam IDLE=0,READ_AR=1,READ_R=2,LOAD=3,KICK=4,WAIT_OUT=5,
  WRITE_AW=6,WRITE_W=7,WRITE_B=8,DRAIN_R=9,FAILED=10;
 reg [3:0] state;
 reg phase;
 reg [31:0] ib,pb,ob;
 reg [63:0] budget_q,read_data;
 reg [12:0] read_beat;
 reg [6:0] read_left;
 reg [2:0] byte_index;
 reg [1:0] write_beat,write_end;
 reg [10:0] record;
 // OC16 emits a complete time window for one output group at a time. Keep
 // the external T16/C128 tensor layout and check that exact emission order.
 wire [10:0] record_index=OUTPUT_GROUP==16 ? {record[7:4],record[10:8],record[3:0]} : record;
 reg [63:0] record_data[0:2];
 wire core_busy,core_done,core_fault,core_valid;
 wire [10:0] core_index;
 wire signed [63:0] center,lower,upper;
 wire [63:0] certificate;
 wire [31:0] ra=(phase ? pb : ib)+read_beat*32'd8;
 wire [12:0] remaining=(phase ? 13'd6208 : 13'd256)-read_beat;
 wire [9:0] page_available=10'd512-{1'b0,ra[11:3]};
 wire [6:0] limited=remaining<16 ? remaining[6:0] : 7'd16;
 wire [6:0] read_count=page_available<limited ? page_available[6:0] : limited;
 wire [31:0] wa=ob+record_index*32'd24+write_beat*32'd8;
 wire [9:0] write_available=10'd512-{1'b0,wa[11:3]};
 wire [2:0] write_remaining=3-write_beat;
 wire [2:0] write_count=write_available<write_remaining ? write_available[2:0] : write_remaining;
 wire bias_load=phase && read_beat>=6144;
 wire [1:0] load_kind=!phase ? 2'd0 : bias_load ? 2'd2 : 2'd1;
 wire [15:0] load_address=bias_load ? (read_beat-6144)*2+byte_index : read_beat*8+byte_index;
 wire [31:0] load_value=bias_load ? read_data[byte_index*32+:32] : {24'b0,read_data[byte_index*8+:8]};
 v4r_c128_core #(.OUTPUT_GROUP(OUTPUT_GROUP)) core(.clk(clk),.rst_n(resetn),.start(state==KICK),.budget(budget_q),
  .load_we(state==LOAD),.load_kind(load_kind),.load_addr(load_address),.load_data(load_value),
  .busy(core_busy),.done(core_done),.fault(core_fault),.out_valid(core_valid),
  .out_ready(state==WAIT_OUT),.out_index(core_index),.out_center(center),
  .out_lower(lower),.out_upper(upper),.out_certificate(certificate),
  .active_cycles(core_cycles),.base_products(base_products),.interval_products(interval_products),
  .residual_products(residual_products),.skipped_products(skipped_products),
  .residual_sample_reads(residual_reads));
 assign busy=state!=IDLE;
 assign araddr=ra;assign arlen=read_count-1'b1;assign arsize=3;assign arburst=1;
 assign arvalid=state==READ_AR;assign rready=state==READ_R || state==DRAIN_R;
 assign awaddr=wa;assign awlen=write_count-1'b1;assign awsize=3;assign awburst=1;
 assign awvalid=state==WRITE_AW;
 assign wdata=record_data[write_beat];assign wstrb=8'hff;
 assign wlast=write_beat==write_end;assign wvalid=state==WRITE_W;assign bready=state==WRITE_B;
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;fault<=0;phase<=0;read_beat<=0;read_left<=0;
   byte_index<=0;record<=0;write_beat<=0;write_end<=0;
  end else case(state)
   IDLE: if(start) begin
    done<=0;fault<=0;budget_q<=budget;
    if((input_base[5:0]|parameter_base[5:0]|output_base[5:0])!=0) begin fault<=1;state<=FAILED;end
    else begin
     ib<=input_base;pb<=parameter_base;ob<=output_base;
     phase<=0;read_beat<=0;record<=0;state<=READ_AR;
    end
   end
   READ_AR: if(arready) begin read_left<=read_count;state<=READ_R;end
   READ_R: if(rvalid) begin
    if(rresp!=0 || rlast!=(read_left==1)) begin
     fault<=1;state<=rlast ? FAILED : DRAIN_R;
    end else begin
     read_data<=rdata;read_left<=read_left-1'b1;byte_index<=0;state<=LOAD;
    end
   end
   LOAD: begin
    if(byte_index==(bias_load ? 1 : 7)) begin
     byte_index<=0;
     if(!phase && read_beat==255) begin phase<=1;read_beat<=0;state<=READ_AR;end
     else if(phase && read_beat==6207) state<=KICK;
     else begin read_beat<=read_beat+1'b1;state<=read_left==0 ? READ_AR : READ_R;end
    end else byte_index<=byte_index+1'b1;
   end
   KICK: state<=WAIT_OUT;
   WAIT_OUT: begin
    if(core_fault) begin fault<=1;state<=FAILED;end
    else if(core_valid) begin
     if(core_index!=record_index) begin fault<=1;state<=FAILED;end
     else begin
      record_data[0]<=center;record_data[1]<=lower;record_data[2]<=upper;
      write_beat<=0;state<=WRITE_AW;
     end
    end
   end
   WRITE_AW: if(awready) begin write_end<=write_beat+write_count-1'b1;state<=WRITE_W;end
   WRITE_W: if(wready) begin
    if(write_beat==write_end) state<=WRITE_B;else write_beat<=write_beat+1'b1;
   end
   WRITE_B: if(bvalid) begin
    if(bresp!=0) begin fault<=1;state<=FAILED;end
    else if(write_beat!=2) begin write_beat<=write_beat+1'b1;state<=WRITE_AW;end
    else if(record==2047) begin
     if(!core_done) begin fault<=1;state<=FAILED;end
     else begin done<=1;state<=IDLE;end
    end else begin record<=record+1'b1;state<=WAIT_OUT;end
   end
   DRAIN_R: if(rvalid && rlast) state<=FAILED;
   FAILED: state<=FAILED;
   default: begin fault<=1;state<=FAILED;end
  endcase
 end
endmodule
