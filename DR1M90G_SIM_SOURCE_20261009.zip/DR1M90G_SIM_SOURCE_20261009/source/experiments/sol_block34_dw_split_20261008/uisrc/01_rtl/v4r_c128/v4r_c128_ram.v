// Fixed single write / synchronous read RAM. Explicit DR1 ERAM mapping.
module v4r_c128_ram #(parameter WIDTH=32,ADDR=15,DEPTH=18432)(
 input wire clk,we,input wire [ADDR-1:0] wa,ra,
 input wire [WIDTH-1:0] data,output wire [WIDTH-1:0] q);
`ifdef __ICARUS__
 reg [WIDTH-1:0] memory[0:DEPTH-1];reg [WIDTH-1:0] qr;
 always @(posedge clk) begin if(we) memory[wa]<=data;qr<=memory[ra];end
 assign q=qr;
`else
 DR1_LOGIC_ERAM #(.DATA_WIDTH_A(WIDTH),.DATA_WIDTH_B(WIDTH),
 .ADDR_WIDTH_A(ADDR),.ADDR_WIDTH_B(ADDR),.DATA_DEPTH_A(DEPTH),.DATA_DEPTH_B(DEPTH),
 .MODE("DP"),.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),.IMPLEMENT("20K(FAST)")) ram(
 .dia(data),.addra(wa),.cea(1'b1),.ocea(1'b1),.clka(clk),.wea(we),.rsta(1'b0),.bea(1'b1),
 .dib({WIDTH{1'b0}}),.addrb(ra),.ceb(1'b1),.oceb(1'b1),.clkb(clk),.web(1'b0),.rstb(1'b0),.beb(1'b1),
 .ecc_sbiterrinj(1'b0),.ecc_dbiterrinj(1'b0),.dob(q));
`endif
endmodule
