// GP and existing HP0 both use p2f_clk0 (80 MHz in the qualified bit).
// Addresses stay immutable until the final write response is acknowledged.
module net_pl_control #(parameter FRONT96=0,BLOCK34=0)(
    input wire aclk,rst_n,
    input wire cap_resetn,cap_done,cap_fault,input wire [7:0] cap_slot,cap_done_slot,
    input wire [31:0] cap_flags,cap_csi,cap_isp,cap_aw,cap_b,cap_rx,cap_valid,
    output reg cap_enable,disp_enable,
    input wire [31:0] S_AXI_AWADDR,input wire [2:0] S_AXI_AWPROT,
    input wire S_AXI_AWVALID,output wire S_AXI_AWREADY,
    input wire [31:0] S_AXI_WDATA,input wire [3:0] S_AXI_WSTRB,
    input wire S_AXI_WVALID,output wire S_AXI_WREADY,
    output reg [1:0] S_AXI_BRESP,output reg S_AXI_BVALID,input wire S_AXI_BREADY,
    input wire [31:0] S_AXI_ARADDR,input wire [2:0] S_AXI_ARPROT,
    input wire S_AXI_ARVALID,output wire S_AXI_ARREADY,
    output reg [31:0] S_AXI_RDATA,output reg [1:0] S_AXI_RRESP,
    output reg S_AXI_RVALID,input wire S_AXI_RREADY,
    output reg dma_start,output wire [31:0] dma_input,dma_parameter,dma_output,
    input wire dma_busy,dma_done,dma_fault,
    output reg v_start,output reg [1:0] owner,
    output wire [31:0] v_input,v_parameter,v_output,output wire [63:0] v_budget,
    input wire v_busy,v_done,v_fault,
    input wire [31:0] v_core_cycles,v_base_products,v_interval_products,
    input wire [31:0] v_residual_products,v_skipped_products,v_residual_reads,
    output reg f_start,output wire [31:0] f_input,f_parameter,f_output,
    input wire f_busy,f_done,f_fault,
    output reg [1:0] c_dw_mode,
    output reg c_start,output wire [31:0] c_input,c_expand,c_depthwise,c_project,c_scratch_expand,c_scratch_depthwise,c_output,
    input wire c_busy,c_done,c_fault
);
    wire [31:0] cap_status;
    fdma_frame_status_regs frame_status(.clk(aclk),.rst_n(rst_n && cap_resetn),.sync_slot(cap_slot),
      .done_irq(cap_done),.done_slot(cap_done_slot),.write_fault(cap_fault),
      .read_offset(S_AXI_ARADDR[5:0]),.read_data(cap_status));
    reg [31:0] ci,ce,cd,cp,cs,ct,co,c_cycles,c_last_cycles;
    reg c_pending,c_armed; reg [1:0] c_status;
    assign c_input=ci;assign c_expand=ce;assign c_depthwise=cd;assign c_project=cp;
    assign c_scratch_expand=cs;assign c_scratch_depthwise=ct;assign c_output=co;
    reg aw_pending,w_pending;
    reg [31:0] wa,wd;
    reg [3:0] ws;
    reg [31:0] cfg_input,cfg_parameter,cfg_output;
    reg pending,armed;
    reg v_pending,v_armed;
    reg [1:0] v_status;
    reg [31:0] vi,vp,vo,v_cycles,v_last_cycles;
    reg [63:0] vb;
    reg [31:0] fi,fp,fo,f_cycles,f_last_cycles;
    reg f_pending,f_armed;
    reg [1:0] f_status;
    assign f_input=fi;assign f_parameter=fp;assign f_output=fo;
    assign v_input=vi;assign v_parameter=vp;assign v_output=vo;assign v_budget=vb;
    reg [1:0] last_status;
    reg [31:0] last_cycles;
    reg [31:0] cycles;
    assign dma_input=cfg_input;
    assign dma_parameter=cfg_parameter;
    assign dma_output=cfg_output;
    assign S_AXI_AWREADY=!aw_pending && !S_AXI_BVALID;
    assign S_AXI_WREADY=!w_pending && !S_AXI_BVALID;
    assign S_AXI_ARREADY=!S_AXI_RVALID;
    always @(posedge aclk) begin
        if(!rst_n) begin
            disp_enable<=0;cap_enable<=0;aw_pending<=0;w_pending<=0;S_AXI_BVALID<=0;S_AXI_BRESP<=0;
            S_AXI_RVALID<=0;S_AXI_RRESP<=0;S_AXI_RDATA<=0;
            cfg_input<=0;cfg_parameter<=0;cfg_output<=0;
            dma_start<=0;pending<=0;armed<=0;cycles<=0;
            last_status<=0;last_cycles<=0;
            vi<=0;vp<=0;vo<=0;vb<=0;owner<=0;v_start<=0;
            v_pending<=0;v_armed<=0;v_status<=0;v_cycles<=0;v_last_cycles<=0;
            f_start<=0;fi<=0;fp<=0;fo<=0;f_cycles<=0;f_last_cycles<=0;
            f_pending<=0;f_armed<=0;f_status<=0;
            c_dw_mode<=0;c_start<=0;ci<=0;ce<=0;cd<=0;cp<=0;cs<=0;ct<=0;co<=0;c_cycles<=0;c_last_cycles<=0;c_pending<=0;c_armed<=0;c_status<=0;
        end else begin
            dma_start<=0;v_start<=0;f_start<=0;c_start<=0;
            if(c_pending && c_busy) begin c_armed<=1;c_cycles<=c_cycles+1'b1;end
            if(c_pending && c_armed && (c_done || c_fault)) begin
                c_pending<=0;c_armed<=0;c_status<={c_fault,c_done};c_last_cycles<=c_cycles;
            end
            if(f_pending && f_busy) begin f_armed<=1;f_cycles<=f_cycles+1'b1;end
            if(f_pending && f_armed && (f_done || f_fault)) begin
                f_pending<=0;f_armed<=0;f_status<={f_fault,f_done};f_last_cycles<=f_cycles;
            end
            if(v_pending && v_busy) begin v_armed<=1;v_cycles<=v_cycles+1'b1;end
            if(v_pending && v_armed && (v_done || v_fault)) begin
                v_pending<=0;v_armed<=0;v_status<={v_fault,v_done};v_last_cycles<=v_cycles;
            end
            if(pending && dma_busy) begin armed<=1;cycles<=cycles+1'b1;end
            if(pending && armed && (dma_done || dma_fault)) begin
                pending<=0;armed<=0;last_status<={dma_fault,dma_done};last_cycles<=cycles;
            end
            if(S_AXI_BVALID && S_AXI_BREADY) S_AXI_BVALID<=0;
            if(S_AXI_AWVALID && S_AXI_AWREADY) begin wa<=S_AXI_AWADDR;aw_pending<=1;end
            if(S_AXI_WVALID && S_AXI_WREADY) begin wd<=S_AXI_WDATA;ws<=S_AXI_WSTRB;w_pending<=1;end
            if(aw_pending && w_pending && !S_AXI_BVALID) begin
                aw_pending<=0;w_pending<=0;S_AXI_BVALID<=1;S_AXI_BRESP<=0;
                if(pending || v_pending || f_pending || c_pending || c_status[1] || last_status[1] || v_status[1] || f_status[1] || ws!=4'hf) S_AXI_BRESP<=2;
                else case(wa)
                    32'h160: if(wd<=1) disp_enable<=wd[0]; else S_AXI_BRESP<=2;
                    32'h140: if(wd<=1) cap_enable<=wd[0]; else S_AXI_BRESP<=2;
                    32'h0c: cfg_input<=wd;
                    32'h10: cfg_parameter<=wd;
                    32'h14: cfg_output<=wd;
                    32'h18: if(wd==1 && (cfg_input[5:0]|cfg_parameter[5:0]|cfg_output[5:0])==0) begin
                        dma_start<=1;owner<=0;pending<=1;armed<=0;cycles<=0;last_status<=0;last_cycles<=0;
                    end else S_AXI_BRESP<=2;
                    32'h2c: vi<=wd;
                    32'h30: vp<=wd;
                    32'h34: vo<=wd;
                    32'h3c: vb[31:0]<=wd;
                    32'h40: vb[63:32]<=wd;
                    32'h38: if(wd==1 && (vi[5:0]|vp[5:0]|vo[5:0])==0) begin
                        v_start<=1;owner<=1;v_pending<=1;v_armed<=0;
                        v_cycles<=0;v_last_cycles<=0;v_status<=0;
                    end else S_AXI_BRESP<=2;
                    32'h6c: fi<=wd;
                    32'h70: fp<=wd;
                    32'h74: fo<=wd;
                    32'h78: if(wd==1 && (fi[5:0]|fp[5:0]|fo[5:0])==0) begin
                        f_start<=1;owner<=2;f_pending<=1;f_armed<=0;
                        f_cycles<=0;f_last_cycles<=0;f_status<=0;
                    end else S_AXI_BRESP<=2;
                    32'hb0: if(wd<=2) c_dw_mode<=wd[1:0]; else S_AXI_BRESP<=2;
                    32'h8c: ci<=wd;
                    32'h90: ce<=wd;
                    32'h94: co<=wd;
                    32'ha0: cd<=wd;
                    32'ha4: cp<=wd;
                    32'ha8: cs<=wd;
                    32'hac: ct<=wd;
                    32'h98: if(wd==1 && (ci[5:0]|ce[5:0]|cd[5:0]|cp[5:0]|cs[5:0]|ct[5:0]|co[5:0])==0) begin
                        c_start<=1;owner<=3;c_pending<=1;c_armed<=0;c_cycles<=0;c_last_cycles<=0;c_status<=0;
                    end else S_AXI_BRESP<=2;
                    default: S_AXI_BRESP<=2;
                endcase
            end
            if(S_AXI_RVALID && S_AXI_RREADY) S_AXI_RVALID<=0;
            if(S_AXI_ARVALID && S_AXI_ARREADY) begin
                S_AXI_RVALID<=1;S_AXI_RRESP<=0;
                case(S_AXI_ARADDR)
                    32'h100: S_AXI_RDATA<=cap_status;
                    32'h104: S_AXI_RDATA<=32'h00010003;
                    32'h108: S_AXI_RDATA<=cap_status;
                    32'h10c: S_AXI_RDATA<=cap_status;
                    32'h110: S_AXI_RDATA<=cap_status;
                    32'h114: S_AXI_RDATA<=cap_status;
                    32'h118: S_AXI_RDATA<=cap_status;
                    32'h11c: S_AXI_RDATA<=cap_status;
                    32'h120: S_AXI_RDATA<=cap_status;
                    32'h124: S_AXI_RDATA<=cap_status;
                    32'h128: S_AXI_RDATA<=cap_status;
                    32'h12c: S_AXI_RDATA<=cap_status;
                    32'h130: S_AXI_RDATA<=cap_status;
                    32'h134: S_AXI_RDATA<=cap_status;
                    32'h160: S_AXI_RDATA<={31'b0,disp_enable};
                    32'h140: S_AXI_RDATA<={31'b0,cap_enable};
                    32'h144: S_AXI_RDATA<=cap_flags;
                    32'h148: S_AXI_RDATA<=cap_csi;
                    32'h14c: S_AXI_RDATA<=cap_isp;
                    32'h150: S_AXI_RDATA<=cap_aw;
                    32'h154: S_AXI_RDATA<=cap_b;
                    32'h158: S_AXI_RDATA<=cap_rx;
                    32'h15c: S_AXI_RDATA<=cap_valid;
                    32'h00: S_AXI_RDATA<=32'h44573136;
                    32'h04: S_AXI_RDATA<=32'h00010001;
                    32'h08: S_AXI_RDATA<={29'b0,last_status,pending};
                    32'h0c: S_AXI_RDATA<=cfg_input;
                    32'h10: S_AXI_RDATA<=cfg_parameter;
                    32'h14: S_AXI_RDATA<=cfg_output;
                    32'h18: S_AXI_RDATA<=32'h03c00707;
                    32'h1c: S_AXI_RDATA<=last_cycles;
                    32'h20: S_AXI_RDATA<=32'h56345232;
                    32'h24: S_AXI_RDATA<=32'h00020001;
                    32'h28: S_AXI_RDATA<={29'b0,v_status,v_pending};
                    32'h2c: S_AXI_RDATA<=vi;
                    32'h30: S_AXI_RDATA<=vp;
                    32'h34: S_AXI_RDATA<=vo;
                    32'h38: S_AXI_RDATA<=32'h10808003;
                    32'h3c: S_AXI_RDATA<=vb[31:0];
                    32'h40: S_AXI_RDATA<=vb[63:32];
                    32'h44: S_AXI_RDATA<=v_last_cycles;
                    32'h48: S_AXI_RDATA<=v_core_cycles;
                    32'h4c: S_AXI_RDATA<=v_base_products;
                    32'h50: S_AXI_RDATA<=v_interval_products;
                    32'h54: S_AXI_RDATA<=v_residual_products;
                    32'h58: S_AXI_RDATA<=v_skipped_products;
                    32'h5c: S_AXI_RDATA<=v_residual_reads;
                    32'h60: S_AXI_RDATA<=FRONT96?32'h46573936:32'h44573936;
                    32'h64: S_AXI_RDATA<=FRONT96?32'h00050001:32'h00030001;
                    32'h68: S_AXI_RDATA<={29'b0,f_status,f_pending};
                    32'h6c: S_AXI_RDATA<=fi;
                    32'h70: S_AXI_RDATA<=fp;
                    32'h74: S_AXI_RDATA<=fo;
                    32'h78: S_AXI_RDATA<=FRONT96?32'h00107070:32'h00607070;
                    32'h7c: S_AXI_RDATA<=f_last_cycles;
                    32'h80: S_AXI_RDATA<=BLOCK34?32'h424c4b34:32'h424c4b33;
                    32'h84: S_AXI_RDATA<=BLOCK34?32'h00060002:32'h00040001;
                    32'h88: S_AXI_RDATA<={29'b0,c_status,c_pending};
                    32'hb0: S_AXI_RDATA<={30'b0,c_dw_mode};
                    32'h8c: S_AXI_RDATA<=ci;
                    32'h90: S_AXI_RDATA<=ce;
                    32'h94: S_AXI_RDATA<=co;
                    32'h98: S_AXI_RDATA<=BLOCK34?32'h2090381c:32'h18903838;
                    32'h9c: S_AXI_RDATA<=c_last_cycles;
                    32'ha0: S_AXI_RDATA<=cd;
                    32'ha4: S_AXI_RDATA<=cp;
                    32'ha8: S_AXI_RDATA<=cs;
                    32'hac: S_AXI_RDATA<=ct;
                    default: begin S_AXI_RDATA<=0;S_AXI_RRESP<=2;end
                endcase
            end
        end
    end
endmodule
