// Fixed trained last TCN layer: T16/C128/O128/K3/dilation4, block4/group16.
// Input samples cached once per tile/channel group and reused for all taps.
// Immutable group bounds are replaced by exact residuals. Both interval ends
// commit together; each output independently stops within accumulator budget.
module v4r_c128_core #(parameter OUTPUT_GROUP=128)(
 input wire clk,rst_n,start,
 input wire [63:0] budget,
 input wire load_we,input wire [1:0] load_kind,
 input wire [15:0] load_addr,input wire [31:0] load_data,
 output reg busy,done,fault,
 output reg out_valid,input wire out_ready,
 output reg [10:0] out_index,
 output reg signed [63:0] out_center,out_lower,out_upper,
 output reg [63:0] out_certificate,
 output reg [31:0] active_cycles,base_products,interval_products,
 output reg [31:0] residual_products,skipped_products,residual_sample_reads
);
 localparam IDLE=0,SUM_BEGIN=1,SUM_SCAN=2,INIT=3,GROUP_BEGIN=4,
  GROUP_VALID=5,SUM_MAC=6,APPLY=7,NEXT_GROUP=8,CACHE=9,
  CHECK_PAIR=10,RES_MAC=11,NEXT_PAIR=12,EMIT=13,WAIT_OUT=14,RES_COMMIT=15;
 reg [3:0] state;
 // Only the current output group owns interval storage. Raw samples, weights
 // and immutable input summaries remain available for the whole C128 job.
 localparam OC_BITS=$clog2(OUTPUT_GROUP),PAIR_COUNT=16*OUTPUT_GROUP;
 localparam SAVED_ADDR=$clog2(6*8*3*OUTPUT_GROUP);
 localparam SAVED_DEPTH=OUTPUT_GROUP==128 ? 18432 : (1<<SAVED_ADDR);
 reg [2:0] output_group;
 reg phase;
 reg memory_ready;
 reg [2:0] tile;
 reg [2:0] group;
 reg [1:0] tap,row;
 reg [6:0] channel,oc;
 reg [3:0] c;
 reg [$clog2(PAIR_COUNT)-1:0] index;
 reg [63:0] budget_q;
 (* ram_style = "block" *) reg signed [7:0] raw[0:2047];

 (* ram_style = "block" *) reg signed [7:0] rep[0:767];
 (* ram_style = "block" *) reg signed [31:0] bias[0:127];
 (* ram_style = "block" *) reg signed [8:0] minimum[0:767];
 (* ram_style = "block" *) reg signed [8:0] maximum[0:767];
 reg signed [8:0] cache[0:63];


 (* ram_style = "block" *) reg signed [63:0] lower[0:PAIR_COUNT-1];
 (* ram_style = "block" *) reg signed [63:0] upper[0:PAIR_COUNT-1];
 reg signed [7:0] rep_q;
 reg signed [8:0] min_q,max_q;
 reg signed [63:0] acc_b,acc_l,acc_u,acc_exact;
 reg signed [63:0] base_q,lo_q,hi_q;

 function signed [7:0] sample;
  input integer t,ch;
  begin sample=(t<8 || t>=24) ? 8'sd0 : raw[(t-8)*128+ch];end
 endfunction
 wire [6:0] group_channel={group,c};
 // Consume the current RAM word while requesting the next MAC channel.
 wire mac_prefetch=busy && memory_ready && (state==SUM_MAC || state==RES_MAC) && c!=15;
 wire [3:0] read_c=mac_prefetch ? c+1'b1 : c;
 wire [6:0] read_channel={group,read_c};
 wire [15:0] summary_address=tile*128+read_channel;
 wire [15:0] group_address=((tile*8+group)*3+tap)*OUTPUT_GROUP+(oc&(OUTPUT_GROUP-1));
 wire [4:0] window_base=(tile-tap)*4;
 wire [$clog2(PAIR_COUNT)-1:0] pair_address=(window_base+row)*OUTPUT_GROUP+(oc&(OUTPUT_GROUP-1));
 wire signed [7:0] w;
 reg signed [7:0] raw_q,rep_read;
 reg signed [8:0] minimum_q,maximum_q;
 wire signed [31:0] immutable_l_q,immutable_u_q;
 reg signed [31:0] bias_q;
 reg signed [63:0] lower_q,upper_q;
 wire [$clog2(PAIR_COUNT)-1:0] interval_address=(state==EMIT || state==INIT) ? index : pair_address;
 wire [10:0] emit_index=(index/OUTPUT_GROUP)*128+output_group*OUTPUT_GROUP+(index&(OUTPUT_GROUP-1));
 wire [4:0] raw_time=tile*4+((state==SUM_BEGIN) ? 0 : row);
 wire [6:0] raw_channel=(state==SUM_BEGIN || state==SUM_SCAN) ? channel : group_channel;
 wire raw_padding=raw_time<8 || raw_time>=24;
 // Single synchronous read port per large memory infers embedded RAM.
 // An address-settle cycle precedes a state entry; MAC then streams one channel per clock.
 always @(posedge clk) begin

  raw_q<=raw[({raw_time,7'b0}+raw_channel-1024)&2047];
  rep_read<=rep[summary_address];
  minimum_q<=minimum[summary_address];maximum_q<=maximum[summary_address];

  lower_q<=lower[interval_address];upper_q<=upper[interval_address];
  bias_q<=bias[output_group*OUTPUT_GROUP+(index&(OUTPUT_GROUP-1))];
 end
 wire signed [7:0] current_sample=raw_padding ? 8'sd0 : raw_q;
 wire signed [15:0] base_product=rep_read*w;
 wire signed [16:0] lo_product=(w<0 ? maximum_q : minimum_q)*w;
 wire signed [16:0] hi_product=(w<0 ? minimum_q : maximum_q)*w;
 wire signed [16:0] residual_product=cache[row*16+c]*w;
 wire signed [63:0] final_exact=acc_exact+residual_product;
 wire [63:0] pair_width=upper_q-lower_q;
 wire [63:0] pair_error=(pair_width>>1)+pair_width[0];
 wire signed [7:0] scan_sample=current_sample;
 wire signed [8:0] scan_residual=$signed({scan_sample[7],scan_sample})-$signed({rep_q[7],rep_q});
 wire signed [8:0] min_next=scan_residual<min_q ? scan_residual : min_q;
 wire signed [8:0] max_next=scan_residual>max_q ? scan_residual : max_q;
 wire signed [7:0] cache_sample=current_sample;
 wire signed [8:0] cache_residual=$signed({cache_sample[7],cache_sample})-
                                  $signed({rep_read[7],rep_read});
 wire [63:0] emit_width=upper_q-lower_q;

 wire summary_write=busy && memory_ready && state==SUM_MAC && c==15;
 wire [15:0] weight_address=(oc*128+read_channel)*3+tap;
 v4r_c128_ram #(.WIDTH(8),.ADDR(16),.DEPTH(49152)) weights(
  .clk(clk),.we(load_we && !busy && load_kind==1 && load_addr<49152),
  .wa(load_addr),.data(load_data[7:0]),.ra(weight_address),.q(w));
 v4r_c128_ram #(.WIDTH(32),.ADDR(SAVED_ADDR),.DEPTH(SAVED_DEPTH)) saved_lower(
  .clk(clk),.we(summary_write),.wa(group_address[SAVED_ADDR-1:0]),
  .data(acc_l+lo_product),.ra(group_address[SAVED_ADDR-1:0]),.q(immutable_l_q));
 v4r_c128_ram #(.WIDTH(32),.ADDR(SAVED_ADDR),.DEPTH(SAVED_DEPTH)) saved_upper(
  .clk(clk),.we(summary_write),.wa(group_address[SAVED_ADDR-1:0]),
  .data(acc_u+hi_product),.ra(group_address[SAVED_ADDR-1:0]),.q(immutable_u_q));
 always @(posedge clk) begin
  if(load_we && !busy) case(load_kind)
   0: if(load_addr<2048) raw[load_addr]<=load_data[7:0];

   2: if(load_addr<128) bias[load_addr]<=load_data;
  endcase
 end
 always @(posedge clk) begin
  if(!rst_n) begin
   state<=IDLE;busy<=0;done<=0;fault<=0;out_valid<=0;memory_ready<=0;
   out_index<=0;out_center<=0;out_lower<=0;out_upper<=0;out_certificate<=0;
   active_cycles<=0;base_products<=0;interval_products<=0;
   residual_products<=0;skipped_products<=0;residual_sample_reads<=0;
   tile<=0;group<=0;tap<=0;row<=0;channel<=0;oc<=0;c<=0;index<=0;phase<=0;output_group<=0;
  end else begin
   if(busy) active_cycles<=active_cycles+1'b1;
   if(!busy || state==WAIT_OUT || memory_ready) begin
    memory_ready<=mac_prefetch;
   case(state)
    IDLE: if(start) begin
     busy<=1;done<=0;fault<=0;out_valid<=0;budget_q<=budget;
     active_cycles<=0;base_products<=0;interval_products<=0;
     residual_products<=0;skipped_products<=0;residual_sample_reads<=0;
     tile<=0;channel<=0;output_group<=0;state<=SUM_BEGIN;
    end
    SUM_BEGIN: begin
     rep_q<=current_sample;min_q<=0;max_q<=0;row<=1;state<=SUM_SCAN;
    end
    SUM_SCAN: begin
     min_q<=min_next;max_q<=max_next;
     if(row==3) begin
      rep[tile*128+channel]<=rep_q;
      minimum[tile*128+channel]<=min_next;maximum[tile*128+channel]<=max_next;
      if(channel==127) begin
       channel<=0;
       if(tile==5) begin index<=0;state<=INIT;end
       else begin tile<=tile+1'b1;state<=SUM_BEGIN;end
      end else begin channel<=channel+1'b1;state<=SUM_BEGIN;end
     end else row<=row+1'b1;
    end
    INIT: begin
     
     if(index==PAIR_COUNT-1) begin tile<=0;group<=0;tap<=0;phase<=0;state<=GROUP_BEGIN;end
     else index<=index+1'b1;
    end
    GROUP_BEGIN: begin
     oc<=output_group*OUTPUT_GROUP;row<=0;c<=0;acc_b<=0;acc_l<=0;acc_u<=0;
     // Cache 4x16 residuals per output group, then reuse across K3 overlaps.
     if(phase && tap==0) state<=CACHE;else state<=GROUP_VALID;
    end
    CACHE: begin
     cache[row*16+c]<=cache_residual;
     if(tile>=2) residual_sample_reads<=residual_sample_reads+1'b1;
     if(c==15) begin
      c<=0;
      if(row==3) begin row<=0;state<=GROUP_VALID;end
      else row<=row+1'b1;
     end else c<=c+1'b1;
    end
    GROUP_VALID: begin
     if(tile<tap || tile-tap>=4) state<=NEXT_GROUP;
     else if(phase) state<=CHECK_PAIR;
     else state<=SUM_MAC;
    end
    SUM_MAC: begin
     acc_b<=acc_b+base_product;acc_l<=acc_l+lo_product;acc_u<=acc_u+hi_product;
     base_products<=base_products+1'b1;interval_products<=interval_products+2;
     if(c==15) begin
      base_q<=acc_b+base_product;lo_q<=acc_l+lo_product;hi_q<=acc_u+hi_product;

      row<=0;state<=APPLY;
     end else c<=c+1'b1;
    end
    APPLY: begin
     
     if(row==3) begin
      if((oc&(OUTPUT_GROUP-1))==OUTPUT_GROUP-1) state<=NEXT_GROUP;
      else begin oc<=oc+1'b1;c<=0;row<=0;acc_b<=0;acc_l<=0;acc_u<=0;state<=SUM_MAC;end
     end else row<=row+1'b1;
    end
    NEXT_GROUP: begin
     state<=GROUP_BEGIN;
     if(tap!=2) tap<=tap+1'b1;
     else begin
      tap<=0;
      if(group!=7) group<=group+1'b1;
      else begin
       group<=0;
       if(tile!=5) tile<=tile+1'b1;
       else begin
        tile<=0;
        if(!phase) phase<=1;
        else begin index<=0;state<=EMIT;end
       end
      end
     end
    end
    CHECK_PAIR: begin
     if(pair_error<=budget_q) begin skipped_products<=skipped_products+16;state<=NEXT_PAIR;end
     else begin c<=0;acc_exact<=0;state<=RES_MAC;end
    end
    RES_MAC: begin
     acc_exact<=final_exact;residual_products<=residual_products+1'b1;
     if(c==15) begin
      // Complete the last multiply/accumulate before checking and replacing
      // the old interval. The pair address stays fixed until this commit.
      state<=RES_COMMIT;
     end else c<=c+1'b1;
    end
    RES_COMMIT: begin
      if(acc_exact<$signed(immutable_l_q) || acc_exact>$signed(immutable_u_q)) begin
       fault<=1;busy<=0;done<=1;state<=IDLE;
      end else begin
       // One atomic clock edge submits result and both certificate ends.
       state<=NEXT_PAIR;
      end
    end
    NEXT_PAIR: begin
     if(row!=3) begin row<=row+1'b1;state<=CHECK_PAIR;end
     else if((oc&(OUTPUT_GROUP-1))!=OUTPUT_GROUP-1) begin oc<=oc+1'b1;row<=0;state<=CHECK_PAIR;end
     else state<=NEXT_GROUP;
    end
    EMIT: begin
     if(((emit_width>>1)+emit_width[0])>budget_q || upper_q<lower_q) begin
      fault<=1;busy<=0;done<=1;state<=IDLE;
     end else begin
      out_index<=emit_index;out_center<=lower_q+$signed(emit_width>>1);
      out_lower<=lower_q;out_upper<=upper_q;
      out_certificate<=(emit_width>>1)+emit_width[0];out_valid<=1;state<=WAIT_OUT;
     end
    end
    WAIT_OUT: if(out_ready) begin
     out_valid<=0;
     if(index==PAIR_COUNT-1) begin
      if(output_group==128/OUTPUT_GROUP-1) begin busy<=0;done<=1;state<=IDLE;end
      else begin output_group<=output_group+1'b1;index<=0;state<=INIT;end
     end
     else begin index<=index+1'b1;state<=EMIT;end
    end
    default: begin fault<=1;busy<=0;done<=1;state<=IDLE;end
   endcase
   end else memory_ready<=1;
  end
 end
 // One address and one write-enable for each interval memory.
 wire interval_write=busy && memory_ready && (state==INIT || state==APPLY ||
   (state==RES_COMMIT && acc_exact>=$signed(immutable_l_q) && acc_exact<=$signed(immutable_u_q)));
 wire signed [63:0] next_lower=state==INIT ? $signed(bias_q) :
   state==APPLY ? lower_q+base_q+lo_q : lower_q+acc_exact-$signed(immutable_l_q);
 wire signed [63:0] next_upper=state==INIT ? $signed(bias_q) :
   state==APPLY ? upper_q+base_q+hi_q : upper_q+acc_exact-$signed(immutable_u_q);
 always @(posedge clk) if(interval_write) begin
  lower[interval_address]<=next_lower;upper[interval_address]<=next_upper;
 end
endmodule
