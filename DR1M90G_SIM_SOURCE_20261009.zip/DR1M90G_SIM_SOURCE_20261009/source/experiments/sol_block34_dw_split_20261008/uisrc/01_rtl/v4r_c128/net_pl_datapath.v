// Four fixed serial jobs share HP0; owner changes only on an idle START.
module net_pl_datapath #(parameter FRONT96=0,BLOCK34=0,V4R_OUTPUT_GROUP=128)(
input wire c_start,
input wire [1:0] c_dw_mode,
input wire [31:0] c_input,c_expand,c_depthwise,c_project,c_scratch_expand,c_scratch_depthwise,c_output,
output wire c_busy,c_done,c_fault,
input wire clk,resetn,start,v_start,f_start, input wire [1:0] owner,
input wire [31:0] input_base,parameter_base,output_base,v_input,v_parameter,v_output,
input wire [63:0] v_budget, input wire [31:0] f_input,f_parameter,f_output, output wire f_busy,f_done,f_fault,
output wire busy,done,fault,v_busy,v_done,v_fault,
output wire [31:0] v_core_cycles,v_base_products,v_interval_products,v_residual_products,v_skipped_products,v_residual_reads,
output wire [31:0] araddr,
output wire [7:0] arlen,
output wire [2:0] arsize,
output wire [1:0] arburst,
output wire arvalid,
input wire arready,
input wire [63:0] rdata,
input wire [1:0] rresp,
input wire rlast,
input wire rvalid,
output wire rready,
output wire [31:0] awaddr,
output wire [7:0] awlen,
output wire [2:0] awsize,
output wire [1:0] awburst,
output wire awvalid,
input wire awready,
output wire [63:0] wdata,
output wire [7:0] wstrb,
output wire wlast,
output wire wvalid,
input wire wready,
input wire [1:0] bresp,
input wire bvalid,
output wire bready
);
wire [31:0] c_araddr;
wire [7:0] c_arlen;
wire [2:0] c_arsize;
wire [1:0] c_arburst;
wire c_arvalid;
wire c_rready;
wire [31:0] c_awaddr;
wire [7:0] c_awlen;
wire [2:0] c_awsize;
wire [1:0] c_awburst;
wire c_awvalid;
wire [63:0] c_wdata;
wire [7:0] c_wstrb;
wire c_wlast;
wire c_wvalid;
wire c_bready;
 wire [31:0] f_araddr,f_awaddr;
 wire [7:0] f_arlen,f_awlen,f_wstrb;
 wire [2:0] f_arsize,f_awsize;
 wire [1:0] f_arburst,f_awburst;
 wire f_arvalid,f_rready,f_awvalid,f_wlast,f_wvalid,f_bready;
 wire [63:0] f_wdata;
 wire [31:0] d_araddr;
 wire [7:0] d_arlen;
 wire [2:0] d_arsize;
 wire [1:0] d_arburst;
 wire d_arvalid;
 wire d_rready;
 wire [31:0] d_awaddr;
 wire [7:0] d_awlen;
 wire [2:0] d_awsize;
 wire [1:0] d_awburst;
 wire d_awvalid;
 wire [63:0] d_wdata;
 wire [7:0] d_wstrb;
 wire d_wlast;
 wire d_wvalid;
 wire d_bready;
 wire [31:0] v_araddr;
 wire [7:0] v_arlen;
 wire [2:0] v_arsize;
 wire [1:0] v_arburst;
 wire v_arvalid;
 wire v_rready;
 wire [31:0] v_awaddr;
 wire [7:0] v_awlen;
 wire [2:0] v_awsize;
 wire [1:0] v_awburst;
 wire v_awvalid;
 wire [63:0] v_wdata;
 wire [7:0] v_wstrb;
 wire v_wlast;
 wire v_wvalid;
 wire v_bready;
dw16_axi_master dw(.clk(clk),.resetn(resetn),.start(start),.input_base(input_base),.parameter_base(parameter_base),.output_base(output_base),.busy(busy),.done(done),.fault(fault),
.araddr(d_araddr),
.arlen(d_arlen),
.arsize(d_arsize),
.arburst(d_arburst),
.arvalid(d_arvalid),
.arready(arready && owner==0),
.rdata(rdata),
.rresp(rresp),
.rlast(rlast),
.rvalid(rvalid && owner==0),
.rready(d_rready),
.awaddr(d_awaddr),
.awlen(d_awlen),
.awsize(d_awsize),
.awburst(d_awburst),
.awvalid(d_awvalid),
.awready(awready && owner==0),
.wdata(d_wdata),
.wstrb(d_wstrb),
.wlast(d_wlast),
.wvalid(d_wvalid),
.wready(wready && owner==0),
.bresp(bresp),
.bvalid(bvalid && owner==0),
.bready(d_bready));
v4r_c128_dma #(.OUTPUT_GROUP(V4R_OUTPUT_GROUP)) v4r(.clk(clk),.resetn(resetn),.start(v_start),.budget(v_budget),.input_base(v_input),.parameter_base(v_parameter),.output_base(v_output),.busy(v_busy),.done(v_done),.fault(v_fault),
.core_cycles(v_core_cycles),.base_products(v_base_products),.interval_products(v_interval_products),.residual_products(v_residual_products),.skipped_products(v_skipped_products),.residual_reads(v_residual_reads),
.araddr(v_araddr),
.arlen(v_arlen),
.arsize(v_arsize),
.arburst(v_arburst),
.arvalid(v_arvalid),
.arready(arready && owner==1),
.rdata(rdata),
.rresp(rresp),
.rlast(rlast),
.rvalid(rvalid && owner==1),
.rready(v_rready),
.awaddr(v_awaddr),
.awlen(v_awlen),
.awsize(v_awsize),
.awburst(v_awburst),
.awvalid(v_awvalid),
.awready(awready && owner==1),
.wdata(v_wdata),
.wstrb(v_wstrb),
.wlast(v_wlast),
.wvalid(v_wvalid),
.wready(wready && owner==1),
.bresp(bresp),
.bvalid(bvalid && owner==1),
.bready(v_bready));
generate if(FRONT96) begin: fused_front
front96_axi_master front(.clk(clk),.resetn(resetn),.start(f_start),
.input_base(f_input),.parameter_base(f_parameter),.output_base(f_output),
.busy(f_busy),.done(f_done),.fault(f_fault),
.araddr(f_araddr),.arlen(f_arlen),.arsize(f_arsize),.arburst(f_arburst),
.arvalid(f_arvalid),.arready(arready && owner==2),
.rdata(rdata),.rresp(rresp),.rlast(rlast),.rvalid(rvalid && owner==2),.rready(f_rready),
.awaddr(f_awaddr),.awlen(f_awlen),.awsize(f_awsize),.awburst(f_awburst),
.awvalid(f_awvalid),.awready(awready && owner==2),
.wdata(f_wdata),.wstrb(f_wstrb),.wlast(f_wlast),.wvalid(f_wvalid),.wready(wready && owner==2),
.bresp(bresp),.bvalid(bvalid && owner==2),.bready(f_bready));
end else begin: original_front
dw96_axi_master front(.clk(clk),.resetn(resetn),.start(f_start),
.input_base(f_input),.parameter_base(f_parameter),.output_base(f_output),
.busy(f_busy),.done(f_done),.fault(f_fault),
.araddr(f_araddr),.arlen(f_arlen),.arsize(f_arsize),.arburst(f_arburst),
.arvalid(f_arvalid),.arready(arready && owner==2),
.rdata(rdata),.rresp(rresp),.rlast(rlast),.rvalid(rvalid && owner==2),.rready(f_rready),
.awaddr(f_awaddr),.awlen(f_awlen),.awsize(f_awsize),.awburst(f_awburst),
.awvalid(f_awvalid),.awready(awready && owner==2),
.wdata(f_wdata),.wstrb(f_wstrb),.wlast(f_wlast),.wvalid(f_wvalid),.wready(wready && owner==2),
.bresp(bresp),.bvalid(bvalid && owner==2),.bready(f_bready));
end endgenerate
generate if(BLOCK34) begin: extended_block
block34_axi_chain block34(.clk(clk),.resetn(resetn),.start(c_start),.dw_only_mode(c_dw_mode),
.input_base(c_input),.expand_parameters(c_expand),.depthwise_parameters(c_depthwise),.project_parameters(c_project),
.scratch_expand(c_scratch_expand),.scratch_depthwise(c_scratch_depthwise),.output_base(c_output),
.busy(c_busy),.done(c_done),.fault(c_fault),
.araddr(c_araddr),.arlen(c_arlen),.arsize(c_arsize),.arburst(c_arburst),.arvalid(c_arvalid),.rready(c_rready),
.awaddr(c_awaddr),.awlen(c_awlen),.awsize(c_awsize),.awburst(c_awburst),.awvalid(c_awvalid),
.wdata(c_wdata),.wstrb(c_wstrb),.wlast(c_wlast),.wvalid(c_wvalid),.bready(c_bready),
.arready(arready && owner==3),.rvalid(rvalid && owner==3),.awready(awready && owner==3),
.wready(wready && owner==3),.bvalid(bvalid && owner==3),.rdata(rdata),.rresp(rresp),.rlast(rlast),.bresp(bresp));
end else begin: original_block
block3_axi_chain block3(.clk(clk),.resetn(resetn),.start(c_start),
.input_base(c_input),.expand_parameters(c_expand),.depthwise_parameters(c_depthwise),.project_parameters(c_project),
.scratch_expand(c_scratch_expand),.scratch_depthwise(c_scratch_depthwise),.output_base(c_output),
.busy(c_busy),.done(c_done),.fault(c_fault),
.araddr(c_araddr),
.arlen(c_arlen),
.arsize(c_arsize),
.arburst(c_arburst),
.arvalid(c_arvalid),
.rready(c_rready),
.awaddr(c_awaddr),
.awlen(c_awlen),
.awsize(c_awsize),
.awburst(c_awburst),
.awvalid(c_awvalid),
.wdata(c_wdata),
.wstrb(c_wstrb),
.wlast(c_wlast),
.wvalid(c_wvalid),
.bready(c_bready),
.arready(arready && owner==3),
.rvalid(rvalid && owner==3),
.awready(awready && owner==3),
.wready(wready && owner==3),
.bvalid(bvalid && owner==3),
.rdata(rdata),
.rresp(rresp),
.rlast(rlast),
.bresp(bresp));
end endgenerate
assign araddr=owner==3 ? c_araddr : owner==2 ? f_araddr : owner==1 ? v_araddr : d_araddr;
assign arlen=owner==3 ? c_arlen : owner==2 ? f_arlen : owner==1 ? v_arlen : d_arlen;
assign arsize=owner==3 ? c_arsize : owner==2 ? f_arsize : owner==1 ? v_arsize : d_arsize;
assign arburst=owner==3 ? c_arburst : owner==2 ? f_arburst : owner==1 ? v_arburst : d_arburst;
assign arvalid=owner==3 ? c_arvalid : owner==2 ? f_arvalid : owner==1 ? v_arvalid : d_arvalid;
assign rready=owner==3 ? c_rready : owner==2 ? f_rready : owner==1 ? v_rready : d_rready;
assign awaddr=owner==3 ? c_awaddr : owner==2 ? f_awaddr : owner==1 ? v_awaddr : d_awaddr;
assign awlen=owner==3 ? c_awlen : owner==2 ? f_awlen : owner==1 ? v_awlen : d_awlen;
assign awsize=owner==3 ? c_awsize : owner==2 ? f_awsize : owner==1 ? v_awsize : d_awsize;
assign awburst=owner==3 ? c_awburst : owner==2 ? f_awburst : owner==1 ? v_awburst : d_awburst;
assign awvalid=owner==3 ? c_awvalid : owner==2 ? f_awvalid : owner==1 ? v_awvalid : d_awvalid;
assign wdata=owner==3 ? c_wdata : owner==2 ? f_wdata : owner==1 ? v_wdata : d_wdata;
assign wstrb=owner==3 ? c_wstrb : owner==2 ? f_wstrb : owner==1 ? v_wstrb : d_wstrb;
assign wlast=owner==3 ? c_wlast : owner==2 ? f_wlast : owner==1 ? v_wlast : d_wlast;
assign wvalid=owner==3 ? c_wvalid : owner==2 ? f_wvalid : owner==1 ? v_wvalid : d_wvalid;
assign bready=owner==3 ? c_bready : owner==2 ? f_bready : owner==1 ? v_bready : d_bready;
endmodule
