// Fixed block3: C24->144 expansion or C144->24 projection plus residual.
// The DMA loader supplies one complete 56-pixel row and its immutable weights.
module pointwise34_row_core #(
 parameter ROW_WIDTH=56,EXPAND_INPUTS=24,EXPAND_OUTPUTS=144,
 parameter EXPAND_ZERO=106,EXPAND_ONLY=0,EXPAND_PIXEL_BITS=8,EXPAND_OUTPUT_ZERO=0,
 parameter MAC_LANES=32
)(
 input wire clk,resetn,start,project,block4,
 input wire input_write,input wire [12:0] input_address,input wire [63:0] input_data,
 input wire skip_write,input wire [10:0] skip_address,input wire [63:0] skip_data,
 input wire parameter_write,input wire [7:0] parameter_output,
 input wire [4:0] parameter_beat,input wire [63:0] parameter_data,
 output wire busy,output reg done,
 output wire out_valid,input wire out_ready,
 output wire [7:0] out_channel,output wire [$clog2(ROW_WIDTH)-1:0] out_column,output wire [7:0] out_data
);
 localparam IDLE=0,INIT=1,DOT=2,QPREP=3,QUANT=4;
 localparam LANE_BITS=$clog2(MAC_LANES);
 localparam EXPAND_GROUPS=(EXPAND_OUTPUTS+MAC_LANES-1)/MAC_LANES;
 localparam PROJECT_GROUPS=(32+MAC_LANES-1)/MAC_LANES;
 localparam PARAM_GROUPS=EXPAND_GROUPS>PROJECT_GROUPS?EXPAND_GROUPS:PROJECT_GROUPS;
 localparam WEIGHT_WORDS=EXPAND_GROUPS*EXPAND_INPUTS>PROJECT_GROUPS*144?
  EXPAND_GROUPS*EXPAND_INPUTS:PROJECT_GROUPS*144;
 reg [2:0] state;
 reg mode,fourth;
 reg [3:0] group_index;
 reg [$clog2(ROW_WIDTH)-1:0] column;
 reg [7:0] issue,consumed;
 reg product_valid;
 reg read_valid;
 reg signed [EXPAND_PIXEL_BITS:0] pixel_q;
 reg signed [8:0] weight_q[0:MAC_LANES-1];
 reg [LANE_BITS:0] qissued,qreceived,qaccepted;
 (* ram_style="distributed" *) reg [EXPAND_PIXEL_BITS-1:0] pixels[0:(EXPAND_ONLY?EXPAND_INPUTS:144)*ROW_WIDTH-1];
 (* ram_style="distributed" *) reg [7:0] skips[0:24*ROW_WIDTH-1];
 (* ram_style="distributed" *) reg [7:0] weights[0:MAC_LANES-1][0:WEIGHT_WORDS-1];
 (* ram_style="distributed" *) reg signed [31:0] biases[0:MAC_LANES-1][0:PARAM_GROUPS-1];
 (* ram_style="distributed" *) reg [31:0] multipliers[0:MAC_LANES-1][0:PARAM_GROUPS-1];
 reg signed [EXPAND_PIXEL_BITS+9:0] products[0:MAC_LANES-1];
 reg signed [39:0] accum[0:MAC_LANES-1];
 wire [7:0] channels=mode?144:EXPAND_INPUTS;
 wire [8:0] output_channels=mode?(fourth?32:24):EXPAND_OUTPUTS;
 wire [8:0] remaining_channels=output_channels-group_index*MAC_LANES;
 wire [LANE_BITS:0] lanes=remaining_channels<MAC_LANES?remaining_channels:MAC_LANES;
 wire signed [EXPAND_PIXEL_BITS:0] pixel=$signed({EXPAND_PIXEL_BITS==16 ? pixels[issue*ROW_WIDTH+column][EXPAND_PIXEL_BITS-1] : 1'b0,pixels[issue*ROW_WIDTH+column]})-(mode?0:fourth?124:EXPAND_ZERO);
 integer i,b,weight_position;
 always @(posedge clk) begin
  if(input_write) for(b=0;b<64/EXPAND_PIXEL_BITS;b=b+1) pixels[input_address+b]<=input_data[b*EXPAND_PIXEL_BITS+:EXPAND_PIXEL_BITS];
  if(skip_write) for(b=0;b<8;b=b+1) skips[skip_address+b]<=skip_data[b*8+:8];
  if(parameter_write) begin
   for(b=0;b<8;b=b+1) begin
    weight_position=parameter_beat*8+b;
    if(weight_position<((!EXPAND_ONLY && project)?144:EXPAND_INPUTS))
     weights[parameter_output[LANE_BITS-1:0]][(parameter_output>>LANE_BITS)*((!EXPAND_ONLY && project)?144:EXPAND_INPUTS)+weight_position]<=parameter_data[b*8+:8];
   end
   if(parameter_beat==18) begin
    biases[parameter_output[LANE_BITS-1:0]][parameter_output>>LANE_BITS]<=parameter_data[31:0];
    multipliers[parameter_output[LANE_BITS-1:0]][parameter_output>>LANE_BITS]<=parameter_data[63:32];
   end
  end
 end
 wire rqready,rqvalid,add_advance;
 wire [7:0] rqresult;
 wire [7:0] quant_zero=mode?(fourth?8'd133:8'd101):EXPAND_OUTPUT_ZERO;
 // Zero products reduce the existing validated patch core to its bias/M/RNE path.
 dw3x3_patch_core rounding(clk,resetn,state==QUANT && qissued<lanes,rqready,
  72'b0,{9{8'd128}},8'd0,8'd128,$signed(accum[qissued[LANE_BITS-1:0]][31:0]),
  multipliers[qissued[LANE_BITS-1:0]][group_index],5'd30,quant_zero,8'd0,8'd255,
  rqvalid,add_advance && state==QUANT,rqresult);
 // Register every residual stage. Global stall preserves data and channel tags.
 reg [5:0] add_valid;
 reg [$clog2(24*ROW_WIDTH)-1:0] skip_read_address;
 reg [7:0] add_channel[0:5], add_raw[0:5];
 reg signed [8:0] skip_delta,project_delta;
 reg signed [63:0] skip_product,project_product,add_sum,add_value;
 reg [7:0] add_result;
 assign add_advance=!add_valid[5] || out_ready;
 wire [7:0] accepted_channel=group_index*MAC_LANES+qaccepted;
 wire signed [63:0] add_floor=add_sum>>>30;
 wire [29:0] add_remainder=add_sum[29:0];
 wire signed [63:0] add_rounded=add_floor+
   ((add_remainder>30'd536870912)||((add_remainder==30'd536870912)&&add_floor[0]))+64'sd124;
 integer a;
 always @(posedge clk) begin
  if(!resetn) add_valid<=0;
  else if(add_advance) begin
   add_valid<={add_valid[4:0],rqvalid && state==QUANT};
   if(rqvalid && state==QUANT) begin
    skip_read_address<=mode ? accepted_channel*ROW_WIDTH+column : 0;
    add_channel[0]<=accepted_channel;add_raw[0]<=rqresult;
   end
   for(a=1;a<6;a=a+1) if(add_valid[a-1]) begin
    add_channel[a]<=add_channel[a-1];add_raw[a]<=add_raw[a-1];
   end
   if(add_valid[0]) begin
    skip_delta<=$signed({1'b0,skips[skip_read_address]})-9'sd106;
    project_delta<=$signed({1'b0,add_raw[0]})-9'sd101;
   end
   if(add_valid[1]) begin
    skip_product<=skip_delta*64'sd958620430;
    project_product<=project_delta*64'sd1114098186;
   end
   if(add_valid[2]) add_sum<=skip_product+project_product;
   if(add_valid[3]) add_value<=add_rounded;
   if(add_valid[4]) add_result<=add_value<0?8'd0:add_value>255?8'd255:add_value[7:0];
  end
 end
 assign out_data=mode && !fourth ? add_result : add_raw[5];
 assign out_valid=add_valid[5] && state==QUANT;
 assign out_channel=add_channel[5];
 assign out_column=column;
 assign busy=state!=IDLE;
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;mode<=0;fourth<=0;group_index<=0;column<=0;
   issue<=0;consumed<=0;read_valid<=0;product_valid<=0;qissued<=0;qreceived<=0;qaccepted<=0;
  end else case(state)
   IDLE: if(start) begin mode<=EXPAND_ONLY?1'b0:project;fourth<=block4;done<=0;group_index<=0;column<=0;state<=INIT;end
   INIT: begin
    for(i=0;i<MAC_LANES;i=i+1) accum[i]<={{8{biases[i][group_index][31]}},biases[i][group_index]};
    issue<=0;consumed<=0;read_valid<=0;product_valid<=0;state<=DOT;
   end
   DOT: begin
    if(product_valid) begin
     for(i=0;i<MAC_LANES;i=i+1) accum[i]<=accum[i]+products[i];
     consumed<=consumed+1'b1;
     if(consumed==channels-1'b1) state<=QPREP;
    end
    product_valid<=read_valid;
    if(read_valid) for(i=0;i<MAC_LANES;i=i+1) products[i]<=pixel_q*weight_q[i];
    read_valid<=issue<channels;
    if(issue<channels) begin
     pixel_q<=pixel;
     for(i=0;i<MAC_LANES;i=i+1)
      weight_q[i]<=$signed({1'b0,weights[i][group_index*(mode?32'd144:EXPAND_INPUTS)+issue]})-9'sd128;
     issue<=issue+1'b1;
    end
   end
   QPREP: begin qissued<=0;qreceived<=0;qaccepted<=0;state<=QUANT;end
   QUANT: begin
    if(rqready && qissued<lanes) qissued<=qissued+1'b1;
    if(rqvalid && add_advance) qaccepted<=qaccepted+1'b1;
    if(out_valid && out_ready) begin
     qreceived<=qreceived+1'b1;
     if(qreceived==lanes-1'b1) begin
      if(column<(mode && fourth?28:ROW_WIDTH)-1) begin column<=column+1'b1;state<=INIT;end
      else if((group_index+1)*MAC_LANES<output_channels) begin group_index<=group_index+1'b1;column<=0;state<=INIT;end
      else begin done<=1;state<=IDLE;end
     end
    end
   end
   default: state<=IDLE;
  endcase
 end
endmodule
