// Fixed NCHW width56 pointwise passes; owned scratch DDR connects the DW pass.
module pointwise34_axi_master(
 input wire clk,resetn,start,project,block4,
 input wire [31:0] input_base,parameter_base,output_base,skip_base,
 output wire busy,output reg done,fault,
 output wire [31:0] araddr,output wire [7:0] arlen,
 output wire [2:0] arsize,output wire [1:0] arburst,
 output wire arvalid,input wire arready,
 input wire [63:0] rdata,input wire [1:0] rresp,input wire rlast,rvalid,output wire rready,
 output wire [31:0] awaddr,output wire [7:0] awlen,
 output wire [2:0] awsize,output wire [1:0] awburst,
 output wire awvalid,input wire awready,
 output reg [63:0] wdata,output wire [7:0] wstrb,output wire wlast,wvalid,input wire wready,
 input wire [1:0] bresp,input wire bvalid,output wire bready
);
 localparam IDLE=0,P_AR=1,P_R=2,I_AR=3,I_R=4,S_AR=5,S_R=6,C_START=7,
  COMPUTE=8,O_AW=9,O_W=10,O_B=11,FAILED=12,O_PREP=13;
 reg [3:0] state;
 reg mode,fourth;
 reg [31:0] ib,pb,ob,sb;
 reg [7:0] parameter_channel,input_channel,output_channel;
 reg [5:0] row;
 reg [4:0] beat,burst_end;
 (* ram_style="distributed" *) reg [7:0] results[0:8063];
 wire [7:0] input_channels=mode?144:24,output_channels=mode?(fourth?32:24):144;
 // The 28-pixel projection uses 32-byte physical rows. It never issues an
 // unaligned 64-bit AXI beat or reads beyond an allocated scratch buffer.
 wire narrow=mode && fourth;
 wire [31:0] pitch=narrow?32:56,plane=narrow?896:3136;
 wire [5:0] row_beats=narrow?4:7;
 wire [31:0] read_address=state==P_AR ? pb+parameter_channel*32'd160+beat*32'd8 :
  (state==S_AR ? sb:ib)+input_channel*plane+row*pitch+beat*32'd8;
 wire [9:0] read_page=10'd512-{1'b0,read_address[11:3]};
 wire [5:0] read_remaining=(state==P_AR ? 6'd20:row_beats)-beat;
 wire [5:0] read_limit=read_remaining>16?6'd16:read_remaining;
 wire [4:0] read_count=read_page<read_limit?read_page[4:0]:read_limit[4:0];
 wire [31:0] write_address=ob+output_channel*plane+row*pitch+beat*32'd8;
 wire [9:0] write_page=10'd512-{1'b0,write_address[11:3]};
 wire [4:0] write_count=write_page<(row_beats-beat)?write_page[4:0]:row_beats-beat;
 wire core_busy,core_done,core_valid;
 wire [7:0] core_channel,core_data;
 wire [5:0] core_column;
 wire [12:0] input_index=input_channel*32'd56+beat*32'd8;
 wire [10:0] skip_index=input_channel*32'd56+beat*32'd8;
 pointwise34_row_core core(clk,resetn,state==C_START,mode,fourth,
  state==I_R && rvalid,input_index,rdata,state==S_R && rvalid,skip_index,rdata,
  state==P_R && rvalid,parameter_channel,beat,rdata,
  core_busy,core_done,core_valid,state==COMPUTE,core_channel,core_column,core_data);
 assign busy=state!=IDLE;
 assign araddr=read_address;assign arlen=read_count-1'b1;
 assign arsize=3;assign arburst=1;
 assign arvalid=state==P_AR || state==I_AR || state==S_AR;
 assign rready=state==P_R || state==I_R || state==S_R;
 assign awaddr=write_address;assign awlen=write_count-1'b1;
 assign awsize=3;assign awburst=1;assign awvalid=state==O_AW;
 assign wstrb=8'hff;assign wvalid=state==O_W;assign wlast=beat==burst_end;
 assign bready=state==O_B;
 integer j;
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;fault<=0;mode<=0;fourth<=0;row<=0;beat<=0;burst_end<=0;
   parameter_channel<=0;input_channel<=0;output_channel<=0;
   wdata<=0;
  end else case(state)
   IDLE: if(start) begin
    done<=0;fault<=0;
    if((input_base[5:0]|parameter_base[5:0]|output_base[5:0]|(project?skip_base[5:0]:6'b0))!=0)
     begin fault<=1;state<=FAILED;end
    else begin
     mode<=project;fourth<=block4;ib<=input_base;pb<=parameter_base;ob<=output_base;sb<=skip_base;
     row<=0;beat<=0;parameter_channel<=0;input_channel<=0;output_channel<=0;state<=P_AR;
    end
   end
   P_AR,I_AR,S_AR: if(arready) begin
    burst_end<=beat+read_count-1'b1;
    state<=state==P_AR?P_R:state==I_AR?I_R:S_R;
   end
   P_R,I_R,S_R: if(rvalid) begin
    if(rresp!=0 || (rlast!=(beat==burst_end))) fault<=1;
    if(rlast) begin
     if(fault || rresp!=0 || beat!=burst_end) state<=FAILED;
     else if(state==P_R) begin
      if(beat<19) begin beat<=beat+1'b1;state<=P_AR;end
      else if(parameter_channel<output_channels-1'b1) begin parameter_channel<=parameter_channel+1'b1;beat<=0;state<=P_AR;end
      else begin input_channel<=0;beat<=0;state<=I_AR;end
     end else if(beat<row_beats-1) begin beat<=beat+1'b1;state<=state==I_R?I_AR:S_AR;end
     else begin
      beat<=0;
      if(input_channel<(state==I_R?input_channels-1'b1:8'd23)) begin
       input_channel<=input_channel+1'b1;state<=state==I_R?I_AR:S_AR;
      end else begin
       input_channel<=0;
       state<=state==I_R && mode && !fourth?S_AR:C_START;
      end
     end
    end else if(beat<31) beat<=beat+1'b1;
   end
   C_START: state<=COMPUTE;
   COMPUTE: begin
    if(core_valid) results[core_channel*32'd56+core_column]<=core_data;
    if(core_done) begin output_channel<=0;beat<=0;state<=O_AW;end
   end
   O_AW: if(awready) begin burst_end<=beat+write_count-1'b1;state<=O_PREP;end
   // Register the distributed-cache read before it reaches the HP0 write mux.
   // WDATA remains unchanged for all cycles where WVALID waits for WREADY.
   O_PREP: begin
    wdata<=0;
    for(j=0;j<8;j=j+1) if(beat<row_beats && (!narrow || beat*8+j<28))
     wdata[j*8+:8]<=results[output_channel*32'd56+beat*32'd8+j];
    state<=O_W;
   end
   O_W: if(wready) begin
    if(beat==burst_end) state<=O_B;
    else begin beat<=beat+1'b1;state<=O_PREP;end
   end
   O_B: if(bvalid) begin
    if(bresp!=0) begin fault<=1;state<=FAILED;end
    else if(beat<row_beats-1) begin beat<=beat+1'b1;state<=O_AW;end
    else if(output_channel<output_channels-1'b1) begin
     output_channel<=output_channel+1'b1;beat<=0;state<=O_AW;
    end else if(row<(narrow?27:55)) begin row<=row+1'b1;input_channel<=0;beat<=0;state<=I_AR;end
    else begin done<=1;state<=IDLE;end
   end
   FAILED: state<=FAILED;
   default: begin fault<=1;state<=FAILED;end
  endcase
 end
endmodule
