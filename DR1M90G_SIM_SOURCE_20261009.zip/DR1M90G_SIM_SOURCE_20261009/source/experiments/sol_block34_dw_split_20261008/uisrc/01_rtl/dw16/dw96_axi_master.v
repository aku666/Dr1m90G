// Fixed NCHW C96, 112x112 -> 56x56, 3x3 stride 2, padding 1.
// Three input rows are resident; a streaming patch core emits one output/cycle.
// HP0 uses AXI3: every burst is <=16 beats and stays within a 4 KiB page.
module dw96_axi_master(
    input wire clk,resetn,start,
    input wire [31:0] input_base,parameter_base,output_base,
    output wire busy,output reg done,fault,
    output wire [31:0] araddr,output wire [7:0] arlen,
    output wire [2:0] arsize,output wire [1:0] arburst,
    output wire arvalid,input wire arready,
    input wire [63:0] rdata,input wire [1:0] rresp,
    input wire rlast,rvalid,output wire rready,
    output wire [31:0] awaddr,output wire [7:0] awlen,
    output wire [2:0] awsize,output wire [1:0] awburst,
    output wire awvalid,input wire awready,
    output reg [63:0] wdata,output reg [7:0] wstrb,
    output wire wlast,wvalid,input wire wready,
    input wire [1:0] bresp,input wire bvalid,output wire bready
);
    localparam IDLE=0,PARAM_AR=1,PARAM_R=2,ROW_PREP=3,
        INPUT_AR=4,INPUT_R=5,COMPUTE=6,OUTPUT_AW=7,OUTPUT_W=8,OUTPUT_B=9,FAILED=10;
    reg [3:0] state;
    reg [31:0] ib,pb,ob;
    reg [6:0] channel;
    reg [5:0] output_row,issued,received;
    reg [1:0] input_row;
    reg [3:0] beat,burst_end;
    reg [7:0] rows[0:335];
    reg [7:0] results[0:55];
    reg [71:0] weight,patch;
    reg signed [31:0] bias;
    reg [31:0] multiplier;
    wire signed [8:0] source_row=$signed({2'b0,output_row,1'b0})+$signed({7'b0,input_row})-9'sd1;
    wire [31:0] input_address=ib+channel*32'd12544+source_row*32'd112+beat*32'd8;
    wire [31:0] output_address=ob+channel*32'd3136+output_row*32'd56+beat*32'd8;
    wire [9:0] input_page_beats=10'd512-{1'b0,input_address[11:3]};
    wire [9:0] output_page_beats=10'd512-{1'b0,output_address[11:3]};
    wire [3:0] input_count=(input_page_beats<(14-beat))?input_page_beats[3:0]:14-beat;
    wire [3:0] output_count=(output_page_beats<(7-beat))?output_page_beats[3:0]:7-beat;
    wire core_ready,core_valid;
    wire [7:0] core_result;
    integer y,x,column,j;
    always @* begin
        patch=0;
        for(y=0;y<3;y=y+1) for(x=0;x<3;x=x+1) begin
            column=issued*2+x-1;
            if(column>=0 && column<112) patch[(y*3+x)*8 +: 8]=rows[y*112+column];
        end
        wdata=0;wstrb=8'hff;
        for(j=0;j<8;j=j+1) if(beat<7) wdata[j*8 +: 8]=results[beat*8+j];
    end
    dw3x3_patch_core core(clk,resetn,state==COMPUTE && issued<56,core_ready,
        patch,weight,8'd0,8'd128,bias,multiplier,5'd30,8'd0,8'd0,8'd255,
        core_valid,state==COMPUTE,core_result);
    assign busy=state!=IDLE;
    assign araddr=(state==PARAM_AR)?pb+channel*32'd32:input_address;
    assign arlen=(state==PARAM_AR)?8'd3:input_count-1'b1;
    assign arsize=3;assign arburst=1;
    assign arvalid=state==PARAM_AR || state==INPUT_AR;
    assign rready=state==PARAM_R || state==INPUT_R;
    assign awaddr=output_address;assign awlen=output_count-1'b1;
    assign awsize=3;assign awburst=1;assign awvalid=state==OUTPUT_AW;
    assign wvalid=state==OUTPUT_W;assign wlast=beat==burst_end;
    assign bready=state==OUTPUT_B;
    integer b;
    always @(posedge clk) begin
        if(!resetn) begin
            state<=IDLE;done<=0;fault<=0;channel<=0;output_row<=0;
            input_row<=0;beat<=0;issued<=0;received<=0;
        end else case(state)
        IDLE: if(start) begin
            done<=0;fault<=0;
            if((input_base[5:0]|parameter_base[5:0]|output_base[5:0])!=0) begin
                fault<=1;state<=FAILED;
            end else begin
                ib<=input_base;pb<=parameter_base;ob<=output_base;
                channel<=0;output_row<=0;beat<=0;state<=PARAM_AR;
            end
        end
        PARAM_AR: if(arready) begin beat<=0;state<=PARAM_R;end
        PARAM_R: if(rvalid) begin
            case(beat)
            0: weight[63:0]<=rdata;
            1: begin weight[71:64]<=rdata[7:0];bias<=rdata[63:32];end
            2: multiplier<=rdata[31:0];
            endcase
            if(rresp!=0 || (rlast!=(beat==3))) fault<=1;
            if(rlast) begin
                beat<=0;input_row<=0;
                state<=(fault || rresp!=0 || beat!=3)?FAILED:ROW_PREP;
            end else if(beat<15) beat<=beat+1'b1;
        end
        ROW_PREP: begin
            beat<=0;
            if(source_row<0 || source_row>=112) begin
                for(b=0;b<112;b=b+1) rows[input_row*112+b]<=0;
                if(input_row==2) begin issued<=0;received<=0;state<=COMPUTE;end
                else input_row<=input_row+1'b1;
            end else state<=INPUT_AR;
        end
        INPUT_AR: if(arready) begin burst_end<=beat+input_count-1'b1;state<=INPUT_R;end
        INPUT_R: if(rvalid) begin
            if(beat<14) for(b=0;b<8;b=b+1) rows[input_row*112+beat*8+b]<=rdata[b*8 +: 8];
            if(rresp!=0 || (rlast!=(beat==burst_end))) fault<=1;
            if(rlast) begin
                if(fault || rresp!=0 || beat!=burst_end) state<=FAILED;
                else if(beat==13) begin
                    beat<=0;
                    if(input_row==2) begin issued<=0;received<=0;state<=COMPUTE;end
                    else begin input_row<=input_row+1'b1;state<=ROW_PREP;end
                end else begin beat<=beat+1'b1;state<=INPUT_AR;end
            end else if(beat<15) beat<=beat+1'b1;
        end
        COMPUTE: begin
            if(core_ready && issued<56) issued<=issued+1'b1;
            if(core_valid) begin
                results[received]<=core_result;
                if(received==55) begin beat<=0;state<=OUTPUT_AW;end
                else received<=received+1'b1;
            end
        end
        OUTPUT_AW: if(awready) begin burst_end<=beat+output_count-1'b1;state<=OUTPUT_W;end
        OUTPUT_W: if(wready) begin
            if(beat==burst_end) state<=OUTPUT_B;else beat<=beat+1'b1;
        end
        OUTPUT_B: if(bvalid) begin
            if(bresp!=0) begin fault<=1;state<=FAILED;end
            else if(beat!=6) begin beat<=beat+1'b1;state<=OUTPUT_AW;end
            else if(output_row!=55) begin output_row<=output_row+1'b1;input_row<=0;state<=ROW_PREP;end
            else if(channel!=95) begin channel<=channel+1'b1;output_row<=0;beat<=0;state<=PARAM_AR;end
            else begin done<=1;state<=IDLE;end
        end
        FAILED: state<=FAILED;
        default: begin fault<=1;state<=FAILED;end
        endcase
    end
endmodule
