// Nine parallel products followed by accumulator/scaling/output stages.
// A downstream stall freezes the entire pipeline; quantization is unchanged.
module dw3x3_patch_core(
    input wire clk, input wire resetn,
    input wire in_valid, output wire in_ready,
    input wire [71:0] pixels, input wire [71:0] weights,
    input wire [7:0] input_zero, input wire [7:0] weight_zero,
    input wire signed [31:0] bias,
    input wire [31:0] multiplier, input wire [4:0] shift,
    input wire [7:0] output_zero, input wire [7:0] clip_min, clip_max,
    output reg out_valid, input wire out_ready, output reg [7:0] result
);
    reg v1,v2,v3;
    reg signed [17:0] product[0:8];
    reg signed [31:0] bias1;
    reg signed [63:0] accumulator2;
    reg signed [96:0] scaled3;
    reg [31:0] mul1,mul2;
    reg [4:0] sh1,sh2,sh3;
    reg [7:0] oz1,oz2,oz3,lo1,lo2,lo3,hi1,hi2,hi3;
    wire advance=!out_valid || out_ready;
    assign in_ready=advance;
    genvar tap;
    generate for(tap=0;tap<9;tap=tap+1) begin: parallel_tap
        wire signed [8:0] a=$signed({1'b0,pixels[tap*8 +: 8]})-$signed({1'b0,input_zero});
        wire signed [8:0] w=$signed({1'b0,weights[tap*8 +: 8]})-$signed({1'b0,weight_zero});
        always @(posedge clk) if(advance && in_valid) product[tap]<=a*w;
    end endgenerate
    wire signed [63:0] summed=
        {{32{bias1[31]}},bias1}+
        {{46{product[0][17]}},product[0]}+{{46{product[1][17]}},product[1]}+
        {{46{product[2][17]}},product[2]}+{{46{product[3][17]}},product[3]}+
        {{46{product[4][17]}},product[4]}+{{46{product[5][17]}},product[5]}+
        {{46{product[6][17]}},product[6]}+{{46{product[7][17]}},product[7]}+
        {{46{product[8][17]}},product[8]};
    wire signed [96:0] quotient=scaled3 >>> sh3;
    wire [96:0] mask=(97'd1 << sh3)-1'b1;
    wire [96:0] remainder=scaled3 & mask;
    wire [96:0] half=97'd1 << (sh3 ? sh3-1'b1 : 0);
    wire round_up=sh3!=0 && (remainder>half || (remainder==half && quotient[0]));
    wire signed [96:0] quantized=quotient+round_up+$signed({1'b0,oz3});
    always @(posedge clk) begin
        if(!resetn) begin
            v1<=0;v2<=0;v3<=0;out_valid<=0;result<=0;
        end else if(advance) begin
            v1<=in_valid;v2<=v1;v3<=v2;out_valid<=v3;
            if(in_valid) begin
                bias1<=bias;mul1<=multiplier;sh1<=shift;
                oz1<=output_zero;lo1<=clip_min;hi1<=clip_max;
            end
            if(v1) begin
                accumulator2<=summed;mul2<=mul1;sh2<=sh1;
                oz2<=oz1;lo2<=lo1;hi2<=hi1;
            end
            if(v2) begin
                scaled3<=accumulator2*$signed({1'b0,mul2});sh3<=sh2;
                oz3<=oz2;lo3<=lo2;hi3<=hi2;
            end
            if(v3) begin
                if(quantized<$signed({1'b0,lo3})) result<=lo3;
                else if(quantized>$signed({1'b0,hi3})) result<=hi3;
                else result<=quantized[7:0];
            end
        end
    end
endmodule
