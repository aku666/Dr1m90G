// GP and existing HP0 both use p2f_clk0 (80 MHz in the qualified bit).
// Addresses stay immutable until the final write response is acknowledged.
module dw16_control(
    input wire aclk,rst_n,
    input wire [31:0] S_AXI_AWADDR,input wire [2:0] S_AXI_AWPROT,
    input wire S_AXI_AWVALID,output wire S_AXI_AWREADY,
    input wire [31:0] S_AXI_WDATA,input wire [3:0] S_AXI_WSTRB,
    input wire S_AXI_WVALID,output wire S_AXI_WREADY,
    output reg [1:0] S_AXI_BRESP,output reg S_AXI_BVALID,input wire S_AXI_BREADY,
    input wire [31:0] S_AXI_ARADDR,input wire [2:0] S_AXI_ARPROT,
    input wire S_AXI_ARVALID,output wire S_AXI_ARREADY,
    output reg [31:0] S_AXI_RDATA,output reg [1:0] S_AXI_RRESP,
    output reg S_AXI_RVALID,input wire S_AXI_RREADY,
    output reg dma_start,output wire [31:0] dma_input,dma_parameter,dma_output,
    input wire dma_busy,dma_done,dma_fault
);
    reg aw_pending,w_pending;
    reg [31:0] wa,wd;
    reg [3:0] ws;
    reg [31:0] cfg_input,cfg_parameter,cfg_output;
    reg pending,armed;
    reg [1:0] last_status;
    reg [31:0] last_cycles;
    reg [31:0] cycles;
    assign dma_input=cfg_input;
    assign dma_parameter=cfg_parameter;
    assign dma_output=cfg_output;
    assign S_AXI_AWREADY=!aw_pending && !S_AXI_BVALID;
    assign S_AXI_WREADY=!w_pending && !S_AXI_BVALID;
    assign S_AXI_ARREADY=!S_AXI_RVALID;
    always @(posedge aclk) begin
        if(!rst_n) begin
            aw_pending<=0;w_pending<=0;S_AXI_BVALID<=0;S_AXI_BRESP<=0;
            S_AXI_RVALID<=0;S_AXI_RRESP<=0;S_AXI_RDATA<=0;
            cfg_input<=0;cfg_parameter<=0;cfg_output<=0;
            dma_start<=0;pending<=0;armed<=0;cycles<=0;
            last_status<=0;last_cycles<=0;
        end else begin
            dma_start<=0;
            if(pending && dma_busy) begin armed<=1;cycles<=cycles+1'b1;end
            if(pending && armed && (dma_done || dma_fault)) begin
                pending<=0;armed<=0;last_status<={dma_fault,dma_done};last_cycles<=cycles;
            end
            if(S_AXI_BVALID && S_AXI_BREADY) S_AXI_BVALID<=0;
            if(S_AXI_AWVALID && S_AXI_AWREADY) begin wa<=S_AXI_AWADDR;aw_pending<=1;end
            if(S_AXI_WVALID && S_AXI_WREADY) begin wd<=S_AXI_WDATA;ws<=S_AXI_WSTRB;w_pending<=1;end
            if(aw_pending && w_pending && !S_AXI_BVALID) begin
                aw_pending<=0;w_pending<=0;S_AXI_BVALID<=1;S_AXI_BRESP<=0;
                if(pending || last_status[1] || ws!=4'hf) S_AXI_BRESP<=2;
                else case(wa)
                    32'h0c: cfg_input<=wd;
                    32'h10: cfg_parameter<=wd;
                    32'h14: cfg_output<=wd;
                    32'h18: if(wd==1 && (cfg_input[5:0]|cfg_parameter[5:0]|cfg_output[5:0])==0) begin
                        dma_start<=1;pending<=1;armed<=0;cycles<=0;last_status<=0;last_cycles<=0;
                    end else S_AXI_BRESP<=2;
                    default: S_AXI_BRESP<=2;
                endcase
            end
            if(S_AXI_RVALID && S_AXI_RREADY) S_AXI_RVALID<=0;
            if(S_AXI_ARVALID && S_AXI_ARREADY) begin
                S_AXI_RVALID<=1;S_AXI_RRESP<=0;
                case(S_AXI_ARADDR)
                    32'h00: S_AXI_RDATA<=32'h44573136;
                    32'h04: S_AXI_RDATA<=32'h00010001;
                    32'h08: S_AXI_RDATA<={29'b0,last_status,pending};
                    32'h0c: S_AXI_RDATA<=cfg_input;
                    32'h10: S_AXI_RDATA<=cfg_parameter;
                    32'h14: S_AXI_RDATA<=cfg_output;
                    32'h18: S_AXI_RDATA<=32'h03c00707;
                    32'h1c: S_AXI_RDATA<=last_cycles;
                    default: begin S_AXI_RDATA<=0;S_AXI_RRESP<=2;end
                endcase
            end
        end
    end
endmodule
