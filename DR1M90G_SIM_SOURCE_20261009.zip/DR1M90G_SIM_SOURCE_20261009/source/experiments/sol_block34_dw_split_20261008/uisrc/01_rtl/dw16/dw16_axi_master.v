// Fixed NCHW 960x7x7 DW16, one channel resident at a time.
// Parameter record: 9 weight bytes, 3 padding, INT32 bias, UINT32 multiplier,
// then 12 padding bytes. All base addresses must be 64-byte aligned.
// Completion is published only after the final AXI B response.
module dw16_axi_master(
    input wire clk,resetn,start,
    input wire [31:0] input_base,parameter_base,output_base,
    output wire busy, output reg done,fault,
    output wire [31:0] araddr, output wire [7:0] arlen,
    output wire [2:0] arsize, output wire [1:0] arburst,
    output wire arvalid, input wire arready,
    input wire [63:0] rdata,input wire [1:0] rresp,
    input wire rlast,rvalid,output wire rready,
    output wire [31:0] awaddr,output wire [7:0] awlen,
    output wire [2:0] awsize,output wire [1:0] awburst,
    output wire awvalid,input wire awready,
    output reg [63:0] wdata,output reg [7:0] wstrb,
    output wire wlast,wvalid,input wire wready,
    input wire [1:0] bresp,input wire bvalid,output wire bready
);
    localparam IDLE=0,INPUT_AR=1,INPUT_R=2,PARAM_AR=3,PARAM_R=4,
               ISSUE=5,RESULT=6,OUTPUT_AW=7,OUTPUT_W=8,OUTPUT_B=9,FAILED=10;
    reg [3:0] state;
    reg [31:0] ib,pb,ob;
    reg [9:0] channel;
    reg [3:0] beat,burst_end;
    reg [5:0] position;
    reg [2:0] row,column;
    reg [7:0] input_bytes[0:55];
    reg [7:0] output_bytes[0:48];
    reg [71:0] weight;
    reg signed [31:0] bias;
    reg [31:0] multiplier;
    reg [71:0] patch;
    wire [31:0] logical_input = ib+channel*32'd49;
    wire [31:0] logical_output = ob+channel*32'd49;
    wire [2:0] byte_offset = logical_input[2:0];
    wire [2:0] output_offset = logical_output[2:0];
    wire [31:0] input_address={logical_input[31:3],3'b0}+beat*32'd8;
    wire [31:0] output_address={logical_output[31:3],3'b0}+beat*32'd8;
    wire [9:0] input_available=10'd512-{1'b0,input_address[11:3]};
    wire [9:0] output_available=10'd512-{1'b0,output_address[11:3]};
    wire [3:0] input_count=(input_available<(7-beat)) ? input_available[3:0] : 7-beat;
    wire [3:0] output_count=(output_available<(7-beat)) ? output_available[3:0] : 7-beat;
    wire core_ready,core_valid;
    wire [7:0] core_result;
    integer ky,kx,yy,xx,j,index;
    always @* begin
        patch=0;
        for(ky=0;ky<3;ky=ky+1) begin
            for(kx=0;kx<3;kx=kx+1) begin
                yy=$signed({1'b0,row})+ky-1;
                xx=$signed({1'b0,column})+kx-1;
                if(yy>=0 && yy<7 && xx>=0 && xx<7)
                    patch[(ky*3+kx)*8 +: 8]=input_bytes[byte_offset+yy*7+xx];
            end
        end
    end
    always @* begin
        wdata=0;wstrb=0;
        for(j=0;j<8;j=j+1) begin
            index=beat*8+j-output_offset;
            if(index>=0 && index<49) begin
                wdata[j*8 +: 8]=output_bytes[index];wstrb[j]=1;
            end
        end
    end
    dw3x3_patch_core core(
        .clk(clk),.resetn(resetn),.in_valid(state==ISSUE),.in_ready(core_ready),
        .pixels(patch),.weights(weight),.input_zero(8'd0),.weight_zero(8'd128),
        .bias(bias),.multiplier(multiplier),.shift(5'd30),.output_zero(8'd0),
        .clip_min(8'd0),.clip_max(8'd255),.out_valid(core_valid),
        .out_ready(state==RESULT),.result(core_result));
    assign busy=state!=IDLE;
    assign araddr=(state==PARAM_AR) ? pb+channel*32'd32 : input_address;
    assign arlen=(state==PARAM_AR) ? 8'd3 : input_count-1'b1;
    assign arsize=3'd3;assign arburst=2'b01;
    assign arvalid=state==INPUT_AR || state==PARAM_AR;
    assign rready=state==INPUT_R || state==PARAM_R;
    assign awaddr=output_address;
    assign awlen=output_count-1'b1;assign awsize=3'd3;assign awburst=2'b01;
    assign awvalid=state==OUTPUT_AW;
    assign wvalid=state==OUTPUT_W;assign wlast=beat==burst_end;
    assign bready=state==OUTPUT_B;
    integer b;
    always @(posedge clk) begin
        if(!resetn) begin
            state<=IDLE;done<=0;fault<=0;beat<=0;channel<=0;
            position<=0;row<=0;column<=0;
        end else begin
            case(state)
            IDLE: if(start) begin
                done<=0;fault<=0;
                if((input_base[5:0]|parameter_base[5:0]|output_base[5:0])!=0) begin
                    fault<=1;state<=FAILED;
                end else begin
                    ib<=input_base;pb<=parameter_base;ob<=output_base;
                    channel<=0;beat<=0;state<=INPUT_AR;
                end
            end
            INPUT_AR: if(arready) begin burst_end<=beat+input_count-1'b1;state<=INPUT_R;end
            INPUT_R: if(rvalid) begin
                if(beat<7) for(b=0;b<8;b=b+1) input_bytes[beat*8+b]<=rdata[b*8 +: 8];
                if(rresp!=0 || (rlast!=(beat==burst_end))) fault<=1;
                if(rlast) begin
                    if(fault || rresp!=0 || beat!=burst_end) state<=FAILED;
                    else if(beat==6) begin beat<=0;state<=PARAM_AR;end
                    else begin beat<=beat+1'b1;state<=INPUT_AR;end
                end else if(beat<15) beat<=beat+1'b1;
            end
            PARAM_AR: if(arready) begin beat<=0;state<=PARAM_R;end
            PARAM_R: if(rvalid) begin
                case(beat)
                0: weight[63:0]<=rdata;
                1: begin weight[71:64]<=rdata[7:0];bias<=rdata[63:32];end
                2: multiplier<=rdata[31:0];
                endcase
                if(rresp!=0 || (rlast!=(beat==3))) fault<=1;
                if(rlast) begin
                    beat<=0;position<=0;row<=0;column<=0;
                    state<=(fault || rresp!=0 || beat!=3) ? FAILED : ISSUE;
                end else if(beat<15) beat<=beat+1'b1;
            end
            ISSUE: if(core_ready) state<=RESULT;
            RESULT: if(core_valid) begin
                output_bytes[position]<=core_result;
                if(position==48) begin beat<=0;state<=OUTPUT_AW;end
                else begin
                    position<=position+1'b1;
                    if(column==6) begin column<=0;row<=row+1'b1;end
                    else column<=column+1'b1;
                    state<=ISSUE;
                end
            end
            OUTPUT_AW: if(awready) begin burst_end<=beat+output_count-1'b1;state<=OUTPUT_W;end
            OUTPUT_W: if(wready) begin
                if(beat==burst_end) state<=OUTPUT_B;
                else beat<=beat+1'b1;
            end
            OUTPUT_B: if(bvalid) begin
                if(bresp!=0) begin fault<=1;state<=FAILED;end
                else if(beat!=6) begin beat<=beat+1'b1;state<=OUTPUT_AW;end
                else if(channel==959) begin done<=1;state<=IDLE;end
                else begin channel<=channel+1'b1;beat<=0;state<=INPUT_AR;end
            end
            FAILED: state<=FAILED; // no automatic retry after partial output.
            default: begin fault<=1;state<=FAILED;end
            endcase
        end
    end
endmodule
