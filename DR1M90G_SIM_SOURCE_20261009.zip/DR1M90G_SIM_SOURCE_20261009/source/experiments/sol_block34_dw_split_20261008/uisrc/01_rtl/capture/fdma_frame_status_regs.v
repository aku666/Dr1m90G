// Candidate read-only register bank in the FDMA UI clock domain.
// read_offset/read_data are NOT an AXI slave. A future PS bridge must preserve
// ordered 32-bit reads and map this exact layout only after separate validation.
module fdma_frame_status_regs (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [7:0]  sync_slot,
    input  wire        done_irq,
    input  wire [7:0]  done_slot,
    input  wire        write_fault,
    input  wire [5:0]  read_offset,
    output reg  [31:0] read_data
);
    reg [7:0] sync_slot_d = 8'd0;
    reg done_irq_d = 1'b0;
    reg reset_seen = 1'b0;
    reg [31:0] version = 32'd0;
    reg [31:0] epoch = 32'd0;
    reg [31:0] completed_seq = 32'd0;
    reg [31:0] completed_slot = 32'd0;
    reg [2:0] write_active = 3'b000;
    reg [31:0] fault_mask = 32'd0;
    reg [31:0] start0 = 32'd0, start1 = 32'd0, start2 = 32'd0;
    reg [31:0] done0 = 32'd0, done1 = 32'd0, done2 = 32'd0;

    wire frame_start = sync_slot != sync_slot_d;
    wire frame_done = done_irq && !done_irq_d;
    wire update = frame_start || frame_done || (write_fault && !fault_mask[0]);

    always @(posedge clk) begin
        sync_slot_d <= sync_slot;
        done_irq_d <= done_irq;
        if (!rst_n) begin
            if (!reset_seen)
                epoch <= epoch + 32'd1;
            reset_seen <= 1'b1;
            version <= 32'd0;
            completed_seq <= 32'd0;
            completed_slot <= 32'd0;
            write_active <= 3'b000;
            fault_mask <= 32'd0;
            start0 <= 32'd0;
            start1 <= 32'd0;
            start2 <= 32'd0;
            done0 <= 32'd0;
            done1 <= 32'd0;
            done2 <= 32'd0;
        end else begin
            reset_seen <= 1'b0;
            if (update)
                version <= version + 32'd2;
            if (write_fault)
                fault_mask[0] <= 1'b1;
            if (frame_start) begin
                if (sync_slot > 8'd2 || write_active[sync_slot[1:0]])
                    fault_mask[1] <= 1'b1;
                else begin
                    write_active[sync_slot[1:0]] <= 1'b1;
                    case (sync_slot)
                        8'd0: start0 <= start0 + 32'd1;
                        8'd1: start1 <= start1 + 32'd1;
                        8'd2: start2 <= start2 + 32'd1;
                    endcase
                end
            end
            if (frame_done) begin
                if (done_slot > 8'd2 || !write_active[done_slot[1:0]] ||
                    frame_start || write_fault)
                    fault_mask[2] <= 1'b1;
                else begin
                    write_active[done_slot[1:0]] <= 1'b0;
                    case (done_slot)
                        8'd0: done0 <= start0;
                        8'd1: done1 <= start1;
                        8'd2: done2 <= start2;
                    endcase
                    completed_slot <= {24'd0, done_slot};
                    completed_seq <= completed_seq == 32'hffffffff ?
                                     32'd1 : completed_seq + 32'd1;
                end
            end
        end
    end

    always @* begin
        case (read_offset)
            6'h00: read_data = 32'h46535431;
            6'h04: read_data = 32'h00010000;
            6'h08: read_data = version;
            6'h0c: read_data = epoch;
            6'h10: read_data = completed_seq;
            6'h14: read_data = completed_slot;
            6'h18: read_data = {29'd0, write_active};
            6'h1c: read_data = fault_mask;
            6'h20: read_data = start0;
            6'h24: read_data = done0;
            6'h28: read_data = start1;
            6'h2c: read_data = done1;
            6'h30: read_data = start2;
            6'h34: read_data = done2;
            default: read_data = 32'd0;
        endcase
    end
endmodule
