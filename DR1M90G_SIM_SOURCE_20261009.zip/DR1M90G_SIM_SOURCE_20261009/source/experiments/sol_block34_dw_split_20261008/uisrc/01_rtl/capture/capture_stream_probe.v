// Locate the observed zero-frame failure. No control or DMA writes.
module capture_stream_probe (
    input wire ui_clk, ui_resetn, rx_clk, rx_resetn,
    input wire csi_start, isp_start, hs_valid,
    input wire [9:0] flags_async,
    input wire aw_fire, b_fire,
    output wire [31:0] flags,
    output wire [31:0] csi_gray, isp_gray,
    output reg [31:0] aw_count, b_count,
    output wire [31:0] rx_gray, valid_gray
);
    reg [15:0] csi_count=0,isp_count=0,rx_count=0,valid_count=0;
    reg csi_d=0,isp_d=0;
    reg [9:0] flags_meta=0,flags_sync=0;
    reg [15:0] csi_meta=0,csi_sync=0,isp_meta=0,isp_sync=0,rx_meta=0,rx_sync=0,valid_meta=0,valid_sync=0;
    wire [15:0] cg=csi_count^(csi_count>>1);
    wire [15:0] ig=isp_count^(isp_count>>1);
    wire [15:0] rg=rx_count^(rx_count>>1),vg=valid_count^(valid_count>>1);
    always @(posedge rx_clk) begin
        if(!rx_resetn) begin csi_count<=0;isp_count<=0;rx_count<=0;valid_count<=0;csi_d<=0;isp_d<=0;end
        else begin
            csi_d<=csi_start;isp_d<=isp_start;rx_count<=rx_count+1;
            if(hs_valid) valid_count<=valid_count+1;
            if(csi_start && !csi_d) csi_count<=csi_count+1;
            if(isp_start && !isp_d) isp_count<=isp_count+1;
        end
    end
    always @(posedge ui_clk) begin
        flags_meta<=flags_async;flags_sync<=flags_meta;
        csi_meta<=cg;csi_sync<=csi_meta;isp_meta<=ig;isp_sync<=isp_meta;
        rx_meta<=rg;rx_sync<=rx_meta;valid_meta<=vg;valid_sync<=valid_meta;
        if(!ui_resetn) begin aw_count<=0;b_count<=0;end
        else begin
            if(aw_fire) aw_count<=aw_count+1;
            if(b_fire) b_count<=b_count+1;
        end
    end
    assign flags={22'd0,flags_sync};
    assign csi_gray={16'd0,csi_sync};assign isp_gray={16'd0,isp_sync};
    assign rx_gray={16'd0,rx_sync};assign valid_gray={16'd0,valid_sync};
endmodule
