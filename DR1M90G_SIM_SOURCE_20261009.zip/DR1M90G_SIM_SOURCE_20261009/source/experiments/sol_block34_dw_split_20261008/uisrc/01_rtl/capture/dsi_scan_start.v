// Keep pixel zero in the FIFO until a full panel frame can consume it.
// The panel/configuration clocks keep running; no AXI reset is performed.
module dsi_scan_start (
    input wire ui_clk, ui_resetn, display_enable, read_word_valid,
    input wire scan_clk, scan_resetn, scan_vsync,
    output reg scan_enabled
);
    reg prefilled;
    always @(posedge ui_clk or negedge ui_resetn) begin
        if (!ui_resetn) prefilled <= 1'b0;
        else if (!display_enable) prefilled <= 1'b0;
        else if (read_word_valid) prefilled <= 1'b1;
    end

    (* async_reg = "true" *) reg ready_meta, ready_sync;
    reg vsync_previous;
    always @(posedge scan_clk or negedge scan_resetn) begin
        if (!scan_resetn) begin
            ready_meta <= 1'b0;
            ready_sync <= 1'b0;
            vsync_previous <= 1'b0;
            scan_enabled <= 1'b0;
        end else begin
            ready_meta <= prefilled;
            ready_sync <= ready_meta;
            vsync_previous <= scan_vsync;
            if (!ready_sync) scan_enabled <= 1'b0;
            // Original video_source's VS is active high during vertical sync,
            // before the 21-line back porch and the first active pixel.
            else if (scan_vsync && !vsync_previous) scan_enabled <= 1'b1;
        end
    end
endmodule
