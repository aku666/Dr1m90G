module reference_camera_path(
input wire I_sysclk,p2f_rst0_n,input wire [1:0] I_button,
input wire I_clk_hs_p,input wire [3:0] I_data_hs_p,I_data_lp_p,I_data_lp_n,
output wire O_clk_24m,O_cam_scl,inout wire IO_cam_sda,
output wire locked,cam_cfg_done,ae_cfg_done,iic_error,S_hs_rx_clk,S_csi_frame_start,
output wire [3:0] S_lane_error,
output wire [127:0] ISP_O_tdata,output wire ISP_O_tlast,ISP_O_tuser,ISP_O_tvalid,
output wire ISP_O_tready,output wire camera_clk24m,output wire receiver_valid,
input wire [23:0] I_video_in_data,output wire scan_clk,scan_de,scan_vsync,
output wire O_clk_hs_p,O_clk_lp_p,O_clk_lp_n,
output wire [3:0] O_data_hs_p,O_data_lp_p,O_data_lp_n);
wire S_clk,S_clk_x2,S_clk_x4,S_clk_x4_90d,S_lp_clk,clk_24m,clk_70m;
wire S_lock,S_hs_rx_valid,S_csi_frame_end,S_csi_valid;
wire [31:0] S_hs_rx_data,S_csi_data;
wire S_raw10_frame_start,S_raw10_frame_end,S_raw10_valid;
wire [39:0] S_raw10_data,axis_tdata;
wire axis_tvalid,axis_tlast,axis_tuser;
wire [7:0] ae; wire ae_req;
  pll U_pll (
      .refclk  (I_sysclk),     //系统时钟输入
      .reset(~p2f_rst0_n),     //PLL复位
      .lock    (locked), 
	  .clk0_out(S_clk),
      .clk1_out(S_clk_x2),
      .clk2_out(S_clk_x4),
      .clk3_out(S_clk_x4_90d),
      .clk4_out(S_lp_clk),
      .clk5_out(clk_24m),
      .clk6_out(clk_70m)
  );

  // oDDR primitive
  DR1_LOGIC_ODDR CMOS_CLK (
      .q  (O_clk_24m),  //output 125mhz（1gbps） 25mhz(100mbps)    2.5mhz(10mbps)
      .clk(clk_24m),
      .d0 (1'b1),
      .d1 (1'b0),
      .rst(1'b0)
  );

	//手动配置相机AE
  ae_set u_ae_set(
	.I_clk(clk_24m),
	.I_rst(locked),
	.I_btn(~I_button),
	.I_cam_cfg_done(cam_cfg_done),
	.I_ae_cfg_done(ae_cfg_done),
	.O_ae_req(ae_req),
	.O_ae(ae)
  );
	
  uicfg_imx415#
	(
	.CLK_DIV(24_000_000/100_000-1)
	)
	u_uicfg_imx415
	(
	.I_clk(clk_24m),  
	.I_rst_n(locked),  
	.I_ae_req(ae_req),
	.I_ae_data(ae),
	.O_cam_scl(O_cam_scl), 
	.IO_cam_sda(IO_cam_sda), 
	.O_cfg_done(cam_cfg_done),
	.O_ae_cfg_done(ae_cfg_done),.O_iic_bus_error(iic_error)
  );

  mipi_dphy_rx_over_lvds_wrapper#(
    .DEVICE           ( "DR1" ),
    .LANE_NUM         ( 4    )
)u_mipi_dphy_rx_over_lvds_wrapper(
    .I_lp_clk         ( clk_70m      ),
    .I_rst            ( ~locked      ),

    .I_mipi_clk_p     ( I_clk_hs_p   ),
    .I_mipi_data_hs_p ( I_data_hs_p  ),
    .I_mipi_data_lp_p ( I_data_lp_p  ),
    .I_mipi_data_lp_n ( I_data_lp_n  ),

    .I_lane_hs_invert ( 4'b0000      ),
    .I_lane_lp_invert ( 4'b0000      ),

    .O_hs_rx_clk      ( S_hs_rx_clk   ),
    .O_hs_rx_valid    ( S_hs_rx_valid ),
    .O_hs_rx_data     ( S_hs_rx_data  ),

    .O_lp_rx_lane0_p  (),
    .O_lp_rx_lane0_n  (),

    .O_lane_error(S_lane_error)
);

//csi ����ΪRAW����
csi_unpacket_4lane u_csi_unpacket(
.I_clk                 ( S_hs_rx_clk       ),
.I_rst_n               ( locked        	   ),
.I_hs_valid            ( S_hs_rx_valid     ),
.I_hs_data             ( S_hs_rx_data      ),

.O_csi_frame_start     ( S_csi_frame_start ),
.O_csi_frame_end       ( S_csi_frame_end   ),
.O_csi_valid           ( S_csi_valid       ),
.O_csi_data            ( S_csi_data        )
);



// ����ΪRAW10
raw10_unpacket_4lane u_raw10_unpacket (
.I_clk  (S_hs_rx_clk),
.I_rst_n(locked),

.I_csi_frame_start(S_csi_frame_start),
.I_csi_frame_end  (S_csi_frame_end),
.I_csi_valid      (S_csi_valid),
.I_csi_data       (S_csi_data),

.O_raw10_frame_start(S_raw10_frame_start),
.O_raw10_frame_end  (S_raw10_frame_end  ),
.O_raw10_valid      (S_raw10_valid      ),
.O_raw10_data       (S_raw10_data       )
);

image_correction #(
    .DATA_WIDTH  (40),
    .TDEST_WIDTH (10)
)image_correction
(
    .I_clk            (S_hs_rx_clk),
    .I_rst_n          (locked),

    .I_raw_data       (S_raw10_data       ),       
    .I_raw_valid      (S_raw10_valid      ),     
    .I_raw_frame_start(S_raw10_frame_start),
    .I_raw_frame_end  (S_raw10_frame_end  ),
    
    .O_raw_tdata (axis_tdata ),
    .O_raw_tlast (axis_tlast ),
    .O_raw_tdest (           ),
    .O_raw_tvalid(axis_tvalid),
    .O_raw_tuser (axis_tuser )

);

isp_top u_isp_top (
.axi4s_video_aclk(S_hs_rx_clk),
.I_rst_n         (locked),
.I_tlast         (axis_tlast ),
.I_tuser         (axis_tuser ),
.I_tdata         (axis_tdata ),
.I_tvalid        (axis_tvalid),
.I_tdest         (),
.O_tready        (ISP_O_tready),
.O_tdata         (ISP_O_tdata ),
.O_tlast         (ISP_O_tlast ),
.O_tuser         (ISP_O_tuser ),
.O_tvalid        (ISP_O_tvalid),
.I_tready        ()
  );


assign camera_clk24m=clk_24m; assign receiver_valid=S_hs_rx_valid;
  wire        S_rst;  //synthesis keep
  wire        S_config_start;
  wire        S_config_done;

  wire        S_24b_vsync;  //synthesis keep
  wire        S_24b_hsync;  //synthesis keep
  wire        S_24b_de;  //synthesis keep
  wire [23:0] S_24b_data;  //synthesis keep

  wire        S_32b_vsync;  //synthesis keep
  wire        S_32b_hsync;  //synthesis keep
  wire        S_32b_de;  //synthesis keep
  wire [31:0] S_32b_data;  //synthesis keep

  wire        S_hs_en;  //synthesis keep           
  wire        S_hs_last;  //synthesis keep	       
  wire [31:0] S_hs_data;  //synthesis keep    

  wire        S_lp_tx_valid;
  wire        S_lp_tx_last;
  wire [ 7:0] S_lp_tx_data;
  wire        S_lp_tx_ready;

  wire camera_start_resetn;
  fdma_frame_reset_sync camera_reset_sync(.clk(S_clk),
      .async_resetn(p2f_rst0_n && locked),.frame_resetn(camera_start_resetn));
  reset_gen u_reset_gen (
      .I_clk     (S_clk),
      .I_pll_lock(locked),
      .I_rst     (~camera_start_resetn),

      .O_rst_n       (),
      .O_rst         (S_rst),
      .O_config_start(S_config_start)
  );


  video_source #(
        .HTOTAL ( 1344 ),
        .HSA    ( 24    ),
        .HBP    ( 136   ),
        .HFP    ( 160   ),
 
        .VTOTAL ( 635 ),
        .VSA    ( 2    ),
        .VBP    ( 21   ),
        .VFP    ( 12   )
  ) u_video_source (
      .I_clk(S_clk),
      .I_rst(S_rst),

      .I_config_done(S_config_done),

      .O_rgb24b_vsync(S_24b_vsync),
      .O_rgb24b_hsync(S_24b_hsync),
      .O_rgb24b_de   (S_24b_de),
      .O_rgb24b_data (S_24b_data)
  );


  rgb_24b_to_32b #(
      .H_ACTIVE(1024)
  ) u_rgb_24b_to_32b (
      .I_clk(S_clk),
      .I_rst(S_rst),

      .I_vsync(S_24b_vsync),
      .I_hsync(S_24b_hsync),
      .I_de   (S_24b_de),
      .I_data (I_video_in_data),

      .O_vsync(S_32b_vsync),
      .O_hsync(S_32b_hsync),
      .O_de   (S_32b_de),
      .O_data (S_32b_data)
  );


  dsi_video_mode_packet #(
      .H_ACTIVE(1024)
  ) u_dsi_video_mode_packet (
      .I_clk(S_clk),
      .I_rst(S_rst),

      .I_vsync(S_32b_vsync),
      .I_hsync(S_32b_hsync),
      .I_de   (S_32b_de),
      .I_data (S_32b_data),

      .O_hs_en  (S_hs_en),
      .O_hs_data(S_hs_data),
      .O_hs_last(S_hs_last)
  );


  display_config_wrapper u_display_config_wrapper (
      .I_clk(S_lp_clk),
      .I_rst(S_rst),

      .I_config_start(S_config_start),
      .O_config_done (S_config_done),

      .O_lp_tx_valid(S_lp_tx_valid),
      .O_lp_tx_last (S_lp_tx_last),
      .O_lp_tx_data (S_lp_tx_data),
      .I_lp_tx_ready(S_lp_tx_ready)
  );



  mipi_dphy_tx_wrapper #(
      .LANE_NUM(4),

      .HS_TX_FIFO_TYPE      ("DRAM"),  ///"DRAM","BRAM"
      .LP_TX_FIFO_TYPE      ("DRAM"),  ///"DRAM","BRAM"
      .LP_TX_MAX_DATA_LENGTH(8),       ///1-240

      .CLK_LANE_MODE("CONTINUE"),  ///"INTERRUPT","CONTINUE"

      .T_DATA_LPX       (10),
      .T_DATA_HS_PREPARE(10),
      .T_DATA_HS_ZERO   (20),
      .T_DATA_HS_TRAIL  (20),
      .T_CLK_LPX        (10),
      .T_CLK_PREPARE    (10),
      .T_CLK_ZERO       (10),
      .T_CLK_PRE        (10),
      .T_CLK_POST       (10),
      .T_CLK_TRAIL      (10)
  ) u_mipi_dphy_tx_wrapper (
      .I_hs_clk       (S_clk),
      .I_hs_clk_x2    (S_clk_x2),
      .I_hs_clk_x4    (S_clk_x4),
      .I_hs_clk_x4_90d(S_clk_x4_90d),

      .I_rst(S_rst),

      .I_hs_tx_valid(S_hs_en),
      .I_hs_tx_data (S_hs_data),
      .I_hs_tx_last (S_hs_last),
      .O_hs_tx_ready(),

      .I_lpdt_clk   (S_lp_clk),
      .I_lp_tx_valid(S_lp_tx_valid),
      .I_lp_tx_data (S_lp_tx_data),
      .I_lp_tx_last (S_lp_tx_last),
      .O_lp_tx_ready(S_lp_tx_ready),

      .O_clk_hs_p (O_clk_hs_p),
      .O_data_hs_p(O_data_hs_p),
      .O_clk_lp_p (O_clk_lp_p),
      .O_clk_lp_n (O_clk_lp_n),
      .O_data_lp_p(O_data_lp_p),
      .O_data_lp_n(O_data_lp_n)
  );


assign scan_clk=S_clk; assign scan_de=S_24b_de; assign scan_vsync=S_24b_vsync;
endmodule
