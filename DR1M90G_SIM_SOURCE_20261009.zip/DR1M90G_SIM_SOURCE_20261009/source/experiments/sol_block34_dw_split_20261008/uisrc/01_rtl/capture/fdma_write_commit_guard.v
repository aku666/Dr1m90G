// Passive AXI write-response guard for the saved uiFDMA write path.
// The guard and AXI taps must share M_AXI_ACLK. An error stops frame release
// until reset; this module never starts a write or acknowledges an AXI response.
module fdma_write_commit_guard (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       raw_wbusy,
    input  wire       awvalid,
    input  wire       awready,
    input  wire       bvalid,
    input  wire       bready,
    input  wire [1:0] bresp,
    output wire       safe_wbusy,
    output reg        fault,
    output reg        transfer_committed
);
    reg raw_busy_d;
    reg active;
    reg data_done;
    reg seen_aw;
    reg seen_b;
    reg [16:0] outstanding;

    wire start = raw_wbusy && !raw_busy_d;
    wire stop_data = !raw_wbusy && raw_busy_d;
    wire aw_fire = awvalid && awready;
    wire b_fire = bvalid && bready;

    assign safe_wbusy = raw_wbusy || active || fault;

    always @(posedge clk) begin
        if (!rst_n) begin
            raw_busy_d <= 1'b0;
            active <= 1'b0;
            data_done <= 1'b0;
            seen_aw <= 1'b0;
            seen_b <= 1'b0;
            outstanding <= 17'd0;
            fault <= 1'b0;
            transfer_committed <= 1'b0;
        end else begin
            raw_busy_d <= raw_wbusy;
            transfer_committed <= 1'b0;

            if (start && active)
                fault <= 1'b1;

            if (start && !active) begin
                active <= 1'b1;
                data_done <= 1'b0;
                seen_aw <= aw_fire;
                seen_b <= b_fire;
                if (b_fire && !aw_fire)
                    fault <= 1'b1;
                if (b_fire && bresp != 2'b00)
                    fault <= 1'b1;
                outstanding <= aw_fire && !b_fire ? 17'd1 : 17'd0;
            end else if (active) begin
                if (aw_fire)
                    seen_aw <= 1'b1;
                if (b_fire) begin
                    seen_b <= 1'b1;
                    if (bresp != 2'b00)
                        fault <= 1'b1;
                end
                if (aw_fire && !b_fire) begin
                    if (outstanding == 17'h1ffff)
                        fault <= 1'b1;
                    else
                        outstanding <= outstanding + 1'b1;
                end else if (b_fire && !aw_fire) begin
                    if (outstanding == 17'd0)
                        fault <= 1'b1;
                    else
                        outstanding <= outstanding - 1'b1;
                end else if (b_fire && aw_fire && outstanding == 17'd0) begin
                    // Same-cycle AW/B is allowed only if both really handshake.
                    outstanding <= 17'd0;
                end
                if (stop_data)
                    data_done <= 1'b1;
                if (data_done && !raw_wbusy && outstanding == 17'd0 &&
                    seen_aw && seen_b && !fault && !aw_fire && !b_fire) begin
                    active <= 1'b0;
                    transfer_committed <= 1'b1;
                end
            end else if (aw_fire || b_fire) begin
                fault <= 1'b1;
            end
        end
    end
endmodule
