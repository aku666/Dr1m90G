// Assert when async_resetn falls; release after two local clock edges.
// Instantiate separately for each clock domain that consumes the output.
module fdma_frame_reset_sync (
    input  wire clk,
    input  wire async_resetn,
    output wire frame_resetn
);
    (* async_reg = "true" *) reg [1:0] release_pipe = 2'b00;

    always @(posedge clk or negedge async_resetn) begin
        if (!async_resetn)
            release_pipe <= 2'b00;
        else
            release_pipe <= {release_pipe[0], 1'b1};
    end

    assign frame_resetn = release_pipe[1];
endmodule
