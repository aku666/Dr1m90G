/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2021/10/15
*Module Name:system_wrapper
*File Name:system_wrapper.v
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) _i input
*2) _o output
*3) _n activ low
*4) _dg debug signal 
*5) _r delay or register
*6) _s state mechine
*********************************************************************/
`timescale 1 ps / 1 ps

module system_wrapper
(
inout [14:0]DDR_addr,
inout [2:0]DDR_ba,
inout DDR_cas_n,
inout DDR_ck_n,
inout DDR_ck_p,
inout DDR_cke,
inout DDR_cs_n,
inout [3:0]DDR_dm,
inout [31:0]DDR_dq,
inout [3:0]DDR_dqs_n,
inout [3:0]DDR_dqs_p,
inout DDR_odt,
inout DDR_ras_n,
inout DDR_reset_n,
inout DDR_we_n,
inout FIXED_IO_ddr_vrn,
inout FIXED_IO_ddr_vrp,
inout [53:0]FIXED_IO_mio,
inout FIXED_IO_ps_clk,
inout FIXED_IO_ps_porb,
inout FIXED_IO_ps_srstb

);
wire [31:0] FDMA_S_0_fdma_raddr;
wire        FDMA_S_0_fdma_rareq;
wire        FDMA_S_0_fdma_rbusy;
wire [31:0] FDMA_S_0_fdma_rdata;
wire        FDMA_S_0_fdma_rready;
wire [15:0] FDMA_S_0_fdma_rsize;
wire        FDMA_S_0_fdma_rvalid;
wire [31:0] FDMA_S_0_fdma_waddr;
wire        FDMA_S_0_fdma_wareq;
wire        FDMA_S_0_fdma_wbusy;
wire [31:0] FDMA_S_0_fdma_wdata;
wire        FDMA_S_0_fdma_wready;
wire [15:0] FDMA_S_0_fdma_wsize;
wire        FDMA_S_0_fdma_wvalid;
wire [31:0] FDMA_S_1_fdma_raddr;
wire        FDMA_S_1_fdma_rareq;
wire        FDMA_S_1_fdma_rbusy;
wire [31:0] FDMA_S_1_fdma_rdata;
wire        FDMA_S_1_fdma_rready;
wire [15:0] FDMA_S_1_fdma_rsize;
wire        FDMA_S_1_fdma_rvalid;
wire [31:0] FDMA_S_1_fdma_waddr;
wire        FDMA_S_1_fdma_wareq;
wire        FDMA_S_1_fdma_wbusy;
wire [31:0] FDMA_S_1_fdma_wdata;
wire        FDMA_S_1_fdma_wready;
wire [15:0] FDMA_S_1_fdma_wsize;
wire        FDMA_S_1_fdma_wvalid;
wire [31:0] FDMA_S_2_fdma_raddr;
wire        FDMA_S_2_fdma_rareq;
wire        FDMA_S_2_fdma_rbusy;
wire [31:0] FDMA_S_2_fdma_rdata;
wire        FDMA_S_2_fdma_rready;
wire [15:0] FDMA_S_2_fdma_rsize;
wire        FDMA_S_2_fdma_rvalid;
wire [31:0] FDMA_S_2_fdma_waddr;
wire        FDMA_S_2_fdma_wareq;
wire        FDMA_S_2_fdma_wbusy;
wire [31:0] FDMA_S_2_fdma_wdata;
wire        FDMA_S_2_fdma_wready;
wire [15:0] FDMA_S_2_fdma_wsize;
wire        FDMA_S_2_fdma_wvalid;
wire [31:0] FDMA_S_3_fdma_raddr;
wire        FDMA_S_3_fdma_rareq;
wire        FDMA_S_3_fdma_rbusy;
wire [31:0] FDMA_S_3_fdma_rdata;
wire        FDMA_S_3_fdma_rready;
wire [15:0] FDMA_S_3_fdma_rsize;
wire        FDMA_S_3_fdma_rvalid;
wire [31:0] FDMA_S_3_fdma_waddr;
wire        FDMA_S_3_fdma_wareq;
wire        FDMA_S_3_fdma_wbusy;
wire [31:0] FDMA_S_3_fdma_wdata;
wire        FDMA_S_3_fdma_wready;
wire [15:0] FDMA_S_3_fdma_wsize;
wire        FDMA_S_3_fdma_wvalid;

wire        fdma_rstn;
wire        pl_clk;

fdma_test# 
(
.TEST_MEM_SIZE   (1024*1024*400),//400MB
.FDMA_BURST_LEN  (2000),//burst 2000*32/8=8000byes  bytes every time 
.ADDR_MEM_OFFSET (32'h10000000)//start from 256MB 
)
fdma_test0
(
.ui_clk(pl_clk),
.fdma_rstn(fdma_rstn), 
.fdma_waddr(FDMA_S_0_fdma_waddr), 
.fdma_wareq(FDMA_S_0_fdma_wareq), 
.fdma_wsize(FDMA_S_0_fdma_wsize),                                     
.fdma_wbusy(FDMA_S_0_fdma_wbusy), 		
.fdma_wdata(FDMA_S_0_fdma_wdata), 
.fdma_wvalid(FDMA_S_0_fdma_wvalid), 
.fdma_wready(FDMA_S_0_fdma_wready), 

.fdma_raddr(FDMA_S_0_fdma_raddr), 
.fdma_rareq(FDMA_S_0_fdma_rareq), 
.fdma_rsize(FDMA_S_0_fdma_rsize),                                      
.fdma_rbusy(FDMA_S_0_fdma_rbusy), 			
.fdma_rdata(FDMA_S_0_fdma_rdata), 
.fdma_rvalid(FDMA_S_0_fdma_rvalid), 
.fdma_rready(FDMA_S_0_fdma_rready)
);

fdma_test# 
(
.TEST_MEM_SIZE   (1024*1024*400),//400MB
.FDMA_BURST_LEN  (2000),//burst 2000*32/8=8000byes  bytes every time 
.ADDR_MEM_OFFSET (32'h10000000)//start from 256MB 
)
fdma_test
(
.ui_clk(pl_clk),
.fdma_rstn(fdma_rstn), 
.fdma_waddr(FDMA_S_1_fdma_waddr), 
.fdma_wareq(FDMA_S_1_fdma_wareq), 
.fdma_wsize(FDMA_S_1_fdma_wsize),                                     
.fdma_wbusy(FDMA_S_1_fdma_wbusy), 		
.fdma_wdata(FDMA_S_1_fdma_wdata), 
.fdma_wvalid(FDMA_S_1_fdma_wvalid), 
.fdma_wready(FDMA_S_1_fdma_wready), 

.fdma_raddr(FDMA_S_1_fdma_raddr), 
.fdma_rareq(FDMA_S_1_fdma_rareq), 
.fdma_rsize(FDMA_S_1_fdma_rsize),                                      
.fdma_rbusy(FDMA_S_1_fdma_rbusy), 			
.fdma_rdata(FDMA_S_1_fdma_rdata), 
.fdma_rvalid(FDMA_S_1_fdma_rvalid), 
.fdma_rready(FDMA_S_1_fdma_rready)
);

fdma_test# 
(
.TEST_MEM_SIZE   (1024*1024*400),//400MB
.FDMA_BURST_LEN  (2000),//burst 2000*32/8=8000byes  bytes every time 
.ADDR_MEM_OFFSET (32'h10000000)//start from 256MB 
)
fdma_test2
(
.ui_clk(pl_clk),
.fdma_rstn(fdma_rstn), 
.fdma_waddr(FDMA_S_2_fdma_waddr), 
.fdma_wareq(FDMA_S_2_fdma_wareq), 
.fdma_wsize(FDMA_S_2_fdma_wsize),                                     
.fdma_wbusy(FDMA_S_2_fdma_wbusy), 		
.fdma_wdata(FDMA_S_2_fdma_wdata), 
.fdma_wvalid(FDMA_S_2_fdma_wvalid), 
.fdma_wready(FDMA_S_2_fdma_wready), 

.fdma_raddr(FDMA_S_2_fdma_raddr), 
.fdma_rareq(FDMA_S_2_fdma_rareq), 
.fdma_rsize(FDMA_S_2_fdma_rsize),                                      
.fdma_rbusy(FDMA_S_2_fdma_rbusy), 			
.fdma_rdata(FDMA_S_2_fdma_rdata), 
.fdma_rvalid(FDMA_S_2_fdma_rvalid), 
.fdma_rready(FDMA_S_2_fdma_rready)
);

fdma_test#
(
.TEST_MEM_SIZE   (1024*1024*400),//400MB
.FDMA_BURST_LEN  (2000),//burst 2000*32/8=8000byes  bytes every time 
.ADDR_MEM_OFFSET (32'h10000000)//start from 256MB 
)
fdma_test3
(
.ui_clk(pl_clk),
.fdma_rstn(fdma_rstn), 
.fdma_waddr(FDMA_S_3_fdma_waddr), 
.fdma_wareq(FDMA_S_3_fdma_wareq), 
.fdma_wsize(FDMA_S_3_fdma_wsize),                                     
.fdma_wbusy(FDMA_S_3_fdma_wbusy), 		
.fdma_wdata(FDMA_S_3_fdma_wdata), 
.fdma_wvalid(FDMA_S_3_fdma_wvalid), 
.fdma_wready(FDMA_S_3_fdma_wready), 

.fdma_raddr(FDMA_S_3_fdma_raddr), 
.fdma_rareq(FDMA_S_3_fdma_rareq), 
.fdma_rsize(FDMA_S_3_fdma_rsize),                                      
.fdma_rbusy(FDMA_S_3_fdma_rbusy), 			
.fdma_rdata(FDMA_S_3_fdma_rdata), 
.fdma_rvalid(FDMA_S_3_fdma_rvalid), 
.fdma_rready(FDMA_S_3_fdma_rready)
);

system system_i
(
.DDR_addr(DDR_addr),
.DDR_ba(DDR_ba),
.DDR_cas_n(DDR_cas_n),
.DDR_ck_n(DDR_ck_n),
.DDR_ck_p(DDR_ck_p),
.DDR_cke(DDR_cke),
.DDR_cs_n(DDR_cs_n),
.DDR_dm(DDR_dm),
.DDR_dq(DDR_dq),
.DDR_dqs_n(DDR_dqs_n),
.DDR_dqs_p(DDR_dqs_p),
.DDR_odt(DDR_odt),
.DDR_ras_n(DDR_ras_n),
.DDR_reset_n(DDR_reset_n),
.DDR_we_n(DDR_we_n),
.FIXED_IO_ddr_vrn(FIXED_IO_ddr_vrn),
.FIXED_IO_ddr_vrp(FIXED_IO_ddr_vrp),
.FIXED_IO_mio(FIXED_IO_mio),
.FIXED_IO_ps_clk(FIXED_IO_ps_clk),
.FIXED_IO_ps_porb(FIXED_IO_ps_porb),
.FIXED_IO_ps_srstb(FIXED_IO_ps_srstb),
.FDMA_S_0_fdma_raddr(FDMA_S_0_fdma_raddr),
.FDMA_S_0_fdma_rareq(FDMA_S_0_fdma_rareq),
.FDMA_S_0_fdma_rbusy(FDMA_S_0_fdma_rbusy),
.FDMA_S_0_fdma_rdata(FDMA_S_0_fdma_rdata),
.FDMA_S_0_fdma_rready(FDMA_S_0_fdma_rready),
.FDMA_S_0_fdma_rsize(FDMA_S_0_fdma_rsize),
.FDMA_S_0_fdma_rvalid(FDMA_S_0_fdma_rvalid),
.FDMA_S_0_fdma_waddr(FDMA_S_0_fdma_waddr),
.FDMA_S_0_fdma_wareq(FDMA_S_0_fdma_wareq),
.FDMA_S_0_fdma_wbusy(FDMA_S_0_fdma_wbusy),
.FDMA_S_0_fdma_wdata(FDMA_S_0_fdma_wdata),
.FDMA_S_0_fdma_wready(FDMA_S_0_fdma_wready),
.FDMA_S_0_fdma_wsize(FDMA_S_0_fdma_wsize),
.FDMA_S_0_fdma_wvalid(FDMA_S_0_fdma_wvalid),
.FDMA_S_1_fdma_raddr(FDMA_S_1_fdma_raddr),
.FDMA_S_1_fdma_rareq(FDMA_S_1_fdma_rareq),
.FDMA_S_1_fdma_rbusy(FDMA_S_1_fdma_rbusy),
.FDMA_S_1_fdma_rdata(FDMA_S_1_fdma_rdata),
.FDMA_S_1_fdma_rready(FDMA_S_1_fdma_rready),
.FDMA_S_1_fdma_rsize(FDMA_S_1_fdma_rsize),
.FDMA_S_1_fdma_rvalid(FDMA_S_1_fdma_rvalid),
.FDMA_S_1_fdma_waddr(FDMA_S_1_fdma_waddr),
.FDMA_S_1_fdma_wareq(FDMA_S_1_fdma_wareq),
.FDMA_S_1_fdma_wbusy(FDMA_S_1_fdma_wbusy),
.FDMA_S_1_fdma_wdata(FDMA_S_1_fdma_wdata),
.FDMA_S_1_fdma_wready(FDMA_S_1_fdma_wready),
.FDMA_S_1_fdma_wsize(FDMA_S_1_fdma_wsize),
.FDMA_S_1_fdma_wvalid(FDMA_S_1_fdma_wvalid),
.FDMA_S_2_fdma_raddr(FDMA_S_2_fdma_raddr),
.FDMA_S_2_fdma_rareq(FDMA_S_2_fdma_rareq),
.FDMA_S_2_fdma_rbusy(FDMA_S_2_fdma_rbusy),
.FDMA_S_2_fdma_rdata(FDMA_S_2_fdma_rdata),
.FDMA_S_2_fdma_rready(FDMA_S_2_fdma_rready),
.FDMA_S_2_fdma_rsize(FDMA_S_2_fdma_rsize),
.FDMA_S_2_fdma_rvalid(FDMA_S_2_fdma_rvalid),
.FDMA_S_2_fdma_waddr(FDMA_S_2_fdma_waddr),
.FDMA_S_2_fdma_wareq(FDMA_S_2_fdma_wareq),
.FDMA_S_2_fdma_wbusy(FDMA_S_2_fdma_wbusy),
.FDMA_S_2_fdma_wdata(FDMA_S_2_fdma_wdata),
.FDMA_S_2_fdma_wready(FDMA_S_2_fdma_wready),
.FDMA_S_2_fdma_wsize(FDMA_S_2_fdma_wsize),
.FDMA_S_2_fdma_wvalid(FDMA_S_2_fdma_wvalid),
.FDMA_S_3_fdma_raddr(FDMA_S_3_fdma_raddr),
.FDMA_S_3_fdma_rareq(FDMA_S_3_fdma_rareq),
.FDMA_S_3_fdma_rbusy(FDMA_S_3_fdma_rbusy),
.FDMA_S_3_fdma_rdata(FDMA_S_3_fdma_rdata),
.FDMA_S_3_fdma_rready(FDMA_S_3_fdma_rready),
.FDMA_S_3_fdma_rsize(FDMA_S_3_fdma_rsize),
.FDMA_S_3_fdma_rvalid(FDMA_S_3_fdma_rvalid),
.FDMA_S_3_fdma_waddr(FDMA_S_3_fdma_waddr),
.FDMA_S_3_fdma_wareq(FDMA_S_3_fdma_wareq),
.FDMA_S_3_fdma_wbusy(FDMA_S_3_fdma_wbusy),
.FDMA_S_3_fdma_wdata(FDMA_S_3_fdma_wdata),
.FDMA_S_3_fdma_wready(FDMA_S_3_fdma_wready),
.FDMA_S_3_fdma_wsize(FDMA_S_3_fdma_wsize),
.FDMA_S_3_fdma_wvalid(FDMA_S_3_fdma_wvalid),
.pl_clk(pl_clk),
.fdma_rstn(fdma_rstn)
);
endmodule
