/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2024/06/17
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) _n activ low
*5) _dg debug signal 
*6) _r delay or register
*7) _s state mechine
*********************************************************************/
`timescale 1ns / 1ns

module fdma_test#
(
parameter TEST_MEM_SIZE   = 32'd536800000,
parameter FDMA_BURST_LEN  = 16'd1000,
parameter ADDR_MEM_OFFSET = 1024*1024*50
)
(
input  wire             ui_clk,
input  wire             fdma_rstn, 
output wire    [31: 0]  fdma_waddr,		//synthesis keep  
output reg          	fdma_wareq,		//synthesis keep  
output wire    [15: 0]  fdma_wsize,  	//synthesis keep                                     
input  wire             fdma_wbusy,		//synthesis keep  	
output reg 	   [63: 0]  fdma_wdata,		//synthesis keep  
input  wire             fdma_wvalid,	//synthesis keep  
output wire             fdma_wready,	//synthesis keep  

output wire    [31: 0]  fdma_raddr,		//synthesis keep  
output reg          	fdma_rareq,		//synthesis keep  
output wire    [15: 0]  fdma_rsize, 	//synthesis keep                                      
input  wire             fdma_rbusy,		//synthesis keep  		
input  wire    [63: 0]  fdma_rdata,		//synthesis keep  
input  wire             fdma_rvalid,	//synthesis keep  
output wire             fdma_rready		//synthesis keep  
);
  
localparam WRITE1 = 0;
localparam WRITE2 = 1;
localparam READ1  = 2;
localparam READ2  = 3;

reg [31: 0] fdma_waddr_r;
reg [16 :0] fdma_rcnt = 0;//synthesis keep  
reg [1  :0] T_S = 0;

assign fdma_waddr = fdma_waddr_r + ADDR_MEM_OFFSET;
assign fdma_raddr = fdma_waddr;

assign fdma_wsize = FDMA_BURST_LEN;
assign fdma_rsize = FDMA_BURST_LEN;

reg [10:0] rst_cnt = 0;

always @(posedge ui_clk)
    if(fdma_rstn == 1'b0)begin
        rst_cnt <=0;
    end 
    else begin
        if(rst_cnt[10] == 1'b0)
            rst_cnt <= rst_cnt + 1'b1;
        else 
            rst_cnt <= rst_cnt;
    end

assign fdma_wready = 1'b1;
assign fdma_rready = 1'b1;

always @(posedge ui_clk)begin
    if(rst_cnt[10] == 1'b0)begin
        T_S <=0;   
        fdma_wareq  	<= 1'b0; 
        fdma_rareq  	<= 1'b0; 
        fdma_wdata		<=0;
        fdma_waddr_r 	<=0;       
    end 
    else begin
        case(T_S)      
        WRITE1:begin
            if(fdma_waddr_r>TEST_MEM_SIZE) fdma_waddr_r<=0; 
                if(!fdma_wbusy)begin
                    fdma_wareq  <= 1'b1; 
                    fdma_wdata  <= 0;
                end
                if(fdma_wareq&&fdma_wbusy)begin
                    fdma_wareq  <= 1'b0; 
                    T_S         <= WRITE2;
                end
        end
        WRITE2:begin
            if(!fdma_wbusy) begin
                 T_S <= READ1;
                 fdma_wdata  <= 32'd0;
            end 
            else if(fdma_wvalid) begin
                fdma_wdata <= fdma_wdata + 1'b1;
            end
        end
        
        READ1:begin
            if(!fdma_rbusy)begin
                fdma_rareq  <= 1'b1; 
                fdma_rcnt   <= 0;
            end
            if(fdma_rareq&&fdma_rbusy)begin
                 fdma_rareq  <= 1'b0; 
                 T_S         <= READ2;
            end 
        end
        READ2:begin
            if(!fdma_rbusy) begin
                 T_S <= WRITE1;
                 fdma_rcnt  <= 32'd0;
                 fdma_waddr_r  <= fdma_waddr_r + FDMA_BURST_LEN*8;//64/8=8
            end 
            else if(fdma_rvalid) begin
                fdma_rcnt <= fdma_rcnt + 1'b1;
            end
        end   
        default:
            T_S <= WRITE1;     
        endcase
    end
  end
  
reg [15:0]  fdma_rcnt_r;	//synthesis keep  
reg [15:0]  fdma_rdata_r;	//synthesis keep  
reg 		fdma_rvalid_r;	//synthesis keep  
always @(posedge ui_clk)begin
	fdma_rdata_r 	<= fdma_rdata[15:0];
    fdma_rvalid_r 	<= fdma_rvalid;
    fdma_rcnt_r		<= fdma_rcnt;
end
wire test_error;//synthesis keep  
assign test_error = ((fdma_rready&&fdma_rvalid_r) && (fdma_rcnt_r[15:0] != fdma_rdata_r[15:0]));


    
    
endmodule
