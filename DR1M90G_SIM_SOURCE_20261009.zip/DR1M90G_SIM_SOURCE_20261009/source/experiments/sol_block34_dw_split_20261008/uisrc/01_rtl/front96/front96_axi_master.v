// Fixed signed16 C16/112 -> PW96 -> DW96 C96/56. Intermediate rows stay on chip.
// Parameter records: 96*160B PW, then 96*32B DW. AXI3 <=16 beats /4KiB.
module front96_axi_master(
 input wire clk,resetn,start,input wire [31:0] input_base,parameter_base,output_base,
 output wire busy,output reg done,fault,
 output wire [31:0] araddr,output wire [7:0] arlen,
 output wire [2:0] arsize,output wire [1:0] arburst,
 output wire arvalid,input wire arready,
 input wire [63:0] rdata,input wire [1:0] rresp,input wire rlast,rvalid,output wire rready,
 output wire [31:0] awaddr,output wire [7:0] awlen,
 output wire [2:0] awsize,output wire [1:0] awburst,
 output wire awvalid,input wire awready,
 output reg [63:0] wdata,output wire [7:0] wstrb,output wire wlast,wvalid,input wire wready,
 input wire [1:0] bresp,input wire bvalid,output wire bready
);
 localparam IDLE=0,P_AR=1,P_R=2,D_AR=3,D_R=4,I_AR=5,I_R=6,
  CORE_START=7,COMPUTE=8,O_AW=9,O_W=10,O_B=11,FAILED=12;
 reg [3:0] state;
 reg [31:0] ib,pb,ob;
 reg [2:0] group_index;
 reg [3:0] parameter_channel,input_channel,output_channel;
 reg [6:0] row;
 reg [4:0] beat,burst_end;
 (* ram_style="distributed" *) reg [7:0] results[0:895];
 wire p_read=state==P_AR || state==P_R;
 wire d_read=state==D_AR || state==D_R;
 wire [31:0] global_parameter=group_index*32'd16+parameter_channel;
 wire [31:0] read_address=p_read ? pb+global_parameter*32'd160+beat*32'd8 :
  d_read ? pb+32'd15360+global_parameter*32'd32+beat*32'd8 :
  ib+input_channel*32'd25088+row*32'd224+beat*32'd8;
 wire [9:0] read_page=10'd512-{1'b0,read_address[11:3]};
 wire [5:0] read_remaining=(p_read?6'd20:d_read?6'd4:6'd28)-beat;
 wire [5:0] read_limit=read_remaining>16?6'd16:read_remaining;
 wire [4:0] read_count=read_page<read_limit?read_page[4:0]:read_limit[4:0];
 wire [31:0] write_address=ob+(group_index*32'd16+output_channel)*32'd3136+(row>>1)*32'd56+beat*32'd8;
 wire [9:0] write_page=10'd512-{1'b0,write_address[11:3]};
 wire [4:0] write_count=write_page<(7-beat)?write_page[4:0]:7-beat;
 wire core_busy,core_done,core_valid;
 wire [3:0] core_channel;wire [5:0] core_row,core_column;wire [7:0] core_data;
 wire [12:0] input_index=input_channel*32'd112+beat*32'd4;
 front96_group_core core(clk,resetn,state==CORE_START,row,
  state==I_R && rvalid && beat<28,input_index,rdata,
  state==P_R && rvalid && beat<20,{4'b0,parameter_channel},beat,rdata,
  state==D_R && rvalid && beat<4,parameter_channel,beat[1:0],rdata,
  core_busy,core_done,core_valid,state==COMPUTE,core_channel,core_row,core_column,core_data);
 assign busy=state!=IDLE;
 assign araddr=read_address;assign arlen=read_count-1'b1;
 assign arsize=3;assign arburst=1;
 assign arvalid=state==P_AR || state==D_AR || state==I_AR;
 assign rready=state==P_R || state==D_R || state==I_R;
 assign awaddr=write_address;assign awlen=write_count-1'b1;
 assign awsize=3;assign awburst=1;assign awvalid=state==O_AW;
 assign wstrb=8'hff;assign wvalid=state==O_W;assign wlast=beat==burst_end;
 assign bready=state==O_B;
 integer j;
 always @* begin
  wdata=0;
  for(j=0;j<8;j=j+1) if(beat<7) wdata[j*8+:8]=results[output_channel*32'd56+beat*32'd8+j];
 end
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;fault<=0;group_index<=0;row<=0;beat<=0;burst_end<=0;
   parameter_channel<=0;input_channel<=0;output_channel<=0;
  end else case(state)
   IDLE:if(start) begin
    done<=0;fault<=0;
    if((input_base[5:0]|parameter_base[5:0]|output_base[5:0])!=0) begin fault<=1;state<=FAILED;end
    else begin
     ib<=input_base;pb<=parameter_base;ob<=output_base;
     group_index<=0;row<=0;beat<=0;parameter_channel<=0;input_channel<=0;output_channel<=0;state<=P_AR;
    end
   end
   P_AR,D_AR,I_AR:if(arready) begin
    burst_end<=beat+read_count-1'b1;state<=state==P_AR?P_R:state==D_AR?D_R:I_R;
   end
   P_R,D_R,I_R:if(rvalid) begin
    if(rresp!=0 || (rlast!=(beat==burst_end)))fault<=1;
    if(rlast) begin
     if(fault || rresp!=0 || beat!=burst_end)state<=FAILED;
     else if(beat<(state==P_R?19:state==D_R?3:27)) begin
      beat<=beat+1'b1;state<=state==P_R?P_AR:state==D_R?D_AR:I_AR;
     end else begin
      beat<=0;
      if(state==P_R)state<=D_AR;
      else if(state==D_R)begin
       if(parameter_channel<15)begin parameter_channel<=parameter_channel+1'b1;state<=P_AR;end
       else begin input_channel<=0;state<=I_AR;end
      end else if(input_channel<15)begin input_channel<=input_channel+1'b1;state<=I_AR;end
      else begin input_channel<=0;state<=CORE_START;end
     end
    end else if(beat<31)beat<=beat+1'b1;
   end
   CORE_START:state<=COMPUTE;
   COMPUTE:begin
    if(core_valid)results[core_channel*32'd56+core_column]<=core_data;
    if(core_done)begin
     if(row[0])begin output_channel<=0;beat<=0;state<=O_AW;end
     else begin row<=row+1'b1;input_channel<=0;beat<=0;state<=I_AR;end
    end
   end
   O_AW:if(awready)begin burst_end<=beat+write_count-1'b1;state<=O_W;end
   O_W:if(wready)begin if(beat==burst_end)state<=O_B;else beat<=beat+1'b1;end
   O_B:if(bvalid)begin
    if(bresp!=0)begin fault<=1;state<=FAILED;end
    else if(beat<6)begin beat<=beat+1'b1;state<=O_AW;end
    else if(output_channel<15)begin output_channel<=output_channel+1'b1;beat<=0;state<=O_AW;end
    else if(row<111)begin row<=row+1'b1;input_channel<=0;beat<=0;state<=I_AR;end
    else if(group_index<5)begin group_index<=group_index+1'b1;row<=0;beat<=0;parameter_channel<=0;state<=P_AR;end
    else begin done<=1;state<=IDLE;end
   end
   FAILED:begin end
   default:state<=IDLE;
  endcase
 end
endmodule
