// Fixed PW16->16 group followed by C16 DW3x3 stride2. Six groups cover C96.
// Three packed row banks, one synchronous read per bank, no PW DDR image.
module front96_group_core(
 input wire clk,resetn,start,input wire [6:0] row_index,
 input wire input_write,input wire [12:0] input_address,input wire [63:0] input_data,
 input wire parameter_write,input wire [7:0] parameter_output,
 input wire [4:0] parameter_beat,input wire [63:0] parameter_data,
 input wire dw_parameter_write,input wire [3:0] dw_parameter_channel,
 input wire [1:0] dw_parameter_beat,input wire [63:0] dw_parameter_data,
 output wire busy,output reg done,
 output wire out_valid,input wire out_ready,
 output wire [3:0] out_channel,output wire [5:0] out_row,out_column,
 output wire [7:0] out_data
);
 localparam IDLE=0,PW_START=1,PW_WAIT=2,DW_R0=3,DW_R1=4,DW_PATCH=5,DW_SEND=6,DW_DRAIN=7;
 reg [2:0] state;
 reg [6:0] row;
 reg [3:0] channel;
 reg [5:0] column;
 reg [9:0] received;
 wire pw_busy,pw_done,pw_valid;
 wire [7:0] pw_channel,pw_data;
 wire [6:0] pw_column;
 pointwise_expand_row #(.INPUTS(16),.OUTPUTS(16),.PIXEL_BITS(16),.INPUT_ZERO(0)) pw(
  clk,resetn,state==PW_START,input_write,input_address,input_data,
  parameter_write,parameter_output,parameter_beat,parameter_data,
  pw_busy,pw_done,pw_valid,state==PW_WAIT,pw_channel,pw_column,pw_data);
 wire [31:0] row_read[0:2];
 wire [31:0] rd0=row_read[0],rd1=row_read[1],rd2=row_read[2];
 reg [31:0] first0,first1,first2;
 reg [71:0] weights[0:15];
 reg signed [31:0] biases[0:15];
 reg [31:0] multipliers[0:15];
 reg [71:0] patch;
 wire [7:0] left_column=column==0?0:{column,1'b0}-1'b1;
 wire cross_word=column!=0 && left_column[1:0]==3;
 wire [8:0] read_address=channel*28+(left_column>>2)+((state==DW_R1 && cross_word)?1:0);
 wire [8:0] write_address=pw_channel*28+(pw_column>>2);
 genvar bank_index,lane;
 generate for(bank_index=0;bank_index<3;bank_index=bank_index+1)begin: row_bank
  for(lane=0;lane<4;lane=lane+1)begin: byte_lane
   DR1_LOGIC_DRAM #(.DATA_WIDTH_W(8),.DATA_WIDTH_R(8),.ADDR_WIDTH_W(9),.ADDR_WIDTH_R(9),
    .DATA_DEPTH_W(512),.DATA_DEPTH_R(512),.READREG("ENABLE"),.RESETMODE("SYNC")) memory(
    .di(pw_data),.waddr(write_address),.we(pw_valid && state==PW_WAIT && row%3==bank_index && pw_column[1:0]==lane),
    .wclk(clk),.rclk(clk),.rrst(!resetn),.rce(state==DW_R0 || state==DW_R1),
    .raddr(read_address),.rdoq(row_read[bank_index][lane*8+:8]),.rdo());
  end
 end endgenerate
 always @(posedge clk) begin
  if(dw_parameter_write) case(dw_parameter_beat)
   0:weights[dw_parameter_channel][63:0]<=dw_parameter_data;
   1:begin weights[dw_parameter_channel][71:64]<=dw_parameter_data[7:0];biases[dw_parameter_channel]<=dw_parameter_data[63:32];end
   2:multipliers[dw_parameter_channel]<=dw_parameter_data[31:0];
  endcase
 end
 // Patch assembly reads registers, after the three memory ports have settled.
 reg [31:0] first_word,next_word;
 reg [71:0] next_patch;
 integer y,x,byte_index,bank;
 always @* begin
  next_patch=0;first_word=0;next_word=0;byte_index=0;bank=0;
  for(y=0;y<3;y=y+1) begin
   bank=(row+1+y)%3;
   case(bank)
    0:begin first_word=first0;next_word=rd0;end
    1:begin first_word=first1;next_word=rd1;end
    2:begin first_word=first2;next_word=rd2;end
   endcase
   for(x=0;x<3;x=x+1) begin
    byte_index=column==0?x-1:left_column[1:0]+x;
    if(!(row==1 && y==0) && byte_index>=0)
     next_patch[(y*3+x)*8+:8]=byte_index<4?first_word[byte_index*8+:8]:next_word[(byte_index-4)*8+:8];
   end
  end
 end
 wire dw_ready,dw_valid;
 dw3x3_patch_core dw(clk,resetn,state==DW_SEND,dw_ready,
  patch,weights[channel],8'd0,8'd128,biases[channel],multipliers[channel],
  5'd30,8'd0,8'd0,8'd255,dw_valid,state>=DW_R0 && out_ready,out_data);
 assign busy=state!=IDLE;
 assign out_valid=state>=DW_R0 && dw_valid;
 assign out_channel=received/56;assign out_row=row>>1;assign out_column=received%56;
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;row<=0;channel<=0;column<=0;received<=0;patch<=0;
   first0<=0;first1<=0;first2<=0;
  end else begin
   case(state)
    IDLE:if(start) begin done<=0;row<=row_index;state<=PW_START;end
    PW_START:state<=PW_WAIT;
    PW_WAIT:if(pw_done) begin
     if(row[0]) begin channel<=0;column<=0;received<=0;state<=DW_R0;end
     else begin done<=1;state<=IDLE;end
    end
    DW_R0:state<=DW_R1;
    DW_R1:begin first0<=rd0;first1<=rd1;first2<=rd2;state<=DW_PATCH;end
    DW_PATCH:begin patch<=next_patch;state<=DW_SEND;end
    DW_SEND:if(dw_ready) begin
     if(column<55) begin column<=column+1'b1;state<=DW_R0;end
     else if(channel<15) begin column<=0;channel<=channel+1'b1;state<=DW_R0;end
     else state<=DW_DRAIN;
    end
    DW_DRAIN:begin end
    default:state<=IDLE;
   endcase
   if(out_valid && out_ready) begin
    received<=received+1'b1;
    if(received==895) begin done<=1;state<=IDLE;end
   end
  end
 end
endmodule
