// Fixed row expansion: overlap the next dot product with current requantization.
// One pending accumulator bank is enough; stalls retain both banks and tags.
module pointwise_expand_row #(
 parameter ROW_WIDTH=112,INPUTS=16,OUTPUTS=96,PIXEL_BITS=16,INPUT_ZERO=0
)(
 input wire clk,resetn,start,
 input wire input_write,input wire [12:0] input_address,input wire [63:0] input_data,
 input wire parameter_write,input wire [7:0] parameter_output,
 input wire [4:0] parameter_beat,input wire [63:0] parameter_data,
 output wire busy,output reg done,
 output wire out_valid,input wire out_ready,
 output wire [7:0] out_channel,
 output wire [$clog2(ROW_WIDTH)-1:0] out_column,output wire [7:0] out_data
);
 localparam IDLE=0,INIT=1,DOT=2,PUBLISH=3,DRAIN=4;
 reg [2:0] state;
 reg [3:0] group_index,qgroup;
 reg [$clog2(ROW_WIDTH)-1:0] column,qcolumn;
 reg [7:0] issue,consumed;
 reg product_valid,qactive;
 reg [4:0] qissued,qreceived;
 localparam PIXELS_PER_WORD=64/PIXEL_BITS;
 // The loader supplies aligned whole words. One write port avoids a replicated
 // multi-write memory when four signed16 pixels arrive in the same cycle.
 wire signed [8:0] weight_selected[0:15];
 wire [31:0] bias_selected[0:15],multiplier_selected[0:15];
 genvar coefficient_lane;
 generate if(INPUTS==16 && OUTPUTS==16)begin: fixed_group
  // Constant coefficient banks avoid oversized memories from the generic
  // group address. Each lane has exactly sixteen weights and one bias/scale.
  for(coefficient_lane=0;coefficient_lane<16;coefficient_lane=coefficient_lane+1)begin: coefficient
   reg [127:0] weight;
   reg [31:0] bias,multiplier;
   always @(posedge clk)if(parameter_write && parameter_output==coefficient_lane)case(parameter_beat)
    0:weight[63:0]<=parameter_data;
    1:weight[127:64]<=parameter_data;
    18:begin bias<=parameter_data[31:0];multiplier<=parameter_data[63:32];end
   endcase
   assign weight_selected[coefficient_lane]=$signed({1'b0,weight[issue[3:0]*8+:8]})-9'sd128;
   assign bias_selected[coefficient_lane]=bias;
   assign multiplier_selected[coefficient_lane]=multiplier;
  end
 end else begin: grouped_coefficients
  (* ram_style="distributed" *) reg [7:0] weights[0:15][0:(OUTPUTS/16)*INPUTS-1];
  (* ram_style="distributed" *) reg signed [31:0] biases[0:15][0:OUTPUTS/16-1];
  (* ram_style="distributed" *) reg [31:0] multipliers[0:15][0:OUTPUTS/16-1];
  integer b;
  always @(posedge clk)if(parameter_write)begin
   for(b=0;b<8;b=b+1)if(parameter_beat*8+b<INPUTS)
    weights[parameter_output[3:0]][parameter_output[7:4]*INPUTS+parameter_beat*8+b]<=parameter_data[b*8+:8];
   if(parameter_beat==18)begin
    biases[parameter_output[3:0]][parameter_output[7:4]]<=parameter_data[31:0];
    multipliers[parameter_output[3:0]][parameter_output[7:4]]<=parameter_data[63:32];
   end
  end
  for(coefficient_lane=0;coefficient_lane<16;coefficient_lane=coefficient_lane+1)begin: lane
   assign weight_selected[coefficient_lane]=$signed({1'b0,weights[coefficient_lane][group_index*INPUTS+issue]})-9'sd128;
   assign bias_selected[coefficient_lane]=biases[coefficient_lane][group_index];
   assign multiplier_selected[coefficient_lane]=multipliers[coefficient_lane][group_index];
  end
 end endgenerate
 reg signed [PIXEL_BITS+9:0] products[0:15];
 reg signed [39:0] accum[0:15];
 reg signed [31:0] qaccum[0:15];
 reg [31:0] qmult[0:15];
 localparam PIXEL_ADDR=$clog2(INPUTS*ROW_WIDTH/PIXELS_PER_WORD);
 wire [PIXEL_ADDR-1:0] pixel_read_address=issue*(ROW_WIDTH/PIXELS_PER_WORD)+column/PIXELS_PER_WORD;
 wire [PIXEL_ADDR-1:0] pixel_write_address=input_address/PIXELS_PER_WORD;
 wire [63:0] pixel_word;
 // An explicit async DRAM port preserves the dot-product pipeline latency.
 // Automatic mapping used 32 ERAM blocks for this fixed 3.5 KiB row.
 DR1_LOGIC_DRAM #(.DATA_WIDTH_W(64),.DATA_WIDTH_R(64),
  .ADDR_WIDTH_W(PIXEL_ADDR),.ADDR_WIDTH_R(PIXEL_ADDR),
  .DATA_DEPTH_W(2**PIXEL_ADDR),.DATA_DEPTH_R(2**PIXEL_ADDR),
  .READREG("DISABLE"),.RESETMODE("SYNC")) input_row(
  .di(input_data),.waddr(pixel_write_address),.we(input_write),.wclk(clk),
  .rclk(clk),.rrst(!resetn),.rce(1'b1),.raddr(pixel_read_address),
  .rdo(pixel_word),.rdoq());
 wire [PIXEL_BITS-1:0] pixel_raw=pixel_word[(column%PIXELS_PER_WORD)*PIXEL_BITS+:PIXEL_BITS];
 wire signed [PIXEL_BITS:0] pixel=$signed({PIXEL_BITS==16?pixel_raw[PIXEL_BITS-1]:1'b0,pixel_raw})-INPUT_ZERO;
 integer i;
 wire rqready;
 dw3x3_patch_core rounding(clk,resetn,qactive && qissued<16,rqready,
  72'b0,{9{8'd128}},8'd0,8'd128,qaccum[qissued[3:0]],
  qmult[qissued[3:0]],5'd30,8'd0,8'd0,8'd255,out_valid,out_ready,out_data);
 assign out_channel={qgroup,4'b0}+qreceived;
 assign out_column=qcolumn;
 assign busy=state!=IDLE;
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;group_index<=0;column<=0;issue<=0;consumed<=0;
   product_valid<=0;qactive<=0;qissued<=0;qreceived<=0;qgroup<=0;qcolumn<=0;
  end else begin
   if(qactive && rqready && qissued<16) qissued<=qissued+1'b1;
   if(out_valid && out_ready) begin
    qreceived<=qreceived+1'b1;
    if(qreceived==15) qactive<=0;
   end
   case(state)
    IDLE: if(start) begin done<=0;group_index<=0;column<=0;state<=INIT;end
    INIT: begin
     for(i=0;i<16;i=i+1) accum[i]<={{8{bias_selected[i][31]}},bias_selected[i]};
     issue<=0;consumed<=0;product_valid<=0;state<=DOT;
    end
    DOT: begin
     if(product_valid) begin
      for(i=0;i<16;i=i+1) accum[i]<=accum[i]+products[i];
      consumed<=consumed+1'b1;
      if(consumed==INPUTS-1) state<=PUBLISH;
     end
     product_valid<=issue<INPUTS;
     if(issue<INPUTS) begin
      for(i=0;i<16;i=i+1)
       products[i]<=pixel*weight_selected[i];
      issue<=issue+1'b1;
     end
    end
    PUBLISH: if(!qactive) begin
     for(i=0;i<16;i=i+1) begin qaccum[i]<=accum[i][31:0];qmult[i]<=multiplier_selected[i];end
     qactive<=1;qissued<=0;qreceived<=0;qgroup<=group_index;qcolumn<=column;
     if(column<ROW_WIDTH-1) begin column<=column+1'b1;state<=INIT;end
     else if(group_index<OUTPUTS/16-1) begin column<=0;group_index<=group_index+1'b1;state<=INIT;end
     else state<=DRAIN;
    end
    DRAIN: if(!qactive) begin done<=1;state<=IDLE;end
    default: state<=IDLE;
   endcase
  end
 end
endmodule
