// Fixed block3: all 3 passes consume the preceding real DDR output.
module block3_axi_chain(
input wire clk,resetn,start,
input wire [31:0] input_base,expand_parameters,depthwise_parameters,project_parameters,scratch_expand,scratch_depthwise,output_base,
output wire busy,
output reg done,fault,
output wire [31:0] araddr,
output wire [7:0] arlen,
output wire [2:0] arsize,
output wire [1:0] arburst,
output wire arvalid,
input wire arready,
input wire [63:0] rdata,
input wire [1:0] rresp,
input wire rlast,
input wire rvalid,
output wire rready,
output wire [31:0] awaddr,
output wire [7:0] awlen,
output wire [2:0] awsize,
output wire [1:0] awburst,
output wire awvalid,
input wire awready,
output wire [63:0] wdata,
output wire [7:0] wstrb,
output wire wlast,
output wire wvalid,
input wire wready,
input wire [1:0] bresp,
input wire bvalid,
output wire bready
);
reg [1:0] state,phase; localparam IDLE=0,LAUNCH=1,WAIT=2,FAILED=3;
reg [31:0] ib,ep,dp,pp,se,sd,ob; wire dw_selected=phase==1;
wire pw_done,dw_done,pw_fault,dw_fault,pw_busy,dw_busy; assign busy=state!=IDLE;
wire [31:0] pw_araddr,dw_araddr;
assign araddr=dw_selected?dw_araddr:pw_araddr;
wire [7:0] pw_arlen,dw_arlen;
assign arlen=dw_selected?dw_arlen:pw_arlen;
wire [2:0] pw_arsize,dw_arsize;
assign arsize=dw_selected?dw_arsize:pw_arsize;
wire [1:0] pw_arburst,dw_arburst;
assign arburst=dw_selected?dw_arburst:pw_arburst;
wire pw_arvalid,dw_arvalid;
assign arvalid=dw_selected?dw_arvalid:pw_arvalid;
wire pw_rready,dw_rready;
assign rready=dw_selected?dw_rready:pw_rready;
wire [31:0] pw_awaddr,dw_awaddr;
assign awaddr=dw_selected?dw_awaddr:pw_awaddr;
wire [7:0] pw_awlen,dw_awlen;
assign awlen=dw_selected?dw_awlen:pw_awlen;
wire [2:0] pw_awsize,dw_awsize;
assign awsize=dw_selected?dw_awsize:pw_awsize;
wire [1:0] pw_awburst,dw_awburst;
assign awburst=dw_selected?dw_awburst:pw_awburst;
wire pw_awvalid,dw_awvalid;
assign awvalid=dw_selected?dw_awvalid:pw_awvalid;
wire [63:0] pw_wdata,dw_wdata;
assign wdata=dw_selected?dw_wdata:pw_wdata;
wire [7:0] pw_wstrb,dw_wstrb;
assign wstrb=dw_selected?dw_wstrb:pw_wstrb;
wire pw_wlast,dw_wlast;
assign wlast=dw_selected?dw_wlast:pw_wlast;
wire pw_wvalid,dw_wvalid;
assign wvalid=dw_selected?dw_wvalid:pw_wvalid;
wire pw_bready,dw_bready;
assign bready=dw_selected?dw_bready:pw_bready;
pointwise_axi_master pw(
.clk(clk),
.resetn(resetn),
.start(state==LAUNCH && !dw_selected),
.project(phase==2),.input_base(phase==2?sd:ib),.parameter_base(phase==2?pp:ep),.output_base(phase==2?ob:se),.skip_base(ib),
.busy(pw_busy),
.done(pw_done),
.fault(pw_fault),
.araddr(pw_araddr),
.arlen(pw_arlen),
.arsize(pw_arsize),
.arburst(pw_arburst),
.arvalid(pw_arvalid),
.arready((!dw_selected) && arready),
.rdata(rdata),
.rresp(rresp),
.rlast(rlast),
.rvalid((!dw_selected) && rvalid),
.rready(pw_rready),
.awaddr(pw_awaddr),
.awlen(pw_awlen),
.awsize(pw_awsize),
.awburst(pw_awburst),
.awvalid(pw_awvalid),
.awready((!dw_selected) && awready),
.wdata(pw_wdata),
.wstrb(pw_wstrb),
.wlast(pw_wlast),
.wvalid(pw_wvalid),
.wready((!dw_selected) && wready),
.bresp(bresp),
.bvalid((!dw_selected) && bvalid),
.bready(pw_bready)
);
dw144_axi_master dw(
.clk(clk),
.resetn(resetn),
.start(state==LAUNCH && dw_selected),
.input_base(se),.parameter_base(dp),.output_base(sd),
.busy(dw_busy),
.done(dw_done),
.fault(dw_fault),
.araddr(dw_araddr),
.arlen(dw_arlen),
.arsize(dw_arsize),
.arburst(dw_arburst),
.arvalid(dw_arvalid),
.arready((dw_selected) && arready),
.rdata(rdata),
.rresp(rresp),
.rlast(rlast),
.rvalid((dw_selected) && rvalid),
.rready(dw_rready),
.awaddr(dw_awaddr),
.awlen(dw_awlen),
.awsize(dw_awsize),
.awburst(dw_awburst),
.awvalid(dw_awvalid),
.awready((dw_selected) && awready),
.wdata(dw_wdata),
.wstrb(dw_wstrb),
.wlast(dw_wlast),
.wvalid(dw_wvalid),
.wready((dw_selected) && wready),
.bresp(bresp),
.bvalid((dw_selected) && bvalid),
.bready(dw_bready)
);
always @(posedge clk) begin
 if(!resetn) begin state<=IDLE;phase<=0;done<=0;fault<=0;end
 else case(state)
 IDLE: if(start) begin
  done<=0;fault<=0;phase<=0;
  ib<=input_base;ep<=expand_parameters;dp<=depthwise_parameters;pp<=project_parameters;
  se<=scratch_expand;sd<=scratch_depthwise;ob<=output_base;
  if((input_base[5:0]|expand_parameters[5:0]|depthwise_parameters[5:0]|project_parameters[5:0]|scratch_expand[5:0]|scratch_depthwise[5:0]|output_base[5:0])!=0) begin fault<=1;state<=FAILED;end
  else state<=LAUNCH;
 end
 LAUNCH: state<=WAIT;
 WAIT: if(dw_selected?dw_fault:pw_fault) begin fault<=1;state<=FAILED;end
 else if(dw_selected?dw_done:pw_done) begin
  if(phase==2) begin done<=1;state<=IDLE;end
  else begin phase<=phase+1'b1;state<=LAUNCH;end
 end
 FAILED: state<=FAILED;
 default: begin fault<=1;state<=FAILED;end
 endcase
end
endmodule
