// Fixed block3: C24->144 expansion or C144->24 projection plus residual.
// The DMA loader supplies one complete 56-pixel row and its immutable weights.
module pointwise_row_core(
 input wire clk,resetn,start,project,
 input wire input_write,input wire [12:0] input_address,input wire [63:0] input_data,
 input wire skip_write,input wire [10:0] skip_address,input wire [63:0] skip_data,
 input wire parameter_write,input wire [7:0] parameter_output,
 input wire [4:0] parameter_beat,input wire [63:0] parameter_data,
 output wire busy,output reg done,
 output wire out_valid,input wire out_ready,
 output wire [7:0] out_channel,output wire [5:0] out_column,output wire [7:0] out_data
);
 localparam IDLE=0,INIT=1,DOT=2,QPREP=3,QUANT=4;
 reg [2:0] state;
 reg mode;
 reg [3:0] group_index;
 reg [5:0] column;
 reg [7:0] issue,consumed;
 reg product_valid;
 reg [4:0] qissued,qreceived,qaccepted;
 (* ram_style="distributed" *) reg [7:0] pixels[0:8063];
 (* ram_style="distributed" *) reg [7:0] skips[0:1343];
 (* ram_style="distributed" *) reg [7:0] weights[0:15][0:287];
 (* ram_style="distributed" *) reg signed [31:0] biases[0:15][0:8];
 (* ram_style="distributed" *) reg [31:0] multipliers[0:15][0:8];
 reg signed [17:0] products[0:15];
 reg signed [39:0] accum[0:15];
 wire [7:0] channels=mode?144:24;
 wire [4:0] lanes=(mode && group_index==1)?8:16;
 wire signed [8:0] pixel=$signed({1'b0,pixels[issue*56+column]})-(mode?9'sd0:9'sd106);
 integer i,b,weight_position;
 always @(posedge clk) begin
  if(input_write) for(b=0;b<8;b=b+1) pixels[input_address+b]<=input_data[b*8+:8];
  if(skip_write) for(b=0;b<8;b=b+1) skips[skip_address+b]<=skip_data[b*8+:8];
  if(parameter_write) begin
   for(b=0;b<8;b=b+1) begin
    weight_position=parameter_beat*8+b;
    if(weight_position<(project?144:24))
     weights[parameter_output[3:0]][parameter_output[7:4]*(project?144:24)+weight_position]<=parameter_data[b*8+:8];
   end
   if(parameter_beat==18) begin
    biases[parameter_output[3:0]][parameter_output[7:4]]<=parameter_data[31:0];
    multipliers[parameter_output[3:0]][parameter_output[7:4]]<=parameter_data[63:32];
   end
  end
 end
 wire rqready,rqvalid,add_advance;
 wire [7:0] rqresult;
 // Zero products reduce the existing validated patch core to its bias/M/RNE path.
 dw3x3_patch_core rounding(clk,resetn,state==QUANT && qissued<lanes,rqready,
  72'b0,{9{8'd128}},8'd0,8'd128,$signed(accum[qissued[3:0]][31:0]),
  multipliers[qissued[3:0]][group_index],5'd30,mode?8'd101:8'd0,8'd0,8'd255,
  rqvalid,add_advance && state==QUANT,rqresult);
 // Register every residual stage. Global stall preserves data and channel tags.
 reg [5:0] add_valid;
 reg [10:0] skip_read_address;
 reg [7:0] add_channel[0:5], add_raw[0:5];
 reg signed [8:0] skip_delta,project_delta;
 reg signed [63:0] skip_product,project_product,add_sum,add_value;
 reg [7:0] add_result;
 assign add_advance=!add_valid[5] || out_ready;
 wire [7:0] accepted_channel={group_index,4'b0}+qaccepted;
 wire signed [63:0] add_floor=add_sum>>>30;
 wire [29:0] add_remainder=add_sum[29:0];
 wire signed [63:0] add_rounded=add_floor+
   ((add_remainder>30'd536870912)||((add_remainder==30'd536870912)&&add_floor[0]))+64'sd124;
 integer a;
 always @(posedge clk) begin
  if(!resetn) add_valid<=0;
  else if(add_advance) begin
   add_valid<={add_valid[4:0],rqvalid && state==QUANT};
   if(rqvalid && state==QUANT) begin
    skip_read_address<=mode ? accepted_channel*56+column : 0;
    add_channel[0]<=accepted_channel;add_raw[0]<=rqresult;
   end
   for(a=1;a<6;a=a+1) if(add_valid[a-1]) begin
    add_channel[a]<=add_channel[a-1];add_raw[a]<=add_raw[a-1];
   end
   if(add_valid[0]) begin
    skip_delta<=$signed({1'b0,skips[skip_read_address]})-9'sd106;
    project_delta<=$signed({1'b0,add_raw[0]})-9'sd101;
   end
   if(add_valid[1]) begin
    skip_product<=skip_delta*64'sd958620430;
    project_product<=project_delta*64'sd1114098186;
   end
   if(add_valid[2]) add_sum<=skip_product+project_product;
   if(add_valid[3]) add_value<=add_rounded;
   if(add_valid[4]) add_result<=add_value<0?8'd0:add_value>255?8'd255:add_value[7:0];
  end
 end
 assign out_data=mode ? add_result : add_raw[5];
 assign out_valid=add_valid[5] && state==QUANT;
 assign out_channel=add_channel[5];
 assign out_column=column;
 assign busy=state!=IDLE;
 always @(posedge clk) begin
  if(!resetn) begin
   state<=IDLE;done<=0;mode<=0;group_index<=0;column<=0;
   issue<=0;consumed<=0;product_valid<=0;qissued<=0;qreceived<=0;qaccepted<=0;
  end else case(state)
   IDLE: if(start) begin mode<=project;done<=0;group_index<=0;column<=0;state<=INIT;end
   INIT: begin
    for(i=0;i<16;i=i+1) accum[i]<={{8{biases[i][group_index][31]}},biases[i][group_index]};
    issue<=0;consumed<=0;product_valid<=0;state<=DOT;
   end
   DOT: begin
    if(product_valid) begin
     for(i=0;i<16;i=i+1) accum[i]<=accum[i]+products[i];
     consumed<=consumed+1'b1;
     if(consumed==channels-1'b1) state<=QPREP;
    end
    product_valid<=issue<channels;
    if(issue<channels) begin
     for(i=0;i<16;i=i+1)
      products[i]<=pixel*($signed({1'b0,weights[i][group_index*(mode?32'd144:32'd24)+issue]})-9'sd128);
     issue<=issue+1'b1;
    end
   end
   QPREP: begin qissued<=0;qreceived<=0;qaccepted<=0;state<=QUANT;end
   QUANT: begin
    if(rqready && qissued<lanes) qissued<=qissued+1'b1;
    if(rqvalid && add_advance) qaccepted<=qaccepted+1'b1;
    if(out_valid && out_ready) begin
     qreceived<=qreceived+1'b1;
     if(qreceived==lanes-1'b1) begin
      if(column<55) begin column<=column+1'b1;state<=INIT;end
      else if(group_index<(mode?1:8)) begin group_index<=group_index+1'b1;column<=0;state<=INIT;end
      else begin done<=1;state<=IDLE;end
     end
    end
   end
   default: state<=IDLE;
  endcase
 end
endmodule
