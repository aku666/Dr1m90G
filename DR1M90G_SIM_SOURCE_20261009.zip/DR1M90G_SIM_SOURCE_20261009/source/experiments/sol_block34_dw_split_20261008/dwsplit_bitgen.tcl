import_device dr1_90.db -package DR1M90GEG400 -speed 2
open_project soc_v2.prj -noanalyze
import_db camera_dsi_dwsplit_final.db
bitgen -bit camera_dsi_dwsplit_result.bit
puts CAMERA_DSI_ALIGNRESET_BIT_COMPLETE
exit

