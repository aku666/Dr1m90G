# Execute only after physical cold recovery and qualified temporary setup.
connect_cable -host_name localhost:5555
download -bit C:/Users/16429/.codex/worktrees/19de/fdma_imx415_20251008/experiments/sol_block34_dw_split_20261008/camera_dsi_dwsplit_result.bit -mode jtag -spd 7 -cable 0
connect_cable -close
puts DW_SPLIT_VOLATILE_DOWNLOAD_COMPLETE
exit
