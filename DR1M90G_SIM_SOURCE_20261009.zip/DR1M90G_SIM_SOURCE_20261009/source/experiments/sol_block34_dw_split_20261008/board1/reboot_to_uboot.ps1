param([string]$RebootCommand = 'reboot',
      [string]$LogName = 'reboot_to_uboot.log')
$ErrorActionPreference = 'Stop'
$logPath = Join-Path $PSScriptRoot $LogName
if (Test-Path -LiteralPath $logPath) { throw "preserve existing boot log: $logPath" }
$port = [IO.Ports.SerialPort]::new('COM4', 115200)
$port.ReadTimeout = 200
$port.Open()
try {
    $port.DiscardInBuffer()
    $port.Write("$RebootCommand`r")
    $deadline = (Get-Date).AddSeconds(40)
    $output = [Text.StringBuilder]::new()
    $interrupted = $false
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 100
        $part = $port.ReadExisting()
        if ($part) {
            [void]$output.Append($part)
            if (-not $interrupted -and $output.ToString().Contains('Hit any key')) {
                $port.Write("`r")
                $interrupted = $true
            }
            if ($interrupted -and $output.ToString().Contains('=>')) { break }
        }
    }
    $output.ToString() | Set-Content -LiteralPath $logPath
    if (-not $output.ToString().Contains('=>')) { throw 'U-Boot prompt not reached' }
    Write-Output 'U-Boot prompt reached'
} finally {
    $port.Close()
    $port.Dispose()
}
