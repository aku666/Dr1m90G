import_device dr1_90.db -package DR1M90GEG400 -speed 2
open_project soc_v2.prj
elaborate -top system_top
optimize_rtl
export_db camera_dsi_dwsplit_rtl.db
read_adc camera_dsi_pins.adc
optimize_gate -packarea camera_dsi_dwsplit_gate.area
export_db camera_dsi_dwsplit_gate.db
puts CAMERA_DSI_ALIGNRESET_GATE_COMPLETE
exit
