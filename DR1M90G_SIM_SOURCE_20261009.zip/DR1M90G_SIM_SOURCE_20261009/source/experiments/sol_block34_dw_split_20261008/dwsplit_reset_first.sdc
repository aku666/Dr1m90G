# Actual routed remaining hold path; receiving output is
# u_low_per_fun/cdc_synchronization_external[0], the existing PS reset first stage.
set_false_path -from [get_pins {I_system/ARM_Processor_System_0/ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst.p2f_clk0_rst_n}] -to [get_pins {I_system/Processor_System_Reset_0/proc_sys_reset_003909975d3e_Inst/u_low_per_fun/cdc_synchronization_external_reg[0]_syn_2.ie}]
