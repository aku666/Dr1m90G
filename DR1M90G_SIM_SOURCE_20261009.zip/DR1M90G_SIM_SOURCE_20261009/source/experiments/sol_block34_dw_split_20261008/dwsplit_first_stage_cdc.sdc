# This actual route only: first synchronizer inputs; later stages remain timed.
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[11]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[11]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[11]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[11]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[7]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[9]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[0]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[3]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[10]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[5]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[10]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[9]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[4]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[4]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[5]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[4]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[5]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[5]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[7]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[6]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[7]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[7]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[8]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[9]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_sync_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[9]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_sync_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[7]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[5]_syn_2.ima}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[3]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[3]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[6]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[4]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[7]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[5]_syn_2.imb}]
# FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[8]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[3]_syn_2.ima}]
# FLAGS_FIRST_STAGE
set_false_path -from [get_pins {camera/u_uicfg_imx415/O_ae_cfg_done_reg_syn_8.clk}] -to [get_pins {probe/flags_meta_reg[3]_syn_2.ima}]
# FLAGS_FIRST_STAGE
set_false_path -from [get_pins {camera/u_uicfg_imx415/O_cfg_done_reg_syn_6.clk}] -to [get_pins {probe/flags_meta_reg[3]_syn_2.imb}]
# FLAGS_FIRST_STAGE
set_false_path -from [get_pins {iic_seen_reg_syn_6.clk}] -to [get_pins {probe/flags_meta_reg[8]_syn_2.ima}]
# LOCAL_RESET_FIRST_STAGE
set_false_path -from [get_pins {probe/flags_meta_reg[0]_syn_2.clk}] -to [get_pins {camera/camera_reset_sync/release_pipe_reg[0]_syn_2.asr}]
# SCAN_READY_FIRST_STAGE
set_false_path -from [get_pins {scan_start/prefilled_reg_syn_6.clk}] -to [get_pins {scan_start/ready_meta_reg_syn_3.ima}]
# FIFO_RESET_FIRST_STAGE
set_false_path -from [get_pins {ui_sync/release_pipe_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/asy_r_rst0_reg_syn_3.asr}]
# LOCAL_RESET_FIRST_STAGE
set_false_path -from [get_pins {ui_sync/release_pipe_reg[0]_syn_2.clk}] -to [get_pins {r_sync/release_pipe_reg[0]_syn_2.asr}]
