import_device dr1_90.db -package DR1M90GEG400 -speed 2
open_project soc_v2.prj -noanalyze
import_db camera_dsi_dwsplit_gate.db
clear_sdc
read_adc camera_dsi_pins.adc
read_sdc -ip system_ARM_Processor_System_0 board_softnpu_80mhz.sdc
read_sdc uisrc/04_pin/timing.sdc
legalize_phy_inst
place
export_db camera_dsi_dwsplit_place.db
route
report_area -io_info -file camera_dsi_dwsplit_phy.area
update_timing -mode final
report_timing_status -file camera_dsi_dwsplit_raw.ts
report_timing_summary -file camera_dsi_dwsplit_raw.timing
report_timing_exception -file camera_dsi_dwsplit_raw_exception.timing
export_db camera_dsi_dwsplit_route.db
puts CAMERA_DSI_ALIGNRESET_ROUTE_COMPLETE
exit
