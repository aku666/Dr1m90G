$ErrorActionPreference='Stop'
$taskTools='F:/BaiduNetdiskDownload/01_fdma_vdma_20251010/Aku666/fdma_imx415_20251008/tools/msys64/ucrt64/bin'
$env:PATH="$taskTools;$env:PATH"
$rtl='uisrc/01_rtl/front_block34'
& "$taskTools/iverilog.exe" -g2012 -s tb_dw_split -o dw_split.vvp tb_dw_split.v "$rtl/block34_axi_chain.v" "$rtl/pointwise34_axi_master.v" "$rtl/pointwise34_row_core.v" "$rtl/dw144_stride_axi_master.v" uisrc/01_rtl/dw16/dw3x3_patch_core.v
if($LASTEXITCODE -ne 0){throw 'DW split compile failed'}
& "$taskTools/vvp.exe" dw_split.vvp | Tee-Object sim.log
if($LASTEXITCODE -ne 0){throw 'DW split simulation failed'}
