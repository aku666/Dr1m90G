"""Reapply existing first-stage CDC handling to this route's actual pins."""
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
text = (root / 'camera_dsi_dwsplit_raw.timing').read_text()
pairs = {}
for block in text.split('Slack               :')[1:]:
    endpoints = re.search(r'Begin Point\s+: (\S+).*?End Point\s+: (\S+)', block, re.S)
    if not endpoints:
        continue
    source, target = endpoints.groups()
    # TD may name the packed slice after another register. Identify the
    # receiving register's output net, never its preceding data-path net.
    capture = re.search(r'^reg\s+[^\n]*net:\s+(\S+),', block, re.M)
    net = capture.group(1) if capture else ''
    kind = None
    if 'buffers/rdbuf_fifo/' in target and '/sync_r1[' in net:
        kind = 'FIFO_GRAY_FIRST_STAGE'
    elif net.startswith('probe/flags_meta['):
        kind = 'FLAGS_FIRST_STAGE'
    elif net.startswith('scan_start/ready_meta'):
        kind = 'SCAN_READY_FIRST_STAGE'
    elif 'buffers/rdbuf_fifo/asy_r_rst0_reg' in target and target.endswith('.asr'):
        kind = 'FIFO_RESET_FIRST_STAGE'
    elif re.search(r'(?:r_sync|camera/camera_reset_sync)/release_pipe_reg\[0\].*\.asr$', target):
        kind = 'LOCAL_RESET_FIRST_STAGE'
    elif (source.endswith('.p2f_clk0_rst_n') and
          net.endswith('/cdc_synchronization_external[0]')):
        kind = 'PS_RESET_FIRST_STAGE_EXTERNAL0'
    if kind:
        pairs[(source, target)] = kind

lines = ['# This actual route only: first synchronizer inputs; later stages remain timed.']
for (source, target), kind in sorted(pairs.items()):
    lines.extend([f'# {kind}',
                  f'set_false_path -from [get_pins {{{source}}}] -to [get_pins {{{target}}}]'])
(root / 'dwsplit_first_stage_cdc.sdc').write_bytes(('\n'.join(lines)+'\n').encode())
(root / 'dwsplit_first_stage_cdc.json').write_text(json.dumps([
    dict(source=s, target=t, kind=k) for (s, t), k in sorted(pairs.items())], indent=2)+'\n')
print('ACTUAL_ROUTE_FIRST_STAGE_PAIRS', len(pairs))
