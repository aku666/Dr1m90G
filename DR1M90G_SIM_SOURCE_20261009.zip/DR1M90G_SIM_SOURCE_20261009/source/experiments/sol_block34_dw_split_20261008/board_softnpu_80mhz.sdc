# Soft NPU-only bring-up clocks: P2F_CLK0=80 MHz, P2F_CLK1=40 MHz.
# APUG1205 documents 80 MHz as the typical Soft NPU clock.
# These divisors must also be written to FCLK_CNT_DIV on the board.
set_ip_property GBE0_TXCLK_FREQ 125 [get_cells {ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst}]
set_ip_property GBE0_TXCLK_PHA 0 [get_cells {ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst}]
set_ip_property IOPLL_400M_FREQ 400 [get_cells {ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst}]
set_ip_property P2F_CLK0_DIV 5 [get_cells {ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst}]
set_ip_property P2F_CLK1_DIV 10 [get_cells {ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst}]
set_ip_property P2F_CLK2_DIV 8 [get_cells {ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst}]
