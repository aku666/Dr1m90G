SWNS: -0.734ns, STNS: -2.428ns.
HWNS: -1.189ns, HTNS: -14.733ns.
