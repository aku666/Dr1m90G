"""Two real saved DW tensors on the existing PL engine; final comparison only."""
import argparse
import json
from pathlib import Path
from time import perf_counter
import numpy as np
from dw144_executor import DW144Executor

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('fixture', type=Path, help='Extracted existing cpu_gap_check.tgz')
args = parser.parse_args()
executor = DW144Executor(args.fixture)
report = dict(scope='TWO_EXISTING_PL_DW_MODES_NOT_FULL_MODEL_OR_SUSTAINED_FPS',
              adopted=False, completed_jobs=[])
try:
    for block in (3, 4):
        source = np.load(args.fixture / f'expand{block}.npy', allow_pickle=False)
        start = perf_counter()
        output = executor(source, block)
        record = dict(executor.last_run, client_ms=(perf_counter()-start)*1000)
        golden = np.load(args.fixture / f'dw{block}.npy', allow_pickle=False)
        delta = output.astype(np.int16)-golden.astype(np.int16)
        record.update(differing=int(np.count_nonzero(delta)), max_abs=int(np.max(np.abs(delta))))
        report['completed_jobs'].append(record)
        if record['differing']:
            raise ArithmeticError(f'PL DW{block} differs from the existing CPU golden')
    print('DW144_TWO_REAL_TENSORS_PASS', flush=True)
finally:
    report['last_device_run'] = executor.last_run
    report['device_blocked'] = executor.blocked
    (args.fixture / 'pl_dw_verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2), flush=True)
    executor.close()
