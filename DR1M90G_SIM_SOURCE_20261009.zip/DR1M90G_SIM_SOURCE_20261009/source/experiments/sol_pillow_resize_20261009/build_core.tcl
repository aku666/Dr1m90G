import_device dr1_90.db -package DR1M90GEG400 -speed 2
open_project pillow_aa_224.prj
elaborate -top pillow_aa_224
optimize_rtl
export_db pillow_aa_224_rtl.db
optimize_gate -packarea pillow_aa_224_gate.area
export_db pillow_aa_224_gate.db
puts PILLOW_EXACT_CORE_GATE_COMPLETE_NO_BIT_NO_BOARD
exit
