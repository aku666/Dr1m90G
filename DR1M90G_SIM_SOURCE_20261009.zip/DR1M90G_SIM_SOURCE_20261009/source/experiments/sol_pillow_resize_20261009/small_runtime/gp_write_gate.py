"""Serialize capture-control writes against the existing GP PL job busy gate.

net_pl_control.v rejects every write while any PL job is pending. Reads and
CPU computation remain concurrent. A failed PL call forbids further writes;
it does not claim that DMA stopped or that buffers can be released.
"""
import fcntl
import os
from contextlib import contextmanager
from time import perf_counter


class GpWriteGate:
    def __init__(self, path, create=False):
        flags=os.O_RDWR|os.O_CLOEXEC
        if create:flags|=os.O_CREAT|os.O_EXCL
        self.fd=os.open(path,flags,0o600)
        self.calls=0
        self.wait_ms=0.0

    @contextmanager
    def hold(self, pl_job=False):
        start=perf_counter()
        fcntl.flock(self.fd,fcntl.LOCK_EX)
        self.wait_ms+=(perf_counter()-start)*1000
        try:
            if os.pread(self.fd,1,0)==b'X':
                raise RuntimeError('Prior PL failure: no further GP write; retain DMA and physically recover')
            self.calls+=1
            try:
                yield
            except BaseException:
                if pl_job:os.pwrite(self.fd,b'X',0)
                raise
        finally:
            fcntl.flock(self.fd,fcntl.LOCK_UN)

    def close(self):
        if self.fd>=0:os.close(self.fd);self.fd=-1


class LockedPlExecutor:
    def __init__(self, executor, gate):
        self.executor=executor
        self.gate=gate

    def __getattr__(self, name):
        return getattr(self.executor,name)

    def __call__(self, *args):
        # Hold through the existing completion/status checks, not merely
        # configuration writes: capture cannot write until pending clears.
        with self.gate.hold(pl_job=True):
            return self.executor(*args)
