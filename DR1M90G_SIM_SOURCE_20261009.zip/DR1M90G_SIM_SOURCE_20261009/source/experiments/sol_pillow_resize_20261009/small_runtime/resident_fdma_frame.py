"""Decode an explicitly described offline FDMA frame dump; no device access."""

from __future__ import annotations

from collections.abc import Sequence

from PIL import Image

from sign_model.preprocess import normalized_rgb_chw


def normalized_mapped_frame(
    buffer, *, width: int, height: int, stride_bytes: int, pixel_bytes: str,
):
    """Resize a frozen RGBX/BGRX buffer; return an independently owned tensor.

    The caller must stop slot recycling through completion of this function.
    Channel interpolation is independent, so swap B/R after the small resize.
    No borrowed image or buffer is retained by the returned array.
    """
    if width <= 0 or height <= 0 or stride_bytes < width * 4 or stride_bytes % 4:
        raise ValueError('invalid frame dimensions or stride')
    if pixel_bytes not in ('BGRX', 'RGBX'):
        raise ValueError('pixel_bytes must explicitly be BGRX or RGBX')
    if len(buffer) < height * stride_bytes:
        raise ValueError('mapped frame buffer too short')
    # RGBX is a Pillow shareable mode. Interpret BGRX in that same mode and
    # recover the actual RGB order after applying the original bilinear filter.
    with Image.frombuffer('RGBX', (width, height), buffer, 'raw', 'RGBX', stride_bytes, 1) as source:
        with source.resize((224, 224), Image.Resampling.BILINEAR) as small:
            with Image.frombytes('RGB', small.size, small.tobytes(), 'raw', pixel_bytes, 224 * 4, 1) as rgb:
                return normalized_rgb_chw(rgb, [224, 224], [.485, .456, .406], [.229, .224, .225])


def decode_offline_frame(
    raw: bytes,
    *,
    width: int,
    height: int,
    stride_bytes: int,
    pixel_bytes: str,
    roi_xywh: Sequence[int],
    slot_bytes: int | None = None,
) -> Image.Image:
    if width <= 0 or height <= 0 or stride_bytes < width * 4 or stride_bytes % 4:
        raise ValueError("invalid frame dimensions or stride")
    required = stride_bytes * height
    expected = required if slot_bytes is None else slot_bytes
    if expected < required or len(raw) != expected:
        raise ValueError(f"raw frame length {len(raw)} does not match expected {expected}")
    if pixel_bytes not in ("BGRX", "RGBX"):
        raise ValueError("pixel_bytes must explicitly be BGRX or RGBX")
    if len(roi_xywh) != 4:
        raise ValueError("roi_xywh must be [x, y, width, height]")
    x, y, crop_width, crop_height = (int(value) for value in roi_xywh)
    if x < 0 or y < 0 or crop_width <= 0 or crop_height <= 0:
        raise ValueError("ROI must have nonnegative origin and positive size")
    if x + crop_width > width or y + crop_height > height:
        raise ValueError("ROI exceeds frame")
    image = Image.frombytes("RGB",(width,height),raw[:required],"raw",pixel_bytes,stride_bytes,1)
    if (x,y,crop_width,crop_height)==(0,0,width,height):
        return image
    return image.crop((x,y,x+crop_width,y+crop_height))
