import json,signal,sys
from pathlib import Path
import numpy as np
from capture_callback import capture

spool=Path(sys.argv[1]);output=Path(sys.argv[2])
spool.mkdir(exist_ok=False)
produced=0
def cancel(signum,frame):
 raise RuntimeError('Capture producer stopped; disable future writes and retain reserved DDR')
signal.signal(signal.SIGTERM,cancel)
def submit(frame,source):
 global produced
 p=spool/f'{produced:03d}.npy'
 if frame.shape!=(3,224,224) or frame.dtype!=np.float32:
  raise ValueError('Capture normalization must retain the original CHW tensor')
 np.save(p,frame[None],allow_pickle=False)
 temp=spool/f'{produced:03d}.json.tmp'
 temp.write_text(json.dumps(source)+'\n')
 temp.replace(spool/f'{produced:03d}.json')
 produced+=1
try:
 report=capture(output,'BGRX',[0,0,224,224],timeout=30.,frame_count=16,status_offset=0x100,
     freeze_copy=True,save_snapshots=False,frame_consumer=submit,save_inputs=True)
 (spool/'complete.json').write_text(json.dumps(dict(produced=produced,capture=report))+'\n')
except Exception as error:
 (spool/'failure.json').write_text(json.dumps(dict(error=str(error),produced=produced))+'\n')
 raise
