import json,subprocess,sys
from pathlib import Path
from time import perf_counter,monotonic,sleep
import numpy as np
from feature_ring import FeatureRing
from run_hard_soft_clip import main

def consume(chain,hard,temporal,args,initialization_ms,frame_index,front_block,front_dw,dw16):
 root=Path(__file__).resolve().parent
 spool=args.results/'spool'
 ring=FeatureRing(64)
 frame_times=[];latencies=[];peak_queue=0
 started=perf_counter()
 log=(args.results/'capture_producer.log').open('w')
 child=subprocess.Popen([sys.executable,str(root/'capture_producer.py'),str(spool),str(args.results/'capture')],stdout=log,stderr=subprocess.STDOUT)
 try:
  # The first follow-up separates capture with models merely loaded from
  # overlap. It distinguishes a capture access fault from concurrent START.
  capture_first=__import__('os').environ.get('RESIDENT_CAPTURE_FIRST')=='1'
  if capture_first:
   child.wait(timeout=35)
   if child.returncode!=0:raise RuntimeError('Capture-only with resident models failed before any START')
  for index in range(16):
   ready=spool/f'{index:03d}.json'
   while not ready.exists():
    if child.poll() is not None:
     raise RuntimeError('Capture producer exited before supplying the next complete distinct frame; see capture log')
    if perf_counter()-started>40:
     raise TimeoutError('Finite live pipeline did not supply its next frame')
    sleep(.005)
   source=json.loads(ready.read_text())
   peak_queue=max(peak_queue,len(list(spool.glob('[0-9][0-9][0-9].json'))))
   p=spool/f'{index:03d}.npy'
   frame=np.load(p,allow_pickle=False)
   if frame.shape!=(1,3,224,224) or frame.dtype!=np.float32:
    raise ValueError('Producer must publish a private normalized frame, not a live DMA view')
   frame_index[0]=index
   begin=perf_counter();feature,timing=chain.run(frame)
   frame_times.append((perf_counter()-begin)*1000)
   latencies.append((monotonic()-source['host_observed_monotonic_seconds'])*1000)
   ring.append(feature[0],source)
   chain.prefix.records.clear()
   p.unlink();ready.unlink()
  child.wait(timeout=3)
  if child.returncode!=0:raise RuntimeError('Capture producer failed after publishing frames')
  capture=json.loads((spool/'complete.json').read_text())['capture']
  value,mask,selection=ring.window(0,15)
  before=hard.starts
  prediction=temporal.classify(value,mask)
  assert before==hard.starts==256
  np.save(args.results/'features.npy',value)
  np.save(args.results/'valid_mask.npy',mask)
  report=dict(scope='LIVE_IMX415_RESIDENT_SPATIAL_FINITE16_WITH_CAPTURE_OVERLAP',
    prediction=prediction,selection=selection,capture=capture,frames_processed=ring.count,
    parameter_loads=1,model_initializations=1,initialization_ms=initialization_ms,
    processing_ms=(perf_counter()-started)*1000,frame_service_ms=frame_times,
    frame_service_p95_ms=float(np.percentile(frame_times,95)),host_observed_to_feature_p95_ms=float(np.percentile(latencies,95)),
    maximum_pending_tensor_files=peak_queue,spool_capacity_frames=16,
    actual_hard_starts=hard.starts,actual_front96_starts=front_dw.count,actual_dw144_starts=2*front_block.count,
    actual_dw16_starts=16,actual_soft_starts=0,actual_v4r_starts=0,
    source_sequence_gaps=[x['sequence_gap'] for x in selection['sources']],
    capture_compute_overlap=not capture_first,
    gp_control_serialization='CAPTURE_WRITES_VS_COMPLETE_PL_CALLS_CPU_AND_READS_OVERLAP',
    pl_gate_calls=front_dw.gate.calls,pl_gate_wait_ms=front_dw.gate.wait_ms,
    throughput_scope='FINITE16_NOT_SUSTAINED; SOURCE_SEQUENCE_GAPS_ARE_NOT_HIDDEN',
    quality='NOT_CALIBRATED',mode='PARTIAL_FULL_CAMERA_RATE_NOT_PROCESSED',automatic_action_end=False,display=False)
  (args.results/'live_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps({k:v for k,v in report.items() if k not in ('capture','frame_service_ms','selection')},ensure_ascii=False),flush=True)
  return report
 finally:
  if child.poll() is None:
   child.terminate()
   child.wait(timeout=3)
  log.close()

if __name__=='__main__':
 __import__('os').environ['RESIDENT_GP_SERIAL']='1'
 main(sys.argv[1:],stream_consumer=consume)
