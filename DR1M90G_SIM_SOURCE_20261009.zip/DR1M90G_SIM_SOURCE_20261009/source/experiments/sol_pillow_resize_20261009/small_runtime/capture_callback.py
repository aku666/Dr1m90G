"""Capture sixteen complete FDMA frames into the existing model's NPY input.

Requires its matching controlled-capture bit, reserved startup DTB and IMX415.
This entry has no NPU access; failed capture never supplies synthetic frames.
"""
import argparse
import json
import mmap
import os
import re
import struct
import sys
from pathlib import Path
from time import monotonic,sleep
import numpy as np

ROOT = Path('/run/camera_pw32_20261006_1')
sys.path.insert(0,str(ROOT/'model_pipeline/src'))
from resident_fdma_frame import decode_offline_frame,normalized_mapped_frame
from small_frame import normalized_small_bgrx

BASE,SLOT_BYTES,SLOTS = 0x0a000000,8388608,3
FRAME_BYTES = 224*224*4
STATUS_BASE,ID = 0x90000000,0x46535431
SUPPORTED_ABIS = (0x00010006,)  # Isolated AA224 only; old full-HD ABI rejected.
GPIO_BASE = 0xf8411000
GPIO_BANK2_DATA = 0x200


def verify_reservation():
    node = Path('/proc/device-tree/reserved-memory/fdma_frames@a000000')
    if not (node/'no-map').is_file() or (node/'reg').read_bytes()!=struct.pack('>IIII',0,BASE,0,SLOT_BYTES*SLOTS):
        raise RuntimeError('capture requires its exact no-map startup reservation')
    for line in Path('/proc/iomem').read_text().splitlines():
        match = re.match(r'\s*([0-9a-f]+)-([0-9a-f]+)\s*:\s*System RAM\s*$',line)
        if match and max(int(match[1],16),BASE)<min(int(match[2],16)+1,BASE+SLOT_BYTES*SLOTS):
            raise RuntimeError('video slots overlap Linux System RAM; do not enable capture')


def read_status(registers):
    words = struct.unpack_from('<14I',registers,0)
    after = struct.unpack_from('<I',registers,8)[0]
    if words[0]!=ID or words[1] not in SUPPORTED_ABIS:
        raise RuntimeError('requires isolated FST1 AA224 ABI 1.6')
    if words[2]!=after or after&1:
        return None
    if words[7]:
        raise RuntimeError('FDMA reported a write/frame fault; preserve reserved slots and recover')
    slot = words[5]
    if words[3]==0 or words[4]==0 or slot>=SLOTS or words[6]&(1<<slot):
        return None
    start,done = words[8+2*slot:10+2*slot]
    if start==0 or start!=done:
        return None
    return dict(epoch=words[3],sequence=words[4],slot=slot,generation=start)


def gray16(value):
    value &= 0xffff
    for shift in (8,4,2,1):
        value ^= value >> shift
    return value


def camera_preflight(registers,abi,record,timeout=2.0):
    """Require current CSI/ISP activity before enabling DDR writes."""
    if abi<0x00010002:
        sleep(.5)
        record['frame_probe']='UNAVAILABLE_ABI_1_1'
        return
    deadline = monotonic()+timeout
    previous = (gray16(struct.unpack_from('<I',registers,0x48)[0]),
                gray16(struct.unpack_from('<I',registers,0x4c)[0]))
    stable = 0
    record.update(samples=[],iic_error_seen=False)
    while monotonic()<deadline:
        sleep(.1)
        flags = struct.unpack_from('<I',registers,0x44)[0]
        current = (gray16(struct.unpack_from('<I',registers,0x48)[0]),
                   gray16(struct.unpack_from('<I',registers,0x4c)[0]))
        delta = tuple((a-b)&0xffff for a,b in zip(current,previous))
        record['samples'].append(dict(flags=flags,csi_frames=current[0],isp_frames=current[1],
                                      csi_delta=delta[0],isp_delta=delta[1]))
        record['iic_error_seen'] |= abi>=0x00010003 and bool(flags&0x100)
        if flags&0xcc0:
            raise RuntimeError('capture writer busy or faulted before capture enable')
        stable = stable+1 if flags&0x1f==0x1f and all(delta) else 0
        if stable>=3:
            record['frame_probe']='CSI_AND_ISP_ADVANCING'
            record['warning']='HISTORICAL_I2C_NO_ACK' if record['iic_error_seen'] else None
            if record['warning']:
                print('CAPTURE_WARNING historical I2C no ACK; current CSI/ISP frames advancing',flush=True)
            return
        previous = current
    record['frame_probe']='NO_STABLE_FRAME_GROWTH'
    raise RuntimeError('camera has no stable CSI/ISP frame growth; capture not enabled; '
                       'retain I2C history and locate failed transaction/ACK stage')


def write_capture_control(registers,offset,value):
    # The shared slave rejects writes during a PL job; use the same file lock
    # as the three actual PL executors. Keep the original register value/width.
    from gp_write_gate import GpWriteGate
    gate=GpWriteGate(os.environ['RESIDENT_GP_LOCK'])
    try:
        with gate.hold():
            struct.pack_into('<I',registers,offset,value)
            if struct.unpack_from('<I',registers,offset)[0]!=value:
                raise RuntimeError('Capture control write did not read back')
    finally:gate.close()


def trace_phase(message):
    # Only enabled for the next actual SError localization; keep markers on UART
    # because a kernel panic prevents fetching files from the temporary root.
    if os.environ.get('RESIDENT_CAPTURE_TRACE')=='1':
        fd=os.open('/dev/console',os.O_WRONLY|os.O_NOCTTY)
        try:os.write(fd,('CAPTURE_PHASE '+message+'\n').encode())
        finally:os.close(fd)


def capture(output,pixel_bytes,roi,timeout=8.0,frame_count=16,status_offset=0,freeze_copy=False,preview_snapshots=False,
            mapped_resize=False,mapped_validate=False,save_snapshots=True,frame_consumer=None,save_inputs=True):
    if pixel_bytes!='BGRX' or list(roi)!=[0,0,224,224] or status_offset!=0x100:
        raise ValueError('AA224 uses network bank and complete 224 BGRX image only')
    if not freeze_copy or mapped_resize or mapped_validate:
        raise ValueError('AA224 requires frozen small copy, without a second resize')
    verify_reservation()
    if status_offset not in (0,0x100):
        raise ValueError('status offset must match the original capture bank or network capture bank')
    if frame_count not in (1,16):
        raise ValueError('frame_count must be 1 for first-image acceptance or 16 for recognition')
    if mapped_resize and not freeze_copy:
        raise ValueError('mapped resize requires stopped, completed writes before reading the slot')
    if mapped_validate and (not mapped_resize or frame_count!=1):
        raise ValueError('mapped validation is a one-frame comparison, not a product hot path')
    x,y,width,height = roi
    if x<0 or y<0 or width<=0 or height<=0 or x+width>1920 or y+height>1080:
        raise ValueError('ROI must be inside the 1920x1080 frame')
    if output.exists():
        raise ValueError('preserve previous capture; choose a new directory')
    output.mkdir(parents=True)
    frames,records = [],[]
    first_image = latest_image = None
    timing = dict(copy_ms=0.0,status_validation_ms=0.0,decode_ms=0.0,status_wait_ms=0.0,
                  preprocess_ms=0.0,snapshot_write_ms=0.0,npy_write_ms=0.0,freeze_wait_ms=0.0)
    copy_attempts = copy_rejected = status_waits = full_roi_copies = 0
    mapped_comparison = None
    preflight = {}
    fd = os.open('/dev/mem',os.O_RDWR|os.O_SYNC|os.O_CLOEXEC)
    armed = False
    try:
        # This bank shares the network reset. An ID read while it is held
        # stalled the board on 2026-10-06; setup must release it first.
        if status_offset==0x100:
            with mmap.mmap(fd,4096,offset=GPIO_BASE) as gpio:
                if not struct.unpack_from('<I',gpio,GPIO_BANK2_DATA)[0]&1:
                    raise RuntimeError('release the qualified network PL reset in setup before shared-bank access')
        with mmap.mmap(fd,4096,offset=STATUS_BASE) as bank, memoryview(bank)[status_offset:] as registers:
            trace_phase('FST1_ID_READ_BEGIN')
            hardware_id,hardware_abi = struct.unpack_from('<2I',registers,0)
            trace_phase('FST1_ID_READ_DONE')
            if hardware_id!=ID or hardware_abi not in SUPPORTED_ABIS:
                raise RuntimeError('wrong bit/status ABI; capture not enabled')
            geometry=struct.unpack_from('<3I',registers,0x64)
            if geometry!=(0x00e000e0,200704,0x41413232):
                raise RuntimeError('wrong AA224 geometry/algorithm; capture not enabled')
            if freeze_copy and hardware_abi<0x00010002:
                raise RuntimeError('freeze-copy requires current writer and AXI completion probes')
            if struct.unpack_from('<I',registers,0x40)[0]!=0:
                raise RuntimeError('capture already enabled; do not take over another session')
            # The reference design holds its UI/FDMA/MIPI reset through PS PL GPIO
            # bank 2 bit 0.  The 2026-09-30 board probe found this bit low after
            # boot; the existing firmware releases it before camera use.
            with mmap.mmap(fd,4096,offset=GPIO_BASE) as gpio:
                current = struct.unpack_from('<I',gpio,GPIO_BANK2_DATA)[0]
                if not current&1:
                    if hardware_abi>=0x00010002 and struct.unpack_from('<I',registers,0x44)[0]&0xc0:
                        raise RuntimeError('capture writer busy or faulted before PL reset release')
                    struct.pack_into('<I',gpio,GPIO_BANK2_DATA,current|1)
                    if not struct.unpack_from('<I',gpio,GPIO_BANK2_DATA)[0]&1:
                        raise RuntimeError('PL GPIO reset release did not read back')
            trace_phase('PREFLIGHT_BEGIN')
            camera_preflight(registers,hardware_abi,preflight)
            trace_phase('PREFLIGHT_DONE')
            with mmap.mmap(fd,SLOT_BYTES*SLOTS,offset=BASE,access=mmap.ACCESS_READ) as slots:
                try:
                    prior = read_status(registers)
                    previous = (prior['epoch'],prior['sequence']) if prior else None
                    csi_before = gray16(struct.unpack_from('<I',registers,0x48)[0]) if hardware_abi>=0x10002 else None
                    trace_phase('ENABLE_WRITE_BEGIN_90000140')
                    write_capture_control(registers,0x40,1)
                    armed = True
                    if struct.unpack_from('<I',registers,0x40)[0]!=1:
                        raise RuntimeError('capture enable did not read back')
                    trace_phase('ENABLE_READBACK_DONE')
                    started = monotonic()
                    next_sample = started
                    while len(frames)<frame_count:
                        if monotonic()-started>timeout:
                            raise TimeoutError(f'{frame_count} complete distinct frames not received')
                        if monotonic()<next_sample:
                            wait_start = monotonic()
                            sleep(min(.005,next_sample-monotonic()))
                            timing['status_wait_ms'] += (monotonic()-wait_start)*1000
                            continue
                        before = read_status(registers)
                        if before is None or (before['epoch'],before['sequence'])==previous:
                            status_waits += 1
                            wait_start = monotonic()
                            sleep(.001)
                            timing['status_wait_ms'] += (monotonic()-wait_start)*1000
                            continue
                        if freeze_copy:
                            # uidbuf tests enable only in S_IDLE. Finish the current
                            # frame and all B responses before copying a stopped slot.
                            freeze_start = monotonic()
                            write_capture_control(registers,0x40,0)
                            if struct.unpack_from('<I',registers,0x40)[0]!=0:
                                raise RuntimeError('capture disable did not read back')
                            stable = 0
                            while stable<2:
                                if monotonic()-freeze_start>.5:
                                    raise TimeoutError('capture did not finish its active frame; preserve slots')
                                words = struct.unpack_from('<14I',registers,0)
                                flags = struct.unpack_from('<I',registers,0x44)[0]
                                aw_count,b_count = struct.unpack_from('<2I',registers,0x50)
                                if words[7] or flags&0xc80:
                                    raise RuntimeError('capture fault while stopping for copy; preserve slots')
                                stable = stable+1 if words[6]==0 and not flags&0x40 and aw_count==b_count else 0
                                sleep(.001)
                            before = read_status(registers)
                            timing['freeze_wait_ms'] += (monotonic()-freeze_start)*1000
                            if before is None or (before['epoch'],before['sequence'])==previous:
                                raise RuntimeError('stopped capture has no new complete frame')
                        trace_phase('FROZEN_FRAME_COPY_BEGIN')
                        offset = before['slot']*SLOT_BYTES
                        image = normalized = raw = None
                        if mapped_resize:
                            # No full-resolution RGB copy for intermediate frames.
                            # The writer stays stopped until this owned 224 tensor is
                            # finished and its source generation is validated below.
                            preprocess_start = monotonic()
                            roi_start = offset+y*896+x*4
                            with memoryview(slots)[roi_start:roi_start+height*896] as view:
                                normalized = normalized_mapped_frame(view,width=width,height=height,
                                    stride_bytes=896,pixel_bytes=pixel_bytes)
                            mapped_ms = (monotonic()-preprocess_start)*1000
                            timing['preprocess_ms'] += mapped_ms
                        if not mapped_resize or mapped_validate or (save_snapshots and len(frames) in (0,frame_count-1)):
                            # Keep first/last screenshots identical to the old path.
                            copy_start = monotonic()
                            if x==0 and width==224:
                                raw = slots[offset+y*896:offset+(y+height)*896]
                            else:
                                raw = b''.join(slots[offset+(y+row)*896+x*4:
                                    offset+(y+row)*896+(x+width)*4] for row in range(height))
                            timing['copy_ms'] += (monotonic()-copy_start)*1000
                            full_roi_copies += 1
                        copy_attempts += 1
                        validation_start = monotonic()
                        after = read_status(registers)
                        if after is not None and before['epoch']!=after['epoch']:
                            raise RuntimeError('capture session reset during copy; physical recovery required')
                        # Reject a torn copy, including a slot recycled during memcpy.
                        if after is None:
                            timing['status_validation_ms'] += (monotonic()-validation_start)*1000
                            copy_rejected += 1
                            if freeze_copy:
                                raise RuntimeError('stopped frame became invalid during copy; preserve slots')
                            continue
                        slot = before['slot']
                        words = struct.unpack_from('<14I',registers,0)
                        last_version = struct.unpack_from('<I',registers,8)[0]
                        if words[7] or words[3]!=before['epoch']:
                            raise RuntimeError('capture fault or reset during copy; preserve reserved slots')
                        if words[2]!=last_version or last_version&1 or words[6]&(1<<slot) or \
                            words[8+2*slot]!=before['generation'] or words[9+2*slot]!=before['generation']:
                            timing['status_validation_ms'] += (monotonic()-validation_start)*1000
                            copy_rejected += 1
                            if freeze_copy:
                                raise RuntimeError('stopped frame changed during copy; preserve slots')
                            continue
                        timing['status_validation_ms'] += (monotonic()-validation_start)*1000
                        if freeze_copy and len(frames)+1<frame_count:
                            write_capture_control(registers,0x40,1)
                            if struct.unpack_from('<I',registers,0x40)[0]!=1:
                                raise RuntimeError('capture resume did not read back')
                        if raw is not None:
                            decode_start = monotonic()
                            image = decode_offline_frame(raw,width=width,height=height,stride_bytes=width*4,
                                pixel_bytes=pixel_bytes,roi_xywh=(0,0,width,height))
                            timing['decode_ms'] += (monotonic()-decode_start)*1000
                        if not mapped_resize or mapped_validate:
                            preprocess_start = monotonic()
                            reference = normalized_small_bgrx(raw)
                            reference_ms = (monotonic()-preprocess_start)*1000
                            timing['preprocess_ms'] += reference_ms
                            if mapped_validate:
                                mapped_comparison = dict(differing=int(np.count_nonzero(normalized!=reference)),
                                    max_abs=float(np.max(np.abs(normalized-reference))),
                                    mapped_ms=mapped_ms,copied_resize_normalize_ms=reference_ms,
                                    copy_ms=timing['copy_ms'],decode_ms=timing['decode_ms'],
                                    scope='SAME_FROZEN_REAL_FRAME_ORIGINAL_PREPROCESS')
                                if mapped_comparison['differing']:
                                    raise RuntimeError('mapped preprocessing does not match original real frame')
                            else:
                                normalized = reference
                        trace_phase('PRIVATE_NORMALIZED_FRAME_DONE')
                        frames.append(normalized if save_inputs else None)
                        stamp = monotonic()
                        records.append(dict(**before,observed_seconds=stamp-started,
                            host_observed_monotonic_seconds=stamp,
                            sequence_gap=None if previous is None else (before['sequence']-previous[1])&0xffffffff))
                        if len(frames)==1:
                            first_image = image
                        if image is not None:
                            latest_image = image
                        if frame_consumer is not None:
                            callback_start = monotonic()
                            frame_consumer(normalized,records[-1])
                            timing['frame_callback_ms'] = timing.get('frame_callback_ms',0.0)+(monotonic()-callback_start)*1000
                        previous = (before['epoch'],before['sequence'])
                        next_sample = max(next_sample+.125,stamp)
                        print('CAPTURE_FRAME',len(frames)-1,before['sequence'],flush=True)
                    sampling_finished = monotonic()
                    csi_after = gray16(struct.unpack_from('<I',registers,0x48)[0]) if hardware_abi>=0x10002 else None
                finally:
                    if armed:
                        write_capture_control(registers,0x40,0)
                        # This only disables future frames. Reserved DDR remains owned.
    except Exception as error:
        (output/'failure.json').write_text(json.dumps(dict(error=str(error),completed_frames=records,preflight=preflight,
            recovery='NO_CAPTURE_RESET_OR_RESERVED_MEMORY_RELEASE; consumer owns any NPU recovery'),indent=2)+'\n')
        raise
    finally:
        os.close(fd)
    snapshot_start = monotonic()
    if save_snapshots and preview_snapshots:
        # Only the display evidence is smaller; all sixteen model tensors
        # above still come from the original full-resolution ROI.
        first_image = first_image.copy()
        latest_image = latest_image.copy()
        first_image.thumbnail((384,216))
        latest_image.thumbnail((384,216))
    # Lossless level 1 saves ~4.3 s per 1080p image on the board; decoded
    # RGB is identical to the previous default level 6.
    if save_snapshots:
        first_image.save(output/'first_frame.png',compress_level=1)
        latest_image.save(output/'latest_frame.png',compress_level=1)
    timing['snapshot_write_ms'] = (monotonic()-snapshot_start)*1000
    npy_start = monotonic()
    if save_inputs:
        video = np.asarray(frames,np.float32)
        np.save(output/'normalized_frames.npy',video)
    video_shape = [len(frames),3,224,224]
    timing['npy_write_ms'] = (monotonic()-npy_start)*1000
    report = dict(scope='LIVE_FDMA_COPY_BEFORE_AND_AFTER_GENERATION_VERIFIED',shape=video_shape,
        pixel_bytes=pixel_bytes,roi=roi,frames=records,capture_ms=(monotonic()-started)*1000,
        hardware_abi=hardware_abi,
        status_base=STATUS_BASE+status_offset,
        preflight=preflight,requested_frames=frame_count,
        sampling_ms=(sampling_finished-started)*1000,timing_ms=timing,
        copy_attempts=copy_attempts,copy_rejected=copy_rejected,status_waits=status_waits,
        full_roi_copies=full_roi_copies,
        preprocess_policy='PL_PILLOW_Q22_AA_RESIZE_CPU_ORIGINAL_NORMALIZE',source_roi=[0,0,1920,1080],
        bytes_copied_per_frame=200704,pl_capture_mode='ONE_REQUEST_ONE_COMPLETE_FRAME',
        mapped_comparison=mapped_comparison,
        snapshot_policy='AFTER_CAPTURE_DISABLED' if save_snapshots else 'DISABLED_HEADLESS',
        snapshot_png_compress_level=1 if save_snapshots else None,
        snapshot_resolution=list(latest_image.size) if save_snapshots else None,
        capture_policy='STOP_FINISH_FRAME_COPY_RESUME' if freeze_copy else 'CONTINUOUS_GENERATION_CHECKED',
        actual_npu_starts=None if frame_consumer is not None else 0,external_frame_consumer=frame_consumer is not None,frame_rate='HOST_SAMPLE_TARGET_8FPS_NOT_SENSOR_RATE',
        sensor_color_validation='REQUIRED_WITH_ACTUAL_IMAGE',
        reservation='PERSISTS_UNTIL_BOOT; disabling does not promise DMA drain')
    span=records[-1]['observed_seconds']-records[0]['observed_seconds']
    report['host_acceptance_span_seconds']=span
    report['host_accepted_fps']=(len(records)-1)/span if span>0 else None
    report['published_frames_skipped_between_acceptances']=sum(
        max(0,row['sequence_gap']-1) for row in records[1:])
    report['csi_counter']=dict(before=csi_before,after=csi_after,
        delta_mod_65536=None if csi_before is None else (csi_after-csi_before)&0xffff,
        scope='CSI_PROBE_DURING_CAPTURE; NOT_EXPOSURE_TIMESTAMPS_OR_CONTINUOUS_30FPS_PROOF')
    (output/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--pixel-bytes',choices=('BGRX','RGBX'),required=True)
    ap.add_argument('--roi',nargs=4,type=int,required=True)
    ap.add_argument('--frame-count',type=int,choices=(1,16),default=16)
    ap.add_argument('--timeout-seconds',type=float,default=8.0,
                    help='Deadline for accepting and preprocessing frames; PNG files are saved afterwards')
    ap.add_argument('--status-offset',type=lambda value:int(value,0),choices=(0,0x100),default=0)
    ap.add_argument('--freeze-copy',action='store_true',
                    help='Finish active writes and pause slot recycling during each full-frame copy')
    ap.add_argument('--preview-snapshots',action='store_true',help='Save 384x216 display previews; keep model input unchanged')
    ap.add_argument('--mapped-resize',action='store_true',help='Resize the frozen slot before copying; requires --freeze-copy')
    ap.add_argument('--mapped-validate',action='store_true',help='Compare both transforms on one frozen real frame')
    ap.add_argument('--no-snapshots',action='store_true',help='Keep model input and JSON; do not copy frames for PNG evidence')
    args = ap.parse_args()
    if args.timeout_seconds<=0:
        ap.error('--timeout-seconds must be positive')
    print(json.dumps(capture(args.output,args.pixel_bytes,args.roi,timeout=args.timeout_seconds,frame_count=args.frame_count,
                             status_offset=args.status_offset,freeze_copy=args.freeze_copy,
                             preview_snapshots=args.preview_snapshots,mapped_resize=args.mapped_resize,
                             mapped_validate=args.mapped_validate,save_snapshots=not args.no_snapshots),indent=2))


if __name__=='__main__':
    main()
