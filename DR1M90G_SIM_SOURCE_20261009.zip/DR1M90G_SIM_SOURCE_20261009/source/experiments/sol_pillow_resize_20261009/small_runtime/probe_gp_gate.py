"""One Linux file-only check before the new live entry; no MMIO or NPU access."""
import fcntl
import json
import subprocess
import sys
from pathlib import Path
from gp_write_gate import GpWriteGate,LockedPlExecutor


def worker(path):
    gate=GpWriteGate(path)
    try:
        with gate.hold(pl_job=True):
            print('PL_LOCK_HELD',flush=True)
            if sys.stdin.readline().strip()!='release':raise RuntimeError('No release signal')
    finally:gate.close()


def probe(path):
    gate=GpWriteGate(path,create=True)
    child=subprocess.Popen([sys.executable,__file__,'worker',str(path)],
                           stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    try:
        assert child.stdout.readline().strip()=='PL_LOCK_HELD'
        try:
            fcntl.flock(gate.fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            raise AssertionError('Capture must not obtain the gate during a PL call')
        child.stdin.write('release\n');child.stdin.flush()
        child.wait(timeout=3)
        assert child.returncode==0
        with gate.hold():pass
        class FailingPl:
            def __call__(self):raise RuntimeError('Simulated PL call failure, no device access')
        try:LockedPlExecutor(FailingPl(),gate)()
        except RuntimeError:pass
        assert Path(path).read_bytes()==b'X'
        try:
            with gate.hold():raise AssertionError('Capture attempted a write after PL fault')
        except RuntimeError as error:
            assert 'Prior PL failure' in str(error)
        print(json.dumps(dict(scope='LINUX_CROSS_PROCESS_FILE_LOCK_NO_DEVICE',
                              mutual_exclusion=True,post_failure_writes_refused=True,
                              actual_device_starts=0,hardware_correctness='NOT_TESTED')),flush=True)
    finally:
        if child.poll() is None:
            child.terminate();child.wait(timeout=3)
        gate.close()
        child.stdin.close();child.stdout.close()


if __name__=='__main__':
    if sys.argv[1]=='worker':worker(sys.argv[2])
    else:probe(sys.argv[1])
