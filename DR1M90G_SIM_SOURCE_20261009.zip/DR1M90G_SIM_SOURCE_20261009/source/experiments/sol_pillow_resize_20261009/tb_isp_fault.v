`timescale 1ns/1ps
module tb_isp_fault;
 reg rx=0,ui=0,rst=0,en=0,valid=0,user=0,last=0;
 wire ov,ou,ol,fault;wire [1:0] reason;wire [23:0] rgb;
 integer i;
 always #5 rx=~rx;
 always #6.25 ui=~ui;
 isp_pixel_serial #(.FIFO_LOG2(4)) dut(rx,ui,rst,en,valid,user,last,
   128'hffffffffffffffffffffffffffffffff,ov,ou,ol,rgb,fault,reason);
 initial begin
  repeat(10)@(negedge rx);rst=1;en=1;repeat(10)@(negedge rx);
  // Sustained ingress exceeds the read rate and deliberately fills a tiny
  // FIFO. This must fail visibly, not yield a silently shortened image.
  for(i=0;i<100;i=i+1)begin
   @(negedge rx);valid=1;user=i==0;last=0;
  end
  @(negedge rx);valid=0;user=0;
  repeat(10)@(negedge ui);
  if(reason!==2'b01 || !fault || ov)$fatal(1,"OVERFLOW_NOT_LATCHED %b",reason);
  en=0;repeat(20)@(negedge rx);en=1;
  repeat(20)@(negedge ui);
  if(!fault || ov)$fatal(1,"FAULT_CLEARED_WITHOUT_RESET");
  $display("FIFO_OVERFLOW_EXPLICIT_STICKY_NO_VALID");
  rst=0;en=0;repeat(10)@(negedge rx);rst=1;en=1;repeat(10)@(negedge rx);
  // First beat cannot also be the last beat of a 1920-pixel line.
  valid=1;user=1;last=1;@(negedge rx);valid=0;user=0;last=0;
  repeat(10)@(negedge ui);
  if(reason!==2'b10 || !fault || ov)$fatal(1,"MALFORMED_NOT_REJECTED %b",reason);
  $display("FRAME_GEOMETRY_FAILURE_EXPLICIT_NO_VALID");$finish;
 end
endmodule
