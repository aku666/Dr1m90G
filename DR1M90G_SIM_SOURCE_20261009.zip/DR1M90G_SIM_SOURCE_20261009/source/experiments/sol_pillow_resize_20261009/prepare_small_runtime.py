"""Patch the already qualified capture/resident entry for AA224 only."""
from pathlib import Path
import hashlib,io,json,tarfile

s=Path(__file__).resolve().parent
with tarfile.open(s.parent/'sol_resident_ring_20261009/live_input4.tgz') as a:
    files={m.name:a.extractfile(m).read() for m in a.getmembers() if m.isfile()}
c=files['capture_callback.py'].decode()
c=c.replace('FRAME_BYTES = 1920*1080*4','FRAME_BYTES = 224*224*4')
c=c.replace('SUPPORTED_ABIS = (0x00010001,0x00010002,0x00010003,0x00010004,0x00010005)  # 1.5 adds DSI frame realignment events.',
            'SUPPORTED_ABIS = (0x00010006,)  # Isolated AA224 only; old full-HD ABI rejected.')
c=c.replace("requires capture FST1 ABI 1.1 through 1.5, not TCON/DUC2",'requires isolated FST1 AA224 ABI 1.6')
c=c.replace('from sign_model.preprocess import normalized_rgb_chw',
            'from small_frame import normalized_small_bgrx')
c=c.replace('    verify_reservation()','''    if pixel_bytes!='BGRX' or list(roi)!=[0,0,224,224] or status_offset!=0x100:
        raise ValueError('AA224 uses network bank and complete 224 BGRX image only')
    if not freeze_copy or mapped_resize or mapped_validate:
        raise ValueError('AA224 requires frozen small copy, without a second resize')
    verify_reservation()''')
c=c.replace("            if freeze_copy and hardware_abi<0x00010002:",'''            geometry=struct.unpack_from('<3I',registers,0x64)
            if geometry!=(0x00e000e0,200704,0x41413232):
                raise RuntimeError('wrong AA224 geometry/algorithm; capture not enabled')
            if freeze_copy and hardware_abi<0x00010002:''')
c=c.replace('if flags&0xc0:', 'if flags&0xcc0:')
c=c.replace('if words[7] or flags&0x80:', 'if words[7] or flags&0xc80:')
c=c.replace('7680','896').replace('width==1920','width==224')
assert c.count("reference = normalized_rgb_chw(image,[224,224],[.485,.456,.406],[.229,.224,.225])")==1
c=c.replace("reference = normalized_rgb_chw(image,[224,224],[.485,.456,.406],[.229,.224,.225])",
            'reference = normalized_small_bgrx(raw)')
c=c.replace("preprocess_policy='FROZEN_MAPPED_RGBX_RESIZE_THEN_CHANNEL_ORDER' if mapped_resize else 'COPIED_RGB_RESIZE',",
            "preprocess_policy='PL_PILLOW_Q22_AA_RESIZE_CPU_ORIGINAL_NORMALIZE',source_roi=[0,0,1920,1080],\n        bytes_copied_per_frame=200704,pl_capture_mode='ONE_REQUEST_ONE_COMPLETE_FRAME',")
files['capture_callback.py']=c.encode()
p=files['capture_producer.py'].decode()
assert p.count("'BGRX',[0,0,1920,1080]")==1
files['capture_producer.py']=p.replace("'BGRX',[0,0,1920,1080]","'BGRX',[0,0,224,224]").encode()
files['small_frame.py']=(s/'small_frame.py').read_bytes()
runtime=s/'small_runtime';runtime.mkdir(exist_ok=True)
for name,data in files.items():
    compile(data,name,'exec')
    (runtime/name).write_bytes(data)
with tarfile.open(s/'small_runtime1.tgz','w:gz') as a:
    for name,data in files.items():
        m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;a.addfile(m,io.BytesIO(data))
archive=s/'small_runtime1.tgz'
print(json.dumps(dict(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),board='NOT_RUN',model_changed=False)))
