"""Derived project only; reuse the qualified PS/network sources read-only."""
from pathlib import Path
import shutil
import xml.etree.ElementTree as E

s=Path(__file__).resolve().parent
base=s.parent/'sol_block34_dw_split_20261008'
out=s/'integrated'
out.mkdir(exist_ok=True)
top=(base/'uisrc/01_rtl/system_top.v').read_text()
top=top.replace('wire capture_enable,display_enable,frame_resetn,write_resetn,read_resetn;',
 '''wire capture_enable,display_enable,frame_resetn,write_resetn,read_resetn;
wire serial_valid,serial_user,serial_last,resize_valid,resize_user,resize_last,resize_fault;
wire [23:0] serial_rgb,resize_rgb;wire [1:0] resize_reason;
isp_pixel_serial serial_pixels(.rx_clk(rx_clk),.ui_clk(ui_clk),.resetn(frame_resetn),
 .enable(capture_enable),.in_valid(pixel_valid),.in_user(pixel_user),.in_last(pixel_last),.in_bgrx(pixels),
 .out_valid(serial_valid),.out_user(serial_user),.out_last(serial_last),.out_rgb(serial_rgb),
 .fault(resize_fault),.fault_reason(resize_reason));
pillow_aa_224 resize(.clk(ui_clk),.resetn(frame_resetn),.in_valid(serial_valid),
 .in_user(serial_user),.in_rgb(serial_rgb),.out_valid(resize_valid),.out_user(resize_user),
 .out_last(resize_last),.out_rgb(resize_rgb));''')
top=top.replace('.W_DATAWIDTH(128)', '.W_DATAWIDTH(32)')
top=top.replace('.W_XSIZE(480),.W_XSTRIDE(480),.W_YSIZE(1080)',
                '.W_XSIZE(224),.W_XSTRIDE(224),.W_YSIZE(224)')
top=top.replace('.I_W_sync(pixel_user)', '.I_W_sync(resize_user)')
top=top.replace('.I_W_wclk(rx_clk),.I_W_rstn(write_resetn),.I_W_tuser(pixel_user),.I_W_tvalid(pixel_valid)',
                '.I_W_wclk(ui_clk),.I_W_rstn(frame_resetn),.I_W_tuser(resize_user),.I_W_tvalid(resize_valid && !resize_fault)')
top=top.replace('.I_W_tdata(pixels),.I_W_tlast(pixel_last)',
                ".I_W_tdata({8'b0,resize_rgb[7:0],resize_rgb[15:8],resize_rgb[23:16]}),.I_W_tlast(resize_last)")
top=top.replace('.I_cap_done(frame_done)', '.I_cap_done(frame_done && !resize_fault)')
top=top.replace('.I_cap_fault(fault)', '.I_cap_fault(fault || resize_fault)')
top=top.replace('.I_cap_flags(flags)', ".I_cap_flags(flags | {20'b0,resize_reason,10'b0})")
(out/'system_top.v').write_text(top)
control=(base/'uisrc/01_rtl/v4r_c128/net_pl_control.v').read_text()
assert "32'h104: S_AXI_RDATA<=32'h00010003;" in control
control=control.replace("32'h104: S_AXI_RDATA<=32'h00010003;", """32'h104: S_AXI_RDATA<=32'h00010006;
                    32'h164: S_AXI_RDATA<=32'h00e000e0; // 224x224 BGRX
                    32'h168: S_AXI_RDATA<=32'd200704; // complete image bytes
                    32'h16c: S_AXI_RDATA<=32'h41413232; // AA22, exact Q22 filter""")
(out/'net_pl_control.v').write_text(control)
for name in ['h_coeff.hex','v_coeff.hex']:
    shutil.copyfile(s/name,out/name)
t=E.parse(base/'soc_v2.prj');r=t.getroot();r.set('Path',out.as_posix())
r.find('Name').text='camera_small_aa224'
replace={'uisrc/01_rtl/system_top.v':out/'system_top.v',
         'uisrc/01_rtl/v4r_c128/net_pl_control.v':out/'net_pl_control.v'}
for f in r.findall('Source_Files/*/File'):
    p=f.get('Path');f.set('Path',replace.get(p,base/p).resolve().as_posix())
for order,name in enumerate(['isp_pixel_serial.v','pillow_aa_224.v'],120):
    f=E.SubElement(r.find('Source_Files/Verilog'),'File',Path=(s/name).as_posix())
    info=E.SubElement(f,'FileInfo')
    for k,v in [('UsedInSyn','true'),('UsedInP&R','true'),('BelongTo','design_1'),('CompileOrder',str(order))]:
        E.SubElement(info,'Attr',Name=k,Val=v)
E.indent(t);t.write(out/'camera_small_aa224.prj',encoding='utf-8')
print('Prepared isolated small-image project; existing PS/network source unchanged.')
