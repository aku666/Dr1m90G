// Fixed 1920x1080 -> 224x224. RGB byte 0=R, 1=G, 2=B.
// One serial pixel per clock; the existing four-pixel CSI beat needs an
// elastic width converter before this core. No DDR writer/CDC is implied.
module pillow_aa_224(
 input wire clk,resetn,input wire in_valid,in_user,input wire [23:0] in_rgb,
 output reg out_valid,out_user,out_last,output reg [23:0] out_rgb
);
 reg [55:0] h_rom[0:1919],v_rom[0:1079];
 initial begin $readmemh("h_coeff.hex",h_rom);$readmemh("v_coeff.hex",v_rom);end
 reg [10:0] x,y;
 wire [10:0] sx=in_user ? 0:x;
 wire [10:0] sy=in_user ? 0:y;
 reg h1,h2,hv,v1,v2;
 reg [55:0] hm1,hm2,vm1,vm2;
 reg [23:0] hp1,h_rgb,vp1;
 reg [10:0] hy1,hy2,h_y;
 reg [7:0] hx,vc1,vc2;
 reg [29:0] ph0[0:2],ph1[0:2],pv0[0:2],pv1[0:2];
 reg [31:0] ha0[0:2],ha1[0:2];
 // Two destination-row accumulator banks. First-contribution bits overwrite
 // old frame contents; never keep a full-resolution frame in the core.
 reg [95:0] vertical0[0:223],vertical1[0:223];
 reg [95:0] vr0,vr1,old0,old1;
 wire [31:0] hs0[0:2],hs1[0:2],vs0[0:2],vs1[0:2];
 function [29:0] product22;
  input [7:0] pixel;input [21:0] coeff;
  reg [25:0] low;reg [11:0] high;
  begin
   low=pixel*coeff[17:0];
   // Keep the upper four bits exact with explicit shifts/adds, not another
   // wide DSP multiplier or a reduced-precision coefficient.
   high=(coeff[18] ? {4'b0,pixel}:12'b0)+
        (coeff[19] ? {3'b0,pixel,1'b0}:12'b0)+
        (coeff[20] ? {2'b0,pixel,2'b0}:12'b0)+
        (coeff[21] ? {1'b0,pixel,3'b0}:12'b0);
   product22={4'b0,low}+{high,18'b0};
  end
 endfunction
 function [7:0] clip_round;
  input [31:0] accumulator;
  begin clip_round=(|accumulator[31:30]) ? 8'hff:accumulator[29:22];end
 endfunction
 genvar c;
 generate for(c=0;c<3;c=c+1) begin:channel
  assign hs0[c]=(hm2[44] ? 32'd2097152:ha0[c])+{2'b0,ph0[c]};
  assign hs1[c]=(hm2[45] ? 32'd2097152:ha1[c])+{2'b0,ph1[c]};
  assign vs0[c]=(vm2[44] ? 32'd2097152:old0[c*32+:32])+{2'b0,pv0[c]};
  assign vs1[c]=(vm2[45] ? 32'd2097152:old1[c*32+:32])+{2'b0,pv1[c]};
 end endgenerate
 integer i;
 always @(posedge clk) begin
  if(!resetn) begin
   x<=0;y<=0;h1<=0;h2<=0;hv<=0;v1<=0;v2<=0;
   out_valid<=0;out_user<=0;out_last<=0;out_rgb<=0;
   for(i=0;i<3;i=i+1)begin ha0[i]<=0;ha1[i]<=0;end
  end else begin
   h1<=in_valid;h2<=h1;hv<=0;v1<=hv;v2<=v1;
   out_valid<=0;out_user<=0;out_last<=0;
   if(in_valid) begin
    hm1<=h_rom[sx];hp1<=in_rgb;hy1<=sy;
    if(sx==1919)begin x<=0;y<=sy==1079 ? 0:sy+1'b1;end
    else begin x<=sx+1'b1;y<=sy;end
   end
   if(h1) begin
    hm2<=hm1;hy2<=hy1;
    for(i=0;i<3;i=i+1)begin
     ph0[i]<=product22(hp1[i*8+:8],hm1[21:0]);
     ph1[i]<=product22(hp1[i*8+:8],hm1[43:22]);
    end
   end
   if(h2) begin
    for(i=0;i<3;i=i+1)begin
     if(hm2[21:0]!=0)ha0[i]<=hs0[i];
     if(hm2[43:22]!=0)ha1[i]<=hs1[i];
     if(hm2[46] || hm2[47])h_rgb[i*8+:8]<=clip_round(hm2[46] ? hs0[i]:hs1[i]);
    end
    if(hm2[46] || hm2[47])begin hv<=1;hx<=hm2[55:48];h_y<=hy2;end
   end
   if(hv)begin
    vm1<=v_rom[h_y];vp1<=h_rgb;vc1<=hx;
    vr0<=vertical0[hx];vr1<=vertical1[hx];
   end
   if(v1)begin
    vm2<=vm1;vc2<=vc1;old0<=vr0;old1<=vr1;
    for(i=0;i<3;i=i+1)begin
     pv0[i]<=product22(vp1[i*8+:8],vm1[21:0]);
     pv1[i]<=product22(vp1[i*8+:8],vm1[43:22]);
    end
   end
   if(v2)begin
    for(i=0;i<3;i=i+1)begin
     if(vm2[21:0]!=0)vertical0[vc2][i*32+:32]<=vs0[i];
     if(vm2[43:22]!=0)vertical1[vc2][i*32+:32]<=vs1[i];
     if(vm2[46] || vm2[47])out_rgb[i*8+:8]<=clip_round(vm2[46] ? vs0[i]:vs1[i]);
    end
    if(vm2[46] || vm2[47])begin
     out_valid<=1;out_user<=vm2[55:48]==0 && vc2==0;out_last<=vc2==223;
    end
   end
  end
 end
endmodule
