`timescale 1ns/1ps
module tb_resize;
 reg clk=0,resetn=0,valid=0,user=0;reg [23:0] pixel;
 wire out_valid,out_user,out_last;wire [23:0] actual;
 reg [23:0] input_pixels[0:2073599],expected[0:50175];
 integer idx,count=0,cycles=0,case_id=0;reg [255:0] filename;
 always #6.25 clk=~clk;
 pillow_aa_224 dut(clk,resetn,valid,user,pixel,out_valid,out_user,out_last,actual);
 always @(negedge clk)begin
  cycles=cycles+1;
  if(out_valid)begin
   if(count>=50176 || actual!==expected[count])$fatal(1,"PIXEL_DIFF case=%0d idx=%0d actual=%h expected=%h",case_id,count,actual,expected[count]);
   if(out_user!==(count==0) || out_last!==(count%224==223))$fatal(1,"ROW_FRAME_MARKER_DIFF %0d",count);
   count=count+1;
  end
 end
 initial begin
  repeat(3)@(negedge clk);resetn=1;
  for(case_id=0;case_id<3;case_id=case_id+1)begin
   $sformat(filename,"input%0d.hex",case_id);$readmemh(filename,input_pixels);
   $sformat(filename,"expected%0d.hex",case_id);$readmemh(filename,expected);
   count=0;
   for(idx=0;idx<2073600;idx=idx+1)begin
    @(negedge clk);valid=1;user=idx==0;pixel=input_pixels[idx];
    // Real bubbles exercise metadata/ROM/data alignment across clock gaps.
    if(idx%1920==1000)begin @(negedge clk);valid=0;user=0;end
   end
   @(negedge clk);valid=0;user=0;
   repeat(12)@(negedge clk);
   if(count!=50176)$fatal(1,"FRAME_INCOMPLETE %0d",count);
   $display("REAL_1080P_PILLOW_Q22_RTL_PASS case=%0d pixels=%0d cycles=%0d",case_id,count,cycles);
  end
  $display("THREE_DISTINCT_REAL_FRAMES_PIXEL_EXACT_NO_DDR_NO_BOARD");$finish;
 end
endmodule
