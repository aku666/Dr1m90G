"""Standalone core project, generated only inside the current worktree."""
from pathlib import Path
import xml.etree.ElementTree as E
s=Path(__file__).resolve().parent
root=s.parents[1]
t=E.parse(root/'experiments/sol_block34_dw_split_20261008/soc_v2.prj')
r=t.getroot();r.set('Path',s.as_posix());r.find('Name').text='pillow_aa_224'
files=r.find('Source_Files');files.clear()
f=E.SubElement(E.SubElement(files,'Verilog'),'File',Path='pillow_aa_224.v')
info=E.SubElement(f,'FileInfo')
for k,v in [('UsedInSyn','true'),('UsedInP&R','true'),('BelongTo','design_1'),('CompileOrder','1')]:
    E.SubElement(info,'Attr',Name=k,Val=v)
r.find('TOP_MODULE/LABEL').text='pillow_aa_224';r.find('TOP_MODULE/MODULE').text='pillow_aa_224'
E.indent(t);t.write(s/'pillow_aa_224.prj',encoding='utf-8')
