from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
log=(s/'isp_sim1.log').read_text()
assert log.count('ISP_CDC_REAL_FRAME_EXACT')==2
assert 'ISP_CDC_TWO_FRAMES_PIXEL_EXACT_SIM_ONLY' in log
assert 'FIFO_OVERFLOW_EXPLICIT_STICKY_NO_VALID' in (s/'isp_fault1.log').read_text()
assert 'FRAME_GEOMETRY_FAILURE_EXPLICIT_NO_VALID' in (s/'isp_fault1.log').read_text()
assert 'SMALL_UIDBUF_REAL_PIXELS_PASS pixels=50176 bursts=448 bytes=200704 slot=1' in (s/'small_fdma3.log').read_text()
build=(s/'integrated/build_small2.log').read_text()
assert 'CAMERA_SMALL_AA224_GATE_COMPLETE' in build
area=(s/'integrated/camera_small_aa224_gate.area').read_text()
resource={k:int(re.search(r'^'+re.escape(tag)+r'\s+(\d+)',area,re.M)[1])
          for k,tag in [('slices','#slice*'),('eram','#eram'),('dsp','#dsp')]}
archive=s/'small_runtime1.tgz'
physical=(s/'integrated/camera_small_aa224_phy.area').read_text()
physical_resource={k:int(re.search(r'^'+re.escape(tag)+r'\s+(\d+)',physical,re.M)[1])
          for k,tag in [('slices','#slice'),('eram','#eram'),('dsp','#dsp')]}
sta=(s/'integrated/camera_small_aa224_first_stage.ts').read_text()
assert 'SWNS: 0.103ns, STNS: 0.000ns.' in sta
assert 'HWNS: 0.024ns, HTNS: 0.000ns.' in sta
assert 'CAMERA_SMALL_AA224_FIRST_STAGE_STA_COMPLETE' in (s/'integrated/first_stage_small2.log').read_text()
report=dict(scope='ISP_4PIX_CDC_EXACT_AA224_SMALL_UIDBUF_RESIDENT_INPUT_CANDIDATE',
 coded='PASS',sim='PASS_TWO_REAL_SOURCE_FRAMES_100352_PIXELS_ZERO_DIFF',
 fifo_fault_sim='PASS_OVERFLOW_AND_MALFORMED_LINE_LATCH_STOP',
 small_uidbuf_sim=dict(pixels=50176,bursts=448,burst_64bit_beats=56,bytes=200704,slot=1,
                      scope='RTL_FAKE_FDMA_NOT_DDR_BOARD'),
 simulated_rx_mhz=100,simulated_ui_mhz=80,source_line_period_us=32,
 simulated_source_fps=1e6/(32*1080),sensor_fps='NOT_MEASURED_BY_THIS_STAGE',
 request_mode='ONE_ENABLE_REQUEST_ONE_COMPLETE_FRAME; LOW_REARMS',
 fifo_storage_bits=104*2048,full_hd_frame_storage=False,
 combined_synth='GATE_PASS',combined_gate_resource=resource,
 baseline_same_gate_resource=dict(slices=43045,eram=150,dsp=174),
 capture_abi='0x10006',geometry='224x224 BGRX',algorithm='AA22 Q22 TWO_UINT8_PASSES',
 reservation='UNCHANGED_0x0a000000_THREE_8MiB_SLOTS',
 pnr='ROUTED; CURRENT_TIMED_CLOCKS_FIRST_STAGE_STA_PASS',
 physical_resource=physical_resource,setup_wns_ns=.103,hold_wns_ns=.024,
 sta_coverage_percent=64.82,
 sta_scope='EXISTING_TIMED_CLOCKS; EXTERNAL_MIPI_RX_CLOCK_NOT_IN_CLOCK_SUMMARY; NOT_FULL_IO_TIMING_PROOF',
 cdc_exceptions='31_ACTUAL_FIRST_STAGE_PAIRS_ONLY; ALL_RESIZE_DW_AXI_DATA_PATHS_REMAIN_TIMED',
 bit='NOT_BUILT',board='NOT_RUN',
 cpu_normalization=json.loads((s/'small_tensor.json').read_text()),
 runtime=dict(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
 next_board='AFTER_NEW_PHYSICAL_RECOVERY_FIRST_VALIDATE_EXISTING_GP_SERIALIZED_LIVE; FIX_SOURCE_RATE_SERVICE_BUDGET_BEFORE_NEW_CAPTURE_ACCEPTANCE',
 rate_blocker='PREVIOUS_CSI_ISP_5_TO_6_PER_0_1s_APPROX_50fps_EXCEEDS_SERIAL_80MHz_FULL_PIXEL_SERVICE; ONE_SHOT_DOES_NOT_PROVE_FRAME_INTRABURST_CAPACITY',
 preserved='MODEL_QUANTIZATION_NPU_DRIVERS_PS_PLL_PINS_AXI_B_COMMIT_AND_RESERVED_BUFFER_LIFETIME',
 default_changed=False,quality='PC_PIXEL_INPUT_EXACT; TASK_QUALITY_NOT_NEWLY_CALIBRATED',
 end_to_end_speed='NOT_MEASURED; PRIOR_SPACE_NETWORK_APPROX_380ms_PER_FRAME_UNCHANGED',
 sim_compatibility='uidbuf_sim removes duplicate declaration and moves five declarations before use only; FPGA uses original uidbuf')
(s/'integration_qualification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
original=json.loads((s/'qualification.json').read_text())
original['integration']='CODED_SIM_COMBINED_SYNTH_ROUTED_TIMED_CLOCK_STA_PASS; RATE_BUDGET_AND_BOARD_PENDING'
original['integration_evidence']='integration_qualification.json'
(s/'qualification.json').write_text(json.dumps(original,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(sim='PASS',combined_synth='PASS',resource=resource,board='NOT_RUN')))
