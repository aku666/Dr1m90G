"""Owned CPU tensor from a completed AA224 BGRX slot; no device access."""
import numpy as np

def normalized_small_bgrx(raw):
    if len(raw)!=224*224*4:
        raise ValueError('AA224 requires exactly 200704 complete BGRX bytes')
    pixels=np.frombuffer(raw,np.uint8).reshape(224,224,4)
    rgb=pixels[:,:,[2,1,0]].astype(np.float32)/255.0
    mean=np.asarray([.485,.456,.406],np.float32).reshape(1,1,3)
    std=np.asarray([.229,.224,.225],np.float32).reshape(1,1,3)
    return np.ascontiguousarray(((rgb-mean)/std).transpose(2,0,1))
