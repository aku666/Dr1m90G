SWNS: -0.317ns, STNS: -0.896ns.
HWNS: -1.198ns, HTNS: -15.470ns.
