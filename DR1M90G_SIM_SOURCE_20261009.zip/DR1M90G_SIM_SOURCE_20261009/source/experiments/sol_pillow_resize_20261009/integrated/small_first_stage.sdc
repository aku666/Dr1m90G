# Only actual first-stage receiving pins; functional data paths remain timed.
# EXISTING_PS_RESET_EXTERNAL_FIRST_STAGE
set_false_path -from [get_pins {I_system/ARM_Processor_System_0/ARM_Processor_System_59fb6a0bf2ca_Inst/DR1_PHY_PROCESSOR_SYSTEM_Inst.p2f_clk0_rst_n}] -to [get_pins {I_system/Processor_System_Reset_0/proc_sys_reset_003909975d3e_Inst/u_low_per_fun/cdc_synchronization_external_reg[1]_syn_2.ie}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[11]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[9]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[11]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[5]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[4]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[3]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[4]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[5]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[5]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[2]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[5]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[5]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[6]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[2]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg_reg[6]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[6]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/secondary_addr_o_reg[11]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[6]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[3]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[10]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[7]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[10]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[7]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[2]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[2]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[3]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[3]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[4]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[4]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[4]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[4]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[5]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[6]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[9]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[9]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[9]_syn_2.imb}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_sync_reg[6]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[8]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/secondary_addr_o_reg[10]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg_reg[3]_syn_2.ima}]
# EXISTING_FIFO_GRAY_FIRST_STAGE
set_false_path -from [get_pins {buffers/rdbuf_fifo/wr_to_rd_cross_inst/sync_r1_reg[2]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/rd_to_wr_cross_inst/sync_r1_reg[9]_syn_2.ima}]
# EXISTING_FLAGS_FIRST_STAGE
set_false_path -from [get_pins {camera/u_uicfg_imx415/O_ae_cfg_done_reg_syn_8.clk}] -to [get_pins {probe/flags_meta_reg[3]_syn_2.imb}]
# EXISTING_FLAGS_FIRST_STAGE
set_false_path -from [get_pins {camera/u_uicfg_imx415/REG_DATA_b[22]_syn_5.clk}] -to [get_pins {probe/flags_meta_reg[3]_syn_2.ima}]
# EXISTING_FLAGS_FIRST_STAGE
set_false_path -from [get_pins {iic_seen_reg_syn_6.clk}] -to [get_pins {probe/flags_meta_reg[8]_syn_2.ima}]
# EXISTING_LOCAL_RESET_FIRST_STAGE
set_false_path -from [get_pins {probe/flags_meta_reg[0]_syn_2.clk}] -to [get_pins {camera/camera_reset_sync/release_pipe_reg[0]_syn_2.asr}]
# EXISTING_FIFO_RESET_FIRST_STAGE
set_false_path -from [get_pins {r_sync/release_pipe_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/asy_w_rst0_reg_syn_3.asr}]
# EXISTING_SCAN_READY_FIRST_STAGE
set_false_path -from [get_pins {scan_start/prefilled_reg_syn_6.clk}] -to [get_pins {scan_start/ready_meta_reg_syn_3.ima}]
# EXISTING_FIFO_RESET_FIRST_STAGE
set_false_path -from [get_pins {ui_sync/release_pipe_reg[0]_syn_2.clk}] -to [get_pins {buffers/rdbuf_fifo/asy_r_rst0_reg_syn_3.asr}]
# EXISTING_LOCAL_RESET_FIRST_STAGE
set_false_path -from [get_pins {ui_sync/release_pipe_reg[0]_syn_2.clk}] -to [get_pins {r_sync/release_pipe_reg[0]_syn_2.asr}]
