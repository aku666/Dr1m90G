import_device dr1_90.db -package DR1M90GEG400 -speed 2
open_project camera_small_aa224.prj -noanalyze
import_db camera_small_aa224_gate.db
clear_sdc
read_adc ../../sol_block34_dw_split_20261008/camera_dsi_pins.adc
read_sdc -ip system_ARM_Processor_System_0 ../../sol_block34_dw_split_20261008/board_softnpu_80mhz.sdc
read_sdc ../../sol_block34_dw_split_20261008/uisrc/04_pin/timing.sdc
legalize_phy_inst
place
export_db camera_small_aa224_place.db
route
report_area -io_info -file camera_small_aa224_phy.area
update_timing -mode final
report_timing_status -file camera_small_aa224_raw.ts
report_timing_summary -file camera_small_aa224_raw.timing
report_timing_exception -file camera_small_aa224_raw_exception.timing
export_db camera_small_aa224_route.db
puts CAMERA_SMALL_AA224_RAW_ROUTE_COMPLETE
exit
