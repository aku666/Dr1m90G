"""Reapply the qualified first-stage CDC policy to this route's actual pins.

Never exempt the resize/DW/AXI paths or later synchronizer stages. TD sometimes
names a packed slice after another register: inspect its receiving output net.
"""
from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
text=(s/'camera_small_aa224_raw.timing').read_text()
followup=s/'camera_small_aa224_first_stage.timing'
if followup.exists():text+='\n'+followup.read_text()
pairs={}
unhandled=[]
for block in text.split('Slack               :')[1:]:
    m=re.search(r'Begin Point\s+: (\S+).*?End Point\s+: (\S+)',block,re.S)
    if not m:continue
    source,target=m.groups()
    capture=re.search(r'^(?:reg\s+|\S+\s+\(reg\)\s+)[^\n]*net:\s+(\S+),',block,re.M)
    net=capture.group(1) if capture else ''
    kind=None
    if 'buffers/rdbuf_fifo/' in target and '/sync_r1[' in net:
        kind='EXISTING_FIFO_GRAY_FIRST_STAGE'
    elif net.startswith('probe/flags_meta['):kind='EXISTING_FLAGS_FIRST_STAGE'
    elif net.startswith('scan_start/ready_meta'):kind='EXISTING_SCAN_READY_FIRST_STAGE'
    elif re.search(r'buffers/rdbuf_fifo/asy_[rw]_rst0_reg',target) and target.endswith('.asr'):
        kind='EXISTING_FIFO_RESET_FIRST_STAGE'
    elif re.search(r'(?:r_sync|camera/camera_reset_sync)/release_pipe_reg\[0\].*\.asr$',target):
        kind='EXISTING_LOCAL_RESET_FIRST_STAGE'
    elif source.endswith('.p2f_clk0_rst_n') and net.endswith('/cdc_synchronization_external[0]'):
        kind='EXISTING_PS_RESET_EXTERNAL_FIRST_STAGE'
    if kind:pairs[(source,target)]=dict(kind=kind,receiving_net=net)
    elif float(block.strip().split('ns',1)[0])<0:
        unhandled.append(dict(source=source,target=target,receiving_net=net))
assert not unhandled,unhandled
lines=['# Only actual first-stage receiving pins; functional data paths remain timed.']
for (source,target),record in sorted(pairs.items()):
    lines.extend(['# '+record['kind'],f'set_false_path -from [get_pins {{{source}}}] -to [get_pins {{{target}}}]'])
(s/'small_first_stage.sdc').write_text('\n'.join(lines)+'\n')
(s/'small_first_stage.json').write_text(json.dumps([dict(source=a,target=b,**r) for (a,b),r in sorted(pairs.items())],indent=2)+'\n')
print('Actual verified first-stage pairs:',len(pairs),'unhandled negative paths:',len(unhandled))
