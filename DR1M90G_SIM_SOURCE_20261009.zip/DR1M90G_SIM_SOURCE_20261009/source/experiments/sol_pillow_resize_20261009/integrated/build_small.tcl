import_device dr1_90.db -package DR1M90GEG400 -speed 2
open_project camera_small_aa224.prj
elaborate -top system_top
optimize_rtl
export_db camera_small_aa224_rtl.db
read_adc ../../sol_block34_dw_split_20261008/camera_dsi_pins.adc
optimize_gate -packarea camera_small_aa224_gate.area
export_db camera_small_aa224_gate.db
puts CAMERA_SMALL_AA224_GATE_COMPLETE
exit
