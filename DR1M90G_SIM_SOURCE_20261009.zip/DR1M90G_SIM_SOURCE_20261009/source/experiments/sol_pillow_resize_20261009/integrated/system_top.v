`timescale 1ns/1ps
module system_top(input wire I_sysclk,input wire [1:0] I_button,
input wire I_clk_hs_p,input wire [3:0] I_data_hs_p,I_data_lp_p,I_data_lp_n,
output wire O_clk_24m,O_cam_scl,inout wire IO_cam_sda,
output wire O_clk_hs_p,O_clk_lp_p,O_clk_lp_n,
output wire [3:0] O_data_hs_p,O_data_lp_p,O_data_lp_n);
wire ui_clk,ui_resetn,locked,cam_cfg_done,ae_cfg_done,iic_error,rx_clk,csi_start;
wire [3:0] lane_error;wire cam_clk24,rx_valid;
wire [127:0] pixels; wire pixel_last,pixel_user,pixel_valid,isp_ready;
wire capture_enable,display_enable,frame_resetn,write_resetn,read_resetn;
wire serial_valid,serial_user,serial_last,resize_valid,resize_user,resize_last,resize_fault;
wire [23:0] serial_rgb,resize_rgb;wire [1:0] resize_reason;
isp_pixel_serial serial_pixels(.rx_clk(rx_clk),.ui_clk(ui_clk),.resetn(frame_resetn),
 .enable(capture_enable),.in_valid(pixel_valid),.in_user(pixel_user),.in_last(pixel_last),.in_bgrx(pixels),
 .out_valid(serial_valid),.out_user(serial_user),.out_last(serial_last),.out_rgb(serial_rgb),
 .fault(resize_fault),.fault_reason(resize_reason));
pillow_aa_224 resize(.clk(ui_clk),.resetn(frame_resetn),.in_valid(serial_valid),
 .in_user(serial_user),.in_rgb(serial_rgb),.out_valid(resize_valid),.out_user(resize_user),
 .out_last(resize_last),.out_rgb(resize_rgb));
wire scan_clk,scan_de,scan_vsync,display_scan_enabled,display_rbusy,display_rvalid,display_rready,display_rreq;
wire [31:0] display_raddr,display_pixel; wire [15:0] display_rsize;
wire [63:0] display_rdata;
wire raw_busy,safe_busy,fault,commit,fdma_wvalid,fdma_wready,fdma_req,frame_done;
wire [31:0] fdma_addr;wire [15:0] fdma_size;wire [63:0] fdma_data;
wire [7:0] slot,done_slot;
wire awvalid,awready,bvalid,bready;wire [1:0] bresp;
wire [31:0] flags,csi_gray,isp_gray,aw_count,b_count,rx_gray,valid_gray;
reg iic_seen=0;
always @(posedge cam_clk24 or negedge locked)
 if(!locked) iic_seen<=0; else if(iic_error) iic_seen<=1;
reference_camera_path camera(.I_sysclk(I_sysclk),.p2f_rst0_n(ui_resetn),.I_button(I_button),
 .I_clk_hs_p(I_clk_hs_p),.I_data_hs_p(I_data_hs_p),.I_data_lp_p(I_data_lp_p),.I_data_lp_n(I_data_lp_n),
 .O_clk_24m(O_clk_24m),.O_cam_scl(O_cam_scl),.IO_cam_sda(IO_cam_sda),
 .locked(locked),.cam_cfg_done(cam_cfg_done),.ae_cfg_done(ae_cfg_done),.iic_error(iic_error),
 .S_hs_rx_clk(rx_clk),.S_csi_frame_start(csi_start),.S_lane_error(lane_error),
 .ISP_O_tdata(pixels),.ISP_O_tlast(pixel_last),.ISP_O_tuser(pixel_user),.ISP_O_tvalid(pixel_valid),
 .ISP_O_tready(isp_ready),.camera_clk24m(cam_clk24),.receiver_valid(rx_valid),
 .I_video_in_data(display_scan_enabled ? display_pixel[23:0] : 24'b0),.scan_clk(scan_clk),.scan_de(scan_de),.scan_vsync(scan_vsync),
 .O_clk_hs_p(O_clk_hs_p),.O_clk_lp_p(O_clk_lp_p),.O_clk_lp_n(O_clk_lp_n),
 .O_data_hs_p(O_data_hs_p),.O_data_lp_p(O_data_lp_p),.O_data_lp_n(O_data_lp_n));
fdma_frame_reset_sync ui_sync(.clk(ui_clk),.async_resetn(ui_resetn && locked),.frame_resetn(frame_resetn));
fdma_frame_reset_sync w_sync(.clk(rx_clk),.async_resetn(frame_resetn),.frame_resetn(write_resetn));
fdma_frame_reset_sync r_sync(.clk(scan_clk),.async_resetn(frame_resetn),.frame_resetn(read_resetn));
dsi_scan_start scan_start(.ui_clk(ui_clk),.ui_resetn(frame_resetn),.display_enable(display_enable),
 .read_word_valid(display_rvalid),.scan_clk(scan_clk),.scan_resetn(read_resetn),
 .scan_vsync(scan_vsync),.scan_enabled(display_scan_enabled));
fdma_write_commit_guard commit_guard(.clk(ui_clk),.rst_n(frame_resetn),.raw_wbusy(raw_busy),
 .awvalid(awvalid),.awready(awready),.bvalid(bvalid),.bready(bready),.bresp(bresp),
 .safe_wbusy(safe_busy),.fault(fault),.transfer_committed(commit));
uidbuf #(.AXI_DATA_WIDTH(64),.AXI_ADDR_WIDTH(32),.W_BUFDEPTH(2048),.W_DATAWIDTH(32),
 .W_BASEADDR(32'h0a000000),.W_DSIZEBITS(23),.W_XSIZE(224),.W_XSTRIDE(224),.W_YSIZE(224),
 .W_XDIV(2),.W_BUFSIZE(3),.R_BASEADDR(32'h0b800000),.R_DSIZEBITS(22),.R_XSIZE(1024),.R_XSTRIDE(1024),.R_YSIZE(600),.R_XDIV(2),.R_BUFSIZE(1),.R_SYNC(0)) buffers(
 .I_ui_clk(ui_clk),.I_ui_rstn(frame_resetn),.I_W_en(capture_enable),.I_W_sync(resize_user),
 .I_W_wclk(ui_clk),.I_W_rstn(frame_resetn),.I_W_tuser(resize_user),.I_W_tvalid(resize_valid && !resize_fault),
 .I_W_tdata({8'b0,resize_rgb[7:0],resize_rgb[15:8],resize_rgb[23:16]}),.I_W_tlast(resize_last),.O_W_tready(),.O_W_sync_cnt(slot),.I_W_buf(slot),
 .O_fdma_waddr(fdma_addr),.O_fdma_wareq(fdma_req),.O_fdma_wsize(fdma_size),
 .I_fdma_wbusy(safe_busy),.O_fdma_wdata(fdma_data),.I_fdma_wvalid(fdma_wvalid),
 .O_fdma_wready(fdma_wready),.O_fdma_wbuf(done_slot),.O_fdma_wirq(frame_done),
 .I_R_en(display_enable),.I_R_sync(1'b0),.I_R_rclk(scan_clk),.I_R_rstn(read_resetn),.I_R_tready(scan_de && display_scan_enabled),
 .O_R_tdata(display_pixel),.I_R_buf(8'b0),.I_fdma_rbusy(display_rbusy),.I_fdma_rdata(display_rdata),.I_fdma_rvalid(display_rvalid),
 .O_fdma_raddr(display_raddr),.O_fdma_rareq(display_rreq),.O_fdma_rsize(display_rsize),.O_fdma_rready(display_rready));
capture_stream_probe probe(.ui_clk(ui_clk),.ui_resetn(frame_resetn),.rx_clk(rx_clk),.rx_resetn(locked),
 .csi_start(csi_start),.isp_start(pixel_user && pixel_valid),.hs_valid(rx_valid),
 .flags_async({(|lane_error),iic_seen,fault,raw_busy,isp_ready,ae_cfg_done,cam_cfg_done,locked,locked,ui_resetn}),
 .aw_fire(awvalid && awready),.b_fire(bvalid && bready),.flags(flags),.csi_gray(csi_gray),
 .isp_gray(isp_gray),.aw_count(aw_count),.b_count(b_count),.rx_gray(rx_gray),.valid_gray(valid_gray));
system I_system(.O_ui_clk(ui_clk),.O_ui_rstn(ui_resetn),
 .I_fdma_waddr(32'b0),.I_fdma_wareq(1'b0),.I_fdma_wsize(16'b0),.I_fdma_wdata(64'b0),.I_fdma_wready(1'b0),
 .I_fdma_raddr(32'b0),.I_fdma_rareq(1'b0),.I_fdma_rsize(16'b0),.I_fdma_rready(1'b0),
 .I_mwdata(32'b0),.I_irq2(1'b0),.I_video_in_data(24'b0),.I_video_in_de(1'b0),.I_video_in_vs(1'b0),.I_video_in_hs(1'b0),
 .I_cap_resetn(frame_resetn),.I_cap_slot(slot),.I_cap_done(frame_done && !resize_fault),.I_cap_done_slot(done_slot),.I_cap_fault(fault || resize_fault),
 .I_cap_addr(fdma_addr),.I_cap_req(fdma_req),.I_cap_size(fdma_size),.I_cap_data(fdma_data),.I_cap_ready(fdma_wready),.I_disp_addr(display_raddr),.I_disp_req(display_rreq),.I_disp_size(display_rsize),
 .I_disp_ready(display_rready),.O_disp_busy(display_rbusy),.O_disp_valid(display_rvalid),.O_disp_data(display_rdata),.O_disp_enable(display_enable),
 .O_cap_busy(raw_busy),.O_cap_valid(fdma_wvalid),.O_cap_enable(capture_enable),
 .O_cap_awvalid(awvalid),.O_cap_awready(awready),.O_cap_bvalid(bvalid),.O_cap_bready(bready),.O_cap_bresp(bresp),
 .I_cap_flags(flags | {20'b0,resize_reason,10'b0}),.I_cap_csi(csi_gray),.I_cap_isp(isp_gray),.I_cap_aw(aw_count),.I_cap_b(b_count),
 .I_cap_rx(rx_gray),.I_cap_valid(valid_gray));
endmodule
