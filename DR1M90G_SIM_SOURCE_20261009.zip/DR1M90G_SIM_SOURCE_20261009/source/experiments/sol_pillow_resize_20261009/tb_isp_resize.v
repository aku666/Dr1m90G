`timescale 1ns/1ps
module tb_isp_resize;
 reg rx_clk=0,ui_clk=0,resetn=0,enable=0;
 reg valid=0,user=0,last=0;reg [127:0] bgrx=0;
 wire pv,pu,pl,fault;wire [1:0] reason;wire [23:0] rgb;
 wire ov,ou,ol;wire [23:0] result;
 reg [23:0] input_pixels[0:2073599],expected[0:50175];
 integer row,b,lane,idx,count=0,serial_count=0,case_id=0;
 reg [255:0] filename;
 always #5 rx_clk=~rx_clk;
 always #6.25 ui_clk=~ui_clk;
 isp_pixel_serial serializer(rx_clk,ui_clk,resetn,enable,
  valid,user,last,bgrx,pv,pu,pl,rgb,fault,reason);
 pillow_aa_224 resize(ui_clk,resetn,pv,pu,rgb,ov,ou,ol,result);
 always @(posedge ui_clk)begin
  if(resetn && fault)$fatal(1,"UNEXPECTED_STREAM_FAULT %b",reason);
  if(pv)begin
   if(rgb!==input_pixels[serial_count])$fatal(1,"SOURCE_ORDER_COLOR %0d",serial_count);
   if(pu!==(serial_count==0) || pl!==(serial_count%1920==1919))$fatal(1,"SOURCE_MARKER %0d",serial_count);
   serial_count=serial_count+1;
  end
 end
 always @(negedge ui_clk)if(ov)begin
  if(count>=50176 || result!==expected[count])$fatal(1,"RESIZE_DIFF case=%0d idx=%0d",case_id,count);
  if(ou!==(count==0) || ol!==(count%224==223))$fatal(1,"OUTPUT_MARKER %0d",count);
  count=count+1;
 end
 initial begin
  repeat(10)@(negedge rx_clk);resetn=1;
  for(case_id=0;case_id<2;case_id=case_id+1)begin
   $sformat(filename,"input%0d.hex",case_id);$readmemh(filename,input_pixels);
   $sformat(filename,"expected%0d.hex",case_id);$readmemh(filename,expected);
   count=0;serial_count=0;enable=1;
   repeat(10)@(negedge rx_clk);
   // Four-pixel bursts: 4.8us data + 27.2us blank per line. Two genuinely
   // different clocks, 28.94 simulated full frames/s offered, no frame buffer.
   for(row=0;row<1080;row=row+1)begin
    for(b=0;b<480;b=b+1)begin
     @(negedge rx_clk);valid=1;user=(row==0 && b==0);last=(b==479);
     for(lane=0;lane<4;lane=lane+1)begin
      idx=row*1920+b*4+lane;
      bgrx[lane*32 +:32]={8'hff,input_pixels[idx][7:0],input_pixels[idx][15:8],input_pixels[idx][23:16]};
     end
    end
    @(negedge rx_clk);valid=0;user=0;last=0;
    repeat(2719)@(negedge rx_clk);
   end
   repeat(50)@(negedge rx_clk);
   if(serial_count!=2073600 || count!=50176)$fatal(1,"INCOMPLETE_FRAME %0d %0d",serial_count,count);
   $display("ISP_CDC_REAL_FRAME_EXACT case=%0d source=%0d output=%0d",case_id,serial_count,count);
   enable=0;repeat(50)@(negedge rx_clk);
  end
  $display("ISP_CDC_TWO_FRAMES_PIXEL_EXACT_SIM_ONLY");$finish;
 end
 initial begin #80000000;$fatal(1,"WATCHDOG");end
endmodule
