"""Actual saved sensor -> AA224 bytes -> original normalized CHW comparison."""
from pathlib import Path
from time import perf_counter
import importlib.util,json,tarfile
import numpy as np
from PIL import Image
from small_frame import normalized_small_bgrx

s=Path(__file__).resolve().parent
with tarfile.open(s.parent/'sol_headless_20261007/runtime.tgz') as a:
    code=a.extractfile('camera/model_pipeline/src/sign_model/preprocess.py').read()
original={};exec(compile(code,'qualified_preprocess.py','exec'),original)
references=json.loads((s/'reference.json').read_text())
results=[]
for i in range(3):
    small=np.asarray(Image.open(s/f'resized{i}.png').convert('RGB'))
    packed=np.zeros((224,224,4),np.uint8)
    packed[:,:,:3]=small[:,:,::-1]
    raw=packed.tobytes()
    start=perf_counter();tensor=normalized_small_bgrx(raw)
    elapsed=(perf_counter()-start)*1000
    full=Image.open(references['cases'][i]['source']).convert('RGB')
    reference=original['normalized_rgb_chw'](full,[224,224],[.485,.456,.406],[.229,.224,.225])
    differing=int(np.count_nonzero(tensor!=reference))
    assert differing==0 and tensor.flags.c_contiguous
    # Mutating the source cannot change the published privately owned tensor.
    saved=tensor.copy();packed[:]=0;assert np.array_equal(tensor,saved)
    results.append(dict(case=i,differing=differing,elements=tensor.size,copied_bytes=len(raw),
                        pc_normalization_ms=elapsed,scope='PC_FULL_HD_ORIGINAL_PREPROCESS_NOT_BOARD_OR_END_TO_END'))
(s/'small_tensor.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
