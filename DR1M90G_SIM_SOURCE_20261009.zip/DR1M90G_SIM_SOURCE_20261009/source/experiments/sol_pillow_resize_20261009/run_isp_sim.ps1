$ErrorActionPreference='Stop'
$taskTools='F:/BaiduNetdiskDownload/01_fdma_vdma_20251010/Aku666/fdma_imx415_20251008/tools/msys64/ucrt64/bin'
$env:PATH="$taskTools;$env:PATH"
Push-Location $PSScriptRoot
try {
 & "$taskTools/iverilog.exe" -g2012 -s tb_isp_resize -o isp_resize.vvp tb_isp_resize.v isp_pixel_serial.v pillow_aa_224.v ../sol_block34_dw_split_20261008/uisrc/03_ip/uifdmadbuf/sfifo.v
 if($LASTEXITCODE -ne 0){throw 'ISP resize compile failed'}
 & "$taskTools/vvp.exe" isp_resize.vvp | Tee-Object isp_sim1.log
 if($LASTEXITCODE -ne 0){throw 'ISP resize simulation failed'}
} finally {Pop-Location}
