from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
report=json.loads((s/'reference.json').read_text(encoding='utf-8'))
log=(s/'sim1.log').read_text()
passes=re.findall(r'RTL_PASS case=(\d+) pixels=(\d+) cycles=(\d+)',log)
assert len(passes)==3 and all(int(p)==50176 for _,p,_ in passes)
assert 'THREE_DISTINCT_REAL_FRAMES_PIXEL_EXACT_NO_DDR_NO_BOARD' in log
build=(s/'build_core1.log').read_text()
assert 'PILLOW_EXACT_CORE_GATE_COMPLETE_NO_BIT_NO_BOARD' in build
area=(s/'pillow_aa_224_gate.area').read_text()
resource={k:int(re.search(r'^'+re.escape(tag)+r'\s+(\d+)',area,re.M)[1])
          for k,tag in [('slices','#slice*'),('eram','#eram'),('dsp','#dsp')]}
report.update(coded='PASS',sim='PASS_THREE_REAL_FRAMES_AND_STREAM_MARKERS',synth='GATE_PASS',
              simulation=passes,standalone_resource=resource,
              pnr='NOT_RUN',bit='NOT_BUILT',board='NOT_RUN',
              integration='PENDING_128_TO_32_ELASTIC_CDC_PLUS_SMALL_FDMA_AND_MATCHED_CAPTURE_ABI',
              actual_camera_rate='NOT_VERIFIED_BY_THIS_SIMULATION',
              warnings=['ROM driver warnings; HDL log explicitly reads both coefficient hex files',
                        'standalone IO unassigned, expected; no physical timing/combined fit claim'],
              quality_scope='PIXEL_MATCH_TO_PC_PILLOW_12_3_ONLY; TASK_QUALITY_NOT_NEWLY_VALIDATED',
              performance_scope='SIM_INPUT_RATE_ONLY; NO_BOARD_END_TO_END_SPEED_CLAIM')
(s/'qualification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(sim='PASS',synth='PASS',resource=resource,board='NOT_RUN')))
