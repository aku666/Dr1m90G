$ErrorActionPreference='Stop'
$taskTools='F:/BaiduNetdiskDownload/01_fdma_vdma_20251010/Aku666/fdma_imx415_20251008/tools/msys64/ucrt64/bin'
$env:PATH="$taskTools;$env:PATH"
Push-Location $PSScriptRoot
try {
 & 'F:/My_proj/_isolated_builds/softnpu_spatial_quant_20260919_1/.venv/Scripts/python.exe' prepare_uidbuf_sim.py
 if($LASTEXITCODE -ne 0){throw 'UIDBUF simulation copy failed'}
 & "$taskTools/iverilog.exe" -g2012 -s tb_small_fdma -o small_fdma.vvp tb_small_fdma.v ../sol_block34_dw_split_20261008/uisrc/03_ip/uifdmadbuf/sfifo.v uidbuf_sim.v
 if($LASTEXITCODE -ne 0){throw 'Small FDMA compile failed'}
 & "$taskTools/vvp.exe" small_fdma.vvp | Tee-Object small_fdma3.log
 if($LASTEXITCODE -ne 0){throw 'Small FDMA simulation failed'}
} finally {Pop-Location}
