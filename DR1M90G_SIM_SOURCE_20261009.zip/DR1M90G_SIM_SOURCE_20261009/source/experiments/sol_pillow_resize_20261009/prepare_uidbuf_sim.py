"""Declaration order only, for Icarus; never used by the FPGA project."""
from pathlib import Path
import re
s=Path(__file__).resolve().parent
p=(s.parent/'sol_block34_dw_split_20261008/uisrc/03_ip/uifdmadbuf/uidbuf.v').read_bytes()
assert p.count(b'reg           wfifo_rst_done,wfifo_rst_done_r1')==1
p=p.replace(b'reg           wfifo_rst_done,wfifo_rst_done_r1',b'reg           wfifo_rst_done_r1')
names=['O_fdma_wareq_r','O_fdma_wbufn','W_MS','wirq_dly_cnt','W_REQ']
moved=[]
for name in names:
    matches=list(re.finditer(rb'^reg[^\r\n]*\b'+name.encode()+rb'\s*(?:=|;)[^\r\n]*',p,re.M))
    assert len(matches)==1,(name,len(matches))
    m=matches[0];moved.append(m.group());p=p[:m.start()]+p[m.end():]
anchor=b'reg                               wfifo_rst_lock;'
assert p.count(anchor)==1
p=p.replace(anchor,anchor+b'\n'+b'\n'.join(moved))
(s/'uidbuf_sim.v').write_bytes(p)
print('Simulation-only declaration cleanup; production RTL unchanged')
