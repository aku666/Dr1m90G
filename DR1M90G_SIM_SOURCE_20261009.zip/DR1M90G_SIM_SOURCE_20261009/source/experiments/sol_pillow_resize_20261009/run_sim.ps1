$ErrorActionPreference='Stop'
$taskTools='F:/BaiduNetdiskDownload/01_fdma_vdma_20251010/Aku666/fdma_imx415_20251008/tools/msys64/ucrt64/bin'
$env:PATH="$taskTools;$env:PATH"
Push-Location $PSScriptRoot
try {
 & "$taskTools/iverilog.exe" -g2012 -s tb_resize -o resize.vvp tb_resize.v pillow_aa_224.v
 if($LASTEXITCODE -ne 0){throw 'Resize compile failed'}
 & "$taskTools/vvp.exe" resize.vvp | Tee-Object sim.log
 if($LASTEXITCODE -ne 0){throw 'Resize simulation failed'}
} finally {Pop-Location}
