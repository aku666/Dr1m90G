"""Fixed Pillow-compatible bilinear AA coefficients and real sensor-frame vectors.

Arithmetic source: Pillow 11.3.0 src/libImaging/Resample.c, precompute_coeffs,
normalize_coeffs_8bpc, horizontal/vertical UINT8 passes. No images are resized
to fake camera inputs. Both passes round to UINT8 independently with Q22.
"""
from pathlib import Path
import hashlib,json
from time import perf_counter
import numpy as np
from PIL import Image,__version__ as pillow_version

stage=Path(__file__).resolve().parent
root=stage.parents[1]
Q=22


def axis_coefficients(size, output=224):
    scale=size/output
    support=max(1.,scale)
    result=[]
    for dst in range(output):
        center=(dst+.5)*scale
        first=max(0,int(center-support+.5))
        end=min(size,int(center+support+.5))
        weights=[max(0.,1.-abs((x-center+.5)/support)) for x in range(first,end)]
        total=sum(weights)
        coefficients=np.array([int(.5+w/total*(1<<Q)) for w in weights],np.int64)
        result.append((first,coefficients))
    return result


def stream_rom(size):
    coeffs=axis_coefficients(size)
    records=[[0,0,False,False,False,False,0] for _ in range(size)]
    occupied=[[False,False] for _ in range(size)]
    for dst,(first,weights) in enumerate(coeffs):
        nonzero=np.flatnonzero(weights)
        for index in nonzero:
            x=first+int(index);slot=dst%2
            assert not occupied[x][slot],('overlapping destinations alias',x,dst)
            occupied[x][slot]=True
            records[x][slot]=int(weights[index])
            records[x][2+slot]=index==nonzero[0]
            records[x][4+slot]=index==nonzero[-1]
            if index==nonzero[-1]:
                assert not records[x][4+1-slot],('two completed outputs per input',x)
                records[x][6]=dst
    packed=[]
    for a,b,f0,f1,l0,l1,dst in records:
        assert 0<=a<1<<Q and 0<=b<1<<Q
        packed.append(a|(b<<22)|(int(f0)<<44)|(int(f1)<<45)|
                      (int(l0)<<46)|(int(l1)<<47)|(dst<<48))
    return coeffs,packed


def integer_resize(rgb,hcoeff,vcoeff):
    horizontal=np.empty((1080,224,3),np.uint8)
    for dst,(first,weights) in enumerate(hcoeff):
        acc=(rgb[:,first:first+len(weights)].astype(np.int64)*weights[None,:,None]).sum(axis=1)+(1<<(Q-1))
        horizontal[:,dst]=np.clip(acc>>Q,0,255).astype(np.uint8)
    result=np.empty((224,224,3),np.uint8)
    for dst,(first,weights) in enumerate(vcoeff):
        acc=(horizontal[first:first+len(weights)].astype(np.int64)*weights[:,None,None]).sum(axis=0)+(1<<(Q-1))
        result[dst]=np.clip(acc>>Q,0,255).astype(np.uint8)
    return result


def save_hex(path,rgb):
    value=rgb[:,:,0].astype(np.uint32)|(rgb[:,:,1].astype(np.uint32)<<8)|(rgb[:,:,2].astype(np.uint32)<<16)
    path.write_text(''.join(f'{x:06x}\n' for x in value.flat),encoding='ascii')


if __name__=='__main__':
    h,hrom=stream_rom(1920);v,vrom=stream_rom(1080)
    for name,values in (('h_coeff.hex',hrom),('v_coeff.hex',vrom)):
        (stage/name).write_text(''.join(f'{x:014x}\n' for x in values),encoding='ascii')
    sources=[root/'experiments/sol_dsi_camera_pw32_20261006/board/real1'/p for p in (
        'camera_frame1/first_frame.png','camera_clip16/first_frame.png','camera_clip16/latest_frame.png')]
    cases=[];identities=set()
    for index,p in enumerate(sources):
        digest=hashlib.sha256(p.read_bytes()).hexdigest()
        assert digest not in identities;identities.add(digest)
        with Image.open(p) as original:
            assert original.size==(1920,1080),original.size
            rgb=np.array(original.convert('RGB'))
            expected=np.array(original.convert('RGB').resize((224,224),Image.Resampling.BILINEAR))
        start=perf_counter();actual=integer_resize(rgb,h,v);elapsed=(perf_counter()-start)*1000
        different=int(np.count_nonzero(actual!=expected))
        assert different==0,(p,different,int(np.abs(actual.astype(int)-expected).astype(int).max()))
        save_hex(stage/f'input{index}.hex',rgb);save_hex(stage/f'expected{index}.hex',expected)
        Image.fromarray(actual).save(stage/f'resized{index}.png')
        cases.append(dict(source=str(p),sha256=digest,pixels_differing=different,
                          cpu_reference_ms=elapsed,scope='REAL_SAVED_1080P_NOT_LIVE'))
    report=dict(scope='FIXED_Q22_BILINEAR_AA_TWO_UINT8_PASSES',pillow_version=pillow_version,
                source='https://github.com/python-pillow/Pillow/blob/11.3.0/src/libImaging/Resample.c',
                cases=cases,source_size=[1920,1080],output_size=[224,224],
                maximum_h_taps=max(len(x[1]) for x in h),maximum_v_taps=max(len(x[1]) for x in v),
                h_rom_bits=1920*56,v_rom_bits=1080*56,vertical_accumulator_bits=2*224*3*32,
                pixel_rate_lower_bound_ms_at_80mhz=1920*1080/80e3,
                throughput='NOT_MEASURED_SIM_AND_BOARD_PENDING',default_changed=False)
    (stage/'reference.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False),flush=True)
