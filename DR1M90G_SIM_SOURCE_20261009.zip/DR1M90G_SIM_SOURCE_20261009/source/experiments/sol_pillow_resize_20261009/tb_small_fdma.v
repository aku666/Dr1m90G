`timescale 1ns/1ps
module tb_small_fdma;
 reg clk=0,rst=0,pv=0,pu=0,pl=0,busy=0,rd=0;
 reg [31:0] pixel=0;
 wire req,ready,done;wire [31:0] addr;wire [15:0] size;
 wire [63:0] data;wire [7:0] slot,done_slot;
 reg [23:0] expected[0:50175];
 integer idx,transferred=0,bursts=0,left=0;
 reg [63:0] expected_word;
 always #6.25 clk=~clk;
 uidbuf #(.AXI_DATA_WIDTH(64),.AXI_ADDR_WIDTH(32),.W_BUFDEPTH(2048),
 .W_DATAWIDTH(32),.W_BASEADDR(32'h0a000000),.W_DSIZEBITS(23),
 .W_XSIZE(224),.W_XSTRIDE(224),.W_YSIZE(224),.W_XDIV(2),.W_BUFSIZE(3),
 .R_BUFDEPTH(16),.R_XSIZE(16),.R_XSTRIDE(16),.R_YSIZE(1)) dut(
 .I_ui_clk(clk),.I_ui_rstn(rst),.I_W_en(1'b1),.I_W_sync(pu),
 .I_W_wclk(clk),.I_W_rstn(rst),.I_W_tuser(pu),.I_W_tvalid(pv),
 .I_W_tdata(pixel),.I_W_tlast(pl),.O_W_tready(),.O_W_sync_cnt(slot),.I_W_buf(slot),
 .O_fdma_waddr(addr),.O_fdma_wareq(req),.O_fdma_wsize(size),
 .I_fdma_wbusy(busy),.O_fdma_wdata(data),.I_fdma_wvalid(rd),
 .O_fdma_wready(ready),.O_fdma_wbuf(done_slot),.O_fdma_wirq(done),
 .I_R_en(1'b0),.I_R_sync(1'b0),.I_R_rclk(clk),.I_R_rstn(rst),.I_R_tready(1'b0),
 .I_R_buf(8'b0),.I_fdma_rbusy(1'b0),.I_fdma_rdata(64'b0),.I_fdma_rvalid(1'b0));
 always @(posedge clk)if(rst)begin
  if(!busy && req)begin
   if(size!=56 || addr!==32'h0a800000+bursts*448)$fatal(1,"SMALL_ADDR_SIZE %h %0d %0d",addr,size,bursts);
   busy<=1;rd<=1;left=56;bursts=bursts+1;
  end else if(busy && rd)begin
   expected_word={8'b0,expected[transferred+1][7:0],expected[transferred+1][15:8],expected[transferred+1][23:16],
                 8'b0,expected[transferred][7:0],expected[transferred][15:8],expected[transferred][23:16]};
   if(!ready || data!==expected_word)$fatal(1,"SMALL_FDMA_PIXEL %0d actual=%h expected=%h",transferred,data,expected_word);
   transferred=transferred+2;left=left-1;
   if(left==0)begin busy<=0;rd<=0;end
  end
 end
 initial begin
  $readmemh("expected0.hex",expected);
  repeat(10)@(negedge clk);rst=1;repeat(10)@(negedge clk);
  for(idx=0;idx<50176;idx=idx+1)begin
   @(negedge clk);pv=1;pu=idx==0;pl=idx%224==223;
   pixel={8'b0,expected[idx][7:0],expected[idx][15:8],expected[idx][23:16]};
   // Conservative sparse result stream; actual resize emits at most one
   // pixel/clock. This bench verifies the changed uidbuf geometry/packing.
   @(negedge clk);pv=0;pu=0;pl=0;
  end
  wait(done);@(negedge clk);
  if(transferred!=50176 || bursts!=448 || done_slot!=1)$fatal(1,"SMALL_FDMA_INCOMPLETE");
  $display("SMALL_UIDBUF_REAL_PIXELS_PASS pixels=%0d bursts=%0d bytes=200704 slot=%0d",transferred,bursts,done_slot);
  $display("EXISTING_UIDBUF_NEW_GEOMETRY_SIM_ONLY_NOT_DDR_BOARD");$finish;
 end
 initial begin #3000000;$fatal(1,"SMALL_FDMA_WATCHDOG pixels=%0d bursts=%0d",transferred,bursts);end
endmodule
