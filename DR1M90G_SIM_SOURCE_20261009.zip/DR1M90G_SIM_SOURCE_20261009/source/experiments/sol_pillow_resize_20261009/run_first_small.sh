#!/bin/sh
# Run only after AA224 bit/timing and normal preserved-DTB/clock setup.
# No bit download, reset, NPU loading, START, or buffer release in this entry.
set -eu
test "$#" -eq 2 || { echo 'usage: run_first_small.sh runtime.tgz /run/new_result_dir'; exit 2; }
archive=$1
result=$2
test ! -e "$result" || { echo 'Choose a new result directory'; exit 2; }
mkdir -p "$result/runtime"
tar -xzf "$archive" -C "$result/runtime"
export PYTHONPATH="$result/runtime${PYTHONPATH:+:$PYTHONPATH}"
export RESIDENT_GP_LOCK="$result/gp_write.lock"
export RESIDENT_CAPTURE_TRACE=1
python3 -c 'import os; from gp_write_gate import GpWriteGate; GpWriteGate(os.environ["RESIDENT_GP_LOCK"],create=True).close()'
python3 "$result/runtime/capture_callback.py" --output "$result/capture" \
 --pixel-bytes BGRX --roi 0 0 224 224 --frame-count 1 --status-offset 0x100 \
 --timeout-seconds 8 --freeze-copy
# Complete small PNG + original normalized tensor remain for pixel/input
# comparison; actual completed frame/B responses verified by capture entry.
