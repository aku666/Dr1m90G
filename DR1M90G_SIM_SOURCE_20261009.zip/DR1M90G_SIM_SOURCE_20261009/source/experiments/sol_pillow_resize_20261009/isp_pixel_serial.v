// Reuse uidbuf's asynchronous width-converting FIFO. One request accepts one
// complete 1920x1080 BGRX frame. Request must go low before the next frame.
// Camera has no backpressure: full/malformed input is a latched failure,
// never an apparently complete image. Only reset releases a failed stream.
module isp_pixel_serial #(parameter FIFO_LOG2=11)(
 input wire rx_clk,ui_clk,resetn,enable,
 input wire in_valid,in_user,in_last,input wire [127:0] in_bgrx,
 output wire out_valid,out_user,out_last,output wire [23:0] out_rgb,
 output wire fault,output wire [1:0] fault_reason
);
 reg enable1,enable2,active,armed;
 reg [19:0] beat;
 reg [8:0] column;
 reg [1:0] error_rx,error1,error2;
 wire start=in_valid && in_user && enable2 && armed && !active;
 wire accept=in_valid && (active || start) && error_rx==0;
 wire expected_last=start ? 1'b0 : column==479;
 wire malformed=accept && ((in_last!=expected_last) || (active && in_user));
 wire fifo_full,fifo_empty,fifo_valid;
 wire [25:0] fifo_pixel;
 wire [103:0] fifo_beat;
 genvar lane;
 generate for(lane=0;lane<4;lane=lane+1) begin: pack
  // BGRX byte order is the existing FDMA layout; core uses R,G,B low first.
  assign fifo_beat[lane*26 +:26]={in_last && lane==3,
    start && lane==0,in_bgrx[lane*32 +:8],
    in_bgrx[lane*32+8 +:8],in_bgrx[lane*32+16 +:8]};
 end endgenerate
 always @(posedge rx_clk or negedge resetn) begin
  if(!resetn)begin
   enable1<=0;enable2<=0;active<=0;armed<=1;beat<=0;column<=0;error_rx<=0;
  end else begin
   enable1<=enable;enable2<=enable1;
   if(!enable2 && !active)armed<=1;
   if(accept)begin
    if(fifo_full)error_rx[0]<=1;
    if(malformed)error_rx[1]<=1;
    if(start)begin active<=1;armed<=0;beat<=1;column<=1;end
    else begin
     beat<=beat+1'b1;column<=column==479 ? 0 : column+1'b1;
     if(beat==518399)active<=0;
    end
   end
  end
 end
 always @(posedge ui_clk or negedge resetn)begin
  if(!resetn)begin error1<=0;error2<=0;end
  else begin error1<=error_rx;error2<=error1;end
 end
 assign fault_reason=error2;
 assign fault=|error2;
 sfifo #(.DATA_WIDTH_W(104),.DATA_WIDTH_R(26),
  .ADDR_WIDTH_W(FIFO_LOG2),.ADDR_WIDTH_R(FIFO_LOG2+2),
  .AL_FULL_NUM((1<<FIFO_LOG2)-2),.AL_EMPTY_NUM(2),
  .SHOW_AHEAD_EN(1'b1),.OUTREG_EN("NOREG")) pixels(
  .rst(!resetn),.clkw(rx_clk),.clkr(ui_clk),
  .we(accept && !malformed && !fifo_full),.di(fifo_beat),
  .re(!fifo_empty && !fault),.dout(fifo_pixel),.valid(fifo_valid),
  .full_flag(fifo_full),.empty_flag(fifo_empty),
  .afull(),.aempty(),.wrusedw(),.rdusedw());
 assign out_valid=fifo_valid && !fault;
 assign out_user=fifo_pixel[24];
 assign out_last=fifo_pixel[25];
 assign out_rgb=fifo_pixel[23:0];
endmodule
