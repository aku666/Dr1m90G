"""Target CPU arithmetic reference for the exact batch16/NEON9 production graph. No devices."""
import json,sys,zlib
from pathlib import Path
from time import perf_counter
import numpy as np
root=Path('/run/space16_cached1')
sys.path.insert(0,str(root/'runtime'))
from hard_soft_spatial import HardSoftSpatial,fixed_h5_reference
from soft_residual import fixed_h6_reference
from expansion16_reference import Expansion16Reference
from dw16_reference import Depthwise16Reference
from depthwise_prefix import DepthwiseLayerReference
from pointwise96_reference import Pointwise96Reference
from fixed_cpu_sessions import FixedCpuSessions
from spatial_batch16 import Fixed16BatchPrefix
from block34_cpu_reference import HardBlock34Reference
from v4r_batched_temporal import BatchedV4RTemporalSequence
out=root/'target_cpu_reference1';out.mkdir(exist_ok=False)
if Path('/proc/modules').read_text().strip():raise RuntimeError('CPU comparison requires modules empty')
package=Path('/run/camera_main_assets/sol_cpu_batch16_main_2');neon=Path('/run/sol_float_dw9_graph1')
class FrontReference:
    backend='CPU_FIXED_FRONT96_REFERENCE'
    def __init__(self):
        self.pw=Pointwise96Reference(package/'pw96_assets');self.dw=DepthwiseLayerReference('/root/dw96_net_20260930_1/front_assets');self.last_run=None
    def __call__(self,x):
        y=self.dw(self.pw(x));self.last_run=dict(device_starts=0);return y
class BlockReference:
    backend='CPU_HARD_SCALAR_BLOCK34_CANDIDATE';output_shape=(1,32,28,28)
    def __init__(self):self.ref=HardBlock34Reference(root/'reference_assets');self.last_run=None
    def __call__(self,x):
        y=self.ref(x);self.last_run=dict(device_starts=0,input_crc=zlib.crc32(x.tobytes()),output_crc=zlib.crc32(y.tobytes()));return y
assets=Path('/root/hard_soft_live_product_20260929_1/assets');dw=Path('/root/dw16_usb_main_20260930_1/assets');exp=Path('/root/h4_h5_usb_20260930_1/assets')
lib=neon/'libdepthwise_ort.so';start=perf_counter()
chain=HardSoftSpatial(assets,lambda x:(fixed_h5_reference(x,assets),'CPU_FIXED_H5'),lambda x,y:(fixed_h6_reference(x,y),'CPU_FIXED_ADD'),dw,Depthwise16Reference(dw),exp,Expansion16Reference(exp),front_dw_assets='/root/dw96_net_20260930_1/front_assets',front_dw_executor=FrontReference(),front_block_assets=package/'block3_assets',front_block_executor=BlockReference(),front_pw96_assets=package/'pw96_assets',front_block4_assets=package/'block4_assets',batch16_models=neon/'models',cpu_depthwise_library=lib,cpu_sessions=FixedCpuSessions(lib))
# Use the same fused tensor interface and fixed16 CPU batches with arithmetic-only executors.
chain.prefix.fused=True
chain.prefix=Fixed16BatchPrefix(chain.prefix,neon/'models')
frames=np.load(root/'normalized_frames.npy',allow_pickle=False);chain.prefix.prepare(frames,[0])
features=np.stack([chain.run(frames[i:i+1])[0][0] for i in range(16)])[None];np.save(out/'features.npy',features,allow_pickle=False)
classes=json.loads(Path('/root/tcn_grid7_fixed_product_20260929_1/classes.json').read_text());classes=classes['classes'] if isinstance(classes,dict) else classes
temporal=BatchedV4RTemporalSequence('/root/tcn_grid7_fixed_product_20260929_1/models','/root/tcn_grid7_fixed_product_20260929_1/assets',classes,direct_cpu=True)
prediction=temporal.classify(features,np.ones((1,16),np.bool_))
actual=np.load('/run/space16_cached_result2/features.npy',allow_pickle=False)
report=dict(scope='TARGET_CPU_BATCH16_NEON9_CANDIDATE_NO_DEVICE_ACCESS',device_starts=0,prediction=prediction,elapsed_ms=(perf_counter()-start)*1000,board_feature_differing=int(np.count_nonzero(features!=actual)),board_feature_max_abs=float(np.max(np.abs(features-actual))),block_crc=[r['block34_device'] for r in chain.prefix.records])
(out/'reference.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
