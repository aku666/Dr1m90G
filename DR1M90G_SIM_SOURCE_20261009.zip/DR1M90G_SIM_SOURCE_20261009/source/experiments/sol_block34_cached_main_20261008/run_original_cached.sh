#!/bin/sh
# Explicit experimental entry after qualified temporary setup and block validation.
set -eu
results=${1:?new results directory}
frames=${2:?sixteen existing normalized frames}
root=/run/space16_cached1
package=/run/camera_main_assets/sol_cpu_batch16_main_2
neon=/run/sol_float_dw9_graph1
test ! -e "$results"
test -s "$frames"
test -s "$root/libblock34_cpu_gaps.so"
test -z "$(cat /proc/modules)"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 OMP_WAIT_POLICY=PASSIVE
export PYTHONPATH="$root/runtime:$package/runtime:/run/camera_pw32_20261006_1:/run/camera_pw32_20261006_1/deps/h10_product_runtime/python_packages:/root/network_n1_fnv_20260930:/root/product_20260929_T01_1/implementation_hardnpu/runtime:/root/hard_soft_live_product_20260929_1/float_models:/root/hard_soft_live_product_20260929_1/runtime:/root/hard_soft_serial_product_20260929_1/runtime:/root/tcn_grid7_fixed_product_20260929_1/implementation_hardnpu/runtime:/root/dr1_cpu_onnx_probe_20260914/dr1_cpu_onnx_probe/python_packages"
python3 "$root/disable_dsi.py"
insmod /run/block34_cached_board1/pl_driver/net_pl.ko allow_run=1
insmod "$root/driver/space16_fixed/space16_fixed.ko" allow_h10_start=1
python3 "$root/runtime/run_original_cached.py" \
 --assets /root/hard_soft_live_product_20260929_1/assets --frames "$frames" \
 --temporal-model /root/tcn_grid7_fixed_product_20260929_1/models \
 --temporal-backend fixed-cpu --tcn-assets /root/tcn_grid7_fixed_product_20260929_1/assets \
 --classes /root/tcn_grid7_fixed_product_20260929_1/classes.json \
 --results "$results" --execution-mode product --backend hardware --soft-backend cpu \
 --spatial-batch16-models "$neon/models" --cpu-depthwise-library "$neon/libdepthwise_ort.so" \
 --hard-block-assets "$root/combined_assets" --combined-hard-root "$root" \
 --front-pw96-assets "$package/pw96_assets" \
 --front-dw-assets /root/dw96_net_20260930_1/front_assets --front-dw-backend fused \
 --front-block-assets "$package/block3_assets" --front-block-backend pl34 \
 --front-block4-assets "$package/block4_assets" --front-block-parameters "$package/parameters" \
 --expansion-assets /root/h4_h5_usb_20260930_1/assets \
 --dw16-assets /root/dw16_usb_main_20260930_1/assets --dw16-backend pl
# On actual failure, exit above and retain modules/DMA. No automatic retry.
rmmod space16_fixed
rmmod net_pl
echo ORIGINAL_MODEL_CACHED_DMA_SAVED_REAL16_COMPLETE
