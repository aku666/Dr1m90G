/* SPDX-License-Identifier: GPL-2.0 */
#ifndef H10_RUN_UAPI_H
#define H10_RUN_UAPI_H

#include <linux/ioctl.h>
#include <linux/types.h>

#ifdef H10_FIXED_MODEL
#define H10_RUN_ABI_VERSION 0x42341610u
#else
#define H10_RUN_ABI_VERSION 0x48400000u
#endif
#define H10_RUN_OUTPUT_BYTES 451584u

enum h10_run_phase {
	H10_RUN_COLD = 0,
	H10_RUN_PREPARING = 1,
	H10_RUN_STARTED = 2,
	H10_RUN_DONE_PINNED = 3,
	H10_RUN_FAULT_PINNED = 4,
	H10_RUN_TIMEOUT_PINNED = 5
};

struct h10_run_status {
	__u32 abi_version;
	__u32 phase;
	__u32 writes_attempted;
	__u32 irq_status;
	__u32 work_status;
	__u32 output_crc32;
	__u32 integrity_fail_mask;
	__u32 failure_reason;
	__u32 reserved[4];
};

struct h10_run_output {
	__u32 abi_version;
	__u32 bytes;
	__u64 user_ptr;
};

struct h10_run_release {
	__u32 abi_version;
	__u32 expected_crc32;
};

struct h10_run_input {
	__u32 abi_version;
	__u32 bytes;
	__u64 user_ptr;
	__u64 input_fnv64;
	__u32 expected_crc32;
	__u32 reserved;
};

struct h10_run_job {
	__u32 abi_version;
	__u32 shard_index;
	__u32 packet_bytes;
	__u32 weight_bytes;
	__u32 input_bytes;
	__u32 expected_crc32;
	__u64 packet_ptr;
	__u64 weight_ptr;
	__u64 input_ptr;
	__u64 packet_fnv64;
	__u64 weight_fnv64;
	__u64 input_fnv64;
	__u64 reserved;
};

struct h10_model_load {
 __u32 abi_version, packet_bytes, weight_bytes, reserved;
 __u64 packet_ptr, weight_ptr;
};
#define H10_IOCTL_LOAD_MODEL _IOW('K', 0x28, struct h10_model_load)
#define H10_IOCTL_SET_INPUT _IOW('K', 0x25, struct h10_run_input)
struct space16_group { __u32 abi_version, first_model; };
#define SPACE16_IOCTL_SELECT_GROUP _IOW('K', 0x29, struct space16_group)

#define H10_IOCTL_RUN _IOWR('K', 0x20, struct h10_run_status)
#define H10_IOCTL_STATUS _IOR('K', 0x21, struct h10_run_status)
#define H10_IOCTL_OUTPUT _IOW('K', 0x22, struct h10_run_output)
#define H10_IOCTL_RELEASE _IOW('K', 0x23, struct h10_run_release)
#define H10_IOCTL_DIAG_OUTPUT _IOW('K', 0x24, struct h10_run_output)
#define H10_IOCTL_SET_JOB _IOW('K', 0x26, struct h10_run_job)

#endif
