"""Stop future DSI read frames on the qualified bank; keep DDR owned."""
import mmap
import os
import struct


def disable():
    fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC | os.O_CLOEXEC)
    try:
        with mmap.mmap(fd,4096,offset=0xf8411000) as gpio:
            if not struct.unpack_from('<I',gpio,0x200)[0]&1:
                raise RuntimeError('release qualified shared PL reset before bank access')
        with mmap.mmap(fd,4096,offset=0x90000000) as bank:
            ident,abi = struct.unpack_from('<2I',bank,0x100)
            if ident!=0x46535431 or abi not in (0x10003,0x10004,0x10005):
                raise RuntimeError('requires qualified capture/DSI bank')
            if struct.unpack_from('<I',bank,0x140)[0]:
                raise RuntimeError('finish capture before changing display mode')
            struct.pack_into('<I',bank,0x160,0)
            if struct.unpack_from('<I',bank,0x160)[0]:
                raise RuntimeError('DSI disable did not read back')
    finally:
        os.close(fd)
    # Enable is tested at reader IDLE. Do not reset in-flight AXI reads,
    # touch camera clocks, or release the no-map scanout reservation.
    print('DSI_FUTURE_READ_FRAMES_DISABLED; DDR_REMAINS_OWNED; NO_DRAIN_CLAIM',flush=True)


if __name__=='__main__':
    disable()
