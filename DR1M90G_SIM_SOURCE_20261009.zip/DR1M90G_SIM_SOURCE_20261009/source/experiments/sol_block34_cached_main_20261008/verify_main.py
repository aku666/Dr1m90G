"""Compare completed candidate BOARD results with the same real16 CPU reference."""
import argparse
import json
from pathlib import Path
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--actual',type=Path,required=True)
parser.add_argument('--reference',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args = parser.parse_args()
actual = json.loads((args.actual / 'clip_result.json').read_text())
reference = json.loads((args.reference / 'reference.json').read_text())
x = np.load(args.actual / 'features.npy',allow_pickle=False)
y = np.load(args.reference / 'features.npy',allow_pickle=False)
if x.shape != (1,16,128) or x.dtype != np.float32 or x.shape != y.shape:
    raise ValueError('Original real C128 temporal interface differs')
features_differing = int(np.count_nonzero(x != y))
logit_error = float(np.max(np.abs(np.asarray(actual['prediction']['logits'])-
                                 np.asarray(reference['prediction']['logits']))))
expected_counts = dict(actual_total_hard_starts=256,actual_hard_block34_starts=96,
                       actual_pl_dw144_starts=32,actual_pl_front96_starts=16,
                       actual_pl_dw16_starts=16,actual_soft_starts=0,actual_pl_v4r_starts=0)
if any(actual.get(key) != value for key,value in expected_counts.items()):
    raise ValueError('Completed original whole-model candidate execution counts differ')
passed = features_differing == 0 and logit_error == 0 and np.isfinite(x).all()
report = dict(scope='SAME_REAL16_CANDIDATE_CPU_VS_COMPLETED_BOARD_NOT_SUSTAINED_FPS_OR_QUALITY',
    numeric_pass=bool(passed),feature_shape=list(x.shape),feature_differing=features_differing,
    feature_max_abs=float(np.max(np.abs(x-y))),logits_max_abs=logit_error,
    inference_ms=actual['total_ms'],inference_equivalent_fps=16000/actual['total_ms'],
    throughput_scope='ONE_FIXED16_WINDOW_NOT_SUSTAINED',execution_counts=expected_counts,
    prediction=actual['prediction'],quality='NOT_CALIBRATED_NO_ACTION_LABEL',adopted=False)
if args.output.exists():
    raise FileExistsError('Preserve previous verification')
args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
if not passed:
    raise ArithmeticError('Candidate BOARD128D/logits differ from same-input CPU reference')
