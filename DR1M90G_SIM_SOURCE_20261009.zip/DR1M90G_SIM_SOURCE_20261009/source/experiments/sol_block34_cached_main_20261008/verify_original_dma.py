import json
from pathlib import Path
import numpy as np
r=Path('/run/original_cached_dma_result2');b=Path('/run/space16_cached1/original_reference')
a=json.loads((r/'clip_result.json').read_text());old=json.loads((b/'clip_result.json').read_text());x=np.load(r/'features.npy');y=np.load(b/'features.npy')
keys=dict(actual_total_hard_starts=160,actual_pl_block34_starts=16,actual_pl_front96_starts=16,actual_pl_dw16_starts=16,actual_soft_starts=0,actual_pl_v4r_starts=0,actual_hard_block34_starts=0,actual_pl_dw144_starts=0)
assert all(a.get(k)==v for k,v in keys.items())
error=float(np.max(np.abs(np.asarray(a['prediction']['logits'])-np.asarray(old['prediction']['logits']))))
q=dict(scope='SAME_SAVED_REAL16_ORIGINAL_MODEL_DMA_ONLY_BOARD_COMPARISON',numeric_pass=bool(np.array_equal(x,y) and error==0),feature_differing=int(np.count_nonzero(x!=y)),feature_max_abs=float(np.max(np.abs(x-y))),logits_max_abs=error,total_ms=a['total_ms'],same_input_baseline_ms=old['total_ms'],speedup_ratio=old['total_ms']/a['total_ms'],execution_counts=keys,original_model_unchanged=True,new_quantization=False,quality='NO_NEW_MODEL_CHANGE; ORIGINAL_REJECTION_NOT_CALIBRATED',throughput='ONE_FIXED16_WINDOW_NOT_SUSTAINED',default_changed=False)
(r/'verification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))
assert q['numeric_pass']
