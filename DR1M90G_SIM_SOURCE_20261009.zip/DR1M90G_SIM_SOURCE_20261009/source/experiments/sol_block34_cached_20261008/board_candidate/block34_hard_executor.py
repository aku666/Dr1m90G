"""One fixed BLOCK34 candidate: four Hard PW layers, CPU DW and residual."""
import ctypes as C
import json
import os
from pathlib import Path
from time import perf_counter
import zlib
import numpy as np
from h10_fixed_model_executor import Status, Model, Input, Output, Release, command

ABI = 0x42343300

class Block34HardExecutor:
    backend = 'HARD_PW_CPU_DW_ADD_BLOCK34_CANDIDATE'
    output_shape = (1, 32, 28, 28)

    def ioctl(self, direction, number, value):
        raw = bytearray(bytes(value))
        self.fcntl.ioctl(self.fd, command(direction, number, type(value)), raw, True)
        return type(value).from_buffer_copy(raw)

    def __init__(self, root, results, execution_mode='product', pl_dw=None):
        import fcntl
        self.fcntl = fcntl
        self.root = Path(root)
        self.results = Path(results)
        self.results.mkdir(parents=True, exist_ok=False)
        self.jobs = json.loads((self.root / 'jobs.json').read_text())['jobs']
        self.blocked, self.slot, self.count = False, 0, 0
        self.mode, self.last_run, self.fd = execution_mode, None, -1
        self.pl_dw = pl_dw
        if pl_dw is not None:
            self.backend = 'HARD_PW_PL_DW_CPU_ADD_BLOCK34_CANDIDATE'
        self.gaps = C.CDLL(str(self.root / 'libblock34_cpu_gaps.so'))
        self.gaps.block34_cpu_dw.argtypes = [C.c_void_p]*3 + [C.c_int]
        self.gaps.block34_cpu_dw.restype = C.c_int
        self.gaps.block34_cpu_add.argtypes = [C.c_void_p]*3
        self.gaps.block34_cpu_add.restype = C.c_int
        self.dw_parameters = [C.create_string_buffer((self.root / f'block{b}_dw_params.bin').read_bytes(), 4608)
                              for b in (3, 4)]
        start = perf_counter()
        packets, weights = [], []
        for job in self.jobs:
            i = job['slot']
            packet = (self.root / 'hard_assets' / f'packet_{i}.bin').read_bytes()
            weight = (self.root / 'hard_assets' / f'weight_{i}.bin').read_bytes()
            if (len(packet), len(weight)) != (job['packet_bytes'], job['weight_bytes']):
                raise ValueError('BLOCK34 fixed model length differs')
            packets.append(packet.ljust(840, b'\xa5'))
            weights.append(weight.ljust(4608, b'\xa5'))
        self.fd = os.open('/dev/block34_hard_fixed', os.O_RDWR | os.O_CLOEXEC)
        try:
            state = self.ioctl(2, 0x21, Status(abi=ABI))
            if (state.abi, state.phase, state.writes, state.irq, state.work, state.reserved[3]) != (ABI, 0, 0, 0, 0, 0):
                raise RuntimeError('BLOCK34 requires fresh fixed model instance')
            pb, wb = b''.join(packets), b''.join(weights)
            p, w = C.create_string_buffer(pb, len(pb)), C.create_string_buffer(wb, len(wb))
            self.ioctl(1, 0x28, Model(ABI, len(pb), len(wb), 0, C.addressof(p), C.addressof(w)))
        except Exception:
            self.close()
            raise
        self.asset_load_ms = (perf_counter()-start)*1000

    def pw(self, activation):
        job = self.jobs[self.slot]
        if job['key'] == 'expand' and job['input_shape'][1] == 32:
            if activation.shape != (1,24,56,56) or activation.dtype != np.uint8:
                raise ValueError('Zero padding requires the unchanged C24 UINT8 tensor')
            padded = np.full((1,32,56,56),job['input_zero_point'],np.uint8)
            padded[:,:24] = activation
            activation = padded
        if list(activation.shape) != job['input_shape'] or activation.dtype != np.uint8:
            raise ValueError('BLOCK34 tensor shape/type/order differs')
        self.blocked = True
        raw = np.ascontiguousarray(activation).tobytes()
        source = C.create_string_buffer(raw, len(raw))
        self.ioctl(1, 0x25, Input(ABI, len(raw), C.addressof(source), 0, 0, 0))
        start = perf_counter()
        state = self.ioctl(3, 0x20, Status(abi=ABI))
        record = dict(slot=self.slot, phase=state.phase, writes=state.writes, irq=state.irq,
                      work=state.work, guard=state.guard, reason=state.reason,
                      reserved=list(state.reserved), run_ms=(perf_counter()-start)*1000)
        self.last_run['jobs'].append(record)
        if (state.abi, state.phase, state.writes, state.irq, state.work, state.guard, state.reason) != (ABI, 3, 8, 1, 5, 0, 0):
            if state.writes == 8 and state.phase in (3, 4, 5):
                diagnostic = C.create_string_buffer(job['output_bytes'])
                try:
                    self.ioctl(1, 0x24, Output(ABI, job['output_bytes'], C.addressof(diagnostic)))
                    (self.results / f'failed_slot_{self.slot}.bin').write_bytes(diagnostic.raw)
                except OSError as error:
                    record['diagnostic_error'] = str(error)
            raise RuntimeError('BLOCK34 completion failed: preserve module/DMA, cold recover')
        output = C.create_string_buffer(job['output_bytes'])
        self.ioctl(1, 0x22, Output(ABI, job['output_bytes'], C.addressof(output)))
        crc = zlib.crc32(output.raw)
        if crc != state.crc:
            raise RuntimeError('BLOCK34 export CRC differs: preserve module/DMA')
        if self.mode == 'validate':
            (self.results / f'frame_{self.count:02d}_slot_{self.slot}.bin').write_bytes(output.raw)
        self.ioctl(1, 0x23, Release(ABI, crc))
        cold = self.ioctl(2, 0x21, Status(abi=ABI))
        nxt = (self.slot+1) % 6
        if (cold.abi, cold.phase, cold.writes, cold.irq, cold.work, cold.reserved[3]) != (ABI, 0, 0, 0, 0, 1 | (nxt << 8)):
            raise RuntimeError('BLOCK34 release state differs: preserve module/DMA')
        self.slot = nxt
        record['released'] = True
        self.blocked = False
        return np.frombuffer(output.raw, np.uint8).reshape(job['output_shape']).copy()

    def dw(self, activation, block):
        start = perf_counter()
        if self.pl_dw is not None:
            self.blocked = True
            output = self.pl_dw(activation, block)
            self.last_run[f'pl_dw{block}'] = self.pl_dw.last_run
            self.last_run[f'pl_dw{block}_ms'] = (perf_counter()-start)*1000
            self.blocked = False
            return output
        shape = (1, 144, 56, 56) if block == 3 else (1, 144, 28, 28)
        value, output = np.ascontiguousarray(activation), np.empty(shape, np.uint8)
        rc = self.gaps.block34_cpu_dw(value.ctypes.data, C.addressof(self.dw_parameters[block-3]),
                                       output.ctypes.data, 1 if block == 3 else 2)
        if rc:
            raise RuntimeError('BLOCK34 CPU DW failed')
        self.last_run[f'cpu_dw{block}_ms'] = (perf_counter()-start)*1000
        return output

    def __call__(self, activation):
        if self.blocked:
            raise RuntimeError('Prior BLOCK34 failure: cold recover before another run')
        if activation.shape != (1, 24, 56, 56) or activation.dtype != np.uint8 or self.slot != 0:
            raise ValueError('BLOCK34 fixed input/order differs')
        start = perf_counter()
        self.last_run = dict(frame=self.count, jobs=[], cpu_oracle_calls=0,
                             planned_hardware_pw_layers=4, hardware_pw_layers=0,
                             hardware_starts=0, planned_cpu_dw_layers=0 if self.pl_dw else 2,
                             planned_pl_dw_layers=2 if self.pl_dw else 0, planned_cpu_add_layers=1,
                             cpu_dw_layers=0, pl_dw_layers=0, cpu_add_layers=0)
        try:
            expanded = self.pw(activation)
            depthwise = self.dw(expanded, 3)
            self.last_run['pl_dw_layers' if self.pl_dw else 'cpu_dw_layers'] += 1
            projected = np.empty_like(activation)
            for begin, end in ((0, 19), (19, 38), (38, 56)):
                projected[:, :, begin:end, :] = self.pw(np.ascontiguousarray(depthwise[:, :, begin:end, :]))
            t = perf_counter()
            added = np.empty_like(activation)
            rc = self.gaps.block34_cpu_add(np.ascontiguousarray(activation).ctypes.data,
                                           projected.ctypes.data, added.ctypes.data)
            if rc:
                raise RuntimeError('BLOCK34 CPU residual failed')
            self.last_run['cpu_add_ms'] = (perf_counter()-t)*1000
            self.last_run['cpu_add_layers'] += 1
            expanded = self.pw(added)
            depthwise = self.dw(expanded, 4)
            self.last_run['pl_dw_layers' if self.pl_dw else 'cpu_dw_layers'] += 1
            output = self.pw(depthwise)
            self.count += 1
            return output
        finally:
            self.last_run['run_attempts'] = len(self.last_run['jobs'])
            self.last_run['hardware_starts'] = sum(job['writes'] == 8 for job in self.last_run['jobs'])
            completed = {job['slot'] for job in self.last_run['jobs'] if job.get('released')}
            self.last_run['hardware_pw_layers'] = sum(set(slots) <= completed for slots in ((0,), (1, 2, 3), (4,), (5,)))
            self.last_run['client_ms'] = (perf_counter()-start)*1000
            if self.mode == 'validate' or self.blocked:
                (self.results / 'last_run.json').write_text(json.dumps(self.last_run, indent=2)+'\n')

    def close(self):
        if self.pl_dw is not None:
            self.pl_dw.close()
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1
