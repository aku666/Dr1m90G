"""Fixed DW16 /dev/dw16 client; actual PL output feeds the existing H5 path."""
import ctypes as C
import os
from pathlib import Path
from time import perf_counter
import numpy as np
from dw16_reference import Depthwise16Reference


class Job(C.Structure):
    _fields_=[(n,C.c_uint32) for n in ('abi','input_bytes','parameter_bytes','output_bytes')]+\
             [(n,C.c_uint64) for n in ('input_ptr','parameter_ptr','output_ptr','elapsed_ns')]+\
             [(n,C.c_uint32) for n in ('cycles','status')]


class Depthwise16Executor:
    def __init__(self,folder,execution_mode='validate'):
        import fcntl
        self.fcntl=fcntl
        if execution_mode not in ('product','validate'):raise ValueError('invalid DW16 mode')
        self.mode=execution_mode
        self.reference=Depthwise16Reference(folder) if execution_mode=='validate' else None
        raw=(Path(folder)/'parameter_records.bin').read_bytes()
        if len(raw)!=30720:raise ValueError('DW16 needs 960 parameter records')
        self.parameter=C.create_string_buffer(raw,len(raw))
        self.fd=os.open('/dev/dw16',os.O_RDWR|os.O_CLOEXEC)
        self.blocked=False;self.last_run=None;self.last_output=None

    def __call__(self,activation):
        if self.blocked:raise RuntimeError('DW16 prior failure; preserve DMA and physically recover')
        if activation.shape!=(1,960,7,7) or activation.dtype!=np.uint8:
            raise ValueError('DW16 requires UINT8 1x960x7x7')
        inp=C.create_string_buffer(activation.tobytes(),47040);out=C.create_string_buffer(47040)
        job=Job(0x10001,47040,30720,47040,C.addressof(inp),C.addressof(self.parameter),C.addressof(out))
        data=bytearray(bytes(job));self.blocked=True;start=perf_counter()
        try:
            self.fcntl.ioctl(self.fd,(3<<30)|(C.sizeof(Job)<<16)|(ord('W')<<8)|1,data,True)
            result=Job.from_buffer_copy(data)
            if result.abi!=0x10001 or result.status!=2:
                raise RuntimeError('DW16 did not acknowledge final AXI write completion')
            actual=np.frombuffer(out.raw,np.uint8).reshape(1,960,7,7).copy()
            self.last_output=actual
            if self.reference is not None and not np.array_equal(actual,self.reference(activation)[0]):
                raise RuntimeError('DW16 output differs from independent integer reference')
            self.last_run=dict(ioctl_ms=(perf_counter()-start)*1000,device_ns=result.elapsed_ns,
                device_cycles=result.cycles,status=result.status,golden_compared=self.reference is not None)
            self.blocked=False
            return actual,'PL_DW16'
        except Exception as error:
            result=Job.from_buffer_copy(data)
            self.last_run=dict(error=str(error),status=result.status,device_cycles=result.cycles,
                ioctl_ms=(perf_counter()-start)*1000)
            raise

    def close(self):
        if self.fd>=0:os.close(self.fd);self.fd=-1
