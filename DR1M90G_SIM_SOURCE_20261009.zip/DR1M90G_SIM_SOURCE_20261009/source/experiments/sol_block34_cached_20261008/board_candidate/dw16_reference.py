"""Actual block16 depthwise fixed-point reference for the PL handoff."""
import json
from pathlib import Path
import numpy as np


def requantize(acc,multiplier,shift,zero,low=0,high=255):
    scaled = acc.astype(np.int64)*multiplier
    quotient = scaled >> shift
    remainder = scaled-quotient*(1<<shift)
    if shift:
        half = 1<<(shift-1)
        quotient += (remainder>half)|((remainder==half)&((quotient&1)!=0))
    return np.clip(quotient+zero,low,high).astype(np.uint8)


class Depthwise16Reference:
    def __init__(self,folder):
        folder = Path(folder)
        self.contract = json.loads((folder/'dw16.json').read_text())
        self.weight = np.fromfile(folder/'weight_u8.bin',np.uint8).reshape(960,3,3).astype(np.int64)
        self.weight -= self.contract['weight_zero']
        self.bias = np.fromfile(folder/'bias_i32.bin','<i4').astype(np.int64)

    def __call__(self,activation):
        if activation.shape!=(1,960,7,7) or activation.dtype!=np.uint8:
            raise ValueError('DW16 requires UINT8 1x960x7x7')
        q = self.contract
        pixels = activation.astype(np.int64)-q['input_zero']
        padded = np.pad(pixels,((0,0),(0,0),(1,1),(1,1)))
        acc = np.broadcast_to(self.bias[None,:,None,None],pixels.shape).copy()
        for y in range(3):
            for x in range(3):
                acc += padded[:,:,y:y+7,x:x+7]*self.weight[:,y,x][None,:,None,None]
        multiplier = np.asarray(q['multiplier'],np.int64)
        if multiplier.ndim:
            multiplier = multiplier.reshape(1,960,1,1)
        return requantize(acc,multiplier,q['shift'],q['output_zero']), 'CPU_FIXED_DW16'
