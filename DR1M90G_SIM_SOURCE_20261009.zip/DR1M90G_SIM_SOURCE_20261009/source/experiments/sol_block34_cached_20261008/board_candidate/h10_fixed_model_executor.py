"""Fixed model ABI: preload once, one actual input per frame, eight raw outputs.

No CPU convolution oracle in the running path. Qualification compares saved
raw bytes independently after the device has completed and released safely.
"""
import ctypes as C
import json
import os
from pathlib import Path
from time import perf_counter
import zlib
import numpy as np

ABI = 0x48400100

class Status(C.Structure):
    _fields_ = [('abi',C.c_uint32),('phase',C.c_uint32),('writes',C.c_uint32),
                ('irq',C.c_uint32),('work',C.c_uint32),('crc',C.c_uint32),
                ('guard',C.c_uint32),('reason',C.c_uint32),('reserved',C.c_uint32*4)]

class Model(C.Structure):
    _fields_=[('abi',C.c_uint32),('packet_bytes',C.c_uint32),('weight_bytes',C.c_uint32),
              ('reserved',C.c_uint32),('packet_ptr',C.c_uint64),('weight_ptr',C.c_uint64)]

class Input(C.Structure):
    _fields_=[('abi',C.c_uint32),('bytes',C.c_uint32),('ptr',C.c_uint64),
              ('fnv',C.c_uint64),('expected_crc',C.c_uint32),('reserved',C.c_uint32)]

class Output(C.Structure):
    _fields_=[('abi',C.c_uint32),('bytes',C.c_uint32),('ptr',C.c_uint64)]

class Release(C.Structure):
    _fields_=[('abi',C.c_uint32),('actual_crc',C.c_uint32)]

def command(direction, number, kind):
    return (direction<<30)|(C.sizeof(kind)<<16)|(ord('K')<<8)|number

class H10FixedModelExecutor:
    def _ioctl(self, direction, number, value):
        data=bytearray(bytes(value))
        self.fcntl.ioctl(self.fd,command(direction,number,type(value)),data,True)
        return type(value).from_buffer_copy(data)

    def __init__(self, contracts, result_root):
        import fcntl
        self.fcntl=fcntl
        self.fd=os.open('/dev/h10_fixed_model',os.O_RDWR|os.O_CLOEXEC)
        self.root=Path(result_root)
        self.calls=0
        self.halted=False
        started=perf_counter()
        try:
            status=self._ioctl(2,0x21,Status(abi=ABI))
            if status.abi!=ABI or status.phase or status.writes or status.irq or status.work or status.reserved[3]&2:
                raise RuntimeError('fixed-model ABI or cold state differs')
            if not status.reserved[3]&1:
                packets=b''.join(c['packet'] for c in contracts)
                weights=b''.join(c['weight'] for c in contracts)
                packet=C.create_string_buffer(packets,len(packets))
                weight=C.create_string_buffer(weights,len(weights))
                self._ioctl(1,0x28,Model(ABI,len(packets),len(weights),0,C.addressof(packet),C.addressof(weight)))
            self.model_load_ms=(perf_counter()-started)*1000
        except Exception:
            os.close(self.fd)
            self.fd=-1
            raise
        self.last_timing=None

    def __call__(self,row,activation,unused):
        if self.halted:
            raise RuntimeError('previous device job failed; collect evidence and recover before further submission')
        if row['ordinary_index']!=34 or row['node']!='/backbone/backbone.18/backbone.18.0/Conv' or \
                activation.shape!=(1,320,7,7) or activation.dtype!=np.uint8:
            raise ValueError('fixed H10 shape/node differs')
        folder=self.root/f'image_{self.calls:04d}'
        folder.mkdir(parents=True,exist_ok=False)
        self.calls+=1
        log=[]
        runs=[]
        outputs=[]
        started=perf_counter()
        try:
            raw=activation.tobytes()
            input_buffer=C.create_string_buffer(raw,len(raw))
            self._ioctl(1,0x25,Input(ABI,len(raw),C.addressof(input_buffer),0,0,0))
            for shard in range(8):
                begin=perf_counter()
                status=self._ioctl(3,0x20,Status(abi=ABI))
                runs.append((perf_counter()-begin)*1000)
                log.append(dict(shard=shard,phase=status.phase,writes=status.writes,
                                irq=status.irq,work=status.work,crc=status.crc,
                                guard=status.guard,reason=status.reason,run_ms=runs[-1]))
                if (status.abi,status.phase,status.writes,status.irq,status.work,status.guard,status.reason)!=(ABI,3,8,1,5,0,0):
                    raise RuntimeError('H10 fixed-model completion failed; preserve module/DMA')
                output_buffer=C.create_string_buffer(7840)
                self._ioctl(1,0x22,Output(ABI,7840,C.addressof(output_buffer)))
                output=output_buffer.raw
                crc=zlib.crc32(output)
                if crc!=status.crc:
                    raise RuntimeError('raw output CRC differs; preserve module/DMA')
                outputs.append(output)
                self._ioctl(1,0x23,Release(ABI,crc))
                cold=self._ioctl(2,0x21,Status(abi=ABI))
                if (cold.abi,cold.phase,cold.writes,cold.irq,cold.work)!=(ABI,0,0,0,0):
                    raise RuntimeError('H10 release did not return cold')
                log[-1]['released']=True
                if (cold.reserved[3]>>8)!=(shard+1)%8 or bool(cold.reserved[3]&2)!=(shard<7):
                    raise RuntimeError('fixed frame shard state differs')
        except Exception:
            self.halted=True
            raise
        finally:
            (folder/'client.json').write_text(json.dumps(log,indent=2)+'\n')
            if 'raw' in locals(): (folder/'input.bin').write_bytes(raw)
            for shard,output in enumerate(outputs): (folder/f'output_s{shard}.bin').write_bytes(output)
        self.last_timing=dict(oracle_ms=0,stage_ms=0,client_ms=(perf_counter()-started)*1000,
                             driver_run_ms=sum(runs),model_load_ms=self.model_load_ms if self.calls==1 else 0,
                             driver_run_scope='Eight RUN calls, includes driver checks and IRQ wait; model load is initialization',
                             validation='Raw output CRC and DMA identity/guards; independent numerical qualification after run')
        return np.frombuffer(b''.join(outputs),np.uint8).reshape(1,1280,7,7).copy(),'HARDNPU'

    def close(self):
        if self.fd>=0:
            os.close(self.fd)
            self.fd=-1
