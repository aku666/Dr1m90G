// SPDX-License-Identifier: GPL-2.0
/* Four fixed serial operators, one mutex; block3 additionally owns two intermediate DMA buffers. */
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/io.h>
#include <linux/dma-mapping.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/delay.h>
#include <linux/ktime.h>
#include <linux/crc32.h>
#include "cached_dma.h"
#include "net_pl_uapi.h"
#define GUARD 64u
static bool allow_run;
module_param(allow_run,bool,0400);
struct net_pl_state {
 struct device *dev;void __iomem *regs;
 struct miscdevice dw,v4r,front,block3;struct mutex lock;
 void *cpu[4][5];dma_addr_t dma[4][5];size_t size[4][5];bool pinned,front_fused,block_extended;
};
static const u32 maximum[4][5]={{47040,30720,47040},{2048,49664,49152},{1204224,3072,301056},{75264,31488,75264,451584,451584}};
static const u32 front96_length[3]={401408,18432,301056};
static const u8 fill[5]={0xc7,0xd3,0xa5,0xa5,0xa5};
static bool guards_ok(struct net_pl_state *s,const u32 *length,int slot)
{
 int i;
 for(i=0;i<(slot==3?5:3);i++)
  if(memchr_inv(s->cpu[slot][i],fill[i],GUARD) ||
     memchr_inv((u8 *)s->cpu[slot][i]+GUARD+length[i],fill[i],s->size[slot][i]-GUARD-length[i]))return false;
 return true;
}
static int net_open(struct inode *inode,struct file *file)
{
 struct miscdevice *misc=file->private_data;
 file->private_data=dev_get_drvdata(misc->parent);return 0;
}
static long net_ioctl(struct file *file,unsigned int cmd,unsigned long arg)
{
 struct net_pl_state *s=file->private_data;
 struct v4r_c128_job result={0};struct net_pl_job *job=&result.base;
 bool d1=cmd==NET_DW144_RUN,d2=cmd==NET_DW144_STRIDE2_RUN,d=d1||d2;
 bool v=cmd==NET_V4R_RUN,ff=cmd==NET_FRONT96_RUN,f=ff || cmd==NET_DW96_RUN,cc=cmd==NET_BLOCK34_RUN,c=d || cc || cmd==NET_BLOCK3_RUN;
 size_t job_size=v ? sizeof(result) : sizeof(*job);
 u32 length[5],output_length,status,other,input_crc,param_crc,offset=c ? 0x80 : f ? 0x60 : v ? 0x20 : 0;
 static const u32 offsets[4]={0,0x20,0x60,0x80};
 int input_index=d?3:0,output_index=d?4:2;
 u64 started;int i,ret=0,slot=c ? 3 : f ? 2 : v ? 1 : 0;
 if(!c && !v && !f && cmd!=NET_DW16_RUN)return -ENOTTY;
 if(!allow_run || !capable(CAP_SYS_RAWIO))return -EPERM;
 if(copy_from_user(&result,(void __user *)arg,job_size))return -EFAULT;
 for(i=0;i<5;i++)length[i]=maximum[slot][i];
 if(f && ff!=s->front_fused)return -EINVAL;
 if(c && ((d && !s->block_extended) || (!d && cc!=s->block_extended)))return -EINVAL;
 if(ff)for(i=0;i<3;i++)length[i]=front96_length[i];
 if(cc)length[1]=64256;
 if(d){length[0]=0;length[1]=4608;length[2]=0;length[3]=451584;length[4]=d2?129024:451584;}
 // Output DMA also holds the C24 intermediate until expansion4 consumes it.
 // Guard its full 75264-byte allocation; copy only the final padded image.
 output_length=d?length[4]:cc?28672:length[2];
 if(job->abi!=(d ? (d2?0x80001:0x70001) : cc ? 0x60001 : c ? 0x40001 : ff ? 0x50001 : f ? 0x30001 : v ? 0x20001 : 0x10001) || job->input_bytes!=length[input_index] ||
    job->parameter_bytes!=length[1] || job->output_bytes!=output_length ||
    !job->input_ptr || !job->parameter_ptr || !job->output_ptr ||
    (v && result.accumulator_budget>((255ULL<<23)/22891)))return -EINVAL;
 if(mutex_lock_interruptible(&s->lock))return -ERESTARTSYS;
 status=readl(s->regs+offset+8);
 if(s->pinned || (status!=0 && status!=2)){ret=-EBUSY;goto out;}
 for(i=0;i<4;i++){
  other=readl(s->regs+offsets[i]+8);
  if(other!=0 && other!=2){ret=-EBUSY;goto out;}
 }
 for(i=0;i<(c?5:3);i++)memset(s->cpu[slot][i],fill[i],s->size[slot][i]);
 if(copy_from_user((u8 *)s->cpu[slot][input_index]+GUARD,(void __user *)(unsigned long)job->input_ptr,length[input_index]) ||
    copy_from_user((u8 *)s->cpu[slot][1]+GUARD,(void __user *)(unsigned long)job->parameter_ptr,length[1])){ret=-EFAULT;goto out;}
 input_crc=crc32_le(0,(u8 *)s->cpu[slot][input_index]+GUARD,length[input_index]);
 param_crc=crc32_le(0,(u8 *)s->cpu[slot][1]+GUARD,length[1]);
 __module_get(THIS_MODULE);s->pinned=true;
 for(i=0;i<(c?5:3);i++)dma_sync_single_for_device(s->dev,s->dma[slot][i],s->size[slot][i],DMA_BIDIRECTIONAL);
 dma_wmb();
 writel(lower_32_bits(s->dma[slot][input_index]+GUARD),s->regs+offset+0x0c);
 writel(lower_32_bits(s->dma[slot][1]+GUARD),s->regs+offset+0x10);
 writel(lower_32_bits(s->dma[slot][output_index]+GUARD),s->regs+offset+0x14);
 if(c){
  writel(d2?2:d1?1:0,s->regs+0xb0);
  writel(lower_32_bits(s->dma[slot][1]+GUARD+(d?0:23040)),s->regs+0xa0);
  writel(lower_32_bits(s->dma[slot][1]+GUARD+27648),s->regs+0xa4);
  writel(lower_32_bits(s->dma[slot][3]+GUARD),s->regs+0xa8);
  writel(lower_32_bits(s->dma[slot][4]+GUARD),s->regs+0xac);
 }
 if(v){writel(lower_32_bits(result.accumulator_budget),s->regs+0x3c);writel(upper_32_bits(result.accumulator_budget),s->regs+0x40);}
 started=ktime_get_ns();writel(1,s->regs+offset+0x18);
 do {
  usleep_range(50,100);status=readl(s->regs+offset+8);
  if(!(status&1) && (status&6))break;
 }while(ktime_get_ns()-started<1000000000ULL);
 job->elapsed_ns=ktime_get_ns()-started;job->status=status;
 job->cycles=readl(s->regs+(c ? 0x9c : f ? 0x7c : v ? 0x44 : 0x1c));
 if(v){
  result.core_cycles=readl(s->regs+0x48);result.base_products=readl(s->regs+0x4c);
  result.interval_products=readl(s->regs+0x50);result.residual_products=readl(s->regs+0x54);
  result.skipped_products=readl(s->regs+0x58);result.residual_reads=readl(s->regs+0x5c);
 }
 if(status!=2){ret=(status&4)?-EIO:-ETIMEDOUT;goto failed;}
 for(i=0;i<(c?5:3);i++)dma_sync_single_for_cpu(s->dev,s->dma[slot][i],s->size[slot][i],DMA_BIDIRECTIONAL);
 dma_rmb();
 if(!guards_ok(s,length,slot) || crc32_le(0,(u8 *)s->cpu[slot][input_index]+GUARD,length[input_index])!=input_crc ||
    crc32_le(0,(u8 *)s->cpu[slot][1]+GUARD,length[1])!=param_crc){ret=-EBADMSG;goto failed;}
 if(copy_to_user((void __user *)(unsigned long)job->output_ptr,(u8 *)s->cpu[slot][output_index]+GUARD,output_length))ret=-EFAULT;
 s->pinned=false;module_put(THIS_MODULE);goto returned;
failed:
 dev_err(s->dev,"%s failure status=%x cycles=%u elapsed_ns=%llu; DMA retained, physical recovery required\n",c?"BLOCK3":ff?"FRONT96":f?"DW96":v?"V4R":"DW16",status,job->cycles,job->elapsed_ns);
returned:
 if(copy_to_user((void __user *)arg,&result,job_size) && !ret)ret=-EFAULT;
out:
 mutex_unlock(&s->lock);return ret;
}
static const struct file_operations net_fops={.owner=THIS_MODULE,.open=net_open,.unlocked_ioctl=net_ioctl};
static void free_buffers(struct net_pl_state *s)
{
 int i,slot;for(slot=0;slot<4;slot++)for(i=0;i<(slot==3?5:3);i++)if(s->cpu[slot][i])fixed_cached_free(s->dev,s->size[slot][i],s->cpu[slot][i],s->dma[slot][i]);
}
static int net_probe(struct platform_device *pdev)
{
 struct net_pl_state *s;int i,ret,slot;
 struct resource *res=platform_get_resource(pdev,IORESOURCE_MEM,0);
 if(!res || res->start!=0x90000000ULL || resource_size(res)!=0x1000)return -ENODEV;
 s=devm_kzalloc(&pdev->dev,sizeof(*s),GFP_KERNEL);if(!s)return -ENOMEM;
 pr_info("net_pl: probe begin, mapping GP window\n");
 s->dev=&pdev->dev;s->regs=devm_ioremap_resource(s->dev,res);
 if(IS_ERR(s->regs))return PTR_ERR(s->regs);
 {
  static const u32 id_off[]={0,4,0x20,0x24,0x60,0x64,0x80,0x84};
  static const u32 expected[]={0x44573136,0x10001,0x56345232,0x20001,0x44573936,0x30001,0x424c4b33,0x40001};
  for(i=0;i<8;i++){
   u32 value;
   dev_info(s->dev,"probe ID read offset=%x begin\n",id_off[i]);
   value=readl(s->regs+id_off[i]);
   dev_info(s->dev,"probe ID read offset=%x value=%x\n",id_off[i],value);
   if(i==4 && value==0x46573936){s->front_fused=true;continue;}
   if(i==6 && value==0x424c4b34){s->block_extended=true;continue;}
   if(value!=(i==5 && s->front_fused ? 0x50001 : i==7 && s->block_extended ? 0x60002 : expected[i]))return -ENODEV;
  }
 }
 for(i=0;i<4;i++){u32 off=i==3?0x80:i==2?0x60:i*0x20;u32 status=readl(s->regs+8+off);if(status!=0 && status!=2)return -EBUSY;}
 ret=dma_set_mask_and_coherent(s->dev,DMA_BIT_MASK(32));if(ret)return ret;
 for(slot=0;slot<4;slot++)for(i=0;i<(slot==3?5:3);i++){
  dev_info(s->dev,"probe DMA allocation slot=%d buffer=%d begin\n",slot,i);
  s->size[slot][i]=PAGE_ALIGN((slot==3 && i==1 && s->block_extended ? 64256 : slot==2 && s->front_fused ? front96_length[i] : maximum[slot][i])+2*GUARD);
  s->cpu[slot][i]=fixed_cached_alloc(s->dev,s->size[slot][i],&s->dma[slot][i],GFP_KERNEL);
  if(!s->cpu[slot][i]){ret=-ENOMEM;goto fail;}
  if((s->dma[slot][i]&63) || s->dma[slot][i]+s->size[slot][i]>0x100000000ULL){ret=-ERANGE;goto fail;}
  memset(s->cpu[slot][i],fill[i],s->size[slot][i]);
 }
 dev_info(s->dev,"probe DMA allocations complete\n");
 mutex_init(&s->lock);platform_set_drvdata(pdev,s);
 s->dw.minor=MISC_DYNAMIC_MINOR;s->dw.name="dw16";s->dw.fops=&net_fops;s->dw.parent=s->dev;
 s->v4r.minor=MISC_DYNAMIC_MINOR;s->v4r.name="v4r_c128";s->v4r.fops=&net_fops;s->v4r.parent=s->dev;
 s->front.minor=MISC_DYNAMIC_MINOR;s->front.name=s->front_fused?"front96":"dw96";s->front.fops=&net_fops;s->front.parent=s->dev;
 s->block3.minor=MISC_DYNAMIC_MINOR;s->block3.name=s->block_extended?"block34":"block3";s->block3.fops=&net_fops;s->block3.parent=s->dev;
 ret=misc_register(&s->dw);if(ret)goto fail;
 ret=misc_register(&s->v4r);if(ret){misc_deregister(&s->dw);goto fail;}
 ret=misc_register(&s->front);if(ret){misc_deregister(&s->v4r);misc_deregister(&s->dw);goto fail;}
 ret=misc_register(&s->block3);if(ret){misc_deregister(&s->front);misc_deregister(&s->v4r);misc_deregister(&s->dw);goto fail;}
 dev_info(s->dev,"DW16/DW96/BLOCK3/C128 V4R ready no START; input=%pad parameter=%pad output=%pad\n",&s->dma[2][0],&s->dma[2][1],&s->dma[2][2]);
 return 0;
fail:
 free_buffers(s);return ret;
}
static int net_remove(struct platform_device *pdev)
{
 struct net_pl_state *s=platform_get_drvdata(pdev);
 if(s->pinned)return -EBUSY;
 misc_deregister(&s->block3);misc_deregister(&s->front);misc_deregister(&s->v4r);misc_deregister(&s->dw);free_buffers(s);return 0;
}
static const struct of_device_id net_match[]={{.compatible="codex,net-pl-c128"},{}};
MODULE_DEVICE_TABLE(of,net_match);
static struct platform_driver net_driver={.probe=net_probe,.remove=net_remove,
 .driver={.name="net_pl_c128",.of_match_table=net_match,.suppress_bind_attrs=true}};
module_platform_driver(net_driver);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Fixed serial DW16, DW96 and real C128 V4R accelerator");
