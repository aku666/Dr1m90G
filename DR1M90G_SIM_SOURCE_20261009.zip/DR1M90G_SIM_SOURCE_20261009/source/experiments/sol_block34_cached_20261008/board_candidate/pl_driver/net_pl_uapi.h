#ifndef NET_PL_UAPI_H
#define NET_PL_UAPI_H
#include <linux/types.h>
#include <linux/ioctl.h>
struct net_pl_job {
 __u32 abi,input_bytes,parameter_bytes,output_bytes;
 __u64 input_ptr,parameter_ptr,output_ptr,elapsed_ns;
 __u32 cycles,status;
};
struct v4r_c128_job {
 struct net_pl_job base;
 __u64 accumulator_budget;
 __u32 core_cycles,base_products,interval_products,residual_products,skipped_products,residual_reads;
};
#define NET_BLOCK3_RUN _IOWR('B',1,struct net_pl_job)
#define NET_DW144_RUN _IOWR('G',1,struct net_pl_job)
#define NET_DW144_STRIDE2_RUN _IOWR('H',1,struct net_pl_job)
#define NET_BLOCK34_RUN _IOWR('C',1,struct net_pl_job)
#define NET_DW16_RUN _IOWR('W',1,struct net_pl_job)
#define NET_DW96_RUN _IOWR('D',1,struct net_pl_job)
#define NET_FRONT96_RUN _IOWR('F',1,struct net_pl_job)
#define NET_V4R_RUN _IOWR('V',1,struct v4r_c128_job)
#endif
