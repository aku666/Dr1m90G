// SPDX-License-Identifier: GPL-2.0
/* H10 eight-shard multi-frame diagnostic. START is disabled by default. */
#include <linux/capability.h>
#include <linux/completion.h>
#include <linux/crc32.h>
#include <linux/delay.h>
#include <linux/dma-mapping.h>
#include <linux/err.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/ioport.h>
#include <linux/jiffies.h>
#include <linux/ktime.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/of.h>
#include <linux/platform_device.h>
#include <linux/reset.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/uaccess.h>

#include "cached_dma.h"
#include "h10_dma_contract.h"
#include "h10_run_uapi.h"
#include "h10_multishard_config.h"

#define H10_DDRS1_BASE 0xf840f000ULL
#define H10_DDRS1_CLAIM_BYTES 0x100u
#define H10_TOP_ENABLE_OFFSET 0x1b8u
#define H10_TOP_SRAM_OFFSET 0x30u
#define H10_NPU_RESET_OFFSET 0x0000u
#define H10_WORK_STATUS_OFFSET 0x1014u
#define H10_IRQ_STATUS_OFFSET 0x1018u
#define H10_IRQ_CLEAR_OFFSET 0x101cu
#define H10_TIMEOUT_MS 10000u
#define H10_SUBMIT_WRITE_COUNT 8u
#ifndef H10_FIXED_PACKET_BYTES
#define H10_FIXED_PACKET_BYTES(i) H10_PACKET_BYTES
#define H10_FIXED_WEIGHT_BYTES(i) H10_WEIGHT_BYTES
#define H10_FIXED_INPUT_BYTES(i) H10_INPUT_BYTES
#define H10_FIXED_OUTPUT_BYTES(i) H10_OUTPUT_TILE_BYTES
#endif
#define H10_INPUT_LOGICAL_BYTES H10_FIXED_INPUT_BYTES(state->shard_index)
#define H10_WEIGHT_LOGICAL_BYTES H10_FIXED_WEIGHT_BYTES(state->shard_index)
#define H10_OUTPUT_LOGICAL_BYTES H10_FIXED_OUTPUT_BYTES(state->shard_index)

/* A new explicit gate is required to reach the only START write. */
static bool allow_h10_start;
module_param(allow_h10_start, bool, 0400);
MODULE_PARM_DESC(allow_h10_start, "Permit explicit H10 eight-shard jobs after board review");
static bool measure_completion;
module_param(measure_completion, bool, 0400);
MODULE_PARM_DESC(measure_completion, "Log START-to-IRQ-thread elapsed time for performance measurement");

#ifndef H10_DEVICE_NAME
#define H10_DEVICE_NAME "h10_multishard"
#endif

enum h10_buffer_index {
	H10_BUFFER_PACKET,
	H10_BUFFER_INPUT,
	H10_BUFFER_WEIGHT,
	H10_BUFFER_OUTPUT,
	H10_BUFFER_COUNT
};

struct h10_buffer {
	void *cpu;
	dma_addr_t dma;
	size_t size;
};

struct h10_diag_state {
	struct h10_buffer buffer[H10_BUFFER_COUNT];
	struct miscdevice miscdev;
	struct mutex lock;
	struct completion finished;
	void __iomem *npu_regs;
	void __iomem *top_regs;
	struct resource *ddrs1_claim;
	int irq;
	bool dma_device_owned;
	bool irq_requested;
	bool module_ref_held;
	bool has_run;
	bool job_ready;
	bool output_exported;
	u32 shard_index;
	u64 packet_fnv;
	u64 input_fnv;
	u64 weight_fnv;
	u64 measured_start_ns;
	u32 expected_crc32;
	enum h10_run_phase phase;
	u32 writes_attempted;
	u32 irq_status;
	u32 work_status;
	u32 failure_reason;
	u32 integrity_fail_mask;
	u32 pre_reset_work;
	u32 pre_reset_irq;
	u32 reset_polls;
	u32 last_idle_work;
#ifdef H10_FIXED_MODEL
#ifndef H10_FIXED_MODEL_COUNT
#define H10_FIXED_MODEL_COUNT 8u
#endif
 struct h10_buffer model_packet[H10_FIXED_MODEL_COUNT], model_weight[H10_FIXED_MODEL_COUNT];
 u8 *model_packet_ref[H10_FIXED_MODEL_COUNT], *model_weight_ref[H10_FIXED_MODEL_COUNT], *input_ref;
 bool model_ready, completion_checked;
#endif
};

static const size_t h10_alloc_sizes[H10_BUFFER_COUNT] = {
	H10_PACKET_ALLOC_BYTES,
	H10_INPUT_ALLOC_BYTES,
	H10_WEIGHT_ALLOC_BYTES,
	H10_OUTPUT_ALLOC_BYTES
};
static const u64 h10_packet_fnv[] = H10_PACKET_FNV_LIST;
static const u64 h10_weight_fnv[] = H10_WEIGHT_FNV_LIST;

static u64 h10_fnv64(const u8 *data, size_t length)
{
	u64 result = 0xcbf29ce484222325ULL;
	size_t i = 0;
	unsigned int byte;
	u64 word;

	/* Avoid byte-load latency on coherent DMA memory. Read eight bytes per access,
	 * but retain the original byte order and every FNV multiplication. */
	for (; length - i >= sizeof(word); i += sizeof(word)) {
		memcpy(&word, data + i, sizeof(word));
		word = le64_to_cpu(word);
		for (byte = 0; byte < sizeof(word); ++byte) {
			result ^= word & 0xffu;
			result *= 0x100000001b3ULL;
			word >>= 8;
		}
	}
	for (; i < length; ++i) {
		result ^= data[i];
		result *= 0x100000001b3ULL;
	}
	return result;
}

#ifdef H10_FIXED_MODEL
static void h10_fixed_model_free(struct device *dev, struct h10_diag_state *state);
#endif

static void h10_release_buffers(struct device *dev, struct h10_diag_state *state)
{
	int i;

#ifdef H10_FIXED_MODEL
 h10_fixed_model_free(dev, state);
#endif
	for (i = H10_BUFFER_COUNT - 1; i >= 0; --i) {
		struct h10_buffer *buf = &state->buffer[i];

		if (buf->cpu) {
			fixed_cached_free(dev, buf->size, buf->cpu, buf->dma);
			buf->cpu = NULL;
		}
	}
}

static void h10_fill_plan(struct h10_diag_state *state, struct h10_plan *plan)
{
	plan->packet.address = state->buffer[H10_BUFFER_PACKET].dma;
	plan->packet.allocated_bytes = H10_PACKET_ALLOC_BYTES;
	plan->input.address = state->buffer[H10_BUFFER_INPUT].dma;
	plan->input.allocated_bytes = H10_INPUT_ALLOC_BYTES;
	plan->weight.address = state->buffer[H10_BUFFER_WEIGHT].dma;
	plan->weight.allocated_bytes = H10_WEIGHT_ALLOC_BYTES;
	plan->output.address = state->buffer[H10_BUFFER_OUTPUT].dma;
	plan->output.allocated_bytes = H10_OUTPUT_ALLOC_BYTES;
#ifdef H10_FIXED_MODEL
 if (state->model_ready) {
  plan->packet.address = state->model_packet[state->shard_index].dma;
  plan->weight.address = state->model_weight[state->shard_index].dma;
 }
#endif
}
#ifdef H10_FIXED_MODEL
#include "h10_fixed_model.inc"
#endif

static u32 h10_check_integrity(struct h10_diag_state *state, bool after_run)
{
#ifdef H10_FIXED_MODEL
 if (state->model_ready)
  return h10_fixed_model_integrity(state, after_run);
#endif
	u32 failures = 0;

	if ((state->job_ready &&
	     h10_fnv64(state->buffer[H10_BUFFER_PACKET].cpu,
		     H10_PACKET_BYTES) != state->packet_fnv) ||
	    memchr_inv((u8 *)state->buffer[H10_BUFFER_PACKET].cpu +
		       (state->job_ready ? H10_PACKET_BYTES : 0), 0xa5,
		       H10_PACKET_ALLOC_BYTES -
		       (state->job_ready ? H10_PACKET_BYTES : 0)))
		failures |= BIT(0);
	if ((state->job_ready &&
	     h10_fnv64(state->buffer[H10_BUFFER_INPUT].cpu,
		      H10_INPUT_LOGICAL_BYTES) != state->input_fnv) ||
	    memchr_inv((u8 *)state->buffer[H10_BUFFER_INPUT].cpu +
		       (state->job_ready ? H10_INPUT_LOGICAL_BYTES : 0), 0xa5,
		       H10_INPUT_ALLOC_BYTES -
		       (state->job_ready ? H10_INPUT_LOGICAL_BYTES : 0)))
		failures |= BIT(1);
	if ((state->job_ready &&
	     h10_fnv64(state->buffer[H10_BUFFER_WEIGHT].cpu,
		     H10_WEIGHT_LOGICAL_BYTES) != state->weight_fnv) ||
	    memchr_inv((u8 *)state->buffer[H10_BUFFER_WEIGHT].cpu +
		       (state->job_ready ? H10_WEIGHT_LOGICAL_BYTES : 0), 0xa5,
		       H10_WEIGHT_ALLOC_BYTES -
		       (state->job_ready ? H10_WEIGHT_LOGICAL_BYTES : 0)))
		failures |= BIT(2);
	if (memchr_inv((u8 *)state->buffer[H10_BUFFER_OUTPUT].cpu +
		       (after_run ? H10_OUTPUT_LOGICAL_BYTES : 0), 0xa5,
		       H10_OUTPUT_ALLOC_BYTES -
		       (after_run ? H10_OUTPUT_LOGICAL_BYTES : 0)))
		failures |= BIT(3);
	return failures;
}

static u32 h10_output_crc(struct h10_diag_state *state)
{
	dma_rmb();
	return crc32_le(~0u, state->buffer[H10_BUFFER_OUTPUT].cpu,
			H10_OUTPUT_LOGICAL_BYTES) ^ ~0u;
}

static void h10_refresh_completed(struct h10_diag_state *state)
{
	if (state->phase != H10_RUN_DONE_PINNED)
		return;
#ifdef H10_FIXED_MODEL
 if (state->completion_checked)
  return;
 state->completion_checked = true;
#endif
	dma_rmb();
	state->integrity_fail_mask |= h10_check_integrity(state, true);
	if (state->integrity_fail_mask) {
		state->phase = H10_RUN_FAULT_PINNED;
		state->failure_reason = 5;
	}
}

static void h10_fill_status(struct h10_diag_state *state,
			   struct h10_run_status *status)
{
	h10_refresh_completed(state);
	memset(status, 0, sizeof(*status));
	status->abi_version = H10_RUN_ABI_VERSION;
	status->phase = state->phase;
	status->writes_attempted = state->writes_attempted;
	status->irq_status = state->irq_status;
	status->work_status = state->work_status;
	status->failure_reason = state->failure_reason;
	status->integrity_fail_mask = state->integrity_fail_mask;
	status->reserved[0] = state->pre_reset_work;
	status->reserved[1] = state->pre_reset_irq;
	status->reserved[2] = state->reset_polls;
	status->reserved[3] = state->last_idle_work;
#ifdef H10_FIXED_MODEL
 status->reserved[3] = (state->model_ready ? 1u : 0u) |
                      (state->input_ref ? 2u : 0u) | (state->shard_index << 8);
#endif
	if (state->irq_status == 1u && state->work_status == 5u)
		status->output_crc32 = h10_output_crc(state);
}

static int h10_check_disabled_ddrs1(void)
{
	void __iomem *regs;
	u32 ctrl;
	unsigned int i;
	int ret = 0;

	regs = ioremap(H10_DDRS1_BASE, H10_DDRS1_CLAIM_BYTES);
	if (!regs)
		return -ENOMEM;
	ctrl = readl(regs + 0x4u);
	if (ctrl != 0x800u || readl(regs + 0x10u) != 0x301u ||
	    readl(regs + 0x14u) != 0u ||
	    readl(regs + 0x18u) != 0xffffffffu ||
	    readl(regs + 0x1cu) != 0u)
		ret = -EACCES;
	for (i = 1; i < 8; ++i) {
		u32 base = 0x10u + i * 0x10u;

		if (readl(regs + base) || readl(regs + base + 4u) ||
		    readl(regs + base + 8u) || readl(regs + base + 12u))
			ret = -EACCES;
	}
	if (readl(regs + 0x4u) != ctrl)
		ret = -EACCES;
	iounmap(regs);
	return ret;
}

static irqreturn_t h10_irq_thread(int irq, void *context)
{
	struct h10_diag_state *state = context;
	u32 irq_status = readl(state->npu_regs + H10_IRQ_STATUS_OFFSET);
	u32 work_status = readl(state->npu_regs + H10_WORK_STATUS_OFFSET);
	u64 observed_ns = measure_completion ? ktime_get_ns() : 0;

	(void)irq;
	if (irq_status)
		writel(irq_status, state->npu_regs + H10_IRQ_CLEAR_OFFSET);
	mutex_lock(&state->lock);
	if (state->phase == H10_RUN_TIMEOUT_PINNED && irq_status &&
	    !state->irq_status) {
		state->irq_status = irq_status;
		state->work_status = work_status;
	}
	if (state->phase == H10_RUN_STARTED && irq_status) {
		if (measure_completion && state->measured_start_ns)
			dev_info(state->miscdev.parent,
				 "H10_COMPLETION_TIMING shard=%u start_to_irq_thread_ns=%llu\n",
				 state->shard_index, observed_ns - state->measured_start_ns);
		state->irq_status = irq_status;
		state->work_status = work_status;
		if (irq_status == 1u && work_status == 5u)
			state->phase = H10_RUN_DONE_PINNED;
		else {
			state->phase = H10_RUN_FAULT_PINNED;
			state->failure_reason = 3;
		}
		complete(&state->finished);
	}
	mutex_unlock(&state->lock);
	return irq_status ? IRQ_HANDLED : IRQ_NONE;
}

static int h10_activate(struct h10_diag_state *state)
{
	u32 value;
	unsigned int count;
	unsigned int idle_count = 0;

	value = readl(state->top_regs + H10_TOP_ENABLE_OFFSET);
	writel(value | 3u, state->top_regs + H10_TOP_ENABLE_OFFSET);
	value = readl(state->top_regs + H10_TOP_ENABLE_OFFSET);
	if ((value & 3u) != 3u) {
		state->failure_reason = 11;
		dev_warn(state->miscdev.parent,
			 "H10 prestart TOP enable readback=%08x\n", value);
		return -EIO;
	}
	state->pre_reset_work = readl(state->npu_regs + H10_WORK_STATUS_OFFSET);
	state->pre_reset_irq = readl(state->npu_regs + H10_IRQ_STATUS_OFFSET);
	value = readl(state->top_regs + H10_TOP_SRAM_OFFSET);
	writel(value & 0xc0ffffffu, state->top_regs + H10_TOP_SRAM_OFFSET);
	readl(state->top_regs + H10_TOP_SRAM_OFFSET);
	writel(1u, state->npu_regs + H10_NPU_RESET_OFFSET);
	for (count = 0; count < 100000u; ++count) {
		if (!(readl(state->npu_regs + H10_NPU_RESET_OFFSET) & 1u))
			break;
		udelay(1);
	}
	state->reset_polls = count;
	if (count == 100000u) {
		state->failure_reason = 12;
		dev_warn(state->miscdev.parent,
			 "H10 prestart reset timeout pre_work=%08x pre_irq=%08x reset=%08x\n",
			 state->pre_reset_work, state->pre_reset_irq,
			 readl(state->npu_regs + H10_NPU_RESET_OFFSET));
		return -ETIMEDOUT;
	}
	value = readl(state->npu_regs + H10_IRQ_STATUS_OFFSET);
	if (value) {
		state->failure_reason = 13;
		dev_warn(state->miscdev.parent,
			 "H10 prestart pending IRQ=%08x pre_work=%08x\n",
			 value, state->pre_reset_work);
		return -EIO;
	}
	for (count = 0; count < 100000u; ++count) {
		value = readl(state->npu_regs + H10_WORK_STATUS_OFFSET);
		state->last_idle_work = value;
		if (value == 0u) {
			if (++idle_count == 16u)
				break;
		} else {
			idle_count = 0;
			if (value == 6u)
				break;
		}
		udelay(1);
	}
	value = readl(state->npu_regs + H10_IRQ_STATUS_OFFSET);
	if (idle_count != 16u || value) {
		state->failure_reason = 14;
		dev_warn(state->miscdev.parent,
			 "H10 prestart not idle pre_work=%08x pre_irq=%08x last_work=%08x idle_samples=%u polls=%u irq=%08x\n",
			 state->pre_reset_work, state->pre_reset_irq,
			 state->last_idle_work, idle_count, count, value);
		return -EIO;
	}
	return 0;
}

static void h10_fixed_dma_sync(struct h10_diag_state *s, bool device)
{
 unsigned int i;
 struct device *dev = s->miscdev.parent;
 if (s->dma_device_owned == device) return;
 for (i = H10_BUFFER_INPUT; i <= H10_BUFFER_OUTPUT; i++) {
  if (i == H10_BUFFER_WEIGHT) continue; /* The current resident model is used. */
  if (device) dma_sync_single_for_device(dev, s->buffer[i].dma, s->buffer[i].size, DMA_BIDIRECTIONAL);
  else dma_sync_single_for_cpu(dev, s->buffer[i].dma, s->buffer[i].size, DMA_BIDIRECTIONAL);
 }
 i = s->shard_index;
 if (device) {
  dma_sync_single_for_device(dev, s->model_packet[i].dma, H10_PACKET_ALLOC_BYTES, DMA_BIDIRECTIONAL);
  dma_sync_single_for_device(dev, s->model_weight[i].dma, H10_WEIGHT_ALLOC_BYTES, DMA_BIDIRECTIONAL);
 } else {
  dma_sync_single_for_cpu(dev, s->model_packet[i].dma, H10_PACKET_ALLOC_BYTES, DMA_BIDIRECTIONAL);
  dma_sync_single_for_cpu(dev, s->model_weight[i].dma, H10_WEIGHT_ALLOC_BYTES, DMA_BIDIRECTIONAL);
 }
 s->dma_device_owned = device;
}

static int h10_write_once(struct h10_diag_state *state,
			 struct h10_plan *plan)
{
	const u32 offsets[H10_SUBMIT_WRITE_COUNT] = {
		0x0050u, 0x2000u, 0x2004u, 0x6000u,
		0x003cu, 0x100cu, 0x1010u, 0x1000u
	};
	u32 values[H10_SUBMIT_WRITE_COUNT] = {
		0, (u32)plan->input.address, (u32)plan->weight.address,
		(u32)plan->output.address, 0x00001010u,
		(u32)plan->packet.address, H10_FIXED_PACKET_BYTES(state->shard_index) / 4u, 1u
	};
	u32 i;

	if (h10_validate_plan(plan) != H10_CONTRACT_OK)
		return -ERANGE;
	dma_wmb();
	for (i = 0; i < H10_SUBMIT_WRITE_COUNT; ++i) {
		if (i == H10_SUBMIT_WRITE_COUNT - 1u &&
		    (readl(state->npu_regs + H10_IRQ_STATUS_OFFSET) ||
		     readl(state->npu_regs + H10_WORK_STATUS_OFFSET)))
			return -EIO;
		state->writes_attempted = i + 1u;
		if (measure_completion && i == H10_SUBMIT_WRITE_COUNT - 1u)
			state->measured_start_ns = ktime_get_ns();
		writel(values[i], state->npu_regs + offsets[i]);
		if (i == H10_SUBMIT_WRITE_COUNT - 1u)
			enable_irq(state->irq);
	}
	return 0;
}

static void h10_unmap_before_start(struct h10_diag_state *state)
{
	if (state->irq_requested) {
		free_irq(state->irq, state);
		state->irq_requested = false;
	}
	if (state->top_regs) {
		iounmap(state->top_regs);
		state->top_regs = NULL;
	}
	if (state->npu_regs) {
		iounmap(state->npu_regs);
		state->npu_regs = NULL;
	}
	if (state->ddrs1_claim) {
		release_mem_region(H10_DDRS1_BASE, H10_DDRS1_CLAIM_BYTES);
		state->ddrs1_claim = NULL;
	}
}

#ifndef H10_FIXED_MODEL
static long h10_set_job_ioctl(struct h10_diag_state *state, void __user *arg)
{
	struct h10_run_job request;
	u8 *packet;
	u8 *weight;
	u8 *input;
	int ret;

	if (!capable(CAP_SYS_RAWIO))
		return -EPERM;
	if (copy_from_user(&request, arg, sizeof(request)))
		return -EFAULT;
	if (request.abi_version != H10_RUN_ABI_VERSION ||
	    request.shard_index >= ARRAY_SIZE(h10_packet_fnv) ||
	    request.packet_bytes != H10_PACKET_BYTES ||
	    request.weight_bytes != H10_WEIGHT_LOGICAL_BYTES ||
	    request.input_bytes != H10_INPUT_LOGICAL_BYTES ||
	    !request.packet_ptr || !request.weight_ptr || !request.input_ptr ||
	    request.reserved ||
	    request.packet_fnv64 != h10_packet_fnv[request.shard_index] ||
	    request.weight_fnv64 != h10_weight_fnv[request.shard_index])
		return -EINVAL;
	packet = memdup_user((const void __user *)(unsigned long)request.packet_ptr,
			     H10_PACKET_BYTES);
	if (IS_ERR(packet))
		return PTR_ERR(packet);
	weight = memdup_user((const void __user *)(unsigned long)request.weight_ptr,
			     H10_WEIGHT_LOGICAL_BYTES);
	if (IS_ERR(weight)) {
		ret = PTR_ERR(weight);
		goto out_packet;
	}
	input = memdup_user((const void __user *)(unsigned long)request.input_ptr,
			    H10_INPUT_LOGICAL_BYTES);
	if (IS_ERR(input)) {
		ret = PTR_ERR(input);
		goto out_weight;
	}
	if (h10_fnv64(packet, H10_PACKET_BYTES) != request.packet_fnv64 ||
	    h10_fnv64(weight, H10_WEIGHT_LOGICAL_BYTES) != request.weight_fnv64 ||
	    h10_fnv64(input, H10_INPUT_LOGICAL_BYTES) != request.input_fnv64) {
		ret = -EBADMSG;
		goto out_input;
	}
	ret = mutex_lock_interruptible(&state->lock);
	if (ret)
		goto out_input;
	if (state->phase != H10_RUN_COLD || state->has_run ||
	    state->job_ready || state->module_ref_held) {
		ret = -EBUSY;
		goto out_unlock;
	}
	memcpy(state->buffer[H10_BUFFER_PACKET].cpu, packet, H10_PACKET_BYTES);
	memcpy(state->buffer[H10_BUFFER_WEIGHT].cpu, weight,
	       H10_WEIGHT_LOGICAL_BYTES);
	memcpy(state->buffer[H10_BUFFER_INPUT].cpu, input,
	       H10_INPUT_LOGICAL_BYTES);
	state->shard_index = request.shard_index;
	state->packet_fnv = request.packet_fnv64;
	state->weight_fnv = request.weight_fnv64;
	state->input_fnv = request.input_fnv64;
	state->expected_crc32 = request.expected_crc32;
	state->job_ready = true;
	ret = 0;
out_unlock:
	mutex_unlock(&state->lock);
out_input:
	kfree(input);
out_weight:
	kfree(weight);
out_packet:
	kfree(packet);
	return ret;
}

#endif
static long h10_run_ioctl(struct h10_diag_state *state, void __user *arg)
{
	struct h10_run_status request;
	struct h10_plan plan = { 0 };
	unsigned long waited;
	int ret;

	if (!allow_h10_start || !capable(CAP_SYS_RAWIO))
		return -EPERM;
	if (copy_from_user(&request, arg, sizeof(request)))
		return -EFAULT;
	if (request.abi_version != H10_RUN_ABI_VERSION ||
	    memchr_inv(request.reserved, 0, sizeof(request.reserved)))
		return -EINVAL;
	ret = mutex_lock_interruptible(&state->lock);
	if (ret)
		return ret;
	if (state->phase != H10_RUN_COLD || state->has_run ||
	    !state->job_ready) {
		ret = -EBUSY;
		goto out_unlock;
	}
	h10_fill_plan(state, &plan);
	if (h10_validate_plan(&plan) != H10_CONTRACT_OK ||
	    h10_check_integrity(state, false)) {
		ret = -EIO;
		goto out_unlock;
	}
	if (!try_module_get(THIS_MODULE)) {
		ret = -ENODEV;
		goto out_unlock;
	}
	state->module_ref_held = true;
#ifdef H10_FIXED_MODEL
 if (!state->irq_requested) {
#endif
	state->ddrs1_claim = request_mem_region(H10_DDRS1_BASE,
			H10_DDRS1_CLAIM_BYTES, "h10_multishard_ddrs1");
	if (!state->ddrs1_claim) {
		ret = -EBUSY;
		goto out_prestart;
	}
	ret = h10_check_disabled_ddrs1();
	if (ret)
		goto out_prestart;
	state->npu_regs = ioremap(0x63f00000ULL, 0x100000u);
	state->top_regs = ioremap(0xf8800000ULL, 0x200u);
	if (!state->npu_regs || !state->top_regs) {
		ret = -ENOMEM;
		goto out_prestart;
	}
	ret = request_threaded_irq(state->irq, NULL, h10_irq_thread,
			IRQF_ONESHOT | IRQF_NO_AUTOEN | IRQF_TRIGGER_HIGH,
			"h10_multishard", state);
	if (ret)
		goto out_prestart;
	state->irq_requested = true;
#ifdef H10_FIXED_MODEL
 } else {
  ret = h10_check_disabled_ddrs1();
  if (ret) goto out_prestart;
 }
#endif
 reinit_completion(&state->finished);
	/* Pin DMA and module before TOP/soft reset, which can have side effects. */
	state->has_run = true;
	state->phase = H10_RUN_STARTED;
	state->writes_attempted = 0;
	state->failure_reason = 0;
#ifdef H10_FIXED_MODEL
 state->completion_checked = false;
#endif
	ret = h10_activate(state);
	if (ret) {
		state->phase = H10_RUN_FAULT_PINNED;
		if (!state->failure_reason)
			state->failure_reason = 1;
		goto out_result;
	}
	h10_fixed_dma_sync(state, true);
	ret = h10_write_once(state, &plan);
	if (ret) {
		state->phase = H10_RUN_FAULT_PINNED;
		state->failure_reason = 2;
		goto out_result;
	}
	mutex_unlock(&state->lock);
	waited = wait_for_completion_timeout(&state->finished,
			msecs_to_jiffies(H10_TIMEOUT_MS));
	mutex_lock(&state->lock);
	h10_fixed_dma_sync(state, false);
	if (!waited && state->phase == H10_RUN_STARTED) {
		state->phase = H10_RUN_TIMEOUT_PINNED;
		state->failure_reason = 4;
		dev_warn(state->miscdev.parent,
			 "H10_TIMEOUT_SNAPSHOT work=%08x irq=%08x reset=%08x output_crc=%08x integrity=%08x\n",
			 readl(state->npu_regs + H10_WORK_STATUS_OFFSET),
			 readl(state->npu_regs + H10_IRQ_STATUS_OFFSET),
			 readl(state->npu_regs + H10_NPU_RESET_OFFSET),
			 h10_output_crc(state),
			 h10_check_integrity(state, true));
		dev_warn(state->miscdev.parent,
			 "H10_TIMEOUT_ERRORS out_cnt=%08x wb0=%08x wb1=%08x ch0=%08x ch1=%08x\n",
			 readl(state->npu_regs + 0x603cu),
			 readl(state->npu_regs + 0x6040u),
			 readl(state->npu_regs + 0x6044u),
			 readl(state->npu_regs + 0x6048u),
			 readl(state->npu_regs + 0x604cu));
	}
out_result:
	h10_fixed_dma_sync(state, false);
	h10_fill_status(state, &request);
	mutex_unlock(&state->lock);
	return copy_to_user(arg, &request, sizeof(request)) ? -EFAULT : 0;
out_prestart:
	h10_unmap_before_start(state);
	state->module_ref_held = false;
	module_put(THIS_MODULE);
out_unlock:
	mutex_unlock(&state->lock);
	return ret;
}

static long h10_status_ioctl(struct h10_diag_state *state, void __user *arg)
{
	struct h10_run_status result;
	int ret = mutex_lock_interruptible(&state->lock);

	if (ret)
		return ret;
	h10_fill_status(state, &result);
	mutex_unlock(&state->lock);
	return copy_to_user(arg, &result, sizeof(result)) ? -EFAULT : 0;
}

static long h10_output_ioctl(struct h10_diag_state *state, void __user *arg)
{
	struct h10_run_output request;
	int ret;

	if (copy_from_user(&request, arg, sizeof(request)))
		return -EFAULT;
	if (request.abi_version != H10_RUN_ABI_VERSION ||
	    request.bytes != H10_OUTPUT_LOGICAL_BYTES || !request.user_ptr)
		return -EINVAL;
	ret = mutex_lock_interruptible(&state->lock);
	if (ret)
		return ret;
	h10_refresh_completed(state);
	/* An accepted completion may be exported even if its guard is damaged,
	 * so the raw bytes can be archived before mandatory cold recovery. */
	if (state->irq_status != 1u || state->work_status != 5u ||
	    (state->phase != H10_RUN_DONE_PINNED &&
	     state->phase != H10_RUN_FAULT_PINNED)) {
		ret = -ENODATA;
		goto out_unlock;
	}
	dma_rmb();
	ret = copy_to_user((void __user *)(unsigned long)request.user_ptr,
			   state->buffer[H10_BUFFER_OUTPUT].cpu,
			   H10_OUTPUT_LOGICAL_BYTES) ? -EFAULT : 0;
	if (!ret)
		state->output_exported = true;
out_unlock:
	mutex_unlock(&state->lock);
	return ret;
}

static long h10_diag_output_ioctl(struct h10_diag_state *state, void __user *arg)
{
	struct h10_run_output request;
	int ret;

	if (copy_from_user(&request, arg, sizeof(request)))
		return -EFAULT;
	if (request.abi_version != H10_RUN_ABI_VERSION ||
	    request.bytes != H10_OUTPUT_LOGICAL_BYTES || !request.user_ptr)
		return -EINVAL;
	ret = mutex_lock_interruptible(&state->lock);
	if (ret)
		return ret;
	if (!state->has_run || state->writes_attempted != H10_SUBMIT_WRITE_COUNT ||
	    (state->phase != H10_RUN_TIMEOUT_PINNED &&
	     state->phase != H10_RUN_FAULT_PINNED)) {
		ret = -EPERM;
		goto out_unlock;
	}
	dma_rmb();
	ret = copy_to_user((void __user *)(unsigned long)request.user_ptr,
			   state->buffer[H10_BUFFER_OUTPUT].cpu,
			   H10_OUTPUT_LOGICAL_BYTES) ? -EFAULT : 0;
out_unlock:
	mutex_unlock(&state->lock);
	return ret;
}

static long h10_release_ioctl(struct h10_diag_state *state, void __user *arg)
{
	struct h10_run_release request;
	u32 irq, work;
	unsigned int i;
	int ret;

	if (copy_from_user(&request, arg, sizeof(request)))
		return -EFAULT;
	if (request.abi_version != H10_RUN_ABI_VERSION)
		return -EINVAL;
	ret = mutex_lock_interruptible(&state->lock);
	if (ret)
		return ret;
	h10_refresh_completed(state);
	if (state->phase != H10_RUN_DONE_PINNED ||
	    state->writes_attempted != H10_SUBMIT_WRITE_COUNT ||
	    !state->output_exported ||
	#ifndef H10_FIXED_MODEL
    request.expected_crc32 != state->expected_crc32 ||
#endif
	    state->integrity_fail_mask ||
	    h10_output_crc(state) !=
#ifdef H10_FIXED_MODEL
    request.expected_crc32
#else
    state->expected_crc32
#endif
    ) {
		ret = -EIO;
		goto out_unlock;
	}
	for (i = 0; i < 16u; ++i) {
		irq = readl(state->npu_regs + H10_IRQ_STATUS_OFFSET);
		work = readl(state->npu_regs + H10_WORK_STATUS_OFFSET);
		if (irq || (work != 0u && work != 5u)) {
			ret = -EAGAIN;
			goto out_unlock;
		}
		udelay(1);
	}
	/* Prevent new operations while free_irq waits for its thread. */
	state->phase = H10_RUN_PREPARING;
	mutex_unlock(&state->lock);
	disable_irq(state->irq);
	irq = readl(state->npu_regs + H10_IRQ_STATUS_OFFSET);
	work = readl(state->npu_regs + H10_WORK_STATUS_OFFSET);
	mutex_lock(&state->lock);
	if (irq || (work != 0u && work != 5u)) {
		state->phase = H10_RUN_FAULT_PINNED;
		state->failure_reason = 6;
		mutex_unlock(&state->lock);
		return -EIO;
	}
	mutex_unlock(&state->lock);
#ifndef H10_FIXED_MODEL
	h10_unmap_before_start(state);
#endif
	mutex_lock(&state->lock);
#ifdef H10_FIXED_MODEL
 memset(state->buffer[H10_BUFFER_OUTPUT].cpu, 0xa5, H10_OUTPUT_ALLOC_BYTES);
 state->shard_index++;
 if (state->shard_index == H10_FIXED_MODEL_COUNT)
  state->shard_index = 0;
#ifdef H10_FIXED_INPUT_PER_JOB
 {
#elif defined(H10_FIXED_INPUT_GROUP_END)
 if (H10_FIXED_INPUT_GROUP_END(state->shard_index)) {
#else
 if (state->shard_index == 0) {
#endif
  kfree(state->input_ref);
  state->input_ref = NULL;
  memset(state->buffer[H10_BUFFER_INPUT].cpu, 0xa5, H10_INPUT_ALLOC_BYTES);
 }
 state->phase = H10_RUN_COLD;
 state->module_ref_held = false;
 state->has_run = false;
 state->job_ready = state->input_ref != NULL;
 state->output_exported = false;
 state->completion_checked = false;
#else
	memset(state->buffer[H10_BUFFER_INPUT].cpu, 0xa5,
	       H10_INPUT_ALLOC_BYTES);
	memset(state->buffer[H10_BUFFER_PACKET].cpu, 0xa5,
	       H10_PACKET_ALLOC_BYTES);
	memset(state->buffer[H10_BUFFER_WEIGHT].cpu, 0xa5,
	       H10_WEIGHT_ALLOC_BYTES);
	memset(state->buffer[H10_BUFFER_OUTPUT].cpu, 0xa5,
	       H10_OUTPUT_ALLOC_BYTES);
	state->phase = H10_RUN_COLD;
	state->module_ref_held = false;
	state->has_run = false;
	state->job_ready = false;
	state->output_exported = false;
	state->shard_index = 0;
	state->packet_fnv = 0;
	state->weight_fnv = 0;
	state->input_fnv = 0;
	state->expected_crc32 = 0;
#endif
	state->writes_attempted = 0;
	state->irq_status = 0;
	state->work_status = 0;
	state->failure_reason = 0;
	state->integrity_fail_mask = 0;
	mutex_unlock(&state->lock);
	module_put(THIS_MODULE);
	return 0;
out_unlock:
	mutex_unlock(&state->lock);
	return ret;
}

static long h10_ioctl(struct file *file, unsigned int command,
		     unsigned long argument)
{
	struct miscdevice *misc = file->private_data;
	struct h10_diag_state *state = container_of(misc,
		struct h10_diag_state, miscdev);
	void __user *arg = (void __user *)argument;

	if (command == H10_IOCTL_RUN)
		return h10_run_ioctl(state, arg);
	if (command == H10_IOCTL_STATUS)
		return h10_status_ioctl(state, arg);
	if (command == H10_IOCTL_OUTPUT)
		return h10_output_ioctl(state, arg);
	if (command == H10_IOCTL_DIAG_OUTPUT)
		return h10_diag_output_ioctl(state, arg);
	if (command == H10_IOCTL_RELEASE)
		return h10_release_ioctl(state, arg);
#ifdef H10_FIXED_MODEL
 if (command == H10_IOCTL_LOAD_MODEL)
  return h10_fixed_load_ioctl(state, arg);
 if (command == H10_IOCTL_SET_INPUT)
  return h10_fixed_input_ioctl(state, arg);
 return -ENOTTY;
#else
	if (command == H10_IOCTL_SET_JOB)
		return h10_set_job_ioctl(state, arg);
	return -ENOTTY;
#endif
}

static const struct file_operations h10_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = h10_ioctl,
	.llseek = no_llseek,
};

static int h10_probe_impl(struct platform_device *pdev)
{
	struct h10_diag_state *state;
	struct h10_plan plan = { 0 };
	struct resource *regs;
	struct resource *top_regs;
	struct resource *crp_regs;
	struct reset_control *reset;
	int irq;
	int i;
	int ret;

	regs = platform_get_resource(pdev, IORESOURCE_MEM, 0);
	if (!regs || regs->start != 0x63f00000ULL ||
	    resource_size(regs) != 0x100000ULL)
		return -ENODEV;
	top_regs = platform_get_resource(pdev, IORESOURCE_MEM, 1);
	crp_regs = platform_get_resource(pdev, IORESOURCE_MEM, 2);
	if (!top_regs || top_regs->start != 0xf8800000ULL ||
	    resource_size(top_regs) != 0x200ULL || !crp_regs ||
	    crp_regs->start != 0xf8801000ULL ||
	    resource_size(crp_regs) != 0x100ULL)
		return -ENODEV;
	irq = platform_get_irq(pdev, 0);
	if (irq < 0)
		return irq;
	reset = devm_reset_control_get_optional_shared(&pdev->dev, NULL);
	if (IS_ERR(reset))
		return PTR_ERR(reset);
	if (reset)
		return -EOPNOTSUPP;
	state = devm_kzalloc(&pdev->dev, sizeof(*state), GFP_KERNEL);
	if (!state)
		return -ENOMEM;
	ret = dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32));
	if (ret)
		return ret;
	for (i = 0; i < H10_BUFFER_COUNT; ++i) {
		struct h10_buffer *buf = &state->buffer[i];

		buf->size = h10_alloc_sizes[i];
		buf->cpu = fixed_cached_alloc(&pdev->dev, buf->size,
					      &buf->dma, GFP_KERNEL);
		if (!buf->cpu) {
			ret = -ENOMEM;
			goto err_release;
		}
		memset(buf->cpu, 0xa5, buf->size);
	}
	plan.packet.address = state->buffer[H10_BUFFER_PACKET].dma;
	plan.packet.allocated_bytes = H10_PACKET_ALLOC_BYTES;
	plan.input.address = state->buffer[H10_BUFFER_INPUT].dma;
	plan.input.allocated_bytes = H10_INPUT_ALLOC_BYTES;
	plan.weight.address = state->buffer[H10_BUFFER_WEIGHT].dma;
	plan.weight.allocated_bytes = H10_WEIGHT_ALLOC_BYTES;
	plan.output.address = state->buffer[H10_BUFFER_OUTPUT].dma;
	plan.output.allocated_bytes = H10_OUTPUT_ALLOC_BYTES;
	if (h10_validate_plan(&plan) != H10_CONTRACT_OK) {
		ret = -ERANGE;
		goto err_release;
	}
	mutex_init(&state->lock);
	init_completion(&state->finished);
	state->irq = irq;
	state->phase = H10_RUN_COLD;
	state->miscdev.minor = MISC_DYNAMIC_MINOR;
	state->miscdev.name = H10_DEVICE_NAME;
	state->miscdev.fops = &h10_fops;
	state->miscdev.mode = 0600;
	state->miscdev.parent = &pdev->dev;
	ret = misc_register(&state->miscdev);
	if (ret)
		goto err_release;
	platform_set_drvdata(pdev, state);
	dev_info(&pdev->dev,
		 "H10_MULTISHARD_PREP packet=%pad/%zu input=%pad/%zu weight=%pad/%zu output=%pad/%zu irq=%d start_gate=%u; no START at probe\n",
		 &state->buffer[H10_BUFFER_PACKET].dma,
		 state->buffer[H10_BUFFER_PACKET].size,
		 &state->buffer[H10_BUFFER_INPUT].dma,
		 state->buffer[H10_BUFFER_INPUT].size,
		 &state->buffer[H10_BUFFER_WEIGHT].dma,
		 state->buffer[H10_BUFFER_WEIGHT].size,
		 &state->buffer[H10_BUFFER_OUTPUT].dma,
		 state->buffer[H10_BUFFER_OUTPUT].size,
		 irq, allow_h10_start ? 1u : 0u);
	return 0;

err_release:
	h10_release_buffers(&pdev->dev, state);
	return ret;
}

static int h10_probe_status = -ENODEV;

static int h10_diag_probe(struct platform_device *pdev)
{
	h10_probe_status = h10_probe_impl(pdev);
	return h10_probe_status;
}

static int h10_diag_remove(struct platform_device *pdev)
{
	struct h10_diag_state *state = platform_get_drvdata(pdev);
	u32 failures;

	misc_deregister(&state->miscdev);
	if (state->module_ref_held || state->phase != H10_RUN_COLD)
		return -EBUSY;
	failures = h10_check_integrity(state, state->has_run);
	dev_info(&pdev->dev, "H10_MULTISHARD_PREP guard=%s; releasing buffers\n",
		 failures ? "FAIL" : "PASS");
#ifdef H10_FIXED_MODEL
 h10_unmap_before_start(state);
#endif
	h10_release_buffers(&pdev->dev, state);
	return 0;
}

static const struct of_device_id h10_diag_of_match[] = {
	{ .compatible = "anlogic,hard_npu" },
	{ }
};
MODULE_DEVICE_TABLE(of, h10_diag_of_match);

static struct platform_driver h10_diag_driver = {
	.probe = h10_diag_probe,
	.remove = h10_diag_remove,
	.driver = {
		.name = H10_DEVICE_NAME,
		.of_match_table = h10_diag_of_match,
		.suppress_bind_attrs = true,
	},
};

static int __init h10_diag_init(void)
{
	int ret;

	h10_probe_status = -ENODEV;
	ret = platform_driver_register(&h10_diag_driver);
	if (ret)
		return ret;
	if (h10_probe_status) {
		platform_driver_unregister(&h10_diag_driver);
		return h10_probe_status;
	}
	return 0;
}

static void __exit h10_diag_exit(void)
{
	platform_driver_unregister(&h10_diag_driver);
}

module_init(h10_diag_init);
module_exit(h10_diag_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("HardNPU H10 gated eight-shard multi-frame diagnostic");
