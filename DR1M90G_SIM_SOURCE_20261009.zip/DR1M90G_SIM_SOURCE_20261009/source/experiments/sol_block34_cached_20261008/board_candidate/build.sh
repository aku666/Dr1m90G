#!/bin/sh
set -eu
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
cd /run/block34_cached_board1
for task_module in driver/block34_hard_fixed pl_driver; do
 make -C /root/softnpu_ddr_v054_target_20260920_1/kernel M="$PWD/$task_module" ARCH=arm64 KBUILD_MODPOST_WARN=1 modules
done
sha256sum driver/block34_hard_fixed/block34_hard_fixed.ko pl_driver/net_pl.ko
echo CACHED_DMA_BUILD_COMPLETE_NO_START
