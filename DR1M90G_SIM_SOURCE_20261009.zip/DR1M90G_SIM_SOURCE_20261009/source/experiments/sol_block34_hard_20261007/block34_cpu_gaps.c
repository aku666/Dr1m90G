/* Reuse the existing exact fixed DW/residual CPU fallback between Hard PW. */
#include "front_block4_native.c"
int block34_cpu_dw(const uint8_t *input, const uint8_t *parameters,
                  uint8_t *output, int stride) {
 if (!input || !parameters || !output || (stride != 1 && stride != 2)) return -1;
 if (stride == 1) depthwise(input, parameters, output);
 else depthwise4(input, parameters, output);
 return 0;
}
int block34_cpu_add(const uint8_t *skip, const uint8_t *project, uint8_t *output) {
 if (!skip || !project || !output) return -1;
 for (int p = 0; p < 24*PIXELS; ++p) {
  int64_t value = ((int64_t)skip[p]-106)*958620430LL +
                  ((int64_t)project[p]-101)*1114098186LL;
  output[p] = quant(value, 124);
 }
 return 0;
}
