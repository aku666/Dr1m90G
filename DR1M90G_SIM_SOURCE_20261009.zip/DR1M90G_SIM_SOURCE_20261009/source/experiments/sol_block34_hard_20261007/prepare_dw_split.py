"""Reuse qualified BLOCK34 DW hardware for the two Hard PW bridge gaps."""
import json
import shutil
from pathlib import Path
import numpy as np
from reference import HardBlock34Reference

ROOT = Path(__file__).resolve().parents[2]
stage = ROOT / 'experiments/sol_block34_dw_split_20261008'
source = ROOT / 'experiments/sol_camera_dsi_result_20261006'
stage.mkdir(exist_ok=False)
shutil.copytree(source / 'uisrc', stage / 'uisrc')
for name in ('soc_v2.prj', 'camera_dsi_pins.adc', 'board_softnpu_80mhz.sdc'):
    shutil.copyfile(source / name, stage / name)

def replace(path, old, new, count=1):
    raw = path.read_text()
    assert raw.count(old) == count, (path, old, raw.count(old))
    path.write_bytes(raw.replace(old, new).encode())

replace(stage / 'soc_v2.prj', source.as_posix(), stage.as_posix())
chain = stage / 'uisrc/01_rtl/front_block34/block34_axi_chain.v'
replace(chain, 'input wire clk,resetn,start,', 'input wire clk,resetn,start,\ninput wire [1:0] dw_only_mode,')
replace(chain, 'reg [1:0] state;reg [2:0] phase;', 'reg dw_only;\nreg [1:0] state;reg [2:0] phase;')
replace(chain, '.block4(phase==4),.input_base(se),.parameter_base(phase==4?ep+32\'d54528:dp),.output_base(sd),',
        '.block4(phase==4),.input_base(dw_only?ib:se),.parameter_base(dw_only?dp:phase==4?ep+32\'d54528:dp),.output_base(dw_only?ob:sd),')
replace(chain, 'state<=IDLE;phase<=0;done<=0;fault<=0;', 'state<=IDLE;phase<=0;dw_only<=0;done<=0;fault<=0;')
replace(chain, 'done<=0;fault<=0;phase<=0;', '''done<=0;fault<=0;
  // Fixed modes: full chain, DW3 stride1, DW4 stride2. Unconnected old
  // testbench ports select the original chain through the default case.
  case(dw_only_mode)
   2'd1: begin dw_only<=1;phase<=1;end
   2'd2: begin dw_only<=1;phase<=4;end
   default: begin dw_only<=0;phase<=0;end
  endcase''')
replace(chain, 'if(phase==5) begin done<=1;state<=IDLE;end', 'if(dw_only || phase==5) begin done<=1;state<=IDLE;end')

control = stage / 'uisrc/01_rtl/v4r_c128/net_pl_control.v'
replace(control, 'output reg c_start,output wire [31:0] c_input', 'output reg [1:0] c_dw_mode,\n    output reg c_start,output wire [31:0] c_input')
replace(control, 'c_start<=0;ci<=0;', 'c_dw_mode<=0;c_start<=0;ci<=0;')
replace(control, "32'h8c: ci<=wd;", "32'hb0: if(wd<=2) c_dw_mode<=wd[1:0]; else S_AXI_BRESP<=2;\n                    32'h8c: ci<=wd;")
replace(control, "32'h84: S_AXI_RDATA<=BLOCK34?32'h00060001:32'h00040001;", "32'h84: S_AXI_RDATA<=BLOCK34?32'h00060002:32'h00040001;")
replace(control, "32'h8c: S_AXI_RDATA<=ci;", "32'hb0: S_AXI_RDATA<={30'b0,c_dw_mode};\n                    32'h8c: S_AXI_RDATA<=ci;")
datapath = stage / 'uisrc/01_rtl/v4r_c128/net_pl_datapath.v'
replace(datapath, 'input wire c_start,', 'input wire c_start,\ninput wire [1:0] c_dw_mode,')
replace(datapath, 'block34_axi_chain block34(.clk(clk),.resetn(resetn),.start(c_start),',
        'block34_axi_chain block34(.clk(clk),.resetn(resetn),.start(c_start),.dw_only_mode(c_dw_mode),')
system = stage / 'uisrc/01_rtl/system/hdl/system.v'
replace(system, 'wire c_start,c_busy,c_done,c_fault;', 'wire [1:0] c_dw_mode;\nwire c_start,c_busy,c_done,c_fault;')
replace(system, '.c_start(c_start),.c_busy(c_busy)', '.c_dw_mode(c_dw_mode),.c_start(c_start),.c_busy(c_busy)', 2)

driver = stage / 'driver'
driver.mkdir()
shutil.copyfile(ROOT / 'implementation_v4r/driver/net_pl.c', driver / 'net_pl.c')
shutil.copyfile(ROOT / 'implementation_v4r/driver/net_pl_uapi.h', driver / 'net_pl_uapi.h')
replace(driver / 'net_pl_uapi.h', '#define NET_BLOCK34_RUN',
        "#define NET_DW144_RUN _IOWR('G',1,struct net_pl_job)\n#define NET_DW144_STRIDE2_RUN _IOWR('H',1,struct net_pl_job)\n#define NET_BLOCK34_RUN")
path = driver / 'net_pl.c'
replace(path, 'bool v=cmd==NET_V4R_RUN,', 'bool d1=cmd==NET_DW144_RUN,d2=cmd==NET_DW144_STRIDE2_RUN,d=d1||d2;\n bool v=cmd==NET_V4R_RUN,')
replace(path, 'c=cc || cmd==NET_BLOCK3_RUN;', 'c=d || cc || cmd==NET_BLOCK3_RUN;')
replace(path, 'u64 started;int i,ret=0,slot=', 'int input_index=d?3:0,output_index=d?4:2;\n u64 started;int i,ret=0,slot=')
replace(path, 'if(c && cc!=s->block_extended)return -EINVAL;', 'if(c && ((d && !s->block_extended) || (!d && cc!=s->block_extended)))return -EINVAL;')
replace(path, 'if(cc)length[1]=64256;', 'if(cc)length[1]=64256;\n if(d){length[0]=0;length[1]=4608;length[2]=0;length[3]=451584;length[4]=d2?129024:451584;}')
replace(path, 'output_length=cc?28672:length[2];', 'output_length=d?length[4]:cc?28672:length[2];')
replace(path, 'job->abi!=(cc ? 0x60001', 'job->abi!=(d ? (d2?0x80001:0x70001) : cc ? 0x60001')
replace(path, 'job->input_bytes!=length[0]', 'job->input_bytes!=length[input_index]')
# Generalize the existing guarded buffers only where their input/output indexes
# were hardcoded. Both DW modes reuse BLOCK34 scratch 3/4, no new DMA buffers.
replace(path, 's->cpu[slot][0]+GUARD', 's->cpu[slot][input_index]+GUARD', 3)
replace(path, 'job->input_ptr,length[0]', 'job->input_ptr,length[input_index]')
replace(path, 's->cpu[slot][input_index]+GUARD,length[0]', 's->cpu[slot][input_index]+GUARD,length[input_index]', 2)
replace(path, 's->dma[slot][0]+GUARD', 's->dma[slot][input_index]+GUARD')
replace(path, 's->dma[slot][2]+GUARD', 's->dma[slot][output_index]+GUARD')
replace(path, 's->cpu[slot][2]+GUARD,output_length', 's->cpu[slot][output_index]+GUARD,output_length')
replace(path, 's->dma[slot][1]+GUARD+23040', 's->dma[slot][1]+GUARD+(d?0:23040)')
replace(path, 'if(c){\n  writel', 'if(c){\n  writel(d2?2:d1?1:0,s->regs+0xb0);\n  writel')
replace(path, 'i==7 && s->block_extended ? 0x60001', 'i==7 && s->block_extended ? 0x60002')
(driver / 'Makefile').write_bytes(b'obj-m += net_pl.o\n')

ref = HardBlock34Reference(Path(__file__).resolve().parent / 'assets_vendor')
x = np.load(ROOT / 'experiments/sol_block34_20261001/fixture/input.npy', allow_pickle=False)
e3 = ref.block3.convolution(x, 0)
d3 = ref.block3.convolution(e3, 1)
e4 = ref.block4.convolution(ref.block3(x), 0)
d4 = ref.block4.convolution(e4, 1)
fixture = stage / 'fixture'
fixture.mkdir()
for name, value in dict(input3=e3, gold3=d3, input4=e4).items():
    (fixture / (name+'.hex')).write_text(''.join(f'{v:02x}\n' for v in value.reshape(-1)))
physical = np.zeros((1,144,28,32),np.uint8)
physical[:,:,:,:28] = d4
(fixture / 'gold4.hex').write_text(''.join(f'{v:02x}\n' for v in physical.reshape(-1)))
for block in (3, 4):
    raw = (Path(__file__).resolve().parent / f'board_candidate/block{block}_dw_params.bin').read_bytes()
    (fixture / f'parameters{block}.hex').write_text(''.join(f'{v:02x}\n' for v in raw))
for name in ('build_alignment_reset.tcl','physical_alignment_reset.tcl','alignreset_bitgen.tcl','alignreset_first_stage.tcl'):
    raw = (source / name).read_text().replace('alignreset', 'dwsplit')
    (stage / name.replace('alignment_reset','dw_split').replace('alignreset','dwsplit')).write_bytes(raw.encode())
(stage / 'preparation.json').write_text(json.dumps(dict(scope='REUSE_EXISTING_DW_CORE_NO_NEW_COMPUTE_ENGINE',
    control_abi='0x60002',mode_register='0x900000b0',modes={'0':'FULL_ORIGINAL_BLOCK34','1':'C144_DW3_STRIDE1','2':'C144_DW4_STRIDE2'},
    new_dma_buffers=0,driver_input_buffer=3,driver_output_buffer=4,
    cpu_gap_ms=[53.221531,12.064710,3.412620],simulation='PENDING',board='NOT_RUN',adopted=False),indent=2)+'\n')
print(stage)
