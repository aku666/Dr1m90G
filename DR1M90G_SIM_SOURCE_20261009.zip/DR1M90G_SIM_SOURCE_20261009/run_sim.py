"""Portable, device-free replay of existing RTL benches; Python stdlib + Icarus.
No vendor build/download scripts are executed. Original sources stay unchanged.
"""
from pathlib import Path
import argparse, concurrent.futures, hashlib, json, os, re, shutil, subprocess, tempfile, time

BASE=Path(__file__).resolve().parent
ROOT=Path('\\\\?\\'+str(BASE/'source')) if os.name=='nt' else BASE/'source'
D='experiments/sol_block34_dw_split_20261008/'
R='experiments/sol_pillow_resize_20261009/'
F=D+'uisrc/03_ip/uifdmadbuf/sfifo.v'
CASES={
 'dw_split':('tb_dw_split',[D+'tb_dw_split.v',D+'uisrc/01_rtl/front_block34/block34_axi_chain.v',D+'uisrc/01_rtl/front_block34/pointwise34_axi_master.v',D+'uisrc/01_rtl/front_block34/pointwise34_row_core.v',D+'uisrc/01_rtl/front_block34/dw144_stride_axi_master.v',D+'uisrc/01_rtl/dw16/dw3x3_patch_core.v'],[(D+'fixture/'+n,'fixture/'+n) for n in ['gold3.hex','gold4.hex','input3.hex','input4.hex','parameters3.hex','parameters4.hex']],['DW_SPLIT_REAL_PASS mode=1','DW_SPLIT_REAL_PASS mode=2','DW_SPLIT_SHARED_CORE_SERIAL_PASS_NO_NEW_ENGINE']),
 'resize':('tb_resize',[R+'tb_resize.v',R+'pillow_aa_224.v'],[(R+n,n) for n in ['h_coeff.hex','v_coeff.hex']+[f'{p}{i}.hex' for i in range(3) for p in ['input','expected']]],['REAL_1080P_PILLOW_Q22_RTL_PASS case=0','REAL_1080P_PILLOW_Q22_RTL_PASS case=1','REAL_1080P_PILLOW_Q22_RTL_PASS case=2','THREE_DISTINCT_REAL_FRAMES_PIXEL_EXACT_NO_DDR_NO_BOARD']),
 'isp_resize':('tb_isp_resize',[R+'tb_isp_resize.v',R+'isp_pixel_serial.v',R+'pillow_aa_224.v',F],[(R+n,n) for n in ['h_coeff.hex','v_coeff.hex']+[f'{p}{i}.hex' for i in range(2) for p in ['input','expected']]],['ISP_CDC_REAL_FRAME_EXACT case=0','ISP_CDC_REAL_FRAME_EXACT case=1','ISP_CDC_TWO_FRAMES_PIXEL_EXACT_SIM_ONLY']),
 'isp_fault':('tb_isp_fault',[R+'tb_isp_fault.v',R+'isp_pixel_serial.v',F],[],['FIFO_OVERFLOW_EXPLICIT_STICKY_NO_VALID','FRAME_GEOMETRY_FAILURE_EXPLICIT_NO_VALID']),
 'small_fdma':('tb_small_fdma',[R+'tb_small_fdma.v',R+'uidbuf_sim.v',F],[(R+'expected0.hex','expected0.hex')],['SMALL_UIDBUF_REAL_PIXELS_PASS pixels=50176 bursts=448 bytes=200704 slot=1','EXISTING_UIDBUF_NEW_GEOMETRY_SIM_ONLY_NOT_DDR_BOARD'])
}
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--iverilog',default='iverilog');ap.add_argument('--vvp',default='vvp')
    ap.add_argument('--case',choices=['all']+list(CASES),default='all')
    ap.add_argument('--jobs',type=int,default=1);ap.add_argument('--timeout',type=int,default=900)
    args=ap.parse_args()
    compiler=shutil.which(args.iverilog);runtime=shutil.which(args.vvp)
    if not compiler or not runtime:raise SystemExit('Install Icarus Verilog or supply --iverilog and --vvp paths.')
    env=dict(os.environ);env['PATH']=str(Path(compiler).parent)+os.pathsep+env.get('PATH','')
    out=BASE/'verification';out.mkdir(exist_ok=True)
    version=subprocess.run([compiler,'-V'],capture_output=True,text=True,env=env).stdout
    (out/'iverilog_version.txt').write_text(version,encoding='utf-8')
    def one(name):
        top,sources,data,markers=CASES[name];start=time.perf_counter()
        record={'case':name,'scope':'RTL behavioral simulation, not chip/DDR/board timing','top':top,'sources':sources,'fixtures':data,'status':'FAIL'}
        logs=[]
        try:
            with tempfile.TemporaryDirectory(prefix='dr1sim_',dir=out) as folder:
                work=Path(folder)
                for rel in sources:
                    shutil.copyfile(ROOT/rel,work/Path(rel).name)
                for rel,dest in data:
                    p=work/dest;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/rel,p)
                cmd=[compiler,'-g2012','-s',top,'-o','sim.vvp']+[Path(x).name for x in sources]
                proc=subprocess.run(cmd,cwd=work,env=env,capture_output=True,text=True,timeout=60)
                record['compile_returncode']=proc.returncode
                logs += [proc.stdout,proc.stderr]
                if proc.returncode:raise RuntimeError('Compile failed')
                proc=subprocess.run([runtime,'sim.vvp'],cwd=work,env=env,capture_output=True,text=True,timeout=args.timeout)
                logs += [proc.stdout,proc.stderr]
                joined='\n'.join(logs)
                if proc.returncode or re.search(r'ERROR:|FATAL:|Unable to open|Not enough words|Too many words',joined,re.I):raise RuntimeError('Simulation or fixture read failed')
                absent=[m for m in markers if m not in joined]
                if absent:raise RuntimeError('Missing PASS markers: '+str(absent))
                record['status']='PASS'
        except Exception as exc:record['error']=str(exc)
        record['host_elapsed_seconds']=round(time.perf_counter()-start,3)
        record['host_time_is_not_chip_time']=True
        (out/(name+'.log')).write_text('\n'.join(logs),encoding='utf-8')
        print(json.dumps({k:v for k,v in record.items() if k not in ('sources','fixtures')}),flush=True);return record
    chosen=list(CASES) if args.case=='all' else [args.case]
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,args.jobs)) as pool:
        records=list(pool.map(one,chosen))
    if args.case!='all' and (out/'simulation_results.json').exists():
        previous=json.loads((out/'simulation_results.json').read_text())
        records=[x for x in previous if x['case'] not in chosen]+records
    (out/'simulation_results.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    return 0 if all(x['status']=='PASS' for x in records) else 1
if __name__=='__main__':raise SystemExit(main())
